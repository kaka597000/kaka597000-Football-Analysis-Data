# football-data

> ⚠️ **This repository is a snapshot of the original data sources and is NOT meant for public use.** This data may not be kept in sync with the originals. Please use the original sources directly for research or production purposes. This repository exists solely for convenience to download these datasets in Google Colab.

---

## Data Sources

### StatsBomb Open Data

**Source:** https://github.com/statsbomb/open-data

StatsBomb are committed to sharing new data and research publicly to enhance understanding of the game of Football. They have made certain leagues of StatsBomb Data freely available for public use for research projects and genuine interest in football analytics.

#### Terms & Conditions

If you publish, share or distribute any research, analysis or insights based on this data, **you must state the data source as StatsBomb and use their logo**, available in their [Media Pack](https://statsbomb.com/media-pack/).

---

### Wyscout Soccer Match Event Dataset

**Source:** https://figshare.com/collections/Soccer_match_event_dataset/4415000

This dataset contains all spatio-temporal events (passes, shots, fouls, etc.) that occurred during all matches of an entire season of seven competitions (La Liga, Serie A, Bundesliga, Premier League, Ligue 1, FIFA World Cup 2018, UEFA Euro Cup 2016). The data was collected by [Wyscout](https://wyscout.com/).

#### License

This dataset is licensed under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).

#### Required Citations

If you use this data for your research or analyses, **you must cite the following papers**:

1. Pappalardo, L., Cintia, P., Rossi, A. _et al._ **A public data set of spatio-temporal match events in soccer competitions.** _Sci Data_ 6, 236 (2019). https://doi.org/10.1038/s41597-019-0247-7

2. Pappalardo, L. _et al._ **PlayeRank: Data-driven Performance Evaluation and Player Ranking in Soccer via a Machine Learning Approach.** _ACM Transactions on Intelligent Systems and Technologies (TIST)_ 10, 5, Article 59 (2019). https://doi.org/10.1145/3343172

**Dataset Citation:**

> Pappalardo, Luca; Massucco, Emanuele (2019). Soccer match event dataset. figshare. Collection. https://doi.org/10.6084/m9.figshare.c.4415000.v5
