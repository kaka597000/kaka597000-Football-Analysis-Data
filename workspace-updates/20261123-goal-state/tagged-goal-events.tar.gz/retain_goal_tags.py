"""Extract every tagged goal and own goal, and retain full period counts for 0-0 validation."""
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path

root=Path(__file__).resolve().parent/'events'
output=root/'tagged-events.jsonl'
with output.open('w',encoding='utf-8') as out:
    for path in sorted((root/'raw').glob('events_*.json')):
        with path.open('rb') as raw:
            checksum=hashlib.file_digest(raw,'sha256').hexdigest()
        counts=defaultdict(Counter)
        candidates=defaultdict(list)
        for index, event in enumerate(json.loads(path.read_bytes())):
            mid=event['matchId']
            counts[mid][event['matchPeriod']]+=1
            if any(t['id'] in (101,102) for t in event['tags']):
                candidates[mid].append(dict(source_index=index,event=event))
        for mid, periods in sorted(counts.items()):
            out.write(json.dumps(dict(source_file=path.name,source_sha256=checksum,match_id=mid,
                all_event_counts=periods,all_tag_101_102=candidates[mid]),separators=(',',':'))+'\n')
