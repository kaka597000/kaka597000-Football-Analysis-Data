#!/usr/bin/env python3
"""Rebuild exact-match Wyscout 2017/18 goal sequences against Football-Data fixtures."""
import csv, json, re, unicodedata, hashlib, collections, os
from functools import lru_cache
ROOT=os.path.dirname(os.path.abspath(__file__))
RAW=os.path.join(ROOT,'raw')
TARGET=os.path.join(ROOT,'football-data-fixtures-1718.jsonl')
OUTPUT=os.path.join(ROOT,'events.jsonl')
LEAGUES={
 'England':('eng.1','E0'),'Spain':('esp.1','SP1'),'Germany':('ger.1','D1'),
 'Italy':('ita.1','I1'),'France':('fra.1','F1')}
# Map Wyscout club display names to Football-Data 2017/18 team names.
ALIASES={
 'England': {'AFC Bournemouth':'Bournemouth','Brighton & Hove Albion':'Brighton','Huddersfield Town':'Huddersfield','Leicester City':'Leicester','Manchester City':'Man City','Manchester United':'Man United','Newcastle United':'Newcastle','Stoke City':'Stoke','Swansea City':'Swansea','Tottenham Hotspur':'Tottenham','West Bromwich Albion':'West Brom','West Ham United':'West Ham'},
 'France': {'Amiens SC':'Amiens','Olympique Lyonnais':'Lyon','Olympique Marseille':'Marseille','PSG':'Paris SG','Saint-Étienne':'St Etienne'},
 'Germany': {'Bayern München':'Bayern Munich','Borussia Dortmund':'Dortmund',"Borussia M'gladbach":"M'gladbach",'Bayer Leverkusen':'Leverkusen','Eintracht Frankfurt':'Ein Frankfurt','Köln':'FC Koln','Hamburger SV':'Hamburg','Hannover 96':'Hannover','Hertha BSC':'Hertha','Mainz 05':'Mainz'},
 'Italy': {'Hellas Verona':'Verona','Internazionale':'Inter'},
 'Spain': {'Athletic Club':'Ath Bilbao','Atlético Madrid':'Ath Madrid','Celta de Vigo':'Celta','Deportivo Alavés':'Alaves','Deportivo La Coruña':'La Coruna','Espanyol':'Espanol','Leganés':'Leganes','Málaga':'Malaga','Real Betis':'Betis','Real Sociedad':'Sociedad'}
}
def norm(s):
 s=unicodedata.normalize('NFKD',str(s)).encode('ascii','ignore').decode('ascii').lower()
 return re.sub(r'[^a-z0-9]','',s)
@lru_cache(maxsize=None)
def digest(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def parse_date(s):
 for fmt in ('%d/%m/%Y','%d/%m/%y'):
  try:return __import__('datetime').datetime.strptime(s,fmt).date().isoformat()
  except ValueError:pass
 raise ValueError('unknown Football-Data date '+repr(s))
def load_fd():
 targets=[]
 legacy={}
 for line in open(TARGET,encoding='utf8') if os.path.exists(TARGET) else []:
  x=json.loads(line)
  if x.get('source_file') and x.get('source_line') is not None:legacy[(x.get('source_file'),x.get('source_line'))]=x.get('match_id')
 for country,(cohort,code) in LEAGUES.items():
  path=os.path.join(RAW,'1718_'+code+'.csv')
  with open(path,encoding='utf-8-sig',newline='') as f:
   for line,row in enumerate(csv.DictReader(f),2):
    if not row.get('FTHG') or not row.get('FTAG'):continue
    targets.append({'match_id':legacy.get(('1718_'+code+'.csv',line)),'season':'1718','cohort':cohort,'game_date':parse_date(row['Date']),'home':row['HomeTeam'],'away':row['AwayTeam'],'home_goals':int(row['FTHG']),'away_goals':int(row['FTAG']),'home_ht_goals':int(row['HTHG']) if row.get('HTHG') else None,'away_ht_goals':int(row['HTAG']) if row.get('HTAG') else None,'source_file':'1718_'+code+'.csv','source_line':line,'source_sha256':digest(path)})
 return targets
def decode_wyscout(s):
 # Some Spanish display strings in this mirror are double-escaped (e.g. literal \\u00e9).
 return re.sub(r'\\u([0-9a-fA-F]{4})',lambda m:chr(int(m.group(1),16)),str(s))
def load_wyscout(country,teams):
 matches=json.load(open(os.path.join(RAW,'matches_'+country+'.json'),encoding='utf8'))
 events=json.load(open(os.path.join(RAW,'events_'+country+'.json'),encoding='utf8'))
 by_match=collections.defaultdict(list)
 for ix,e in enumerate(events):by_match[e['matchId']].append((ix,e))
 result=[]; period_order={'1H':1,'2H':2}
 for m in matches:
  if m.get('status')!='Played' or m.get('duration')!='Regular':continue
  sides={int(v['teamId']):v['side'] for v in m['teamsData'].values()}
  names={v['side']:decode_wyscout(teams[int(v['teamId'])]) for v in m['teamsData'].values()}
  evs=by_match[m['wyId']]
  unsupported=sorted({e['matchPeriod'] for _,e in evs if e.get('matchPeriod') not in period_order})
  standard=[]; own=[]; keeper_goals=[]
  for source_index,e in evs:
   tags={t['id'] for t in e.get('tags',[])}; period=e.get('matchPeriod')
   if 101 in tags and e.get('eventName') in ('Shot','Free Kick') and period in period_order:
    side=sides.get(int(e['teamId']))
    if side:standard.append((source_index,e,side,False,'goal_tag_101'))
   if 102 in tags and period in period_order:
    defender=sides.get(int(e['teamId']))
    if defender:own.append((source_index,e,'away' if defender=='home' else 'home',True,'own_goal_tag_102'))
   if 101 in tags and e.get('eventName')=='Save attempt' and period in period_order:
    keeper=sides.get(int(e['teamId']))
    if keeper:keeper_goals.append((source_index,e,'away' if keeper=='home' else 'home',False,'goalkeeper_goal_tag_101_fallback'))
  score={v['side']:int(v['score']) for v in m['teamsData'].values()}
  score={'home':score.get('home',0),'away':score.get('away',0)}
  selected=list(standard)+list(own); counts=collections.Counter(x[2] for x in selected)
  fallback_error=False; fallback_ambiguous=False
  # Goalkeeper records are accepted only for a residual score gap when exactly one goal-tagged
  # keeper event for that scoring side occurs in a half, and no scoring-side shot/free kick is
  # within five seconds (a nearby shot is a possible duplicate representation of the same goal).
  for side in ('home','away'):
   deficit=score[side]-counts[side]
   if deficit<0:
    fallback_error=True;continue
   if deficit==0:continue
   candidates=[]
   for half in ('1H','2H'):
    hc=[x for x in keeper_goals if x[2]==side and x[1]['matchPeriod']==half and x[0] not in {y[0] for y in selected}]
    if len(hc)!=1:continue
    candidate=hc[0]; sec=float(candidate[1]['eventSec'])
    nearby=[e for _,e in evs if e.get('matchPeriod')==half and sides.get(int(e.get('teamId',-1)))==side and e.get('eventName') in ('Shot','Free Kick') and abs(float(e.get('eventSec',-1))-sec)<=5]
    if not nearby:candidates.append(candidate)
   if deficit!=1 or len(candidates)!=1:
    fallback_error=True;fallback_ambiguous=True;continue
   selected.append(candidates[0]);counts[side]+=1
  selected.sort(key=lambda x:(period_order[x[1]['matchPeriod']],float(x[1]['eventSec']),x[0]))
  goals=[]
  for idx,e,side,is_own,kind in selected:
   period=e['matchPeriod'];sec=float(e['eventSec']);half=1 if period=='1H' else 2
   minute=(1 if half==1 else 46)+int(sec//60)
   goals.append({'minute':minute,'half':half,'period':period,'event_sec':sec,'added_time':sec>=2700,'side':side,'own_goal':is_own,'event_kind':kind,'source_event_id':e['id'],'source_team_id':int(e['teamId']),'source_order':idx})
  seq=collections.Counter(g['side'] for g in goals)
  sequence_score={'home':seq['home'],'away':seq['away']}
  ht=collections.Counter(g['side'] for g in goals if g['half']==1)
  sequence_ht={'home':ht['home'],'away':ht['away']}
  score_ht={v['side']:int(v.get('scoreHT',0)) for v in m['teamsData'].values()}
  score_ht={'home':score_ht.get('home',0),'away':score_ht.get('away',0)}
  result.append({'wyscout_match_id':m['wyId'],'date':m['dateutc'][:10],'home':names['home'],'away':names['away'],'score':score,'score_ht':score_ht,'duration':m['duration'],'status':m['status'],'event_count':len(evs),'events':goals,'sequence_score':sequence_score,'sequence_ht':sequence_ht,'event_score_matches_wyscout':sequence_score==score,'event_ht_matches_wyscout':sequence_ht==score_ht,'unsupported_periods':unsupported,'fallback_reconciliation_error':fallback_error,'fallback_ambiguous':fallback_ambiguous})
 return result

def main():
 fd=load_fd(); by_key=collections.defaultdict(list)
 for r in fd: by_key[(r['cohort'],r['game_date'],norm(r['home']),norm(r['away']))].append(r)
 teams={int(t['wyId']):decode_wyscout(t['name']) for t in json.load(open(os.path.join(RAW,'teams.json'),encoding='utf8'))}
 w_all=[]
 country_cohort={x[0]:x[1][0] for x in LEAGUES.items()}
 for country,(cohort,_) in LEAGUES.items():
  for w in load_wyscout(country,teams):
   fd_home=ALIASES[country].get(w['home'],w['home']);fd_away=ALIASES[country].get(w['away'],w['away'])
   key=(cohort,w['date'],norm(fd_home),norm(fd_away)); hits=by_key.get(key,[])
   w.update({'cohort':cohort,'football_data_home_name':fd_home,'football_data_away_name':fd_away,'join_candidate_count':len(hits)})
   if len(hits)==1:
    t=hits[0];w.update({'match_id':t['match_id'],'game_date':t['game_date'],'home_goals':t['home_goals'],'away_goals':t['away_goals'],'football_data_source_file':t['source_file'],'football_data_source_line':t['source_line'],'football_data_source_sha256':t['source_sha256'],'score_matches_football_data':(w['score']['home']==t['home_goals'] and w['score']['away']==t['away_goals']),'home':t['home'],'away':t['away']})
   else:w.update({'match_id':None,'home_goals':None,'away_goals':None,'score_matches_football_data':False})
   w_all.append(w)
 # Keep one output per Football-Data source row (expected 1,826); non-unique matches remain explicit.
 byfd={(w.get('football_data_source_file'),w.get('football_data_source_line')):w for w in w_all if w.get('football_data_source_file')}
 out=[]
 for t in fd:
  w=byfd.get((t['source_file'],t['source_line']))
  if not w:
   out.append({'match_id':None,'cohort':t['cohort'],'game_date':t['game_date'],'home':t['home'],'away':t['away'],'home_goals':t['home_goals'],'away_goals':t['away_goals'],'goals':[],'stage':'regular','score_basis':'regulation_90','training_eligible':False,'join_status':'missing_wyscout_match','football_data_source_file':t['source_file'],'football_data_source_line':t['source_line'],'football_data_source_sha256':t['source_sha256']})
   continue
  seq=w['sequence_score']
  score_ok=bool(w['score_matches_football_data'] and w['event_score_matches_wyscout'])
  ht_ok=bool(w['event_ht_matches_wyscout'] and w['score_ht']=={'home':t['home_ht_goals'] or 0,'away':t['away_ht_goals'] or 0})
  eligible=bool(w['join_candidate_count']==1 and score_ok and ht_ok and w['event_count']>0 and not w['unsupported_periods'] and not w['fallback_reconciliation_error'] and not w['fallback_ambiguous'])
  out.append({'match_id':w.get('match_id'),'cohort':w['cohort'],'stage':'regular','season':'1718','game_date':w['game_date'],'home':w['home'],'away':w['away'],'home_goals':t['home_goals'],'away_goals':t['away_goals'],'score_basis':'regulation_90','half_time_score':w['score_ht'],'football_data_half_time_score':{'home':t['home_ht_goals'],'away':t['away_ht_goals']},'goals':w['events'],'event_sequence_score':seq,'event_sequence_half_time_score':w['sequence_ht'],'wyscout_score':w['score'],'score_matches_wyscout':w['event_score_matches_wyscout'],'score_matches_football_data':w['score_matches_football_data'],'half_time_score_matches_wyscout':w['event_ht_matches_wyscout'],'half_time_score_matches_football_data':ht_ok,'join_status':'exact_one_to_one' if w['join_candidate_count']==1 else 'non_unique_join','event_count':w['event_count'],'unsupported_periods':w['unsupported_periods'],'fallback_reconciliation_error':w['fallback_reconciliation_error'],'fallback_ambiguous':w['fallback_ambiguous'],'training_eligible':eligible,'source':{'event_source':'Wyscout open event dataset (2017/18); source match ID '+str(w['wyscout_match_id']),'event_file':'raw/events_'+next(c for c,v in LEAGUES.items() if v[0]==w['cohort'])+'.json','match_file':'raw/matches_'+next(c for c,v in LEAGUES.items() if v[0]==w['cohort'])+'.json','football_data_file':'raw/'+t['source_file'],'football_data_line':t['source_line'],'football_data_sha256':t['source_sha256'],'football_data_source_url':f"https://www.football-data.co.uk/mmz4281/1718/{next(v[1] for v in LEAGUES.values() if v[0]==w['cohort'])}.csv",'event_file_sha256':digest(os.path.join(RAW,'events_'+next(c for c,v in LEAGUES.items() if v[0]==w['cohort'])+'.json')),'match_file_sha256':digest(os.path.join(RAW,'matches_'+next(c for c,v in LEAGUES.items() if v[0]==w['cohort'])+'.json'))}})
 with open(TARGET,'w') as f:
  for t in fd:f.write(json.dumps(t,ensure_ascii=False,separators=(',',':'))+'\n')
 with open(OUTPUT,'w') as f:
  for x in out:f.write(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n')
 print('football-data fixtures',len(fd),'wyscout matches',len(w_all),'output rows',len(out))
 print('join',collections.Counter(x['join_status'] for x in out))
 print('score matches WY',sum(x.get('score_matches_wyscout',False) for x in out),'FD',sum(x.get('score_matches_football_data',False) for x in out))
 print('non-empty event proof',sum(x.get('event_count',0)>0 for x in out),'goals reconciled',sum(x.get('event_sequence_score')=={'home':x.get('home_goals'),'away':x.get('away_goals')} for x in out),'HT reconciled',sum(x.get('half_time_score_matches_football_data',False) for x in out),'eligible',sum(x.get('training_eligible',False) for x in out))
 print('own goals',sum(g['own_goal'] for x in out for g in x.get('goals',[])),'fallback goals',sum(g['event_kind'].endswith('fallback') for x in out for g in x.get('goals',[])))
 print('unmatched',[(x['cohort'],x['game_date'],x['home'],x['away']) for x in out if x['join_status']!='exact_one_to_one'][:10])
 print('score mismatches',[(x['cohort'],x['game_date'],x['home'],x['away'],x['home_goals'],x['away_goals'],x['event_sequence_score']) for x in out if x['join_status']=='exact_one_to_one' and not x['score_matches_football_data']][:10])
if __name__=='__main__':main()
