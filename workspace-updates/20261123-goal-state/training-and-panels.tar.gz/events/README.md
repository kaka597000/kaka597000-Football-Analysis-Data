# Wyscout goal-event sequence corpus

This package contains a one-to-one join of all five Football-Data 2017/18 top-flight league fixture lists with the public Wyscout event dataset for its 2017/18 season. It is the full five-league Wyscout season available from the cited open dataset: England 380, Spain 380, Germany 306, Italy 380, France 380 (1,826 total). The Wyscout event stream includes match IDs, team IDs, half (`1H`/`2H`), seconds elapsed in period, event type, tags, and event IDs.

## Outputs

- `events.jsonl`: one row per Football-Data fixture; stable `football-data:<id>` match key, `cohort`, `stage=regular`, `game_date`, home/away, FT goals, `score_basis=regulation_90`, half-time scores, `goals` with home/away side, period/half, elapsed seconds, conventional minute, stoppage-time flag, own-goal status, original event ID and ordering.
- `football-data-fixtures-1718.jsonl`: identity/score sidecar for the raw Football-Data CSV rows, including row and SHA metadata. It also carries the stable IDs used by the events JSONL.
- `coverage.json`: counts, exact-match join coverage, final and half-time reconciliation, training eligibility and all exceptions.
- `build_events.py`: deterministic parser and exact-date/cohort/home/away join. It uses only local raw files and the sidecar.
- `raw/`: five Wyscout event files, five match files, name/label dictionaries, and the five Football-Data CSVs. SHA-256 and source URLs are in `source-manifest.json`.

The parser maps Wyscout goal tag `101` on Shot/Free Kick events to that event's team. Wyscout own-goal tag `102` is credited to the opposing side. One fixture (Chelsea–Manchester City, 2017-09-30) lacks the scoring Shot event, but has a single same-half keeper event tagged Goal and no scoring-team shot/free kick within five seconds; that event is retained as an explicitly marked fallback. Every final event sequence reconciles to both the Wyscout match score and Football-Data FTHG/FTAG for all 1,826 fixtures.

All 1,826 matchdays have at least one raw event record, including 0-0 matches. Three matches have a half-time disagreement between the Wyscout match metadata and both the Wyscout event-sequence count and Football-Data HTHG/HTAG. These rows remain in `events.jsonl`, with the mismatch fields visible, but `training_eligible=false`; the other 1,823 rows pass final and half-time score checks.

## Source and scope

Wyscout source mirror: https://github.com/zoid-archive/football-data/tree/bdf35deec5e62de68f55e96cf6d3a0954d24645a/wyscout-data. The pinned Git LFS event object SHA-256s are the hashes of the downloaded files and are recorded in the manifest. The mirror README points to the original Wyscout open dataset, Figshare collection DOI `10.6084/m9.figshare.c.4415000.v5`, describes the season and requires citing Pappalardo et al. (2019), *A public data set of spatio-temporal match events in soccer competitions*, Scientific Data 6:236, DOI `10.1038/s41597-019-0247-7`, and Pappalardo et al. (2019), *PlayeRank*, DOI `10.1145/3343172`. Its README states CC BY 4.0. The mirror itself warns it is a convenience snapshot and directs research/production use to original sources; cite Wyscout/Figshare and the papers when using these records.

Football-Data CSVs provide the fixture identity, regulation-time score, and half-time score checks; they are not the source of the within-match event timing. Rows are joined on same competition, exact calendar date, home team, and away team after the explicit team-name map in the builder. No nearest-date matching is used. Event data is post-match target/training evidence only and must not be supplied as the current match's pre-match input.

The requested recent seasons 2019/20–2023/24 were not available from this Wyscout dataset; its open release covers 2017/18. A local public Understat match page probe returned only an HTML “We will come back soon” placeholder rather than match shots/events; the response is preserved under `attempts/`. No claim of newer season coverage is made. All periods in this league-season source are regular 1H/2H; matches with extra time or penalty shootouts are excluded by `duration=Regular` and none are present in the selected league fixtures.
