#!/usr/bin/env bash
set -euo pipefail
out="$(dirname "$0")/raw"
repo_sha="bdf35deec5e62de68f55e96cf6d3a0954d24645a"
mkdir -p "$out"
for country in England France Germany Italy Spain; do
  curl -fL "https://media.githubusercontent.com/media/zoid-archive/football-data/${repo_sha}/wyscout-data/events/events_${country}.json" -o "$out/events_${country}.json"
  curl -fL "https://raw.githubusercontent.com/zoid-archive/football-data/${repo_sha}/wyscout-data/matches/matches_${country}.json" -o "$out/matches_${country}.json"
done
for path in teams.json competitions.json tags2name.csv eventid2name.csv; do
  curl -fL "https://raw.githubusercontent.com/zoid-archive/football-data/${repo_sha}/wyscout-data/${path}" -o "$out/${path}"
done
curl -fL "https://raw.githubusercontent.com/zoid-archive/football-data/${repo_sha}/README.md" -o "$out/wyscout_mirror_README.md"

for code in E0 SP1 D1 I1 F1; do
  curl -fL "https://www.football-data.co.uk/mmz4281/1718/${code}.csv" -o "$out/1718_${code}.csv"
done
