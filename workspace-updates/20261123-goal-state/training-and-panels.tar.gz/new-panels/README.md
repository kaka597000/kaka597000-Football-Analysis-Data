# Football-Data.co.uk outcome and market panels

This is an independent extraction of public Football-Data.co.uk season CSVs. Target folders include `raw/`, where byte-identical downloaded CSV bodies are retained, `raw-manifest.json` with URL/retrieval time/HTTP status/SHA-256, and `normalized.jsonl` with source row numbers and source hashes for replay. `normalize_panels.py` is the standalone parser; it follows `runtime/database/providers.py` date/result semantics and the Bet365/market field mapping used in `reports/kpi-optimization-20261123-round2/data/normalize_market_paths.py`. The source does not contain a provider quote clock or reliable kick-off time, so scrape/retrieval time is only provenance and is never substituted for a quote time.

## Scope check

`/workspace/Football-Analysis/configs/analysis-scope.json` currently includes `ned.1` (phase identity required), but does not include `eng.2` or `por.1` in its active competition list. Both `eng.2` and `por.1` are nevertheless present in `runtime/database/registry.py`, and the collector/optimization dataset includes them. The requested extraction covers all three; the scope distinction and hashes are recorded in `scope-and-method.json`.

## Panels

`normalized.jsonl` has two non-overlapping groups:

- **Requested secondary leagues, 2019/20–2026/27:** `eng.2` E1, `ned.1` N1, `por.1` P1.
- **Early Big Five, 2012/13–2014/15:** `eng.1` E0, `esp.1` SP1, `ita.1` I1, `ger.1` D1, `fra.1` F1.

Only rows with numeric full-time goals are emitted. Outcomes use the CSV's full-time goals and are tagged `regulation_90`; FTR was independently checked against those goals. Unplayed fixtures in 2026/27 are kept in raw source files but excluded from `normalized.jsonl`. All records are regular league games; the E1 files fit the 24-team, 552-fixture calendar in completed seasons, with no duplicate home/away/date rows. `coverage.json` reports source row counts, season cardinality, valid market fields, duplicate counts and parse discrepancies only; it contains no forecast results or hit-rate measures.

The Netherlands 2019/20 league ended after 232 completed fixtures during COVID and is marked `ABANDONED_COVID_AFTER_232_FT`, rather than as a full 306-match season. The 2026/27 counts are current partial finished results (England Championship 180, Netherlands 108, Portugal 98 as downloaded); they are not full-season cardinality claims.

## Market field policy

For 2019/20–2026/27 secondary-league files, Bet365 is retained as its own provider: close 1X2 `B365CH/B365CD/B365CA`, close O/U 2.5 `B365C>2.5/B365C<2.5`, and close Asian handicap `AHCh/B365CAHH/B365CAHA`. The corresponding open fields are included where present. Each market component is independently nullable so score rows with absent or partial odds remain in the dataset. `B365C`/`AHCh` are the source's closing-category fields; the CSV does not provide a Bet365 quote timestamp, so these are same-book close categories with **no source-clock certification**.

In 2012/13–2014/15 Big Five files, Bet365 opening 1X2 fields are present, but Bet365-specific closing columns for 1X2, totals and AH are absent. Where populated, the source's BetBrain/multi-book closing averages (`BbAv*`, `BbAH*`) are retained under `mixed_book_close_proxy`, explicitly marked `same_book=false`, `historical_proxy=true`; no mixed averages are relabeled Bet365. The early panel's result labels remain single-source match results, not mixed-book labels; the score-based historical state labels are usable, while its closing market values remain explicitly mixed-book proxies.

The CSV date is retained as a source local calendar date. No clock time is inferred for kick-off or price quotes. Method checks, field names and scope hashes are in `scope-and-method.json`; normalized file hashes and bytes are in `delivery-manifest.json`.
