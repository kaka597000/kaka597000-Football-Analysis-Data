"""Normalize football-data.co.uk regular-season CSVs without invented quote clocks."""
import csv,datetime,hashlib,json,math,pathlib,collections
ROOT=pathlib.Path(__file__).resolve().parent; RAW=ROOT/'raw'
SCOPE='/workspace/Football-Analysis/configs/analysis-scope.json'; REGISTRY='/workspace/Football-Analysis/runtime/database/registry.py'
LEAGUES={'eng.2':{'fd':'E1','name':'English Championship','expected':552},'ned.1':{'fd':'N1','name':'Dutch Eredivisie','expected':306},'por.1':{'fd':'P1','name':'Portuguese Primeira Liga','expected':306},'eng.1':{'fd':'E0','name':'English Premier League','expected':380},'esp.1':{'fd':'SP1','name':'Spanish La Liga','expected':380},'ita.1':{'fd':'I1','name':'Italian Serie A','expected':380},'ger.1':{'fd':'D1','name':'German Bundesliga','expected':306},'fra.1':{'fd':'F1','name':'French Ligue 1','expected':380}}
CURRENT=['1920','2021','2122','2223','2324','2425','2526','2627'];EARLY=['1213','1314','1415'];
BOOK_FIELDS={'open':{'1x2':['B365H','B365D','B365A'],'total_2_5':['B365>2.5','B365<2.5'],'ah':['AHh','B365AHH','B365AHA']},'close':{'1x2':['B365CH','B365CD','B365CA'],'total_2_5':['B365C>2.5','B365C<2.5'],'ah':['AHCh','B365CAHH','B365CAHA']}}
AVG_FIELDS={'close':{'1x2':['AvgCH','AvgCD','AvgCA'],'total_2_5':['AvgC>2.5','AvgC<2.5'],'ah':['AHCh','AvgCAHH','AvgCAHA']}}
BETBRAIN_AVG_FIELDS={'close':{'1x2':['BbAvH','BbAvD','BbAvA'],'total_2_5':['BbAv>2.5','BbAv<2.5'],'ah':['BbAHh','BbAvAHH','BbAvAHA']}}
def floatval(row,key,odds=True):
 raw=row.get(key)
 try:x=float(raw)
 except (TypeError,ValueError):return None
 return x if math.isfinite(x) and (x>1 if odds else True) else None
def date_parse(s):
 s=s.strip();return datetime.datetime.strptime(s,'%d/%m/%Y' if len(s)>=10 else '%d/%m/%y').date().isoformat()
def prices(row, fields):
 hda,ou,ah=fields['1x2'],fields['total_2_5'],fields['ah']
 vals=[floatval(row,k) for k in hda]; h2h={'home':vals[0],'draw':vals[1],'away':vals[2]} if all(v is not None for v in vals) else None
 vals=[floatval(row,k) for k in ou]; total={'line':2.5,'over':vals[0],'under':vals[1]} if all(v is not None for v in vals) else None
 line=floatval(row,ah[0],odds=False); home=floatval(row,ah[1]); away=floatval(row,ah[2]); handicap={'home_line':line,'home':home,'away':away} if line is not None and home is not None and away is not None else None
 # Keep partial raw fields separately; only call a market available when its whole requested set is valid.
 return {'h2h':h2h,'total_2_5':total,'asian_handicap':handicap}
def season_name(s):return f'20{s[:2]}/{s[2:]}'
def row_key(code,season,line,date,home,away):return 'football-data:'+hashlib.sha256(f'{code}|{season}|{line}|{date}|{home}|{away}'.encode()).hexdigest()[:24]
def main():
 retrieval=json.load(open(ROOT/'raw-manifest.json'));rawmeta={(x['cohort'],x['season_id']):x for x in retrieval['raw_assets'] if not x.get('error')};scope=json.load(open(SCOPE));scope_codes={x['code']:x for x in scope['competitions']};normalized=[];coverage=[];byseason=collections.defaultdict(list);parse_issues=[]
 for (code,season),meta in sorted(rawmeta.items()):
  b=(RAW/meta['file']).read_bytes();sha=hashlib.sha256(b).hexdigest()
  if sha!=meta['sha256']:raise ValueError('raw SHA mismatch '+meta['file'])
  text=b.decode('utf-8-sig',errors='replace');reader=csv.DictReader(text.splitlines());headers=reader.fieldnames or [];all_rows=list(reader);ft=[];unscored=0;score_mismatch=[]
  for line_no,row in enumerate(all_rows,2):
   home=(row.get('HomeTeam') or '').strip();away=(row.get('AwayTeam') or '').strip()
   if not home or not away:continue
   try:d=date_parse(row.get('Date',''))
   except Exception:parse_issues.append({'file':meta['file'],'line':line_no,'issue':'invalid_date'});continue
   try:hg=int(row.get('FTHG',''));ag=int(row.get('FTAG',''))
   except (TypeError,ValueError):unscored+=1;continue
   if hg<0 or ag<0:parse_issues.append({'file':meta['file'],'line':line_no,'issue':'negative_fulltime_score'});continue
   ftr='H' if hg>ag else 'A' if ag>hg else 'D'
   if (row.get('FTR') or '').strip() and ftr!=(row.get('FTR') or '').strip():score_mismatch.append(line_no)
   ft.append((line_no,row,d,home,away,hg,ag,ftr))
  teams={t for _,_,_,h,a,_,_,_ in ft for t in (h,a)};expected=LEAGUES[code]['expected'];expected_teams=24 if code=='eng.2' else (20 if code in ['eng.1','esp.1','ita.1','fra.1'] else 18)
  duplicates=collections.Counter((d,h,a) for _,_,d,h,a,_,_,_ in ft)
  dup_rows=sum(n-1 for n in duplicates.values() if n>1)
  season_status='CURRENT_SEASON_PARTIAL_FT_ONLY' if season=='2627' else ('ABANDONED_COVID_AFTER_232_FT' if code=='ned.1' and season=='1920' and len(ft)==232 else ('CARDINALITY_COMPLETE' if len(ft)==expected and not dup_rows else 'GAP_OR_EXCEPTION'))
  for line_no,row,d,home,away,hg,ag,ftr in ft:
   b365={stage:prices(row,fields) for stage,fields in BOOK_FIELDS.items()};avg={stage:prices(row,fields) for stage,fields in AVG_FIELDS.items()};bbavg={stage:prices(row,fields) for stage,fields in BETBRAIN_AVG_FIELDS.items()}
   raw_b365={stage:{market:{k:row.get(k) for k in keys} for market,keys in groups.items()} for stage,groups in BOOK_FIELDS.items()}
   raw_avg={stage:{market:{k:row.get(k) for k in keys} for market,keys in groups.items()} for stage,groups in AVG_FIELDS.items()}
   raw_bbavg={stage:{market:{k:row.get(k) for k in keys} for market,keys in groups.items()} for stage,groups in BETBRAIN_AVG_FIELDS.items()}
   has_b365_close=any(b365['close'][k] is not None for k in b365['close']);has_avg_close=any(avg.get('close',{}).get(k) is not None for k in avg.get('close',{}));has_bbavg_close=any(bbavg.get('close',{}).get(k) is not None for k in bbavg.get('close',{}))
   if season in EARLY and has_bbavg_close: market_class='EARLY_MIXED_BOOK_CLOSE_PROXY_B365_CLOSE_FIELDS_NOT_PUBLISHED'
   elif has_b365_close: market_class='BET365_SAME_BOOK_CLOSE_CATEGORY_NO_SOURCE_CLOCK'
   elif has_avg_close or has_bbavg_close: market_class='MIXED_BOOK_CLOSE_PROXY_NO_SOURCE_CLOCK'
   else: market_class='RESULT_ONLY_NO_QUALIFYING_CLOSE_MARKET'
   mixed_close=bbavg.get('close') if season in EARLY else avg.get('close')
   mixed_fields=raw_bbavg if season in EARLY else raw_avg
   mixed_provider='BetBrain multi-book closing average as represented in Football-Data BbAv/BbAH fields; contributors and quote time unspecified' if season in EARLY else 'Football-Data quoted market average (multi-book; exact contributor/time not recorded)'
   out={'match_id':row_key(code,season,line_no,d,home,away),'cohort':code,'competition':code,'league_name':LEAGUES[code]['name'],'stage':'regular','season':season_name(season),'season_id':season,'panel_group':'early_big_five_2012_13_to_2014_15' if season in EARLY else 'requested_secondary_leagues_2019_20_to_2026_27','age':'senior','gender':'men','entity':'club','level':'tier1' if code!='eng.2' else 'tier2','game_date':d,'date_basis':'football-data.co.uk CSV local date; no source kick-off clock field retained','home':home,'away':away,'home_goals':hg,'away_goals':ag,'ftr':ftr,'score_basis':'regulation_90','outcome_source_classification':'single-source Football-Data full-time league result; state-result labels available, no xG/lineup included','historical_proxy':False,'timestamp_certified':False,'season_coverage_status':season_status,'market_source_classification':market_class,'market_time_basis':'football-data.co.uk opening/closing category; no bookmaker quote timestamp in source; retrieval timestamp is not used as quote time','market':{'bet365':{'open':b365['open'],'close':b365['close'],'source_fields':raw_b365,'source_bookmaker':'Bet365','same_book':True},'mixed_book_close_proxy':{'close':mixed_close,'source_fields':mixed_fields,'source_bookmaker':mixed_provider,'same_book':False,'historical_proxy':True}},'source':{'provider':'football-data.co.uk','url':meta['url'],'file':'raw/'+meta['file'],'source_sha256':sha,'retrieved_at_utc':meta['retrieved_at_utc'],'source_line':line_no,'header_fields_available':headers}}
   normalized.append(out);byseason[(code,season)].append(out)
  coverage.append({'cohort':code,'season_id':season,'season':season_name(season),'panel_group':'early_big_five_2012_13_to_2014_15' if season in EARLY else 'requested_secondary_leagues_2019_20_to_2026_27','raw_rows':len(all_rows),'ft_regular_rows':len(ft),'unscored_rows':unscored,'team_count':len(teams),'expected_teams':expected_teams,'expected_full_season_matches':expected,'distinct_home_away_date_duplicate_rows':dup_rows,'ftr_mismatches':len(score_mismatch),'season_coverage_status':season_status,'market_class_counts':dict(collections.Counter(x['market_source_classification'] for x in byseason[(code,season)])),'bet365_open_1x2_rows':sum(x['market']['bet365']['open']['h2h'] is not None for x in byseason[(code,season)]),'bet365_open_ou25_rows':sum(x['market']['bet365']['open']['total_2_5'] is not None for x in byseason[(code,season)]),'bet365_open_ah_rows':sum(x['market']['bet365']['open']['asian_handicap'] is not None for x in byseason[(code,season)]),'bet365_close_1x2_rows':sum(x['market']['bet365']['close']['h2h'] is not None for x in byseason[(code,season)]),'bet365_close_ou25_rows':sum(x['market']['bet365']['close']['total_2_5'] is not None for x in byseason[(code,season)]),'bet365_close_ah_rows':sum(x['market']['bet365']['close']['asian_handicap'] is not None for x in byseason[(code,season)]),'mixed_proxy_close_1x2_rows':sum(x['market']['mixed_book_close_proxy']['close']['h2h'] is not None for x in byseason[(code,season)]),'mixed_proxy_close_ou25_rows':sum(x['market']['mixed_book_close_proxy']['close']['total_2_5'] is not None for x in byseason[(code,season)]),'mixed_proxy_close_ah_rows':sum(x['market']['mixed_book_close_proxy']['close']['asian_handicap'] is not None for x in byseason[(code,season)])})
 for season,code in []:pass
 normalized.sort(key=lambda x:(x['panel_group'],x['cohort'],x['season_id'],x['game_date'],x['home'],x['away']))
 with (ROOT/'normalized.jsonl').open('w') as f:
  for r in normalized:f.write(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n')
 # Coverage table is descriptive only and does not inspect forecast outcomes.
 (ROOT/'coverage.json').write_text(json.dumps({'coverage_scope':'source row and field availability only; no prediction or hit-rate data','retrieved_at_utc':retrieval['built_at_utc'],'seasons':coverage,'parse_issues':parse_issues},ensure_ascii=False,indent=2)+'\n')
 checks={'analysis_scope':{'source':SCOPE,'codes_present':[c for c in ['eng.2','ned.1','por.1'] if c in scope_codes],'classification':{c:scope_codes.get(c) for c in ['eng.2','ned.1','por.1']},'scope_sha256':hashlib.sha256(pathlib.Path(SCOPE).read_bytes()).hexdigest()},'registry':{'source':REGISTRY,'registered_codes':['eng.2','ned.1','por.1'],'registry_sha256':hashlib.sha256(pathlib.Path(REGISTRY).read_bytes()).hexdigest()},'normalization_policy':{'regular_phase':'league code in official football-data CSV; no cup/playoff datasets requested; E1 files match 24-club/552-game regular season for completed seasons','scores':'only rows with numeric FTHG/FTAG retained; CSV FTR cross-checked','current_2026_27':'only rows with FT score retained; upcoming/blank scores excluded','parser_reference':'Independent normalizer follows runtime/database/providers.py football_data CSV semantics (Date, HomeTeam, AwayTeam, FTHG/FTAG, regular league Div) and round2/data/normalize_market_paths.py market-column mappings; independent script needed to retain Bet365 and historical proxy field groups','times':'Date retained as source local date; no kick-off/quote time inferred from capture timestamps','bet365_close_fields':['B365CH','B365CD','B365CA','B365C>2.5','B365C<2.5','AHCh','B365CAHH','B365CAHA'],'opening_fields':['B365H','B365D','B365A','B365>2.5','B365<2.5','AHh','B365AHH','B365AHA'],'early_proxy_fields':['BbAvH','BbAvD','BbAvA','BbAv>2.5','BbAv<2.5','BbAHh','BbAvAHH','BbAvAHA'],'early_market_limit':'2012/13–2014/15 Football-Data exports have Bet365 opening 1X2 but no Bet365 close-specific columns; where available the closing comparison is the source BetBrain/multi-book average and is labeled proxy. This does not make the outcome labels mixed-book.'}}
 (ROOT/'scope-and-method.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
 sha=hashlib.sha256((ROOT/'normalized.jsonl').read_bytes()).hexdigest();covsha=hashlib.sha256((ROOT/'coverage.json').read_bytes()).hexdigest()
 print('normalized',len(normalized),'sha',sha,'coverage',covsha);print('issues',len(parse_issues),'FTR mismatches',sum(x['ftr_mismatches'] for x in coverage));
 for x in coverage:print(x['cohort'],x['season_id'],x['ft_regular_rows'],x['season_coverage_status'],'B365 close',x['bet365_close_1x2_rows'],x['bet365_close_ou25_rows'],x['bet365_close_ah_rows'],'mixed proxy close',x['mixed_proxy_close_1x2_rows'],x['mixed_proxy_close_ou25_rows'],x['mixed_proxy_close_ah_rows'])
if __name__=='__main__':main()
