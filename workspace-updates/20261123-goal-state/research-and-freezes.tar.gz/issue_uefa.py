"""Freeze every scheduled UEFA match in the window, including ones absent at HKJC."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import sys

from research.analysis_freeze import aware, digest
from research_program import displayed_exact_scores, goal_state_process as model, goal_state_forward as ledger
from research_program.goal_state_study import sha, write_new
from research_program.prior_team_strength import selections


def read(p):
    return json.loads(p.read_bytes())


def run(root, previous):
    sys.path.insert(0, str(previous))
    from freeze_displayed import markets
    capture = root/'uefa-prices'
    source = capture/'hkjc-espn-uefa-window.json'
    records = read(source)['records']
    board = {}
    fixtures = []
    for p in sorted((capture/'raw/espn').glob('scoreboard-*.json')):
        x = read(p)
        assert any(v['slug'] == 'uefa.champions' for v in x['leagues'])
        for e in x['events']:
            stamp = aware(e['date'])
            if not aware('2026-11-25T00:00:00+08:00') <= stamp < aware('2026-11-27T00:00:00+08:00'):
                continue
            assert e['season']['slug'] == 'league-phase' and not e['status']['type']['completed']
            assert e['status']['type']['state'] == 'pre'
            c, = e['competitions']
            teams = {t['homeAway']: t['team'] for t in c['competitors']}
            f = dict(match_id='espn:'+e['id'], cohort='uefa.champions', stage='league_phase',
                     kickoff_at=e['date'], home='espn:'+teams['home']['id'], away='espn:'+teams['away']['id'],
                     home_name=teams['home']['displayName'], away_name=teams['away']['displayName'],
                     score_basis='regulation_90', age='senior', gender='men', source_sha256=sha(p))
            if e['id'] in board:
                assert board[e['id']] == f
            else:
                board[e['id']] = f
                fixtures.append(f)
    assert len(board) == len(records) and set(board) == {r['id'] for r in records}
    choice = read(root/'study/choice.json')
    artifact = read(root/'study/artifact.json')
    assert digest(artifact) == choice['artifact_sha256']
    track = 'goal-state-uefa-displayed-scores'
    folder = root/'live-uefa'
    pairs = dict(direct_scores=['market','direct'], process=['market','selected'], multi_objective=['market','composite'])
    identity = dict(pairs=pairs, artifact_sha256=digest(artifact), choice=choice,
                    protocol_sha256=sha(root/'direct-protocol.json'), direct_version=displayed_exact_scores.VERSION,
                    complete_fixture_input_sha256=sha(source))
    plan = ledger.register(fixtures, identity, track, folder)
    cutoff = datetime.now(timezone.utc).isoformat()
    matches = {}
    for r in records:
        f = dict(board[r['id']], cutoff_at=cutoff)
        assert aware(f['kickoff_at']) == aware(r['date'])
        assert [f['home_name'],f['away_name']] == [r['home'],r['away']]
        m = r.get('markets')
        payload = dict(line=None, forecasts={}, status=r['hkjc_status'], source_sha256=sha(source))
        if m:
            assert aware(r['hkjc_kickoff_hkt']) == aware(f['kickoff_at']) and aware(m['response_complete_utc']) <= aware(cutoff)
            raw = capture/'raw/hkjc'/(r['hkjc_frontend_id']+'-all-markets.txt')
            assert sha(raw) == m['visible_text_sha256']
            pool_body = capture/m['source_response_file']
            assert sha(pool_body) == m['source_response_sha256']
            clocks = {k: m[k]['market_update_utc'] for k in ('correct_score', 'hda', 'totals')}
            assert all(aware(v) <= aware(m['response_complete_utc']) for v in clocks.values())
            offer, other, hda, totals = markets(raw.read_text())
            exact = {v['selection_original'].replace(':','-'): v['price_decimal'] for v in m['correct_score']['lines'][0]['selections']
                     if v['selection_type'] == 'exact_score'}
            groups = {v['selection_original']:v['price_decimal'] for v in m['correct_score']['lines'][0]['selections']
                      if v['selection_type'] == 'other_group'}
            assert exact == {v['score']:v['decimal'] for v in offer}
            assert groups == {v['label']:v['decimal'] for v in other}
            assert hda == {{'H':'home','A':'away','D':'draw'}[v['side_code']]:v['price_decimal'] for v in m['hda']['lines'][0]['selections']}
            assert sorted((v['line'],v['over'],v['under']) for v in totals) == sorted(
                ((sum(v['line_components'])/len(v['line_components']) if v['line_components'] else v['line_decimal']),next(s['price_decimal'] for s in v['selections'] if s['side_code']=='H'),
                 next(s['price_decimal'] for s in v['selections'] if s['side_code']=='L')) for v in m['totals']['lines'])
            direct = displayed_exact_scores.compare(offer, other, h2h=hda, totals=totals)
            total = direct['inferred_same_page']['source_total']
            arms = {name:model.compact(selections(matrix, total['line']))
                    for name,matrix in model.matrices(artifact, hda, total, f['kickoff_at'][:10]).items()}
            forecasts = dict(market=arms['market'], selected=arms[choice['selected']],
                             composite=model.combine_heads(arms, choice['heads']),
                             direct=dict(primary=direct['primary'],top3=direct['top3']))
            assert forecasts['market']['top3'] == direct['inferred_same_page']['top3']
            payload.update(line=total['line'], forecasts=forecasts, market_observed_at=m['response_complete_utc'],
                           individual_option_quoted_at=None, market_pool_updated_at=clocks,
                           official_response_sha256=sha(pool_body), source_url=m['url'], text_sha256=sha(raw),
                           official_match_id=m['official_match_id'], market_event_id=m['frontend_match_id'],
                           hda=hda, totals=totals, exact_scores=offer, grouped=other)
        matches[f['match_id']] = ledger.issue(plan, f, payload, track, folder)
    write_new(folder/'receipts.json', dict(registration=plan, matches=matches))
    write_new(folder/'pending.json', ledger.review(folder, [], root))


if __name__ == '__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--previous', type=Path, required=True)
    a=p.parse_args()
    run(a.root, a.previous)
