"""Create content-hashed, reproducible bundles and a human-readable scorecard."""
import argparse
import gzip
import hashlib
import io
import json
import math
from pathlib import Path
import re
import shutil
import subprocess
import tarfile

METRICS = ('score_top1','score_top3','wdl','actual_ou')


def read(path): return json.loads(path.read_bytes())


def write(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')


def sha(path):
    with path.open('rb') as stream: return hashlib.file_digest(stream,'sha256').hexdigest()


def bundle(root, target, files):
    files = sorted(set(p for p in files if p.is_file() and '__pycache__' not in p.parts))
    inventory = {}
    private = re.compile(rb'(?:gh[pousr]_[A-Za-z0-9]{32,}|github_pat_[A-Za-z0-9_]{45,}|(?i:authorization)[\x22\s:]+(?i:bearer) [A-Za-z0-9._-]{16,}|[?&](?i:apiKey|access_token)=[A-Za-z0-9_-]{20,})')
    with target.open('wb') as output, gzip.GzipFile(fileobj=output,mode='wb',compresslevel=5,mtime=0,filename='') as compressed, tarfile.open(fileobj=compressed, mode='w|') as t:
        for p in files:
            name = p.relative_to(root).as_posix()
            body = p.read_bytes()
            if private.search(body): raise ValueError('possible credential in retained file '+name)
            row = tarfile.TarInfo(name)
            row.mode, row.mtime, row.size = 0o644, 0, len(body)
            t.addfile(row, io.BytesIO(body))
            inventory[name] = hashlib.sha256(body).hexdigest()
    return {'file':target.name,'sha256':sha(target),'bytes':target.stat().st_size,'members':inventory}


def summary(folder):
    result = {'artifact':read(folder/'artifact.json'), 'choice':read(folder/'choice.json'), 'panels':{}}
    for key in ('selection','known','dutch','english_second','portuguese','recent'):
        r=read(folder/(key+'-report.json'))
        comparisons={}
        for label,c in r['comparisons'].items():
            tracks={name:{k:[m[k]['hits'],m[k]['eligible'],m[k]['resolved_gate_denominator']] for k in METRICS}
                    for name,arm in c['tracks'].items() for m in [arm['metrics']]}
            comparisons[label]=dict(population=c['population'],tracks=tracks,
                paired={k:{v:c['paired'][k][v] for v in ('gained','lost','net_hits','date_cluster_ci')} for k in METRICS})
        result['panels'][key]=dict(diagnostics=r['diagnostics'],comparisons=comparisons)
    return result


def main(root, data, code):
    folder=data/'workspace-updates/20261123-goal-state'
    source_commit=subprocess.check_output(['git','-C',str(code),'rev-parse','HEAD'],text=True).strip()
    evidence=root/'events'
    inputs=[evidence/'locked-training.jsonl',evidence/'events.jsonl',evidence/'football-data-fixtures-1718.jsonl',root/'new-panels/normalized.jsonl']
    inputs += [p for p in evidence.glob('*') if p.suffix in ('.json','.md','.py','.sh')]
    inputs += [p for p in (root/'new-panels').rglob('*') if p.name!='normalized.jsonl']
    archives=[bundle(root,folder/'training-and-panels.tar.gz',inputs)]
    # Attribute event streams upstream. Store the complete compact timeline and its
    # match authority, source hashes and one durable compressed stream per league.
    events_raw=[p for p in (evidence/'raw').rglob('*') if not p.name.startswith('events_')]
    archives.append(bundle(root,folder/'event-matches-and-provenance.tar.gz',events_raw))
    archives.append(bundle(root,folder/'tagged-goal-events.tar.gz',
                           [evidence/'tagged-events.jsonl',root/'retain_goal_tags.py']))
    live=root/'uefa-prices'
    sources=list((root/'context').rglob('*'))+[p for p in (root/'score-archive').rglob('*') if p.suffix in ('.json','.txt','.md')]
    # Use only specific market response bodies and public visible text, never browser session logs.
    uefa_bodies = {r['markets']['source_response_file'] for r in read(live/'hkjc-espn-uefa-window.json')['records'] if r.get('markets')}
    sources += [p for p in live.rglob('*') if p.is_file() and
                ('raw' not in p.relative_to(live).parts or p.parent.name=='espn' or p.suffix=='.txt'
                 or p.parent.name in ('public-pools','market-bodies','public-graphql')
                 or p.relative_to(live).as_posix() in uefa_bodies
                 or any(x in p.name for x in ('-public-pools','-pool-response','-graphql-public','-pools.json')))]
    early=root/'early-three'
    early_bodies={r['source_response']['file'] for r in read(early/'hkjc-official-three-matches.json')['events']}
    sources += [p for p in early.rglob('*') if p.is_file() and
                ('raw' not in p.relative_to(early).parts or p.suffix=='.txt' or
                 p.relative_to(early).as_posix() in early_bodies or p.name.endswith('response.metadata.json'))]
    archives.append(bundle(root,folder/'market-evidence.tar.gz',sources))
    runs=[p for p in (root/'study').glob('*') if p.is_file()]
    for target in ('live-36','live-open','live-uefa','live-early','live-directions'):
        runs.extend((root/target).glob('*.json'))
    runs.extend(root.glob('*protocol.json'))
    runs += [root/'issue_club_slate.py',root/'issue_uefa.py',root/'verify_early.py',root/'integration-final.log',root/'research-freeze.json',root/'research-record.json',root/'supplement-freeze.json',root/'supplement-record.json',root/'issue_displayed_directions.py',root/'final-integration.log',root/'package.py']
    archives.append(bundle(root,folder/'research-and-freezes.tar.gz',runs))
    scorecard=summary(root/'study')
    write(folder/'results.json',scorecard)
    prospective={}
    for name in ('live-36','live-open','live-uefa','live-early','live-directions'):
        row=read(root/name/'receipts.json')
        report=read(root/name/'verified-pending.json')
        prospective[name]=dict(registered=len(row['matches']),registration=row['registration'],
            pairs={p:{arm:{k:v['issued'] for k,v in track['metrics'].items()} for arm,track in r['tracks'].items()} for p,r in report.items()})
    write(folder/'manifest.json',dict(source_commit=source_commit,previous_source='3e0845afc442ae8635811edd4dde74a2360d9039',
        previous_data='8a6039f9fd222edcf0cbd668f0754cc2275fa8de',protocol_registration='01f65877870d1b5a320281db3f0406ff155101c8',
        selection_lock_commit='60a4e2465d4f062ba84bbd4174529cd7e2b53413', algorithm_commit='3655acc86e27a0eb54324dcea5ca602cbf5bc610',
        protocols={p.name:sha(p) for p in root.glob('*protocol.json')},prospective=prospective,bundles=archives,
        files={p.name:sha(p) for p in sorted(folder.iterdir()) if p.is_file() and p.name not in ('manifest.json','README.md')}))


if __name__=='__main__':
    p=argparse.ArgumentParser()
    for k in ('root','data','code'):p.add_argument('--'+k,type=Path,required=True)
    a=p.parse_args()
    main(a.root,a.data,a.code)
