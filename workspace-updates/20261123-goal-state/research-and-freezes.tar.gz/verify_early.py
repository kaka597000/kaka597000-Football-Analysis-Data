"""Append source-clock evidence for the three earlier issues without modifying them."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path

from research.analysis_freeze import aware, verify
from research_program import goal_state_forward as ledger
from research_program.goal_state_study import sha, write_new


def read(p):
    return json.loads(p.read_bytes())


def run(root, previous):
    source=root/'early-three/hkjc-official-three-matches.json'
    events=read(source)['events']
    older=previous/'direct'
    rows=read(older/'summary.json')['rows']
    previous_records={}
    for r in rows:
        ref=r['receipt']
        rec=verify(read(older/(ref['freeze_id']+'.json')))
        assert rec['record_sha256']==ref['sha256']
        previous_records[r['match_id']]=rec
    assert {'espn:'+r['espn_event_id'] for r in events}==set(previous_records)
    folder=root/'live-early'
    track='goal-state-early-quote-check'
    plan=ledger.register([rec['fixture'] for rec in previous_records.values()],
        dict(pairs={'quoted':['market','selected']}, source_sha256=sha(source), source_age_window_seconds=3600,
             original_firsts={mid:r['record_sha256'] for mid,r in previous_records.items()}), track, folder)
    now=datetime.now(timezone.utc).isoformat()
    matches={}
    for e in events:
        mid='espn:'+e['espn_event_id']
        old=previous_records[mid]
        f=dict(old['fixture'],cutoff_at=now)
        assert e['league_code']==f['cohort'] and aware(e['scheduled_at_utc'])==aware(f['kickoff_at'])
        ref=e['source_response']
        assert sha(source.parent/ref['file'])==ref['sha256']
        clocks={k:e['markets'][k]['market_update_utc'] for k in ('correct_score','hda','totals')}
        ages={k:(aware(e['response_complete_utc'])-aware(v)).total_seconds() for k,v in clocks.items()}
        assert all(t>3600 for t in ages.values())
        matches[mid]=ledger.issue(plan,f,dict(line=None,forecasts={},status='SOURCE_POOLS_OLDER_THAN_ONE_HOUR',
            displayed_observed_at=e['response_complete_utc'],source_pool_updated_at=clocks,age_seconds_at_capture=ages,
            source_response_sha256=ref['sha256'],original_first_sha256=old['record_sha256'],
            original_score_choices=old['payload']['prediction']['top3']),track,folder)
    write_new(folder/'receipts.json',dict(registration=plan,matches=matches))
    write_new(folder/'pending.json',ledger.review(folder,[],root))


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--root',required=True,type=Path)
    p.add_argument('--previous',required=True,type=Path)
    a=p.parse_args()
    run(a.root,a.previous)
