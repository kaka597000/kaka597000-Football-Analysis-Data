"""Issue R4 first research forecasts using two independent input pairs on the R3 fixture universe."""
import argparse
from collections import Counter
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path

from research.analysis_freeze import aware, digest, verify
from research_program import goal_state_forward as ledger, goal_state_process as model
from research_program.club_market_capture import attach
from research_program.goal_state_study import sha, write_new
from research_program.prior_team_strength import selections
from research_program.score_form import poisson_matrix


def read(p):
    return json.loads(p.read_bytes())


def brief(p):
    total = p.get('total')
    return dict(primary=p['primary'], top3=p['top3'], wdl=p['wdl'],
                total_side=total['direction'] if total else None, total_line=total['line'] if total else None)


def main(root, previous, opening=False):
    folder = root/('live-open' if opening else 'live-36')
    artifact, choice = (read(root/'study'/s) for s in ('artifact.json', 'choice.json'))
    assert choice['artifact_sha256'] == digest(artifact)
    refs = read(previous/'forward/receipts.json')
    original_plan = verify(read(previous/'issued'/(refs['register']['freeze_id']+'.json')))
    fixtures = read(previous/'next/fixtures.json')
    archive = read(previous/'study/infer-source-manifest.json')
    teams = read(previous/'study/infer-team-ids.json')
    gather = root/'context/raw-live-20261123T0403Z'
    capture = {r['espn_match_id']: r for r in read(gather/'capture-manifest.json')['records']}
    assert set(original_plan['payload']['fixtures']) == set(capture) == {f['match_id'] for f in fixtures}
    pairs = dict(quoted=['market','selected'], team_only=['team_poisson','team_process'], multi_objective=['market','composite'])
    identity = dict(pairs=pairs, model_sha256=digest(artifact), selected=choice, main_protocol=sha(root/'protocol.json'),
                    fallback_protocol=sha(root/'no-quote-forward-protocol.json'), heads_protocol=sha(root/'heads-protocol.json'), previous=original_plan['record_sha256'])
    if opening:
        pairs.pop('team_only')
        identity['opening_protocol'] = sha(root/'opening-market-protocol.json')
    track = 'goal-state-opening-36' if opening else 'goal-state-club-36'
    plan = ledger.register(fixtures, identity, track, folder)
    cutoff = datetime.now(timezone.utc).isoformat()
    matches, coverage = {}, Counter()
    for f in fixtures:
        mid = f['match_id']
        old = verify(read(previous/'issued'/(refs['matches'][mid]['freeze_id']+'.json')))
        evidence = previous/'forward'/(mid.replace(':', '-')+'-forecast.json')
        assert sha(evidence) == old['payload']['candidate']['forecast_evidence_sha256']
        previous_goal = read(evidence)['candidate']
        meta = archive[mid]
        shared = {key:dict(meta[key], file=str((previous/meta[key]['file']).relative_to(root.parent)))
                  for key in ('espn','events')}
        current = capture[mid]
        event = current['event_id']
        assert event == meta['event_id'] and current['status'] == 200
        raw = gather/(event+'-odds.json')
        assert sha(raw) == current['sha256']
        shared['event_id'] = event
        shared['odds'] = dict(file=str(raw.relative_to(root.parent)), sha256=sha(raw),
                              url='https://api.infersports.dev/v1/events/'+event+'/odds?period=full_time',
                              captured_at=current['retrieved_at_utc'])
        f = attach(dict(f, cutoff_at=cutoff), root.parent, shared, teams, cutoff,
                   maximum_age=timedelta(hours=24 if opening else 1))
        if opening:
            trial = dict(status='ABSTAIN', reasons=[f['market_availability']])
            if f['market_availability'] == 'AGE_WINDOW_SAME_BOOK_PAIR':
                q = f['total_quote']
                source, = [v for v in f['market_snapshots'] if v['market']=='1x2' and v['bookmaker']==q['bookmaker']]
                assert q['provider_match_id']==source['provider_match_id']==event
                assert q['query_time']==source['query_time'] and q['source_sha256']==source['source_sha256']==sha(raw)
                total = dict(line=q['line'], over=q['over_odds'], under=q['under_odds'])
                arms = {n:selections(m, q['line']) for n,m in model.matrices(
                    artifact, source['decimal_odds'], total, f['kickoff_at'][:10]).items()}
                trial = dict(status='AVAILABLE', arms=arms,
                    composite=model.combine_heads({n:model.compact(v) for n,v in arms.items()},choice['heads']),
                    quote_snapshot=dict(h2h=source,total=q,age_seconds={
                        'h2h':(aware(cutoff)-aware(source['quoted_at'])).total_seconds(),
                        'total':(aware(cutoff)-aware(q['quoted_at'])).total_seconds()}))
        else:
            trial = model.predict(artifact, f, choice['selected'], choice['heads'])
        quote = f.get('total_quote')
        line = quote['line'] if quote else None
        predictions = {}
        rates = previous_goal.get('strength_rates')
        if rates and not opening:
            size = 51
            control = poisson_matrix(rates, (size,size))
            challenger = model.simulate(rates, artifact['factors'], size)
            for name,matrix in [('team_poisson', control), ('team_process', challenger)]:
                predictions[name] = brief(selections(matrix, line))
        if trial['status'] == 'AVAILABLE':
            predictions['market'] = brief(trial['arms']['market'])
            predictions['composite'] = trial['composite']
            predictions['selected'] = brief(trial['arms'][choice['selected']])
        payload = dict(line=line, forecasts=predictions, market_status=trial['status'], market_reasons=trial.get('reasons'),
                       market_availability=f['market_availability'], total_quote=quote, source_evidence=shared,
                       source_per_market=trial.get('quote_snapshot'), original_first_sha256=old['record_sha256'],
                       original_forecast_file_sha256=sha(evidence), previous_team_rates=rates)
        matches[mid] = ledger.issue(plan, f, payload, track, folder)
        coverage[f['market_availability']] += 1
    write_new(folder/'receipts.json', dict(registration=plan, matches=matches, coverage=dict(coverage)))
    write_new(folder/'pending.json', ledger.review(folder, [], root))


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--root', required=True, type=Path)
    p.add_argument('--previous', required=True, type=Path)
    p.add_argument('--opening', action='store_true')
    a = p.parse_args()
    main(a.root, a.previous, a.opening)
