"""Issue a separate whole-book direction pair on the full pre-registered Champions League slate."""
import argparse
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path

from research.analysis_freeze import aware
from research_program import displayed_market_directions as direct, goal_state_forward as ledger
from research_program.goal_state_study import sha, write_new


def read(p):
    return json.loads(p.read_bytes())


def run(root):
    parent=root/'live-uefa'
    index=read(parent/'receipts.json')
    previous={mid:ledger._read(parent,r) for mid,r in index['matches'].items()}
    data=root/'uefa-prices'
    source=data/'hkjc-espn-uefa-window.json'
    events={f"espn:{r['id']}":r for r in read(source)['records']}
    assert set(previous)==set(events)
    folder=root/'live-directions'
    track='whole-correct-score-book-directions'
    plan=ledger.register([r['fixture'] for r in previous.values()],
        dict(pairs={'direction':['market','correct_score_book']},model=direct.VERSION,
             rules_sha256=sha(root/'direction-protocol.json'),source_sha256=sha(source),
             input_registration_sha256=index['registration']['sha256']),track,folder)
    matches={}
    now=datetime.now(timezone.utc).isoformat()
    for mid,prev in previous.items():
        f=dict(prev['fixture'],cutoff_at=now)
        original=prev['payload']
        payload=dict(input_first_sha256=prev['record_sha256'],forecasts={},line=None)
        if 'market' in original['forecasts']:
            m=events[mid]['markets']
            assert all(timedelta(0)<=aware(now)-aware(t)<=timedelta(hours=1) for t in original['market_pool_updated_at'].values())
            assert sha(data/m['source_response_file'])==m['source_response_sha256']==original['official_response_sha256']
            pool=m['correct_score']['lines'][0]['selections']
            assert len(pool)==33 and all(v['available'] is True for v in pool)
            groups=[dict(code=v['source_combination_code'],decimal=v['price_decimal']) for v in pool if v['selection_type']=='other_group']
            study=direct.predict(original['exact_scores'],groups,original['line'])
            ref=original['forecasts']['market']
            def heads(wdl, side):
                return dict(wdl=wdl,total_side=side,total_line=original['line'] if side else None)
            payload.update(line=original['line'],forecasts={'market':heads(ref['wdl'],ref['total_side']),
                'correct_score_book':heads(study['wdl'],study['total_side'])}, estimate=study,
                source_response_sha256=original['official_response_sha256'],source_pool_times=original['market_pool_updated_at'])
        matches[mid]=ledger.issue(plan,f,payload,track,folder)
    write_new(folder/'receipts.json',dict(registration=plan,matches=matches))
    write_new(folder/'verified-pending.json',ledger.review(folder,[],root))


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--root',type=Path,required=True)
    run(p.parse_args().root)
