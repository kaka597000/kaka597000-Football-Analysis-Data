# Historical pre-match correct-score archive — source audit

**Status: no qualifying bulk historical market snapshot found; 0 match rows admitted.** This directory preserves reproducible evidence from two independent public-source routes and documents why none is represented as a complete pre-match correct-score market. No hit rates or post-match reconstructions were calculated.

## Scope

The repository analysis scope is `/workspace/Football-Analysis-kpi-20261123-r3/configs/analysis-scope.json` (SHA-256 recorded in `metadata/analysis-scope-reference.json`): 20 men's senior competitions, including ENG/ESP/GER/ITA/FRA top flights, JPN/KOR/AUS/USA/NOR/SWE/NED, UEFA Champions/Europa/Conference, AFC Champions Elite, FIFA World Cup, Nations League, Japanese League Cup and Brazil Serie A. Score basis is regulation 90 minutes. The target was historical pre-match **full correct-score selection prices for every offered option**, including losing selections and explicit “other” groups, with event identity and quote-time semantics. HDA/total-goals markets were secondary.

## Route A — public GitHub HKJC collectors

Repository metadata/tree snapshots and README files are under `metadata/github-*.json` and `raw/github-*-README`; manifest includes capture time, URLs, status, size and SHA-256. Repositories checked include:

- `hello0827/HKJCOddsScraper`
- `chungbfong/HKJC-Football-Odds-Crawler`
- `cyrusscchan/hkjc-football-data`
- `rkwyu/sport-betting-data`

These are scraper/source repositories. Their checked-in trees contain source and documentation, not an archived date-stamped dataset of match-level correct-score quotes. The README in the HKJC crawler has an illustrative sample with “Correct Score For Full Time” and a scrape-time example (29 March 2018), but the snippet does not establish a verifiable match ID, source response, quote snapshot or complete original market page. It is therefore retained only as evidence that the collector schema can parse correct-score arrays, **not ingested as historical odds**. The sport-betting-data repository marks football as unfinished and does not contain football quote archives.

## Route B — Betfair official Historical Data portal

`raw/betfair-historical-portal.html` and its referenced app JS are public HTTP 200 captures. The portal app client references account/data-plan functions such as `GetUserDetails`, `GetCollectionOptions`, `PreDownload` and `GetMyData`; it is not a static public archive. A common guessed `/api/sample-download` path returned HTTP 404, captured in `raw/betfair-sample-download-response.bin`. No login, subscription, purchase or access control bypass was attempted. No sample market file was obtained, so there are no Betfair market IDs/timestamps/runner ladders to report.

## Other open odds data checked

GitHub repository `iredchuk/soccer-bookmaker-odds` has bulk CSV/JSON for the five European leagues, but its data are conventional historical bookmaker result odds and do not include the complete correct-score market ladders. It cannot support the requested all-outcome CS dataset. Exchange last traded or winner settlement data, where found, would also not prove pre-match prices for losing selections and are not substituted.

## Time and admissibility

Capture timestamps in this audit are collector observation times in UTC, not quote times, match kickoffs, market suspension/settlement times, or publisher “updated” times. For the HKJC README example, the text says `Scrape Time` but gives no captured source page/response or exact market-date identity. No quote timestamp is promoted from this example. Betfair portal capture time likewise is not a quote timestamp. Because no eligible quote records were obtained, source quote age/staleness is **not applicable / unknown**, not zero.

## Machine-readable files

- `metadata/acquisition-manifest.json`: URLs, HTTP status, captured-at, size and file hash for raw source evidence.
- `metadata/github-*.json`: repository metadata and complete file-tree listings at capture.
- `metadata/analysis-scope-reference.json`: exact analysis-scope config identity.
- `raw/`: byte-preserved public HTML/JS/error body and public README files.
- `quotes.json`: intentionally empty schema stub; `accepted_record_count` is zero.

No fixture/result-derived score prices are included. No prices are invented or inferred from FT outcomes.
