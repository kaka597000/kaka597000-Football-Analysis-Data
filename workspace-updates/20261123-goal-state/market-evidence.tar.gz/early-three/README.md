# Fresh pre-kickoff access capture: R3 three fixtures

This is a separate R4 snapshot of Monza–Fiorentina, Levante–Elche, and Brentford–Everton, using the official HKJC public all-odds pages and official match-market responses. The crosswalk is the previously retained R3 ESPN fixture identity, rechecked against fresh public ESPN date-scoreboard responses (`raw/espn/`). No authentication or paid access was used.

## Observed results

All three pages and match-specific API responses returned normally before their ESPN scheduled kickoffs. The official source pools were open (`SELLINGSTARTED`) and all available lines/selections were `AVAILABLE`. Each had 28 exact correct scores and 5 other groups, plus HDA and full-time total-goals markets. Raw text and DOM HTML are kept for each public match page; each isolated complete match-specific JSON response and its response-body SHA-256 are saved beside it. `hkjc-official-three-matches.json` has the normalized prices, pool update clocks/ages, capture clocks, identities, and per-event DOM/API price checks.

**Freshness is poor:** source `foPools.updateAt` for Monza and Levante was `2026-11-19T19:30:01.807+08:00`, making the pools about 320,074–320,078 seconds old at response completion. Brentford pools were last updated `2026-11-12T20:49:55.251+08:00`, about 920,088 seconds old. The pages separately showed `更新時間: 23/11/2026 12:24` (page-level only); this does not refresh the source quote timestamp. Although the pools returned `SELLINGSTARTED`, this package labels the prices stale and does not treat fetch time or page update time as live/current price time. Use the quote timestamps as recorded; do not freeze them as fresh market inputs without a separate decision.

All three markets expose pool-level update times, not per-selection timestamps. For 90-minute semantics, source market codes/labels are `CRS`/“波膽” and `HAD`/“主客和”; HKJC fixed-odds rules 3.2 and 3.4 distinguish legal-time HDA/formal score from extra-time markets. Standard full-time `HIL`/“入球大細” is retained separately from extra-time total goals per rule 3.3. Prices are the source decimal fixed-odds display.

## Files

- `hkjc-official-three-matches.json`: machine-readable crosswalk and market data.
- `raw/hkjc/*-all-markets.txt` / `.html`: readable DOM and complete rendered public page.
- `raw/hkjc/*-matchMarket-response.json`: isolated complete official response body per event.
- `raw/hkjc/*-matchMarket-response.metadata.json`: URL, status, request and response-completion UTC, response-body SHA-256; no cookies or browser headers.
- `raw/espn/scoreboard-*-20261123.json`: fresh public ESPN event data; capture manifest includes URL/status/hash/time.
- `raw/hkjc-fixed-odds-rules.*`: official HKJC rules source reused from the same R3 public capture; metadata retains its original capture URL/time/hash.
- `evidence-manifest.json`: byte sizes and SHA-256 for files in this directory.
