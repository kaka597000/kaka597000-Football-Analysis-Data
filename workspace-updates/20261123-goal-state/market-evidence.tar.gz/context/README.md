# r4 context: score-state evidence and 36-fixture quote panel

Scope: original r3 36-fixture slate, UTC kickoffs 2026-11-27 to 2026-11-29. This is an evidence/input refresh, not a forecast or profitability evaluation. No fixture was screened by expected result or win rate.

## Research evidence

Read conclusions below are limited to the accessible article abstracts. Publisher DOI links identify the canonical publications; abstracts were fetched through Crossref/OpenAlex where publisher full text was not publicly accessible. No hit rate, betting edge, or current performance is inferred. Full citation and abstract-source details are in `literature-sources.json`.

| Source | Read-supported result | Limit |
|---|---|---|
| [Mark Dixon and Michael Robinson (1998), *A birth process model for association football matches*](<https://doi.org/10.1111/1467-9884.00152>) — DOI 10.1111/1467-9884.00152 | Abstract reports over 4,000 recent matches from the main English competitions; goal-scoring rate changes over the match, tends to increase over time, and is influenced by current score. Their model uses team attack/defense, home advantage, current score, and time left as interacting birth processes and reports satisfactory fit. | Historical English competition sample and abstract-level evidence; supports score/time dependence as a modeling feature, not a universal effect size, current market accuracy, or a validated hit rate. |
| [Dimitris Karlis and Ioannis Ntzoufras (2003), *Analysis of sports data by using bivariate Poisson models*](<https://doi.org/10.1111/1467-9884.00366>) — DOI 10.1111/1467-9884.00366 | Abstract describes bivariate-Poisson models that allow correlation between two scores; reports that even slight correlation can improve fit and prediction of football draws, and discusses diagonal inflation/overdispersion extensions. | Joint-score distribution modeling; does not itself establish score-state goal hazard effects or calibrated market probabilities. |
| [Mark J. Dixon and Stuart G. Coles (1997), *Modelling Association Football Scores and Inefficiencies in the Football Betting Market*](<https://doi.org/10.1111/1467-9876.00065>) — DOI 10.1111/1467-9876.00065 | Abstract reports a Poisson-regression model fit to 1992–95 English league/cup matches, addressing data structure and dynamic team performance, then tested against bookmaker odds from 1995–96. | Historical market/data and abstract-level claim only; the paper abstract is not evidence that an adapted model earns profit now or has a specified hit rate. |

### Quarter-line settlement rule source

HKJC’s official football fixed-odds rules, §3.8(a)(ii)(b), describe an even two-way split of stake across two different handicap lines and use a 1.5/1.0 example; §3.8(a)(ii)(b)(1–3) gives outcomes when the adjusted result is a clear win, a tie (one half push/refund), or a loss; §3.8(b)(iv) specifies refund when the adjusted score is a tie. For totals, §3.9(a)(iii)(b) explicitly splits stake equally over lines 2.5 and 3 and §3.9(a)(iii)(b)(2) says a total of 3 wins the 2.5 half and refunds the 3 half. Therefore a quarter line such as 2.75 is operationalized as equal stakes at 2.5 and 3: a 3-goal result is half-win/half-push for Over 2.75 (and the inverse for Under); for Asian handicap +0.25/-0.25 the two half-stakes likewise settle at the adjacent 0 and 0.5 lines, yielding half-win or half-loss depending on side/result. HKJC calls this a “system” two-line bet rather than using the phrase “quarter line”; the quoted rule text itself is the operator source for the split/push mechanics. Official URL: [HKJC rules](<https://special.hkjc.com/e-win/-/media/Sites/JCBW/Special/betting-rules/Football_Rule_3_Chi_20260429>). Retained source PDF SHA-256: `1a0e0f946da5944b005e618a89c5488ecf9c6cf2b079a3e5e38b8494d086a387`; text extraction: `r3/live-acquisition/raw/hkjc-fixed-odds-rules.txt` (capture 2026-11-23T03:13:50Z).

## 36-fixture panel audit

- Frozen first-version preparation cutoff: **2026-11-23T03:09:42.199223+00:00**. This was not reopened, revised, or used as the new quote time.
- Original odds capture window: **2026-11-23T02:57:01.147571+00:00–2026-11-23T02:57:07.943810+00:00** (all old quote payloads retained in r3).
- New lawful public pull: **2026-11-23T04:03:45.978042+00:00–2026-11-23T04:04:32.908505+00:00 UTC**, one GET per mapped event ID (36 requests, approximately 1.1 seconds apart) to InferSports keyless read-only route `https://api.infersports.dev/v1/events/{event_id}/odds?period=full_time`. No authentication or access-control bypass.
- The new event response has a single request body containing all returned full-time quote rows for that event, but each individual row retains its own source `as_of`; these row clocks are not interchangeable with capture time.
- All 36 responses were HTTP 200; 36/36 returned complete positive full-time 1X2, AH, and totals from at least one bookmaker; every fixture had at least one same-book pair with full 1X2 + one or more two-sided AH lines + at least two two-sided totals lines. Per-event source quotes include every returned bookmaker/line/prices/status/source clock in `infer-36-market-panel.json` and raw payloads.
- 36/36 response-level `stale` flags were false. Across 967 full-time rows, source quote age at retrieval was 120 ≤1h, 825 >1–16h, and 22 >16h. Thus response-level `stale=false` is not a substitute for examining each row clock.
- Bookmakers observed in the refreshed responses: Crown, M8Bet, Nova88, SBOBET. Same-book panel coverage is computed from positive `open` rows. `missing_or_limited` records the absent books by market for each event; it does not indicate missing market families in the overall event panel.
- Original ESPN fixture/event IDs/team mapping is preserved from r3 `next/fixtures.json` and r3 InferSports event crosswalk. The table below also lists the original frozen issue record and the main total side/line/book recorded in the first version. Blank values mean the first-version CSV did not record a corresponding main quote; they are not imputed. Full immutable `market_baseline`, actual `total_quote`, raw market snapshot list, source event ID and response provenance are embedded in each row of the JSON.

### Original fixture-to-event mapping and previously frozen market fields

| ESPN match ID | InferSports event ID | Fixture | First-version frozen ID | First-version W/D/L | Recorded total side / line / book | market baseline score |
|---|---|---|---|---|---|---|
| espn:401884720 | evt_WB7ADVR6 | Werder Bremen vs Borussia Mönchengladbach | 69cb5466c14a52be-v000001 | 主胜 | — / — / — | — |
| espn:401876392 | evt_B607J8VP | Brest vs Paris FC | dd737e5d106c3c30-v000001 | 主胜 | — / — / — | — |
| espn:401875004 | evt_YT1M7PBW | Venezia vs Bologna | ff3423962560d869-v000001 | 客胜 | — / — / — | — |
| espn:401879225 | evt_QND9HYCS | Nottingham Forest vs Chelsea | c458a97cdf1aa4c6-v000001 | 客胜 | 小 / 3.0 / m8bet | — |
| espn:401882791 | evt_B607Z7VP | Levante vs Racing Santander | ed93b5c35027d5f4-v000001 | 主胜 | — / — / — | — |
| espn:401882796 | evt_G538MMY6 | Real Betis vs Rayo Vallecano | b276955749dcc26b-v000001 | 主胜 | — / — / — | — |
| espn:401875081 | evt_9DYPW6H2 | Frosinone vs Parma | 7ac0fe5441164df6-v000001 | 主胜 | — / — / — | — |
| espn:401884719 | evt_H8BWNJ26 | SC Paderborn 07 vs Schalke 04 | 1380df034b53ce6b-v000001 | 主胜 | 小 / 2.75 / nova88 | 1-1 |
| espn:401884721 | evt_836BS0M7 | FC Cologne vs SV Elversberg | 786e9d4a6ffed075-v000001 | 主胜 | 大 / 3.0 / nova88 | 1-1 |
| espn:401884722 | evt_5KC30XTH | Hamburg SV vs Bayern Munich | b44366f1b2898bb9-v000001 | 客胜 | 小 / 3.75 / nova88 | 1-2 |
| espn:401884723 | evt_QND92BCS | Mainz vs 1. FC Union Berlin | 8d710fcffba40c1d-v000001 | 主胜 | 小 / 3.0 / nova88 | — |
| espn:401879226 | evt_5KC31ATH | Manchester United vs Brentford | a07dfe0f58382194-v000001 | 主胜 | 大 / 3.0 / nova88 | 1-1 |
| espn:401879227 | evt_H8BWRZ26 | Leeds United vs Coventry City | da3961c0e366ea94-v000001 | 主胜 | 小 / 2.75 / nova88 | 1-0 |
| espn:401882790 | evt_FANQCPKC | Málaga vs Athletic Club | 9d6deae4045a6fd6-v000001 | 客胜 | — / — / — | — |
| espn:401876394 | evt_NSJDMXGJ | Angers vs Lens | 6816dac22e9aba2e-v000001 | 客胜 | — / — / — | — |
| espn:401874826 | evt_QND9H1CS | Torino vs Lazio | b53c1baacfc95701-v000001 | 客胜 | — / — / — | — |
| espn:401878752 | evt_YT1M79BW | Ipswich Town vs Aston Villa | ff42c7ff84f59b70-v000001 | 客胜 | 大 / 3.0 / nova88 | 1-1 |
| espn:401882793 | evt_4RXK92QV | Elche vs Atlético Madrid | 6650da5ad1c16a2f-v000001 | 客胜 | — / — / — | — |
| espn:401884726 | evt_YT1MZHBW | VfB Stuttgart vs Eintracht Frankfurt | b585cb8a00b1cd5d-v000001 | 主胜 | 小 / 3.75 / nova88 | 2-1 |
| espn:401876387 | evt_VE4Z3ZS2 | Paris Saint-Germain vs Lorient | d547e37289a430b1-v000001 | 主胜 | — / — / — | — |
| espn:401876388 | evt_FANQPWKC | Nice vs Troyes | 7663669d045febbc-v000001 | 主胜 | — / — / — | — |
| espn:401876390 | evt_B607JZVP | Le Mans vs Lille | cde2f15ec5e7fa3f-v000001 | 客胜 | — / — / — | — |
| espn:401876391 | evt_G53877Y6 | Le Havre AC vs Strasbourg | 4ba9300caf5a7225-v000001 | 客胜 | — / — / — | — |
| espn:401874977 | evt_E2R4QTF3 | Internazionale vs Genoa | cd6ad26aa2ca68b5-v000001 | 主胜 | — / — / — | — |
| espn:401882789 | evt_PYM2A8WS | Real Madrid vs Alavés | 3f6cb0468ac25a3c-v000001 | 主胜 | — / — / — | — |
| espn:401875031 | evt_2MVRNHAY | Udinese vs Fiorentina | 38fd98f71179a0f3-v000001 | 客胜 | — / — / — | — |
| espn:401879229 | evt_PYM2A6WS | Everton vs Liverpool | ca8eca16d8feafa3-v000001 | 客胜 | 小 / 2.75 / nova88 | 1-1 |
| espn:401882787 | evt_T9P10P68 | Valencia vs Osasuna | 5d9d0648bd0db13c-v000001 | 主胜 | — / — / — | — |
| espn:401876393 | evt_4RXKHAQV | AJ Auxerre vs Marseille | 7d3d0361340e57a1-v000001 | 客胜 | — / — / — | — |
| espn:401874992 | evt_A7SNGAX7 | Sassuolo vs Napoli | d811a024c4620953-v000001 | 客胜 | — / — / — | — |
| espn:401879224 | evt_DJTYBW8P | Sunderland vs Tottenham Hotspur | 6f74d4207242c779-v000001 | 客胜 | 小 / 2.5 / nova88 | 1-1 |
| espn:401879228 | evt_VE4ZJXS2 | Fulham vs AFC Bournemouth | 8343a26ed6c4ca18-v000001 | 客胜 | 小 / 2.75 / nova88 | 1-1 |
| espn:401879230 | evt_NSJD8AGJ | Crystal Palace vs Hull City | c71531005663594e-v000001 | 主胜 | 小 / 2.75 / nova88 | 1-1 |
| espn:401879231 | evt_B607ZDVP | Brighton & Hove Albion vs Newcastle United | 3fef038f7ff931f8-v000001 | 主胜 | 大 / 3.0 / nova88 | 1-1 |
| espn:401884724 | evt_PYM2XEWS | SC Freiburg vs RB Leipzig | 1cde31063c84dd0b-v000001 | 客胜 | 大 / 3.25 / nova88 | 1-1 |
| espn:401882794 | evt_CG8H2MP3 | Deportivo vs Barcelona | dcf7f95381664438-v000001 | 客胜 | — / — / — | — |

## Files and provenance

- `infer-36-market-panel.json`: fixture/event audit, prior first-version records and recorded quote fields, full refresh panel, per-row clocks, freshness and missingness.
- `raw-live-20261123T0403Z/`: all 36 refresh payloads and request/response metadata; `capture-manifest.json` enumerates request time, HTTP status, SHA-256 and bytes.
- `literature-sources.json`: DOI citations and abstract-level conclusions/limits. `raw-research/` retains the Crossref and OpenAlex response bodies plus retrieval times and SHA-256 metadata used to verify bibliographic identity and abstract statements.
- r3 source hashes are in `infer-36-market-panel.json` (`source_sha256`). Raw refresh body SHA-256 values are repeated in the panel and capture manifest.
