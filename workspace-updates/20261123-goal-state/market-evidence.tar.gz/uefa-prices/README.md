# UEFA Champions League official HKJC prices (public snapshot)

Collection window requested: **Beijing time 2026-11-25 00:00 inclusive to 2026-11-27 00:00 exclusive** (`2026-11-24T16:00Z` to `2026-11-26T16:00Z`). ESPN's official competition route lists **18 men's UEFA Champions League league-phase fixtures** in that exact time interval. The normal public HKJC event list exposed **9** matching fixtures and public all-odds pages; all 9 pages showed complete full-time correct-score prices, HDA, and regulation full-time total-goals lines. The other 9 ESPN fixtures are retained with explicit missing HKJC IDs and status; no market/page is inferred for them.

## Deliverables

- `hkjc-espn-uefa-window.json`: machine-readable 18-event ESPN↔HKJC crosswalk, 9 collected events with normalized CRS/HAD/HIL ladders, quote-pool status and source times, 9 missing-list entries.
- `raw/espn/scoreboard-YYYYMMDD.json`: original ESPN public scoreboard response bodies queried by UTC event date; three dates queried to establish the complete interval boundary. The date filter is exact UTC, not the Beijing calendar date.
- `raw/hkjc/public-home.txt`, `public-allmatchlist-55.json`, `public-list-capture.json`: public list evidence and visible page clock. The list displayed “共有 55 場賽事” and the underlying current match-list response contained 55 items; it contained 9 UEFA events for the first matchday and none of the second matchday's 9 fixtures.
- `raw/hkjc/FB*-all-markets.txt` and `.html`: public, rendered, match-specific source pages. The text file is the readable transcript used to cross-check market prices.
- `raw/hkjc/FB*-matchMarket-response.json` and `.metadata.json`: one isolated, complete, match-specific public GraphQL response per event. Response bodies are saved as delivered by Playwright, with SHA-256 of the exact adjacent bytes. No browser cookies or request headers are included. Metadata has the request URL/method/status and capture start/response-complete times.
- `raw/hkjc-fixed-odds-rules.*`: public HKJC fixed-odds rules, including the distinction between regulation formal score, half-time score, and extra-time score.
- `evidence-manifest.json`: SHA-256 and byte size for source/evidence files.

## Canonical keys and time fields

Each `records[]` entry has `espn_event_id`, `date` (ESPN kickoff UTC), `home`/`away` (ESPN event order), `season.slug`, `competition_note`, ESPN scheduled state, and regulation period metadata from the captured source. HKJC identity is `hkjc_match_id` plus `hkjc_frontend_id`; raw HKJC home/away labels and kick-off in HKT remain alongside the crosswalk.

For collected events, `markets.correct_score` is the official `CRS` pool rendered as “波膽”; it has exactly **28 exact score selections + 5 other groups = 33 selections** per match. `markets.hda` is the `HAD` pool (“主客和”). `markets.totals` is the `HIL` pool (“入球大細”) with every source line and both sides. All captured pools were `SELLINGSTARTED`, and every line and selection was `AVAILABLE` in the same response. Prices retain original text and numeric decimal value; HKJC fixed odds are decimal total-return multipliers under rules 3.1(b).

Every pool has `market_update_at_original` and `market_update_utc`, sourced from the official `foPools.updateAt` field. This is a **pool-level last-update timestamp**, not a separate timestamp per runner/selection. It was `2026-11-23T12:00:06.567+08:00` for all three pools in all nine matches. Request start and response completion are separate collector observation clocks. The rendered page separately displayed `更新時間: 23/11/2026 12:12`, a page-level timestamp, not the quote clock. At response completion, the pool update ages ranged about **755–843 seconds** (12m35s–14m03s); these figures are computed against actual per-match response completion and do not replace source timestamps.

The HKJC fixed-odds rules 3.2 and 3.4 explicitly define standard HDA at the end of legal match time and distinguish full-time formal score from extra-time score. The rows were `HAD` and `CRS`, with page labels “主客和” and “波膽”; half-time markets were separate. For the `HIL` total-goals pool, the source type/page labels identify the standard full-time market; the rules 3.3 separately distinguish legal-time and extra-time totals. No extra-time pool was substituted.

`markets.dom_to_pool_price_check` reports the per-match check: all 33 correct-score selections, all three HDA selections, and every HIL line/side price from the isolated response match the visible DOM transcript. Market/selection statuses are retained. There is no forecast or expected-effect calculation in this data package.

## Scope and missing entries

ESPN records are selected by exact event timestamp in `[2026-11-24T16:00:00Z, 2026-11-26T16:00:00Z)`, competition route `soccer/uefa.champions`, `season.slug=league-phase`, and scheduled status. On capture, the public HKJC current match list included:

- 25 Nov Beijing: Bodo/Glimt–LASK Linz; Galatasaray–Aston Villa; Arsenal–Borussia Dortmund; Como–AEK Athens; Feyenoord–Porto; Manchester City–Napoli; RB Leipzig–Lens; Real Madrid–PSV Eindhoven; Slovan Bratislava–Real Betis.
- 26 Nov Beijing: Sabah FK–Barcelona; Slavia Prague–Villarreal; Atlético Madrid–Viking FK; Club Brugge–Liverpool; Internazionale–VfB Stuttgart; Lille–Bayern Munich; Paris Saint-Germain–AS Roma; Shakhtar Donetsk–Fenerbahce; Sporting CP–Manchester United.

Only the first 9 were in the official public 55-match list snapshot and had public match IDs/pages at this capture. The other 9 records have `hkjc_status=not_in_hkjc_current_public_55_match_list_at_capture`; their HKJC IDs, quotes and quote times are null. This documents absence from that specific public list response, not a claim that HKJC never lists the events.
