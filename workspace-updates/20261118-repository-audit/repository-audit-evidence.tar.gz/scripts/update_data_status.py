"""Reconcile current source/runtime/result status; retain the previous full index."""
import json,sys
from datetime import datetime,timezone
from pathlib import Path
D=Path('/workspace/kaka597000-Football-Analysis-Data');R=Path('/workspace/WCPP/research/repo-audit-20261118')
source=sys.argv[1];p=D/'latest-source.json';x=json.loads(p.read_text())
backup=R/'latest-source-before.json'
if not backup.exists():backup.write_bytes(p.read_bytes())
review='workspace-updates/20261118-all-analysis-review';audit='workspace-updates/20261118-repository-audit'
x.update(previous_source_commit=x['commit'],commit=source,source_code_change_commit=source,
 synchronized_at=datetime.now(timezone.utc).astimezone(timezone(__import__('datetime').timedelta(hours=8))).isoformat(),
 source_branch='research/repo-audit-20261118',source_merge_status='AUDIT_SOURCE_PUSHED_DEPLOYMENT_PENDING',
 latest_repository_audit=audit+'/README.md',latest_complete_analysis_review=review+'/manifest.json',
 latest_nations_review=review+'/manifest.json')
for path in (review,audit):
 if path not in x['additional_workspace_updates']:x['additional_workspace_updates'].append(path)
rep=x['latest_nations_repair_status'];rep.update(settled=18,pending=0,
 latest_review=review+'/repair-complete-forward-review.json',
 autonomous_market_status='THEODDS_AUTHENTICATED; NO_FUTURE_TARGETS_AT_LAST_OBSERVED_RUN_44174108654')
xg=x['latest_nations_xg_status'];xg.update(settled=8,pending=0,latest_review=review+'/xg-first-forward-review.json',
 first_future_result={'population':8,'statistical_top1_hits_per_arm':3,'wdl_hits_per_arm':4,
 'total_settlements_per_arm':{'win':4,'half_win':0,'push':1,'half_loss':0,'loss':3},'automatic_promotion':False})
metrics=json.loads((D/review/'metrics.json').read_text())
x['latest_nations_review_status']={'review_completed_at_beijing':'2026-11-18T08:32:37+08:00',
 'all_analysis_population':11,'comprehensive_first':metrics['comprehensive_first']['summary'],
 'nations_comprehensive_first':metrics['comprehensive_first']['by_competition']['uefa.nations'],
 'model_promotion':False}
v=x['actual_runtime_versions']
v['pre_audit_observed_runtime_receipt']='future/runtime-revisions/44174108654-1.json'
for key in ('collector','polling_overlay','evaluation_overlay','market_bridge'):
 v[key+'_target_commit']=source
 v[key+'_verified_run']=44174108654
 if key=='collector':v['collector_verified_commit']='3eca355a9e801c15d21c9b9b87e84592be15cee9'
 else:v[key+'_commit']='3eca355a9e801c15d21c9b9b87e84592be15cee9'
v.update(collector_rollout_status='NEW_AUDIT_REVISION_PENDING_ROLLOUT; OBSERVED_PREVIOUS_RUN_RECONCILED',
 polling_overlay_status='NEW_AUDIT_REVISION_PENDING_ROLLOUT',evaluation_overlay_status='NEW_AUDIT_REVISION_PENDING_ROLLOUT',
 market_bridge_rollout_status='NEW_AUDIT_REVISION_PENDING_ROLLOUT',
 market_credentials_status='THEODDS_HTTP200_ON_44174108654; INFER_ACTIONS_BINDING_AWAITING_NEW_RUN',
 nations_xg_review_status='FIRST_8_MANUALLY_VERIFIED_AND_ARCHIVED; NO_AUTOMATIC_XG_REVIEW_JOB',
 last_strict_integration_source_commit=source)
tests=json.loads((R/'integration-summary.json').read_text());v.update(last_strict_integration_test_executions=tests['test_executions'],last_strict_integration_skips=tests['skipped'])
p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
