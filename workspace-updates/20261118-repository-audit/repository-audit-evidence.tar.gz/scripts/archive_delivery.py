"""Archive this audit without duplicating existing retained model bundles."""
import hashlib,json,os,re,shutil,subprocess,tarfile
from datetime import datetime,timezone
from pathlib import Path
R=Path('/workspace/WCPP/research/repo-audit-20261118');D=Path('/workspace/kaka597000-Football-Analysis-Data');S=Path('/workspace/Football-Analysis-audit-20261118')
DEST=D/'workspace-updates/20261118-repository-audit';DEST.mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
source=subprocess.check_output(['git','-C',str(S),'rev-parse','HEAD'],text=True).strip()
inv=json.loads((R/'infer-evidence/evidence-inventory.json').read_text());retained=[]
for name,info in inv['sources'].items():
 for key,expected in [('raw_path','sha256'),('metadata_path','metadata_sha256')]:
  if key not in info:continue
  p=Path(info[key]);assert sha(p)==info[expected]
  out=R/'original-evidence'/name/p.name;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,out)
  retained.append({'original_path':str(p),'archived_relative_path':str(out.relative_to(R)),'sha256':sha(out)})
dump(R/'retained-original-paths.json',retained)
required=[]
for name in ['workspace-updates/20261117-nations-xg-research/manifest.json','workspace-updates/20261118-all-analysis-review/manifest.json','workspace-updates/20261117-tonight-analysis/manifest.json']:
 p=D/name;m=json.loads(p.read_text());archive=p.parent/m['archive'];h=m.get('sha256',m.get('archive_sha256'));assert sha(archive)==h
 required.append({'manifest':name,'manifest_sha256':sha(p),'archive':str(archive.relative_to(D)),'archive_sha256':h})
dump(R/'input-dependencies.json',{'repository':'kaka597000/kaka597000-Football-Analysis-Data','verified_data_commit':'2ceecf1d51b0673bbe1b1fe4df4306d184a07f9b','existing_archives_reused':required,'repair_bundle':'future/nations-repair-bundle','repair_results':'future/nations-repair-state/results.json','old_analysis_frozen_sources_retained':True})
source_receipt={'repository':'kaka597000/Football-Analysis','commit':source,'pull_request':'https://github.com/kaka597000/Football-Analysis/pull/43','source_files_sha256':{name:sha(S/name) for name in ['runtime/automation/infer_market_snapshot.py','configs/infer-nations-alias-reviews.json','runtime/research/total_objectives.py']},'runtime_rollout':'SEE_SEPARATE_DELIVERY_RECEIPT'}
dump(R/'source-receipt.json',source_receipt)
# Inspect actual credential values in memory; never serialize or print them.
secret_values={v.encode() for k,v in os.environ.items() if re.search(r'KEY|TOKEN|SECRET|PASSWORD',k,re.I) and len(v)>=12}
paths=sorted(p for p in R.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ('.pyc',))
for p in paths:
 body=p.read_bytes()
 if any(v in body for v in secret_values):raise ValueError('credential match in archive input: '+str(p.relative_to(R)))
archive=DEST/'repository-audit-evidence.tar.gz';members=[]
with tarfile.open(archive,'w:gz') as tar:
 for p in paths:
  name=str(p.relative_to(R));tar.add(p,arcname=name,recursive=False);members.append({'path':name,'bytes':p.stat().st_size,'sha256':sha(p)})
manifest={'schema':'WCPP-REPOSITORY-AUDIT-ARCHIVE-1','created_at':datetime.now(timezone.utc).isoformat(),'source':source_receipt,'archive':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':members,'new_prematch_predictions':0,'active_model_changed':False,'new_policy_future_samples':0,'scope':'ENGINEERING_REPLAY_AND_KNOWN_OUTCOME_POLICY_DIAGNOSTIC'}
dump(DEST/'manifest.json',manifest)
for name in ['infer-evidence/alias-review-candidates.json','infer-evidence/d-live/conclusion.json','infer-replay/summary.json','total-objectives/protocol.json','total-objectives/report.json','integration-summary.json','source-receipt.json','input-dependencies.json','active-assets-verified.json']:
 out=DEST/name;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/name,out)
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'members':len(members),'sha256':sha(archive),'credential_scan':'passed'}))
