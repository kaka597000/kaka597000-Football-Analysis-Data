"""Predeclared descriptive policies on unchanged known-outcome forward matrices."""
import collections,hashlib,json,sys
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
S=Path('/workspace/Football-Analysis-audit-20261118');sys.path[:0]=[str(S/'runtime'),str(S/'runtime/v5')]
from research.analysis_freeze import verify,save
from research.total_objectives import decisions,OBJECTIVES
from nations_league.repair_forward import review as validate_repair
from nations_league.xg_research import review_forward as validate_xg
from v2.model import total_settlement
ROOT=Path('/workspace/WCPP/research/repo-audit-20261118');out=ROOT/'total-objectives';out.mkdir(exist_ok=False)
D=Path('/workspace/kaka597000-Football-Analysis-Data');review=Path('/workspace/WCPP/reports/all-review-20261118-0818')
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):
 with p.open('x') as f:json.dump(x,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
state=D/'future/nations-repair-state'
results=[dict(r,source_path=str(state/r['source_path'])) for r in read(state/'results.json')]
xg_results=[r for r in read(review/'verified-results.json') if r['competition']=='uefa.nations']
bundles={'repair':D/'future/nations-repair-bundle','xg':Path('/workspace/WCPP/research/nations-xg-20261117/forward')}
protocol={'schema':'WCPP-TOTAL-OBJECTIVE-DIAGNOSTIC-1','registered_at':datetime.now(timezone.utc).isoformat(),
 'policies':list(OBJECTIVES),'known_results_before_registration':True,'classification':'DEVELOPMENT_COUNTERFACTUAL_NOT_FORWARD_POLICY_VALIDATION',
 'selection':'all frozen first predictions in the two complete plans, every track kept separate',
 'same_matrix_same_quote':True,'default_policy_change':False,'future_policy_promotion':False,
 'score_policy_unchanged':True,'parameters_tuned':[],'bootstrap_seed':20261118,'bootstrap_draws':20000,
 'sources':{name:{'plan_sha256':sha(root/'plan.json'),'freezes':{p.name:sha(p) for p in sorted((root/'freezes').glob('*.json'))}} for name,root in bundles.items()},
 'result_sha256':{'repair':sha(state/'results.json'),'xg':sha(review/'verified-results.json')}}
dump(out/'protocol.json',protocol)
fix={'match_id':'total-objectives-protocol-20261118','kickoff_at':'2026-11-16T17:00:00Z','cutoff_at':protocol['registered_at']}
protocol_receipt=save(protocol,fix,stage='review',track='total-objectives-protocol',root=out/'freezes')
validate_repair(bundles['repair'],results);validate_xg(bundles['xg'],xg_results)
settlements=('win','half_win','push','half_loss','loss');rows=[]
for name,root in bundles.items():
 by_result={r['match_id']:r for r in (results if name=='repair' else xg_results)}
 for path in sorted((root/'freezes').glob('*.json')):
  r=verify(read(path));actual=by_result[r['match_id']]
  for track,p in r['payload']['predictions'].items():
   d=decisions(p);assert d['choices']['settlement_balance']==p['total']['reference_direction']
   point=np.zeros(np.asarray(p['matrix']).shape);point[actual['home_goals'],actual['away_goals']]=1.
   for policy,side in d['choices'].items():
    s=total_settlement(point,d['quote']['line'],side);outcome=next(k for k,v in s.items() if v==1.)
    rows.append({'experiment':name,'track':track,'match_id':r['match_id'],'freeze_id':r['freeze_id'],'record_sha256':r['record_sha256'],
       'matrix_hash':p['matrix_hash'],'policy':policy,'line':d['quote']['line'],'bookmaker':d['quote']['bookmaker'],
       'quote_time':d['quote']['quoted_at'],'side':side,'actual':[actual['home_goals'],actual['away_goals']],
       'settlement':outcome,'probabilities':d['probabilities'][side],'objective_values':{k:d['objectives'][k][side] for k in OBJECTIVES}})
summaries={};rng=np.random.default_rng(protocol['bootstrap_seed'])
for experiment,track in sorted({(r['experiment'],r['track']) for r in rows}):
 group=[r for r in rows if (r['experiment'],r['track'])==(experiment,track)];base={r['match_id']:r for r in group if r['policy']=='settlement_balance'}
 summaries[experiment+':'+track]={}
 for policy in OBJECTIVES:
  chosen=[r for r in group if r['policy']==policy];counts=collections.Counter(r['settlement'] for r in chosen);non=len(chosen)-counts['push']
  diffs=np.asarray([int(r['settlement']=='win')-int(base[r['match_id']]['settlement']=='win') for r in chosen if r['settlement']!='push'])
  differences=[r for r in chosen if r['side']!=base[r['match_id']]['side']]
  summaries[experiment+':'+track][policy]={'n':len(chosen),'coverage':len(chosen)/len(base),'non_push_n':non,
    'settlements':{k:counts[k] for k in settlements},'strict_full_win_rate':counts['win']/non if non else None,
    'changed_directions':len(differences),'net_full_wins':int(diffs.sum()),
    'descriptive_match_bootstrap95':np.quantile(rng.choice(diffs,size=(20000,len(diffs)),replace=True).mean(axis=1),[.025,.975]).tolist() if len(diffs) else None,
    'changed_matches':[{'match_id':r['match_id'],'line':r['line'],'before':base[r['match_id']]['side'],'after':r['side'],'before_settlement':base[r['match_id']]['settlement'],'after_settlement':r['settlement']} for r in differences]}
for name,root in bundles.items():
 assert sha(root/'plan.json')==protocol['sources'][name]['plan_sha256']
 assert {p.name:sha(p) for p in sorted((root/'freezes').glob('*.json'))}==protocol['sources'][name]['freezes']
report={'created_at':datetime.now(timezone.utc).isoformat(),'classification':protocol['classification'],
 'unique_matches':len({r['match_id'] for r in rows}),'separate_forecast_nodes':26,'matrix_quote_pairs':len(rows)//4,
 'policy_rows':len(rows),'model_groups':summaries,'protocol_sha256':sha(out/'protocol.json'),
 'protocol_freeze_receipt':protocol_receipt,'original_forecasts_unchanged':True,'new_future_samples':0,'active_model_promotion':False}
dump(out/'rows.json',rows);dump(out/'report.json',report)
report_receipt=save(report,dict(fix,match_id='total-objectives-report-20261118',cutoff_at=report['created_at']),stage='review',track='total-objectives-report',root=out/'freezes')
dump(out/'receipt.json',report_receipt)
print(json.dumps({'pairs':report['matrix_quote_pairs'],'unique_matches':report['unique_matches'],'groups':{k:{p:{q:v[q] for q in ('strict_full_win_rate','changed_directions','net_full_wins')} for p,v in x.items()} for k,x in summaries.items()}},ensure_ascii=False))
