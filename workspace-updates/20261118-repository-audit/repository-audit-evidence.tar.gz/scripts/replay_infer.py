"""Reprocess archived responses with today's identity review, never a new forecast."""
import hashlib, importlib.util, json, shutil, subprocess, sys
from datetime import datetime, timezone
from pathlib import Path
S=Path('/workspace/Football-Analysis-audit-20261118');sys.path.insert(0,str(S))
from runtime.automation import infer_market_snapshot as current
ROOT=Path('/workspace/WCPP/research/repo-audit-20261118')
OLD=Path('/workspace/WCPP/reports/tonight-20261117-2100')
out=ROOT/'infer-replay';out.mkdir(exist_ok=False)
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def meta(raw,mp):
 old=read(mp);dest=out/raw.name;shutil.copyfile(raw,dest)
 assert sha(dest)==old['sha256']==sha(raw)
 x={'file':dest.name,'sha256':sha(dest),'url':old['url'],
    'captured_at':old.get('received_at_utc',old.get('query_time_utc')),
    'original_metadata_sha256':sha(mp),'original_metadata_path':str(mp),
    'capture_time_basis':'received_at_utc' if 'received_at_utc' in old else 'legacy_query_time_proxy_REPLAY_ONLY'}
 if 'requested_at_utc' in old:x['requested_at']=old['requested_at_utc']
 return x
pages=[meta(OLD/'markets'/name,OLD/'markets'/metaname) for name,metaname in
       [('events-raw.json','events-meta.json'),('events-page2-raw.json','events-page2-meta.json')]]
identity=meta(OLD/'fixtures/raw/espn-scoreboard-uefa.nations-20261117-raw.json',OLD/'fixtures/raw/espn-scoreboard-uefa.nations-20261117-meta.json')
board=read(out/identity['file']);cutoff='2026-11-17T13:26:00+00:00';historical_now=datetime.fromisoformat(cutoff)
fixtures=[]
for event in board['events']:
 comp=event['competitions'][0];sides={c['homeAway']:c['team'] for c in comp['competitors']};grade=comp['group']['name'].split()[1][0]
 fixtures.append({'match_id':'espn:'+event['id'],'competition':'uefa.nations','cohort':f'uefa.nations:{grade}:league-phase','stage':'league-phase','home':'espn:'+sides['home']['id'],'away':'espn:'+sides['away']['id'],'kickoff_at':event['date']})
ids={f['match_id'].split(':')[1] for f in fixtures};odds=[]
for p in (OLD/'markets').glob('evt_*-meta.json'):
 x=read(p)
 if x.get('espn_event_id') in ids:odds.append(meta(OLD/'markets'/x['file'],p))
assert len(fixtures)==len(odds)==8
oldfile=out/'original-adapter.py'
oldfile.write_bytes(subprocess.check_output(['git','-C',str(S),'show','29c9701821367034b46fb6d86683e57e31f02262:runtime/automation/infer_market_snapshot.py']))
spec=importlib.util.spec_from_file_location('prior_adapter',oldfile);prior=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior)
review_at=datetime.now(timezone.utc).isoformat()
old=prior.build(out,pages[0],odds,identity,cutoff=cutoff,now=historical_now,fixtures=fixtures)
without_new_aliases=current.build(out,pages,odds,identity,cutoff=cutoff,now=historical_now,fixtures=fixtures)
new=current.build(out,pages,odds,identity,cutoff=cutoff,now=historical_now,fixtures=fixtures,identity_review_at=review_at)
for name,x in [('before-first-page.json',old),('new-code-historical-alias-cutoff.json',without_new_aliases),('new-code-today-identity-review.json',new)]:dump(out/name,x)
summary={'evaluated_at':review_at,'scope':'REPLAY_OF_ARCHIVED_PREMATCH_RAW_WITH_TODAYS_IDENTITY_REVIEW','population':8,
 'before':{k:old[k] for k in ('eligible_fixture_count','covered_fixture_count','verified_quote_count','excluded')},
 'after_pages_and_grade_before_new_alias_review':{k:without_new_aliases[k] for k in ('eligible_fixture_count','covered_fixture_count','verified_quote_count','excluded')},
 'after_today_alias_review':{k:new[k] for k in ('eligible_fixture_count','covered_fixture_count','verified_quote_count','excluded','coverage')},
 'retrospective_identity_replay':new['retrospective_identity_replay'],'legacy_capture_time_proxy':True,
 'quotes_use_original_row_as_of':True,'raw_bytes_unchanged':True,'new_forecasts':0,'active_model_changed':False,
 'metadata':{'pages':pages,'identity':identity,'odds':odds},'fixtures':fixtures,
 'old_source_commit':'29c9701821367034b46fb6d86683e57e31f02262','new_adapter_sha256':sha(current.__file__)}
assert old['covered_fixture_count']==0 and new['covered_fixture_count']==8
assert new['retrospective_identity_replay']
dump(out/'summary.json',summary)
print(json.dumps({k:v for k,v in summary.items() if k not in ('metadata','fixtures')},ensure_ascii=False))
