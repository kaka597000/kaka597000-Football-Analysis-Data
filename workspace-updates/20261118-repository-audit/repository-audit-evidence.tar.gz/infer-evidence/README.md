# InferSports 归档身份核查（2026-11-18）

本轮审核时间：2026-11-18T08:45:15.784230+08:00。全程离线，只写本目录。

已核实 B 级 `lg_4GXKQVPJ / UEFANLB`；6 场均与 ESPN 的 B2/B3/B4 分组、主客次序及北京时间 2026-11-18 03:45 开球逐场吻合。

| ESPN 比赛 | 主队 → 客队（ESPN ID） | Infer 比赛 | 分组 |
|---|---|---|---|
| 401861194 | Denmark (479) → Norway (464) | evt_G53M1EY6 | Group A4 |
| 401861189 | Wales (578) → Portugal (482) | evt_WB7XZTR6 | Group A4 |
| 401861193 | Israel (461) → Austria (474) | evt_836VXBM7 | Group B3 |
| 401861195 | Poland (471) → Sweden (466) | evt_NSJMH6GJ | Group B4 |
| 401861196 | Bosnia (452) → Romania (473) | evt_YT1ZX5BW | Group B4 |
| 401861191 | Hungary (480) → Nor.Ireland (586) | evt_VE437XS2 | Group B2 |
| 401861190 | Ukraine (457) → Georgia (584) | evt_B60JMXVP | Group B2 |
| 401861192 | Ireland (476) → Kosovo (18272) | evt_G537DAY6 | Group B3 |

别名经本轮核验：`Ireland → Republic of Ireland / 476`、`Nor.Ireland → Northern Ireland / 586`、`Bosnia → Bosnia-Herzegovina / 452`。三个归档赔率 meta 已保存同场 ESPN/Infer ID，但仅有查询时间，未发现更早的正式 Infer 别名 `reviewed_at`；不得将此次审核回填成昨晚已完成。

原程序离线诊断：全批 8 场，A2 可进目标，B6 全因原 A/C 分组门限排除。只用归档第一页时，A2 也匹配不到；第二页才有全部 8 场。第一页 `next_cursor=MTAw`，第二页用 `cursor=MTAw` 且仍返回 `next_cursor=MjAw`。两页覆盖本批，不代表完整目录。

8 场均有 SHA 核实的原始赔率响应且 `stale=false`。本清单记录原始/开放总球行数；未声称这些行已通过完整当前快照验证，也未重写旧冻结。

D 级只找到 ESPN 4 场（Andorra–Gibraltar、Liechtenstein–Azerbaijan、Lithuania–Liechtenstein、Gibraltar–Malta，D1/D2）。在已检索 reports/research JSON、JSONL、Markdown 档案中无 `UEFANLD` 记录，未核实 Infer D 级 ID/名称；保持未验证。

最新离线 OpenAPI 采于北京时间 2026-11-18 08:20:39。REST `/v1/events` 支持 `league`（ID 或模糊名称）、`date`（默认 UTC 日）、`timezone`、`status`、`limit`（1–200，默认50）、`cursor`。响应 `page.next_cursor` 可空。REST 无 `date_to`，勿与另一个工具的 `ListEventsRequest` 混用。

完整路径、原文/metadata SHA、URL、查询/接收时间、JSON Pointer、有序双队 ID 与别名时刻限制见 [evidence-inventory.json](evidence-inventory.json)。复核入口：`PYTHONDONTWRITEBYTECODE=1 python build_inventory.py`。
