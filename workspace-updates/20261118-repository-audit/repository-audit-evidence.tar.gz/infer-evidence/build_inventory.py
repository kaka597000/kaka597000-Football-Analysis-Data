"""Offline evidence inventory. Writes only alongside this script; no network."""
from collections import Counter
from datetime import datetime, timezone, timedelta
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

OUT = Path(__file__).resolve().parent
WCPP = Path('/workspace/WCPP')
REPO = Path('/workspace/Football-Analysis-audit-20261118')
BATCH = WCPP / 'reports/tonight-20261117-2100'
BJT = timezone(timedelta(hours=8))
SOURCES = {}


def read(path):
    return json.loads(Path(path).read_bytes())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dt(value):
    return datetime.fromisoformat(value.replace('Z', '+00:00'))


def source(key, raw, metadata, *, node=None, hash_field='sha256', url_field='url'):
    meta = read(metadata) if node is None else node
    actual = sha(raw)
    assert actual == meta[hash_field], (key, actual, meta[hash_field])
    times = {k: v for k, v in meta.items() if k in {
        'query_time_utc', 'requested_at_utc', 'received_at_utc', 'requested_at',
        'captured_at', 'captured_at_utc', 'query_time', 'observed_at_bjt',
        'started_at', 'ended_at', 'http_request_started', 'http_read_complete'}}
    SOURCES[key] = {
        'raw_path': str(raw), 'metadata_path': str(metadata),
        'url': meta[url_field], 'sha256': actual, 'metadata_sha256': sha(metadata),
        'byte_count': Path(raw).stat().st_size, 'sha256_matches_archive_metadata': True,
        'recorded_times': times,
        'recorded_times_beijing': {k: dt(v).astimezone(BJT).isoformat() for k, v in times.items()},
        'http_status': meta.get('http_status', 200),
    }
    return read(raw)


prior_inventory = OUT/'evidence-inventory.json'
reviewed_at = read(prior_inventory)['reviewed_at'] if prior_inventory.exists() else datetime.now(timezone.utc).isoformat()
page1 = source('infer_page_1', BATCH/'markets/events-raw.json', BATCH/'markets/events-meta.json')
page2 = source('infer_page_2', BATCH/'markets/events-page2-raw.json', BATCH/'markets/events-page2-meta.json')
board = source('espn_20261117', BATCH/'fixtures/raw/espn-scoreboard-uefa.nations-20261117-raw.json',
               BATCH/'fixtures/raw/espn-scoreboard-uefa.nations-20261117-meta.json')
assert len(page1['data']) == len(page2['data']) == 100
assert page1['page']['next_cursor'] == 'MTAw'
assert page2['page']['next_cursor'] == 'MjAw'
assert not set(x['id'] for x in page1['data']) & set(x['id'] for x in page2['data'])

aliases = {
    'Ireland': ('476', 'Republic of Ireland'),
    'Nor.Ireland': ('586', 'Northern Ireland'),
    'Bosnia': ('452', 'Bosnia-Herzegovina'),
}


def team_matches(provider, espn):
    if provider['name'] in aliases:
        return (str(espn['id']), espn['displayName']) == aliases[provider['name']]
    return provider['name'] == espn['displayName']


fixtures = []
alias_evidence = []
for index, event in enumerate(page2['data']):
    if event['league']['name'] not in {'UEFANLA', 'UEFANLB'}:
        continue
    matches = []
    for espn_index, item in enumerate(board['events']):
        comp = item['competitions'][0]
        sides = {x['homeAway']: x['team'] for x in comp['competitors']}
        if dt(event['scheduled_at']) == dt(item['date']) and all(
                team_matches(event[s+'_team'], sides[s]) for s in ('home', 'away')):
            matches.append((espn_index, item, comp, sides))
    assert len(matches) == 1, (event['id'], len(matches))
    espn_index, item, comp, sides = matches[0]
    grade = re.fullmatch(r'Group ([AB])[1-4]', comp['group']['name'])[1]
    assert item['season']['slug'] == 'league-phase'
    assert event['league'] == {'id': {'A': 'lg_BEJAVP29', 'B': 'lg_4GXKQVPJ'}[grade], 'name': 'UEFANL'+grade}
    event_id = event['id']
    meta_path = BATCH/f'markets/{event_id}-meta.json'
    meta = read(meta_path)
    assert meta['espn_event_id'] == item['id']
    odds = source('odds_'+event_id, BATCH/f'markets/{event_id}-odds-raw.json', meta_path)
    assert odds['event_id'] == event_id and odds['stale'] is False
    participants = []
    for side in ('home', 'away'):
        pteam, eteam = event[side+'_team'], sides[side]
        participant = {
            'side': side, 'provider_team_id': pteam['id'], 'provider_name': pteam['name'],
            'espn_team_id': eteam['id'], 'espn_name': eteam['displayName'],
            'name_match': 'exact' if pteam['name'] == eteam['displayName'] else 'alias_candidate_verified_in_this_audit',
        }
        participants.append(participant)
        if pteam['name'] != eteam['displayName']:
            alias_evidence.append(dict(participant,
                provider_event_id=event_id, espn_event_id=item['id'],
                provider_evidence={'source': 'infer_page_2', 'json_pointer': f'/data/{index}/{side}_team'},
                espn_evidence={'source': 'espn_20261117', 'json_pointer': f'/events/{espn_index}/competitions/0/competitors'},
                archived_explicit_pairing_metadata=str(meta_path),
                archived_pairing_query_time=meta['query_time_utc'],
                archived_pairing_query_time_beijing=dt(meta['query_time_utc']).astimezone(BJT).isoformat(),
                prior_explicit_reviewed_at=None, reviewed_at=reviewed_at,
                warning='Archived query time is not a documented alias review time; do not backdate this audit.'))
    totals = [q for q in odds['odds'] if q.get('market_type') == 'totals']
    open_totals = [q for q in totals if q.get('period') == 'full_time' and q.get('format') == 'decimal'
                   and q.get('status') == 'open']
    fixtures.append({
        'espn_event_id': item['id'], 'provider_event_id': event_id,
        'provider_event_pointer': f'/data/{index}', 'espn_event_pointer': f'/events/{espn_index}',
        'provider_league': event['league'], 'espn_group': comp['group'], 'grade': grade,
        'phase': item['season']['slug'], 'ordered_participants': participants,
        'provider_kickoff_raw': event['scheduled_at'], 'espn_kickoff_raw': item['date'],
        'kickoff_exact_instant_match': True, 'kickoff_beijing': dt(item['date']).astimezone(BJT).isoformat(),
        'provider_status': event['status'], 'espn_status': item['status']['type'],
        'raw_odds_source': 'odds_'+event_id, 'raw_odds_row_count': len(odds['odds']),
        'raw_totals_row_count': len(totals), 'raw_open_full_time_decimal_totals_count': len(open_totals),
        'response_stale': odds['stale'], 'response_as_of': odds['as_of'],
        'current_ac_target_filter_excluded': grade == 'B',
    })
assert len(fixtures) == 8 and Counter(x['grade'] for x in fixtures) == {'A': 2, 'B': 6}
assert len(alias_evidence) == 3

# Execute existing read-only identity helpers at an explicit historical evaluation instant.
# This diagnoses the original gate, not a new historical forecast or market acceptance.
sys.path.insert(0, str(REPO))
baseline_revision = '29c9701821367034b46fb6d86683e57e31f02262'
baseline_source = subprocess.check_output(['git','-C',str(REPO),'show',baseline_revision+':runtime/automation/infer_market_snapshot.py'])
baseline_ns = {'__name__':'offline_infer_identity_diagnostic','__file__':str(REPO/'runtime/automation/infer_market_snapshot.py')}
exec(compile(baseline_source, '<retained-git-baseline-infer-market-snapshot>', 'exec'), baseline_ns)
eligible_targets = baseline_ns['eligible_targets']
matched_events = baseline_ns['matched_events']
cutoff = '2026-11-17T13:05:00+00:00'
eligible, excluded = eligible_targets(board, cutoff=cutoff, now=dt(cutoff))
baseline = {
    'source_path': str(REPO/'runtime/automation/infer_market_snapshot.py'),
    'source_git_revision': baseline_revision,
    'source_sha256': hashlib.sha256(baseline_source).hexdigest(),
    'diagnostic_evaluation_instant': cutoff,
    'fixture_denominator': len(board['events']), 'grades': dict(Counter(x['grade'] for x in fixtures)),
    'eligible_fixture_count': len(eligible), 'excluded': dict(excluded),
    'provider_matches_using_page1_only': sum(bool(matched_events(page1['data'], t, s, g, cutoff)) for t,s,g in eligible),
    'provider_matches_using_page2': sum(bool(matched_events(page2['data'], t, s, g, cutoff)) for t,s,g in eligible),
    'archived_raw_odds_response_count': len(fixtures),
    'b_fixture_count_requiring_no_alias': sum(x['grade']=='B' and all(p['name_match']=='exact' for p in x['ordered_participants']) for x in fixtures),
    'b_fixture_count_requiring_alias': sum(x['grade']=='B' and any(p['name_match']!='exact' for p in x['ordered_participants']) for x in fixtures),
    'full_snapshot_or_quote_validation_claimed': False,
}
assert baseline['eligible_fixture_count'] == 2
assert baseline['excluded'] == {'unverified_target_identity_or_phase': 6}
assert baseline['provider_matches_using_page1_only'] == 0
assert baseline['provider_matches_using_page2'] == 2

d_sources = []
root13 = WCPP/'reports/nations-prematch-20261113-2118'
meta13_path = root13/'market/source-metadata.json'
meta13 = read(meta13_path)['identity']
d_sources.append(('espn_20261113', source('espn_20261113', root13/'market/identity.json', meta13_path, node=meta13)))
root16 = WCPP/'reports/nations-prematch-20261116-2018'
d_sources.append(('espn_20261116', source('espn_20261116', root16/'data/raw/scoreboard-20261116.raw.json',
        root16/'data/meta/scoreboard-20261116.meta.json', hash_field='response_sha256', url_field='request_url')))
d_fixtures = []
for source_key, data in d_sources:
    for index, item in enumerate(data['events']):
        comp = item['competitions'][0]
        if not comp.get('group', {}).get('name', '').startswith('Group D'):
            continue
        sides = {x['homeAway']: x['team'] for x in comp['competitors']}
        d_fixtures.append({'espn_event_id': item['id'], 'espn_group': comp['group'],
            'phase': item['season']['slug'], 'kickoff_raw': item['date'],
            'kickoff_beijing': dt(item['date']).astimezone(BJT).isoformat(),
            'ordered_participants': [{'side': s, 'espn_team_id': sides[s]['id'], 'espn_name': sides[s]['displayName']} for s in ('home','away')],
            'source': source_key, 'json_pointer': f'/events/{index}',
            'infer_league_id': None, 'infer_league_name': None, 'infer_ordered_team_mapping': None})
assert len(d_fixtures) == 4

schema_root = WCPP/'reports/all-review-20261118-0818/friendly-results'
schema = source('infer_openapi_20261118', schema_root/'raw/infersports-openapi.json', schema_root/'infersports-openapi.json.meta.json')
schema_evidence = {
    'source': 'infer_openapi_20261118', 'api_info': schema['info'],
    'rest_endpoint': '/v1/events', 'operation_id': schema['paths']['/v1/events']['get']['operationId'],
    'parameters': schema['paths']['/v1/events']['get']['parameters'],
    'response_schema': schema['components']['schemas']['Paginated_Event_'],
    'page_schema': schema['components']['schemas']['Page'],
    'warning': 'REST /v1/events has no date_to parameter. ListEventsRequest belongs to a separate operation; do not mix its schema with this REST endpoint.',
}
theodds_root = WCPP/'research/nations-xg-20261117/data/markets'
theodds = source('the_odds_20261117', theodds_root/'raw/odds.json', theodds_root/'capture.json', hash_field='raw_sha256')

inventory = {
    'schema': 'WCPP-INFER-LEAGUE-IDENTITY-EVIDENCE-1', 'reviewed_at': reviewed_at,
    'reviewed_at_beijing': dt(reviewed_at).astimezone(BJT).isoformat(),
    'scope': 'Offline archive audit only; original sources, model assets, freezes and branches unchanged.',
    'network_requests': 0, 'training_performed': False,
    'verified_new_provider_leagues': [{'id': 'lg_4GXKQVPJ', 'name': 'UEFANLB', 'grade': 'B',
        'source': 'infer_page_2', 'provider_pointers': [x['provider_event_pointer'] for x in fixtures if x['grade']=='B'],
        'independent_espn_source': 'espn_20261117', 'independent_groups': ['Group B2','Group B3','Group B4'],
        'observed_fixture_count': 6, 'reviewed_at': reviewed_at}],
    'alias_candidates_verified_now': alias_evidence,
    'archived_formal_infer_b_alias_review_times_found': False,
    'alias_time_policy': 'Preserve provider query times and independent ESPN receive time separately from this audit review time. BSD Ireland and The Odds API Bosnia aliases are other providers and do not establish an InferSports review timestamp.',
    'fixtures_20261117': fixtures, 'baseline_identity_diagnostic': baseline,
    'pagination': [{'source': key, 'row_count': len(page['data']), 'page': page['page'],
        'nations_rows_in_this_page': sum(e['league']['name'].startswith('UEFANL') for e in page['data'])}
        for key,page in [('infer_page_1',page1),('infer_page_2',page2)]],
    'pagination_complete': False,
    'pagination_note': 'Page 2 still advertises MjAw; two retained pages cover the eight independently requested fixtures, not the full provider event catalogue.',
    'd_grade': {'status': 'INDEPENDENT_ESPN_ONLY_NO_VERIFIED_INFER_LEAGUE_ID', 'fixtures': d_fixtures,
        'search': {'roots': [str(WCPP/'reports'), str(WCPP/'research')],
                   'globs': ['*.json','*.jsonl','*.md'], 'literal': 'UEFANLD',
                   'rg_exit_code_before_this_inventory': 1, 'hits_before_this_inventory': 0},
        'limitation': 'No D provider ID/name or aliases inferred. ESPN D1/D2 proves grade identity only; provider pages are incomplete and absence from retained archives is not absence from service.'},
    'latest_offline_schema': schema_evidence,
    'the_odds_archive': {'source': 'the_odds_20261117', 'event_count': len(theodds),
        'relevance': 'This archive is The Odds API, not InferSports; it cannot establish Infer league IDs or Infer alias review times.'},
    'sources': SOURCES,
    'timestamp_limitations': 'Infer 11/17 metadata records query_time_utc only. It does not record actual response capture completion; no captured_at has been invented from it. Raw quote as_of remains distinct.',
}
(OUT/'evidence-inventory.json').write_text(json.dumps(inventory, ensure_ascii=False, indent=2)+'\n')

# Small implementation inputs retain the same review instant and raw evidence.
names = {'Ireland':'ireland', 'Nor.Ireland':'northern-ireland', 'Bosnia':'bosnia'}
review_candidates = []
for a in alias_evidence:
    review_candidates.append({
        'version':'infer-nations-'+names[a['provider_name']]+'-20261118-1',
        'reviewed_at':reviewed_at, 'espn_id':a['espn_team_id'], 'espn_name':a['espn_name'],
        'provider_name':a['provider_name'], 'evidence': {
            'provider_event':dict(SOURCES['infer_page_2'],json_pointer=a['provider_evidence']['json_pointer'],provider_event_id=a['provider_event_id']),
            'espn_identity':dict(SOURCES['espn_20261117'],json_pointer=a['espn_evidence']['json_pointer'],espn_event_id=a['espn_event_id']),
            'ordered_fixture':next(f for f in fixtures if f['provider_event_id']==a['provider_event_id']),
            'archive_explicit_pairing_metadata':a['archived_explicit_pairing_metadata'],
            'archive_explicit_pairing_query_time':a['archived_pairing_query_time'],
            'prior_formal_review_time':None, 'review_time_warning':a['warning'],
        }})
(OUT/'alias-review-candidates.json').write_text(json.dumps(review_candidates,ensure_ascii=False,indent=2)+'\n')
(OUT/'b-league-evidence.json').write_text(json.dumps(dict(inventory['verified_new_provider_leagues'][0],
    provider_source=SOURCES['infer_page_2'],espn_source=SOURCES['espn_20261117'],
    fixtures=[f for f in fixtures if f['grade']=='B']),ensure_ascii=False,indent=2)+'\n')
(OUT/'pagination-and-schema.json').write_text(json.dumps({
    'reviewed_at':reviewed_at,'pages':[dict(p,source_evidence=SOURCES[p['source']]) for p in inventory['pagination']],
    'baseline':baseline,'complete':False,'note':inventory['pagination_note'],
    'latest_offline_schema':schema_evidence,'schema_source':SOURCES['infer_openapi_20261118'],
},ensure_ascii=False,indent=2)+'\n')
(OUT/'d-grade-evidence.json').write_text(json.dumps(dict(inventory['d_grade'],
    sources={k:SOURCES[k] for k in ['espn_20261113','espn_20261116']}),ensure_ascii=False,indent=2)+'\n')

lines = [
    '# InferSports 归档身份核查（2026-11-18）', '',
    f'本轮审核时间：{inventory["reviewed_at_beijing"]}。全程离线，只写本目录。', '',
    '已核实 B 级 `lg_4GXKQVPJ / UEFANLB`；6 场均与 ESPN 的 B2/B3/B4 分组、主客次序及北京时间 2026-11-18 03:45 开球逐场吻合。', '',
    '| ESPN 比赛 | 主队 → 客队（ESPN ID） | Infer 比赛 | 分组 |',
    '|---|---|---|---|',
]
for f in fixtures:
    h,a=f['ordered_participants']
    lines.append(f'| {f["espn_event_id"]} | {h["provider_name"]} ({h["espn_team_id"]}) → {a["provider_name"]} ({a["espn_team_id"]}) | {f["provider_event_id"]} | {f["espn_group"]["name"]} |')
lines += ['', '别名经本轮核验：`Ireland → Republic of Ireland / 476`、`Nor.Ireland → Northern Ireland / 586`、`Bosnia → Bosnia-Herzegovina / 452`。三个归档赔率 meta 已保存同场 ESPN/Infer ID，但仅有查询时间，未发现更早的正式 Infer 别名 `reviewed_at`；不得将此次审核回填成昨晚已完成。', '',
    '原程序离线诊断：全批 8 场，A2 可进目标，B6 全因原 A/C 分组门限排除。只用归档第一页时，A2 也匹配不到；第二页才有全部 8 场。第一页 `next_cursor=MTAw`，第二页用 `cursor=MTAw` 且仍返回 `next_cursor=MjAw`。两页覆盖本批，不代表完整目录。', '',
    '8 场均有 SHA 核实的原始赔率响应且 `stale=false`。本清单记录原始/开放总球行数；未声称这些行已通过完整当前快照验证，也未重写旧冻结。', '',
    'D 级只找到 ESPN 4 场（Andorra–Gibraltar、Liechtenstein–Azerbaijan、Lithuania–Liechtenstein、Gibraltar–Malta，D1/D2）。在已检索 reports/research JSON、JSONL、Markdown 档案中无 `UEFANLD` 记录，未核实 Infer D 级 ID/名称；保持未验证。', '',
    '最新离线 OpenAPI 采于北京时间 2026-11-18 08:20:39。REST `/v1/events` 支持 `league`（ID 或模糊名称）、`date`（默认 UTC 日）、`timezone`、`status`、`limit`（1–200，默认50）、`cursor`。响应 `page.next_cursor` 可空。REST 无 `date_to`，勿与另一个工具的 `ListEventsRequest` 混用。', '',
    '完整路径、原文/metadata SHA、URL、查询/接收时间、JSON Pointer、有序双队 ID 与别名时刻限制见 [evidence-inventory.json](evidence-inventory.json)。复核入口：`PYTHONDONTWRITEBYTECODE=1 python build_inventory.py`。',
]
(OUT/'README.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({'output': str(OUT/'evidence-inventory.json'), 'verified_sources':len(SOURCES),
    'fixture_count':len(fixtures), 'alias_count':len(alias_evidence), 'baseline':baseline,
    'd_fixture_count':len(d_fixtures)},ensure_ascii=False,indent=2))
