"""Bounded append-only result evidence collection; default verified TLS and proxy."""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import os,json,hashlib,time,sys
from urllib.request import Request,build_opener,HTTPRedirectHandler
from urllib.error import HTTPError
from urllib.parse import urlsplit
ROOT=Path(__file__).parent
class NoRedirect(HTTPRedirectHandler):
 def redirect_request(self,req,fp,code,msg,headers,newurl): return None

def fetch(name,url,auth=False):
 manifest=ROOT/'requests.json'
 rows=json.loads(manifest.read_text()) if manifest.exists() else []
 if len(rows)>=20: raise RuntimeError('20 HTTP request cap')
 host=urlsplit(url).netloc
 if auth and host!='api.infersports.dev': raise ValueError('Unapproved credential host')
 if urlsplit(url).scheme!='https': raise ValueError('HTTPS required')
 if any(r.get('http_status') in [401,403] and r.get('host')==host for r in rows): raise RuntimeError('No retry after 401/403')
 key=(os.environ.get('WCPP_INFERSPORTS_KEY') or os.environ.get('infer_yapan_zhishu') or os.environ.get('yapan_infersports')) if auth else None
 if auth and not key: raise RuntimeError('No bound credential')
 headers={'User-Agent':'Mozilla/5.0','Accept':'application/json,text/html;q=0.9,*/*;q=0.8'}
 if key: headers['Authorization']='Bearer '+key
 last=rows[-1].get('captured_at') if rows else None
 if last:
  diff=(datetime.now(timezone.utc)-datetime.fromisoformat(last)).total_seconds()
  if diff<1.1: time.sleep(1.1-diff)
 q=datetime.now(timezone.utc).isoformat()
 row={'request_number':len(rows)+1,'name':name,'url':url,'host':host,'requested_at':q,'query_time':q,'observed_at_bjt':datetime.now(timezone(timedelta(hours=8))).isoformat(),'http_status':None}
 try:
  try: resp=build_opener(NoRedirect()).open(Request(url,headers=headers),timeout=30)
  except HTTPError as e: resp=e
  with resp:
   body=resp.read(10*1024*1024+1)
   row.update(http_status=resp.status,final_url=resp.geturl(),content_type=resp.headers.get('content-type'),headers={k:resp.headers.get(k) for k in ['date','last-modified','etag','x-ratelimit-remaining'] if resp.headers.get(k)})
  if len(body)>10*1024*1024: raise RuntimeError('Oversized response')
  if key and key.encode() in body: raise RuntimeError('Response contains credential; not written')
  p=ROOT/'raw'/name
  with p.open('xb') as f:f.write(body)
  row.update(source_path=str(p),sha256=hashlib.sha256(body).hexdigest(),bytes=len(body))
 except Exception as e:
  row.update(error_type=type(e).__name__)
 row['captured_at']=datetime.now(timezone.utc).isoformat()
 rows.append(row); manifest.write_text(json.dumps(rows,ensure_ascii=False,indent=2))
 (ROOT/(name+'.meta.json')).write_text(json.dumps(row,ensure_ascii=False,indent=2))
 print(json.dumps({k:row.get(k) for k in ['request_number','name','http_status','bytes','error_type']},ensure_ascii=False),flush=True)
 return row
if __name__=='__main__':
 fetch(sys.argv[1],sys.argv[2],auth='--auth' in sys.argv)
