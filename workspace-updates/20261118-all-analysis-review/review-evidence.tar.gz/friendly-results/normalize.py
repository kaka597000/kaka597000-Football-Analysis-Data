from pathlib import Path
from datetime import datetime,timezone
import json,re,hashlib
ROOT=Path(__file__).parent
SCOPE=ROOT.parent/'review-scope-lock.json'
scope=json.loads(SCOPE.read_text());req=json.loads((ROOT/'requests.json').read_text())
meta={x['name']:x for x in req}
results=[]
for eid in ['401930880','401916336','401916335']:
 p=ROOT/'raw'/('espn-'+eid+'.json');d=json.loads(p.read_text());m=meta[p.name]
 h=d['header'];c=h['competitions'][0];stat=c['status']['type'];comp={x['homeAway']:x for x in c['competitors']};ids={k:str(v['team']['id']) for k,v in comp.items()};sides={v:k for k,v in ids.items()}
 assert h['id']==eid and stat['completed'] and stat['state']=='post' and stat['name']=='STATUS_FULL_TIME'
 fixture=next(x for x in scope['fixtures'] if x['match_id']=='fifa.friendly:'+eid)
 assert fixture['kickoff_at']==c['date']
 for side in ['home','away']:assert fixture[side]==comp[side]['team']['displayName']
 assert d['format']['regulation']['periods']==2 and d['format']['regulation']['clock']==2700
 roster={str(a['athlete']['id']):str(t['team']['id']) for t in d['rosters'] for a in t['roster']}
 events=[];score=[0,0];all_goals=[e for e in d['keyEvents'] if e.get('scoringPlay')];reds=[]
 for e in d['keyEvents']:
  typ=e['type']['text'];etype=e['type']['type'];is_red=('red-card' in etype or 'yellow-red' in etype or 'second-yellow' in etype)
  if not e.get('scoringPlay') and not is_red:continue
  assert not e.get('shootout') and e.get('period',{}).get('number') in [1,2]
  team_id=str(e.get('team',{}).get('id'));beneficiary=sides.get(team_id);own=etype=='own-goal'
  athlete=(e.get('participants') or [{}])[0].get('athlete',{});actor_id=roster.get(str(athlete.get('id')));actor=sides.get(actor_id)
  row={'source_event_id':e['id'],'type':'goal' if e.get('scoringPlay') else 'red_card','detail_type':typ,'minute':e['clock']['displayValue'],'clock_seconds':e['clock']['value'],'period':e['period']['number'],'actor':athlete.get('displayName'),'actor_id':athlete.get('id'),'actor_team_id':actor_id,'actor_side':actor,'source_team_id':team_id,'own_goal':own,'shootout':False,'text':e.get('text'),'wallclock':e.get('wallclock')}
  if e.get('scoringPlay'):
   match=re.search(r'(\d+), [^.!?]+? (\d+)\.',e.get('text',''));assert match,e
   after=[int(match.group(1)),int(match.group(2))];delta=[a-b for a,b in zip(after,score)];assert delta in [[1,0],[0,1]],e
   bside='home' if delta==[1,0] else 'away';assert beneficiary==bside
   assert actor==('away' if bside=='home' else 'home') if own else actor==bside
   row.update(beneficiary_side=bside,beneficiary_team_id=ids[bside],score_before=score.copy(),score_after=after,penalty=etype=='penalty---scored',normalization='SCORE_DELTA_EVENT_TEAM_AND_ROSTER_TEAM_VERIFIED')
   score=after
  else:reds.append(row)
  events.append(row)
 final=[int(comp[k]['score']) for k in ['home','away']];assert score==final
 stats={sides[str(t['team']['id'])]:{s['name']:s['displayValue'] for s in t['statistics']} for t in d['boxscore']['teams']}
 end=[e for e in d['keyEvents'] if e['type']['type']=='end-regular-time'];assert end and end[-1]['period']['number']==2 and end[-1]['clock']['value']==5400
 source={'provider':'ESPN','source_url':m['url'],'source_path':m['source_path'],'source_sha256':m['sha256'],'requested_at':m['requested_at'],'observed_at':m['captured_at'],'http_status':m['http_status']}
 warnings=[]
 for side in ['home','away']:
  actual=sum(1 for e in events if e['type']=='goal' and e.get('penalty') and e['beneficiary_side']==side)
  if 'penaltyKickGoals' in stats[side] and int(stats[side]['penaltyKickGoals'])!=actual:
   warnings.append({'field':'boxscore.penaltyKickGoals','side':side,'boxscore_value':stats[side]['penaltyKickGoals'],'goal_event_count':actual,'handling':'Preserve provider statistic; use validated goal event for penalty narrative, not silent correction.'})
 result={'match_id':'fifa.friendly:'+eid,'competition':'fifa.friendly','source_event_id':eid,'home_team':comp['home']['team']['displayName'],'away_team':comp['away']['team']['displayName'],'home_team_id':ids['home'],'away_team_id':ids['away'],'kickoff_at':c['date'],'status':'completed','event_status':'FT','provider_status':stat,'score_basis':'regulation_90','home_score':final[0],'away_score':final[1],'score':{'home':final[0],'away':final[1]},'regulation_90':{'home':final[0],'away':final[1]},'identity_verified_against_scope':True,'period_evidence':{'format':d['format'],'last_regular_event':end[-1],'no_scoring_events_after_period_two':True},'process':{side:{'shots':int(stats[side]['totalShots']),'shots_on_target':int(stats[side]['shotsOnTarget']),'red_cards':int(stats[side]['redCards']),'saves':int(stats[side]['saves']),'corners':int(stats[side]['wonCorners']),'possession_pct':float(stats[side]['possessionPct']),'xg':None} for side in ['home','away']},'real_xg_available':False,'xg_missing_reason':'No real expected-goals statistic in fetched ESPN boxscore; no proxy estimated.','events':events,'goal_events':[e for e in events if e['type']=='goal'],'red_card_events':reds,'raw_team_statistics':stats,'source_internal_conflicts':warnings,**source}
 results.append(result)
(ROOT/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
# Independent source result identity mapping fixed using the prematch event ids.
friendly={'fifa.friendly:401930880':'evt_YT131PBW','fifa.friendly:401916336':'evt_NSJZ3XGJ','fifa.friendly:401916335':'evt_G53J17Y6'}
im=meta['infersports-results.json'];idata=json.loads((ROOT/'raw/infersports-results.json').read_text())['results'];byid={r['event_id']:r for r in idata};cross=[]
for f in scope['fixtures']:
 pid=friendly.get(f['match_id']) or f['total_quote']['provider_event_id'];r=byid[pid]
 assert datetime.fromisoformat(f['kickoff_at'].replace('Z','+00:00'))==datetime.fromisoformat(r['scheduled_at'].replace('Z','+00:00'))
 primary=next((x for x in results if x['match_id']==f['match_id']),None)
 status='AGREES' if primary and primary['score']==r['score'] else 'PENDING_ROOT_ESPN_COMPARISON'
 if f['match_id']=='espn:401861194':status='SOURCE_CONFLICT'
 cross.append({'match_id':f['match_id'],'independent_provider_event_id':pid,'identity_mapping_basis':'Locked prematch InferSports event id + home/away names and UTC kickoff; Ireland/Nor.Ireland/Bosnia accepted aliases of scope names.','scope_home':f.get('home_name',f['home']),'scope_away':f.get('away_name',f['away']),'independent_result':r,'comparison_status':status,'primary_espn_score':primary['score'] if primary else ({'home':2,'away':3} if f['match_id']=='espn:401861194' else None),'score_basis':'provider_final_score_not_explicit_90','limitation':'InferSports schema defines final score without period components; confirm 90-minute result from ESPN regulation/FT evidence. finished_at is when provider first recorded finish, not final-whistle timestamp.','source_url':im['url'],'source_path':im['source_path'],'source_sha256':im['sha256'],'observed_at':im['captured_at']})
(ROOT/'independent-crosscheck.json').write_text(json.dumps(cross,ensure_ascii=False,indent=2))
print('WROTE results.json',len(results),'independent-crosscheck.json',len(cross))
for r in results:print(r['home_team'],r['score'],r['away_team'],'goals',len(r['goal_events']),'warnings',r['source_internal_conflicts'])
