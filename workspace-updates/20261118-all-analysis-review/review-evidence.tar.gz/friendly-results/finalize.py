from pathlib import Path
from datetime import datetime,timezone
import json,re,html,hashlib
ROOT=Path(__file__).parent
req=json.loads((ROOT/'requests.json').read_text());meta={x['name']:x for x in req}
results=json.loads((ROOT/'results.json').read_text());scope=json.loads((ROOT.parent/'review-scope-lock.json').read_text())
for r in results:
 r.update(home_goals=r['home_score'],away_goals=r['away_score'],home_name=r['home_team'],away_name=r['away_team'],home='espn:'+r['home_team_id'],away='espn:'+r['away_team_id'],source_http_status=r['http_status'],query_time=r['requested_at'],identity_verified=True,date=r['kickoff_at'][:10],gender='men',age='senior',entity='national')
 r['independent_score_status']='AGREES_WITH_INFERSPORTS_FINAL_SCORE'
(ROOT/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
# Preserve an inspectable official page text extract in addition to raw HTML.
m=meta['norway-official-denmark-report.html'];s=Path(m['source_path']).read_text()
t=re.sub('<script.*?</script>','',s,flags=re.S);t=re.sub('<style.*?</style>','',t,flags=re.S);t=html.unescape(re.sub('<[^>]+>',' ',t));t=re.sub(r'\s+',' ',t)
start=t.index('Avgjorde på overtid: - Tidenes landslagsår',t.index('Del:'))
end=t.index('Nyttige lenker',start)
extract=t[start:end]
(ROOT/'norway-official-denmark-report-extract.txt').write_text(extract+'\n')
assert 'Danmark 2 - 3 Pauseresultat: 2 - 1 Norge' in extract
assert '17.11.2026 20:45' in extract
resolution={'match_id':'espn:401861194','home':'Denmark','away':'Norway','kickoff_at':'2026-11-17T19:45:00Z','issue':'InferSports final score 2-2 conflicts with ESPN FT 2-3.','status':'RESOLVED_WITH_OFFICIAL_THIRD_SOURCE','selected_regulation_score':{'home':2,'away':3},'selected_source_basis':'ESPN FT/two regulation periods and goals agree with Norway Football Federation official post-match report; InferSports conflicting raw value is preserved.','rejected_conflicting_value':{'provider':'InferSports','event_id':'evt_G53M1EY6','score':{'home':2,'away':2},'finished_at':'2026-11-17T21:45:49Z','finished_at_definition':'Official schema: when result first recorded as finished, not a data-revision timestamp.','cause':'Unresolved provider discrepancy; no assumption of cause.'},'official_source':{'provider':'Norges Fotballforbund','source_url':m['url'],'source_path':m['source_path'],'source_sha256':m['sha256'],'http_status':m['http_status'],'observed_at':m['captured_at'],'published_date':'2026-11-17','title':'Avgjorde på overtid: - Tidenes landslagsår','match_number':'99101000922','venue':'Parken, København','kickoff_local':'17.11.2026 20:45','home_score':2,'away_score':3,'half_time':{'home':2,'away':1},'plain_text_extract':str(ROOT/'norway-official-denmark-report-extract.txt')},'official_goal_events':[{'minute':'11','team':'Denmark','actor':'Rasmus Højlund'},{'minute':'14','team':'Denmark','actor':'Pierre-Emile Højbjerg'},{'minute':'37','team':'Norway','actor':'Erling Braut Haaland'},{'minute':'84','team':'Norway','actor':'Martin Ødegaard'},{'minute':'90','team':'Norway','actor':'Erling Braut Haaland','detail':'penalty; stoppage time stated in narrative; added minute not separately stated'}],'event_minute_discrepancies':[{'actor':'Martin Ødegaard','espn':'83','nff':'84','handling':'Keep source-specific minutes.'},{'actor':'Erling Braut Haaland penalty','espn':'90+6','nff':'90 with narrative stoppage time','handling':'Official page supports stoppage-time goal; does not independently confirm +6.'}],'real_xg_available':False}
(ROOT/'denmark-conflict-resolution.json').write_text(json.dumps(resolution,ensure_ascii=False,indent=2))
nations=json.loads((ROOT.parent/'nations-results/results.json').read_text());primary={r['match_id']:r for r in nations+results};cross=json.loads((ROOT/'independent-crosscheck.json').read_text())
red_conflicts=[]
for x in cross:
 r=primary[x['match_id']];score={'home':r['home_goals'],'away':r['away_goals']};x['primary_espn_score']=score
 x['primary_espn_source_path']=r['source_path'];x['primary_espn_source_sha256']=r['source_sha256'];x['comparison_status']='AGREES' if score==x['independent_result']['score'] else 'SOURCE_CONFLICT'
 assert hashlib.sha256(Path(r['source_path']).read_bytes()).hexdigest()==r['source_sha256']
 raw=json.loads(Path(r['source_path']).read_text());comp={t['homeAway']:str(t['team']['id']) for t in raw['header']['competitions'][0]['competitors']};st={str(t['team']['id']):{a['name']:a['displayValue'] for a in t['statistics']} for t in raw['boxscore']['teams']};reds={side:int(st[tid]['redCards']) for side,tid in comp.items()}
 x['primary_espn_red_cards']=reds;x['independent_red_card_status']='MISSING' if x['independent_result']['red_cards'] is None else ('AGREES' if reds==x['independent_result']['red_cards'] else 'CONFLICT')
 if x['independent_red_card_status']=='CONFLICT':red_conflicts.append(x['match_id'])
 if x['match_id']=='espn:401861194':
  x['resolution_status']=resolution['status'];x['resolution_path']=str(ROOT/'denmark-conflict-resolution.json');x['accepted_score']=score;x['official_third_source']=resolution['official_source']
(ROOT/'independent-crosscheck.json').write_text(json.dumps(cross,ensure_ascii=False,indent=2))
checks=[]
for m in req:
 assert m['http_status']==200,m
 p=Path(m['source_path']);assert hashlib.sha256(p.read_bytes()).hexdigest()==m['sha256']
 checks.append({'file':str(p),'sha256':m['sha256'],'http_status':m['http_status']})
validation={'generated_at':datetime.now(timezone.utc).isoformat(),'http_requests':len(req),'max_authorized_http_requests':20,'retries_after_auth_block':0,'scope_matches':11,'friendly_results':3,'friendly_goal_events':sum(len(r['goal_events']) for r in results),'friendly_red_card_events':sum(len(r['red_card_events']) for r in results),'friendly_real_xg_matches':0,'independent_result_coverage':11,'independent_infersports_score_agreements':sum(x['comparison_status']=='AGREES' for x in cross),'independent_score_conflicts':1,'score_conflicts_resolved_officially':1,'independent_red_card_conflicts':red_conflicts,'friendly_identity_kickoff_verified':True,'goal_totals_and_actor_beneficiary_roster_verified':True,'raw_sha256_verified':checks,'existing_freezes_modified':False,'existing_models_modified':False}
(ROOT/'validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2))
lines=['# 2026-11-17三场友谊赛赛果与11场独立交叉核验','', '采集时间为北京时间2026-11-18；先读取已锁定11场范围后采集。共12次HTTPS请求，全部HTTP200，未重试鉴权失败、未修改预测冻结或模型。原始内容、查询时间和SHA256见requests.json。','', '| 比赛 | 90分钟FT | 射门 | 射正 | 红牌 | 真实xG |','|---|---:|---:|---:|---:|---|']
for r in results:
 h=r['process']['home'];a=r['process']['away'];lines.append(f"| {r['home_team']}–{r['away_team']} | {r['home_goals']}–{r['away_goals']} | {h['shots']}–{a['shots']} | {h['shots_on_target']}–{a['shots_on_target']} | {h['red_cards']}–{a['red_cards']} | 缺失 |")
lines+=['','进球过程：','']
for r in results:
 events=[]
 for e in r['goal_events']:
  suffix='（点球）' if e.get('penalty') else ''
  if e['own_goal']:suffix=f"（乌龙，球员属{r['home_team'] if e['actor_side']=='home' else r['away_team']}，受益{r['home_team'] if e['beneficiary_side']=='home' else r['away_team']}）"
  events.append(f"{e['minute']} {e['actor']}{suffix} {e['score_after'][0]}–{e['score_after'][1]}")
 lines.append(f"- {r['home_team']}–{r['away_team']}："+'；'.join(events)+'。')
lines+=['','11场InferSports官方结果接口全部找到赛前已映射事件ID，球队与开球时间匹配。10场比分与ESPN一致；丹麦–挪威InferSports为2–2，ESPN为2–3。NFF官方赛后报道及比赛表确认丹麦2–3挪威，正文明确哈兰德补时点球制胜，因此保留冲突原值并采用2–3。详见denmark-conflict-resolution.json。','', '过程口径：NFF扳平球列84分钟，ESPN列83分钟；NFF制胜点球仅写90分钟并正文明确补时，ESPN写90+6。分钟差异逐源保留。InferSports red_cards在三场友谊赛为null，不能解释为0；八场欧国联红牌计数与ESPN核对结果见independent-crosscheck.json。','', '中国–巴林内部字段冲突：ESPN逐球80分钟张玉宁罚入点球，比分递增校验通过；其boxscore penaltyKickGoals却为0。比赛过程采用明确的进球事件，原统计字段保留并标明冲突。','', '三个友谊赛没有真实xG字段，未用射门或射正替代xG。JFA两页HTTP200但未提供目标场赛后结果，因此未作赛果证据。官方NFF仅补核丹麦比赛，其他欧国联独立来源提供比分/部分红牌计数，未补齐独立逐球/射门过程。','', '文件：results.json为友谊赛完整结果/过程；independent-crosscheck.json为11场逐场交叉核验；validation.json为覆盖与哈希核验。']
(ROOT/'采集与交叉核验.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({k:v for k,v in validation.items() if k!='raw_sha256_verified'},ensure_ascii=False,indent=2))
