# 欧国联赛果采集记录

首次赛果查询（北京时间）：2026-11-18T08:18:41.398966+08:00 至 2026-11-18T08:18:51.960470+08:00。8场均由 ESPN 明确 FT、completed=true、state=post 与两个半场比分相加核实为90分钟赛果（含补时，不含加时或点球大战）。锁定主客ID、名称及开球时间全部相符。

本任务共9次HTTPS请求：8场各一次，加1次丹麦—挪威复查；每次串行，初批两次请求间至少1.1秒。无额外网络请求获取上场首发，已复用并复制赛前采集的11月14日8场原始响应。

|比赛|90分钟赛果|射门 主/客|射正 主/客|控球率 主/客|首发变化 主/客|
|---|---|---|---|---|---|
|Wales—Portugal|2–3|22/11|8/6|40.7/59.3|6/4|
|Ukraine—Georgia|1–0|11/12|3/4|39.7/60.3|4/3|
|Hungary—Northern Ireland|1–1|17/8|2/2|76.1/23.9|4/1|
|Republic of Ireland—Kosovo|3–0|28/5|12/3|60.9/39.1|1/4|
|Israel—Austria|1–1|3/21|2/6|39.3/60.7|2/8|
|Denmark—Norway|2–3|7/22|4/7|48.2/51.8|1/4|
|Poland—Sweden|1–1|10/17|3/6|38.3/61.7|5/7|
|Bosnia-Herzegovina—Romania|2–1|13/13|6/6|55.1/44.9|6/4|

共核实23个进球事件，3张红牌，无乌龙；每个进球均通过比分增量、ESPN记账队及球员所在阵容的球队ID核验。8场真实xG均缺失，未用射门、射正或估算数替代。

关键事件：

- 葡萄牙70′由Carlos Forbs取得3–2领先；74′Pedro Neto两黄退场，红牌后比分未变。
- 乌克兰Danylo Sikan在1′进球；格鲁吉亚Luka Lochoshvili在90′两黄退场。
- 科索沃Kreshnik Hajrizi在26′红牌；爱尔兰Troy Parrott在28′、50′罚进点球，75′Jack Moylan头球。
- 丹麦11′、14′连入两球，挪威37′、83′、90+6′进球逆转。31′被VAR取消的哈兰德进球未计入23个进球或赛果。

丹麦—挪威来源冲突另存：主代理告知InferSports记录2–2。本任务初抓与重抓ESPN均为FT2–3，主队分段[2,0]、客队[1,2]；90+4′评论明确VAR Decision: Penalty Norway，90+6′哈兰德罚进，90+9′及Match ends均为2–3，未见末段点球被取消。重抓属于同一提供方验证，不能视为独立第三源或自动解决冲突。原始响应全部保留；摘录与来源哈希见denmark-recheck.json。results.json保留ESPN来源值，最终冲突结算由主代理处理。

字段冲突：ESPN penaltyKickGoals对爱尔兰和挪威均记0，与2次及1次罚进事件不一致；保留源字段并在process-summary.json/statistical_conflicts标注。爱尔兰、丹麦的saves与对方射正减进球的简单恒等式也不一致，不据此推断门将表现。

文件：results.json为8场结构化赛果；process-summary.json含时间线、全部首发、对上场首发变化、VAR与终场评论及字段冲突；normalization-audit.json为身份/分段/进球核验；collection-receipt.json为首次8次采集；denmark-recheck.json及request-budget.json记录第9次请求；raw/与prior-raw/保留原始证据。

时间字段说明：初抓request_started_at为查询时间，observed_at/request_finished_at记录收到响应头的时间，body_saved_at是原始文件落盘时间；第9次复查在读完响应体后记录完成时间。所有机器字段均带UTC时区。

首发变化仅描述选人差异，不推断缺阵原因；赛后证据未回填任何赛前预测。本任务未改预测、权重、活动模型或统一赛事库。
