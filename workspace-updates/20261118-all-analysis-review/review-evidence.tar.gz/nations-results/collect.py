"""Collect locked Nations League summaries once; staging evidence only."""
import hashlib
import json
import time
from datetime import datetime, timezone
from pathlib import Path

import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parent
LOCK = ROOT.parent / "review-scope-lock.json"
now = lambda: datetime.now(timezone.utc).isoformat()
write = lambda path, data: path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")
lock_bytes = LOCK.read_bytes()
scope = json.loads(lock_bytes)
fixtures = [f for f in scope["fixtures"] if f["competition"] == "uefa.nations"]
assert {f["match_id"] for f in fixtures} == {f"espn:{i}" for i in range(401861189, 401861197)}
assert len(fixtures) == 8
assert not (ROOT / "collection-receipt.json").exists(), "Refusing implicit repeated network collection"
write(ROOT / "locked-fixtures.json", {"source_path": str(LOCK), "source_sha256": hashlib.sha256(lock_bytes).hexdigest(), "locked_at": scope["locked_at"], "read_before_results_at": now(), "fixtures": fixtures})
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, file_pointer, code, message, headers, new_url):
        return None

opener = urllib.request.build_opener(NoRedirect)
captures = []
last_finished = None
for index, fixture in enumerate(fixtures, 1):
    if last_finished is not None:
        time.sleep(max(0, 1.1 - (time.monotonic() - last_finished)))
    event_id = fixture["source_event_id"]
    url = "https://site.api.espn.com/apis/site/v2/sports/soccer/uefa.nations/summary?event=" + event_id
    started = now()
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    raw_path = ROOT / "raw" / f"espn-{event_id}-{stamp}.raw.json"
    capture = {"request_number": index, "match_id": fixture["match_id"], "source_url": url, "request_started_at": started, "request_finished_at": None, "observed_at": None, "http_status": None, "source_path": str(raw_path), "source_sha256": None, "tls_verified": True, "proxy_inherited": True, "redirects_allowed": False}
    try:
        request = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 WCPP-result-evidence/1.0", "Accept": "application/json"})
        try:
            response = opener.open(request, timeout=30)
        except urllib.error.HTTPError as exc:
            response = exc
        finished = now()
        body = response.read()
        raw_path.write_bytes(body)
        capture.update({"request_finished_at": finished, "observed_at": finished, "http_status": response.code, "source_sha256": hashlib.sha256(body).hexdigest(), "bytes": len(body), "response_date": response.headers.get("date"), "content_type": response.headers.get("content-type")})
        try:
            document = json.loads(body)
            competition = document.get("header", {}).get("competitions", [{}])[0]
            capture["event_status"] = competition.get("status")
            capture["event_id_returned"] = competition.get("id")
            capture["json_valid"] = True
        except (ValueError, KeyError, IndexError):
            capture["json_valid"] = False
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        capture.update({"request_finished_at": now(), "observed_at": now(), "error_type": type(exc).__name__})
    last_finished = time.monotonic()
    capture_path = raw_path.with_suffix(".capture.json")
    capture["capture_path"] = str(capture_path)
    write(capture_path, capture)
    captures.append(capture)
    write(ROOT / "collection-receipt.json", {"scope_source_path": str(LOCK), "scope_source_sha256": hashlib.sha256(lock_bytes).hexdigest(), "http_requests": len(captures), "max_authorized_http_requests": 16, "minimum_gap_after_prior_response_seconds": 1.1, "source": "ESPN public summary", "captures": captures})
    print(json.dumps({"request_number": index, "match_id": fixture["match_id"], "http_status": capture["http_status"], "event_status": capture.get("event_status"), "bytes": capture.get("bytes")}, ensure_ascii=False), flush=True)
