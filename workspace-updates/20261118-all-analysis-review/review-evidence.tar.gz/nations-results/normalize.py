"""Normalize captured ESPN evidence; no forecast/model/database writes."""
import hashlib
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

CODE = Path('/workspace/Football-Analysis-xg-research-20261117/runtime')
sys.path.insert(0, str(CODE))
from research.review_events import normalize_fotmob_goal
from research_program.nations_phase import verify_period_scores, _score_integer

ROOT = Path(__file__).resolve().parent
PRIOR = Path('/workspace/WCPP/reports/tonight-20261117-2100/context/raw')
read = lambda path: json.loads(Path(path).read_text())
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write(path, data):
    content = json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + '\n'
    if path.exists() and path.read_text() == content:
        return
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(content)
    temporary.replace(path)

def instant(value):
    result = datetime.fromisoformat(value.replace('Z', '+00:00'))
    assert result.tzinfo is not None
    return result

def number(value):
    if value is None:
        return None
    n = float(str(value).rstrip('%'))
    return int(n) if n.is_integer() else n

def athlete(player, team_id):
    item = player['athlete']
    return {'id': str(item['id']), 'name': item['displayName'], 'team_id': str(team_id),
            'starter': player.get('starter'), 'position': player.get('position', {}).get('displayName'),
            'jersey': player.get('jersey'), 'subbed_in': player.get('subbedIn'),
            'subbed_out': player.get('subbedOut')}

def minute_fields(event):
    display = event.get('clock', {}).get('displayValue')
    minutes = [int(x) for x in re.findall(r'\d+', display or '')]
    return {'minute': display, 'minute_regular': minutes[0] if minutes else None,
            'minute_added': minutes[1] if len(minutes) > 1 else 0,
            'period': event.get('period', {}).get('number'),
            'clock_seconds': event.get('clock', {}).get('value')}

receipt = read(ROOT / 'collection-receipt.json')
locked = read(ROOT / 'locked-fixtures.json')
assert sha(locked['source_path']) == locked['source_sha256']
fixtures = {f['match_id']: f for f in locked['fixtures']}
assert len(receipt['captures']) == len(fixtures) == 8

# Reuse the eight already captured 14-Nov prior fixtures. No additional HTTP.
prior_by_team = {}
(ROOT / 'prior-raw').mkdir(exist_ok=True)
for event_id in range(401861163, 401861171):
    original = PRIOR / f'espn-summary-{event_id}.json'
    meta = read(str(original) + '.meta.json')
    assert sha(original) == meta['sha256']
    prior = read(original)
    competition = prior['header']['competitions'][0]
    assert competition['id'] == str(event_id)
    assert competition['status']['type']['completed'] is True
    destination = ROOT / 'prior-raw' / original.name
    destination.write_bytes(original.read_bytes())
    evidence = {'match_id': f'espn:{event_id}', 'kickoff_at': competition['date'],
                'source_url': meta['url'], 'source_path': str(destination),
                'source_sha256': sha(destination), 'observed_at': meta['completed_at'],
                'http_status': meta['status'], 'original_path': str(original),
                'original_metadata_path': str(original) + '.meta.json',
                'retrieval_method': 'REUSED_LOCAL_PREMATCH_CAPTURE_NO_NEW_HTTP'}
    write(destination.with_suffix('.capture.json'), evidence)
    for roster in prior.get('rosters', []):
        team_id = str(roster['team']['id'])
        starters = [athlete(p, team_id) for p in roster['roster'] if p.get('starter') is True]
        assert len(starters) == 11
        prior_by_team[team_id] = {'evidence': evidence, 'starting_xi': starters}

results, process, integrity = [], [], []
name_aliases = {'Bosnia and Herzegovina': 'Bosnia-Herzegovina'}
for capture in receipt['captures']:
    fixture = fixtures[capture['match_id']]
    assert capture['http_status'] == 200 and capture['json_valid'] is True
    assert sha(capture['source_path']) == capture['source_sha256']
    document = read(capture['source_path'])
    competition = document['header']['competitions'][0]
    assert competition['id'] == fixture['source_event_id']
    status = competition['status']['type']
    assert status['name'] == 'STATUS_FULL_TIME' and status['state'] == 'post' and status['completed'] is True
    assert status.get('shortDetail') == 'FT' or status.get('detail') == 'FT'
    assert instant(competition['date']) == instant(fixture['kickoff_at'])
    teams = {side: next(t for t in competition['competitors'] if t['homeAway'] == side) for side in ('home', 'away')}
    team_ids = {s: str(t['team']['id']) for s, t in teams.items()}
    names = {s: t['team']['displayName'] for s, t in teams.items()}
    for side in teams:
        assert fixture[side] == 'espn:' + team_ids[side]
        assert fixture[side + '_name'] == names[side]
    periods = {s: verify_period_scores(t, competition['status']) for s, t in teams.items()}
    assert all(p and p['extra_time'] == 0 and p['shootout'] is None for p in periods.values())
    score90 = {s: p['regulation'] for s, p in periods.items()}
    final_score = [score90['home'], score90['away']]
    rosters = {}
    formations = {}
    for roster in document.get('rosters', []):
        team_id = str(roster['team']['id'])
        formations[team_id] = roster.get('formation')
        for player in roster.get('roster', []):
            item = athlete(player, team_id)
            assert item['id'] not in rosters
            rosters[item['id']] = item
    starters = {s: [p for p in rosters.values() if p['team_id'] == team_ids[s] and p['starter'] is True] for s in teams}
    assert all(len(x) == 11 for x in starters.values())
    running_score, halftime = [0, 0], [0, 0]
    goals, cards, timeline = [], [], []
    for event in document.get('keyEvents', []):
        event_type = event.get('type', {}).get('type', '')
        scoring = event.get('scoringPlay') is True
        red_card = 'red-card' in event_type or 'second-yellow' in event_type
        if not scoring and not red_card:
            continue
        assert event['period']['number'] in (1, 2) and not event.get('shootout')
        event_team_id = str(event['team']['id'])
        assert event_team_id in team_ids.values()
        source_side = next(s for s in team_ids if team_ids[s] == event_team_id)
        actor_id = str(event['participants'][0]['athlete']['id'])
        actor = rosters[actor_id]
        item = {'event_id': event['id'], **minute_fields(event), 'event_type': event_type,
                'player': actor['name'], 'athlete_id': actor_id, 'player_team_id': actor['team_id'],
                'player_side': next(s for s in team_ids if team_ids[s] == actor['team_id']),
                'source_event_team_id': event_team_id, 'text': event['text'],
                'score_before': {'home': running_score[0], 'away': running_score[1]}}
        if scoring:
            score_match = re.search(r'(?:Goal!\s+)?([^!]+?)\s+(\d+),\s+(.+?)\s+(\d+)\.', event['text'])
            assert score_match, event['text']
            home_label, home_score, away_label, away_score = score_match.groups()
            assert name_aliases.get(home_label, home_label) == names['home'], (home_label, names['home'])
            assert name_aliases.get(away_label, away_label) == names['away'], (away_label, names['away'])
            after = [int(home_score), int(away_score)]
            own_goal = event_type == 'own-goal' or event.get('ownGoal') is True
            adapter = {'type': 'Goal', 'homeScore': running_score[0], 'awayScore': running_score[1],
                       'newScore': after, 'ownGoal': own_goal, 'isHome': source_side == 'home',
                       'shotmapEvent': {'isOwnGoal': own_goal, 'teamId': actor['team_id']},
                       'timeStr': item['minute'], 'fullName': actor['name']}
            normalized = normalize_fotmob_goal(adapter, home_team_id=team_ids['home'], away_team_id=team_ids['away'])
            beneficiary_side = normalized['detail']['beneficiary_side']
            item.update({'kind': 'goal', 'own_goal': own_goal, 'penalty': 'penalty' in event_type,
                         'beneficiary_side': beneficiary_side, 'beneficiary_team_id': team_ids[beneficiary_side],
                         'score_after': {'home': after[0], 'away': after[1]},
                         'score_text_home_name': home_label, 'score_text_away_name': away_label,
                         'normalized': normalized,
                         'normalizer_adapter': 'Shared helper; ESPN score-text delta and source credited team, actor team from ESPN roster. No FotMob or actual shotmap source used.'})
            if own_goal:
                item['own_goal_actor'] = {'athlete_id': actor_id, 'player': actor['name'], 'team_id': actor['team_id'], 'side': item['player_side']}
                assert actor['team_id'] != item['beneficiary_team_id']
            else:
                assert actor['team_id'] == item['beneficiary_team_id']
            running_score = after
            if item['period'] == 1:
                halftime = after.copy()
            goals.append(item)
        else:
            assert actor['team_id'] == event_team_id
            item.update({'kind': 'red_card', 'dismissed_side': source_side,
                         'dismissed_team_id': event_team_id,
                         'opposing_side': 'away' if source_side == 'home' else 'home',
                         'second_yellow': 'second yellow' in event['text'].lower(),
                         'score_at_event': {'home': running_score[0], 'away': running_score[1]}})
            cards.append(item)
        timeline.append(item)
    assert running_score == final_score
    for index, side in enumerate(('home', 'away')):
        assert _score_integer(teams[side]['linescores'][0]) == halftime[index]
    stats = {}
    xg_source_fields = {}
    for box_team in document.get('boxscore', {}).get('teams', []):
        team_id = str(box_team['team']['id'])
        assert team_id in team_ids.values()
        raw_stats = {s['name']: s.get('displayValue') for s in box_team.get('statistics', [])}
        xg_stats = [s for s in box_team.get('statistics', []) if s.get('name', '').lower() == 'xg' or re.search(r'expected.?goals?', s.get('name', '') + ' ' + s.get('label', ''), re.I)]
        xg_source_fields[team_id] = xg_stats
        stats[team_id] = {k: number(raw_stats.get(k)) for k in ['totalShots', 'shotsOnTarget', 'possessionPct', 'redCards', 'saves', 'wonCorners', 'penaltyKickGoals', 'penaltyKickShots', 'expectedGoals', 'xG']}
        assert stats[team_id]['redCards'] == sum(c['dismissed_team_id'] == team_id for c in cards)
    statistical_conflicts = []
    for side, team_id in team_ids.items():
        penalty_goals = sum(g['penalty'] and g['beneficiary_team_id'] == team_id for g in goals)
        if stats[team_id]['penaltyKickGoals'] is not None and stats[team_id]['penaltyKickGoals'] != penalty_goals:
            statistical_conflicts.append({'field': 'penaltyKickGoals', 'side': side, 'team_id': team_id,
                                         'boxscore_value': stats[team_id]['penaltyKickGoals'],
                                         'scored_penalty_event_count': penalty_goals,
                                         'handling': 'Preserve both values; score-text goal events and final/period score evidence establish scored penalties. Do not use this boxscore field as penalty-goal truth.'})
        opponent = 'away' if side == 'home' else 'home'
        opponent_sot = stats[team_ids[opponent]]['shotsOnTarget']
        reported_saves = stats[team_id]['saves']
        if opponent_sot is not None and reported_saves is not None and opponent_sot - score90[opponent] != reported_saves:
            statistical_conflicts.append({'field': 'saves', 'side': side, 'team_id': team_id,
                                         'boxscore_value': reported_saves,
                                         'opponent_shots_on_target_minus_goals': opponent_sot - score90[opponent],
                                         'handling': 'Simple cross-field identity differs; possible provider definitions or unrecorded team saves. Preserve source values and do not infer goalkeeper quality from this identity.'})
    commentary_review = [e for e in document.get('commentary', []) if re.search(r'VAR|OVERTURNED|No Goal|Match ends|Half ends|converts the penalty', e.get('text', ''), re.I)]
    lineup_changes = {}
    for side in teams:
        current_xi = {p['id']: p for p in starters[side]}
        prior_info = prior_by_team[team_ids[side]]
        prior_xi = {p['id']: p for p in prior_info['starting_xi']}
        assert instant(prior_info['evidence']['kickoff_at']) < instant(fixture['kickoff_at'])
        lineup_changes[side] = {'comparison': 'Compared with the cached 14-Nov Nations League starting XI; changes do not prove injury or suspension.',
                                'prior_evidence': prior_info['evidence'],
                                'unchanged_count': len(current_xi.keys() & prior_xi.keys()),
                                'changed_count': len(current_xi.keys() - prior_xi.keys()),
                                'new_starters': [current_xi[k] for k in sorted(current_xi.keys() - prior_xi.keys())],
                                'previous_starters_not_starting': [prior_xi[k] for k in sorted(prior_xi.keys() - current_xi.keys())],
                                'previous_starting_xi': prior_info['starting_xi']}
    evidence = {k: capture[k] for k in ['source_url', 'source_path', 'source_sha256', 'observed_at', 'http_status', 'request_started_at', 'request_finished_at', 'capture_path']}
    evidence['query_time'] = capture['request_started_at']
    evidence['body_saved_at'] = datetime.fromtimestamp(Path(capture['source_path']).stat().st_mtime, timezone.utc).isoformat()
    evidence['timestamp_note'] = 'request_started_at is query time; observed_at/request_finished_at record response headers arrival; body_saved_at is the raw-file write timestamp.'
    result = {k: fixture[k] for k in ['match_id', 'competition', 'cohort', 'stage', 'league_level', 'home', 'away', 'home_name', 'away_name', 'kickoff_at', 'date', 'gender', 'age', 'entity', 'neutral']}
    result.update({'status': 'completed', 'event_status': 'FT', 'score_basis': 'regulation_90',
                   'home_goals': score90['home'], 'away_goals': score90['away'], 'source_event_id': competition['id'],
                   'source_url': capture['source_url'], 'source_path': capture['source_path'],
                   'source_sha256': capture['source_sha256'], 'source_http_status': capture['http_status'],
                   'observed_at': capture['observed_at'], 'query_time': capture['request_started_at'],
                   'capture_path': capture['capture_path'], 'home_team_id': team_ids['home'], 'away_team_id': team_ids['away'],
                   'period_evidence': periods, 'identity_verified': True})
    item = {'match_id': fixture['match_id'], 'home_name': names['home'], 'away_name': names['away'],
            'team_ids': team_ids, 'competition': fixture['competition'], 'league_level': fixture['league_level'],
            'stage': fixture['stage'], 'kickoff_at': competition['date'], 'status': 'completed', 'event_status': 'FT',
            'score_basis': 'regulation_90', 'score_90': score90, 'halftime_score': {'home': halftime[0], 'away': halftime[1]},
            'period_evidence': periods, 'team_stats': stats, 'real_xg': {k: None if not v else v for k, v in xg_source_fields.items()},
            'xg_source_fields': xg_source_fields, 'xg_note': '真实 xG 仅从明确的 expectedGoals/xG 字段读取；本批缺失，射门和射正不得当作 xG。',
            'goals': goals, 'red_cards': cards, 'critical_timeline': timeline,
            'commentary_review': commentary_review, 'statistical_conflicts': statistical_conflicts,
            'starting_xi': starters, 'formations': formations, 'lineup_changes_vs_prior': lineup_changes,
            'capture': evidence, 'source_path': capture['source_path'], 'source_sha256': capture['source_sha256'],
            'source_url': capture['source_url'], 'observed_at': capture['observed_at'],
            'data_limitations': ['ESPN single current result source; shared fields within one response are not independent corroboration.',
                                 'Starting XI changes are observed selection differences; reasons are not inferred.',
                                 'Postmatch evidence only; no backfill to prematch forecasts.']}
    results.append(result)
    process.append(item)
    integrity.append({'match_id': fixture['match_id'], 'raw_sha256_verified': True, 'locked_identity_verified': True,
                      'kickoff_verified': True, 'final_status_verified': True, 'regulation_period_sum_verified': True,
                      'goal_delta_and_roster_ownership_verified': True, 'goal_count': len(goals),
                      'red_cards': len(cards), 'starting_xi_counts': {s: len(v) for s, v in starters.items()},
                      'has_real_xg': any(xg_source_fields.values())})

write(ROOT / 'results.json', results)
write(ROOT / 'process-summary.json', process)
write(ROOT / 'normalization-audit.json', {'verified_at': datetime.now(timezone.utc).isoformat(),
      'scope_source_path': locked['source_path'], 'scope_source_sha256': locked['source_sha256'],
      'matches': integrity, 'current_http_requests': receipt['http_requests'], 'prior_http_requests': 0,
      'goal_events': sum(len(p['goals']) for p in process), 'red_card_events': sum(len(p['red_cards']) for p in process),
      'own_goals': sum(g['own_goal'] for p in process for g in p['goals']),
      'xg_matches': sum(i['has_real_xg'] for i in integrity),
      'statistical_conflicts': [{'match_id': p['match_id'], **c} for p in process for c in p['statistical_conflicts']],
      'helper_source_paths': [str(CODE / 'research/review_events.py'), str(CODE / 'research_program/nations_phase.py')]})
for r, p in zip(results, process):
    print(f"{r['match_id']} {r['home_name']} {r['home_goals']}-{r['away_goals']} {r['away_name']} FT | XI changes "
          f"{p['lineup_changes_vs_prior']['home']['changed_count']}/{p['lineup_changes_vs_prior']['away']['changed_count']}")
