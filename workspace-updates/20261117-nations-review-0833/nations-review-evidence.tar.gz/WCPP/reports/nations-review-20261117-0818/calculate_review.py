"""Evaluate immutable first forecasts, delivered revisions and original future plan."""
import json,sys,math,hashlib
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import numpy as np
SOURCE=Path('/workspace/Football-Analysis-nations-repair-20261116')
sys.path[:0]=[str(SOURCE/'runtime'),str(SOURCE/'runtime/v5'),str(SOURCE/'runtime/optimization')]
from research.analysis_freeze import verify,digest,aware
from research.team_goal_analysis import summarize_prediction,review as goal_review
from research_program.future_validation import check_matrix,quote_audit
from research_program.nations_phase import verify_period_scores
from v5.paired_review import review
from v2.model import total_settlement
from optimization.evaluate import settle_ou
from nations_league.repair_forward import review as forward_review,validate_result
R=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(name,x):
 with (R/name).open('x') as h:json.dump(x,h,ensure_ascii=False,indent=2,allow_nan=False)
lock=read(R/'review-scope-lock.json')
results=read(R/'verified-results.json');res={r['match_id']:r for r in results}
assert len(res)==len(results) and set(res)<=set(i['fixture']['match_id'] for i in lock['fixtures'])
for i in lock['fixtures']:
 if i['fixture']['match_id'] in res:validate_result(res[i['fixture']['match_id']],i['fixture'])
def record(ref):
 z=verify(read(ref['path']));assert z['record_sha256']==ref['sha256'];return z
def actual(mid):
 r=res[mid];h,a=r['home_goals'],r['away_goals'];return f'{h}-{a}',('主胜' if h>a else '客胜' if h<a else '平局')
def pair(ref,candidate=True):
 z=record(ref);p=z['payload'];a,b=('current','test') if candidate else ('current_model','test_model')
 from nations_league.repair_forward import identity as fixture_identity
 assert fixture_identity(p[a]['input'])==fixture_identity(z['fixture'])
 assert fixture_identity(p[b]['input'])==fixture_identity(z['fixture'])
 return dict(match_id=z['match_id'],current_model=p[a],test_model=p[b])
def settle(mid,line,direction):
 side={'大':'over','小':'under'}.get(direction)
 if side is None or mid not in res:return None
 r=res[mid];m=np.zeros((51,51));m[r['home_goals'],r['away_goals']]=1
 out=next(k for k,v in total_settlement(m,line,side).items() if v==1.)
 assert {'win':'FULL_WIN','half_win':'HALF_WIN','push':'PUSH','half_loss':'HALF_LOSS','loss':'FULL_LOSS'}[out]==settle_ou(r['home_goals']+r['away_goals'],line,side)
 return out
def wilson(h,n):
 if not n:return None
 z=1.959963984540054;p=h/n;den=1+z*z/n;v=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den;c=(p+z*z/(2*n))/den;return [c-v,c+v]
def counts(rows):
 pop=len(rows);done=[r for r in rows if r.get('settled',True)]
 ph=[r['primary_hit'] for r in done if r['primary_hit'] is not None];wh=[r['wdl_hit'] for r in done if r['wdl_hit'] is not None]
 t=Counter(r['total_settlement'] for r in done if r['total_settlement'] is not None);n=sum(t.values());non=n-t['push']
 selected=dict(primary=sum(r['primary'] is not None for r in rows),wdl=sum(r['wdl'] in ['主胜','平局','客胜'] for r in rows),total=sum(r['total_direction'] in ['大','小'] for r in rows))
 return dict(population=pop,settled=len(done),pending=pop-len(done),selected=selected,coverage={k:v/pop if pop else None for k,v in selected.items()},primary_n=len(ph),primary_hits=sum(ph),primary_accuracy=sum(ph)/len(ph) if ph else None,primary_abstentions=len(done)-len(ph),primary_hits_over_population=sum(ph)/pop if pop else None,primary_wilson_95=wilson(sum(ph),len(ph)),wdl_n=len(wh),wdl_hits=sum(wh),wdl_accuracy=sum(wh)/len(wh) if wh else None,wdl_wilson_95=wilson(sum(wh),len(wh)),total_n=n,total_non_push_n=non,total_strict_full_win_rate=t['win']/non if non else None,total_settlements={k:t[k] for k in ['win','half_win','push','half_loss','loss']})
comp=[];pairs={'first':[],'published_revision':[]};active=[];identity=[];predictions={};updated_pairs=[]
for item in lock['fixtures']:
 f=item['fixture'];mid=f['match_id'];first=record(item['tracks']['candidate']['first']);rev=record(item['published_candidate_update'])
 for label,ref in [('first',item['tracks']['candidate']['first']),('published_revision',item['published_candidate_update'])]:
  p=record(ref)['payload']
  for role in ['current','test']:check_matrix(p[role])
  pairs[label].append(pair(ref))
 identity.append(dict(match_id=mid,matrix_identity={r:first['payload'][r]['matrix_hash']==rev['payload'][r]['matrix_hash'] for r in ['current','test']},artifact_identity={r:first['payload'][r]['artifact_sha256']==rev['payload'][r]['artifact_sha256'] for r in ['current','test']},first_ref=item['tracks']['candidate']['first'],published_ref=item['published_candidate_update']))
 active.append(pair(item['tracks']['active']['first'],False))
 c=record(item['published_comprehensive']);p=c['payload'];assert c['evaluation_slot']=='FIRST_PREMATCH'
 assert quote_audit(f)['eligible'] and p['actual_quote']==f['total_quote']
 done=mid in res;score,wdl=actual(mid) if done else (None,None)
 comp.append(dict(match_id=mid,name=item['name'],level=f['league_level'],settled=done,actual=score,primary=p['primary'],primary_hit=p['primary']==score if done and p['primary'] is not None else None,wdl=p['wdl'],wdl_hit=p['wdl']==wdl if done and p['wdl'] in ['主胜','平局','客胜'] else None,total_line=p['total_line'],total_direction=p['total_direction'],total_settlement=settle(mid,p['total_line'],p['total_direction']),quote=p['actual_quote'],freeze_id=c['freeze_id'],record_sha256=c['record_sha256'],recorded_at=c['recorded_at']))
 original=record(item['original_repair_comparison'])['payload']['predictions']
 updated=record(item['repair_reference_update'])['payload']['predictions']
 for role in ['fixed_current','fixed_test','challenger']:
  check_matrix(updated[role]);assert original[role]['matrix_hash']==updated[role]['matrix_hash'];assert original[role]['artifact_sha256']==updated[role]['artifact_sha256']
 predictions[mid]=dict(old_current=rev['payload']['current'],old_test=rev['payload']['test'],**updated)
top=[];tr=record(lock['top3_receipt'])
for rank,t in enumerate(tr['payload']['top3'],1):
 row=next(x for x in comp if x['match_id']==t['match_id']);assert t['rank']==rank
 for k in ['primary','wdl','total_line','total_direction']:assert row[k]==t[k]
 top.append(dict(row,rank=rank))
net={};prob={}
def summarize_net(rows):
 if not rows:return dict(n=0)
 dif=np.array([int(x['comprehensive_hit'])-int(x['candidate_hit']) for x in rows]);rng=np.random.default_rng(20261117);boot=rng.choice(dif,size=(20000,len(dif)),replace=True).mean(axis=1);right=int((dif>0).sum());wrong=int((dif<0).sum());n=right+wrong
 return dict(n=len(rows),changed_right=right,changed_wrong=wrong,net_hits=int(dif.sum()),descriptive_match_bootstrap_95=np.quantile(boot,[.025,.975]).tolist(),exact_discordant_sign_test_p=min(1.,2*sum(math.comb(n,k) for k in range(min(right,wrong)+1))/2**n) if n else 1.,single_date_cluster=True,not_promotion_evidence=True)
for role in ['old_current','old_test','fixed_current','fixed_test','challenger']:
 nr=[];wr=[];diag=[]
 for i in lock['fixtures']:
  mid=i['fixture']['match_id']
  if mid not in res:continue
  p=predictions[mid][role];matrix=check_matrix(p);h,a=res[mid]['home_goals'],res[mid]['away_goals'];score,wdl=actual(mid);c=next(x for x in comp if x['match_id']==mid)
  base=dict(match_id=mid,level=i['fixture']['league_level'],version=p['version'])
  if c['primary'] is not None:nr.append(dict(base,comprehensive=c['primary'],candidate=p['primary'],actual=score,comprehensive_hit=c['primary_hit'],candidate_hit=p['primary']==score))
  if c['wdl'] in ['主胜','平局','客胜']:wr.append(dict(base,comprehensive=c['wdl'],candidate=p['wdl_reference'],actual=wdl,comprehensive_hit=c['wdl_hit'],candidate_hit=p['wdl_reference']==wdl))
  g=summarize_prediction(p);gr=goal_review(g,home_goals=h,away_goals=a);tot=np.add.outer(np.arange(matrix.shape[0]),np.arange(matrix.shape[1]));line=i['fixture']['total_quote']['line']
  probs=total_settlement(matrix,line,'under');category=settle(mid,line,'小')
  diag.append(dict(base,training_cutoff=p['training_data_cutoff'],actual=[h,a],primary=p['primary'],statistical_top1=p.get('statistical_top1',p['primary']),primary_hit=p['primary']==score,mean=[g[s]['mean'] for s in ['home','away']],mean_error=[gr[s]['mean_error'] for s in ['home','away']],absolute_error=[gr[s]['absolute_error'] for s in ['home','away']],interval_hit=[gr[s]['interval_hit'] for s in ['home','away']],interval=[g[s]['central_interval'] for s in ['home','away']],p_zero=[g[s]['p0'] for s in ['home','away']],observed_zero=[h==0,a==0],p_total_ge4=float(matrix[tot>=4].sum()),observed_total_ge4=h+a>=4,p_total_ge6=float(matrix[tot>=6].sum()),observed_total_ge6=h+a>=6,actual_score_probability=float(matrix[h,a]),score_log_loss=-math.log(max(float(matrix[h,a]),1e-15)),wdl_log_loss=-math.log(max(p['wdl'][wdl],1e-15)),wdl_brier_sum3=sum((v-int(k==wdl))**2 for k,v in p['wdl'].items()),actual_total_line=line,total_settlement_category_probabilities=probs,total_category_observed=category,total_category_log_loss=-math.log(max(probs[category],1e-15)),total_category_brier_sum5=sum((v-int(k==category))**2 for k,v in probs.items())))
 def grouped(rows):return {v:summarize_net([x for x in rows if x['version']==v]) for v in sorted({x['version'] for x in rows})}
 net[role]=dict(score=dict(rows=nr,batch_descriptive=summarize_net(nr),by_version=grouped(nr)),wdl=dict(rows=wr,batch_descriptive=summarize_net(wr),by_version=grouped(wr)))
 def ps(ds):return dict(n=len(ds),**{k:np.mean([d[k] for d in ds],axis=0).tolist() for k in ['actual','mean','mean_error','absolute_error','interval_hit','p_zero','observed_zero','p_total_ge4','observed_total_ge4','p_total_ge6','observed_total_ge6','score_log_loss','wdl_log_loss','wdl_brier_sum3','total_category_log_loss','total_category_brier_sum5']})
 prob[role]=dict(rows=diag,by_version={v:ps([d for d in diag if d['version']==v]) for v in sorted({d['version'] for d in diag})},no_post_result_fitting=True,revision_total_probabilities_not_model_OU_selections=True)
candidate_reviews={label:review(ps,results) for label,ps in pairs.items()};active_review=review(active,results)
forward=forward_review(lock['repair_bundle'],results)
# Published refresh references have scores/WDL, but no selected total directions.
revision_reviews={'scope':'Independent delivered references; their cutoffs differ by seconds, so no paired comparison. Original forward plan provides the matched comparison.','tracks':{}}
for role in ['old_current','old_test','fixed_current','fixed_test','challenger']:
 # The canonical evaluator has a pair-only API. Use the same immutable forecast
 # in both slots and retain one slot; this creates no second sample/comparator.
 ps=[]
 for i in lock['fixtures']:
  mid=i['fixture']['match_id'];p=predictions[mid][role]
  ps.append(dict(match_id=mid,current_model=p,test_model=p))
 rv=review(ps,results)
 revision_reviews['tracks'][role]=dict(summary=rv['models']['当前模型'],rows=[dict(match_id=x['match_id'],result=x['result'],**x['models']['当前模型']) for x in rv['paired_rows']],pending=rv['pending'])
# Previous 34 settled unique first versions remain separate from this delivery's revision.
previous=Path('/workspace/WCPP/reports/nations-review-20261116-0822')
old=read(previous/'cumulative-inputs.json')['original_results']+read(previous/'verified-results.json')
assert len(old)==len({r['match_id'] for r in old})==34 and not set(res)&{r['match_id'] for r in old}
oldpairs=[];oldrefs=[]
for r in old:
 assert sha(r['source_path'])==r['source_sha256'];raw=read(r['source_path']);c=raw['header']['competitions'][0]
 for side in ['home','away']:
  t=next(t for t in c['competitors'] if t['homeAway']==side);assert verify_period_scores(t,c['status'])['regulation']==r[side+'_goals']
 path=Path('/workspace/WCPP/forecasts/issued-analyses')/digest(dict(match_id=r['match_id'],stage='prematch',track='nations-paired-candidates'))/'000001.json'
 z=verify(read(path));assert z['evaluation_slot']=='FIRST_PREMATCH';ref=dict(path=str(path),sha256=z['record_sha256'],freeze_id=z['freeze_id']);oldpairs.append(pair(ref));oldrefs.append(ref)
cumulative=review(oldpairs+pairs['first'],old+results)
write('cumulative-inputs.json',dict(original_results=old,first_candidate_receipts=oldrefs,unique_n=len(old)+len(results)))
for p in lock['protected_assets']:assert sha(p['path'])==p['sha256']
m=dict(schema='WCPP-NATIONS-REVIEW-20261117-1',calculated_at=datetime.now(timezone.utc).isoformat(),population=10,completed=len(results),pending=10-len(results),comprehensive=dict(summary=counts(comp),rows=comp),top3=dict(summary=counts(top),rows=top,original_receipt=lock['top3_receipt']),active_frozen_pairs=active_review,active_scope=dict(population=10,available=0,explicit_refusal_freezes=10),candidate_models=candidate_reviews,first_vs_revision_identity=identity,repair_original_forward=forward,repair_published_revision=revision_reviews,manual_net=net,probability_diagnostics=prob,cumulative_first_candidates=cumulative,model_total_direction_note='Original 18-match repair plan has pre-frozen model OU directions; original old pair and published numeric references do not. Separate scopes, no retroactive selections.',active_registry_sha256=lock['active_registry_sha256'],model_parameters_changed=False,model_promoted=False)
write('metrics.json',m)
print(json.dumps(dict(comprehensive=m['comprehensive']['summary'],top3=m['top3']['summary'],net={r:{k:v['batch_descriptive'] for k,v in z.items()} for r,z in net.items()},original_forward=dict(population=forward['population'],settled=forward['settled'],pending=len(forward['pending'])),cumulative=len(old)+len(results)),ensure_ascii=False))
