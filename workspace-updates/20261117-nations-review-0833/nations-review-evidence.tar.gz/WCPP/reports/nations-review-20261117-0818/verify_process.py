"""Root-agent raw-evidence audit; postmatch evidence never enters prematch inputs."""
import json,sys,re,hashlib
from pathlib import Path
from datetime import datetime,timezone
sys.path.insert(0,'/workspace/Football-Analysis-nations-repair-20261116/runtime')
from research.review_events import normalize_fotmob_goal
from research_program.nations_phase import verify_period_scores,_score_integer
from research.analysis_freeze import aware
from nations_league.repair_forward import validate_result
R=Path(__file__).resolve().parent;P=Path('/workspace/WCPP/reports/nations-prematch-20261116-2018')
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
results=read(R/'verified-results.json');lock=read(R/'review-scope-lock.json');fixtures={x['fixture']['match_id']:x['fixture'] for x in lock['fixtures']}
cross=read(R/'results/odds-crosscheck.json');assert sha(cross['source_path'])==cross['source_sha256']
secondary={x['id']:x for x in read(cross['source_path'])};premarket={x['id']:x for x in read(P/'market-current/odds.json')}
cm={x['match_id']:x for x in cross['matches']};process=[];n_goals=0;own_goals=[];kickoff_differences=[]
prior_ids={'espn:401861181':['316610'],'espn:401861184':['330626'],'espn:401861188':['405692','193282']}
for r in results:
 mid=r['match_id'];f=fixtures[mid];validate_result(r,f);raw=read(r['source_path']);co=raw['header']['competitions'][0]
 teams={s:next(x for x in co['competitors'] if x['homeAway']==s) for s in ['home','away']}
 tids={s:teams[s]['team']['id'] for s in teams};names={s:teams[s]['team']['displayName'] for s in teams}
 athletes={str(p['athlete']['id']):dict(team_id=str(ro['team']['id']),starter=p.get('starter'),name=p['athlete']['displayName']) for ro in raw['rosters'] for p in ro['roster']}
 score=[0,0];goals=[];ht=[0,0]
 for e in raw.get('keyEvents',[]):
  if not e.get('scoringPlay'):continue
  assert not e.get('shootout') and e['period']['number'] in [1,2]
  found=re.search(re.escape(names['home'])+r' (\d+), '+re.escape(names['away'])+r' (\d+)\.',e['text']);assert found,e['text']
  after=list(map(int,found.groups()));own=e['type']['type']=='own-goal';beneficiary=str(e['team']['id']);actorid=str(e['participants'][0]['athlete']['id']);actor=athletes[actorid]
  # Minimal event adapter: score delta comes from ESPN text, actor side from
  # ESPN roster. Shared helper validates ownership; this is not FotMob data.
  adapted=dict(type='Goal',homeScore=score[0],awayScore=score[1],newScore=after,ownGoal=own,isHome=beneficiary==tids['home'],shotmapEvent=dict(isOwnGoal=own,teamId=actor['team_id']),timeStr=e['clock']['displayValue'],fullName=actor['name'])
  norm=normalize_fotmob_goal(adapted,home_team_id=tids['home'],away_team_id=tids['away'])
  goals.append(dict(event_id=e['id'],minute=e['clock']['displayValue'],period=e['period']['number'],source_type=e['type']['type'],source_text=e['text'],athlete_id=actorid,player_team_id=actor['team_id'],beneficiary_team_id=beneficiary,normalized=norm))
  score=after
  if e['period']['number']==1:ht=after
  if own:own_goals.append(dict(match_id=mid,**goals[-1]))
 assert score==[r['home_goals'],r['away_goals']]
 for j,s in enumerate(['home','away']):
  assert _score_integer(teams[s]['linescores'][0])==ht[j]
  assert verify_period_scores(teams[s],co['status'])['regulation']==score[j]
 stats={}
 for t in raw['boxscore']['teams']:
  values={x['name']:x['displayValue'] for x in t['statistics']};stats[str(t['team']['id'])]=values
 overview={s:{k:(float(stats[tids[s]][k]) if k in stats[tids[s]] else None) for k in ['totalShots','shotsOnTarget','redCards','expectedGoals','xG']} for s in ['home','away']}
 reds=[dict(minute=e['clock']['displayValue'],type=e['type']['type'],team_id=e['team']['id'],text=e['text']) for e in raw.get('keyEvents',[]) if 'red' in e.get('type',{}).get('type','')]
 pid=cm[mid]['prematch_provider_match_id'];before=premarket[pid];after=secondary[pid]
 assert before['home_team']==f['home_name'] and before['away_team']==f['away_name']
 assert aware(before['commence_time'])==aware(f['kickoff_at'])
 assert after['home_team']==before['home_team'] and after['away_team']==before['away_team'] and after['completed'] is True
 ss={x['name']:int(x['score']) for x in after['scores']};assert [ss[after['home_team']],ss[after['away_team']]]==score
 drift=(aware(after['commence_time'])-aware(f['kickoff_at'])).total_seconds()
 if drift:kickoff_differences.append(dict(match_id=mid,scheduled=f['kickoff_at'],secondary_updated=after['commence_time'],difference_seconds=drift,identity='PREMATCH_PROVIDER_ID_RETAINED; scheduled kickoff never rewritten'))
 process.append(dict(match_id=mid,name=next(x['name'] for x in lock['fixtures'] if x['fixture']['match_id']==mid),source_path=r['source_path'],source_sha256=r['source_sha256'],score=score,halftime=ht,team_ids=tids,stats=overview,goals=goals,red_cards=reds,starting_xi={s:[dict(athlete_id=k,**v) for k,v in athletes.items() if v['team_id']==tids[s] and v['starter']] for s in ['home','away']},prematch_unresolved_people={pid:athletes.get(pid) for pid in prior_ids.get(mid,[])},absence_not_proof_of_suspension=True,secondary_source_id=pid))
 n_goals+=len(goals)
audit=dict(schema='WCPP-ROOT-PROCESS-AUDIT-20261117-1',verified_at=datetime.now(timezone.utc).isoformat(),results=10,independent_scores_agree=10,goal_events_verified=n_goals,own_goals=own_goals,secondary_kickoff_differences=kickoff_differences,real_xg_available=sum(any(x['stats'][s]['expectedGoals'] is not None or x['stats'][s]['xG'] is not None for s in ['home','away']) for x in process),source_score_basis='ESPN regulation period evidence; TheOdds independent final-score corroboration',original_result_sources_retained=True)
for name,obj in [('verified-process.json',process),('process-audit.json',audit)]:
 with (R/name).open('x') as h:json.dump(obj,h,ensure_ascii=False,indent=2,allow_nan=False)
print(json.dumps(audit,ensure_ascii=False))
