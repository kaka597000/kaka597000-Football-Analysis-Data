"""Durable review increment with complete referenced chains and raw results."""
from pathlib import Path
import hashlib,json,os,shutil,sys,tarfile
from datetime import datetime,timezone
sys.path.insert(0,'/workspace/Football-Analysis-nations-repair-20261116/runtime')
from research.analysis_freeze import verify
R=Path(__file__).resolve().parent;W=Path('/workspace/WCPP').resolve();DATA=Path('/workspace/kaka597000-Football-Analysis-Data')
D=DATA/'workspace-updates/20261117-nations-review-0833';D.mkdir(parents=True,exist_ok=True)
assert not (D/'nations-review-evidence.tar.gz').exists()
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
files={};delivery=read(R/'delivery.json');lock=read(R/'review-scope-lock.json')
def add(p):
 p=Path(p).resolve();assert p.is_file()
 if p.is_relative_to(W):name='WCPP/'+str(p.relative_to(W))
 elif p.is_relative_to(DATA):name='kaka597000-Football-Analysis-Data/'+str(p.relative_to(DATA))
 else:raise ValueError('unexpected evidence path')
 files[name]=p
def refs(x):
 if isinstance(x,dict):
  if x.get('freeze_id') and x.get('path') and x.get('sha256'):yield x
  for v in x.values():yield from refs(v)
 elif isinstance(x,list):
  for v in x:yield from refs(v)
for p in R.rglob('*'):
 if p.is_file() and '__pycache__' not in p.parts:add(p)
allrefs={r['sha256']:r for doc in [lock,delivery,read(R/'cumulative-inputs.json')] for r in refs(doc)}
chains=set()
for ref in allrefs.values():
 path=Path(ref['path']);previous=None
 if not path.stem.isdigit():
  z=verify(read(path));assert z['record_sha256']==ref['sha256'] and z['revision']==1 and z['previous_sha256'] is None;add(path);chains.add(str(path));continue
 for p in sorted(path.parent.glob('[0-9]*.json')):
  if p.name>path.name:continue
  z=verify(read(p));assert z['previous_sha256']==previous;previous=z['record_sha256'];add(p);chains.add(str(p))
 assert previous==ref['sha256']
for r in read(R/'cumulative-inputs.json')['original_results']:
 assert sha(r['source_path'])==r['source_sha256'];add(r['source_path'])
B=Path(lock['repair_bundle'])
for p in B.rglob('*.json'):add(p)
prematch=Path('/workspace/WCPP/reports/nations-prematch-20261116-2018')
for name in ['delivery.json','欧国联赛前分析.md','candidate-diagnostics.json','source-audit.json']:add(prematch/name)
for folder in ['market-current','market-earlier']:
 for p in (prematch/folder).rglob('*'):
  if p.is_file():add(p)
state=delivery['forward_state_receipt'];add(state['run_path'])
secrets=[v.encode() for k,v in os.environ.items() if len(v)>=12 and any(s in k.upper() for s in ['SECRET','TOKEN','API_KEY','APIKEY'])]
for path in files.values():
 if any(secret in path.read_bytes() for secret in secrets):raise ValueError('credential value found in evidence')
archive=D/'nations-review-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for name,p in sorted(files.items()):tar.add(p,arcname=name,recursive=False)
manifest=dict(schema='WCPP-NATIONS-REVIEW-DELIVERY-20261117-1',created_at=datetime.now(timezone.utc).isoformat(),source_commit=delivery['source_commit'],report_freeze=delivery['report_receipt'],scope=dict(population=10,finished=10,primary_selected=7,primary_hits=0,wdl_selected=10,wdl_hits=8,totals=delivery['manual_total_settlements']),research_forward=dict(population=18,settled=10,pending=8),restore_assets_from='workspace-updates/20261116-nations-repair/',previous_prematch_archive='workspace-updates/20261116-nations-prematch-2044/',protected_registry_sha256=delivery['active_registry_sha256'],model_promotion=False,archive=dict(file=archive.name,bytes=archive.stat().st_size,sha256=sha(archive)),files=[dict(path=n,bytes=p.stat().st_size,sha256=sha(p)) for n,p in sorted(files.items())])
with tarfile.open(archive,'r:gz') as tar:
 members={x.name:x for x in tar.getmembers()};assert set(members)==set(files)
 for item in manifest['files']:
  member=members[item['path']];assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
  body=tar.extractfile(member).read();assert len(body)==item['bytes'] and hashlib.sha256(body).hexdigest()==item['sha256']
(D/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
for name in ['复盘报告.md','复盘展示.csv','delivery.json','verification.json','review-decision.json','metrics.json','process-audit.json']:shutil.copyfile(R/name,D/name)
(D/'README.md').write_text('''# 2026-11-17 欧国联复盘

[完整报告](复盘报告.md) · [逐场表格](复盘展示.csv) · [Python指标](metrics.json) · [冻结回执](delivery.json) · [哈希清单](manifest.json)

北京时间08:32冻结。10场完赛，综合唯一比分0/7、3待定；胜平负8/10；大小球5全输、1半输、1走盘、3观望。原TOP3比分0/3、方向3/3、大小球2全输1半输。保持活动参数与候选inactive，未发布环境。

压缩包含本次结果原文及来源、逐球校验、独立TheOdds对照、复盘计算脚本、原TOP3/综合/研究预测及完整前序冻结链；累计44场旧候选首版所需的历史结果和首版记录一并保留。现有18场五轨状态为10已结8待赛，未重新预测。真实源数据、一次性审计脚本和长期备份均不含密钥值。

恢复先按NEW-ENVIRONMENT.md及20261116-nations-repair恢复已有环境和模型。本增量压缩按WCPP/和kaka597000-Football-Analysis-Data/相对路径保存，逐文件SHA已从压缩包读回核验。只恢复到全新目录；已有同名文件应比对哈希，不能覆盖不同的冻结。原模型备份复用此前长期归档，不重复上传全部工件。

复算仅需读取原冻结矩阵和合格赛果，无需API、密钥或新预测。calculate_review.py的输出采用独占创建，应在复制出的新报告目录中运行；保留原始结果、scope lock和源路径映射。源码固定4c6061dd5eb2e4af77f18e64bd908a2847f039d0。

工程验证：10场原始90分钟身份、10场双源比分、29个逐球事件、63份原引用及81份受保护资产通过；大小球调用两份现有实现及独立四分之一盘核算。此为本次真实数据审计，不冒称新的云端CI或训练验收。原夜间采集Actions 43965649567成功回执仍可追溯。
''')
print(json.dumps(dict(archive=str(archive),bytes=archive.stat().st_size,sha256=sha(archive),files=len(files),freeze_chain_records=len(chains)),ensure_ascii=False))
