"""Append verified missing results to the existing forward queue; no API/inference."""
import json,sys,hashlib,shutil
from pathlib import Path
sys.path[:0]=['/workspace/Football-Analysis-nations-repair-20261116','/workspace/Football-Analysis-nations-repair-20261116/runtime','/workspace/Football-Analysis-nations-repair-20261116/runtime/v5']
from runtime.automation.nations_repair_cycle import result_from_raw,cycle
from research.analysis_freeze import verify
R=Path(__file__).resolve().parent;D=Path('/workspace/kaka597000-Football-Analysis-Data')
S=D/'future/nations-repair-state';B=D/'future/nations-repair-bundle'
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
plan=verify(read(B/'plan.json'));fixtures={f['match_id']:f for f in plan['payload']['fixtures_identity']}
before=read(S/'results.json');rows=list(before);known={r['match_id']:r for r in rows};added=[]
for result in read(R/'verified-results.json'):
 mid=result['match_id']
 if mid in known:
  old=known[mid];assert all(result[k]==old[k] for k in ['home_goals','away_goals','source_sha256','observed_at']);continue
 path=Path(result['source_path']);target=S/'raw'/path.name
 with target.open('xb') as h:h.write(path.read_bytes())
 assert sha(target)==result['source_sha256']
 sidecar=path.with_suffix('.capture.json')
 if sidecar.exists():shutil.copyfile(sidecar,S/'raw'/sidecar.name)
 new=result_from_raw(fixtures[mid],target,result['source_url'],result['observed_at']);assert new is not None
 rows.append(dict(new,source_path=str(target.relative_to(S))));added.append(mid)
assert rows[:len(before)]==before and len(rows)==len({r['match_id'] for r in rows})==10
(S/'results.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
report=cycle(B,S,max_requests=0,max_seconds=40)
assert report['population']==18 and report['settled']==10 and len(report['pending'])==8 and report['result_requests']==0
latest=max((S/'runs').glob('*.json'));run=read(latest)
receipt=run['freeze_receipt'];assert verify(read(receipt['path']))['record_sha256']==receipt['sha256']
out=dict(before_settled=len(before),added=added,settled=10,pending=report['pending'],result_requests=0,predictions_recomputed=False,source_results_sha256=sha(R/'verified-results.json'),state_results_sha256=sha(S/'results.json'),run_path=str(latest),run_sha256=sha(latest),freeze_receipt=receipt)
with (R/'forward-state-receipt.json').open('x') as h:json.dump(out,h,ensure_ascii=False,indent=2)
print(json.dumps(out,ensure_ascii=False))
