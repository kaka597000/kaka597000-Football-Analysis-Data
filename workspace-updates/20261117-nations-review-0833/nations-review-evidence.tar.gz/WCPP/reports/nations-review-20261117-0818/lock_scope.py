"""Lock first forecasts and the delivered revision before querying results."""
import hashlib,json,sys,subprocess
from pathlib import Path
from datetime import datetime,timezone
sys.path.insert(0,'/workspace/Football-Analysis-nations-repair-20261116/runtime')
from research.analysis_freeze import verify,save,aware
R=Path(__file__).resolve().parent
P=Path('/workspace/WCPP/reports/nations-prematch-20261116-2018')
B=Path('/workspace/WCPP/research/nations-repair-20261116/forward-v2')
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=lambda:datetime.now(timezone.utc).isoformat()
def write(name,obj):
 with (R/name).open('x') as f:json.dump(obj,f,ensure_ascii=False,indent=2,allow_nan=False)
def reference(path):
 z=verify(read(path))
 return dict(path=str(path),sha256=z['record_sha256'],freeze_id=z['freeze_id'],recorded_at=z['recorded_at'],evaluation_slot=z['evaluation_slot'])
def chain(ref):
 z=verify(read(ref['path']));assert z['record_sha256']==ref['sha256']
 paths=sorted(Path(ref['path']).parent.glob('*.json'))
 zs=[verify(read(p)) for p in paths]
 assert zs[0]['evaluation_slot']=='FIRST_PREMATCH'
 for z in zs:assert aware(z['recorded_at'])<aware(z['fixture']['kickoff_at'])
 return dict(first=reference(paths[0]),published=ref,chain=[reference(p) for p in paths])
d=read(P/'delivery.json');rows=read(P/'analysis-records.json');updates={x['match_id']:x for x in read(P/'repair-updates.json')}
items=[]
for row in rows:
 f=row['fixture'];mid=f['match_id'];tracks={k:chain(row[k+'_receipt']) for k in ['active','candidate','comprehensive']}
 c=verify(read(row['comprehensive_receipt']['path']));assert c['payload']==row['payload']
 items.append(dict(fixture=f,name=c['payload']['name'],tracks=tracks,published_candidate_update=row['candidate_receipt'],published_comprehensive=row['comprehensive_receipt'],repair_reference_update=updates[mid]['receipt'],original_repair_comparison=reference(B/'freezes'/f"{mid.replace(':','-')}.json"),published_selections={k:c['payload'][k] for k in ['primary','wdl','total_line','total_direction']}))
assert len(items)==len({x['fixture']['match_id'] for x in items})==10
for k in ['report_receipt','top3_receipt']:assert reference(d[k]['path'])['sha256']==d[k]['sha256']
plan=verify(read(B/'plan.json'));assert len(plan['payload']['fixtures_identity'])==18
top=verify(read(d['top3_receipt']['path']))['payload']['top3']
assert [x['match_id'] for x in top]==['espn:401861183','espn:401861182','espn:401861187']
protected=[Path('/workspace/WCPP/runtime/active-model.json')]
protected+=sorted(Path('/workspace/nations-model-20261110/models').rglob('*.json'))
protected+=sorted(Path('/workspace/WCPP/research/nations-repair-20261116/experiment-v4').rglob('*.json'))
lock=dict(schema='WCPP-NATIONS-REVIEW-SCOPE-20261117-1',locked_at=now(),result_access_started=False,population=10,fixtures=items,top3_receipt=d['top3_receipt'],report_receipt=d['report_receipt'],top3_order=top,original_repair_plan=reference(B/'plan.json'),repair_population=18,repair_bundle=str(B),policy='FIRST_PREMATCH_PRIMARY; PUBLISHED_REVISION_SEPARATE; NO_RESELECTED_TOP3; NO_RETROACTIVE_TOTAL_DIRECTION',source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd='/workspace/Football-Analysis-nations-repair-20261116',text=True).strip(),data_base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd='/workspace/kaka597000-Football-Analysis-Data',text=True).strip(),active_registry_sha256=sha(protected[0]),protected_assets=[dict(path=str(p),sha256=sha(p)) for p in protected],original_delivery_sha256=sha(P/'delivery.json'))
write('review-scope-lock.json',lock)
f=dict(match_id='review-nations:20261117-0818',kickoff_at=min(x['fixture']['kickoff_at'] for x in items),cutoff_at=now())
receipt=save(lock,f,stage='review',track='population-lock')
write('scope-lock-receipt.json',receipt)
print(json.dumps(dict(lock=receipt,population=10,repair_population=18,top3=[x['match_id'] for x in top],protected=len(protected)),ensure_ascii=False))
