"""Freeze verified review, its fixed TOP3, and the explicit model decision."""
import json,csv,sys,hashlib,subprocess
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
sys.path.insert(0,'/workspace/Football-Analysis-nations-repair-20261116/runtime')
from research.analysis_freeze import save,verify,aware
R=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();now=lambda:datetime.now(timezone.utc).isoformat()
def write(name,x):
 with (R/name).open('x') as h:json.dump(x,h,ensure_ascii=False,indent=2,allow_nan=False)
m=read(R/'metrics.json');lock=read(R/'review-scope-lock.json');results={x['match_id']:x for x in read(R/'verified-results.json')};process={x['match_id']:x for x in read(R/'verified-process.json')};audit=read(R/'process-audit.json');state=read(R/'forward-state-receipt.json')
s=m['comprehensive']['summary'];t=m['top3']['summary'];assert (s['primary_hits'],s['primary_n'],s['wdl_hits'],s['wdl_n'])==(0,7,8,10)
assert s['total_settlements']==dict(win=0,half_win=0,push=1,half_loss=1,loss=5)
assert t['primary_hits']==0 and t['wdl_hits']==3 and t['total_settlements']==dict(win=0,half_win=0,push=0,half_loss=1,loss=2)
assert audit['goal_events_verified']==29 and audit['independent_scores_agree']==10 and len(m['repair_original_forward']['pending'])==8
for row in m['comprehensive']['rows']:
 a=results[row['match_id']];assert row['actual']==f"{a['home_goals']}-{a['away_goals']}"
 if row['total_settlement'] is not None:
  line=row['total_line'];legs=[line] if line*2==int(line*2) else [line-.25,line+.25];g=a['home_goals']+a['away_goals'];v=sum(int(g<q)-int(g>q) for q in legs)/len(legs)
  if row['total_direction']=='大':v=-v
  assert row['total_settlement']=={1:'win',.5:'half_win',0:'push',-.5:'half_loss',-1:'loss'}[v]
def refs(x):
 if isinstance(x,dict):
  if x.get('freeze_id') and x.get('path') and x.get('sha256'):yield x
  for v in x.values():yield from refs(v)
 elif isinstance(x,list):
  for v in x:yield from refs(v)
oldrefs={x['sha256']:x for x in refs(lock)}
for ref in oldrefs.values():
 z=verify(read(ref['path']));assert z['record_sha256']==ref['sha256']
 if z['stage']=='prematch':assert aware(z['recorded_at'])<aware(z['fixture']['kickoff_at'])
for p in lock['protected_assets']:assert sha(p['path'])==p['sha256']
source='/workspace/Football-Analysis-nations-repair-20261116';assert not subprocess.check_output(['git','status','--porcelain'],cwd=source).strip()
decision=dict(decision=['KEEP_CURRENT_TEST_PARAMETERS','KEEP_ALL_RESEARCH_CANDIDATES_INACTIVE','CONTINUE_EXISTING_FROZEN_18_MATCH_PLAN','RETAIN_FAILED_MANUAL_SCORE_AND_TOTAL_CHOICES'],batch_population=10,manual_score_n=7,manual_primary_hits=0,cumulative_old_candidate_matches=44,original_forward_settled=10,original_forward_pending=8,parameters_changed=False,registry_changed=False,model_promoted=False,new_training_run=False,reasons=['Manual WDL 8/10 did not translate into exact scores (0/7) or actual totals (0 wins, 1 half loss, 1 push, 5 losses). Three score abstentions remain.', 'Germany 5-0 and Switzerland 4-0 had strong shots-on-target advantages without red cards. Switzerland had one own goal, followed by three other goals. Estonia red card followed the final goal, so it cannot explain the small-total miss.', 'Both old Test and fixed-recipe Test have zero exact-score hits this batch. Fixed Test WDL improved by one versus old Test, but fresh history is not proof of exact-score gains.', 'Manual exact score lost one hit to old Current on Gibraltar and one to the separate challenger on Faroe on the same seven eligible games. These baselines must not be combined into a hypothetical perfect model.', 'Old Current selects 1-1 in all ten; fixed Current remains 1-1 in eight. Structural grade-level averaging and conservative manual selection remain diagnostic concerns; this batch cannot identify new optimal weights.', 'No source provides real xG in the ten current summaries. Shots-on-target demonstrate shot placement/count, not calibrated chance quality or purely unlucky finishing.'],next_check=dict(trigger='Remaining eight original frozen matches reach verified 90-minute FT',population_locked=18,require=['Keep all five original tracks and original actual quotes','Report grade/version-specific Primary, WDL, five-way total settlement and coverage','Retain manual and statistical Primary separately','No tuning against these ten observed matches and relabeling them as untouched validation','Any later tail/strength/selection experiment requires its own locked temporal development and unseen forward cohort']),automatic_promotion=False)
write('review-decision.json',decision)
cn={None:'观望','win':'全赢','half_win':'半赢','push':'走盘','half_loss':'半输','loss':'全输'}
lines=['# 欧国联复盘｜北京时间2026年11月17日','','HELLO BOSS','','**本轮第一比分0/7，胜平负8/10（80%），实际大小球5全输、1半输、1走盘。原TOP3方向3/3，比分0/3。** 本轮没有达到首要目标；胜平负判断正确不能抵消比分和大小球失败。','',
'范围为北京时间11月16日23:00至17日03:45开球的10场，全部已90分钟完赛。按11月16日20:43冻结的综合发布稿结算；比分覆盖7/10、3场原待定，大小球覆盖7/10、3场原观望。严格全赢率为0/6（剔除走盘）；半输没有算成半个命中，走盘没有算赢。','',
'比分0/7的95% Wilson区间约0%–35.4%；胜平负8/10约49.0%–94.3%。本批很小，不能据一次80%宣布达到长期80%目标。原首版、发布修订和研究候选分别保留，没有赛后挑版本。','',
'|比赛|原唯一比分|90分钟赛果|比分|原胜平负|方向|原实际大小球|结算|','|---|---|---|---|---|---|---|---|']
for x in m['comprehensive']['rows']:
 total=f"{x['total_direction']}{x['total_line']:g}" if x['total_direction'] in ['大','小'] else '观望'
 lines.append(f"|{x['name']}|{x['primary'] or '待定'}|{x['actual']}|{'—' if x['primary_hit'] is None else '中' if x['primary_hit'] else '失'}|{x['wdl']}|{'中' if x['wdl_hit'] else '失'}|{total}|{cn[x['total_settlement']]}|")
lines+=['','实际盘均引用原冻结Pinnacle报价，北京时间11月16日20:04:40；没有按赛后盘口或统一2.5球结算。冰岛总球3，小2.75是半输；直布罗陀总球2，小2是走盘。哈萨克斯坦、立陶宛、希腊的原比分待定仍保留，已明确的胜平负或大小球独立结算。','',
'## 原TOP3，名单及排序不变','','|原排名|比赛|原比分→赛果|比分|原方向及结果|实际大小球|','|---|---|---|---|---|---|']
for x in m['top3']['rows']:lines.append(f"|{x['rank']}|{x['name']}|{x['primary']}→{x['actual']}|失|{x['wdl']}：中|{x['total_direction']}{x['total_line']:g}：{cn[x['total_settlement']]}|")
lines+=['','三场都判断对胜者，却都低估总进球：爱沙尼亚未零封、冰岛多进一球、斯洛文尼亚多进两球。三场赛事TOP3不是每场三种备选比分，原分析提到3-0等路径也不能补算第一比分命中。','',
'## 误差在哪里','',
'**1．强弱方向与进球幅度脱节。** 德国原1-1、主胜、小3.5，实际5-0。半场1-0，下半场60、65、71、77分钟再进四球，射正10-1，没有红牌；荷兰的近期大胜和首回合压制表现并未在本场延续。原Old Test德国/荷兰进球均值约1.34/1.37，固定配方刷新后约1.61/1.43，仍未刻画这次单边压制。真实xG缺失，无法进一步把偏差精确分成机会质量、射术和门将三部分。','',
'瑞士原1-0、小2.5，实际4-0，射正8-1。22分钟苏格兰球员Lewis Ferguson乌龙使瑞士领先，47、51、89分钟瑞士又进三球，无红牌。乌龙只解释一个进球，不能解释全部偏差；赛前“已锁定第一、可能轮换”的情景也不能自动推导为低得分。原Test瑞士均值1.53，刷新后1.58，均只选1-0。','',
'北马其顿原0-1、小2.25，实际0-3。斯洛文尼亚29、66、90+1分钟进球，射正6-4；零封方向成立，但只给客队一球低估获胜幅度。赛前已知北马五连败、失12球，却更强调斯洛文尼亚进攻不强和保住第二，防守脆弱及领先后继续进球的路径没有获得足够重视。赛后北马射正4次，也提醒零进球并不等于完全没有机会。','',
'**2．近期小比分被过度延伸。** 爱沙尼亚原1-0、小2.25，实际2-1：8分钟领先、45+1分钟丢球、60分钟再领先，射正4-2。90+1分钟红牌出现在全部进球之后，不能用红牌解释小球判断失败。赛前三场1-0、0-0、1-0支持谨慎预期，但不足以保证继续零封或最多两球。','',
'冰岛原2-0、小2.75，实际3-0，射门25-4、射正11-0，25分钟、37分钟点球、50分钟已进三球。赛前已有本届进12失1、上轮5-0、首回合3-0的证据；虽然报告列出3-0风险，最后仍把小球列入TOP3，属于反证与最终推荐没有充分一致。点球是实际路径的一部分，不剔除。立陶宛2-1同样含50分钟点球及60分钟对手任意球，原小2.5全输，不能因为比分待定而把已选小球漏掉。','',
'**3．低比分集中不只是训练数据旧。** 综合7个点比分的平均总球为1.43，实际为3.00；同7场原Test矩阵期望总球约2.33、固定Test约2.39。点比分众数本来就不等于均值，这些数字不能直接当成校准检验；但与本轮七场全部未命中、七个大小球全部选小的结果一起看，人工选分和总球判断仍过于集中。原Current十场全为1-1，固定Current仍有八场1-1；仅刷新历史没有消除同级统一基础进球率的结构限制。','',
'**4．人工覆盖没有带来比分净增。** 直布罗陀81分钟用全场唯一一次射正扳成1-1：原Current的1-1命中，综合改为0-1失误。法罗1-0则被独立challenger命中，综合1-1失误。相同7场，综合对原Current净少1场、对原Test净增0场、对challenger净少1场；不能把不同候选各自命中的比赛拼成一个模型。方向上的增益不同：综合相对原Current在北马改对，相对原Test在德国改对，各净增1场。','',
'哈萨克斯坦2-2斯洛伐克为本轮另一场方向失误：主队29和65分钟两次领先，斯洛伐克56和90+5分钟追平，射正5-4。原“斯洛伐克已锁定第一”的轮换风险应保留，但本次缺乏可量化阵容与轮换影响，不能把失误确定归因于轮换。希腊1-0方向正确，比分原待定不补命中。四名赛前人员身份本场未列在ESPN名单中；缺席本身仍不证明停赛原因。','',
'## 五轨真实前向实验','',
'活动Current/Test仍没有通过验收的欧国联路由，十场均保留明确拒绝记录，活动有效预测覆盖0/10。下表是**未晋级研究工件**，各等级/版本分列。统计使用11月16日17:35已冻结的原18场计划，现10场完赛、8场待赛；原20:24发布参考只单独结算，不重复增加样本。','',
'|研究轨|等级|已结/待赛|精确比分|胜平负|大小球：全赢/半赢/走/半输/全输|','|---|---|---|---|---|---|']
mapping=[('原Current','old_current_vs_fixed_current','当前模型'),('原Test','old_test_vs_fixed_test','当前模型'),('固定刷新Current','old_current_vs_fixed_current','test模型'),('固定刷新Test','old_test_vs_fixed_test','test模型'),('新算法challenger','fixed_test_vs_challenger','test模型')]
for label,key,role in mapping:
 z=m['repair_original_forward']['comparisons'][key]['models'][role]
 for ver,v in z['by_version'].items():
  grade=ver.split('-')[2];sett=v['total_settlements'];seq='/'.join(str(sett[k]) for k in ['win','half_win','push','half_loss','loss'])
  lines.append(f"|{label}|{grade}|{v['settled']}/{v['pending']}|{v['primary_hits']}/{v['primary_eligible']}|{v['wdl_hits']}/{v['wdl_eligible']}|{seq}|")
lines+=['','跨等级只作本批计数概览，不声称同一版本的统一准确率：原Current比分1/10、原Test0/10、固定Current0/10、固定Test0/10、challenger1/10。固定Test胜平负8/10，相比原Test7/10增加德国一场；这不是精确比分改善。新算法只在C级法罗比固定Test多中一场，其他等级无比分增益。','',
'原五轨各有10场有效大小球结算，分母已经不是0。原Current及原Test各1全赢、1半输、1走盘、7全输；固定Current、固定Test、challenger各2全赢、1半输、1走盘、6全输。原冻结选向使用单位赔率下的结算概率平衡，不是实际赔率的盈利优化。其报价为北京时间17:14:51，和人工20:04:40的快照分开；本批盘线相同但价格不同。不能将概率诊断或不同节点的金额收益混为同场增益。','',
'旧候选11月10日首版与11月16日发布版工件及矩阵逐场相同，比分/方向成绩相同；固定刷新与challenger发布参考也与原计划矩阵相同。发布参考未存数值大小球选向，其大小球仍不新增结算，以上大小球成绩只属于原五轨计划。旧参考与新参考的输入截止相差数秒，因此发布参考各自评价；严格同节点比较使用原计划。','',
'同场净增、逐场矩阵概率、单队均值/80%模型内区间、零球概率、4球及6球尾部、精确比分log-loss、胜平负Brier/log-loss和盘口五类概率质量均保存在metrics.json。只有一个比赛日簇，按日期重采样的区间会退化；逐场重采样区间也只是描述，不作为显著性或晋级依据。','',
'## 累计首版候选及本次决定','','累计44场不重复、已完赛的原候选首版，各等级仍分开：','','|等级|已完赛|原Current比分|原Test比分|原Current胜平负|原Test胜平负|','|---|---|---|---|---|---|']
for grade in ['A','B','C','D']:
 c=m['cumulative_first_candidates']['models']['当前模型']['by_version'][f'WCPP-NATIONS-{grade}-CURRENT-0.1'];v=m['cumulative_first_candidates']['models']['test模型']['by_version'][f'WCPP-NATIONS-{grade}-TEST-0.1'];n=c['primary_eligible']
 lines.append(f"|{grade}|{n}|{c['primary_hits']}/{n}|{v['primary_hits']}/{n}|{c['wdl_hits']}/{n}|{v['wdl_hits']}/{n}|")
lines+=['','这44场仅为旧候选首版成绩，不是44场综合人工Primary，也不是新算法44场前向成绩。旧候选A/B/C训练截至10月6日、D截至10月4日；新固定工件已包含11月新增合格数据，本轮结果表明刷新完成不能直接写成效果改善。','',
'**本次决定：保持原活动参数，所有研究候选继续inactive；完整保留本轮失败，继续已有18场五轨计划。** 已将新取得的5场赛果追加到现有前向任务状态，现为10已结、8待赛，并用原结算入口重新冻结；没有发起新推理、补写赛前方向或重复采集。下一检查点是余下8场完赛，届时按原全集和各级工件比较。','',
'后续强弱差距、尾部及选分实验需把机会生成与终结误差拆开，补来源时间可证的过程/xG与人员数据；不把今晚失败简单修成“全部加一球”或“全部改大球”。这10场已成为已见诊断样本，不能再被新规则当作未见验证。没有证据支持立即切换权重。','',
'## 数据、冻结与恢复','',
'ESPN的10份原文已核对事件/球队ID、主客、赛程、等级/阶段、FT及90分钟分节，29个进球按比分递增和球员名单核对；瑞士乌龙明确区分球员队与受益队。The Odds API一次scores请求，使用赛前已保存的provider ID连接，10/10比分一致。法罗、哈萨克的TheOdds赛后开球字段晚1分钟，保留原赛程与同一provider ID，不改原冻结。','',
'5场复用夜间任务06:00北京时间的原文，保留原observed_at和SHA；旧缓存没有HTTP请求起止及状态，明确记为缺失。其余5场08:23–08:24新采集ESPN，独立赛果08:26采集，均HTTP200。10场当前原文都没有真实xG，不用射正冒充；赛后名单和过程只用于本复盘。','',
'[ESPN赛程](https://site.api.espn.com/apis/site/v2/sports/soccer/uefa.nations/scoreboard?dates=20261116)；逐场summary URL、原始响应哈希、TheOdds对照、比赛事件和采集限制随归档保存。','',
f"原综合报告冻结：{lock['report_receipt']['freeze_id']}；原TOP3：{lock['top3_receipt']['freeze_id']}。本轮08:22先锁定评价范围，随后读取赛果。实际复盘源码{lock['source_commit']}，原预测源码/模型身份仍以原交付为准。源码与活动工件本次未改，未新增源码PR；夜间既有Actions运行43965649567成功属于旧采集任务，不冒称本复盘新CI。复盘验证、前向状态、报告及冻结链另行提交数据仓库；环境未发布。"]
report='\n'.join(lines)+'\n';(R/'复盘报告.md').write_text(report)
with (R/'复盘展示.csv').open('x',encoding='utf-8-sig',newline='') as h:
 w=csv.writer(h);w.writerow(['比赛','原比分','90分钟赛果','比分命中','原胜平负','方向命中','盘口线','方向','结算','原冻结ID'])
 for x in m['comprehensive']['rows']:w.writerow([x['name'],x['primary'],x['actual'],x['primary_hit'],x['wdl'],x['wdl_hit'],x['total_line'],x['total_direction'],cn[x['total_settlement']],x['freeze_id']])
verification=dict(status='PASS',verified_at=now(),original_freezes_verified=len(oldrefs),protected_assets_verified=len(lock['protected_assets']),results=10,independent_scores_agree=10,goal_events=29,settlement_implementations=2,quarter_line_independent_check=True,original_population=10,primary_abstentions_preserved=3,total_abstentions_preserved=3,original_forward_population=18,original_forward_settled=10,original_forward_pending=8,metrics_sha256=sha(R/'metrics.json'),process_audit_sha256=sha(R/'process-audit.json'),source_worktree_clean=True,source_files_changed=False,parameters_changed=False,environment_published=False)
write('verification.json',verification)
receipts=[]
for item in lock['fixtures']:
 mid=item['fixture']['match_id'];f=dict(item['fixture'],cutoff_at=now());row=next(x for x in m['comprehensive']['rows'] if x['match_id']==mid)
 receipts.append(save(dict(result=results[mid],process=process[mid],original_accounts=item,comprehensive_review=row,candidate_first_review=next(x for x in m['candidate_models']['first']['paired_rows'] if x['match_id']==mid),candidate_published_revision=next(x for x in m['candidate_models']['published_revision']['paired_rows'] if x['match_id']==mid),metrics_sha256=sha(R/'metrics.json'),decision_sha256=sha(R/'review-decision.json'),prematch_records_modified=False),f,stage='review',track='comprehensive'))
shell=dict(match_id='review-nations:20261117-0818',kickoff_at=min(x['kickoff_at'] for x in results.values()),cutoff_at=now())
top=save(dict(top3=m['top3'],ranking_changed=False),shell,stage='review',track='top3-selection')
rr=save(dict(report_markdown=report,metrics=m,decision=decision,scope_lock=read(R/'scope-lock-receipt.json'),match_review_receipts=receipts,top3_review_receipt=top,verification=verification,source_commit=lock['source_commit'],forward_state_receipt=state,environment_published=False),dict(shell,cutoff_at=now()),stage='review',track='analysis-report')
allrefs=[read(R/'scope-lock-receipt.json')]+receipts+[top,rr]
for ref in allrefs+list(oldrefs.values()):assert verify(read(ref['path']))['record_sha256']==ref['sha256']
write('delivery.json',dict(report_receipt=rr,match_review_receipts=receipts,top3_review_receipt=top,all_receipts=allrefs,review_population=10,review_settled=10,review_pending=0,manual_score_n=7,manual_primary_hits=0,manual_wdl_hits=8,manual_total_settlements=s['total_settlements'],cumulative_original_candidate_n=44,source_commit=lock['source_commit'],active_registry_sha256=lock['active_registry_sha256'],active_model_changed=False,prematch_records_changed=False,forward_state_receipt=state,environment_published=False))
print(json.dumps(dict(report=rr,new_receipts=len(allrefs),original_freezes_unchanged=len(oldrefs),verification=verification),ensure_ascii=False))
