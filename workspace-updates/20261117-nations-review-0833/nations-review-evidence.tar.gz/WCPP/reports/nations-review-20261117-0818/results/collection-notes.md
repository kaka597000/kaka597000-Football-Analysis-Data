# 欧国联复盘采集记录

范围取自 `review-scope-lock.json` 锁定的10场。核验分数采用90分钟常规时间；ESPN summary两段linescores相加与FT比分及逐球keyEvents核对。

5场（401861179、401861185–188）在2026-11-17 08:23–08:24北京时间逐场请求ESPN summary，间隔约3秒，均HTTP 200，TLS验证开启。5场（401861180–184）复用夜间仓库缓存原文，沿用原 `observed_at` 与SHA256。缓存原始采集材料没有保存HTTP状态或请求起止时间，故不补造；详见process-summary.json的capture.cached_metadata_limitation。

另用赛前market-current/odds.json中的provider_match_id，一次TheOdds scores请求交叉核对10场，均匹配ESPN 90分钟比分；逐场ID、状态与对照见 `odds-crosscheck.json`。比赛过程字段、缺失值、首发名单和具体采集证据见 `process-summary.json` 及 `raw/`。真实xG仅按原始字段保留；没有xG时为null，射正不替代xG。


赛前提出的Samorodov、Kucys、Vanja Dragojevic、Andrija Zivkovic身份在对应ESPN名单中均未出现；这只表示本次赛事payload未记录其名单/出场，不据此断言停赛。具体结果在process-summary.json。

重点过程证据：德国5-0荷兰（半场1-0，射门18-9、射正10-1，进球41'、60'、65'、71'、77'）；瑞士4-0苏格兰（半场1-0，射门18-13、射正8-1，22' Lewis Ferguson乌龙使瑞士受益，后续47'、51'、89'）；北马其顿0-3斯洛文尼亚（半场0-1，射门9-8、射正4-6，29'、66'、90'+1'）。只有爱沙尼亚—保加利亚记录红牌：爱沙尼亚Karel Mustmaa 90'+1'第二黄；其余场无keyEvents红牌记录。真实xG字段本批均缺失（null），不可用射正替代。
