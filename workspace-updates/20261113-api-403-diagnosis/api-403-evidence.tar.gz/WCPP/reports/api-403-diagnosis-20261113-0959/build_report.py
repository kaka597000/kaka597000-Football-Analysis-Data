"""Build the final report from saved evidence, without network calls."""
import json
import subprocess
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

R = Path(__file__).resolve().parent
S = Path('/workspace/Football-Analysis')
def read(p):
    return json.loads(p.read_text())
def git(*args):
    return subprocess.check_output(['git','-C',str(S),*args],text=True).strip()

delivery = read(R/'source-delivery.json')
ci = read(R/'ci-receipt.json')
assert delivery['state'] == 'MERGED' and ci['conclusion'] == 'success'
head = git('rev-parse','HEAD')
assert head == delivery['mergeCommit']['oid']
assert git('rev-parse',head+'^{tree}') == git('rev-parse',ci['headSha']+'^{tree}')
summary = {
    'schema':'WCPP-API-403-DIAGNOSIS-1',
    'generated_at_beijing':datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),
    'source_commit':head,'tested_source_commit':ci['headSha'],
    'same_git_tree_verified':True,'rollback_source_commit':'ddfbc43197df8944072c70135e2a2831ae1a3ef5',
    'source_pr':delivery['url'],'source_pr_state':delivery['state'],'source_ci':ci['url'],
    'physical_api_requests_this_task':4,'public_research_requests_this_task':21,
    'api_football':{'status':'BLOCKED_CLOUDFLARE_HTML','current_key_api_probes':1,
                    'other_controls_executed':False,'authentication':'UNVERIFIED','plan':'UNVERIFIED',
                    'exact_rule_known':False,'response_evidence':'apifootball/probe-results-api-host.json'},
    'therundown':{'status':'BLOCKED_CLOUDFLARE_HTML','protected_api_probes':3,
                  'all_controls_returned_403_html':True,'authentication':'UNVERIFIED','plan':'UNVERIFIED',
                  'exact_rule_known':False,'response_evidence':'therundown/probe-results.json'},
    'implementation':'COMPLETED_AND_MERGED','workspace_code':'UPDATED',
    'environment_published':False,'scheduled_collector_deployment_changed':False,
    'actual_provider_data_acceptance':'BLOCKED','service_access_restored':False,
    'historical_prediction_effect':'NOT_APPLICABLE','forward_prediction_effect':'NOT_APPLICABLE',
    'active_model_or_database_changed':False,'service_support_request_sent':False,
    'support_draft':'support-request-unsent.md',
    'validation':read(R/'validation.json'),'ci_test_summary':read(R/'ci-test-summary.json'),
}
(R/'audit-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
text = (S/'docs/api-access-diagnosis-20261113.md').read_text()
text += f'''

## 本次交付与验收

- 源码 PR：{delivery['url']}，已合并；main commit：`{head}`。
- 实际本地严格测试与 PR CI 的源 commit：`{ci['headSha']}`；已校验与合并版本 Git tree 一致。
- 本地严格集成：24 组、869 次执行，零跳过、零失败；静态检查 495 文件、0 项发现，diff 检查通过。
- PR CI：{ci['url']}，三项成功。公开 CI 主测试报告 839 次执行、16 个跳过标记（含整类跳过），Ubuntu/Windows portable 各 11 次；运行资产相关检查在本地已真实执行，未将公开 CI 跳过算作通过。
- 活动模型注册表 SHA-256：`923e34fc44cda33fe965498a24a2435abb37a01a80c539108d8ec20d490bf013`，前后不变。
- 回滚基点：`ddfbc43197df8944072c70135e2a2831ae1a3ef5`。共享 main 如需撤回，按 PR 追加 revert 并重跑检查，不重写历史；代码回滚不代表恢复 API 访问。

| 交付维度 | 状态 |
|---|---|
| 代码完成 | 已完成并合并 |
| 工作区代码落地 | 已同步合并版本 |
| 环境发布 / 定时任务部署 | 未发布、未修改定时任务 |
| 真实数据验收 | 两家仍 403，未取得赛事或盘口数据 |
| 历史效果 / 未来效果 | 本次为接入诊断，不做命中率或模型增益声明 |

本轮实际发出 4 次 API 请求、21 次公开资料请求；没有新增浏览器访问。上轮独立浏览器测试的阻断不伪装成本轮实测。

执行限制已保留：API-Football FAQ 返回阻断后，同一串行脚本中已排队的 Cloudflare 官方说明页请求仍完成，随后停止；追加 API 主机探针独立记录。无密钥和固定无效值的 API-Football 控制未执行，不虚构对照结果。响应正文未保存，归档中的原始响应哈希不能独立重算；可校验保存的元数据、报告和冻结记录完整性。

本报告是独立技术审计，冻结记录不属于赛前预测，不计入比分、胜平负或大小球成绩。冻结回执与长期档案清单分别见 delivery.json 和 manifest.json。
'''
(R/'report.md').write_text(text)
print(json.dumps({'source_commit':head,'tested_source_commit':ci['headSha'],'same_tree':True}))
