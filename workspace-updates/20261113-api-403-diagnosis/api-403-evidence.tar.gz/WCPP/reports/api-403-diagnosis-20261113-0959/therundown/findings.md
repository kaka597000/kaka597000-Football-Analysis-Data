# TheRundown 403专项结果

日期：2026-11-13。官方 API host 按最新公开 OpenAPI 与认证文档确认为 `therundown.io`。本专项没有改源码、数据库或 Git。

## 已核验契约

- 官方认证指南建议服务端将 key 放在 `X-TheRundown-Key`；仅 `/api/v2/sports` 与 `/api/v2/affiliates` 被列为免鉴权端点。`/api/v2/markets` 是受保护的市场目录，官方 curl/Python 示例直接使用此 endpoint。
- OpenAPI 生产服务器是 `https://therundown.io`。V2 市场目录使用 market-based data structure；V1 使用 legacy line-based schema。认证文档说明 header 对新旧集成均可用，query-key 仅为现有集成保留兼容。因此没有找到能解释现有 403 的 v1→v2 请求契约修正；已记录的 v1 schedule 与 header 组合也未被文档否定。
- 官方错误文档把缺少/无效 key 描述为 JSON 401，把套餐/账户限制描述为 JSON 403；此次收到的是 Cloudflare HTML，说明本探测观察到边缘拦截页面，而不是已识别的 API JSON 鉴权错误。HTML 403 本身不说明确切拦截原因，也不能证明 key 错误。

## 有界探测

端点：`https://therundown.io/api/v2/markets`。三种情况各请求一次，严格串行，间隔至少5秒，TLS验证和默认代理保留，禁用重定向。结果完整安全字段见 [probe-results.json](probe-results.json)。

- 当前绑定：HTTP 403，`text/html`，标题 `Attention Required! | Cloudflare`，blocked 标记为真，CF-Ray `a59a32243e0e1c16-DFW`；无 Retry-After、无 JSON 错误或用量字段。
- 无 key：HTTP 403，相同HTML标题与大小，CF-Ray `a59a32455f661c16-DFW`。
- 固定明显无效诊断值：HTTP 403，相同HTML标题与大小，CF-Ray `a59a326689f81c16-DFW`。

三种响应原始字节均未保留，仅保存每个响应的 SHA-256、长度、安全标记和 Ray ID。三组一致落在 HTML 层，无法据此判断应用层对当前 key 的接受与否。没有继续请求赛事、体育项目或其他 API 路径。

## 公开方案检索

官方 docs 与 GitHub SDK / examples 已检索；精确 URL、原文要点及公开请求日志见 [sources.json](sources.json) 和 [search-log.json](search-log.json)。官方 Python SDK 的当前 README 确认相同 base URL 和 header，并声明不自动重试、拒绝重定向。GitHub 对官方 Python SDK 的 403 issue 搜索无结果；没有发现匹配且验证过的公开修复。

通用“绕过 Cloudflare”做法（伪装客户端、使用第三方代理或 CORS 转发、把 key 转发到其他域）既不属于官方契约修正，也有凭据泄露风险，未执行。也没有把通用 Cloudflare 页面提示解释为具体规则命中。

## 建议交给 root 的下一步

停止本环境对 TheRundown 的请求。本轮没有可安全执行的请求差异修正。若要进一步定位，保留上述三个 CF-Ray 与 UTC 时间，走项目已授权的服务商支持流程；不要附带 key、完整响应HTML、IP或账户资料。只有服务方确认是可修正的官方契约差异后，再由 root 指定一个具体端点/参数做单次验证。
