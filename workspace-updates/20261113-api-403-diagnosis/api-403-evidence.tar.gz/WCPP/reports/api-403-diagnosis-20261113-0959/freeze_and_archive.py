"""Append-freeze the audit and archive sanitized evidence; no API requests."""
import hashlib
import json
import shutil
import subprocess
import tarfile
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from research.analysis_freeze import save, verify

R = Path(__file__).resolve().parent
S = Path('/workspace/Football-Analysis')
D = Path('/workspace/kaka597000-Football-Analysis-Data/workspace-updates/20261113-api-403-diagnosis')

def read(p):
    return json.loads(p.read_text())

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def write(p, value):
    p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')

if D.exists() or (R/'delivery.json').exists():
    raise SystemExit('Existing delivery; inspect it rather than overwrite or refreeze.')
validation = read(R/'validation.json')
ci = read(R/'ci-receipt.json')
assert ci['conclusion'] == 'success'
status = read(R/'verification.json')
assert status['status'] == 'PASS_WITH_LIMITATIONS'
for name, expected in status['evidence_sha256'].items():
    assert sha(R/name) == expected, name
summary = read(R/'audit-summary.json')
payload = {'report_markdown':(R/'report.md').read_text(),'summary':summary,
           'verification':status,'validation':validation,'ci_receipt':ci,
           'decision':'BOTH_PROVIDERS_REMAIN_BLOCKED; NO_MODEL_OR_DATABASE_CHANGE',
           'model_promotion':False,'service_access_restored':False,
           'service_support_request_sent':False}
now = datetime.now(ZoneInfo('Asia/Shanghai')).isoformat()
fixture = {'match_id':'api-403-diagnosis:20261113-0959','cohort':'data-source-audit',
           'kickoff_at':'2026-11-13T09:59:00+08:00','cutoff_at':now}
receipt = save(payload,fixture,stage='review',track='api-access-diagnosis',
               idempotency_key='20261113-api-403-diagnosis-final-1')
assert verify(read(Path(receipt['path'])))['record_sha256'] == receipt['sha256']
delivery = {'receipt':receipt,'report_sha256':sha(R/'report.md'),
            'source_commit':summary['source_commit'],'source_pr':summary['source_pr'],
            'environment_published':False,'service_access_restored':False,
            'model_or_database_modified':False}
write(R/'delivery.json',delivery)
D.mkdir(parents=True)
files = sorted(p for p in R.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
files.append(Path(receipt['path']))
archive = D/'api-403-evidence.tar.gz'
members = []
with tarfile.open(archive,'w:gz') as tf:
    for p in files:
        if p.is_relative_to(R):
            arc = 'WCPP/reports/'+R.name+'/'+str(p.relative_to(R))
        else:
            arc = 'WCPP/forecasts/issued-analyses/'+str(p).split('/forecasts/issued-analyses/')[1]
        tf.add(p,arcname=arc,recursive=False)
        members.append({'path':arc,'bytes':p.stat().st_size,'sha256':sha(p)})
with tarfile.open(archive) as tf:
    for m in members:
        assert hashlib.sha256(tf.extractfile(m['path']).read()).hexdigest() == m['sha256']
for name in ['report.md','audit-summary.json','delivery.json','validation.json','verification.json',
             'ci-receipt.json','source-delivery.json','support-request-unsent.md']:
    shutil.copy2(R/name,D/name)
write(D/'manifest.json',{'schema':'WCPP-API-403-ARCHIVE-1','source_commit':summary['source_commit'],
      'tested_source_commit':summary['tested_source_commit'],
      'data_parent_commit':subprocess.check_output(['git','-C',str(D.parents[1]),'rev-parse','HEAD'],text=True).strip(),
      'archive':archive.name,'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,
      'members':members,'freeze_receipt':receipt,'recover_without_expiring_actions_links':True})
(D/'README.md').write_text('# API 403 排查证据\n\n'
    '两家 API 仍受阻，修正内容和限制见 [report.md](report.md)。'
    '支持材料尚未发送；活动模型与比赛数据库未变，环境未发布。\n\n'
    '完整证据在 api-403-evidence.tar.gz；manifest.json 记录每个成员的 SHA-256。'
    '解包到隔离目录并校验哈希后查阅，不需运行任何联网脚本。冻结记录为独立技术审计，'
    '不是赛前预测，不纳入比分、胜平负或大小球命中率。\n')
print(json.dumps({'receipt':receipt,'members_verified':len(members),
                  'archive_bytes':archive.stat().st_size},ensure_ascii=False))
