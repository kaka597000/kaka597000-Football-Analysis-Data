# API-Football 403 专项调查

**调查时间：** 2026-11-13 10:00–10:02 北京时间（02:00–02:02 UTC）  
**结论状态：** 因公开官方 FAQ 主机返回 Cloudflare challenge，按停止条件结束；本轮没有进行 API `/status` 探针。

## 实际结论

- 当前环境观察为 revision 4、网络策略 unrestricted/enforced、`apifootball` 绑定 ready，且允许目的主机 `v3.football.api-sports.io`。这仅是环境配置观察，不能保证远端服务可达。
- API-Sports 官方 Football v3 OpenAPI 文档（v3.9.3）确认 API host 为 `v3.football.api-sports.io`，鉴权头为 `x-apisports-key`，只使用 GET 且避免添加文档未列出的请求头。文档提供的是客户端契约；没有发现足以解释当前 API-host 403 的差异，也没有官方资料指出应改变项目当前请求。
- `www.api-football.com/faq` 本次 HTTP 403 返回 Cloudflare “Attention Required”/blocked 页面，并表示网站安全服务触发了阻断。完整 HTML 未保存，访客 IP 未保留。该页面挑战只证明 FAQ 网页请求被拦，不能推断 API host 的封禁规则、密钥有效性、订阅权限或 API JSON 错误处理情况。
- Cloudflare 官方有专门的 HTTP 403 文档（来源见 `sources.json`），但本次公开证据未识别导致 FAQ 页面被挡的具体规则。
- GitHub 公开检索没有找到可验证的 API-Football Cloudflare 403 修复。唯一相关 issue 报告 Free 计划日期窗口返回 JSON `errors.plan`，属于计划范围限制的第三方轶事，与 Cloudflare 403 无关。

## 请求与探针

本次公开资料检索/读取共发生 9 个网络请求（GitHub 请求及官方文档，明细见 `search-log.json`），低于 12 次上限。需要如实说明：FAQ challenge 与 Cloudflare 说明页请求放在同一个串行脚本中，FAQ 返回 challenge 后，已经排队的 Cloudflare 文档请求仍然完成；该脚本没有按响应自适应中止。此后没有再发起请求。原计划的 `/status` current-env、不带 key、固定诊断字符串三种探针全部**未执行**；没有观察到 API `/status` HTTP 状态、JSON 错误或 HTML 响应，也未检验是否进入 API JSON 错误处理。

## 后续说明

本轮没有可先行建议并复测的合法客户端修正。为遵守挑战停止条件，本次不在同一主机或 API host 上继续请求。此结果不改变旧报告，仅作为本次独立公开来源调查记录。

来源逐条 URL、引用、适用条件和限制见 `sources.json`；检索过程见 `search-log.json`；探针状态见 `probe-results.json`。
