# API-Football API host `/status` 对照补充

**时间：** 2026-11-13 10:08:05 北京时间（02:08:05 UTC）  
**端点：** `https://v3.football.api-sports.io/status`  
**结果文件：** `probe-results-api-host.json`

## 已执行请求

按官方 Football v3 OpenAPI 契约发送一次 GET，使用当前环境 `apifootball` 绑定作为 `x-apisports-key` header。实现通过 Python 标准库 `urllib.request.Request(..., method="GET")`，不设置自定义 User-Agent，不跟随重定向，使用默认 TLS 证书校验并继承环境代理。密钥内容未打印或落盘。

- HTTP 403，`text/html; charset=UTF-8`
- 页面 title：`Attention Required! | Cloudflare`
- 安全标记：`cloudflare`、`attention required`、`sorry, you have been blocked`
- CF-Ray：`a59a3a02986e2cc8-DFW`
- 响应长度：4547 字节；SHA-256：`957cf0af374cbbb3b9f1c6bd7e151bc77e2198f91229d60db2ac843e1296a884`
- 格式判断：HTML；没有进入 API JSON 错误处理，因此不能据此判断 API 返回的认证/权限错误。

检查器同时命中了预设的交互式挑战检测条件，因此按补充任务停止。原始 HTML 未保存，`probe-results-api-host.json` 仅保留标准标记、title、CF-Ray、哈希与安全分类。

## 未执行的控制

无 API key 与固定 `TEST_DIAGNOSTIC_NOT_A_KEY` 的两次控制均未运行。它们在交互式挑战检测命中后按规则终止。没有自动重试、额外 endpoint、FAQ 请求或其他公开网页请求。

## 适用结论

本次实际观测仅说明在该时间、该环境及该官方 API host 上，带当前绑定的 `/status` GET 收到 Cloudflare HTML 403。由于缺失两个对照，不能比较 Cloudflare 拦截与 API JSON 错误的区别，也不能确认密钥是否有效、账号权限或具体 Cloudflare 规则；不能把该响应归因为 key 错误。
