"""Verify saved diagnostic metadata only; performs no network calls."""
import hashlib
import json
import os
import re
import subprocess
from datetime import datetime
from pathlib import Path

R = Path(__file__).resolve().parent
S = Path('/workspace/Football-Analysis')

def read(path):
    return json.loads(path.read_text())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    a = read(R/'apifootball/probe-results-api-host.json')['results']
    t = read(R/'therundown/probe-results.json')['results']
    assert len(a) == 1 and len(t) == 3
    assert a[0]['http_status'] == 403 and a[0]['format'] == 'html'
    assert a[0]['redirects_followed'] is False
    assert a[0]['tls_verification'] == 'enabled_default_ca'
    assert {x['case'] for x in t} == {'current_key', 'no_key', 'fixed_invalid_key'}
    for x in t:
        assert x['status'] == 403 and x['response_format'] == 'html'
        assert x['safe_html_markers']['blocked_marker']
        assert datetime.fromisoformat(x['requested_at_beijing']) == datetime.fromisoformat(x['requested_at_utc'])
        assert re.fullmatch(r'[0-9a-f]{64}', x['body_sha256'])
    starts = [datetime.fromisoformat(x['requested_at_utc']) for x in t]
    assert all((y-x).total_seconds() >= 5 for x,y in zip(starts, starts[1:]))
    assert datetime.fromisoformat(a[0]['started_beijing']) == datetime.fromisoformat(a[0]['started_utc'])
    assert re.fullmatch(r'[0-9a-f]{64}', a[0]['sha256'])
    state = read(R/'environment-observation.json')
    assert state['observations_current'] and state['spec_revision'] == state['observed_spec_revision'] == '4'
    bindings = {x['name']:x for x in state['credentials']}
    for name, host in [('apifootball','v3.football.api-sports.io'),('therundown','therundown.io')]:
        assert bindings[name]['state'] == 'ready'
        assert host in bindings[name]['target']['allowed_domains']
    registry = read(S/'runtime/data_sources/registry.json')['providers']
    assert registry['api-football']['historical_observations'][0]['last_http_status'] == 200
    for p in ['api-football','therundown']:
        assert registry[p]['last_http_status'] == 403
        assert not registry[p]['account_authentication_verified']
        assert not registry[p]['exact_security_rule_known']
    validation = read(R/'validation.json')
    assert validation['test_groups'] == 24 and validation['test_executions'] == 869
    assert validation['skipped'] == 0 and validation['failed_suites_none']
    assert sha(Path('/workspace/WCPP/runtime/active-model.json')) == validation['active_registry_sha256']
    import sys
    sys.path.insert(0, str(S/'runtime'))
    from data_sources.clients import PROVIDERS, QUARANTINED_CREDENTIAL_NAMES
    names = set(QUARANTINED_CREDENTIAL_NAMES)
    for spec in PROVIDERS.values():
        names.update(spec.get('aliases', []))
        if 'env' in spec:
            names.add(spec['env'])
    names.update(['infer_yapan_zhishu','yapan_infersports'])
    secrets = [os.environ[n].encode() for n in names if os.environ.get(n)]
    files = sorted(p for p in R.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
    for p in files:
        content = p.read_bytes()
        assert not any(s in content for s in secrets), 'configured credential detected; value suppressed'
        if p.suffix == '.json':
            read(p)
    evidence = {str(p.relative_to(R)):sha(p) for p in files if p.name != 'verification.json'}
    result = {'status':'PASS_WITH_LIMITATIONS','api_requests_verified':4,
              'api_football_controls_not_executed':['no_key','fixed_invalid_key'],
              'time_pairs_verified':4,'therundown_minimum_interval_verified':True,
              'configured_credential_matches':0,'model_registry_unchanged':True,
              'raw_error_bodies_saved':False,'raw_error_hashes_not_independently_recomputable':True,
              'source_commit':subprocess.check_output(['git','-C',str(S),'rev-parse','HEAD'],text=True).strip(),
              'known_execution_deviations':['One already-queued Cloudflare documentation GET completed after the FAQ block; retained in search log.'],
              'limitations':['No provider security rule identified','No current credential acceptance confirmed for either provider',
                             'API-Football challenge detection was conservative, not a manual CAPTCHA confirmation',
                             'Official docs and SDK alignment do not prove service access'],
              'evidence_sha256':evidence}
    (R/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k != 'evidence_sha256'},ensure_ascii=False))

if __name__ == '__main__':
    main()
