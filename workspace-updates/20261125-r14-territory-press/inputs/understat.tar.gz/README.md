# R14 Understat 补齐版：原始历史数据与来源审计

本目录独立于 `r14-understat-intake`，不改写初版。数据来自项目已归档的 Understat 官方 `getLeagueData` gzip 原响应；所有已取得的原件、检查响应和脚本均保存在本目录。

## 实测结论与覆盖

- 普通官方 URL `https://understat.com/getLeagueData/EPL/2026` 于 2026-11-25 08:41:09 UTC 返回 HTTP 200，但 `Content-Type: text/html`，正文为错误 HTML（非 JSON，无 `teams`/`dates`）。这不是可用 JSON 响应；只探测一次后停止，没有换代理/主机或绕过拒绝。
- R6/项目原始 `getLeagueData` 当前可用范围是五联赛 2020/21–2026/27，共 35 份。历史 2014/15–2019/20 的原始 JSON 在所检项目归档中未找到，也未请求不可用端点。
- R6 2026/27 五联赛在 2026-10-15 的两份已归档 gzip：第一份由逐场源记录保存采集时钟，第二份在同日稍晚的项目原始响应包中；五份第二版均与第一版逐字节相同，压缩 SHA 和解压 JSON SHA 一致。
- 项目于 2026-10-16 对官方 EPL 与 La_liga 2026 JSON 端点的既有直接复核是 HTTP 404，36 字节错误正文和 SHA 已保留。2026-11-25 EPL/2026 的响应虽然 HTTP 200，内容仍是 HTML，记录于 `reports/access-attempts.jsonl`。
- 结构化表共 11,031 场已完赛比赛，截止筛选按源日期不晚于 2026-11-24；但原始快照只到 2026-10-15，因此 10 月 15 日之后的新比赛不在覆盖内。不可把报告日期截止误读为数据已刷新至该日。
- `competition` 使用项目标准代码：英超 `eng.1`、西甲 `esp.1`、德甲 `ger.1`、意甲 `ita.1`、法甲 `fra.1`。`understat_competition` 单独保留 Understat 原键 `EPL`、`La_liga`、`Bundesliga`、`Serie_A`、`Ligue_1`；源 URL 和 raw 目录也保留请求时的 Understat route。
- 每场含来源赛事 ID、主客队 ID/名称、日期原串、比分、双方 `deep/deep_allowed`、`ppda/ppda_allowed` 的 `att/def`、`xG/xGA`、解压 JSON 原文 SHA、gzip SHA 和来源 URL。双方原始 history 子对象留在每行 `source_history_sides`，镜像对照及冲突留在 `mirror_checks`/`source_conflicts`。射门数不在源 `getLeagueData` 中，故不生成射门计数。
- 日期原串不带时区标记；采集时钟来自项目响应记录，不是 Understat 发布时间。数据只能称为归档赛后事实，不能据此证明历史时点的 first-known/赛前发布状态。

## 文件

```text
README.md
extract.py                              # 标准库离线提取、哈希、身份与镜像核验
raw/<Understat原键>/<赛季年>/
  getLeagueData.json.gz                 # R6 官方 JSON 原响应（原 gzip 字节）
  capture.json                          # 原始键、标准键、请求 URL、采集时钟及 SHA
raw/rechecks/20261015-v2/               # 同日第二份五联赛 gzip 原响应副本
raw/rechecks/20261017-endpoint-errors/  # 项目既有 HTTP 404 正文
raw/rechecks/20261125-endpoint-probe.*  # 本轮官方 URL 响应正文与 HTTP 头
sources.jsonl                            # 每个联赛/赛季的原始响应清单
events.jsonl                            # 每场一行，competition 为 eng.1 等标准键
reports/coverage.json                    # 字段覆盖、赛季覆盖与镜像核验
reports/20261015-second-capture.json     # 五联赛第二版时间和两种 SHA 对照
reports/access-attempts.jsonl            # 失败/非 JSON 官方端点响应审计
reports/archive-scope.json               # 未找到的年代、检索范围及停止扩展原因
```

## 离线复现

在本目录运行 `python3 extract.py`。脚本仅读取 `raw/<联赛>/<赛季年>/getLeagueData.json.gz` 及同目录 `capture.json`，不访问网络；输出 `events.jsonl`、`sources.jsonl` 和 `reports/coverage.json`。它核验压缩/解压 SHA，并按 source match ID、日期、主客 ID、home/away history 方向配对；未开赛、缺失/歧义配对和超截止日期的行不进入事件表。源冲突会保留双方原值并逐项计数。
