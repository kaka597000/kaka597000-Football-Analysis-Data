#!/usr/bin/env python3
"""Offline Understat getLeagueData archive extractor and consistency audit.

Run from this directory: python3 extract.py
Inputs are the archived gzipped getLeagueData JSON responses in raw/.
Only Python's standard library is required.
"""
from __future__ import annotations
import gzip, hashlib, json
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RAW = ROOT / "raw"
EVENTS = ROOT / "events.jsonl"
SOURCES = ROOT / "sources.jsonl"
REPORT = ROOT / "reports" / "coverage.json"
CUTOFF = "2026-11-24"
UNDERSTAT_KEYS = ["EPL", "La_liga", "Bundesliga", "Serie_A", "Ligue_1"]
COMPETITION_CODES = {"EPL": "eng.1", "La_liga": "esp.1", "Bundesliga": "ger.1", "Serie_A": "ita.1", "Ligue_1": "fra.1"}
COMPETITION_NAMES = {"EPL": "英超", "La_liga": "西甲", "Bundesliga": "德甲", "Serie_A": "意甲", "Ligue_1": "法甲"}
UNDERSTAT_ROUTES = {"EPL": "EPL", "La_liga": "La%20liga", "Bundesliga": "Bundesliga", "Serie_A": "Serie%20A", "Ligue_1": "Ligue%201"}


def sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def number(v):
    if v is None or v == "":
        return None
    try:
        n = float(v)
        return int(n) if n.is_integer() else n
    except (TypeError, ValueError):
        return None


def parse_time(s):
    return datetime.strptime(s, "%Y-%m-%d %H:%M:%S")


def main():
    event_rows = []
    source_rows = []
    summary = {"cutoff_utc_date": CUTOFF, "cutoff_semantics": "fixture raw datetime date <= cutoff; not a claim of source-timezone conversion", "competitions": {}, "totals": {}, "checks": {}}
    all_checks = Counter()
    conflicts = []
    for league in UNDERSTAT_KEYS:
        cn = COMPETITION_NAMES[league]
        competition = COMPETITION_CODES[league]
        csum = summary["competitions"][competition] = {"name_zh": cn, "understat_competition": league, "seasons": {}, "events": 0, "field_nonnull": Counter()}
        for year in range(2020, 2027):
            folder = RAW / league / str(year)
            gzpath = folder / "getLeagueData.json.gz"
            clockpath = folder / "capture.json"
            if not gzpath.exists():
                continue
            gzbytes = gzpath.read_bytes()
            payload = gzip.decompress(gzbytes)
            payload_hash = sha(payload)
            compressed_hash = sha(gzbytes)
            capture = json.loads(clockpath.read_text()) if clockpath.exists() else {}
            if capture.get("source_sha256_uncompressed") and capture["source_sha256_uncompressed"] != payload_hash:
                raise ValueError(f"decompressed source SHA mismatch: {gzpath}")
            if capture.get("source_sha256_gzip") and capture["source_sha256_gzip"] != compressed_hash:
                raise ValueError(f"gzip source SHA mismatch: {gzpath}")
            data = json.loads(payload)
            season_rows = []
            # Pair each fixture record with the two team-perspective history records.
            histories = {}
            for tid, team in data.get("teams", {}).items():
                for h in team.get("history", []):
                    key = (str(tid), h.get("date"), h.get("h_a"))
                    histories.setdefault(key, []).append(h)
            for match in data.get("dates", []):
                if not match.get("isResult"):
                    all_checks["unplayed_excluded"] += 1
                    continue
                dt = match.get("datetime")
                if not dt or parse_time(dt).date().isoformat() > CUTOFF:
                    all_checks["after_cutoff_excluded"] += 1
                    continue
                h = match.get("h") or {}; a = match.get("a") or {}
                hid, aid = str(h.get("id", "")), str(a.get("id", ""))
                ht = histories.get((hid, dt, "h"), [])
                at = histories.get((aid, dt, "a"), [])
                if len(ht) != 1 or len(at) != 1:
                    all_checks["history_pair_unmatched_or_ambiguous"] += 1
                    continue
                hh, ah = ht[0], at[0]
                goals = match.get("goals") or {}
                xg = match.get("xG") or {}
                values = {
                    "home_deep": number(hh.get("deep")),
                    "away_deep": number(ah.get("deep")),
                    "home_deep_allowed": number(hh.get("deep_allowed")),
                    "away_deep_allowed": number(ah.get("deep_allowed")),
                    "home_ppda_att": number((hh.get("ppda") or {}).get("att")),
                    "home_ppda_def": number((hh.get("ppda") or {}).get("def")),
                    "away_ppda_att": number((ah.get("ppda") or {}).get("att")),
                    "away_ppda_def": number((ah.get("ppda") or {}).get("def")),
                    "home_ppda_allowed_att": number((hh.get("ppda_allowed") or {}).get("att")),
                    "home_ppda_allowed_def": number((hh.get("ppda_allowed") or {}).get("def")),
                    "away_ppda_allowed_att": number((ah.get("ppda_allowed") or {}).get("att")),
                    "away_ppda_allowed_def": number((ah.get("ppda_allowed") or {}).get("def")),
                    "home_xg": number(hh.get("xG")), "away_xg": number(ah.get("xG")),
                    "home_xga": number(hh.get("xGA")), "away_xga": number(ah.get("xGA")),
                    "home_shots": None, "away_shots": None,
                }
                pairs = {
                    "home_deep_vs_away_deep_allowed": (hh.get("deep"), ah.get("deep_allowed")),
                    "away_deep_vs_home_deep_allowed": (ah.get("deep"), hh.get("deep_allowed")),
                    "home_ppda_vs_away_allowed": (hh.get("ppda"), ah.get("ppda_allowed")),
                    "away_ppda_vs_home_allowed": (ah.get("ppda"), hh.get("ppda_allowed")),
                    "home_xg_vs_fixture_xg": (hh.get("xG"), xg.get("h")),
                    "away_xg_vs_fixture_xg": (ah.get("xG"), xg.get("a")),
                    "home_score_vs_fixture": (hh.get("scored"), goals.get("h")),
                    "away_score_vs_fixture": (ah.get("scored"), goals.get("a")),
                    "home_score_vs_away_missed": (hh.get("scored"), ah.get("missed")),
                    "away_score_vs_home_missed": (ah.get("scored"), hh.get("missed")),
                }
                pair_check = {}
                for name, (left, right) in pairs.items():
                    if isinstance(left, dict) and isinstance(right, dict):
                        norm_left = {k: number(left.get(k)) for k in ("att", "def")}
                        norm_right = {k: number(right.get(k)) for k in ("att", "def")}
                        ok = norm_left == norm_right
                        pair_check[name] = {"left": norm_left, "right": norm_right, "equal": ok}
                    else:
                        nl, nr = number(left), number(right)
                        ok = nl == nr
                        pair_check[name] = {"left": nl, "right": nr, "equal": ok}
                    all_checks["mirror_checks"] += 1
                    if not ok:
                        all_checks["mirror_conflicts"] += 1
                event = {
                    "competition": competition, "understat_competition": league, "competition_name": cn,
                    "season": f"{year}/{str(year+1)[-2:]}",
                    "source_match_id": str(match.get("id")), "date": dt,
                    "home_id": hid, "away_id": aid,
                    "home": h.get("title"), "away": a.get("title"),
                    "home_goals": number(goals.get("h")), "away_goals": number(goals.get("a")),
                    **values,
                    "source_sha256": payload_hash,
                    "source_url": f"https://understat.com/getLeagueData/{UNDERSTAT_ROUTES[league]}/{year}",
                    "source_league_page_url": f"https://understat.com/league/{league}/{year}",
                    "source_file": str(gzpath.relative_to(ROOT)),
                    "source_gzip_sha256": compressed_hash,
                    "source_fetched_at": capture.get("source_fetched_at"),
                    "source_fetched_at_utc": capture.get("source_fetched_at_utc"),
                    "source_clock": {"provider_match_datetime_raw": dt, "timezone": "not stated in archived payload"},
                    "source_history_sides": {"home": hh, "away": ah},
                    "mirror_checks": pair_check,
                    "source_conflicts": [k for k, v in pair_check.items() if not v["equal"]],
                }
                event_rows.append(event); season_rows.append(event)
                for k, v in values.items():
                    if v is not None: csum["field_nonnull"][k] += 1
            csum["events"] += len(season_rows)
            csum["seasons"][str(year)] = {
                "season": f"{year}/{str(year+1)[-2:]}", "events": len(season_rows),
                "competition": competition, "understat_competition": league,
                "source_url": f"https://understat.com/getLeagueData/{UNDERSTAT_ROUTES[league]}/{year}",
                "source_league_page_url": f"https://understat.com/league/{league}/{year}",
                "source_payload_sha256": payload_hash, "source_gzip_sha256": compressed_hash,
                "source_fetched_at": capture.get("source_fetched_at"),
                "source_fetched_at_utc": capture.get("source_fetched_at_utc"),
                "source_match_ids": len({e['source_match_id'] for e in season_rows}),
            }
            source_rows.append({**csum["seasons"][str(year)], "source_file": str(gzpath.relative_to(ROOT)), "payload_bytes": len(payload), "gzip_bytes": len(gzbytes), "raw_top_level_fields": list(data.keys()), "data_scope": "original archived Understat getLeagueData JSON, not a reconstructed third-party table"})
    event_rows.sort(key=lambda r: (r["date"], r["competition"], r["source_match_id"]))
    with EVENTS.open("w", encoding="utf-8") as f:
        for row in event_rows: f.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")
    with SOURCES.open("w", encoding="utf-8") as f:
        for row in source_rows: f.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")
    for c in summary["competitions"].values():
        c["field_nonnull"] = dict(c["field_nonnull"])
    summary["totals"] = {"events": len(event_rows), "sources": len(source_rows), "conflicted_events": sum(bool(r["source_conflicts"]) for r in event_rows), "seasons": sorted({r["season"] for r in event_rows})}
    summary["checks"] = dict(all_checks)
    summary["checks"].setdefault("history_pair_unmatched_or_ambiguous", 0)
    summary["checks"]["events_matched_by_match_id_date_home_away"] = len(event_rows)
    summary["checks"]["unique_competition_match_ids"] = len({(r["competition"], r["source_match_id"]) for r in event_rows})
    summary["checks"]["duplicate_competition_match_ids"] = len(event_rows) - summary["checks"]["unique_competition_match_ids"]
    summary["checks"].setdefault("after_cutoff_excluded", 0)
    summary["checks"].setdefault("unplayed_excluded", 0)
    summary["checks"].setdefault("mirror_conflicts", 0)
    # Field-by-field coverage for the requested schema.
    required = ["competition", "source_match_id", "date", "home_id", "away_id", "home", "away", "home_goals", "away_goals", "home_deep", "away_deep", "home_ppda_att", "home_ppda_def", "away_ppda_att", "away_ppda_def", "home_xg", "away_xg", "source_sha256", "source_url"]
    summary["field_coverage"] = {field: {"present": sum(r.get(field) is not None for r in event_rows), "total": len(event_rows)} for field in required}
    for field in ("home_deep_allowed", "away_deep_allowed", "home_ppda_allowed_att", "home_ppda_allowed_def", "away_ppda_allowed_att", "away_ppda_allowed_def", "home_xga", "away_xga"):
        summary["field_coverage"][field] = {"present": sum(r.get(field) is not None for r in event_rows), "total": len(event_rows)}
    summary["field_coverage"]["home_shots"] = {"present": 0, "total": len(event_rows), "status": "FIELD_NOT_IN_ARCHIVED_GETLEAGUEDATA"}
    summary["field_coverage"]["away_shots"] = {"present": 0, "total": len(event_rows), "status": "FIELD_NOT_IN_ARCHIVED_GETLEAGUEDATA"}
    summary["checks"]["unique_competition_match_ids"] = len({(r["competition"], r["source_match_id"]) for r in event_rows})
    summary["checks"]["duplicate_competition_match_ids"] = len(event_rows) - summary["checks"]["unique_competition_match_ids"]
    summary["checks"]["events_matched_by_match_id_date_home_away"] = len(event_rows)
    summary["limitations"] = [
        "Available archive starts at Understat season year 2020 (2020/21); 2019/20 (year 2019) and 2014/15–2018/19 raw getLeagueData files were not present in the inspected R6/project archive.",
        "All included archived responses were captured 2026-10-15; this archive does not cover results added after that time, including late 2026/27 fixtures through 2026-11-24.",
        "Official getLeagueData/EPL/2026 probe on 2026-11-25 returned HTML (HTTP 200, text/html), not JSON; R6 project log records direct getLeagueData EPL and La_liga attempts as HTTP 404 on 2026-10-16; no access restriction was bypassed.",
        "No per-match shot count is present in these league-history fields; goals scored/conceded are present. Shot maps are not fabricated.",
        "Provider fixture datetime strings carry no timezone marker; raw clock strings are preserved without asserting UTC conversion."
    ]
    REPORT.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"events": len(event_rows), "sources": len(source_rows), "conflicted_events": summary["totals"]["conflicted_events"], "report": str(REPORT)}, ensure_ascii=False))

if __name__ == "__main__": main()
