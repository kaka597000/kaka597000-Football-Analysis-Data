"""Complete Brazil inference after correcting fixture evidence field name; preserve failed input."""
import json,sys,subprocess
from pathlib import Path
from datetime import datetime,timezone
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from research.team_goal_analysis import summarize_prediction
from research.score_distribution_audit import audit_prediction
R=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())
def write(p,x):
 with Path(p).open('x') as h:json.dump(x,h,ensure_ascii=False,indent=2,allow_nan=False)
fs=read(R/'prepared-fixtures.json');index=[]
for f in fs:
 if f['competition']!='bra.1':continue
 f['cutoff_at']=datetime.now(timezone.utc).isoformat()
 for s in f['sources']:s['source_url']=s.pop('url')
 fp=R/'brazil-pairs'/(f['source_event_id']+'-validated-input.json');out=R/'brazil-pairs'/(f['source_event_id']+'.json');write(fp,f)
 subprocess.run(['/workspace/football-venv/bin/python','/workspace/Football-Analysis/runtime/predict_active.py',str(fp),'--out',str(out)],check=True)
 pair=read(out);index.append(dict(match_id=f['match_id'],path=str(out),keys=list(pair)))
write(R/'brazil-pair-index.json',index);write(R/'ready-fixtures.json',fs)
diag=[]
for f in fs:
 if f['competition']=='uefa.nations':pair=read(R/'candidate-update'/(f['match_id'].replace(':','-')+'.json'));roles={'current':'current','test':'test'}
 else:pair=read(R/'brazil-pairs'/(f['source_event_id']+'.json'));roles={'current':'current_model','test':'test_model'}
 diag.append(dict(match_id=f['match_id'],actual_quote=f['total_quote'],**{r:dict(primary=pair[k]['primary'],wdl=pair[k]['wdl'],team_goal_analysis=summarize_prediction(pair[k]),distribution_audit=audit_prediction(pair[k])) for r,k in roles.items()}))
write(R/'diagnostics.json',diag)
print('DONE',len(fs))
