# 雷速欧国联首发补查（BJT）

首发状态仍为 UNKNOWN。雷速首页成功显示五场目标赛程，并将其分别链接至 detail-4518097、4518099、4518100、4518101、4518103；队名、欧国联A/B级、北京时间03:45均与本批原 schedule 的队伍ID对应。

葡萄牙—丹麦的首页新闻标题原文为“葡萄牙vs丹麦首发：B费、拉莫斯领衔，菲利克斯在列”，分类 `PARTIAL_HEADLINE_ONLY`。无法据此确认三人均首发；标题也不含完整11人、球员ID、阵型、门将或替补。

点击葡萄牙—丹麦比赛详情后出现滑动验证；打开该新闻正文也出现同类验证，已停止相应端点，不登录、不绕过验证码、不重试其余比赛详情。其余四场没有在已捕获首页可见内容中发现阵容标题，不能据此认定未发布。C罗、Isak、Gyökeres、Lewandowski、Francisco Conceição可用性均为UNKNOWN。

证据：`source-ledger.json`、`lineups.json`、`homepage-visible-evidence.txt`；截图为 `home.png`、`apex.png`、`home-links.png`、`match-4518097.png`、`news-786148.png`。