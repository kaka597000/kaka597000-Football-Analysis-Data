"""Independent verification of team IDs, league windows, raw evidence and frozen matrices."""
import json,hashlib,sys
from pathlib import Path
from datetime import datetime,timezone
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from research.analysis_freeze import verify
from v2_test.data_contract import digest
R=Path(__file__).resolve().parent;P=Path('/workspace/WCPP/reports/nations-prematch-20261114-2051')
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):
 with Path(p).open('x') as h:json.dump(x,h,ensure_ascii=False,indent=2,allow_nan=False)
fs=read(R/'ready-fixtures.json');forms=[];checks=0;training=[]
idx=read('/workspace/nations-model-20261110/models/candidates.json')
assert sha('/workspace/nations-model-20261110/models/candidates.json')=='9c60bfc468c4b04dc3343d3ba5f621ff559cc534de9f5e93afa9c4fcb8081520'
for f in fs:
 d=read(f['phase_evidence']['source_path']);assert sha(f['phase_evidence']['source_path'])==f['phase_evidence']['source_sha256']
 for team in d['lastFiveGames']:
  tid=str(team['team']['id']);assert 'espn:'+tid in [f['home'],f['away']];games=[];excluded=[]
  for e in team['events']:
   name=e['competitionName'].strip();valid=name==('2026-27 UEFA Nations League' if f['competition']=='uefa.nations' else '2026 Brasileiro Serie A')
   if f['competition']=='uefa.nations':valid=valid and e.get('roundName')=='League Phase'
   ishome=str(e['homeTeamId'])==tid;assert ishome or str(e['awayTeamId'])==tid
   x=dict(id=str(e['id']),date=e['gameDate'],home=ishome,gf=int(e['homeTeamScore'] if ishome else e['awayTeamScore']),ga=int(e['awayTeamScore'] if ishome else e['homeTeamScore']),opponent=e['opponent']['displayName'],opponent_id=str(e['opponent']['id']),competition_name=name)
   assert datetime.fromisoformat(x['date'].replace('Z','+00:00'))<datetime.fromisoformat(f['cutoff_at'])
   (games if valid else excluded).append(x);checks+=2
  assert len(games)==len({g['id'] for g in games})
  stats=lambda gs:dict(n=len(gs),W=sum(g['gf']>g['ga'] for g in gs),D=sum(g['gf']==g['ga'] for g in gs),L=sum(g['gf']<g['ga'] for g in gs),GF=sum(g['gf'] for g in gs),GA=sum(g['ga'] for g in gs))
  forms.append(dict(fixture_id=f['source_event_id'],team=team['team']['displayName'],team_id=tid,games=games,excluded_nonleague=excluded,overall=stats(games),home=stats([g for g in games if g['home']]),away=stats([g for g in games if not g['home']]),source=f['phase_evidence']))
  if f['competition']=='uefa.nations':
   assert len(games)==4
   art=read(idx['routes'][f['league_level']]['test']['path']);assert sha(art['dataset_path'])==art['dataset_sha256'];dataset={x['source_event_id']:x for x in read(art['dataset_path'])['rows']}
   for g in games:
    row=dataset[g['id']];side='home' if g['home'] else 'away';opp='away' if g['home'] else 'home';assert row[side]=='espn:'+tid and [row[side+'_goals'],row[opp+'_goals']]==[g['gf'],g['ga']];checks+=2
   training.append(dict(match_id=f['match_id'],team_id=tid,training_cutoff=art['train_end'],recent_league_rows=4,all_present_in_training=True))
  else:
   cutoff='2026-10-09';assert all(g['date'][:10]>cutoff for g in games)
   training.append(dict(match_id=f['match_id'],team_id=tid,training_cutoff=cutoff,recent_league_rows=len(games),rows_after_training_cutoff=len(games),all_present_in_training=False,used_in_manual_context_only=True))
write(R/'verified-form.json',forms)
oldproc=read(P/'verified-process.json');wanted=set()
for f in fs:
 if f['competition']!='uefa.nations':continue
 ff=[x for x in forms if x['fixture_id']==f['source_event_id']];ids={x['team_id'] for x in ff};wanted|={max(x['games'],key=lambda y:y['date'])['id'] for x in ff};wanted|={p['event_id'] for p in oldproc if set(p['teams'])==ids}
process=[]
for p in oldproc:
 if p['event_id'] not in wanted:continue
 assert sha(p['source_path'])==p['source_sha256'];m=read(p['source_path'].replace('.raw.json','.meta.json'));assert m['sha256']==p['source_sha256'];process.append(p);checks+=2
for eid in ['401841304','401841305','401841306']:
 path=R/'brazil'/('summary-'+eid+'.json');d=read(path);c=d['header']['competitions'][0];assert c['id']==eid and c['status']['type']['name']=='STATUS_FULL_TIME';assert d['header']['league']['slug']=='bra.1'
 sides={s['homeAway']:s for s in c['competitors']};stats={str(t['team']['id']):{z['name']:z['displayValue'] for z in t['statistics']} for t in d['boxscore']['teams']};assert set(stats)=={str(s['team']['id']) for s in sides.values()}
 events=[dict(type=e.get('type',{}).get('type'),minute=e['clock']['displayValue'],text=e.get('text'),team_id=str(e.get('team',{}).get('id')),home_score=e.get('homeScore'),away_score=e.get('awayScore')) for e in d.get('keyEvents',[]) if e.get('scoringPlay') or e.get('type',{}).get('type') in ['red-card','yellow-red-card']]
 process.append(dict(event_id=eid,date=c['date'],source_path=str(path),source_sha256=sha(path),window='LATEST_LEAGUE',teams={str(s['team']['id']):dict(name=s['team']['displayName'],side=s['homeAway'],goals=int(s['score']),stats=stats[str(s['team']['id'])]) for s in sides.values()},events=events,real_xg_fields={tid:{k:v for k,v in st.items() if 'expected' in k.lower() or 'xg' in k.lower()} for tid,st in stats.items()},field_conflicts=['Penalty aggregate may conflict with events; own-goal beneficiary checked from score progression/text, not actor team ID. Saves are not a goalkeeper quality metric.']))
 checks+=3
write(R/'verified-process.json',process)
matrices=[]
for rr in read(R/'candidate-update/receipts.json'):
 chain=[verify(read(p)) for p in sorted(Path(rr['path']).parent.glob('[0-9]*.json'))]
 assert len(chain)>=3
 for role in ['current','test']:assert all(x['payload'][role]['matrix']==chain[0]['payload'][role]['matrix'] for x in chain)
 matrices.append(dict(match_id=chain[-1]['match_id'],first=chain[0]['freeze_id'],latest=chain[-1]['freeze_id'],numerical_matrices_unchanged=True,additional_independent_match=False));checks+=2
coverage={}
for label in ['nations','brazil']:
 channel=read(R/('validated-market-'+label)/'market-channel.json');coverage[label]={k:channel[k] for k in ['eligible_fixture_count','covered_fixture_count','verified_quote_count','coverage','market_max_age_seconds']}
 for snap in channel['snapshots']:
  assert snap['snapshot_sha256']==digest({k:v for k,v in snap.items() if k!='snapshot_sha256'});checks+=1
  for row in snap['observations']:
   assert row['provider_match_id']!='30b32c194d8c2ae2bc5a209be5df44a9'
   for k in ['evidence','identity_evidence']:assert sha(R/('validated-market-'+label)/row[k]['file'])==row[k]['sha256'];checks+=1
write(R/'source-audit.json',dict(status='PASS',checks=checks,coverage=coverage,training_freshness=training,candidate_revision_audit=matrices,verified_process_games=len(process),verified_team_result_rows=sum(len(x['games']) for x in forms),xg_fields_present=sum(bool(v) for p in process for v in p['real_xg_fields'].values()),brazil_time_audit=str(R/'brazil/time-audit.json'),brazil_cup_games_excluded_from_league_window=4,formal_kpi_acceptance=False))
print(json.dumps(dict(checks=checks,process=len(process),rows=sum(len(x['games']) for x in forms),coverage=coverage),ensure_ascii=False))
