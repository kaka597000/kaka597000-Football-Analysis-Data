"""Validate retained sources and run immutable model tracks. No network or fitting."""
import json,hashlib,sys,shutil,subprocess
from pathlib import Path
from datetime import datetime,timezone
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from automation.market_snapshot import build
from automation.market_bridge import attach_total_quote
from nations_league import safe_cli
from research.team_goal_analysis import summarize_prediction
from research.score_distribution_audit import audit_prediction
from research.analysis_freeze import verify
from research_program.future_validation import quote_audit
R=Path(__file__).resolve().parent;P=Path('/workspace/WCPP/reports/nations-prematch-20261114-2051');F=Path('/workspace/WCPP/forecasts/issued-analyses')
def read(p):return json.loads(Path(p).read_text())
def write(p,x):
 with Path(p).open('x') as h:json.dump(x,h,ensure_ascii=False,indent=2,allow_nan=False)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def now():return datetime.now(timezone.utc)
channels={}
for label,competition in [('nations','uefa.nations'),('brazil','bra.1')]:
 src=R/('market-'+label);dest=R/('validated-market-'+label);dest.mkdir()
 m=read(src/'source-metadata.json')
 for k in ['odds','identity']:
  shutil.copy2(src/m[k]['file'],dest/m[k]['file']);assert sha(dest/m[k]['file'])==m[k]['sha256']
 if label=='brazil':
  a=next(x for x in read(R/'brazil/time-audit.json')['requests'] if x['file']=='scoreboard-20261114.json')['timestamp_audit']
  m['identity'].update(captured_at=a['available_by_utc'],capture_time_basis='conservative persisted-file available-by bound; exact HTTP read completion unmeasured',response_read_completed_at=None,time_audit_path=str(R/'brazil/time-audit.json'),original_metadata_path=str(src/'source-metadata.json'))
 t=now();channel=build(dest,m['odds'],m['identity'],cutoff=t.isoformat(),now=t,competition=competition,market_max_age_seconds=3600)
 write(dest/'source-metadata.json',m);write(dest/'market-channel.json',channel);channels[label]=channel
 print(label,'identity',len(channel['identity_mappings']),'observations',sum(len(s['observations']) for s in channel['snapshots']),channel['excluded'])
prepared=[];audits=[];sources=[]
for label in ['nations','brazil']:
 fixtures=read(R/label/'fixtures.json');mapping={x['match_id']:x for x in channels[label]['identity_mappings']};meta=read(R/('validated-market-'+label)/'source-metadata.json')
 for original in fixtures:
  f=dict(original,cutoff_at=now().isoformat(),identity_verified=True,score_basis='regulation_90')
  raw=read(f['phase_evidence']['source_path']);assert sha(f['phase_evidence']['source_path'])==f['phase_evidence']['source_sha256']
  c=raw['header']['competitions'][0];assert c['id']==f['source_event_id'] and c['status']['type']['state']=='pre' and c['status']['type']['completed'] is False
  assert {s['homeAway']:'espn:'+str(s['team']['id']) for s in c['competitors']}=={s:f[s] for s in ['home','away']}
  assert datetime.fromisoformat(c['date'].replace('Z','+00:00'))==datetime.fromisoformat(f['kickoff_at'].replace('Z','+00:00')) and c['neutralSite']==f['neutral']
  pe=dict(f['phase_evidence'])
  if label=='brazil':
   f.pop('date');pe['query_time']=pe['identity_available_by_utc'];pe['query_time_basis']='conservative local availability bound, not exact HTTP completion'
  else:
   sm=read(str(pe['source_path']).replace('.raw.json','.meta.json'));pe['query_time']=sm['captured_at'];assert sm['sha256']==pe['source_sha256']
  f['phase_evidence']=pe
  f['sources']=[dict(tier='L2',url=pe['source_url'],query_time=pe['query_time'],sha256=pe['source_sha256'])]
  f,au=attach_total_quote(f,R/('validated-market-'+label),provider_order=('the-odds-api',),bookmaker_order=('pinnacle','leovegas_se'),now=now());assert au['status']=='ATTACHED';assert quote_audit(f)['eligible']
  f['market_snapshots']=[];pid=mapping[f['match_id']]['provider_match_id'];book=f['total_quote']['bookmaker']
  evidence=[(R/('validated-market-'+label)/'odds.json',meta['odds'])]
  if label=='nations':evidence.insert(0,(P/'market/odds.json',read(P/'market/source-metadata.json')['odds']))
  for path,mm in evidence:
   assert sha(path)==mm['sha256']
   ee=[e for e in read(path) if e['id']==pid]
   if not ee:continue
   assert len(ee)==1;e=ee[0]
   assert datetime.fromisoformat(e['commence_time'].replace('Z','+00:00'))==datetime.fromisoformat(f['kickoff_at'].replace('Z','+00:00'))
   for b in e['bookmakers']:
    if b['key']!=book:continue
    for market in b['markets']:
     if market['key'] not in ['h2h','totals']:continue
     names={e['home_team']:'home',e['away_team']:'away','Draw':'draw'} if market['key']=='h2h' else {'Over':'over','Under':'under'}
     f['market_snapshots'].append(dict(match_id=f['match_id'],bookmaker=book,market='1x2' if market['key']=='h2h' else 'totals',line=market['outcomes'][0].get('point'),decimal_odds={names[o['name']]:o['price'] for o in market['outcomes']},quoted_at=market['last_update'],query_time=mm['captured_at'],source_url=mm['url'],source_sha256=mm['sha256']))
  prepared.append(f);audits.append(dict(match_id=f['match_id'],audit=au));print(f['match_id'],book,f['total_quote']['line'],[(x['market'],x['decimal_odds']) for x in f['market_snapshots'][-2:]])
write(R/'prepared-fixtures.json',prepared);write(R/'market-attachment-audit.json',audits)
ns=[f for f in prepared if f['competition']=='uefa.nations'];safe_cli.freeze_pairs('/workspace/nations-model-20261110/models/candidates.json',ns,R/'candidate-update',F)
(R/'brazil-pairs').mkdir();br=[]
for f in [x for x in prepared if x['competition']=='bra.1']:
 fp=R/'brazil-pairs'/(f['source_event_id']+'-input.json');out=R/'brazil-pairs'/(f['source_event_id']+'.json');write(fp,f)
 subprocess.run(['/workspace/football-venv/bin/python','/workspace/Football-Analysis/runtime/predict_active.py',str(fp),'--out',str(out)],check=True)
 pair=read(out);br.append(dict(match_id=f['match_id'],path=str(out),keys=list(pair)))
write(R/'brazil-pair-index.json',br)
diag=[]
for f in prepared:
 if f['competition']=='uefa.nations':pair=read(R/'candidate-update'/(f['match_id'].replace(':','-')+'.json'));roles={'current':'current','test':'test'}
 else:pair=read(R/'brazil-pairs'/(f['source_event_id']+'.json'));roles={'current':'current_model','test':'test_model'}
 diag.append(dict(match_id=f['match_id'],actual_quote=f['total_quote'],**{r:dict(primary=pair[k]['primary'],wdl=pair[k]['wdl'],team_goal_analysis=summarize_prediction(pair[k]),distribution_audit=audit_prediction(pair[k])) for r,k in roles.items()}))
write(R/'diagnostics.json',diag)
print('DONE',len(prepared))
