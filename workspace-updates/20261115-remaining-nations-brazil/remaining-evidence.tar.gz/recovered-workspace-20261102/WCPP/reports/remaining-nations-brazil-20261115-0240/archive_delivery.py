"""Retain this batch; reuse hash-verified prior archives without rewriting old records."""
import os,json,hashlib,sys,tarfile,shutil,subprocess,platform,importlib.metadata
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
R=Path(__file__).resolve().parent;P=Path('/workspace/WCPP/reports/nations-prematch-20261114-2051');REPO=Path('/workspace/kaka597000-Football-Analysis-Data');DEST=REPO/'workspace-updates/20261115-remaining-nations-brazil'
sys.path.insert(0,'/workspace/Football-Analysis/scripts')
from check_repository import BINDINGS,PATTERNS
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):
 with Path(p).open('x') as h:json.dump(x,h,ensure_ascii=False,indent=2,allow_nan=False)
delivery=read(R/'delivery.json');source=delivery['source_commit']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd='/workspace/Football-Analysis').decode().strip()==source
assert not subprocess.check_output(['git','status','--porcelain'],cwd='/workspace/Football-Analysis').strip()
write(R/'inference-environment.json',dict(python=platform.python_version(),packages={n:importlib.metadata.version(n) for n in ['numpy','scipy','lightgbm','scikit-learn']},source_commit=source,main_commit='1257fdde7b6746b7ba6d2aa919382214a2cfb589',source_branch='analysis/remaining-nations-brazil-20261115',model_promotion=False,registry_unchanged=True))
DEST.mkdir(exist_ok=False);catalog={};archive_hashes={}
for folder in ['20261110-nations-model','20261113-nations-evening','20261114-nations-review','20261114-nations-prematch']:
 root=REPO/'workspace-updates'/folder;m=read(root/'manifest.json');name=str((root/m['archive']).relative_to(REPO));assert sha(REPO/name)==m['archive_sha256'];archive_hashes[name]=dict(sha256=m['archive_sha256'])
 for row in m.get('members',m.get('files',[])):
  path=row.get('original_path',row.get('path'));member=row.get('archive_member',row.get('archive_path'))
  if path and member:catalog[(str(Path(path).resolve()),row['sha256'])]=dict(original_path=path,repository_archive=name,archive_member=member,sha256=row['sha256'])
 rp=root/'recovery-map.json'
 if rp.exists():
  old=read(rp);archive_hashes.update(old['reused_archives'])
  for row in old['reused_files']:catalog[(str(Path(row['original_path']).resolve()),row['sha256'])]=row
paths={str(p):p for p in R.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
for rr in delivery['all_receipts']:
 for p in Path(rr['path']).parent.glob('[0-9]*.json'):paths[str(p)]=p
for p in [Path('/workspace/nations-model-20261110/models/candidates.json'),Path('/workspace/nations-model-20261110/models/protocol.json'),Path('/workspace/WCPP/runtime/active-model.json'),Path('/workspace/WCPP/runtime/upset-classifier.json'),Path('/workspace/WCPP/runtime/upset-candidates.json')]:paths[str(p)]=p
idx=read('/workspace/nations-model-20261110/models/candidates.json')
for route in idx['routes'].values():
 for ref in route.values():
  p=Path(ref['path']);assert sha(p)==ref['sha256'];paths[str(p)]=p;d=read(p)
  for k in ['dataset_path','protocol_path']:
   q=Path(d[k]);paths[str(q)]=q
for x in read(R/'analysis-records.json'):
 for p in x['payload']['process_evidence']:
  q=Path(p['source_path']);paths[str(q)]=q
  if q.name.endswith('.raw.json'):
   m=Path(str(q).replace('.raw.json','.meta.json'));paths[str(m)]=m
for name in ['odds.json','source-metadata.json']:
 q=P/'market'/name;paths[str(q)]=q
for name in ['verified-form.json','verified-process.json','source-audit.json','selections.json','delivery.json']:
 q=P/name;paths[str(q)]=q
route=read('/workspace/WCPP/runtime/active-model.json')['models']['bra.1']
for k in ['artifact_path','test_artifact_path']:
 q=Path(route[k]);expected=route['artifact_sha256' if k=='artifact_path' else 'test_artifact_sha256'];assert sha(q)==expected;paths[str(q)]=q
new=[];reused=[];secrets=[os.environ[k].encode() for k in BINDINGS if os.environ.get(k) and len(os.environ[k])>=8]
for original,p in sorted(paths.items()):
 b=p.read_bytes()
 if any(v in b for v in secrets):raise ValueError('configured credential found; publication stopped in '+p.name)
 if p.suffix.lower() not in ['.png','.jpg','.jpeg','.xlsx']:
  txt=b.decode('utf-8')
  for name,pattern in PATTERNS.items():
   for match in pattern.finditer(txt):
    if name=='literal_credential' and match.group(1).upper().startswith(('TEST_','SYNTHETIC_','EXAMPLE_')):continue
    raise ValueError('credential pattern found; publication stopped: '+name+' in '+str(p))
 digest=hashlib.sha256(b).hexdigest();prior=catalog.get((str(p.resolve()),digest))
 if prior and not p.is_relative_to(R):reused.append(dict(prior,original_path=original));continue
 new.append(dict(original_path=original,archive_member=str(Path(original).relative_to('/workspace')),sha256=digest,bytes=len(b)))
archive=DEST/'remaining-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for e in new:t.add(e['original_path'],arcname=e['archive_member'],recursive=False)
used={e['repository_archive']:archive_hashes[e['repository_archive']] for e in reused}
for name,v in used.items():assert sha(REPO/name)==v['sha256']
write(DEST/'recovery-map.json',dict(reused_archives=used,reused_files=reused,absolute_path_aliases={'/workspace/WCPP':'/workspace/recovered-workspace-20261102/WCPP'},no_frozen_path_or_hash_rewrite=True,source_checkout_separate=source,restore_notice='Stage first. Restore paths with the documented WCPP alias without overwriting existing user files. Check out the source commit and install matching inference packages separately. Archive restore is not production deployment. Past fixtures must not be rerun as new prematch predictions.'))
for old,newname in {'剩余赛事赛前分析.md':'report.md','比赛分析展示.csv':'比赛分析展示.csv','delivery.json':'delivery.json','source-audit.json':'source-audit.json','source-validation.json':'source-validation.json','source-ci.json':'source-ci.json','ci-summary.json':'ci-summary.json','inference-environment.json':'inference-environment.json'}.items():shutil.copy2(R/old,DEST/newname)
shutil.copy2(REPO/'workspace-updates/20261114-nations-prematch/verify_archive.py',DEST/'verify_archive.py')
(DEST/'README.md').write_text('''# 剩余欧国联与巴西甲｜2026年11月15日

[完整报告](report.md) · [CSV](比赛分析展示.csv) · [冻结回执](delivery.json) · [来源审计](source-audit.json) · [代码与CI回执](ci-summary.json)

03:07北京时间完成本轮5场欧国联、2场巴甲赛前冻结。比分/胜平负各7场，实际大小球4场给方向、3场观望。优先三场：葡萄牙2-1丹麦、北爱尔兰1-0乌克兰、瑞典1-1波黑。欧国联候选未晋级；巴甲现有双模型实际加载，训练只到10月9日。原活动参数、注册表和旧冻结不变。

雷速首页核实五场赛程并看到葡萄牙首发新闻标题，但详情和正文受滑动验证阻断；没有取得完整11人名单。ESPN/FotMob/SofaScore缺项与失败均保留。七场盘口身份、来源哈希及真实报价时间均已核验；不使用错误的奥地利—冰岛事件。巴甲采集原日志存在请求前/抓取完成时间重复，保留原记录及time-audit.json，以落盘时间作为保守可用上界，不伪造HTTP完成时间。

源代码commit与PR见delivery.json，分支为analysis/remaining-nations-brazil-20261115。该版本已用于本轮人工运行，main和后台采集工作流未切换。回滚代码到1257fdde7b6746b7ba6d2aa919382214a2cfb589即可恢复原范围/映射；旧模型不需要回滚。数据父commit见manifest.json，不能删除本轮冻结链。

长期恢复：先运行 `python verify_archive.py --stage /tmp/NEW-remaining-restore`，验证原文字节、所有引用的旧归档和冻结链，再按recovery-map.json协调原始路径与WCPP符号链接。源码另checkout精确commit，Python/numpy/scipy/LightGBM等版本见inference-environment.json。候选模型、训练数据/协议、巴甲两份原工件及原运行输入均已保留；其余旧文件复用长期归档，不依赖Actions短期下载链接。比赛过期后不能绕过未来时点检查重新冒称赛前运行，只读取已冻结矩阵或使用独立历史研究入口。

prepare.py保存了最初的60秒窗口拒绝与sources字段名失败；finish_predictions.py只修正本轮输入证据字段名后完成真正predict_active运行。失败诊断保留，不修改模型或哈希检查。冻结receipt为规范化记录哈希，不等同于JSON文件字节哈希。全部尚待比赛结果结算；恢复校验、CI与代码完整性不等于预测准确率已通过验收。
''')
sidecars=[dict(path=p.name,sha256=sha(p)) for p in sorted(DEST.iterdir()) if p.is_file() and p!=archive]
manifest=dict(schema='WCPP-REMAINING-PREMATCH-ARCHIVE-20261115',created_at_beijing=datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),source_commit=source,source_main_commit='1257fdde7b6746b7ba6d2aa919382214a2cfb589',data_parent_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO).decode().strip(),archive=archive.name,archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,members=new,reused_files=len(reused),sidecar_files=sidecars,report_receipt=delivery['report_receipt'],top3_receipt=delivery['top3_receipt'],new_receipts=len(delivery['all_receipts']),credential_scan=dict(scanned_files=len(paths),configured_bindings_checked=len(secrets),findings=0),active_model_changed=False,environment_published=False)
write(DEST/'manifest.json',manifest)
latest=read(REPO/'latest-source.json');key=str(DEST.relative_to(REPO));assert latest['commit']=='1257fdde7b6746b7ba6d2aa919382214a2cfb589'
latest['additional_workspace_updates'].append(key);latest['latest_nations_prematch']=key+'/manifest.json';latest['latest_nations_analysis']=key+'/report.md';latest['latest_nations_top3_research']=key+'/manifest.json';latest['latest_remaining_nations_brazil']=key+'/manifest.json';latest['synchronized_at']=datetime.now(ZoneInfo('Asia/Shanghai')).isoformat();latest['latest_analysis_source_commit']=source
latest['actual_runtime_versions'].update(manual_nations_prematch_commit=source,manual_nations_prematch_freeze=delivery['report_receipt']['freeze_id'],manual_remaining_brazil_commit=source,last_strict_integration_source_commit=source,last_strict_integration_test_executions=941,last_strict_integration_skips=0,manual_branch_status='PR38_OPEN_CI_PASSED; MAIN_AND_AUTOMATION_UNCHANGED')
latest['latest_chat_analysis_runtime']=dict(source_commit=source,source_branch='analysis/remaining-nations-brazil-20261115',competition=['uefa.nations','bra.1'],population=7,scope='NATIONS_CANDIDATE_RESEARCH_AND_BRAZIL_ACTIVE_RESEARCH',market_verified_quote_count=218,market_covered_fixtures=7,market_scope_note='All verified bookmaker observations; does not update Actions credential or deployment status.',active_registry_sha256=delivery['active_registry_sha256'],active_model_promotion=False,report_receipt=delivery['report_receipt'],full_lineups_verified=0)
(REPO/'latest-source.json').write_text(json.dumps(latest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(destination=str(DEST),new_files=len(new),reused_files=len(reused),archives=len(used)+1,archive_bytes=archive.stat().st_size,credential_findings=0),ensure_ascii=False))
