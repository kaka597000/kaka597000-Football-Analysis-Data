"""Freeze seven prematch analyses, a separate remaining-fixture TOP3 and report."""
import csv,json,hashlib,sys,subprocess
from pathlib import Path
from datetime import datetime,timezone
from zoneinfo import ZoneInfo
import numpy as np
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from prediction_engine import predict_models
from research.analysis_freeze import save,verify
from research.team_goal_analysis import summarize_prediction
from research.score_distribution_audit import audit_prediction
from research.market_movement import analyze
from research_program.future_validation import quote_audit
from v2.model import total_settlement
R=Path(__file__).resolve().parent;P=Path('/workspace/WCPP/reports/nations-prematch-20261114-2051');F=Path('/workspace/WCPP/forecasts/issued-analyses');BJT=ZoneInfo('Asia/Shanghai')
SOURCE='7a18cee715acb0633904af434b3f743d870c0951'
def read(p):return json.loads(Path(p).read_text())
def write(p,x):
 with Path(p).open('x') as h:json.dump(x,h,ensure_ascii=False,indent=2,allow_nan=False)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def now():return datetime.now(timezone.utc).isoformat()
def bt(t):return datetime.fromisoformat(t.replace('Z','+00:00')).astimezone(BJT).strftime('%m-%d %H:%M:%S')
def pct(v):return f'{v:.1%}'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd='/workspace/Football-Analysis').decode().strip()==SOURCE
assert not subprocess.check_output(['git','status','--porcelain'],cwd='/workspace/Football-Analysis').strip()
fs=read(R/'ready-fixtures.json');choices=read(R/'selections.json');forms=read(R/'verified-form.json');process=read(R/'verified-process.json');audit=read(R/'source-audit.json')
assert audit['status']=='PASS' and len(fs)==len(choices)==7
registry='/workspace/WCPP/runtime/active-model.json';registry_sha=sha(registry);assert registry_sha=='923e34fc44cda33fe965498a24a2435abb37a01a80c539108d8ec20d490bf013'
crs={verify(read(r['path']))['match_id']:r for r in read(R/'candidate-update/receipts.json')}
lineup=read(R/'leisu-lineups/lineups.json');all_records=[]
for f in fs:
 q=f['total_quote'];choice=choices[f['source_event_id']];assert choice['expected_line']==q['line'];assert quote_audit(dict(f,cutoff_at=now()))['eligible']
 cr=None
 if f['competition']=='uefa.nations':
  try:predict_models(dict(f,cutoff_at=now()))
  except ValueError as e:assert str(e)=='no validated identity/history model for this cohort'
  else:raise ValueError('Active Nations route changed; review required')
  failed=dict(status='ABSTAIN_NO_ACTIVE_ROUTE',matrix=None,primary=None,input=f)
  active=save(dict(current_model=dict(failed,model_label='当前模型'),test_model=dict(failed,model_label='test模型'),active_registry_sha256=registry_sha,candidate_substitution=False),dict(f,cutoff_at=now()),stage='prematch',track='current-test-pair',root=F)
  pair=read(R/'candidate-update'/(f['match_id'].replace(':','-')+'.json'));cr=crs[f['match_id']];roles={'current':'current','test':'test'};scope='candidate_research'
 else:
  pair=read(R/'brazil-pairs'/(f['source_event_id']+'.json'));active=pair['freeze_receipt'];roles={'current':'current_model','test':'test_model'};scope='active_reference'
  assert pair['execution_audit']['source_identity']==dict(commit=SOURCE,worktree_dirty=False,status='GIT_IDENTIFIED')
 if pair[roles['current']]['primary']==pair[roles['test']]['primary'] and choice['primary']!=pair[roles['current']]['primary']:assert len(set(choice['nonmarket_evidence_classes']))>=2
 outputs={}
 for role,key in roles.items():
  p=pair[key];m=np.asarray(p['matrix']);a,b=np.indices(m.shape);tot=a+b
  outputs[role]=dict(p,team_goal_analysis=summarize_prediction(p),score_distribution_audit=audit_prediction(p,choice['primary']),actual_total_settlement={side:total_settlement(m,q['line'],side) for side in ['over','under']},total_probabilities=dict(p_le_2=float(m[tot<=2].sum()),p_eq_3=float(m[tot==3].sum()),p_ge_3=float(m[tot>=3].sum()),p_ge_4=float(m[tot>=4].sum())))
 ff=[x for x in forms if x['fixture_id']==f['source_event_id']];latest={max(x['games'],key=lambda z:z['date'])['id'] for x in ff};ids={x['team_id'] for x in ff};ctx=[x for x in process if x['event_id'] in latest or set(x['teams'])==ids]
 assert len(ctx)==(3 if f['competition']=='uefa.nations' else 2)
 payload=dict(choice,selection_scope=scope,method_version='WCPP-REMAINING-MANUAL-20261115-1',status='RESEARCH_COMPREHENSIVE',total_line=q['line'],actual_quote=q,current_test_reference=active,model_outputs=outputs,selection_evidence={k:choice[k] for k in ['compared_scores','zero_vs_one','three_plus_path','total_reason']},current_edition_form=ff,process_evidence=ctx,market_movement=analyze(dict(f,cutoff_at=now())),availability_evidence=str(R/'leisu-lineups/lineups.json') if f['competition']=='uefa.nations' else str(R/'brazil/facts.json'),full_verified_starting_XI=False,xg_status='NO_VERIFIED_CURRENT_SAME_PROVIDER_XG',full_club_workload='NOT_VERIFIED',formal_kpi_eligible=False,active_model_promotion=False,numerical_weights_changed=False,exact_score_basis='regulation_90',source_commit=SOURCE,sources=dict(fixture=f['phase_evidence'],form=str(R/'verified-form.json'),process=str(R/'verified-process.json'),market=str(R/('validated-market-nations' if f['competition']=='uefa.nations' else 'validated-market-brazil')/'source-metadata.json'),audit=str(R/'source-audit.json')))
 if cr:payload.update(candidate_reference=cr,candidate_status='UNACCEPTED_RESEARCH_ONLY')
 comp=save(payload,dict(f,cutoff_at=now()),stage='prematch',track='comprehensive',root=F);rec=verify(read(comp['path']));assert rec['selection_audit']['top3_ready']
 all_records.append(dict(fixture=f,payload=payload,candidate_receipt=cr,active_receipt=active,comprehensive_receipt=comp))
byid={x['fixture']['source_event_id']:x for x in all_records}
topids=['401861167','401861169','401861166'];reasons=['葡萄牙持续创造较多射正，丹麦有回应得分能力，2-1路径最完整；首回合六球及完整首发未核实为反证。','北爱四场零封，乌克兰最新及首回合均2次射正，1-0优先；北爱两个主场0-0和客队定位球是风险。','双方本届均不败，最新射正产量低，1-1有双向得分路径；瑞典主场两连胜使2-1同样不可忽视。']
topitems=[]
for rank,eid in enumerate(topids,1):
 x=byid[eid];p=x['payload'];topitems.append(dict(rank=rank,match_id=x['fixture']['match_id'],**{k:p[k] for k in ['primary','wdl','total_line','total_direction']},comprehensive_reference=x['comprehensive_receipt'],reason=reasons[rank-1],risk=p['counter']))
shell=dict(match_id='remaining-nations-brazil:20261115-0300',cohort='remaining-analysis',kickoff_at=min(f['kickoff_at'] for f in fs),cutoff_at=now())
top=save(dict(selection_scope='candidate_research',population=[f['match_id'] for f in fs],eligible_population=[f['match_id'] for f in fs if f['competition']=='uefa.nations'],not_prioritized=[dict(match_id=f['match_id'],reason='Brazil models omit verified recent league games and full XI unknown; included in batch, not priority three') for f in fs if f['competition']=='bra.1'],top3=topitems,ranking_basis='研究比分证据与反证比较；不是已验证的命中率排序；巴甲数据鲜度不足，独立列入全批但不列优先三场',previous_batch_top3_unchanged=True,formal_kpi_eligible=False),shell,stage='prematch',track='top3-selection',root=F)
plan=save(dict(population=[dict(match_id=x['fixture']['match_id'],kickoff_at=x['fixture']['kickoff_at'],current_test_reference=x['active_receipt'],candidate_reference=x['candidate_receipt'],comprehensive_reference=x['comprehensive_receipt']) for x in all_records],top3_reference=top,status='PENDING_ALL_NOT_STARTED',evaluation_policy='First prematch version is default per-track; this later edition is separate. Exact score, WDL, actual-line OU and coverage use separate denominators; all seven retained, abstentions and pending results never converted into wins. No best-of-two model selection.',score_basis='regulation_90',settlement_states=['FULL_WIN','HALF_WIN','PUSH','HALF_LOSS','FULL_LOSS','ABSTAIN','PENDING'],active_model_promotion=False),dict(shell,cutoff_at=now()),stage='prematch',track='forward-validation-plan',root=F)
lines=['# 剩余赛事赛前分析｜北京时间2026年11月15日','', 'HELLO BOSS','',
 '本轮覆盖仍未开赛的5场欧国联与2场巴西甲。已开赛的此前赛事不加入本版，也不据其结果重排此前TOP3。本轮是独立的“剩余比赛”版本，全部按90分钟含补时结算。','',
 '本轮优先：葡萄牙2-1丹麦、北爱尔兰1-0乌克兰、瑞典1-1波黑。巴西甲可加载现有双模型，已加入全批；由于训练遗漏近期联赛数据，暂不列优先三场。排名是研究判断，并非已验证命中率。','',
 '雷速首页已实际匹配5场赛程，并看到“葡萄牙vs丹麦首发：B费、拉莫斯领衔，菲利克斯在列”标题；比赛详情和新闻正文均出现滑动验证。ESPN本场名单仍为空，FotMob/SofaScore回退未成功，因此本版不是“完整首发已确认版”，不根据标题推断C罗或其他球员缺席。首发与最新伤停缺项明确保留，没有虚设球员数值权重。','',
 '欧国联活动Current/Test路由实测仍拒绝输出；数值比较来自两套未晋级研究候选，另轨保存。候选训练至10月6日，今晚10队本届各4场、40条球队赛果均核实已在训练数据中；本轮候选矩阵与原冻结相同。巴甲使用实际注册的MAIN-1.2 / ML-0.1（DC＋LightGBM，alpha=0.25），训练至10月9日，4队近期联赛16条赛果全部晚于训练截止，只进入人工综合判断。工件、参数和注册表均未改变。','',
 '盘口为The Odds API实际留存报价：欧国联北京时间02:44:00（奥地利02:44:02），巴甲02:46:21；欧国联抓取02:44:20，巴甲02:46:40。7/7场合格，欧国联134条、巴甲84条机构市场观测，不是218个独立比赛样本。实际分析在报价后一小时内完成。原默认60秒窗口的重建拒绝结果保留；本次明确采用现有规则允许的3600秒赛前快照上限，没有改报价时间或放宽到一小时以上。','',
 '## 七场结论','', '|北京时间11月15日|比赛|Current统计|Test统计|综合唯一比分|胜平负|实际大小球|','|---|---|---|---|---|---|---|']
for x in all_records:
 f,p=x['fixture'],x['payload'];lines.append(f"|{bt(f['kickoff_at'])[6:11]}|{p['name']}|{p['model_outputs']['current']['primary']}|{p['model_outputs']['test']['primary']}|**{p['primary']}**|{p['wdl']}|{p['total_direction']} {p['total_line']:g}|")
lines+=['','欧国联两列是未验收候选；巴甲两列是已登记研究模型。综合比分独立于两者，不冒充新训练结果。胜平负比较的是所有主胜/平局/客胜比分的集合，因此瑞典及米拉索尔的单一比分1-1与集合方向主胜分别评价。大小球不由单一比分机械推出。','',
 '## 相比上一版','',
 '- 欧国联5场的综合比分与胜平负不变；数值候选也不变。','- 葡萄牙—丹麦：小3.25改为观望3。3球时已从半赢变成走盘，不能沿用旧优势。','- 北爱尔兰—乌克兰：观望1.75改为弱小2。2球时从小盘半输变为走盘，结合低射正过程重新判断。','- 瑞典—波黑：本轮身份审核完成后首次形成合格盘口，给小3；旧版缺项保留，旧原文中的2.75仅作为现在核验的历史价格对照。','- 奥地利的大2.5仍是较弱人工倾向，原模型总球分布并不支持大球占多数；罗马尼亚—波兰继续观望2.75。','',
 '## 本轮TOP3','', '|顺序|比赛与唯一比分|胜平负|实际大小球|依据与风险|','|---|---|---|---|---|']
for i,eid in enumerate(topids):
 p=byid[eid]['payload'];lines.append(f"|{i+1}|{p['name']} **{p['primary']}**|{p['wdl']}|{p['total_direction']} {p['total_line']:g}|{reasons[i]}|")
lines+=['','这三场各一个比分，其他候选比分不补算命中。小2遇2球走盘，小3遇3球走盘；2.75盘遇3球为大半赢、小半输。观望不加入大小球推荐命中分母。','']
for x in all_records:
 f,p=x['fixture'],x['payload'];q=p['actual_quote'];lines+=['## '+p['name'],'',f"北京时间{bt(f['kickoff_at'])[:11]}；{'欧国联'+f['league_level']+'级联赛阶段' if f['competition']=='uefa.nations' else '巴西甲2026常规赛'}。",'','**判断：**'+p['reason'],'','**反证：**'+p['counter'],'','比较比分：'+'、'.join(p['compared_scores'])+'。','', '**大小球：**'+p['total_reason'],'','三球以上路径：'+p['three_plus_path'],'','**人员：**'+p['availability'],'']
 for side,z in p['zero_vs_one'].items():lines+=['零球对比一球（'+('主队' if side=='home' else '客队')+'）：'+z['reason']+' 反证：'+z['counterevidence'],'']
 lines+=['|模型|主均值/中央80%区间|主0球/≥2/≥3|客均值/中央80%区间|客0球/≥2/≥3|主胜/平/客胜|总球≥3/≥4|','|---|---|---|---|---|---|---|']
 for role in ['current','test']:
  pred=p['model_outputs'][role];g=pred['team_goal_analysis'];cells=[]
  for side in ['home','away']:
   z=g[side];ci=z['central_interval'];cells+=[f"{z['mean']:.2f} / {ci['lower']}–{ci['upper']}",' / '.join(pct(z[k]) for k in ['p0','p_ge_2','p_ge_3'])]
  cells+=[' / '.join(pct(pred['wdl'][k]) for k in ['主胜','平局','客胜']),' / '.join(pct(pred['total_probabilities'][k]) for k in ['p_ge_3','p_ge_4'])];lines.append('|'+role+'|'+'|'.join(cells)+'|')
 lines+=['','这些是模型原分布，均值不是提供方xG，区间不是已校准置信区间；没有给人工综合选择编造概率。','']
 market=[z for z in f['market_snapshots'] if z['market']=='1x2'][-1];h=market['decimal_odds'];nv={k:(1/v)/sum(1/w for w in h.values()) for k,v in h.items()}
 lines+=[f"实盘 `{q['bookmaker']}`：主{h['home']} / 平{h['draw']} / 客{h['away']}；简单去水参考{pct(nv['home'])} / {pct(nv['draw'])} / {pct(nv['away'])}。总球{q['line']:g}，大{q['over_odds']} / 小{q['under_odds']}；报价北京时间{bt(q['quoted_at'])}。",'']
 if p['total_direction'] in ['大','小']:
  side='over' if p['total_direction']=='大' else 'under';lines+=['|模型所选盘结算|全赢|半赢|走盘|半输|全输|','|---|---|---|---|---|---|']
  for role in ['current','test']:
   a=p['model_outputs'][role]['actual_total_settlement'][side];lines.append('|'+role+'|'+'|'.join(pct(a[k]) for k in ['win','half_win','push','half_loss','loss'])+'|')
  lines+=['']
 for c in p['market_movement'].get('comparisons',[]):
  label='1X2（主/平/客）' if c['market']=='1x2' else f"总球{c['line']:g}（大/小）";keys=['home','draw','away'] if c['market']=='1x2' else ['over','under'];fmt=lambda d:' / '.join(str(d[k]) for k in keys)
  lines+=[f"同机构同盘：{label}，{bt(c['first_quoted_at'])} 的 {fmt(c['first_decimal_odds'])} → {bt(c['last_quoted_at'])} 的 {fmt(c['last_decimal_odds'])}。",'']
 totals=[s for s in f['market_snapshots'] if s['market']=='totals']
 if len(totals)==2 and totals[0]['line']!=totals[1]['line']:lines+=[f"总球{totals[0]['line']:g} → {totals[1]['line']:g}属于换线，不把不同线价格当同盘水位变化。",'']
 if f['competition']=='bra.1':lines+=['巴甲本轮只有一次实盘采集，没有同机构同盘历史快照，因此不宣称盘口升降或资金流。','']
 lines+=['报价变化不等于资金流、投注比例或比赛操纵证据。','',f"原始赛程/近期资料：[ESPN]({f['phase_evidence']['source_url']})；综合冻结 `{x['comprehensive_receipt']['freeze_id']}`；数值冻结 `{(x['candidate_receipt'] or x['active_receipt'])['freeze_id']}`。",'']
lines+=['## 保存与后续评价','',f"本版来源代码 `{SOURCE}`，PR #38；严格集成24组、941次测试执行，零跳过无失败。GitHub Ubuntu/Windows检查通过；公开CI的资产缺失跳过与本地严格集成分开记录。只在该分支执行本轮人工分析，未将其冒称main或后台任务已部署。",'',
 '本轮全批7场：比分7、胜平负7、实际大小球4场给方向，3场观望；全部尚未开赛、待结算。Current、Test、欧国联候选、综合Primary和TOP3分别保存；首个赛前版本为默认逐轨评价，本轮修订单列，不选择赛后更准版本，不增加同一比赛的独立分母。','',
 '过程证据共16场详细比赛；本次保留56条球队近期联赛结果（欧国联40、巴甲16）。巴甲杯赛4条从联赛窗口排除。未取得真实当前同源xG，射门/射正不伪装为xG；部分点球汇总与事件冲突，采用明确事件解释并保留冲突，不据扑救数推断门将能力。巴甲原采集日志把请求前时间同时写作抓取完成时间，已独立审计并保留原记录；精确HTTP读完时间未知，使用保存文件时点作为保守可用上界，没有伪造抓取结束。','',
 '长期归档：数据仓库 `workspace-updates/20261115-remaining-nations-brazil/`；包含原始响应、时间修正审计、雷速截图、模型身份、逐轨冻结、代码/CI回执和恢复清单。旧模型与旧冻结复用已有校验归档；未发布环境，未晋级模型。']
report='\n'.join(lines)+'\n'
rp=save(dict(markdown=report,comprehensive_receipts=[x['comprehensive_receipt'] for x in all_records],top3_receipt=top,forward_plan_receipt=plan,source_commit=SOURCE,formal_kpi_eligible=False),dict(shell,cutoff_at=now()),stage='prematch',track='analysis-report',root=F)
(R/'剩余赛事赛前分析.md').write_text(report)
write(R/'analysis-records.json',all_records)
receipts=[]
for x in all_records:
 for k in ['candidate_receipt','active_receipt','comprehensive_receipt']:
  if x[k]:receipts.append(x[k])
receipts += [top,plan,rp,read(R/'candidate-update/plan-receipt.json')]
for rr in receipts:
 rec=verify(read(rr['path']));assert rec['record_sha256']==rr['sha256'];assert datetime.fromisoformat(rec['recorded_at'])<datetime.fromisoformat(rec['fixture']['kickoff_at'].replace('Z','+00:00'))
assert sha(registry)==registry_sha
write(R/'delivery.json',dict(report_receipt=rp,top3_receipt=top,forward_plan_receipt=plan,all_receipts=receipts,population=7,comprehensive_scores=7,wdl_selections=7,total_selections=4,total_qualified_quotes=7,total_abstentions=3,top3_count=3,source_commit=SOURCE,source_pr='https://github.com/kaka597000/Football-Analysis/pull/38',source_ci='https://github.com/kaka597000/Football-Analysis/actions/runs/43629642719',active_registry_sha256=registry_sha,active_registry_changed=False,verified_all_receipts=True,all_before_kickoff=True,verified_full_lineups=0,environment_published=False))
with (R/'比赛分析展示.csv').open('x',encoding='utf-8-sig',newline='') as h:
 w=csv.writer(h);w.writerow(['北京时间','赛事','比赛','Current统计','Test统计','综合唯一比分','胜平负','大小球方向','实际盘线','机构','大赔率','小赔率','报价北京时间','综合冻结ID','完整首发已核实'])
 for x in all_records:
  f,p=x['fixture'],x['payload'];q=p['actual_quote'];w.writerow([bt(f['kickoff_at']),f['competition'],p['name'],p['model_outputs']['current']['primary'],p['model_outputs']['test']['primary'],p['primary'],p['wdl'],p['total_direction'],p['total_line'],q['bookmaker'],q['over_odds'],q['under_odds'],bt(q['quoted_at']),x['comprehensive_receipt']['freeze_id'],'否'])
print(json.dumps(dict(report_freeze=rp,top3_freeze=top,receipts=len(receipts),before_kickoff=True),ensure_ascii=False))
