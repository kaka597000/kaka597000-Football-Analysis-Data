# 欧国联阵容补查（BJT）

采集时点：2026-11-15 02:51:45 BJT，开球时间均为2026-11-15 03:45 BJT。

五场均未核实到真实的11人首发。ESPN本批已有原文中两队 roster 均为空；FotMob指定日接口返回404；FotMob网页重定向到首页且比赛区仅显示加载骨架；UEFA官方赛程页显示“Suspended until further notice”，没有比赛行或可点开的具体阵容页；SofaScore指定赛程API返回403，按规则立即停止。因此所有球员可用性和首发均为UNKNOWN，不能把空列表理解为无人伤停。

- 401861170 Austria—Republic of Ireland：UNKNOWN
- 401861169 Northern Ireland—Ukraine：UNKNOWN
- 401861167 Portugal—Denmark：UNKNOWN；Francisco Conceição停赛/出场资格未核实；Cristiano Ronaldo UNKNOWN
- 401861168 Romania—Poland：UNKNOWN；Robert Lewandowski UNKNOWN
- 401861166 Sweden—Bosnia-Herzegovina：UNKNOWN；Alexander Isak、Viktor Gyökeres UNKNOWN

没有用5Dollar/APIfootball：现有文档没有验证当前首发访问权限，5Dollar兼容范围不含首发；APIfootball.com也没有已验证绑定，API-Sports与它是不同服务。

证据原文/截图和调用记录见 `lineup-fallback/`；具体字段见 `lineups.json` 和 `source-ledger.json`。