"""Append the issued analysis and research TOP3, then render the full report."""
from pathlib import Path
from datetime import datetime,timezone
from zoneinfo import ZoneInfo
import csv,hashlib,json,shutil,sys
R=Path(__file__).parent;S=Path('/workspace/Football-Analysis-xg-research-20261117')
sys.path.insert(0,str(S/'runtime'))
from research.analysis_freeze import save,verify
from research.score_distribution_audit import audit_prediction
from research.team_goal_analysis import summarize_prediction
from research_program.future_validation import quote_audit
from v2.model import aware
def read(p):return json.loads(Path(p).read_text())
def write(p,v):
 with Path(p).open('x') as f:json.dump(v,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
def now():return datetime.now(timezone.utc).isoformat()
def bj(t):return aware(t).astimezone(ZoneInfo('Asia/Shanghai')).strftime('%Y-%m-%d %H:%M:%S')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

out=R/'publication';out.mkdir(exist_ok=False);freezes=out/'freezes';freezes.mkdir()
choices=read(R/'nations/selections.json');fixtures=read(R/'nations/fixtures.json')
contexts={c['match_id']:c for c in read(R/'nations/verified-context.json')}
pairs={verify(read(r['path']))['match_id']:r for r in read(R/'nations/paired/receipts.json')}
issued=[];all_receipts=[]
for f in fixtures:
 eid=f['source_event_id'];d=choices[eid];f=dict(f,cutoff_at=now())
 assert quote_audit(f)['eligible'],quote_audit(f)
 pair=verify(read(pairs[f['match_id']]['path']))['payload']
 fixed=read(R/f'nations/fixed/{eid}.json');xg=read(R/f'nations/xg/{eid}.json')
 refs={**{'old_'+k:pair[k] for k in ('current','test')},**fixed['payload']['predictions'],**xg['payload']['predictions']}
 scenario={**{'fixed_'+k:v for k,v in fixed['payload']['venue_sensitivity'].items()},**{'xg_'+k:v for k,v in xg['payload']['venue_sensitivity'].items()}}
 audits={k:audit_prediction(v,d['primary']) for k,v in dict(refs,**scenario).items()}
 payload={'schema':'WCPP-TONIGHT-RESEARCH-20261117-1','name':d['name'],'primary':d['primary'],'wdl':d['wdl'],
  'total_line':f['total_quote']['line'],'total_direction':d['total_direction'],
  'selection_scope':'candidate_research','candidate_reference':pairs[f['match_id']],
  'decision_policy_version':'WCPP-COMPREHENSIVE-REPAIR-1','override_validation_status':'UNVALIDATED_MANUAL_RESEARCH',
  'formal_kpi_eligible':False,'active_model_promotion':False,
  'independent_references':{'fixed_recipe':fixed['receipt'],'xg_selected_and_goals':xg['receipt']},
  'reason':d['reason'],'counterevidence':d['counter'],'ranking_reason':d['priority'],'research_rank':d['rank'],
  'personnel':d['personnel'],'actual_quote':f['total_quote'],'market_wdl':f['wdl_quote'],
  'selection_evidence':{'compared_scores':d['scores'],'zero_vs_one':d['zero'],'three_plus_path':d['high'],
    'total_reason':d['total_reason'],'wdl_evidence':{'reason':d['wdl_reason'],'counterevidence':d['wdl_counter']},
    'total_evidence':{'reason':d['total_reason'],'counterevidence':d['total_counter']}},
  'context_evidence':contexts[f['match_id']],'comparison_audits':audits,
  'current_test_status':'No accepted active Nations route; original Current/Test research candidates remain separate from fixed refresh, xG and manual choices.',
  'xg_use':'Archived actual finite BSD fields checked by source hash; fourteen teams one September match, Ireland/Kosovo none. Selected xG arm retains explicit goal fallback; no invented recent xG.',
  'evaluation':'First comprehensive 90-minute score, WDL and exact line outcomes evaluated separately over all eight; earlier statistical freezes remain their own first versions. No best-of-version scoring.'}
 receipt=save(payload,f,stage='prematch',track='comprehensive')
 r=verify(read(receipt['path']));assert r['selection_audit']['top3_ready'],r['selection_audit']
 issued.append({'fixture':f,'payload':payload,'freeze':receipt})
 all_receipts += [pairs[f['match_id']],fixed['receipt'],xg['receipt'],receipt]
ranked=sorted([p for p in issued if p['payload']['research_rank']],key=lambda p:p['payload']['research_rank'])
batch={'match_id':'nations-tonight-20261117-eight-match-analysis','kickoff_at':min(f['kickoff_at'] for f in fixtures),'cutoff_at':now()}
top={'selection_scope':'candidate_research','formal_kpi_eligible':False,'basis':'Exact-score paths and evidence comparison first; not a ranking of low win odds.',
 'top3':[{'rank':p['payload']['research_rank'],'match_id':p['fixture']['match_id'],'primary':p['payload']['primary'],'wdl':p['payload']['wdl'],
          'total_line':p['payload']['total_line'],'total_direction':p['payload']['total_direction'],'comprehensive_reference':p['freeze'],'reason':p['payload']['ranking_reason']} for p in ranked]}
topreceipt=save(top,batch,stage='prematch',track='top3-selection');verify(read(topreceipt['path']));all_receipts.append(topreceipt)
all_receipts.append(read(R/'nations/paired/plan-receipt.json'))
japan=read(R/'japan-revision/revision.json');all_receipts.extend([japan['freeze'],japan['research_freeze']])
for receipt in all_receipts:
 r=verify(read(receipt['path']));assert r['record_sha256']==receipt['sha256'];shutil.copy2(receipt['path'],freezes/(receipt['freeze_id']+'.json'))
write(out/'issued-analyses.json',issued);write(out/'top3.json',dict(payload=top,freeze=topreceipt));write(out/'freeze-receipts.json',all_receipts)
write(out/'status-and-scope.json',{'analysis_scope':'Configured 20 competitions plus explicit Japan-friendly revision; other friendlies returned by schedule source are discovery-only.',
 'clock_at_report':now(),'beijing_nations_kickoff':'2026-11-18 03:45','china_bahrain':'Already started at 21:00 capture; retain morning first prematch record, no new prematch.',
 'singapore_brazil':'Already complete at 21:00 capture; retain morning first prematch record, no new prematch.',
 'japan_paraguay':'Revision frozen 21:04:46 before 21:10 kickoff; now no further prematch rewrite.',
 'scope_endpoint_gaps':['kor.1','jpn.league_cup'],'nations_fixture_count':8,'current_fresh_total_coverage':8,
 'official_uefa_tiebreak_verification':'No readable rules body obtained; arithmetic facts separated from conditional H2H claims.'})
with (out/'今晚预测.csv').open('x',newline='') as h:
 w=csv.writer(h);w.writerow(['北京时间','对阵','综合第一比分','胜平负','实际总球线','大小球','研究TOP3','机构','源报价北京时间','冻结ID','状态'])
 for p in issued:
  f=p['fixture'];d=p['payload'];w.writerow([bj(f['kickoff_at']),d['name'],d['primary'],d['wdl'],d['total_line'],d['total_direction'],d['research_rank'] or '',f['total_quote']['bookmaker'],bj(f['total_quote']['quoted_at']),p['freeze']['freeze_id'],'待开赛'])
lines=['# 今晚赛事分析｜2026年11月17日夜间批次','',
 '按当前20项覆盖范围核查，主分析为北京时间**11月18日03:45的八场欧国联**，并保存11月17日日本—巴拉圭21:04临场修订。全部为成年男子、90分钟口径；精确比分、胜平负与实际盘口分别判断。', '',
 '| 对阵 | 综合第一比分 | 胜平负 | 实际大小球 | 研究优先级 |','|---|---|---|---|---|']
for p in issued:
 d=p['payload'];lines.append(f"| {d['name']} | **{d['primary']}** | {d['wdl']} | {d['total_direction']}{d['total_line']:g} | {d['research_rank'] or '普通研究'} |")
lines += ['', '**研究TOP3：乌克兰—格鲁吉亚、匈牙利—北爱尔兰、爱尔兰—科索沃。** 排序以比分路径和证据比较为先；胜平负单项中葡萄牙客胜、奥地利客胜较明确，不将这一把握转移给精确比分。所有排序已随赛前记录冻结。', '',
 '本批7场偏小、1场偏大来自不同实际盘线与逐场分布，不是统一小球权重；丹麦场小3.25和波黑场大2.75尤其接近分界。整数盘走盘、四分之一盘半赢半输分别统计，不并为全赢。', '',
 '## 模型对照与xG使用', '',
 '没有将研究候选冒充已通过验收的活动模型。原Current/Test候选在兼容源码下实际加载；原配方刷新、独立尾部分布候选、今天上午锁定的xG方案分别计算和保存。模型参数、注册表及上午的真实前向冻结保持原样。', '',
 '| 对阵 | 原Current | 原Test | 固定刷新Test | 独立候选 | 锁定xG方案 | 综合 |', '|---|---|---|---|---|---|---|']
for p in issued:
 eid=p['fixture']['source_event_id'];pa=verify(read(pairs[p['fixture']['match_id']]['path']))['payload'];fx=read(R/f'nations/fixed/{eid}.json')['payload']['predictions'];xb=read(R/f'nations/xg/{eid}.json')['payload'];sel=xb['locked_selected_arm']
 lines.append(f"| {p['payload']['name']} | {pa['current']['primary']} | {pa['test']['primary']} | {fx['fixed_test']['primary']} | {fx['challenger']['primary']} | {sel}: {xb['predictions'][sel]['primary']} | {p['payload']['primary']} |")
lines += ['', 'xG覆盖经过重新核验：148场目录映射中29场取得有效BSD统计；本批16队中14队各仅有1场9月24–25日数据，爱尔兰和科索沃0场。**没有取得本批各队11月14日最近一轮的真实xG。** 最新一轮射门、射正已逐场核查。目录有映射或has_xg不等于已取得xG，字段为空的不计覆盖。', '',
 'A组锁定方案为shotmap-75，B组为expected-75：0.75仅用于已有对应xG字段的训练进球目标混合，缺失侧回退真实进球；不是全模型75%的信息来自xG，也不是临场人为给xG75%权重。这些方案的真实未来增益尚待验证。', '',
 '乌克兰在斯洛伐克科希策，以色列在匈牙利德布勒森。ESPN仍返回neutralSite=false：原始参考保留该值，另冻结neutral=True情景，没有修改原工件或伪称原模型已处理场地冲突。', '',
 '| 场地情景 | 原xG参考均值/比分 | 不计本土主场加成 |', '|---|---|---|']
for p in issued:
 f=p['fixture']
 if not f['venue_sensitivity_required']:continue
 xb=read(R/f"nations/xg/{f['source_event_id']}.json")['payload'];sel=xb['locked_selected_arm'];a=xb['predictions'][sel];b=xb['venue_sensitivity'][sel]
 lines.append(f"| {p['payload']['name']} | {a['expected_goals'][0]:.2f}/{a['expected_goals'][1]:.2f}, {a['primary']} | {b['expected_goals'][0]:.2f}/{b['expected_goals'][1]:.2f}, {b['primary']} |")
lines += ['', '## 逐场依据与反证']
for p in issued:
 f=p['fixture'];d=p['payload'];eid=f['source_event_id'];c=choices[eid];q=f['total_quote']
 lines += ['',f"### {d['name']}：{d['primary']}／{d['wdl']}／{d['total_direction']}{d['total_line']:g}",'',c['reason'],'',f"反证：{c['counter']}",'',
  f"胜平负独立理由：{c['wdl_reason']} 反证：{c['wdl_counter']}",'',f"实际盘口判断：{c['total_reason']} 反证：{c['total_counter']}",'',
  f"候选比较：{'、'.join(c['scores'])}，仅用于比较，不是额外推荐。{c['high']}",'',f"人员：{c['personnel']}",'',f"排序：{c['priority']}",'',
  f"Nova88 / InferSports：总球{q['line']:g}，大{q['over_odds']}、小{q['under_odds']}，源报价北京时间{bj(q['quoted_at'])}，采集{bj(q['query_time'])}。只有此次同源快照，不将不同机构上午/晚间报价称为升降水或资金流。",'',
  f"综合冻结 `{p['freeze']['freeze_id']}`，{bj(p['freeze']['recorded_at'])}。"]
 for side,z in c['zero'].items():lines += ['',f"{'主队' if side=='home' else '客队'}0球/1球：{z['reason']} 反证：{z['counterevidence']}"]
lines += ['', '## 单队进球参考与概率边界','',
 '下表取锁定xG研究的原矩阵；两处第三国场地使用已单独冻结的无本土主场加成情景。均值是模型进球均值，不能称为最新实测xG。中央80%区间只反映该分布，不是保证区间。', '',
 '| 对阵/球队 | 均值 | 中央80%区间 | 0球概率 | 至少2球 | 至少3球 |','|---|---:|---|---:|---:|---:|']
for p in issued:
 f=p['fixture'];xb=read(R/f"nations/xg/{f['source_event_id']}.json")['payload'];sel=xb['locked_selected_arm'];pred=xb['venue_sensitivity'].get(sel,xb['predictions'][sel]);ts=summarize_prediction(pred)
 for side in ('home','away'):
  t=ts[side];iv=t['central_interval'];lines.append(f"| {f[side+'_name']} | {t['mean']:.2f} | {iv['lower']}–{iv['upper']} | {t['p0']:.1%} | {t['p_ge_2']:.1%} | {t['p_ge_3']:.1%} |")
lines += ['', '## 日本临场修订及已开赛场次','',
 '日本—巴拉圭在21:04:46、原定21:10开球之前追加冻结：**1-1／日本胜弱倾向／小2.75弱倾向**。与上场对巴西相比仅门将留在首发，实际更换10人；久保、堂安本场替补，镰田此前因俱乐部事务退出。当前同机构大2.5由上午1.81降到1.67是反证，新2.75均衡盘另记，不把价格变化当资金流。', '',
 '第一比分1-1与日本胜方向分别评价，后者是全部日本获胜比分合计的判断。上午11:44的2-1／日本胜／大2.5仍为首版主评价记录；本次临场修订另列，不赛后择优。', '',
 '中国—巴林在21:00核查时已经中场，新加坡—巴西已完赛：本批没有重写两场赛前预测，也没有将已知结果放进本批预测输入。', '',
 '## 证据、范围与复盘','',
 '- 20项配置中18项赛程查询成功；韩K1、日联杯接口本次返回400，保持覆盖缺口。成功响应显示本时段主范围未开赛赛事为上述八场欧国联；友谊赛额外目录保留备查，除用户已指定的日本临场场次外没有扩大模型覆盖。',
 '- 本批8场目标summary及8场最近比赛summary均有原始响应、真实查询时间及SHA256；积分表来自目标summary内嵌表，不假称另一路独立积分源。80条球队近期记录与现存历史逐分核验。',
 '- 葡萄牙平局确保积分第一、丹麦平局确保积分第二，以及奥地利/瑞典锁首、波黑固定第二均可用末轮积分直接核算。需要同分规则才能确定的威尔士名次，仅保留条件推演；本次官方UEFA规则页面未取得可读正文。',
 '- 所有实际总球采用Nova88完整两侧报价与逐行源时间；停盘、零价、时间缺失或超过时窗的报价没有被当成有效现价。',
 '- 旧/新Current/Test、固定配方、xG方案、场地情景与综合判断分别留档；全部八场未来结果待结算。精确比分、胜平负和实际盘口各自分母，TOP3另列且不替代全样本。',
 '- 活动参数和注册表未修改，没有发布环境。数据仓库保存本批原始证据、实际工件身份、矩阵、冻结、报告及本次执行脚本。','',
 '逐场赛程入口：'+ ' · '.join(f"[{choices[f['source_event_id']]['name']}](https://www.espn.com/soccer/match/_/gameId/{f['source_event_id']})" for f in fixtures), '']
(out/'今晚赛事分析.md').write_text('\n'.join(lines))
print(json.dumps({'comprehensive':len(issued),'top3':len(top['top3']),'freeze_records_copied':len(all_receipts),'top3_freeze':topreceipt,'report':str(out/'今晚赛事分析.md'),
 'latest_comprehensive_times':[bj(p['freeze']['recorded_at']) for p in issued]},ensure_ascii=False,indent=2))
