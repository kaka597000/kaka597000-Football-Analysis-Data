"""Genuine lineup revision; preserve the 11:44 first prediction unchanged."""
from datetime import datetime,timezone
import hashlib,json,sys
from pathlib import Path
import shutil
ROOT=Path(__file__).parent
OLD=Path('/workspace/WCPP/reports/internationals-20261117-1120')
CODE=Path('/workspace/Football-Analysis-xg-research-20261117')
sys.path.insert(0,str(CODE/'runtime'))
from v2.model import research_predict,aware
from research.analysis_freeze import save,verify
from research.score_distribution_audit import audit_prediction
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def now():return datetime.now(timezone.utc).isoformat()
def write(p,v):
 with Path(p).open('x') as f:json.dump(v,f,ensure_ascii=False,indent=2,allow_nan=False)

out=ROOT/'japan-revision';out.mkdir(exist_ok=True)
assert not list(out.iterdir()), 'Existing issued revision must not be overwritten'
rawpath=ROOT/'fixtures/raw/espn-401916336-summary-raw.json'
raw=read(rawpath);meta=read(rawpath.with_name('espn-401916336-summary-meta.json'))
match=raw['header']['competitions'][0]
assert match['status']['type']['state']=='pre' and not match['status']['type']['completed']
assert aware(match['date'])>aware(now())
lineups={t['team']['id']:[x['athlete']['displayName'] for x in t['roster'] if x.get('starter')] for t in raw['rosters']}
assert set(lineups)=={'627','210'} and all(len(set(x))==11 for x in lineups.values())
prev=read(OLD/'team-evidence/espn-401916337-summary-raw.json')
previous=next(t for t in prev['rosters'] if t['team']['id']=='627')
prev_xi=[x['athlete']['displayName'] for x in previous['roster'] if x.get('starter')]
assert len(set(prev_xi)&set(lineups['627']))==1
old=next(p for p in read(OLD/'publication/published-analysis.json') if p['fixture']['match_id']=='fifa.friendly:401916336')
verify(read(old['freeze']['path']))
fixture=dict(old['fixture']);fixture.update(cutoff_at=now(),confirmed_starting_lineup=True)
market=read(ROOT/'markets/japan-paraguay-raw.json');mm=read(ROOT/'markets/japan-paraguay-meta.json')
assert sha(ROOT/'markets/japan-paraguay-raw.json')==mm['sha256'] and market['event_id']=='evt_NSJZ3XGJ' and market['stale'] is False
q=next(q for q in market['odds'] if q['market_type']=='totals' and q['line']==2.75 and q['bookmaker']=='m8bet' and q['status']=='open')
assert all(v>1 for v in q['prices'].values()) and 0<=(aware(fixture['cutoff_at'])-aware(q['as_of'])).total_seconds()<3600
fixture['total_line']=2.75
fixture['total_quote']=dict(q,source_url=mm['url'],query_time=mm['query_time_utc'],source_quote_time=q['as_of'],provider='InferSports',source_sha256=mm['sha256'])
fixture['sources'] += [{'source_url':'https://site.api.espn.com/apis/site/v2/sports/soccer/fifa.friendly/summary?event=401916336','query_time':meta['received_at_utc']},
                       {'source_url':mm['url'],'query_time':mm['query_time_utc']}]
preds={}
for name in ('retained','refreshed'):
 model=read(OLD/f'derived/{name}-artifact.json')
 preds[name]=research_predict(model,fixture,model['selected_family'],model['temperature'])
 preds[name]['artifact_sha256']=sha(OLD/f'derived/{name}-artifact.json')
 preds[name]['training_data_cutoff']=model['train_end']
rr=save({'research_models':preds,'active_route':False,'formal_kpi_eligible':False,'lineup_used_numerically':False,'note':'Same numerical cores; lineup evidence is qualitative, no invented player multiplier.'},fixture,stage='prematch',track='friendly-independent-research')
fixture['cutoff_at']=now()
p=dict(old['payload'])
p.update(primary='1-1',wdl='主胜',total_direction='小',total_line=2.75,
 reason='实际首发相对上场对巴西更换10人，上午依据最近三场进攻连续性选2-1的前提明显减弱；久保建英和堂安律本场替补，镰田已离队。日本上一场8射4正进3球的高转化不宜照搬。巴拉圭由恩西索、阿尔米隆等首发，仍保留进一球路径，故综合修订为1-1。',
 counterevidence='日本替补席仍有进攻能力；M8Bet同2.5大球从上午1.81降至当前1.67，最新均衡总球2.75，市场更支持进球。轮换不等于必定小球，2-1和2-2仍为反证。',
 wdl_reason='胜平负独立仍略倾向日本：同机构三项当前1.69/3.45/3.86，历史球队强度也没有转为客胜。主胜是多个比分概率的合计；1-1为单格选择，两项分别复盘。',
 wdl_counter='10名首发更换使近期进攻连续性下降，巴拉圭近六场5胜1负；平局风险上升，不把主胜当高把握。',
 total_reason='改为实际小2.75弱倾向：刷新历史研究两球以内约53.4%，本场大范围轮换与上场高转化回落支持较低连续进攻产出。2球以内全赢，3球半输，4球以上全输；不是从1-1的两球机械推出小球。',
 total_counter='市场同线大2.5明显降价，且巴拉圭最近六场均进球；如果日本替补攻击手后段登场，三球以上仍可能。当前小2.75报价1.93不等于已验证正收益。',
 compared_scores=['1-1','2-1','1-0','2-2'],zero_vs_one={},
 three_plus_path='日本后段换入久保/堂安等、巴拉圭保持前场威胁可形成2-1或2-2；首发轮换仅降低原2-1依据，不构成统一减球参数。',
 confidence='胜平负与大小球均弱倾向',risk='市场偏大与日本后段强攻；1-1只是独立临场研究选择。',
 lineups=lineups,japan_starting_changes=10,lineup_source={'path':str(rawpath),'sha256':sha(rawpath),'meta':meta},
 supersedes_for_current_view=old['freeze'],first_primary_evaluation_reference=old['freeze'],
 independent_research_reference=rr,research_score_comparisons={n:audit_prediction(v,'1-1') for n,v in preds.items()},
 model_parameters_changed=False,player_weights_trained=False,
 source_notes={'xg':'仍未取得真实国家队xG；没有补造。','personnel':'本次ESPN已公布双方各11名首发；镰田官方离队证据沿用上午已查公告。','markets':'同机构同2.5真实报价比较；均衡2.75是不同盘线，单独记录，非资金流。'})
p['selection_evidence']={'compared_scores':p['compared_scores'],'zero_vs_one':{},'three_plus_path':p['three_plus_path'],'total_reason':p['total_reason'],
 'wdl_evidence':{'reason':p['wdl_reason'],'counterevidence':p['wdl_counter']},'total_evidence':{'reason':p['total_reason'],'counterevidence':p['total_counter']}}
rec=save(p,fixture,stage='prematch',track='comprehensive')
assert rec['evaluation_slot']=='SEPARATE_REVISION_OR_STAGE'
for receipt in (rr,rec):verify(read(receipt['path']));shutil.copy2(receipt['path'],out/(receipt['freeze_id']+'.json'))
write(out/'revision.json',{'fixture':fixture,'payload':p,'freeze':rec,'research_freeze':rr})
(out/'日本临场修订.md').write_text('# 日本—巴拉圭临场修订\n\n开球：北京时间11月17日21:10。\n\n综合第一比分改为**1-1**；胜平负仍略倾向日本胜；实际总球改为**小2.75，弱倾向**。\n\n'+p['reason']+'\n\n'+p['counterevidence']+'\n\n'+p['wdl_reason']+'\n\n'+p['total_reason']+'\n\n上午11:44首版2-1／日本胜／大2.5完整保留，仍是首版评价记录；本次只作为临场修订单列。未更改数值模型或虚构人员系数。\n\n冻结：'+rec['freeze_id']+'，'+rec['recorded_at']+'。\n')
print(json.dumps({'freeze':rec,'lineup_changes':10,'primary':'1-1','wdl':'主胜','total':'小2.75','original_preserved':old['freeze']['freeze_id']},ensure_ascii=False))
