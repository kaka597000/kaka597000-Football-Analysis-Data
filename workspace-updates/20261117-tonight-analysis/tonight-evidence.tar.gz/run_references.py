"""Execute each retained engine in its own process without bypassing identities."""
import argparse,hashlib,json,sys
from pathlib import Path
from datetime import datetime,timezone
import numpy as np
R=Path(__file__).parent
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def now():return datetime.now(timezone.utc).isoformat()
def write(p,v):
 with Path(p).open('x') as f:json.dump(v,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
ap=argparse.ArgumentParser();ap.add_argument('kind',choices=['fixed','xg']);a=ap.parse_args()
source=Path('/workspace/Football-Analysis-nations-repair-20261116' if a.kind=='fixed' else '/workspace/Football-Analysis-xg-retained-7dc5')
sys.path.insert(0,str(source/'runtime'))
from nations_league import repair,safe_cli
from nations_league.repair_forward import attach_total
from research.analysis_freeze import save,verify,digest
from research.team_goal_analysis import summarize_prediction
from research.score_distribution_audit import audit_prediction
from v2.model import rates,matrix,probabilities,total_settlement,aware
fixtures=read(R/'nations/fixtures.json');out=R/'nations'/a.kind;out.mkdir(exist_ok=False)
index=read('/workspace/WCPP/research/nations-repair-20261116/experiment-v4/candidates.json' if a.kind=='fixed' else '/workspace/WCPP/research/nations-xg-20261117/experiment/index.json')
if a.kind=='xg':
 from nations_league import xg_research as xg
result=[]
for original in fixtures:
 f=dict(original,cutoff_at=now());safe_cli.validate_future(f)
 preds={};sensitivity={}
 roles=('fixed_current','fixed_test','challenger') if a.kind=='fixed' else ('goals',index['selected'][f['league_level']])
 for role in roles:
  ref=index['routes'][f['league_level']][role];artifact=read(ref['path']);assert sha(ref['path'])==ref['sha256']
  if a.kind=='fixed':
   pred=attach_total(repair.predict(ref['path'],f))
  else:
   assert artifact['schema']=='WCPP-NATIONS-XG-ARTIFACT-1' and artifact['engine_sha256']==sha(xg.__file__)
   assert artifact['protocol_sha256']==index['protocol_sha256']
   for dep in artifact['inputs'].values():assert sha(dep['path'])==dep['sha256']
   assert aware(artifact['created_at'])<=aware(f['cutoff_at'])
   pred=xg.prediction(artifact['core'],f,ref['version'],ref['sha256'])
  pred['team_goal_analysis']=summarize_prediction(pred);pred['score_distribution_audit']=audit_prediction(pred)
  preds[role]=pred
  if f.get('venue_sensitivity_required'):
   scenario=dict(f,neutral=True)
   if a.kind=='fixed':
    m,mu,missing=repair.distribution(artifact['core'],artifact['recipe'],scenario,artifact['numeric_role'],artifact['temperature'])
   else:
    h,aw,missing=rates(artifact['core'],scenario);mu=[h,aw];m=repair.probability_matrix(h,aw)
   primary=repair.select_score(m);probs=probabilities(m)
   sp={'version':pred['version']+':neutral-sensitivity','status':'EXPLICIT_THIRD_COUNTRY_VENUE_SCENARIO',
    'source_prediction_matrix_hash':pred['matrix_hash'],'source_artifact_sha256':ref['sha256'],
    'input':scenario,'generated_at':now(),'matrix':m.tolist(),'matrix_hash':digest(m.tolist()),'primary':'-'.join(map(str,primary)),
    'expected_goals':mu,'wdl':dict(zip(['主胜','平局','客胜'],map(float,probs))),
    'formal_kpi_eligible':False,'note':'Neutral input scenario changes only the venue indicator; raw source flag and original forecasts remain untouched.'}
   sensitivity[role]=attach_total(sp)
 payload={'predictions':preds,'venue_sensitivity':sensitivity,'active_route':False,'formal_kpi_eligible':False,
          'reference_scope':'NEW_EVIDENCE_NODE_NOT_REPLACEMENT_FOR_ORIGINAL_FIRST_FREEZES','source_path':str(source),
          'retained_index_sha256':sha('/workspace/WCPP/research/nations-repair-20261116/experiment-v4/candidates.json' if a.kind=='fixed' else '/workspace/WCPP/research/nations-xg-20261117/experiment/index.json')}
 if a.kind=='xg':payload['locked_selected_arm']=index['selected'][f['league_level']]
 receipt=save(payload,f,stage='prematch',track='nations-'+a.kind+'-reference-update');verify(read(receipt['path']))
 bundle={'fixture':f,'payload':payload,'receipt':receipt};write(out/(f['source_event_id']+'.json'),bundle);result.append(bundle)
 for name,p in preds.items():print(f['home_name'],f['away_name'],name,p['primary'],[round(x,3) for x in p['expected_goals']],p['wdl'],p.get('total',{}).get('reference_direction') if p.get('total') else None)
write(out/'references.json',[{'match_id':b['fixture']['match_id'],'receipt':b['receipt']} for b in result])
