# InferSports盘口采集记录｜北京时间2026-11-17 21:00批次

共12次HTTP请求：日本–巴拉圭盘口1次、赛事目录分页2次、8场03:45欧国联盘口各1次、尼日尔–摩洛哥盘口1次。全部使用只读Bearer API；TheOdds API本批未请求；无冻结或回写旧文件。赔率查询串行进行。

赛事目录第1页覆盖到18:00Z、第2页识别出目标8场，主客和19:45Z开球与冻结映射一致。第2页中新增一个当晚成年国际赛扩展项尼日尔–摩洛哥（20:00Z）。此批不覆盖目录中全部其他低级别/青年赛事。

验收口径：逐行保存机构、市场、90分钟周期、盘线、原价、报价源时间、查询时间、状态和event stale。仅将 `open`、非陈旧、必需两/三侧齐全、正价且存在源报价时间的行标为有效；无报价时间、停盘、0价、部分报价均保留但不采用。报价时间绝不使用查询时间替代。

## Israel vs Austria（provider `evt_836VXBM7` / ESPN `401861193`）
- 北京时间开球：2026-11-18 03:45；查询UTC：2026-11-17T13:02:55.865917+00:00；HTTP 200
- 行统计：`{"1x2": {"total": 6, "accepted": 5, "invalid": 1}, "asian_handicap": {"total": 24, "accepted": 15, "invalid": 9}, "totals": {"total": 27, "accepted": 18, "invalid": 9}}`
- 原文：`evt_836VXBM7-odds-raw.json`；元数据：`evt_836VXBM7-meta.json`；逐行：`nations-league-odds-rows.jsonl (filtered by event_id)`

## Ukraine vs Georgia（provider `evt_B60JMXVP` / ESPN `401861190`）
- 北京时间开球：2026-11-18 03:45；查询UTC：2026-11-17T13:02:57.065859+00:00；HTTP 200
- 行统计：`{"1x2": {"total": 6, "accepted": 5, "invalid": 1}, "asian_handicap": {"total": 20, "accepted": 15, "invalid": 5}, "totals": {"total": 22, "accepted": 18, "invalid": 4}}`
- 原文：`evt_B60JMXVP-odds-raw.json`；元数据：`evt_B60JMXVP-meta.json`；逐行：`nations-league-odds-rows.jsonl (filtered by event_id)`

## Ireland vs Kosovo（provider `evt_G537DAY6` / ESPN `401861192`）
- 北京时间开球：2026-11-18 03:45；查询UTC：2026-11-17T13:02:57.286574+00:00；HTTP 200
- 行统计：`{"1x2": {"total": 6, "accepted": 5, "invalid": 1}, "asian_handicap": {"total": 19, "accepted": 15, "invalid": 4}, "totals": {"total": 21, "accepted": 18, "invalid": 3}}`
- 原文：`evt_G537DAY6-odds-raw.json`；元数据：`evt_G537DAY6-meta.json`；逐行：`nations-league-odds-rows.jsonl (filtered by event_id)`

## Denmark vs Norway（provider `evt_G53M1EY6` / ESPN `401861194`）
- 北京时间开球：2026-11-18 03:45；查询UTC：2026-11-17T13:02:55.137652+00:00；HTTP 200
- 行统计：`{"1x2": {"total": 6, "accepted": 5, "invalid": 1}, "asian_handicap": {"total": 25, "accepted": 17, "invalid": 8}, "totals": {"total": 31, "accepted": 19, "invalid": 12}}`
- 原文：`evt_G53M1EY6-odds-raw.json`；元数据：`evt_G53M1EY6-meta.json`；逐行：`nations-league-odds-rows.jsonl (filtered by event_id)`

## Poland vs Sweden（provider `evt_NSJMH6GJ` / ESPN `401861195`）
- 北京时间开球：2026-11-18 03:45；查询UTC：2026-11-17T13:02:56.167079+00:00；HTTP 200
- 行统计：`{"1x2": {"total": 6, "accepted": 5, "invalid": 1}, "asian_handicap": {"total": 21, "accepted": 16, "invalid": 5}, "totals": {"total": 26, "accepted": 18, "invalid": 8}}`
- 原文：`evt_NSJMH6GJ-odds-raw.json`；元数据：`evt_NSJMH6GJ-meta.json`；逐行：`nations-league-odds-rows.jsonl (filtered by event_id)`

## Hungary vs Nor.Ireland（provider `evt_VE437XS2` / ESPN `401861191`）
- 北京时间开球：2026-11-18 03:45；查询UTC：2026-11-17T13:02:56.830864+00:00；HTTP 200
- 行统计：`{"1x2": {"total": 6, "accepted": 5, "invalid": 1}, "asian_handicap": {"total": 20, "accepted": 16, "invalid": 4}, "totals": {"total": 21, "accepted": 18, "invalid": 3}}`
- 原文：`evt_VE437XS2-odds-raw.json`；元数据：`evt_VE437XS2-meta.json`；逐行：`nations-league-odds-rows.jsonl (filtered by event_id)`

## Wales vs Portugal（provider `evt_WB7XZTR6` / ESPN `401861189`）
- 北京时间开球：2026-11-18 03:45；查询UTC：2026-11-17T13:02:55.547233+00:00；HTTP 200
- 行统计：`{"1x2": {"total": 6, "accepted": 5, "invalid": 1}, "asian_handicap": {"total": 24, "accepted": 16, "invalid": 8}, "totals": {"total": 24, "accepted": 18, "invalid": 6}}`
- 原文：`evt_WB7XZTR6-odds-raw.json`；元数据：`evt_WB7XZTR6-meta.json`；逐行：`nations-league-odds-rows.jsonl (filtered by event_id)`

## Niger vs Morocco（provider `evt_YT17V9BW` / ESPN `None`）
- 北京时间开球：2026-11-18 04:00；查询UTC：2026-11-17T13:03:39.546314+00:00；HTTP 200
- 行统计：`{"1x2": {"total": 6, "accepted": 5, "invalid": 1}, "asian_handicap": {"total": 12, "accepted": 7, "invalid": 5}, "totals": {"total": 11, "accepted": 9, "invalid": 2}}`
- 原文：`evt_YT17V9BW-odds-raw.json`；元数据：`evt_YT17V9BW-meta.json`；逐行：`evt_YT17V9BW-odds-rows.jsonl`

## Bosnia vs Romania（provider `evt_YT1ZX5BW` / ESPN `401861196`）
- 北京时间开球：2026-11-18 03:45；查询UTC：2026-11-17T13:02:56.475600+00:00；HTTP 200
- 行统计：`{"1x2": {"total": 6, "accepted": 5, "invalid": 1}, "asian_handicap": {"total": 21, "accepted": 15, "invalid": 6}, "totals": {"total": 26, "accepted": 18, "invalid": 8}}`
- 原文：`evt_YT1ZX5BW-odds-raw.json`；元数据：`evt_YT1ZX5BW-meta.json`；逐行：`nations-league-odds-rows.jsonl (filtered by event_id)`

## Japan vs Paraguay（provider `evt_NSJZ3XGJ` / ESPN `401916336`）
- 北京时间开球：11月17日21:10；查询UTC：2026-11-17T13:00:56.302633+00:00；HTTP 200
- 行统计：`{"1x2": {"total": 6, "accepted": 5, "invalid": 1}, "asian_handicap": {"total": 21, "accepted": 13, "invalid": 8}, "totals": {"total": 19, "accepted": 15, "invalid": 4}}`
- 原文：`japan-paraguay-raw.json`；元数据：`japan-paraguay-meta.json`；逐行：`japan-paraguay-rows.jsonl`

## 目录与日本–巴拉圭
- `events-raw.json` / `events-meta.json`：目录第1页。
- `events-page2-raw.json` / `events-page2-meta.json`：目录第2页（包含8场目标欧国联及后续国际赛）。
- `japan-paraguay-raw.json` / `japan-paraguay-meta.json` / `japan-paraguay-rows.jsonl`：北京时间21:00:56单次临场采集。
- 原始响应SHA256、状态码、配额头在各自meta文件；认证失败响应体不保存。
