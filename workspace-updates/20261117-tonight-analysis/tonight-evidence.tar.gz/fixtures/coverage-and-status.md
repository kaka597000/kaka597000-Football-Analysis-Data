# 今晚赛事覆盖范围（截至 2026-11-18 08:00 北京时间）

查询时间：2026-11-17 13:07:19 UTC（北京时间 2026-11-17 21:07:19）

范围：成年男子、90分钟；当前查询时刻之后至明早08:00，赛前/未开赛。ESPN日期使用UTC 2026-11-17，因此本地北京时间跨到11月18日。

## 11月17日（北京时间）

- 2026-11-17 21:10｜Japan vs Paraguay｜International friendly｜场地：Singapore National Stadium｜中立场：未知｜ESPN Scheduled
- 2026-11-17 22:00｜Qatar vs South Korea｜International friendly｜场地：Abdullah bin Khalifa Stadium｜中立场：未知｜ESPN Scheduled
- 2026-11-17 22:10｜United Arab Emirates vs Syria｜International friendly｜场地：Hazza Bin Zayed Stadium｜中立场：未知｜ESPN Scheduled
- 2026-11-17 23:30｜Saudi Arabia vs Uzbekistan｜International friendly｜场地：Jassim Bin Hamad Stadium｜中立场：未知｜ESPN Scheduled

## 11月18日（北京时间凌晨）

- 2026-11-18 00:00｜Jordan vs Australia｜International friendly｜场地：Suheim bin Hamad Stadium｜中立场：未知｜ESPN Scheduled
- 2026-11-18 00:00｜Russia vs Venezuela｜International friendly｜场地：Krasnodar Stadium｜中立场：未知｜ESPN Scheduled
- 2026-11-18 00:15｜Iraq vs Iran｜International friendly｜场地：Basra International Stadium｜中立场：未知｜ESPN Scheduled
- 2026-11-18 00:30｜Kuwait vs Honduras｜International friendly｜场地：Al-Sadaqua Walsalam Stadium｜中立场：未知｜ESPN Scheduled
- 2026-11-18 03:45｜Bosnia-Herzegovina vs Romania｜2026-27 UEFA Nations League league phase, Group B4｜场地：Bilino Polje Stadium｜中立场：未知｜ESPN Scheduled
- 2026-11-18 03:45｜Denmark vs Norway｜2026-27 UEFA Nations League league phase, Group A4｜场地：Parken Stadium｜中立场：未知｜ESPN Scheduled
- 2026-11-18 03:45｜Hungary vs Northern Ireland｜2026-27 UEFA Nations League league phase, Group B2｜场地：Puskás Aréna｜中立场：未知｜ESPN Scheduled
- 2026-11-18 03:45｜Israel vs Austria｜2026-27 UEFA Nations League league phase, Group B3｜场地：Nagyerdei Stadium｜中立场：未知｜ESPN Scheduled
- 2026-11-18 03:45｜Poland vs Sweden｜2026-27 UEFA Nations League league phase, Group B4｜场地：Municipal Stadium Wroclaw｜中立场：未知｜ESPN Scheduled
- 2026-11-18 03:45｜Republic of Ireland vs Kosovo｜2026-27 UEFA Nations League league phase, Group B3｜场地：Aviva Stadium｜中立场：未知｜ESPN Scheduled
- 2026-11-18 03:45｜Ukraine vs Georgia｜2026-27 UEFA Nations League league phase, Group B2｜场地：Košická futbalová aréna (KFA)｜中立场：未知｜ESPN Scheduled
- 2026-11-18 03:45｜Wales vs Portugal｜2026-27 UEFA Nations League league phase, Group A4｜场地：Cardiff City Stadium｜中立场：未知｜ESPN Scheduled
- 2026-11-18 07:00｜Argentina vs Costa Rica｜International friendly｜场地：Mario Alberto Kempes｜中立场：未知｜ESPN Scheduled
- 2026-11-18 07:00｜Chile vs Colombia｜International friendly｜场地：Estadio Monumental David Arellano｜中立场：未知｜ESPN Scheduled
- 2026-11-18 07:30｜Ecuador vs Bolivia｜International friendly｜场地：Estadio Banco Pichincha｜中立场：未知｜ESPN Scheduled
- 2026-11-18 07:30｜Uruguay vs Dominican Republic｜International friendly｜场地：Estadio Domingo Burgueño Miguel｜中立场：未知｜ESPN Scheduled

## 单独核对的友谊赛状态

- Japan vs Paraguay（401916336）：STATUS_SCHEDULED，开球 2026-11-17 21:10 BJT。
- China vs Bahrain（401930880）：STATUS_HALFTIME，开球 2026-11-17 20:00 BJT。
- Singapore vs Brazil（401916335）：STATUS_FULL_TIME，开球 2026-11-17 18:00 BJT。

## 完整性与来源限制

- ESPN 单日 scoreboard 对20赛事：18个HTTP 200；韩K1、日联杯HTTP 400。已成功响应的项目按赛事代码保存原始JSON、UTC查询时间、HTTP状态和SHA-256。
- 20个 `dates=20261117-20261118` range 请求均HTTP 400；未重复该错误参数。全球 scoreboard 路径两次HTTP 404。HTTP请求总计48：首批29、后续19（单日已成功赛事复用，不重发）。
- 已单独查询 `fifa.friendly` scoreboard，作为三场关注友谊赛与同日国际友谊赛覆盖补充（不属于analysis-scope.json 20项代码）。中立场未由ESPN明确给出的条目标“未知”。日本—巴拉圭为特殊源冲突：ESPN新summary中neutralSite=false，但JFA先前官方证据确认新加坡为中立场。
- 赛程按ESPN单日成功响应核查；中韩与日联杯对应项HTTP 400仍是覆盖缺口，对全范围不作完整无缺口断言。
