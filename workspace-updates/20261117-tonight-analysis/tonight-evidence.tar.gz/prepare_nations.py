"""Audit fresh evidence and prepare the eight genuinely future Nations matches."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,math,sys
R=Path(__file__).parent
S=Path('/workspace/Football-Analysis-xg-research-20261117')
sys.path.insert(0,str(S/'runtime'))
from research_program.future_validation import quote_audit
from nations_league.safe_cli import validate_future
from v2.model import aware
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):
 with Path(p).open('x') as f:json.dump(x,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
def now():return datetime.now(timezone.utc).isoformat()

out=R/'nations';out.mkdir(exist_ok=False)
old=read('/workspace/WCPP/research/nations-xg-20261117/future-prepared.json')
quotes={}
for f in (R/'markets').glob('evt_*-meta.json'):
 m=read(f)
 if not m.get('espn_event_id'):continue
 rawfile=f.with_name(f.name.replace('-meta','-odds-raw'));assert sha(rawfile)==m['sha256']
 quotes[m['espn_event_id']]=(read(rawfile),m)
fixtures=[];contexts=[]
xgs=read('/workspace/WCPP/research/nations-xg-20261117/data/xg-records.json')['rows']
history={r['match_id']:r for r in read('/workspace/WCPP/research/nations-xg-20261117/canonical-history.json')}
lines={'401861189':3.25,'401861190':2.25,'401861191':2.,'401861192':2.,'401861193':3.,'401861194':3.25,'401861195':3.25,'401861196':2.75}
for original in old:
 f={k:v for k,v in original.items() if k not in ('total_quote','market_attachment','market_snapshots')}
 eid=f['source_event_id'];p=R/f'context/raw/espn-summary-{eid}.json';m=read(p.with_suffix('.json.meta.json'));raw=read(p)
 assert sha(p)==m['sha256'] and m['status']==200
 f['cutoff_at']=now();f['phase_evidence']={'source_path':str(p),'source_url':m['url'],'source_sha256':m['sha256'],'query_time':m['completed_at']}
 validate_future(f)
 mr,mm=quotes[eid];assert not mr['stale'] and mr['event_id']==mm['provider_event_id']
 q=next(q for q in mr['odds'] if q['bookmaker']=='nova88' and q['market_type']=='totals' and q['line']==lines[eid] and q['status']=='open')
 assert q['period']=='full_time' and q['format']=='decimal'
 f['total_quote']={'verified':True,'match_id':f['match_id'],'bookmaker':q['bookmaker'],'market':'asian_total',
  'line':q['line'],'over_odds':q['prices']['over'],'under_odds':q['prices']['under'],'quoted_at':q['as_of'],'query_time':mm['query_time_utc'],
  'source_url':mm['url'],'source_sha256':mm['sha256'],'provider':'InferSports','provider_event_id':mr['event_id']}
 assert quote_audit(f)['eligible'],quote_audit(f)
 wdl=[q for q in mr['odds'] if q['market_type']=='1x2' and q['status']=='open' and set(q['prices'])=={'home','draw','away'} and all(x>1 for x in q['prices'].values())
      and 0<=(aware(f['cutoff_at'])-aware(q['as_of'])).total_seconds()<=3600]
 wdl.sort(key=lambda q:(q['bookmaker']!='nova88',-aware(q['as_of']).timestamp()))
 assert wdl
 f['wdl_quote']=dict(wdl[0],provider='InferSports',source_url=mm['url'],query_time=mm['query_time_utc'],source_sha256=mm['sha256'])
 venue=raw['gameInfo']['venue'];f['venue']=venue
 f['venue_sensitivity_required']=eid in ('401861190','401861193')
 f['venue_note']='Third-country designated home venue; retain provider flag in original engine, compare neutral=True separately.' if f['venue_sensitivity_required'] else 'No detected venue-country contradiction'
 ctx={'match_id':f['match_id'],'teams':[],'venue':venue,'source':f['phase_evidence'],'standings':[]}
 for group in raw['standings']['groups']:
  for e in group['standings']['entries']:
   st={x['name']:x.get('value',x.get('displayValue')) for x in e['stats']}
   assert int(st['points'])==3*int(st['wins'])+int(st['ties'])
   ctx['standings'].append({'team':e['team'],'id':'espn:'+e['id'],'stats':st})
 for t in raw['lastFiveGames']:
  tid='espn:'+str(t['team']['id']);games=[]
  for g in t['events']:
   if g.get('competitionName')!='2026-27 UEFA Nations League' or g.get('roundName')!='League Phase':continue
   mid='espn:'+str(g['id']);h='espn:'+str(g['homeTeamId']);a='espn:'+str(g['awayTeamId'])
   assert tid in (h,a) and aware(g['gameDate'])<aware(f['cutoff_at'])
   gf,ga=map(int,(g['homeTeamScore'],g['awayTeamScore']) if tid==h else (g['awayTeamScore'],g['homeTeamScore']))
   r=history[mid];assert r['home']==h and r['away']==a and (r['home_goals'],r['away_goals'])==(int(g['homeTeamScore']),int(g['awayTeamScore']))
   games.append({'match_id':mid,'kickoff_at':g['gameDate'],'gf':gf,'ga':ga,'home':tid==h,'opponent':g['opponent']['displayName'],'opponent_id':'espn:'+str(g['opponent']['id'])})
  assert len(games)==5
  games.sort(key=lambda g:g['kickoff_at']);latest=games[-1]
  lf=R/f"context/raw/espn-summary-{latest['match_id'].split(':')[1]}.json";lb=read(lf);lm=read(lf.with_suffix('.json.meta.json'))
  assert sha(lf)==lm['sha256'] and lb['header']['competitions'][0]['status']['type']['completed'] is True
  stats={}
  for b in lb.get('boxscore',{}).get('players',[]):
   if 'espn:'+str(b['team']['id'])==tid:stats={z['name']:z.get('displayValue',z.get('value')) for z in b.get('statistics',[])}
  if not stats:
   for b in lb.get('boxscore',{}).get('teams',[]):
    if 'espn:'+str(b['team']['id'])==tid:stats={z['name']:z.get('displayValue',z.get('value')) for z in b.get('statistics',[])}
  validx=[]
  for x in xgs:
   if tid not in (x['home'],x['away']):continue
   vals=x.get('values',{})
   if not all(len(vals.get(k,[]))==2 and all(type(v) in (int,float) and math.isfinite(v) and v>=0 for v in vals[k]) for k in ('expected','actual','shotmap')):continue
   assert x['quality']['status']=='STATS_CAPTURED' and sha(x['source_path'])==x['source_sha256']
   side=0 if tid==x['home'] else 1
   validx.append({'match_id':x['match_id'],'kickoff_at':x['kickoff_at'],'expected_for':vals['expected'][side],'expected_against':vals['expected'][1-side],
                  'actual_for':vals['actual'][side],'actual_against':vals['actual'][1-side],'shotmap_for':vals['shotmap'][side],'shotmap_against':vals['shotmap'][1-side],
                  'quality':x['quality'],'source_path':x['source_path'],'source_sha256':x['source_sha256'],'observed_at':x['observed_at']})
  reds=[e for e in lb.get('keyEvents',[]) if 'red' in str(e.get('type',{})).lower() and 'espn:'+str(e.get('team',{}).get('id'))==tid]
  ctx['teams'].append({'id':tid,'name':t['team']['displayName'],'games':games,'summary':{'n':5,'W':sum(g['gf']>g['ga'] for g in games),'D':sum(g['gf']==g['ga'] for g in games),'L':sum(g['gf']<g['ga'] for g in games),'GF':sum(g['gf'] for g in games),'GA':sum(g['ga'] for g in games)},
    'latest_process':stats,'latest_process_source':{'path':str(lf),'sha256':lm['sha256'],'query_time':lm['completed_at']},'latest_red_events':reds,'actual_xg_rows':validx})
 contexts.append(ctx);fixtures.append(f)
write(out/'fixtures.json',fixtures);write(out/'verified-context.json',contexts)
write(out/'source-identity.json',{'preparation_time':now(),'source_commit':'29c9701821367034b46fb6d86683e57e31f02262','old_pair_source':'/workspace/Football-Analysis',
  'xg_retained_engine_commit':'7dc5d0f9a64185dd16e44e45b59385990d12f331','xg_research_index':'/workspace/WCPP/research/nations-xg-20261117/experiment/index.json',
  'fresh_total_quotes':len(fixtures),'venue_scenarios':['espn:401861190','espn:401861193'],'form_rows_rechecked':sum(len(t['games']) for c in contexts for t in c['teams']),
  'actual_xg_team_rows':{t['name']:len(t['actual_xg_rows']) for c in contexts for t in c['teams']}})
print(json.dumps(read(out/'source-identity.json'),ensure_ascii=False,indent=2))
