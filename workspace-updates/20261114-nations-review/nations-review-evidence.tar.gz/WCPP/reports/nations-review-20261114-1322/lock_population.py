import json,hashlib,sys
from datetime import datetime,timezone
from pathlib import Path
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from research.analysis_freeze import verify,save
R=Path(__file__).resolve().parent
P=Path('/workspace/WCPP/reports/nations-prematch-20261113-2118')
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def receipt(record,path):return {'path':str(path),'sha256':record['record_sha256'],'freeze_id':record['freeze_id'],'recorded_at':record['recorded_at'],'evaluation_slot':record['evaluation_slot']}
d=read(P/'delivery-final.json')
for ref in d['all_receipts']:assert verify(read(ref['path']))['record_sha256']==ref['sha256']
items=[]
for entry in read(P/'analysis-records.json'):
 f=entry['fixture'];comp=verify(read(entry['comprehensive_receipt']['path']));assert comp['evaluation_slot']=='FIRST_PREMATCH'
 p=Path(entry['candidate_receipt']['path']);first=p.parent/'000001.json';r=verify(read(first));assert r['evaluation_slot']=='FIRST_PREMATCH' and r['match_id']==f['match_id']
 items.append({'fixture':f,'name':comp['payload']['name'],'comprehensive':entry['comprehensive_receipt'],'candidate_first':receipt(r,first),'candidate_revision':entry['candidate_receipt'],'active_refusal':entry['active_receipt']})
assert len(items)==10 and len({x['fixture']['match_id'] for x in items})==10
v={'locked_at':datetime.now(timezone.utc).isoformat(),'scope':'exact 10 fixtures in 20261113 evening delivered report; no result data read before this lock','population':items,'top3_receipt':d['top3_receipt'],'top3':verify(read(d['top3_receipt']['path']))['payload']['top3'],'prematch_delivery_file_sha256':sha(P/'delivery-final.json'),'prematch_report_receipt':d['report_receipt'],'source_commit':'1257fdde7b6746b7ba6d2aa919382214a2cfb589','active_registry_sha256':sha('/workspace/WCPP/runtime/active-model.json'),'counts':{'population':10,'comprehensive_primary':9,'comprehensive_wdl':9,'comprehensive_totals':8,'top3':3}}
with (R/'population-lock.json').open('x') as h:json.dump(v,h,ensure_ascii=False,indent=2)
shell={'match_id':'nations-review-batch:20261113-evening','cohort':'uefa.nations','kickoff_at':min(x['fixture']['kickoff_at'] for x in items),'cutoff_at':v['locked_at']}
ref=save(v,shell,stage='review',track='review-population-lock')
with (R/'population-lock-receipt.json').open('x') as h:json.dump(ref,h,ensure_ascii=False,indent=2)
print(json.dumps({'locked_at':v['locked_at'],'population':10,'freeze':ref},ensure_ascii=False))
