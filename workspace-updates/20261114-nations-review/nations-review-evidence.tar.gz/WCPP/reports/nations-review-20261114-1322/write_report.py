import json,csv
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
R=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())
m=read(R/'metrics.json');ps={x['match_id']:x for x in read(R/'verified-process.json')};results={x['match_id']:x for x in read(R/'verified-results.json')};lock=read(R/'population-lock.json');direction=read(R/'direction-diagnostics.json')
labels={'win':'全赢','half_win':'半赢','push':'走盘','half_loss':'半输','loss':'全输',None:'观望'}
notes={
'401861162':('摩尔多瓦2-1哈萨克斯坦','比分1-1与平局均错，大2全赢。两边射正均5次，主队77分钟再次领先，比赛有相互得分路径但并未停在平局。哈萨克斯坦红牌发生90+4分钟，晚于制胜球，不能用红牌解释77分钟进球。','赛前已记录主队前次客场2-1、但因为整体接近仍选平；相近实力不意味着平局边际概率最大。2-1虽在备选里，不能计第一比分命中。'),
'401861155':('安道尔2-0直布罗陀','比分及胜平负保持弃权，不补计主胜命中。小1.75在2球时半输。双方均8次射门，但安道尔射正3次、对手1次，主队24/35分钟连进两球。','低总球倾向不代表低盘口安全；1.75对恰好2球已有半输风险。不能赛后因为热门赢球就宣称当时应无条件跟随低赔。'),
'401861157':('保加利亚0-5冰岛','1-1、平局和小2.5全部失败。冰岛16射7正，保加利亚9射2正；17分钟点球、21分钟再进，52分钟保加利亚球员乌龙令冰岛3-0，之后还有两球。无红牌。','赛前过度依赖冰岛上一场0-0/1次射正及保加利亚上一场2-0的反向材料，未给本届冰岛进7失1、保加利亚前次0-3足够重视。两候选共同1-1不构成平局方向的充分依据。点球与乌龙均计入真实90分钟赛果，不剔除美化指标。'),
'401861153':('列支敦士登0-1阿塞拜疆','唯一综合比分命中，客胜及小2.25也命中。列支5射0正，阿塞拜疆29射11正，26分钟进球；列支扑救字段10次与11次被射正/失1球一致。','主队零进球路径获得过程支持；客队只进1球也包含机会转化与扑救影响。没有xG，不能凭1-0就证明客队只应进1球，更不能据一次命中证明TOP3排序可靠。'),
'401861154':('卢森堡0-1爱沙尼亚','1-1与平局均错，大小球原观望。卢森堡8射3正，爱沙尼亚10射5正，42分钟取得唯一进球。','赛前卢森堡本届两个主场0进球、4场3次零进球，爱沙尼亚3次零封；用卢森堡上一场18射7正支持本场必有一球过于乐观。单场机会数量不能直接抵消连续低产及对手防守证据。'),
'401861159':('荷兰7-0希腊','主胜命中，2-1比分错误，大小球原观望。荷兰17射13正、希腊9射1正；6至40分钟已5-0，61分钟成为7-0。没有红牌、点球或乌龙事件。','漏掉的是强弱失衡与大比分尾部，以及客队零进球路径；不是只把2-1加一球即可修正。赛前希腊不败与荷兰此前失球让综合保留客队1球，但本场过程并不支持这一外推。没有真实xG，不能将7球全部归结为机会质量，也不能全部叫运气。'),
'401861161':('苏格兰2-1北马其顿','主胜命中，2-0比分错误；小3走盘，不算全赢。苏格兰18射6正、北马7射2正；54分钟主队领先，57分钟客队角球后头球追平，74分钟主队点球制胜。','北马前4场零进球并不能排除定位球进球，赛前反证已有“只需一次定位球”。主队两球判断正确，失误在零封选择。本场扑救总数与射正/进球不一致，不用它推算门将发挥。'),
'401861158':('塞尔维亚1-3德国','客胜命中，1-2比分错误，小3.25全输。德国22射6正、塞尔维亚5射3正；3分钟塞尔维亚球员乌龙，德国14/50分钟再进，56分钟塞尔维亚扳成1-3。','塞尔维亚76/89分钟两张红牌均在1-3形成之后，不能把前三个失球归因于少打人。赛前以德国此前4场仅进3球压低总球，未充分保留早球改变比赛状态的路径；乌龙不能删掉以追认1-2命中。'),
'401861160':('斯洛伐克2-2法罗群岛','2-1和主胜错误，大2.5全赢。斯洛伐克14射5正、法罗10射4正；主队17分钟领先，法罗30分钟点球、47分钟再进，主队74分钟扳平。','法罗此前四连平及持续进球是已知反证，赛前虽披露却仍列TOP3主胜；本场风险实际发生。大球判断不证明主胜或第一比分判断正确，不能三项混为一个推荐成绩。'),
'401861156':('斯洛文尼亚0-0瑞士','1-2、客胜与大2全部失败。瑞士71.3%控球、13射3正，主队8射2正，全场无进球。','赛前瑞士4战全胜、进11球被外推过强；斯洛文尼亚本届两个主场均零封的反证未充分落实。控球或角球多不等于高质量机会，缺xG不能断言瑞士“必应进2球”。本场扑救字段与射正有冲突，门将质量归因保留未知。')}
lines=['# 欧国联赛后复盘｜北京时间2026年11月14日','',
'本次复盘欧洲11月13日比赛日、北京时间11月14日01:00/03:45开球的原定10场。全部已完成90分钟；比赛名单与各轨首次/修订冻结在本次读取赛果前已锁定。结果采集北京时间13:24—13:26，来源与核验见下文。',
'本轮综合第一比分只有1/9命中，胜平负4/9。失败必须按原推荐承认；备选比分、不同版本及事后好看的指标均不补命中。','',
'## 结算总表','', '|项目|有效推荐／全部10场|结果|准确率口径|','|---|---|---|---|',
'|综合第一比分|9/10，1场弃权|1中、8错|1/9＝11.1%；整批命中覆盖1/10|',
'|综合胜平负|9/10，1场观望|4中、5错|4/9＝44.4%|',
'|综合实际盘口大小球|8/10，2场观望|3全赢、0半赢、1走盘、1半输、3全输|严格全赢率3/7＝42.9%，走盘剔除、半输保留|',
'|原定TOP3第一比分|3/3|1中、2错|1/3＝33.3%|',
'|原定TOP3胜平负|3/3|2中、1错|2/3＝66.7%|',
'|原定TOP3大小球|3/3|2全赢、1走盘|非走盘仅2场，2/2；不包装为稳定100%或已达标|','',
'综合比分的Wilson 95%描述区间约2.0%—43.5%，胜平负约18.9%—73.3%；小样本不能证明稳定能力。没有达到第一比分70%、方向/大小球80%的证明。','',
'|对阵|原综合比分|90分钟赛果|比分|原胜平负|方向|原实际盘口|结算|','|---|---|---|---|---|---|---|---|']
for r in m['comprehensive']['rows']:
 lines.append('|'+ '|'.join([r['name'],r['primary'] or '观望',r['actual'],'中' if r['primary_hit'] else '弃权' if r['primary_hit'] is None else '错',r['wdl'],'中' if r['wdl_hit'] else '观望' if r['wdl_hit'] is None else '错',f"{r['total_direction']}{r['total_line']:g}",labels[r['total_settlement']]])+'|')
lines+=['','盘口均保留赛前Pinnacle实际线及两侧价格，来源报价时间为北京时间11月13日21:20:52。安道尔小1.75遇到2球是半输；苏格兰小3遇到3球是走盘；德国场小3.25遇到4球是全输。均按原线结算，不改成常用2.5。','',
'## 模型与人工判断分开','',
'活动Current/Test原本没有欧国联已验收路由，本轮两边均10/10拒绝，无有效预测，不记为“0/10预测全错”。以下是四个等级各自独立的研究候选，首版冻结于11月10日；昨晚v2只补充当时证据，两边10场矩阵及工件哈希均与首版一致，成绩相同、比赛分母不翻倍。','',
'|等级／本轮场次|Current候选比分|Test候选比分|Current候选胜平负|Test候选胜平负|','|---|---|---|---|---|']
for level in ['A','B','C','D']:
 c=m['candidate_models']['first']['models']['当前模型']['by_version'][f'WCPP-NATIONS-{level}-CURRENT-0.1'];t=m['candidate_models']['first']['models']['test模型']['by_version'][f'WCPP-NATIONS-{level}-TEST-0.1'];n=c['population'];lines.append(f"|{level}／{n}|{c['primary_hits']}/{n}|{t['primary_hits']}/{n}|{c['wdl_hits']}/{n}|{t['wdl_hits']}/{n}|")
lines+=['','这10场的候选命中数合计：Current比分0场、方向4场；Test比分1场、方向5场。这是本批不同等级模型的数量汇总，不将它们当一个版本的统一准确率。候选没有冻结唯一大小球方向；即使v2保存了盘口及两边结算概率，也不能赛后择一边统计模型大小球命中率。','',
'|同场9个已给综合比分／方向的比赛|相对Current候选|相对Test候选|','|---|---|---|',
'|综合精确比分净增|改对1场、改错0场，净+1|改对0场、改错0场，净0|',
'|综合胜平负净增|综合4中，对照3中，净+1|综合4中，对照5中，净−1|','',
'人工改分尚无稳定增益证明。相对Current比分净增率的描述性配对bootstrap区间为0—33.3%；相对Test本批所有命中差值为0，bootstrap会退化，不能据此证明两者未来等效。两项差异符号检验p均为1。',
'三个综合平局推荐全部失败。本轮每个综合方向恰好与所选点比分方向一致；这不证明代码错误，但提示需独立审查胜平负边际，不能把1-1联合众数顺带当成最有把握的平局。冰岛场Test原方向是客胜，综合改为平局后少中1场。','',
'## 逐场过程与错误来源','']
for r in m['comprehensive']['rows']:
 title,text,lesson=notes[r['match_id'].split(':')[-1]];p=ps[r['match_id']];rr=results[r['match_id']]
 lines+=['### '+title,'',text,'',lesson,'',f"来源：[ESPN比赛记录]({rr['source_url']})；综合原冻结 `{r['freeze_id']}`。"]
lines+=['','## 分布诊断与累计证据','',
'本批实际主队平均1.60球、客队1.40球，总均值3.00球。Current预测均值约1.33/1.12，总2.45；Test约1.15/1.17，总2.31。实际≥4球4/10，候选平均尾部概率约23.3%/20.7%，这批存在大比分尾部偏低。',
'但同时有7个球队零进球（主队4/10、客队3/10）及一场0-0。问题包含强弱分化与分布形状，不能通过统一加λ、强迫提高比分或减少1-1来修正。两候选中央80%离散区间本批主客各覆盖9/10，但区间较宽，这不证明比分准确或校准已通过。',
'Current候选本来就是等级均值＋主场基线，不含球队攻防；本轮10个众数全部1-1是配方结果，不是已发现球队参数加载失败。Test有球队攻防但分化有限；“收缩过强或尾部不足”仅登记为待检验假设，不能凭7-0/0-5单场就调参数。','',
'累计只合并此前已复盘8场与本次10场的独立首次候选冻结，共18场，按同版本及等级分列：','',
'|等级／累计场次|Current比分命中|Test比分命中|Current方向命中|Test方向命中|','|---|---|---|---|---|']
for level in ['A','B','C','D']:
 c=m['cumulative_first_candidates_18']['models']['当前模型']['by_version'][f'WCPP-NATIONS-{level}-CURRENT-0.1'];t=m['cumulative_first_candidates_18']['models']['test模型']['by_version'][f'WCPP-NATIONS-{level}-TEST-0.1'];n=c['population'];lines.append(f"|{level}／{n}|{c['primary_hits']}/{n}|{t['primary_hits']}/{n}|{c['wdl_hits']}/{n}|{t['wdl_hits']}/{n}|")
lines+=['','各等级数量和证据均不足以完成已登记的前向验收，不晋级。此前8场与本批人工方法版本不同，人工准确率不混合声称单一方法效果。','',
'## 数据核验与本次调整决定','',
'ESPN同日赛程与10份summary全部一致；每场FT/post/completed且两个半场比分相加证明90分钟。The Odds API的同一已冻结事件ID、双方球队和比分全部匹配；其中苏格兰、斯洛伐克、斯洛文尼亚三场的该来源开球字段较原冻结分别晚1、1、2分钟，单列元数据差异，不回写原赛程。第二来源只用于比分交叉核对，90分钟证据来自ESPN分段。',
'30个进球逐事件按比分增量、球员ID在本场名单所属队及header detail核验；包含2个乌龙、3个点球。乌龙受益队是冰岛/德国，球员所属队是保加利亚/塞尔维亚。没有把FotMob专用适配器套到ESPN伪造结构。',
'三场boxscore.penaltyKickGoals=0与双事件字段相反，按已核实点球事件描述，同时保留冲突原文。苏格兰、斯洛文尼亚各有扑救数与射正/进球不一致，不据此计算扑救率或门将贡献。没有任何可信本场xG字段，射门不能替代xG。',
'上一轮发布脚本把市场名保留为提供方totals，标准quote_audit只识别standard_total/asian_total。此次先逐项核验原始报价、比赛ID、两侧价格、时间和哈希，再仅在复盘审计副本显式映射为standard_total（既有market_bridge的同源映射），未改冻结、盘口或方向，也未补抓新盘口。后续发布应使用既有市场桥接器，避免手工标签不一致。','',
'决定：保持活动注册表与全部候选参数；补数据继续观察，候选不晋级。已执行事项是独立方向审计、事件/聚合字段冲突标记及真实线五类结算，非新训练或效果改进证明。',
'下一次检查在下一批预先锁定的比赛结算时进行：继续分别比较唯一综合Primary与两候选的同场净增、胜平负独立改判及零球/高比分尾部；人员与xG缺口优先补齐。若启动收缩/分布或选分实验，须事先固定配方和时间隔离，当前18场已经看过、不得再称全新未见验证。',
'原始预赛冻结、首版/修订版、待定项、失误、红牌、乌龙均保留；没有发布环境或重写历史。','',
'## 原定TOP3复盘（保持原排名）','', '|原排名|对阵|原唯一比分→赛果|胜平负|原大小球与结算|','|---|---|---|---|---|']
for r in m['top3']['rows']:lines.append(f"|{r['rank']}|{r['name']}|{r['primary']} → {r['actual']}|{r['wdl']}：{'中' if r['wdl_hit'] else '错'}|{r['total_direction']}{r['total_line']:g}：{labels[r['total_settlement']]}|")
lines+=['','TOP3为原赛前的研究参考排序，比分1/3、方向2/3、大小球2全赢1走盘；不根据赛果换名次，不替代完整10场成绩。','',
'复算文件：`population-lock.json`、`verified-results.json`、`verified-process.json`、`quote-review-audit.json`、`metrics.json`、`direction-diagnostics.json`、`verification.json`；源码版本`1257fdde7b6746b7ba6d2aa919382214a2cfb589`。','']
with (R/'review.md').open('x') as h:h.write('\n'.join(lines))
with (R/'复盘展示.csv').open('x',encoding='utf-8-sig',newline='') as h:
 w=csv.writer(h);w.writerow(['比赛','原综合比分','90分钟赛果','比分命中','原胜平负','方向命中','原实际总球线','大小方向','五类结算','综合冻结ID'])
 for r in m['comprehensive']['rows']:w.writerow([r['name'],r['primary'] or '观望',r['actual'],r['primary_hit'],r['wdl'],r['wdl_hit'],r['total_line'],r['total_direction'],labels[r['total_settlement']],r['freeze_id']])
decision={'decision':'KEEP_PARAMETERS_SUPPLEMENT_DATA_CONTINUE_FORWARD_VALIDATION','promote':False,'retrain':False,'reason':'Primary 1/9; no net Primary gain versus Test; WDL net -1 versus Test; tiny grade samples and missing xG; avoid outcome-driven global goal adjustment','implemented_review_repairs':['score-delta + player-roster ID own-goal ownership verification','penalty aggregate conflicts retained','independent WDL audit','source-bound explicit provider-market label mapping only in review copy'],'next_check':'next fully preregistered batch settlement, complete population and unchanged first-freeze accounting','experimental_hypotheses':['team-strength shrinkage too strong','joint score tail shape and asymmetric dominance','manual draw/clean-sheet selection'], 'experiment_status':'NOT_RUN; no claimed training or gain','current_seen_matches':18,'per_grade_seen':{'A':6,'B':2,'C':8,'D':2},'no_retrospective_selection':True}
with (R/'review-decision.json').open('x') as h:json.dump(decision,h,ensure_ascii=False,indent=2)
print(str(R/'review.md'))
