"""Read only original freezes/results; separate tracks, versions and denominators."""
import json,hashlib,math,sys
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import numpy as np
sys.path[:0]=['/workspace/Football-Analysis/runtime','/workspace/Football-Analysis/runtime/v5','/workspace/Football-Analysis/runtime/optimization']
from research.analysis_freeze import verify,aware
from research.team_goal_analysis import summarize_prediction,review as goal_review
from research_program.future_validation import check_matrix
from research_program.selection_review import compare
from v5.paired_review import review
from v2.model import total_settlement
from optimization.evaluate import settle_ou
from research_program.nations_phase import verify_period_scores
R=Path(__file__).resolve().parent
P=Path('/workspace/WCPP/reports/nations-prematch-20261113-2118')
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):
 with Path(p).open('x') as h:json.dump(x,h,ensure_ascii=False,indent=2,allow_nan=False)
lock=read(R/'population-lock.json');results=read(R/'verified-results.json');res={r['match_id']:r for r in results}
assert len(res)==10 and set(res)=={i['fixture']['match_id'] for i in lock['population']}
def record(item,key):
 ref=item[key];r=verify(read(ref['path']));assert r['record_sha256']==ref['sha256'];return r
def actual(mid):
 r=res[mid];h,a=r['home_goals'],r['away_goals'];return f'{h}-{a}',('主胜' if h>a else '客胜' if h<a else '平局')
def settle(mid,line,direction):
 side={'大':'over','小':'under'}.get(direction)
 if side is None:return None
 r=res[mid];m=np.zeros((51,51));m[r['home_goals'],r['away_goals']]=1
 out=next(k for k,v in total_settlement(m,line,side).items() if v==1.)
 assert {'win':'FULL_WIN','half_win':'HALF_WIN','push':'PUSH','half_loss':'HALF_LOSS','loss':'FULL_LOSS'}[out]==settle_ou(r['home_goals']+r['away_goals'],line,side)
 return out
def wilson(h,n):
 if not n:return None
 z=1.959963984540054;p=h/n;den=1+z*z/n;v=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den;c=(p+z*z/(2*n))/den;return [c-v,c+v]
def counts(rows):
 ph=[r['primary_hit'] for r in rows if r['primary_hit'] is not None];wh=[r['wdl_hit'] for r in rows if r['wdl_hit'] is not None];t=Counter(r['total_settlement'] for r in rows if r['total_settlement'] is not None);n=sum(t.values());non=n-t['push'];pop=len(rows)
 return {'population':pop,'settled':pop,'pending':0,'primary_n':len(ph),'primary_hits':sum(ph),'primary_accuracy':sum(ph)/len(ph) if ph else None,'primary_coverage':len(ph)/pop,'primary_abstentions':pop-len(ph),'primary_hits_over_population':sum(ph)/pop,'primary_wilson_95':wilson(sum(ph),len(ph)),'wdl_n':len(wh),'wdl_hits':sum(wh),'wdl_accuracy':sum(wh)/len(wh) if wh else None,'wdl_coverage':len(wh)/pop,'wdl_wilson_95':wilson(sum(wh),len(wh)),'total_n':n,'total_coverage':n/pop,'total_non_push_n':non,'total_strict_full_win_rate':t['win']/non if non else None,'total_settlements':{k:t[k] for k in ['win','half_win','push','half_loss','loss']}}
comp=[];activity=[];pairs={'first':[],'revision':[]};same=[]
for i in lock['population']:
 mid=i['fixture']['match_id'];c=record(i,'comprehensive');p=c['payload'];score,wdl=actual(mid)
 assert c['evaluation_slot']=='FIRST_PREMATCH' and c['stage']=='prematch'
 comp.append({'match_id':mid,'name':i['name'],'league_level':i['fixture']['league_level'],'actual':score,'primary':p['primary'],'primary_hit':p['primary']==score if p['primary'] is not None else None,'wdl':p['wdl'],'wdl_hit':p['wdl']==wdl if p['wdl'] in ['主胜','平局','客胜'] else None,'total_line':p['total_line'],'total_direction':p['total_direction'],'total_settlement':settle(mid,p['total_line'],p['total_direction']),'freeze_id':c['freeze_id'],'record_sha256':c['record_sha256'],'actual_quote':p['actual_quote']})
 a=record(i,'active_refusal');activity.append({'match_id':mid,'current_model':a['payload']['current_model'],'test_model':a['payload']['test_model']})
 first=record(i,'candidate_first');rev=record(i,'candidate_revision');assert first['evaluation_slot']=='FIRST_PREMATCH' and rev['evaluation_slot']=='SEPARATE_REVISION_OR_STAGE'
 for tag,r in [('first',first),('revision',rev)]:
  for role in ['current','test']:check_matrix(r['payload'][role])
  pairs[tag].append({'match_id':mid,'current_model':r['payload']['current'],'test_model':r['payload']['test']})
 same.append({'match_id':mid,'matrix_identity':{role:first['payload'][role]['matrix_hash']==rev['payload'][role]['matrix_hash'] for role in ['current','test']},'artifact_identity':{role:first['payload'][role]['artifact_sha256']==rev['payload'][role]['artifact_sha256'] for role in ['current','test']},'first_receipt':i['candidate_first'],'revision_receipt':i['candidate_revision']})
active_review=review(activity,results);candidate_reviews={k:review(v,results) for k,v in pairs.items()}
topfrozen=verify(read(lock['top3_receipt']['path']));assert topfrozen['record_sha256']==lock['top3_receipt']['sha256'];top=[]
for rank,t in enumerate(topfrozen['payload']['top3'],1):
 row=next(r for r in comp if r['match_id']==t['match_id']);assert t['rank']==rank
 for k in ['primary','wdl','total_line','total_direction']:assert t[k]==row[k]
 top.append(dict(row,rank=rank))
active_comparison=compare([{'comprehensive':record(i,'comprehensive'),'pair':record(i,'active_refusal')} for i in lock['population']],results)
net={};prob={}
for role in ['current','test']:
 rows=[];diag=[]
 for i in lock['population']:
  mid=i['fixture']['match_id'];c=record(i,'comprehensive');p=c['payload'];candidate=record(i,'candidate_revision');f=candidate['payload'][role]
  assert p['candidate_reference']['sha256']==candidate['record_sha256'] and f['matrix_hash']==p['candidate_outputs'][role]['matrix_hash']
  score,wdl=actual(mid);h=res[mid]['home_goals'];a=res[mid]['away_goals'];m=check_matrix(f)
  if p['primary'] is not None:rows.append({'match_id':mid,'version':f['version'],'comprehensive':p['primary'],'candidate':f['primary'],'actual':score,'comprehensive_hit':p['primary']==score,'candidate_hit':f['primary']==score,'changed_right':p['primary']==score and f['primary']!=score,'changed_wrong':p['primary']!=score and f['primary']==score})
  summary=summarize_prediction(f);gr=goal_review(summary,home_goals=h,away_goals=a);idx=np.add.outer(np.arange(m.shape[0]),np.arange(m.shape[1]))
  diag.append({'match_id':mid,'version':f['version'],'league_level':i['fixture']['league_level'],'training_cutoff':f['training_data_cutoff'],'actual':[h,a],'mean':[summary[s]['mean'] for s in ['home','away']],'mean_error':[gr[s]['mean_error'] for s in ['home','away']],'absolute_error':[gr[s]['absolute_error'] for s in ['home','away']],'interval_hit':[gr[s]['interval_hit'] for s in ['home','away']],'interval':[summary[s]['central_interval'] for s in ['home','away']],'p_zero':[summary[s]['p0'] for s in ['home','away']],'observed_zero':[h==0,a==0],'p_total_ge4':float(m[idx>=4].sum()),'observed_total_ge4':h+a>=4,'actual_score_probability':float(m[h,a]),'score_log_loss':float(-math.log(max(m[h,a],1e-15))),'wdl_log_loss':float(-math.log(max(f['wdl'][wdl],1e-15))),'wdl_brier_sum3':sum((v-int(k==wdl))**2 for k,v in f['wdl'].items()),'original_first_matrix_identical':record(i,'candidate_first')['payload'][role]['matrix_hash']==f['matrix_hash']})
 diff=np.array([int(x['comprehensive_hit'])-int(x['candidate_hit']) for x in rows]);rng=np.random.default_rng(20261114);boot=rng.choice(diff,size=(20000,len(diff)),replace=True).mean(axis=1)
 right=int((diff>0).sum());wrong=int((diff<0).sum());n=right+wrong;lower=min(right,wrong);pval=min(1.,2*sum(math.comb(n,k) for k in range(lower+1))/2**n) if n else 1.
 net[role]={'paired_n':len(rows),'changed_right':right,'changed_wrong':wrong,'net_hits':int(diff.sum()),'descriptive_rate_difference_bootstrap_95':np.quantile(boot,[.025,.975]).tolist(),'exact_discordant_sign_test_p':pval,'bootstrap_seed':20261114,'bootstrap_samples':20000,'not_promotion_evidence':True,'rows':rows,'by_version':{v:{'n':sum(r['version']==v for r in rows),'net_hits':sum(int(r['comprehensive_hit'])-int(r['candidate_hit']) for r in rows if r['version']==v)} for v in sorted({r['version'] for r in rows})}}
 def summary(ds):
  return {'n':len(ds),**{k:np.mean([d[k] for d in ds],axis=0).tolist() for k in ['actual','mean','mean_error','absolute_error','interval_hit','p_zero','observed_zero','p_total_ge4','observed_total_ge4','score_log_loss','wdl_log_loss','wdl_brier_sum3']}}
 prob[role]={'rows':diag,'batch_descriptive_not_single_model_performance':summary(diag),'by_version':{v:summary([d for d in diag if d['version']==v]) for v in sorted({d['version'] for d in diag})},'limitations':'tiny per-grade samples; no certified calibration; no post-result fitted probabilities'}
# Cumulative first-candidate evidence: include all 8 matches from the previous fixed review, distinct IDs only.
oldroot=Path('/workspace/WCPP/reports/nations-review-20261113-0842');oldres=read(oldroot/'verified-results.json');oldaccounts=read(oldroot/'frozen-accounts.json');oldpairs=[]
assert not set(res)&{r['match_id'] for r in oldres}
for r in oldres:
 assert sha(r['source_path'])==r['source_sha256'];raw=read(r['source_path']);c=raw['header']['competitions'][0]
 for side in ['home','away']:
  t=next(t for t in c['competitors'] if t['homeAway']==side);assert verify_period_scores(t,c['status'])['regulation']==r[side+'_goals']
for item in oldaccounts['fixtures']:
 ref=item['tracks']['nations-paired-candidates']['first'];r=verify(read(ref['path']));assert r['record_sha256']==ref['record_sha256'] and r['evaluation_slot']=='FIRST_PREMATCH'
 oldpairs.append({'match_id':item['match_id'],'current_model':r['payload']['current'],'test_model':r['payload']['test']})
cumulative=review(oldpairs+pairs['first'],oldres+results)
metrics={'schema':'WCPP-NATIONS-REVIEW-20261114-1','calculated_at':datetime.now(timezone.utc).isoformat(),'population':10,'completed':len(results),'pending':0,'comprehensive':{'summary':counts(comp),'rows':comp},'top3':{'summary':counts(top),'rows':top,'original_receipt':lock['top3_receipt']},'active_models':active_review,'candidate_models':candidate_reviews,'first_vs_revision_identity':same,'first_comprehensive_vs_active':active_comparison,'first_comprehensive_vs_actual_referenced_candidates':net,'probability_diagnostics':prob,'cumulative_first_candidates_18':cumulative,'cumulative_scope':'prior fixed eight plus all current ten; distinct first freezes, grade/version separated; not aggregate single-model accuracy','market_review':'original totals provider label normalized only in review-side audit after raw source verification; no forecast/price/line/direction alteration','candidate_total_direction_note':'candidate freezes include probabilities/line but no selected over/under reference; do not invent model OU hit rates after results','formal_model_promotion':False,'model_parameters_changed':False,'active_registry_sha256':sha('/workspace/WCPP/runtime/active-model.json')}
assert metrics['active_registry_sha256']==lock['active_registry_sha256'];write(R/'metrics.json',metrics)
print(json.dumps({'comprehensive':metrics['comprehensive']['summary'],'top3':metrics['top3']['summary'],'net':{r:{k:v for k,v in x.items() if k not in ['rows','by_version']} for r,x in net.items()}},ensure_ascii=False,indent=2))
