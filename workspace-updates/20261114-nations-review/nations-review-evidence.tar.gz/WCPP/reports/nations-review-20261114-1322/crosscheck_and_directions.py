import json,hashlib,sys
from pathlib import Path
from datetime import datetime,timezone
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from research.analysis_freeze import verify,aware
R=Path(__file__).resolve().parent;P=Path('/workspace/WCPP/reports/nations-prematch-20261113-2118')
def read(p):return json.loads(Path(p).read_text())
def write(p,x):
 with Path(p).open('x') as h:json.dump(x,h,ensure_ascii=False,indent=2,allow_nan=False)
lock=read(R/'population-lock.json');results={r['match_id']:r for r in read(R/'verified-results.json')};meta=read(R/'results/odds-request-ledger.json');source=R/'results/raw'/meta['file'];assert hashlib.sha256(source.read_bytes()).hexdigest()==meta['sha256']
assert aware(meta['requested_at'])>aware(lock['locked_at']) and aware(meta['captured_at'])<=datetime.now(timezone.utc)
raw=read(source);assert len({x['id'] for x in raw})==len(raw);old={q['match_id']:q for q in read(P/'market/pinnacle-markets.json')['matches']};checks=[]
for i in lock['population']:
 mid=i['fixture']['match_id'];q=old[mid];e=next(e for e in raw if e['id']==q['source_event_id']);assert e['sport_key']=='soccer_uefa_nations_league' and e['completed'] is True
 assert e['home_team']==q['home'] and e['away_team']==q['away']
 delta=(aware(e['commence_time'])-aware(i['fixture']['kickoff_at'])).total_seconds()
 # The same already-frozen provider ID and sides identify these records.
 # Preserve provider kickoff revisions as discrepancies, not rewritten fixture times.
 assert delta=={'espn:401861161':60,'espn:401861160':60,'espn:401861156':120}.get(mid,0)
 s={x['name']:int(x['score']) for x in e['scores']};assert len(e['scores'])==2 and set(s)=={q['home'],q['away']}
 assert [s[q['home']],s[q['away']]]==[results[mid]['home_goals'],results[mid]['away_goals']]
 assert aware(e['last_update'])<=aware(meta['captured_at'])
 checks.append({'match_id':mid,'frozen_provider_event_id':e['id'],'same_frozen_provider_id_teams_score':True,'kickoff_exact_agreement':delta==0,'provider_kickoff':e['commence_time'],'frozen_kickoff':i['fixture']['kickoff_at'],'kickoff_difference_seconds':delta,'frozen_kickoff_modified':False,'home_goals':s[q['home']],'away_goals':s[q['away']],'provider_updated_at':e['last_update']})
write(R/'second-source-verification.json',{'status':'SCORES_PASS_WITH_3_KICKOFF_METADATA_DIFFERENCES','verified_at':datetime.now(timezone.utc).isoformat(),'source':meta,'matches':checks,'coverage':10,'scope':'only locked ten; no claim about all other scores-response events','independently_certifies_90_minutes':False,'90_minute_evidence':'ESPN verified FT/two periods supplied in verified-results.json'})
rows=[]
for i in lock['population']:
 mid=i['fixture']['match_id'];c=verify(read(i['comprehensive']['path']))['payload'];f=verify(read(i['candidate_revision']['path']))['payload'];r=results[mid];h,a=r['home_goals'],r['away_goals'];actual='主胜' if h>a else '客胜' if h<a else '平局'
 row={'match_id':mid,'name':i['name'],'actual':actual,'comprehensive':c['wdl'],'selected':c['wdl'] in ['主胜','平局','客胜'],'models':{}}
 for role in ['current','test']:
  row['models'][role]={'frozen_direction':f[role]['wdl_reference'],'probabilities':f[role]['wdl'],'hit':f[role]['wdl_reference']==actual,'net_comprehensive_minus_model':int(c['wdl']==actual)-int(f[role]['wdl_reference']==actual) if row['selected'] else None}
 rows.append(row)
selected=[x for x in rows if x['selected']]
write(R/'direction-diagnostics.json',{'rows':rows,'paired_n':len(selected),'comprehensive_hits':sum(x['comprehensive']==x['actual'] for x in selected),'by_role':{role:{'model_hits_on_same_selected_matches':sum(x['models'][role]['hit'] for x in selected),'net_hits':sum(x['models'][role]['net_comprehensive_minus_model'] for x in selected),'changed_right':sum(x['models'][role]['net_comprehensive_minus_model']==1 for x in selected),'changed_wrong':sum(x['models'][role]['net_comprehensive_minus_model']==-1 for x in selected)} for role in ['current','test']},'draw_selections':sum(x['comprehensive']=='平局' for x in selected),'draw_hits':sum(x['comprehensive']==x['actual']=='平局' for x in selected),'interpretation':'separate joint-score mode and marginal WDL direction; diagnostic only, no replacement of original direction'})
print('10 same-provider-ID/team/score matches; 3 kickoff metadata differences retained; WDL diagnostic saved')
