import json,hashlib,sys
from pathlib import Path
from datetime import datetime,timezone
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from research.analysis_freeze import save,verify
R=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=lambda:datetime.now(timezone.utc).isoformat()
def write(p,x):
 with Path(p).open('x') as h:json.dump(x,h,ensure_ascii=False,indent=2,allow_nan=False)
assert not (R/'delivery.json').exists()
lock=read(R/'population-lock.json');m=read(R/'metrics.json');decision=read(R/'review-decision.json');v=read(R/'verification.json')
assert v['status']=='PASS' and v['metrics_sha256']==sha(R/'metrics.json')
res={r['match_id']:r for r in read(R/'verified-results.json')};process={r['match_id']:r for r in read(R/'verified-process.json')};receipts=[]
for i in lock['population']:
 f=dict(i['fixture'],cutoff_at=now());mid=f['match_id'];row=next(x for x in m['comprehensive']['rows'] if x['match_id']==mid)
 payload={'result':res[mid],'process':process[mid],'original_freeze_accounts':i,'comprehensive_review':row,'candidate_review':{tag:next(x for x in m['candidate_models'][tag]['paired_rows'] if x['match_id']==mid) for tag in ['first','revision']},'active_review':next(x for x in m['active_models']['paired_rows'] if x['match_id']==mid),'review_decision':decision,'metrics_sha256':sha(R/'metrics.json'),'full_report_sha256':sha(R/'review.md'),'original_predictions_modified':False}
 receipts.append(save(payload,f,stage='review',track='comprehensive',idempotency_key='nations-20261114-review-1:'+mid))
shell={'match_id':'nations-analysis-batch:20261113-evening','cohort':'uefa.nations','kickoff_at':min(i['fixture']['kickoff_at'] for i in lock['population']),'cutoff_at':now()}
top=save({'original_top3':lock['top3_receipt'],'review':m['top3'],'ranking_changed':False,'full_population':10},shell,stage='review',track='top3-selection',idempotency_key='nations-20261114-review-top3-1')
files=[p for p in R.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
report=save({'report_markdown':(R/'review.md').read_text(),'metrics':m,'decision':decision,'population_lock':read(R/'population-lock-receipt.json'),'match_review_receipts':receipts,'top3_review_receipt':top,'prematch_report_receipt':lock['prematch_report_receipt'],'source_commit':lock['source_commit'],'verification':v,'evidence_sha256':{str(p.relative_to(R)):sha(p) for p in sorted(files)},'environment_published':False},dict(shell,cutoff_at=now()),stage='review',track='analysis-report',idempotency_key='nations-20261114-review-report-1')
allrefs=[read(R/'population-lock-receipt.json')]+receipts+[top,report]
for r in allrefs:assert verify(read(r['path']))['record_sha256']==r['sha256']
# Re-read the original first/revision records after all new writes.
for i in lock['population']:
 for key in ['comprehensive','candidate_first','candidate_revision','active_refusal']:
  ref=i[key];assert verify(read(ref['path']))['record_sha256']==ref['sha256']
assert sha('/workspace/WCPP/runtime/active-model.json')==lock['active_registry_sha256']
write(R/'delivery.json',{'report_receipt':report,'match_review_receipts':receipts,'top3_review_receipt':top,'population_lock_receipt':read(R/'population-lock-receipt.json'),'all_review_receipts':allrefs,'report_file':'review.md','report_sha256':sha(R/'review.md'),'metrics_sha256':sha(R/'metrics.json'),'population':10,'settled':10,'pending':0,'source_commit':lock['source_commit'],'prematch_records_modified':False,'active_model_changed':False,'environment_published':False})
print(json.dumps({'new_review_receipts':len(allrefs),'report_receipt':report,'top3_review':top},ensure_ascii=False))
