"""Independent arithmetic and provenance check; no network, fitting or forecast writes."""
import json,hashlib,sys
from collections import Counter
from decimal import Decimal
from pathlib import Path
from datetime import datetime,timezone
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from research.analysis_freeze import verify,aware
R=Path(__file__).resolve().parent
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
lock=read(R/'population-lock.json');m=read(R/'metrics.json');res={x['match_id']:x for x in read(R/'verified-results.json')};rows=[];checks=[]
def check(label,value):
 checks.append({'check':label,'passed':bool(value)});assert value,label
def settlement(goals,line,side):
 if side not in ('大','小'):return None
 l=Decimal(str(line));legs=[l] if l*2==int(l*2) else [l-Decimal('.25'),l+Decimal('.25')]
 parts=[(goals>x)-(goals<x) for x in legs];value=sum(parts)/len(parts)*(1 if side=='大' else -1)
 return {1:'win',.5:'half_win',0:'push',-.5:'half_loss',-1:'loss'}[value]
for item in lock['population']:
 mid=item['fixture']['match_id'];r=res[mid];a=(r['home_goals'],r['away_goals']);wd=['客胜','平局','主胜'][(a[0]>a[1])-(a[0]<a[1])+1]
 records={}
 for key in ['comprehensive','candidate_first','candidate_revision','active_refusal']:
  ref=item[key];x=verify(read(ref['path']));check(mid+':'+key+':hash',x['record_sha256']==ref['sha256']);check(mid+':'+key+':prematch',aware(x['fixture']['cutoff_at'])<=aware(x['recorded_at'])<aware(x['fixture']['kickoff_at']));records[key]=x
 p=records['comprehensive']['payload'];out={'match_id':mid,'primary_hit':None if p['primary'] is None else tuple(map(int,p['primary'].split('-')))==a,'wdl_hit':p['wdl']==wd if p['wdl'] in ('主胜','平局','客胜') else None,'total_settlement':settlement(sum(a),p['total_line'],p['total_direction'])}
 row=next(x for x in m['comprehensive']['rows'] if x['match_id']==mid)
 check(mid+':independent score/wdl/quarter-line settlement',all(row[k]==v for k,v in out.items()));rows.append(out)
 for role,name in [('current','当前模型'),('test','test模型')]:
  for tag,key in [('first','candidate_first'),('revision','candidate_revision')]:
   f=records[key]['payload'][role];rr=next(x for x in m['candidate_models'][tag]['paired_rows'] if x['match_id']==mid)['models'][name]
   check(mid+role+tag+':independent candidate primary',rr['primary_hit']==(tuple(map(int,f['primary'].split('-')))==a))
   check(mid+role+tag+':independent candidate direction',rr['wdl_hit']==(f['wdl_reference']==wd))
   check(mid+role+tag+':no post-result OU direction',rr['total_settlement'] is None and f.get('total') is None)
check('all ten scope preserved',len(rows)==10 and m['population']==10)
check('primary coverage denominator',sum(r['primary_hit'] is not None for r in rows)==m['comprehensive']['summary']['primary_n']==9)
check('score correct numerator',sum(r['primary_hit'] is True for r in rows)==m['comprehensive']['summary']['primary_hits']==1)
check('wdl correct numerator',sum(r['wdl_hit'] is True for r in rows)==m['comprehensive']['summary']['wdl_hits']==4)
t=Counter(r['total_settlement'] for r in rows if r['total_settlement'] is not None)
check('all five total categories',dict(m['comprehensive']['summary']['total_settlements'])=={k:t[k] for k in ['win','half_win','push','half_loss','loss']})
check('strict full-win rate denominator',m['comprehensive']['summary']['total_non_push_n']==7 and m['comprehensive']['summary']['total_strict_full_win_rate']==3/7)
frozen=verify(read(lock['top3_receipt']['path']));check('original TOP3 rank not replaced',[x['match_id'] for x in frozen['payload']['top3']]==[x['match_id'] for x in m['top3']['rows']])
check('TOP3 settled correctly',m['top3']['summary']['primary_hits']==1 and m['top3']['summary']['wdl_hits']==2 and m['top3']['summary']['total_settlements']=={'win':2,'half_win':0,'push':1,'half_loss':0,'loss':0})
check('all matrices unchanged between first/revision',all(all(x['matrix_identity'].values()) and all(x['artifact_identity'].values()) for x in m['first_vs_revision_identity']))
index=read('/workspace/nations-model-20261110/models/candidates.json')
for level,roles in index['routes'].items():
 for role,ref in roles.items():
  check(level+role+':artifact identity',sha(ref['path'])==ref['sha256']);art=read(ref['path'])
  for field in ['dataset','protocol','engine']:check(level+role+':'+field,sha(art[field+'_path'])==art[field+'_sha256'])
check('active registry unchanged',sha('/workspace/WCPP/runtime/active-model.json')==lock['active_registry_sha256'])
check('second-source ten scores verified',read(R/'second-source-verification.json')['coverage']==10)
out={'status':'PASS','verified_at':datetime.now(timezone.utc).isoformat(),'check_count':len(checks),'failed_checks':[],'checks':checks,'metrics_sha256':sha(R/'metrics.json'),'source_verification_sha256':sha(R/'source-verification.json'),'second_source_sha256':sha(R/'second-source-verification.json'),'prematch_records_modified':False,'models_modified':False,'scope':'independent decimal quarter settlement and frozen field accounting; not statistical model validation'}
with (R/'verification.json').open('x') as h:json.dump(out,h,ensure_ascii=False,indent=2)
print(json.dumps({'status':'PASS','checks':len(checks),'metrics_sha256':out['metrics_sha256']}))
