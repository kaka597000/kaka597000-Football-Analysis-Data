"""Independent read-only verification from retained provider bytes, no result lookup."""
import json,hashlib,re,sys
from pathlib import Path
from datetime import datetime,timezone
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from research.analysis_freeze import verify,aware,digest
from research_program.nations_phase import verify_period_scores,classify_source_phase
from research_program.future_validation import quote_audit
R=Path(__file__).resolve().parent;P=Path('/workspace/WCPP/reports/nations-prematch-20261113-2118')
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):
 with Path(p).open('x') as h:json.dump(x,h,ensure_ascii=False,indent=2,allow_nan=False)
lock=read(R/'population-lock.json');ledger=read(R/'results/espn-request-ledger.json')['requests'];metas={x['file']:x for x in ledger}
for m in ledger:
 assert m['http_status']==200 and sha(R/'results/raw'/m['file'])==m['sha256']
 assert aware(lock['locked_at'])<aware(m['requested_at'])<=aware(m['captured_at'])<=datetime.now(timezone.utc)
board=read(R/'results/raw/scoreboard.json');boards={str(x['id']):x for x in board['events']};assert len(boards)==10
market_meta=read(P/'market/source-metadata.json')
for k in ['odds','identity']:assert sha(P/'market'/market_meta[k]['file'])==market_meta[k]['sha256']
rawodds=read(P/'market/odds.json');identity=read(P/'market/identity.json');oldboards={str(x['id']):x for x in identity['events']}
quotes=read(P/'market/pinnacle-markets.json')['matches'];quotes={q['match_id']:q for q in quotes}
channel=read(P/'validated-market.json');snaps={s['target']['match_id']:s for s in channel['snapshots']}
results=[];process=[];market=[];issues=[]
for item in lock['population']:
 f=item['fixture'];mid=f['match_id'];eid=f['source_event_id'];m=metas['summary-'+eid+'.json'];raw=read(R/'results/raw'/m['file']);head=raw['header'];c=head['competitions'][0]
 assert str(head['id'])==eid and head['league']['slug']=='uefa.nations' and len(head['competitions'])==1 and str(c['id'])==eid
 assert aware(c['date'])==aware(f['kickoff_at']) and c['neutralSite']==f['neutral']
 sides={x['homeAway']:x for x in c['competitors']};assert set(sides)=={'home','away'} and len(c['competitors'])==2
 phase=classify_source_phase(boards[eid]);assert phase['complete'] and phase['stage']==f['stage'] and phase['league_level']==f['league_level']
 boardc=boards[eid]['competitions'][0];assert boardc['status']['type']['completed'] is True
 periods={};scores={};names={};team_side={}
 for side in ['home','away']:
  t=sides[side];assert 'espn:'+str(t['team']['id'])==f[side] and str(t['id'])==str(t['team']['id'])
  periods[side]=verify_period_scores(t,c['status']);assert periods[side] and periods[side]['extra_time']==0 and periods[side]['shootout'] is None
  scores[side]=periods[side]['regulation'];names[side]=t['team']['displayName'];team_side[str(t['team']['id'])]=side
  old=next(x for x in oldboards[eid]['competitions'][0]['competitors'] if x['homeAway']==side);assert 'espn:'+old['team']['id']==f[side]
  bc=next(x for x in boardc['competitors'] if x['homeAway']==side);assert str(bc['team']['id'])==str(t['team']['id']) and int(bc['score'])==scores[side]
 result={'match_id':mid,'status':'completed','event_status':'FT','score_basis':'regulation_90','home_goals':scores['home'],'away_goals':scores['away'],'observed_at':m['captured_at'],'source_url':m['url'],'source_sha256':m['sha256'],'source_path':str(R/'results/raw'/m['file']),**{k:f[k] for k in ['competition','cohort','stage','league_level','home','away','kickoff_at']},'regulation_evidence':periods}
 results.append(result)
 # Reconstruct goal ownership from score deltas and roster membership, not team name guessing.
 roster={}
 for t in raw.get('rosters',[]):
  tid=str(t['team']['id']);assert tid in team_side
  for player in t.get('roster',[]):
   aid=str(player['athlete']['id']);assert aid not in roster or roster[aid]==tid;roster[aid]=tid
 stats={}
 for x in raw.get('boxscore',{}).get('teams',[]):
  side=team_side[str(x['team']['id'])];stats[side]={v['name']:v.get('displayValue') for v in x.get('statistics',[])}
 goals=[];cards=[];before=[0,0];seen=set()
 for e in raw.get('keyEvents',[]):
  assert e['id'] not in seen;seen.add(e['id'])
  if e.get('scoringPlay'):
   assert not e.get('shootout') and e['period']['number'] in [1,2]
   pattern=re.escape(names['home'])+r' (\d+), '+re.escape(names['away'])+r' (\d+)'
   matched=re.findall(pattern,e.get('text',''));assert len(matched)==1,(eid,e)
   after=list(map(int,matched[0]));delta=[b-a for a,b in zip(before,after)];assert delta in [[1,0],[0,1]]
   side=['home','away'][delta.index(1)];tid=f[side].split(':')[-1];assert str(e['team']['id'])==tid
   aid=str(e['participants'][0]['athlete']['id']);kind=e['type']['type'];own=kind=='own-goal';actor=('away' if side=='home' else 'home') if own else side
   assert roster.get(aid)==f[actor].split(':')[-1],(eid,'actor team',e)
   details=[d for d in c.get('details',[]) if d.get('scoringPlay') and d['clock']['value']==e['clock']['value'] and str(d.get('team',{}).get('id'))==tid]
   assert len(details)==1 and details[0]['ownGoal']==own
   pen=kind=='penalty---scored';assert details[0]['penaltyKick']==pen
   goals.append({'event_id':e['id'],'minute':e['clock']['displayValue'],'clock_seconds':e['clock']['value'],'period':e['period']['number'],'before':before,'after':after,'beneficiary_side':side,'actor_side':actor,'athlete_id':aid,'athlete':e['participants'][0]['athlete']['displayName'],'own_goal':own,'penalty_goal':pen,'text':e.get('text'),'validation':'SCORE_DELTA_ROSTER_ID_HEADER_DETAIL_MATCH'})
   before=after
  if e.get('type',{}).get('type')=='red-card':
   side=team_side[str(e['team']['id'])];cards.append({'event_id':e['id'],'minute':e['clock']['displayValue'],'clock_seconds':e['clock']['value'],'team_side':side,'score_at_card':before.copy(),'text':e.get('text')})
 assert before==[scores['home'],scores['away']]
 for side in ['home','away']:
  pen=sum(g['penalty_goal'] and g['beneficiary_side']==side for g in goals);field=stats[side].get('penaltyKickGoals')
  if field is not None and int(field)!=pen:issues.append({'match_id':mid,'side':side,'type':'BOX_PENALTY_GOALS_CONFLICT_WITH_TWO_EVENT_FIELDS','box_value':field,'validated_event_count':pen,'used_for_process': 'events; final result unaffected'})
  other='away' if side=='home' else 'home';sot=stats[side].get('shotsOnTarget');saves=stats[other].get('saves');own=sum(g['own_goal'] and g['beneficiary_side']==side for g in goals)
  if sot is not None and saves is not None and float(saves)+scores[side]-own>float(sot):issues.append({'match_id':mid,'side':side,'type':'SAVES_PLUS_NON_OWN_GOALS_EXCEED_SOT','sot':sot,'opponent_saves':saves,'non_own_goals':scores[side]-own,'interpretation':'do not infer goalkeeper quality or save rates from conflicting aggregate fields'})
  assert sum(c['team_side']==side for c in cards)==int(stats[side]['redCards'])
 # xG field presence is checked recursively; no shots-to-xG substitution.
 def xg_keys(x,path=''):
  out=[]
  if isinstance(x,dict):
   for k,v in x.items():
    if re.search(r'expected.?goals|^xg$|^xga$',str(k),re.I) or k=='name' and re.search(r'expected.?goals|^xg$|^xga$',str(v),re.I):out.append({'path':path+'/'+k,'value':v})
    out+=xg_keys(v,path+'/'+str(k))
  elif isinstance(x,list):
   for i,v in enumerate(x):out+=xg_keys(v,path+'/'+str(i))
  return out
 process.append({'match_id':mid,'source_sha256':m['sha256'],'teams':names,'stats':stats,'goals':goals,'red_cards':cards,'xg_fields':xg_keys(raw),'source_notes_excluded':c.get('notes',[]),'own_goal_adapter_note':'research.review_events.normalize_fotmob_goal expects FotMob score fields; not called with fabricated ESPN input. ESPN events independently reconcile score delta, participant roster team ID, and header detail flag.'})
 # Historical quote audit against the original bytes, no fresh market attachment/backfill.
 comp=verify(read(item['comprehensive']['path']));q=comp['payload']['actual_quote'];snap=snaps[mid]
 assert snap['snapshot_sha256']==digest({k:v for k,v in snap.items() if k!='snapshot_sha256'})
 assert snap['target']['match_id']==mid and snap['target']['home_id']==f['home'] and snap['target']['away_id']==f['away'] and aware(snap['target']['kickoff_at'])==aware(f['kickoff_at'])
 sourceid=quotes[mid]['source_event_id'];source=next(x for x in rawodds if x['id']==sourceid)
 assert source['home_team']==names['home'] and source['away_team']==names['away'] and aware(source['commence_time'])==aware(f['kickoff_at'])
 b=next(x for x in source['bookmakers'] if x['key']==q['bookmaker']);t=next(x for x in b['markets'] if x['key']=='totals');out={x['name']:x for x in t['outcomes']}
 assert set(out)=={'Over','Under'} and all(x['point']==q['line'] for x in out.values()) and out['Over']['price']==q['over_odds'] and out['Under']['price']==q['under_odds']
 assert t['last_update']==q['quoted_at'] and q['source_sha256']==market_meta['odds']['sha256'] and q['query_time']==market_meta['odds']['captured_at'] and q['source_url']==market_meta['odds']['url'] and q['match_id']==mid
 assert aware(q['quoted_at'])<=aware(q['query_time'])<=aware(comp['fixture']['cutoff_at'])<aware(comp['recorded_at'])<aware(f['kickoff_at'])
 assert (aware(comp['fixture']['cutoff_at'])-aware(q['quoted_at'])).total_seconds()<=3600
 raw_audit=quote_audit(dict(comp['fixture'],total_quote=q));assert not raw_audit['eligible'] and raw_audit['reasons']==['UNVERIFIED_IDENTITY_BOOK_LINE_OR_TWO_SIDED_PRICE']
 # Explicit review-side semantic alias only, after original raw bytes prove source totals.
 # Existing market_bridge emits standard_total for the same provider market. Do not edit q/freeze.
 normalized_audit=quote_audit(dict(comp['fixture'],total_quote={**q,'market':'standard_total'}));assert normalized_audit['eligible']
 market.append({'match_id':mid,'raw_market_label':q['market'],'canonical_review_label':'standard_total','original_quote_audit':raw_audit,'canonical_review_audit':normalized_audit,'raw_identity_price_time_verified':True,'original_freeze_modified':False,'no_new_quote_or_direction':True})
write(R/'verified-results.json',results);write(R/'verified-process.json',process);write(R/'source-conflicts.json',issues);write(R/'quote-review-audit.json',market)
write(R/'source-verification.json',{'verified_at':datetime.now(timezone.utc).isoformat(),'population':10,'espn_90_verified':len(results),'board_summary_agreement':10,'goal_events_reconciled':sum(len(p['goals']) for p in process),'own_goals_reconciled':sum(g['own_goal'] for p in process for g in p['goals']),'penalties_reconciled':sum(g['penalty_goal'] for p in process for g in p['goals']),'xg_games_with_fields':sum(bool(p['xg_fields']) for p in process),'market_raw_verified':len(market),'source_field_conflicts':issues,'result_identity_and_scores_unchanged':True})
print(json.dumps({'results':len(results),'goals':sum(len(p['goals']) for p in process),'conflicts':issues},ensure_ascii=False))
