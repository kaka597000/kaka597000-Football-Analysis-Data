# R9 pre-2006 independent collection

Collected all 24 official football-data.co.uk CSVs for E0/SP1/D1/I1/F1/N1 in seasons 0203, 0304, 0405 and 0506. The official URL pattern is `https://www.football-data.co.uk/mmz4281/{season}/{division}.csv`. All requests returned HTTP 200. The data cutoff is 2006-07-01. Split roles are train (0203, 0304), calibration (0405), and the sole added test season (0506).

## Contents and provenance

- `raw/{season}-{division}.csv`: exact source bytes.
- `raw/{season}-{division}.receipt.json`: URL, final URL, Beijing fetch timestamp, HTTP status, byte size, SHA-256, source header, strict decoding method and replacement-character count.
- `raw/receipts.json`: consolidated 24-file receipt index.
- `panels/{competition}.jsonl`: R7 pre2010-compatible match records, with stable event IDs, stable source-label team codes, physical CSV line numbers, source hashes, 90-minute scores, season and split role.
- `reports/reconciliation.json`: source rows, qualified panel rows, exclusions and per-row source anomalies for each CSV.
- `reports/coverage.json`: season/competition result and odds coverage.
- `reports/verification.json`: independent digest, cutoff, score, ID, line, odds and replacement-character checks.
- `collect.py`: reproducible network collector/parser. It reuses an existing CSV only when the receipt digest matches; otherwise it fetches the official URL again.

The source has no verifiable historical quote clock. Every archived price is marked `archived_historical_price_observation_proxy_no_quote_clock`; this cannot establish first-known time. 1X2 is populated only when all three Bet365 values are finite and greater than 1. Totals use a complete finite Bet365 2.5 pair first, otherwise a complete finite `BbAv` pair from the same source row. `paired_market=true` only when both 1X2 and totals are from Bet365. Missing odds never remove a valid result.

All CSVs decoded strictly (UTF-8 with BOM, or CP1252 fallback for 0405 E0) with zero replacement characters. The two-digit dates are interpreted in their recorded 2002–2006 season context. All retained dates precede the cutoff.

## Reconciliation notes

There are 8,380 qualified matches. No same-date same-home/away duplicates or FTR/score disagreements were found. Two CSVs contain blank trailing rows: 0203 D1 physical row 308, and 0203 I1 physical rows 308–316. Those rows have no date, teams, score or result, so they cannot be identified as fixtures or attributed to postponements; they are listed in `reports/reconciliation.json` and excluded from the match panel. No other rows were excluded. Team codes are stable hashes of each NFC-normalized, case-folded source label; they preserve the original Unicode labels and do not claim external canonical identity resolution.

No model calculations, sample selection, source-code changes, project data copies or pushes were made.
