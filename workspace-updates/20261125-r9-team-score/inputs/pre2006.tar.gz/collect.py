#!/usr/bin/env python3
"""Fetch and parse six football-data.co.uk season CSVs into an isolated panel."""
import csv, datetime as dt, hashlib, io, json, pathlib, time, urllib.request, urllib.error
import math, unicodedata

ROOT = pathlib.Path(__file__).resolve().parent
LEAGUES = {'eng.1':'E0','esp.1':'SP1','ger.1':'D1','ita.1':'I1','fra.1':'F1','ned.1':'N1'}
SEASONS = {'0203':'train','0304':'train','0405':'calibration','0506':'test'}
BASE = 'https://www.football-data.co.uk/mmz4281/{season}/{div}.csv'

def sha(b): return hashlib.sha256(b).hexdigest()
def num(v):
    try:
        x=float(v.strip())
        return x if math.isfinite(x) and x > 1 else None
    except (ValueError, AttributeError): return None
def pairs(row, a, b):
    x,y=num(row.get(a)),num(row.get(b))
    return (x,y) if x is not None and y is not None else None
def stamp():
    return dt.datetime.now(dt.timezone.utc).astimezone(dt.timezone(dt.timedelta(hours=8))).isoformat(timespec='seconds')

def get_csv(season, div):
    url=BASE.format(season=season,div=div); target=ROOT/'raw'/f'{season}-{div}.csv'
    if target.exists() and target.with_suffix('.receipt.json').exists():
        receipt=json.loads(target.with_suffix('.receipt.json').read_text())
        body=target.read_bytes()
        if sha(body)==receipt['sha256'] and receipt['http_status']==200:
            return url,body,receipt
    req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 (compatible; independent historical data capture)'})
    try:
        with urllib.request.urlopen(req, timeout=45) as res:
            body=res.read(); status=res.status; final=res.geturl()
    except urllib.error.HTTPError as e:
        body=e.read(); status=e.code; final=e.geturl()
    except Exception as e:
        receipt={'url':url,'fetch_time_beijing':stamp(),'http_status':None,'error':type(e).__name__+': '+str(e)}
        (ROOT/'reports'/f'failed-{season}-{div}.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2))
        raise
    rec={'url':url,'final_url':final,'fetch_time_beijing':stamp(),'http_status':status,'size_bytes':len(body),'sha256':sha(body),'source_header':None}
    if status != 200:
        rec['size_bytes']=len(body); rec['sha256']=sha(body)
        target.with_suffix('.receipt.json').write_text(json.dumps(rec,ensure_ascii=False,indent=2))
        target.with_suffix('.http-error.body').write_bytes(body)
        return url,None,rec
    try:
        text=body.decode('utf-8-sig',errors='strict'); rec['decode']='utf-8-sig-strict'
    except UnicodeDecodeError:
        text=body.decode('cp1252',errors='strict'); rec['decode']='cp1252-strict'
    rec['replacement_character_count']=text.count('\ufffd')
    rec['source_header']=next(csv.reader(io.StringIO(text)),[])
    target.write_bytes(body); target.with_suffix('.receipt.json').write_text(json.dumps(rec,ensure_ascii=False,indent=2))
    target.with_suffix('.http-error.body').unlink(missing_ok=True)
    return url,body,rec

def parse(body, season, div, comp, url, digest):
    try: text=body.decode('utf-8-sig',errors='strict')
    except UnicodeDecodeError: text=body.decode('cp1252',errors='strict')
    reader=csv.DictReader(io.StringIO(text)); out=[]; issues=[]; source_rows=0; bad=[]; dup={}
    odds_fields=['B365H','B365D','B365A','B365>2.5','B365<2.5','BbAv>2.5','BbAv<2.5']
    odds_nonempty=dict.fromkeys(odds_fields,0)
    # DictReader line_num counts physical CSV lines, including multiline quoted records.
    while True:
        row=next(reader,None)
        if row is None: break
        line=reader.line_num
        source_rows+=1
        for field in odds_fields:
            if (row.get(field) or '').strip(): odds_nonempty[field]+=1
        date=(row.get('Date') or '').strip()
        try:
            parsed=dt.datetime.strptime(date,'%d/%m/%Y').date()
        except ValueError:
            try: parsed=dt.datetime.strptime(date,'%d/%m/%y').date()
            except ValueError:
                try: parsed=dt.date.fromisoformat(date)
                except ValueError:
                    bad.append({'row':line,'reason':'invalid_or_missing_date','date':date}); continue
        if parsed >= dt.date(2006,7,1):
            bad.append({'row':line,'reason':'after_requested_cutoff','date':parsed.isoformat()}); continue
        home=(row.get('HomeTeam') or '').strip(); away=(row.get('AwayTeam') or '').strip()
        if not home or not away:
            bad.append({'row':line,'reason':'missing_team_identity','home':home,'away':away}); continue
        try: hg,ag=int(row['FTHG']),int(row['FTAG'])
        except (ValueError,KeyError,TypeError):
            bad.append({'row':line,'reason':'missing_or_invalid_full_time_score','home':home,'away':away}); continue
        ftr=row.get('FTR','').strip()
        expected='H' if hg>ag else 'A' if hg<ag else 'D'
        if ftr and ftr != expected: issues.append({'row':line,'reason':'FTR_score_disagreement','FTR':ftr,'score_result':expected,'home':home,'away':away})
        key=(parsed.isoformat(),home.casefold(),away.casefold()); dup.setdefault(key,[]).append(line)
        hda=pairs(row,'B365H','B365D'); b365a=num(row.get('B365A'))
        h2h={'home':hda[0],'draw':hda[1],'away':b365a} if hda and b365a is not None else None
        total=None; paired=False; total_same_book=False
        p=pairs(row,'B365>2.5','B365<2.5')
        if p:
            total={'line':2.5,'over':p[0],'under':p[1],'bookmaker':'Bet365','price_pair_basis':'same_book','method':'archived_historical_price_observation_proxy','observation_type':'historical_price_observation_proxy'}; total_same_book=True
        else:
            p=pairs(row,'BbAv>2.5','BbAv<2.5')
            if p:
                total={'line':2.5,'over':p[0],'under':p[1],'bookmaker':'multiple_bookmaker_average','price_pair_basis':'cross_book','method':'cross_book_average_historical_price_proxy','observation_type':'historical_price_observation_proxy'}
        paired=bool(h2h and total_same_book)
        home_code=team_code(home); away_code=team_code(away)
        mid=hashlib.sha256(('football-data|'+comp+'|'+parsed.isoformat()+'|'+home_code+'|'+away_code).encode()).hexdigest()[:24]
        out.append({'id':'football-data:'+mid,'competition':comp,'season':season,'independent_split_role':SEASONS[season],
          'date':parsed.isoformat(),'stage':'regular','source_stage':'regular','leg':None,'neutral':False,
          'home':home,'away':away,'home_team_code':home_code,'away_team_code':away_code,'home_goals':hg,'away_goals':ag,'score_basis':'regulation_90',
          'h2h':h2h,'bookmaker':'Bet365' if h2h else None,'total':total,'paired_market':paired,
          'market_time_basis':'archived_historical_price_observation_proxy_no_quote_clock',
          'source_sha256':digest,'sources':[{'row':line,'sha256':digest,'url':url}]})
    for key,lines in dup.items():
        if len(lines)>1: issues.append({'rows':lines,'reason':'same_home_away_date_duplicate','date':key[0],'home':key[1],'away':key[2]})
    return out,{'source_rows':source_rows,'qualified_matches':len(out),'excluded_or_unresolved_rows':bad,'issues':issues,
      'odds_field_nonempty_rows':odds_nonempty}

def team_code(label):
    # Stable across seasons for the same canonical source label; preserve Unicode without lossy transliteration.
    normalized=unicodedata.normalize('NFC',label.strip()).casefold()
    return 'fdteam:'+hashlib.sha256(normalized.encode('utf-8')).hexdigest()[:16]

def main():
    receipts=[]; recon={}; panels={c:[] for c in LEAGUES}
    for season in SEASONS:
      for comp,div in LEAGUES.items():
        url,body,rec=get_csv(season,div); receipts.append({'season':season,'competition':comp,'division':div,**rec})
        if body is None:
            recon[f'{season}-{div}']={'season':season,'role':SEASONS[season],'competition':comp,'division':div,
              'source_rows':None,'qualified_matches':0,'panel_rows_added':0,'source_unavailable_http_status':rec['http_status']}
            continue
        digest=sha(body)
        rows,audit=parse(body,season,div,comp,url,digest); panels[comp].extend(rows)
        recon[f'{season}-{div}']={'season':season,'role':SEASONS[season],'competition':comp,'division':div,
          'source_sha256':digest,**audit,'panel_rows_added':len(rows)}
        time.sleep(.25)
    for comp,rows in panels.items():
        rows.sort(key=lambda x:(x['date'],x['home'],x['away']))
        (ROOT/'panels'/f'{comp}.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n' for r in rows))
    (ROOT/'raw'/'receipts.json').write_text(json.dumps(receipts,ensure_ascii=False,indent=2))
    (ROOT/'reports'/'reconciliation.json').write_text(json.dumps(recon,ensure_ascii=False,indent=2))
    coverage={}
    for comp,rows in panels.items():
        for season in SEASONS:
            part=[x for x in rows if x['season']==season]
            coverage[f'{comp}/{season}']={'matches':len(part),'h2h_b365_complete':sum(x['h2h'] is not None for x in part),
              'total_2_5_complete':sum(x['total'] is not None for x in part),'paired_market':sum(x['paired_market'] for x in part),
              'no_odds':sum(x['h2h'] is None and x['total'] is None for x in part)}
    (ROOT/'reports'/'coverage.json').write_text(json.dumps(coverage,ensure_ascii=False,indent=2))
if __name__=='__main__': main()
