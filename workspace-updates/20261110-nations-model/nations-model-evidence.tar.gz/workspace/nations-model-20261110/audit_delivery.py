import collections,hashlib,json,pathlib,sys
import numpy as np
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from research.analysis_freeze import verify,aware
from nations_league.model import predict

root=pathlib.Path(__file__).parent
before=json.loads((root/'protected-assets-before.json').read_text())
for path,expected in before.items():assert hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()==expected,path
index=json.loads((root/'models/candidates.json').read_text())
artifact_count=0
for level,route in index['routes'].items():
    dataset=json.loads((root/'models'/level/'dataset.json').read_text())['rows']
    diagnostic=json.loads((root/'models'/level/'diagnostic.json').read_text())
    evaluated=json.loads((root/'models'/level/'evaluation-models.json').read_text())
    assert evaluated['current']['train_end']<'2026-01-01' and evaluated['test']['train_end']<'2026-01-01'
    for role in ('current','test'):
        entries=diagnostic['predictions'][role]
        assert all(r['date']>evaluated[role]['train_end'] for r in entries)
        artifact=json.loads(pathlib.Path(route[role]['path']).read_text())
        assert hashlib.sha256(pathlib.Path(route[role]['path']).read_bytes()).hexdigest()==route[role]['sha256']
        assert artifact['training_n']==len(dataset)
        assert not artifact['activation_allowed'] and not artifact['formal_acceptance_passed']
        artifact_count+=1
    assert [r['match_id'] for r in diagnostic['predictions']['current']]==[r['match_id'] for r in diagnostic['predictions']['test']]
receipts=json.loads((root/'forward-freezes/receipts.json').read_text())
plan_receipt=json.loads((root/'forward-freezes/plan-receipt.json').read_text())
plan=verify(json.loads(pathlib.Path(plan_receipt['path']).read_text()))
ids=set();grades=collections.Counter();reloads=0
for receipt in receipts:
    record=verify(json.loads(pathlib.Path(receipt['path']).read_text()))
    assert record['record_sha256']==receipt['sha256']
    f=record['fixture'];pair=record['payload'];assert f['match_id'] not in ids;ids.add(f['match_id'])
    assert record['evaluation_slot']=='FIRST_PREMATCH'
    assert aware(plan['recorded_at'])<=aware(f['cutoff_at'])<=aware(record['recorded_at'])<aware(f['kickoff_at'])
    grades[f['league_level']]+=1
    for role in ('current','test'):
        p=pair[role];route=index['routes'][f['league_level']][role]
        assert p['input']==f and p['artifact_sha256']==route['sha256'] and not p['acceptance_passed']
        assert aware(p['generated_at'])<=aware(record['recorded_at'])
        assert np.isfinite(p['matrix']).all() and np.isclose(np.sum(p['matrix']),1)
        recalculated=predict(route['path'],f)
        assert np.array_equal(np.array(recalculated['matrix']),np.array(p['matrix']))
        reloads+=1
assert ids=={f['match_id'] for f in plan['payload']['fixture_population']} and len(ids)==52
report={'trained_artifacts':artifact_count,'first_prematch_pairs':len(ids),'grades':dict(grades),
        'exact_matrix_reload_checks':reloads,'protected_asset_hashes_unchanged':len(before),
        'formal_acceptance_passed':False,'active_registry_modified':False,
        'independent_market_quotes_supplied':0,'prospective_completed':0,
        'dependencies_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [pathlib.Path('/workspace/Football-Analysis/runtime/nations_league/model.py'),pathlib.Path('/workspace/Football-Analysis/runtime/v2/model.py'),pathlib.Path('/workspace/Football-Analysis/runtime/research_program/nations_phase.py')]}}
(root/'independent-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False))
