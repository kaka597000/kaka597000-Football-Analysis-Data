import datetime,hashlib,json,os,pathlib,shutil,tarfile

root=pathlib.Path(__file__).parent
data=pathlib.Path('/workspace/nations_model_data/data')
target=pathlib.Path('/workspace/kaka597000-Football-Analysis-Data/workspace-updates/20261110-nations-model')
target.mkdir(parents=True,exist_ok=False)
report=pathlib.Path('/workspace/Football-Analysis/docs/nations-league-model.md').read_text()
(root/'README.md').write_text(report+'\n## 实际交付\n\n独立复核：8个工件、52组首次未来研究冻结、104次矩阵重载一致；41项原运行资产与独立数据库哈希不变。本地680项测试/23组无跳过，静态检查零发现。源码PR #26；远端状态以PR实际检查为准。\n\n所有未来统计Primary独立保存，不作为综合推荐或已验收活动输出。本次未来记录没有合格实盘报价，不得后补为首次已知盘口。\n')
files=[p for base in (root,data) for p in base.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
receipts=json.loads((root/'forward-freezes/receipts.json').read_text())+[json.loads((root/'forward-freezes/plan-receipt.json').read_text())]
files.extend(pathlib.Path(r['path']) for r in receipts)
files=sorted(set(files))
secrets=[v.encode() for k,v in os.environ.items() if len(v)>=12 and any(s in k.lower() for s in ('token','secret','password','api_key','apikey','therundown'))]
entries=[]
for p in files:
    b=p.read_bytes()
    if any(s in b for s in secrets):raise ValueError('credential-value scan failed')
    entries.append({'path':str(p),'archive_path':str(p).lstrip('/'),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
archive=target/'nations-model-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
    for p in files:tar.add(p,arcname=str(p).lstrip('/'),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    expected={x['archive_path']:x['sha256'] for x in entries}
    assert set(tar.getnames())==set(expected)
    for item in tar:assert hashlib.sha256(tar.extractfile(item).read()).hexdigest()==expected[item.name]
manifest={'created_at':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),
          'archive':archive.name,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
          'archive_bytes':archive.stat().st_size,'files':entries,'trained_artifacts':8,'frozen_pairs':52,
          'active_registry_modified':False,'formal_acceptance_passed':False,'credential_values_included':False}
(target/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
for name in ('README.md','independent-audit.json','protected-assets-before.json'):
    shutil.copy2(root/name,target/name)
shutil.copy2(root/'models/candidates.json',target/'candidates.json')
for level in 'ABCD':
    dest=target/'artifacts'/level;dest.mkdir(parents=True)
    for role in ('current','test'):shutil.copy2(root/'models'/level/(role+'-artifact.json'),dest/(role+'-artifact.json'))
with (target/'README.md').open('a') as f:
    f.write('\n[候选索引](candidates.json) · [工件](artifacts) · [完整证据包](nations-model-evidence.tar.gz) · [SHA清单](manifest.json) · [独立复核](independent-audit.json) · [源码PR26](https://github.com/kaka597000/Football-Analysis/pull/26)\n\n核对压缩包SHA后先解压到新目录并核验逐文件SHA。恢复时保留workspace/nations-model-20261110、workspace/nations_model_data/data和workspace/WCPP/forecasts/issued-analyses目录结构，已有不同文件先处理冲突，不覆盖旧冻结。工件中的dataset/protocol/engine路径与SHA必须保持一致；原始历史原文仍依赖上一批欧国联数据快照。单独下载artifact不能替代完整依赖恢复。\n')
print(json.dumps({'files':len(files),'archive_bytes':archive.stat().st_size,'target':str(target)}))
