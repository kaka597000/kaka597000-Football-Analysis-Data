import pathlib,json,hashlib,re,collections,datetime
root=pathlib.Path(__file__).parent.resolve()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def js(x): return json.dumps(x,ensure_ascii=False,separators=(',',':'))
ledger=json.loads((root/'request-ledger.json').read_text())
scoreboards={int(x['url'].split('dates=')[1].split('&')[0]):x for x in ledger if x.get('http_status')==200}
summary_ledger=[]
for line in (root/'summary-request-ledger.jsonl').read_text().splitlines():
 if line.strip(): summary_ledger.append(json.loads(line))
summary_by_id={r['event_id']:r for r in summary_ledger if r.get('body_saved') and r.get('path')}
fixtures=[]; cancel=[]; states=collections.Counter(); stages=collections.Counter(); seasons=collections.Counter(); grades=collections.Counter(); missing_summary=[]
for y in range(2018,2027):
 sp=root/'raw/espn-scoreboards'/f'uefa.nations-{y}.json'
 data=json.loads(sp.read_text()); req=scoreboards[y]
 for e in data.get('events',[]):
  comps=e.get('competitions') or []; c=comps[0] if comps else {}
  season=e.get('season') or {}; slug=season.get('slug'); season_year=season.get('year')
  status=(e.get('status') or {}).get('type') or {}; score_status=(c.get('status') or {}).get('type') or status
  comp_slug=slug
  if slug in ('league-a','league-b','league-c','league-d'): stage='group-stage'
  elif slug in ('group-stage',): stage='group-stage'
  elif slug in ('league-phase',): stage='league-phase'
  elif slug in ('quarterfinals','quarterfinal'): stage='quarterfinals'
  elif slug in ('semifinals','semifinal'): stage='semifinals'
  elif slug=='final': stage='final'
  elif slug in ('third-place-match','3rd-place-match','third-place'): stage='third-place'
  elif slug in ('relegation-playoffs','promotion-playoffs','promotion-relegation-playoffs'): stage='promotion-relegation-playoffs'
  else: stage=None
  grp=c.get('group') or {}
  group_name=grp.get('name') or grp.get('abbreviation') or None
  league=None
  if slug in ('league-a','league-b','league-c','league-d'): league=slug[-1].upper()
  else:
   m=re.search(r'\bGROUP\s+([ABCD])\s*\d*',str(group_name or c.get('altGameNote') or ''),re.I)
   if m: league=m.group(1).upper()
  competitors=c.get('competitors') or []
  hc=next((v for v in competitors if v.get('homeAway')=='home'),None); ac=next((v for v in competitors if v.get('homeAway')=='away'),None)
  def team(v):
   if not v:return {'id':None,'name':None}
   t=v.get('team') or {};return {'id':str(t.get('id') or v.get('id')) if (t.get('id') or v.get('id')) is not None else None,'name':t.get('displayName') or t.get('name') or None}
  completed=status.get('completed') is True
  sb_score={'home':None,'away':None}
  if completed and hc and ac:
   try: sb_score={'home':int(hc['score']),'away':int(ac['score'])}
   except (ValueError,TypeError,KeyError): pass
  summary=summary_by_id.get(str(e.get('id')))
  sm_path=summary.get('path') if summary else None
  neutral=c.get('neutralSite') if isinstance(c.get('neutralSite'),bool) else None
  group_evidence={'scoreboard.competitions[0].group':grp or None,'scoreboard.competitions[0].altGameNote':c.get('altGameNote'),'scoreboard.competitions[0].notes':c.get('notes'),'scoreboard.season.slug':slug}
  phase_ev={'raw_path':str(sp),'raw_sha256':sha(sp),'source_url':req['url'],'event_id':str(e['id']),'query_time':req['query_time'],'source_fields':group_evidence}
  if summary and sm_path:
   sd=json.loads(pathlib.Path(sm_path).read_text()); sh=(sd.get('header') or {}).get('competitions') or [{}]; sh=sh[0]
   phase_ev['summary_source_fields']={'header.season':(sd.get('header') or {}).get('season'),'header.competitions[0].groups':sh.get('groups'),'header.competitions[0].altGameNote':sh.get('altGameNote'),'header.competitions[0].notes':sh.get('notes')}
  rec={'competition_id':'uefa.nations','event_id':str(e['id']),'provider_event_id':str(e['id']),'season_year':season_year,'season_label':f'{season_year}-{str((season_year or 0)+1)[-2:]}' if season_year else None,'season_type':season.get('type'),'season_slug':slug,'league_level':league,'group_id':grp.get('groupId') or group_name,'group_name':group_name,'stage':stage,'phase_evidence':phase_ev,'kickoff_at':e.get('date'),'status':{'name':status.get('name'),'state':status.get('state'),'detail':status.get('detail'),'completed':completed},'home':team(hc),'away':team(ac),'neutral':neutral,'scoreboard_total':sb_score,'h90':None,'a90':None,'home_et':None,'away_et':None,'home_penalties':None,'away_penalties':None,'score_verification':'pending_summary_review' if completed else 'not_applicable','first_known_at':None,'training_eligible':False,'source_kind':'scoreboard','raw_path':str(sp),'raw_sha256':sha(sp),'query_time':req['query_time'],'source_url':req['url'],'summary_raw_path':sm_path,'summary_raw_sha256':summary.get('sha256') if summary else None,'summary_query_time':summary.get('query_time') if summary else None}
  fixtures.append(rec)
  states[(status.get('state'),status.get('detail'),completed)]+=1; stages[stage]+=1; seasons[season_year]+=1; grades[league]+=1
  if completed and not summary: missing_summary.append(str(e['id']))
  if status.get('detail')=='Canceled' or status.get('name')=='STATUS_CANCELED': cancel.append({'event_id':str(e['id']),'season_year':season_year,'kickoff_at':e.get('date'),'status':status,'home':team(hc),'away':team(ac),'source_path':str(sp),'score_not_used':True})
(root/'fixtures.jsonl').write_text('\n'.join(js(r) for r in fixtures)+'\n')
captures=[]
for eid,rec in summary_by_id.items():
 captures.append({'competition_id':'uefa.nations','event_id':eid,'source_kind':'summary','raw_path':str(pathlib.Path(rec['path']).resolve()),'raw_sha256':rec['sha256'],'query_time':rec['query_time'],'source_url':rec['url'],'query_time':rec['query_time'],'first_known_at':None,'http_status':rec['http_status']})
(root/'summary-captures.jsonl').write_text('\n'.join(js(r) for r in captures)+'\n')
(root/'quarantine/canceled-events.json').write_text(json.dumps(cancel,ensure_ascii=False,indent=2)+'\n')
coverage={'competition_id':'uefa.nations','competition_name':'UEFA Nations League','gender':'men','as_of_date':'2026-11-10','scoreboard_calendar_years':list(range(2018,2027)),'scoreboard_requests':len(ledger),'summary_requests_attempted':len(summary_ledger),'summary_requests_successful':len(summary_by_id),'total_network_requests':len(ledger)+len(summary_ledger),'fixture_count':len(fixtures),'unique_event_ids':len(set(x['event_id'] for x in fixtures)),'completed_count':sum(1 for x in fixtures if x['status']['completed']),'scheduled_pre_count':sum(1 for x in fixtures if x['status']['state']=='pre'),'canceled_quarantine_count':len(cancel),'summary_missing_for_completed_count':len(missing_summary),'summary_missing_event_ids':missing_summary,'training_eligible_count':0,'score_verification':'all fixture rows await independent summary/90-minute review; summary capture presence alone is not verification','state_counts':{f'{a}/{b}/{c}':n for (a,b,c),n in states.items()},'stage_counts':dict(stages),'season_start_year_counts':dict(seasons),'league_level_counts':dict(grades),'scoreboard_ledgers':str(root/'request-ledger.json'),'summary_ledger':str(root/'summary-request-ledger.jsonl'),'source_scope_note':'ESPN public endpoint coverage; no independent UEFA completeness reconciliation performed.'}
(root/'coverage.json').write_text(json.dumps(coverage,ensure_ascii=False,indent=2)+'\n')
competition={'competition_id':'uefa.nations','name':'UEFA Nations League','gender':'men','source':'ESPN public soccer API','source_slug':'uefa.nations','espn_league_id':'2395','source_evidence':{'raw_path':str(root/'raw/espn-scoreboards/uefa.nations-2026.json'),'raw_sha256':sha(root/'raw/espn-scoreboards/uefa.nations-2026.json'),'field':'leagues[0].slug','value':'uefa.nations','league_name':'UEFA Nations League'},'season_label_rule':'season_year through next calendar year; original ESPN season.year/type/slug retained per fixture','tier_rule':'only explicit season.slug league-a/b/c/d or source group label GROUP A/B/C/D supports level; otherwise null','neutral_rule':'null unless source has an explicit boolean neutralSite'}
(root/'competition.json').write_text(json.dumps(competition,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'fixtures':len(fixtures),'summaries':len(captures),'missing_summary_completed':len(missing_summary),'canceled':len(cancel),'status':coverage['state_counts'],'stages':dict(stages),'requests':coverage['total_network_requests']},ensure_ascii=False,indent=2))
