import requests,time,json,pathlib,datetime,hashlib
root=pathlib.Path(__file__).parent
ids=[]
for p in sorted((root/'raw/espn-scoreboards').glob('uefa.nations-*.json')):
    y=int(p.stem.rsplit('-',1)[1]); d=json.loads(p.read_text())
    for e in d.get('events',[]):
        if e.get('status',{}).get('type',{}).get('completed') is True:
            ids.append((e['id'],y))
# unique ESPN ids, source sequence is chronological by scoreboard year then event order
ids=list(dict.fromkeys(x[0] for x in ids))
out=root/'raw/espn-summaries'; out.mkdir(parents=True,exist_ok=True)
ledger_path=root/'summary-request-ledger.jsonl'
ledger=[]
for i,eid in enumerate(ids,1):
    path=out/f'{eid}.json'
    if path.exists():
        continue
    queried=datetime.datetime.now(datetime.timezone.utc).isoformat()
    url='https://site.api.espn.com/apis/site/v2/sports/soccer/uefa.nations/summary'
    try:
        resp=requests.get(url,params={'event':eid},timeout=10)
        rec={'provider':'espn','event_id':eid,'url':resp.url,'query_time':queried,'http_status':resp.status_code,'response_bytes':len(resp.content),'sha256':hashlib.sha256(resp.content).hexdigest()}
        if resp.status_code in (401,403,429):
            rec['stopped_batch']=True; ledger.append(rec)
            with ledger_path.open('a') as f:f.write(json.dumps(rec)+'\n')
            print(f'STOP HTTP {resp.status_code} at {i}/{len(ids)} event={eid}',flush=True); break
        if resp.status_code==200:
            try:
                data=resp.json()
                h=data.get('header',{})
                if str(h.get('id')) != eid:
                    rec['identity_error']='header.id mismatch'; rec['body_saved']=False
                else:
                    path.write_bytes(resp.content); rec['path']=str(path); rec['body_saved']=True
            except Exception as ex: rec['parse_error']=type(ex).__name__+': '+str(ex)
        else: rec['body_saved']=False
        ledger.append(rec)
        with ledger_path.open('a') as f:f.write(json.dumps(rec,ensure_ascii=False)+'\n')
        if i%50==0 or i==len(ids): print(f'progress {i}/{len(ids)} saved={sum(x.get("body_saved",False) for x in ledger)}',flush=True)
    except Exception as ex:
        rec={'provider':'espn','event_id':eid,'url':url,'query_time':queried,'error':type(ex).__name__+': '+str(ex),'body_saved':False}
        ledger.append(rec)
        with ledger_path.open('a') as f:f.write(json.dumps(rec,ensure_ascii=False)+'\n')
    time.sleep(.45)
print('done attempts this run',len(ledger),'saved',sum(x.get('body_saved',False) for x in ledger),flush=True)
