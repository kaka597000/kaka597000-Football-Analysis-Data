"""Read-only independent checks of delivered Nations League snapshot."""
import collections
import hashlib
import json
from pathlib import Path
import sqlite3
import sys

ROOT = Path(__file__).parent
sys.path.insert(0, '/workspace/Football-Analysis/runtime')
from competition_scope import training_rows
from nations_league.database import export

db = Path(sys.argv[1])
c = sqlite3.connect('file:' + str(db) + '?mode=ro', uri=True)
c.row_factory = sqlite3.Row
assert c.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
assert not c.execute('PRAGMA foreign_key_check').fetchall()
source_events = {}
for p in sorted((ROOT/'staging/raw/espn-scoreboards').glob('*.json')):
    payload = json.loads(p.read_text())
    assert {x['slug'] for x in payload['leagues']} == {'uefa.nations'}
    for event in payload['events']:
        assert event['id'] not in source_events
        source_events[event['id']] = event
rows = [dict(r) for r in c.execute('SELECT * FROM events')]
assert {r['provider_event_id'] for r in rows} == set(source_events)
for r in rows:
    event = source_events[r['provider_event_id']]
    sides = {x['homeAway']: 'espn:' + x['team']['id'] for x in event['competitions'][0]['competitors']}
    assert r['home_id'] == sides['home'] and r['away_id'] == sides['away']
    if r['status'] == 'STATUS_SCHEDULED':
        assert r['home_90'] is None and r['away_90'] is None and not r['training_eligible']
    if r['training_eligible']:
        assert r['summary_verified'] and r['neutral'] is not None and r['league_level'] and r['stage']
verified_sources = 0
for r in c.execute('SELECT * FROM source_records WHERE raw_verified=1'):
    assert hashlib.file_digest(open(r['raw_path'], 'rb'), 'sha256').hexdigest() == r['raw_sha256']
    verified_sources += 1
baseline = json.loads((ROOT/'baseline-assets.json').read_text())
for path, expected in baseline['sha256'].items():
    assert hashlib.file_digest(open(path, 'rb'), 'sha256').hexdigest() == expected, path
exports = []
for stage, level in c.execute('SELECT DISTINCT stage,league_level FROM events WHERE training_eligible=1 ORDER BY stage,league_level'):
    out = ROOT/'exports'/f'{stage}-{level}.json'
    result = export(db,out,stage,level)
    exported = json.loads(out.read_text())['rows']
    training_rows(exported)
    assert all(r['first_known_at'] is None for r in exported)
    exports.append(result)
audit = {
    'events': len(rows), 'teams': c.execute('SELECT COUNT(*) FROM teams').fetchone()[0],
    'source_inventory_statuses': dict(collections.Counter(e['status']['type']['name'] for e in source_events.values())),
    'projection_statuses': dict(collections.Counter(r['status'] for r in rows)),
    'training_eligible': sum(r['training_eligible'] for r in rows),
    'eligibility_reasons': dict(collections.Counter(r['eligibility_reason'] for r in rows)),
    'verified_source_records': verified_sources,
    'quarantine_reasons': dict(c.execute('SELECT reason,COUNT(*) FROM quarantine GROUP BY reason').fetchall()),
    'phase_exports': exports, 'unchanged_assets': len(baseline['sha256']),
    'independent_provider_verification': False, 'historical_asof_certified': False,
    'integrity_check': 'ok', 'foreign_key_errors': [],
    'database_sha256': hashlib.file_digest(db.open('rb'), 'sha256').hexdigest(),
}
(ROOT/'independent-audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(audit,ensure_ascii=False,indent=2))
