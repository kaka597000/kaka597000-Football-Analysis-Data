"""Create an immutable snapshot archive and inspectable per-file hashes."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import tarfile

root=Path(__file__).parent
db=Path('/workspace/WCPP/data/nations-league/uefa-nations-20261110.sqlite')
target=Path('/workspace/kaka597000-Football-Analysis-Data/workspace-updates/20261110-nations-league')
target.mkdir(parents=True,exist_ok=False)
files=sorted(p for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts)+[db]
secrets=[v.encode() for k,v in os.environ.items() if len(v)>=12 and any(word in k.lower() for word in ('token','secret','password','api_key','apikey','therundown'))]
entries=[]
for p in files:
    b=p.read_bytes()
    if any(s in b for s in secrets):raise RuntimeError('credential-value scan rejected a file')
    entries.append({'path':str(p),'archive_path':str(p).lstrip('/'),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
archive=target/'nations-league-snapshot.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
    for p in files:tar.add(p,arcname=str(p).lstrip('/'),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    by_name={x['archive_path']:x for x in entries}
    assert set(tar.getnames())==set(by_name)
    for member in tar:
        assert hashlib.sha256(tar.extractfile(member).read()).hexdigest()==by_name[member.name]['sha256']
shutil.copy2(db,target/db.name)
for name in ('independent-audit.json','baseline-assets.json','database-stats.json'):
    if (root/name).exists():shutil.copy2(root/name,target/name)
manifest={'schema':'NATIONS-LEAGUE-DELIVERY-1','created_at':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),
    'database':db.name,'database_sha256':hashlib.file_digest(db.open('rb'),'sha256').hexdigest(),
    'archive':archive.name,'archive_sha256':hashlib.file_digest(archive.open('rb'),'sha256').hexdigest(),
    'archive_bytes':archive.stat().st_size,'files':entries,'credential_value_scan':'PASS','archive_members_verified':len(entries),
    'automatic_model_promotion':False,'historical_asof_certified':False}
(target/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'target':str(target),'files':len(entries),'archive_bytes':archive.stat().st_size,'database_sha256':manifest['database_sha256']}))
