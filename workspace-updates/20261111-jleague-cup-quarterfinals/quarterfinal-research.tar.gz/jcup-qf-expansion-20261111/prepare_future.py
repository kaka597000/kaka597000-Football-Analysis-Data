import json,sys
from pathlib import Path
from datetime import datetime,timezone
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from jleague_cup import quarterfinals as q,database
b=Path('/workspace/jcup-qf-expansion-20261111');cert=q.certificate(b/'rules-certificate.json');new=json.loads((b/'staging/next-leg-sources.json').read_text())['matches'];oldroot=Path('/workspace/jleague-cup-today-20261111/staging');old=json.loads((oldroot/'sources.json').read_text())['sources'];now=datetime.now(timezone.utc).isoformat();fixtures=[]
for s,root in [(x,oldroot) for x in old if '/match/leaguecup/' in x['url']]+[(x,b/'staging') for x in new]:
 raw=(root/s['raw_path']).read_text();matches=q.official_match_objects(raw);assert len(matches)==1;m=matches[0];eid=s['url'].rstrip('/').split('/')[-1];leg=1 if eid.startswith('1111') else 2;kickoff=m['date'][2:];f={'match_id':'jleague:'+eid,'competition':'jpn.league_cup','edition':'2026/27','gender':'men','age':'senior','stage':'quarterfinals','tie_format':'two-leg','leg':leg,'phase':'PreMatch','neutral':None,'date':kickoff[:10],'kickoff_at':kickoff,'cutoff_at':now,'phase_evidence':{'raw_path':str(root/s['raw_path']),'raw_sha256':s['sha256'],'source_url':s['url'],'query_time':s['requested_at_utc']}}
 for side in ['home','away']:
  code=m[side+'Team']['code'];f[side+'_official_code']=code;f[side]=database.team(cert['team_aliases'][code]['historical_name']);f[side+'_name']=cert['team_aliases'][code]['official_name']
 q.target_identity(f,cert);fixtures.append(f)
assert len(fixtures)==8
(b/'future-fixtures.json').write_text(json.dumps(sorted(fixtures,key=lambda f:f['match_id']),ensure_ascii=False,indent=2));print('verified eight fixture identities')
