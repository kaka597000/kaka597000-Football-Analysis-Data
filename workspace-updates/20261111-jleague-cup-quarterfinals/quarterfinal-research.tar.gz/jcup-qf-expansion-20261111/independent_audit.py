import json,sys,hashlib,sqlite3
from pathlib import Path
from datetime import datetime,timezone
import numpy as np
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from jleague_cup import database,model,quarterfinals as q,evidence
from research.analysis_freeze import verify,save
b=Path('/workspace/jcup-qf-expansion-20261111');old=database.rows('/workspace/WCPP/data/jleague-cup/jleague-cup-20261111.sqlite');new=database.rows('/workspace/WCPP/data/jleague-cup/jleague-cup-expanded-20261111.sqlite');by={r['match_id']:r for r in new};cols=['date','home','away','stage','leg','home_goals','away_goals','neutral']
for r in old:assert all(r[k]==by[r['match_id']][k] for k in cols)
protected=json.loads((b/'protected-assets-before.json').read_text());assert all(evidence.sha(p)==sha for p,sha in protected.items())
index=q.read(b/'final-models/candidates.json');reloaded=0;folds=[]
for leg,route in index['routes'].items():
 report=q.read(route['report_path']);assert report['n']==12 and report['formal_acceptance_passed'] is False
 for fold in report['folds']:
  assert not set(fold['fit_ids'])&set(fold['target_ids']);assert fold['target_edition']=='2025';assert len(fold['fit_ids'])==8
  for role,core in fold['cores'].items():
   assert core['fit_end'][:4]<'2025'
   for p in fold['predictions'][role]:
    m,mu=model.distribution(core,by[p['match_id']]);assert np.array_equal(m,np.asarray(p['matrix']));reloaded+=1
 folds.append({'leg':int(leg),'fit_n':8,'held_out_n':4,'current_hits':report['metrics']['current']['primary']['hits'],'test_hits':report['metrics']['test']['primary']['hits'],'current_score_log_loss':report['metrics']['current']['metrics']['score_log_loss'],'test_score_log_loss':report['metrics']['test']['metrics']['score_log_loss']})
future=q.read(b/'future-fixtures.json');receipts=q.read(b/'forward-freezes/receipts.json');assert len(receipts['receipts'])==4 and len(receipts['deferred'])==4
forward=0;unknown={}
for p in (b/'forward-freezes').glob('*.json'):
 d=q.read(p)
 if 'fixture' not in d:continue
 r=verify(q.read(d['freeze_receipt']['path']));assert r['payload']==d['payload'];assert evidence.aware(r['recorded_at'])<evidence.aware(d['fixture']['kickoff_at'])
 for role,ref in index['routes']['1']['artifacts'].items():
  assert evidence.sha(ref['path'])==ref['sha256'];v=q.predict(ref['path'],d['fixture']);assert v==d['payload'][role];forward+=1
  if v['unseen_teams_using_fitted_prior']:unknown[d['fixture']['match_id']]=v['unseen_teams_using_fitted_prior']
for r in [receipts['scope_freeze'],q.read(b/'protocol-freeze-receipt.json')]:verify(q.read(r['path']))
old_freezes=0
for name in ['freeze-receipts.json','model-receipts.json']:
 for r in q.read(Path('/workspace/jleague-cup-today-20261111')/name):
  rec=verify(q.read(r['path']));assert rec['record_sha256']==r['sha256'];old_freezes+=1
sources=q.read(b/'staging/sources.json')['sources'];checked=0;newrequests=0
for s in sources:
 p=b/'staging'/s['raw_path'];expected=s.get('sha256',s.get('raw_sha256'));assert evidence.sha(p)==expected;checked+=1;newrequests+=bool(s.get('requested_at_utc'))
result={'created_at':datetime.now(timezone.utc).isoformat(),'inventory_total':len(new),'added_inventory':len(new)-len(old),'original_fact_rows_unchanged':len(old),'qf_inventory':32,'qf_eligible':24,'excluded_2022_qf':8,'trained_artifacts':4,'folds':folds,'diagnostic_matrices_reloaded_exact':reloaded,'forward_matrices_reloaded_exact':forward,'scope_fixtures':8,'issued_first_leg_pairs':4,'deferred_second_leg_pairs':4,'unseen_teams':unknown,'historical_neutral_known':0,'historical_asof_certified':False,'formal_acceptance_passed':False,'protected_assets_unchanged':len(protected),'prior_freezes_unchanged':old_freezes,'source_hashes_checked':checked,'actual_new_http_requests':newrequests,'active_registry_modified':False}
q.model.write(b/'independent-audit.json',result)
now=datetime.now(timezone.utc).isoformat();r=save(result,{'match_id':'jcup-qf-model-audit-20261111','kickoff_at':now,'cutoff_at':now},stage='review',track='model-readiness-audit');q.model.write(b/'audit-freeze-receipt.json',r)
print(json.dumps(result,ensure_ascii=False,indent=2))
