import sys,json
from pathlib import Path
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from jleague_cup.database import build
from jleague_cup.evidence import sha
b=Path('/workspace/jcup-qf-expansion-20261111');s=json.loads((b/'staging/sources.json').read_text())['sources'];m=json.loads(Path('/workspace/jleague-cup-20261111/build-manifest.json').read_text());r=next(x for x in s if x.get('request_id')=='betexplorer-2022-results');p=b/'staging'/r['raw_path'];assert sha(p)==r['sha256'];m['sources'].append({'raw_path':str(p),'raw_sha256':r['sha256'],'source_url':r['url'],'query_time':r['requested_at_utc']});(b/'build-manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2));out=Path('/workspace/WCPP/data/jleague-cup/jleague-cup-expanded-20261111.sqlite');result=build(m,out);(b/'inventory-stats.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result['counts']))
