import json,sys,re,sqlite3
from pathlib import Path
from datetime import datetime,timezone
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from jleague_cup import quarterfinals as q,database,evidence
b=Path('/workspace/jcup-qf-expansion-20261111');st=b/'staging';sources=json.loads((st/'sources.json').read_text())['sources'];by={x.get('request_id'):x for x in sources if x.get('request_id')}
def ref(name):
 r=by[name];p=st/r['raw_path'];assert evidence.sha(p)==r['sha256'];return {'source_url':r['url'],'raw_path':str(p),'raw_sha256':r['sha256'],'query_time':r['requested_at_utc']}
c={'schema':'WCPP-JCUP-QF-RULES-1','reviewed':True,'reviewed_at':datetime.now(timezone.utc).isoformat(),'reviewer':'primary_agent','compatibility_scope':'quarterfinal_mechanics_only','target_edition':'2026/27','historical_editions':['2023','2024','2025'],'population_equivalence_claimed':False,'population_caveats':['2023 group entry; 2024/25 all-league knockout entry; 2026/27 altered entry and calendar','not interchangeable population or empirically validated transfer'],'editions':{},'excluded':{'2022':'away goals applies before extra time; retain inventory only','2021':'not collected; not admitted by rule certification'},'team_aliases':{}}
for year in ['2023','2024','2025','2026/27']:
 s=ref('official-outline-leaguecup' if year=='2026/27' else 'official-'+year);raw=Path(s['raw_path']).read_text();visible=q.text(raw)
 start=visible.index('準々決勝、準決勝（ホーム＆アウェイ）');end=visible.index('決勝（1試合）',start+15);block=visible[start:end]
 assert '90分間（前後半各45分）' in block and '2試合の得失点差' in block and '30分間（前後半各15分）の延長戦' in block and 'PK' in block
 if year=='2023':assert 'アウェイゴールルールは撤廃' in block
 elif year!='2026/27':assert 'アウェイゴールルールは無し' in block
 else:assert 'アウェイゴール' not in block
 c['editions'][year]={'rules':q.RULES,'support':{k:[{**s,'excerpt':block}] for k in q.RULES},'away_goals_basis':'complete exhaustive tiebreak order contains no away-goals step' if year=='2026/27' else 'explicit abolition/no-away-goals statement'}
old=json.loads(Path('/workspace/jleague-cup-20261111/official-fixtures-verified.json').read_text());jp_sources=json.loads(Path('/workspace/jleague-cup-today-20261111/staging/sources.json').read_text())['sources'];jp={r['url'].rstrip('/').split('/')[-1]:r for r in jp_sources if '/match/leaguecup/' in r['url']}
history_names={'kobe':'Vissel Kobe','machida':'Machida','urawa':'Urawa Reds','cosaka':'Cerezo Osaka','yokohamafm':'Yokohama F. Marinos','kashima':'Kashima Antlers','kawasakif':'Kawasaki Frontale','kashiwa':'Kashiwa Reysol'}
for eid in ['111101','111102','111103','111104']:
 en=ref('official-en-match-'+eid);en_obj=q.official_match_objects(Path(en['raw_path']).read_text());j=jp[eid];jp_path=Path('/workspace/jleague-cup-today-20261111/staging')/j['raw_path'];assert evidence.sha(jp_path)==j['sha256'];jp_obj=q.official_match_objects(jp_path.read_text());assert len(en_obj)==len(jp_obj)==1
 for side in ['home','away']:
  a,en_team=jp_obj[0][side+'Team'],en_obj[0][side+'Team'];assert a['code']==en_team['code'];code=a['code']
  c['team_aliases'][code]={'reviewed':True,'official_name':a['name'],'official_english_name':en_team['name'],'historical_name':history_names[code],'mapping_basis':'same official match ID, side, teamId and code across JP/EN; provider alias manually reviewed, not fuzzy matching','english_source':en,'historical_name_is_provider_identifier':False}
(b/'rules-certificate.json').write_text(json.dumps(c,ensure_ascii=False,indent=2));q.certificate(b/'rules-certificate.json')
db='/workspace/WCPP/data/jleague-cup/jleague-cup-expanded-20261111.sqlite';allrows=database.rows(db);historical=[r for r in allrows if r['stage']=='quarterfinals'];paired=q.pair_history(allrows,c['historical_editions']);byid={r['match_id']:r for r in paired}
context=Path('/workspace/WCPP/data/jleague-cup/quarterfinal-context-20261111.sqlite');context.parent.mkdir(exist_ok=True,parents=True)
with context.open('xb'):pass
conn=sqlite3.connect(context);conn.executescript('CREATE TABLE matches(match_id TEXT PRIMARY KEY,edition TEXT NOT NULL,leg INTEGER NOT NULL CHECK(leg IN(1,2)),eligible INTEGER NOT NULL CHECK(eligible IN(0,1)),first_leg_id TEXT,aggregate_home INTEGER,aggregate_away INTEGER,reason TEXT NOT NULL,payload_json TEXT NOT NULL); CREATE TABLE metadata(key TEXT PRIMARY KEY,value_json TEXT NOT NULL); CREATE TRIGGER immutable_matches_update BEFORE UPDATE ON matches BEGIN SELECT RAISE(ABORT,"immutable snapshot");END; CREATE TRIGGER immutable_matches_delete BEFORE DELETE ON matches BEGIN SELECT RAISE(ABORT,"immutable snapshot");END;')
for r in historical:
 enriched=byid.get(r['match_id'],r);eligible=r['match_id'] in byid;reason='MECHANISM_ALIGNED_TRANSFER_RESEARCH' if eligible else 'EXCLUDED_AWAY_GOALS_ERA'
 conn.execute('INSERT INTO matches VALUES(?,?,?,?,?,?,?,?,?)',(r['match_id'],r['season'],r['leg'],int(eligible),enriched.get('first_leg_match_id'),enriched.get('aggregate_before_home'),enriched.get('aggregate_before_away'),reason,json.dumps(enriched,ensure_ascii=False)))
conn.execute('INSERT INTO metadata VALUES(?,?)',('rules_certificate',json.dumps(c,ensure_ascii=False)));conn.execute('INSERT INTO metadata VALUES(?,?)',('protocol',json.dumps(q.read(b/'preregistered-protocol.json'))));conn.commit();assert conn.execute('PRAGMA integrity_check').fetchone()[0]=='ok';conn.close()
(b/'context-database.json').write_text(json.dumps({'path':str(context),'sha256':evidence.sha(context),'rows':len(historical),'eligible':len(paired),'excluded':len(historical)-len(paired),'historical_first_known':None,'venue_known_n':0},indent=2))
print('certificate and context DB',len(historical),len(paired))
