import sys,json,hashlib
from datetime import datetime,timezone,timedelta
from pathlib import Path
import numpy as np
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from active_route_engines import predict_v4_compat
r=json.loads(Path('/workspace/WCPP/runtime/active-model.json').read_text())['models']['jpn.1'];now=datetime.now(timezone.utc);kickoff=now+timedelta(days=2)
f={'match_id':'SYNTHETIC-J1-CURRENT-ONLY-LOAD-NOT-MATCH','competition':'jpn.1','cohort':'jpn.1','stage':'regular','gender':'men','age':'senior','phase':'PreMatch','date':kickoff.date().isoformat(),'home':'3384','away':'3385','neutral':False,'kickoff_at':kickoff.isoformat(),'cutoff_at':now.isoformat(),'sources':[{'source_url':'https://example.org/synthetic-software-check','query_time':now.isoformat()}]}
p=predict_v4_compat(r['artifact_path'],f);m=np.asarray(p['matrix']);assert abs(m.sum()-1)<1e-9 and np.isfinite(m).all()
sys.path.insert(0,'/workspace/Football-Analysis/runtime/optimization_tools');import candidate
art=json.loads(Path(r['test_artifact_path']).read_text())
v={'synthetic_load_test_only':True,'published_prediction':False,'current_only_loaded':True,'current_matrix_sum':float(m.sum()),'current_status':p['status'],'test_expected_engine_hash':art['optimization_code_hash'],'test_actual_engine_hash':candidate.code_hash(),'test_finalizer_matches':art['finalizer_sha256']==candidate.file_hash(candidate.__file__),'current_ids_in_history':all(any(row['home']==tid or row['away']==tid for row in json.loads(Path(r['artifact_path']).read_text())['history']) for tid in ['3384','3385']),'test_ids_in_fitted_teams':all('espn:'+tid in art['core']['teams'] for tid in ['3384','3385'])}
Path('/workspace/football-skills-audit-20261111/j1-current-and-dependency-check.json').write_text(json.dumps(v,indent=2));print(json.dumps(v,indent=2))
