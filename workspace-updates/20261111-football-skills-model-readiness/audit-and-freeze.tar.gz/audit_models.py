import sys,json,hashlib
from pathlib import Path
from datetime import datetime,timezone,timedelta
import numpy as np
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from prediction_engine import predict_models
from active_route_engines import predict_v4_compat,predict_systematic_candidate
root=Path('/workspace/football-skills-audit-20261111');reg=json.loads(Path('/workspace/WCPP/runtime/active-model.json').read_text());route=reg['models']['jpn.1'];now=datetime.now(timezone.utc);future=now+timedelta(days=2)
f={'match_id':'SYNTHETIC-J1-LOAD-AUDIT-NOT-A-REAL-FIXTURE','cohort':'jpn.1','competition':'jpn.1','season':'2026/27','date':future.date().isoformat(),'home':'espn:3384','away':'espn:3385','neutral':False,'stage':'regular','gender':'men','age':'senior','phase':'PreMatch','kickoff_at':future.isoformat(),'cutoff_at':now.isoformat(),'sources':[{'source_url':'https://example.org/synthetic-software-check','query_time':now.isoformat()}]}
results={'audit_type':'LOAD_DIAGNOSTIC_NOT_MATCH_FORECAST_NOT_PERFORMANCE_TEST','created_at':now.isoformat(),'j1':{'route_present':True,'formal_promotion':route['formal_promotion'],'artifacts':{},'runs':[]},'nations':{'active_routes':[k for k in reg['models'] if k.startswith('uefa.nations')],'candidates':[]}}
for key in ['','test_']:
 p=Path(route[key+'artifact_path']);a=json.loads(p.read_text());actual=hashlib.sha256(p.read_bytes()).hexdigest();assert actual==route[key+'artifact_sha256'];results['j1']['artifacts'][key or 'current']={'path':str(p),'sha256':actual,'training_cutoff':a.get('train_end',a.get('core',{}).get('fit_end')),'acceptance':a.get('acceptance'),'configuration':a.get('configuration'),'fit_n':len(a.get('history',[])) or a.get('core',{}).get('fit_n')}
for ids in ['canonical','numeric']:
 target=dict(f)
 if ids=='numeric':target.update(home='3384',away='3385')
 try:
  state=predict_models(target);entry={'ids':ids,'status':'PAIR_LOADED','current_status':state['current']['status'],'test_status':state['experimental']['status'],'matrix_sums':[float(np.asarray(state[k]['matrix']).sum()) for k in ['current','experimental']]}
  (root/('j1-'+ids+'-pair.json')).write_text(json.dumps({'fixture':target,'current':state['current'],'test':state['experimental']},ensure_ascii=False))
 except Exception as e:entry={'ids':ids,'status':'ERROR','error':type(e).__name__+': '+str(e)}
 results['j1']['runs'].append(entry)
# Isolated test comparisons disclose whether identifiers silently change team features.
for ids in ['canonical','numeric']:
 target=dict(f)
 if ids=='numeric':target.update(home='3384',away='3385')
 try:
  p=predict_systematic_candidate(route['test_artifact_path'],target);results['j1']['runs'].append({'test_only_ids':ids,'status':'LOADED','means':p.get('expected_goals'),'matrix_hash':p['matrix_hash'],'provenance':p.get('provenance')})
 except Exception as e:results['j1']['runs'].append({'test_only_ids':ids,'error':str(e)})
from nations_league.model import predict
index=json.loads(Path('/workspace/nations-model-20261110/models/candidates.json').read_text());fixtures=json.loads(Path('/workspace/nations-model-20261110/future-fixtures.json').read_text())
for level,roles in index['routes'].items():
 fixture=next(x for x in fixtures if x['league_level']==level and datetime.fromisoformat(x['kickoff_at'])>now)
 for role,r in roles.items():
  assert hashlib.sha256(Path(r['path']).read_bytes()).hexdigest()==r['sha256']
  p=predict(r['path'],fixture);m=np.asarray(p['matrix']);assert np.isfinite(m).all() and (m>=0).all() and abs(m.sum()-1)<1e-9
  results['nations']['candidates'].append({'level':level,'role':role,'artifact_sha256':r['sha256'],'loaded':True,'acceptance_passed':p['acceptance_passed'],'training_cutoff':p['training_data_cutoff'],'matrix_sum':float(m.sum()),'basis':'existing Nov10 frozen fixture reloaded; no new prediction published'})
results['nations']['acceptance_summary']=[{'level':r['level'],'fit_n':r['fit_n'],'holdout_n':r['holdout_n'],'current_hits':r['current']['primary']['hits'],'test_hits':r['test']['primary']['hits']} for r in index['summary']]
(root/'model-audit.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print(json.dumps(results,ensure_ascii=False,indent=2))
