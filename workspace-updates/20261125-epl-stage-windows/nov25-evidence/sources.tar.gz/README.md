# EPL first-window source package (PR53 review material)

Coverage is the 10 fixtures in `current-evidence-10.json` and the latest completed match for each of their 20 teams, as observed on 2026-11-25. This package is a compact evidence bundle for review; it does not assert redistribution rights or make a publication decision.

## Files

- `source-index.csv` / `.json`: one row per target team, with target ESPN event/team identity; prior match date, FotMob ID, round, FT score and status; xG and shots on target for/against; prior-match formation and XI; source URL, observation time and raw SHA-256.
- `current-espn-odds.csv` / `.json`: one DraftKings actual sportsbook market row per target event from ESPN summary responses. It preserves the displayed American odds for home/draw/away and both sides of the displayed total. ESPN responses provide query/retrieval times but no provider quote timestamp; these are page/API observations, not provider-clock-qualified quotes.
- `raw/fotmob/`: exact public matchDetails response bodies and capture sidecars for the latest matches.
- `raw/espn/`: exact public summary responses and sidecars for the 10 target events; the Nov 23 scoreboard response is retained as an additional FT cross-check for Brentford–Everton.
- `rebuild_index.py`: standard-library-only reconstruction of both indexes.

## Independent field reconstruction

1. Hash each body with SHA-256 and compare it with the matching sidecar and index row.
2. Read `header.status`: require `finished=true`, `awarded=false`, and `reason.short=FT`. Read match date/clock from `status.utcTime`; read score from `status.scoreStr` and independently preserve `header.teams[].score` in home/away order.
3. In `content.stats.Periods.All.stats[*].stats[*]`, select `key=expected_goals` and `key=ShotsOnTarget`. Their two-element `stats` arrays are home then away. Orient “for” and “against” using the target team's exact name in `header.teams`.
4. Select `content.lineup.homeTeam` or `.awayTeam` by that same identity; preserve formation and the 11 `starters[].name` values. This is the previous match XI, not the upcoming lineup.
5. For current odds, select the `odds[]` row whose provider name is DraftKings. `homeTeamOdds.moneyLine`, `drawOdds.moneyLine`, `awayTeamOdds.moneyLine`, `overUnder`, `overOdds`, and `underOdds` are retained as displayed. The response has no provider quote clock, so do not substitute request time for that field.
6. Run `python3 rebuild_index.py` from this directory to regenerate the CSV/JSON indexes and verify coverage counts.

## Roster/availability evidence

The retained ESPN summaries do not include an `injuries` field or confirmed current availability report. Accordingly, current verified injury status is 0/20. The previous-match XI is the only player-level evidence indexed here and must not be treated as current availability.

## Odds access / budget

The one previously attempted The Odds API call returned HTTP 401 with `x-requests-remaining: 0` and `x-requests-used: 500`; no retry was made. The environment exposes the project-supported InferSports credential alias, but there is no shared `/workspace/WCPP/cache/quota.sqlite` ledger or verified remaining-cost allowance. The quota policy says unknown budgets must not trigger requests. Project history records an InferSports 401 on 2026-11-12, followed by successful archived quote responses on 2026-11-23 (HTTP 200; rate-limit headers were per-window and as low as 2 remaining, not a current account-credit balance). No live request was made because current cost allowance is unknown. ESPN public summary responses were already available and returned actual DraftKings and Bet365 price rows for all 10 target events. This package indexes a consistent DraftKings row; provider quote timestamps are absent in those responses.
