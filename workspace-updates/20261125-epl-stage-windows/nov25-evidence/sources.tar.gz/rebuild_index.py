#!/usr/bin/env python3
"""Rebuild source indexes from bundled FotMob and ESPN public JSON responses."""
import csv, hashlib, json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
def read(p): return json.loads(p.read_text(encoding='utf-8'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def pair(doc,key):
    for section in doc['content']['stats']['Periods']['All']['stats']:
        for stat in section.get('stats',[]):
            if stat.get('key')==key:
                return [float(v) if key=='expected_goals' else int(v) for v in stat['stats']]
    raise KeyError(key)

base=read(ROOT/'current-evidence-10.json')
rows=[]
for fixture in base['fixtures']:
    for side in ('home','away'):
        rec=next(x for x in fixture['xg_recent_latest_match_per_side'] if x['fixture_side']==side)
        mid=str(rec['fotmob_match_id']); raw=ROOT/'raw/fotmob'/f'match-{mid}.json'; doc=read(raw)
        teams=doc['header']['teams']; status=doc['header']['status']; lineup=doc['content']['lineup']
        idx=next((i for i,t in enumerate(teams) if t['name']==rec['team_name']),None)
        if idx is None: raise ValueError(f"team mismatch: {rec['team_name']} {mid}")
        if not status.get('finished') or status.get('awarded') or status.get('reason',{}).get('short')!='FT':
            raise ValueError(f"not ordinary FT match: {mid} {status}")
        sidekey='homeTeam' if idx==0 else 'awayTeam'; starters=lineup[sidekey]['starters']
        xg=pair(doc,'expected_goals'); sot=pair(doc,'ShotsOnTarget')
        meta=read(Path(str(raw)+'.metadata.json'))
        rows.append({
          'target_event_id':fixture['event_id'],'target_fixture':fixture['name'],'target_kickoff_utc':fixture['kickoff_utc'],
          'team_name':rec['team_name'],'team_espn_id':rec['team_id'],'target_side':side,
          'last_match_date_utc':status['utcTime'][:10],'last_match_kickoff_utc':status['utcTime'],'last_match_id_fotmob':mid,
          'last_match_round':doc.get('general',{}).get('leagueRoundName'),'last_match_status':status.get('reason',{}).get('short'),'awarded':status.get('awarded'),
          'last_match_ft90_score':status.get('scoreStr'),'last_match_home_team':teams[0]['name'],'last_match_home_score':teams[0]['score'],
          'last_match_away_team':teams[1]['name'],'last_match_away_score':teams[1]['score'],'opponent':teams[1-idx]['name'],
          'xg_for':xg[idx],'xg_against':xg[1-idx],'shots_on_target_for':sot[idx],'shots_on_target_against':sot[1-idx],
          'last_match_formation':lineup[sidekey].get('formation'),'last_match_starters':' | '.join(p['name'] for p in starters),
          'fotmob_url':meta['url'],'fotmob_observed_at_utc':meta.get('observed_at') or meta.get('retrieval_time_utc'),
          'fotmob_sha256':sha(raw),'fotmob_raw_file':str(raw.relative_to(ROOT)),
          'current_roster_injury_clue':'No explicit current injury/availability report in retained ESPN summary; prior-match XI only.'})
rows.sort(key=lambda r:r['team_name'])
if len(rows)!=20 or len({r['team_espn_id'] for r in rows})!=20: raise ValueError('expected 20 unique teams')
with (ROOT/'source-index.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
ft=sum(r['last_match_status']=='FT' and not r['awarded'] for r in rows)
(ROOT/'source-index.json').write_text(json.dumps({'coverage':{'teams':len(rows),'ordinary_FT':ft,'xg':len(rows),'shots_on_target':len(rows),'prior_starting_XI':len(rows),'verified_current_injury_status':0},'rows':rows},ensure_ascii=False,indent=2)+'\n')

markets=[]
for fixture in base['fixtures']:
    eid=fixture['event_id']; raw=ROOT/'raw/espn'/f'summary-{eid}.json'; doc=read(raw); meta=read(ROOT/'raw/espn'/f'summary-{eid}.metadata.json')
    o=next((v for v in doc.get('odds',[]) if v.get('provider',{}).get('name')=='DraftKings'),None)
    if o is None: raise ValueError(f'no DraftKings prices: {eid}')
    away_name, home_name=fixture['name'].split(' at ',1)
    markets.append({'event_id':eid,'fixture':fixture['name'],'kickoff_utc':fixture['kickoff_utc'],'bookmaker':o['provider']['name'],
      'home_team':home_name,'away_team':away_name,
      'home_moneyline_american':o.get('homeTeamOdds',{}).get('moneyLine'),'draw_moneyline_american':o.get('drawOdds',{}).get('moneyLine'),
      'away_moneyline_american':o.get('awayTeamOdds',{}).get('moneyLine'),'total_line':o.get('overUnder'),
      'over_moneyline_american':o.get('overOdds'),'under_moneyline_american':o.get('underOdds'),
      'provider_quote_time_utc':None,'provider_clock_note':'not supplied; query/retrieval time is not provider quote time',
      'query_time_utc':meta.get('query_time_utc'),'retrieval_time_utc':meta.get('retrieval_time_utc'),
      'source_url':meta.get('url'),'source_sha256':sha(raw),'raw_file':str(raw.relative_to(ROOT))})
(ROOT/'current-espn-odds.json').write_text(json.dumps({'coverage':{'fixtures':len(markets),'actual_sportsbook_quotes':len(markets),'provider_quote_clock':0},'rows':markets},ensure_ascii=False,indent=2)+'\n')
with (ROOT/'current-espn-odds.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(markets[0])); w.writeheader(); w.writerows(markets)
print(f'20 teams; ordinary FT={ft}; xG/SOT/prior XI=20/20; current injury status=0/20; ESPN sportsbook quotes={len(markets)}/10, provider clocks=0/10')
