"""Freeze this complete research analysis and its TOP3 without overwriting prior issues."""
import csv,hashlib,json,subprocess,sys
from pathlib import Path
from datetime import datetime,timezone
from zoneinfo import ZoneInfo
import numpy as np
CODE=Path('/workspace/Football-Analysis-nations-repair-20261116');sys.path.insert(0,str(CODE/'runtime'))
from prediction_engine import predict_models
from research.analysis_freeze import save,verify
from research.team_goal_analysis import summarize_prediction
from research.score_distribution_audit import audit_prediction,comprehensive_audit
from research.market_movement import analyze
from research_program.future_validation import quote_audit
from v2.model import total_settlement
R=Path(__file__).resolve().parent;F=Path('/workspace/WCPP/forecasts/issued-analyses');BJT=ZoneInfo('Asia/Shanghai')
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):
 with Path(p).open('x') as h:json.dump(x,h,ensure_ascii=False,indent=2,allow_nan=False)
def now():return datetime.now(timezone.utc).isoformat()
def bt(t):return datetime.fromisoformat(t.replace('Z','+00:00')).astimezone(BJT).strftime('%m-%d %H:%M:%S')
def pct(x):return f'{x:.1%}'
def display(x):return x if x is not None else '待定'
def githead(path):return subprocess.check_output(['git','-C',str(path),'rev-parse','HEAD'],text=True).strip()
fs=read(R/'prepared-fixtures.json');choices=read(R/'selections.json');crs=read(R/'candidate-update/receipts.json');updates={x['match_id']:x for x in read(R/'repair-updates.json')};forms=read(R/'verified-form.json');process=read(R/'verified-process.json');windows=read(R/'process-windows.json');pindex=read(R/'process-window-index.json');audit=read(R/'source-audit.json');groups=read(R/'data/standings.json')['groups'];web=read(R/'web-context/red-card-eligibility-check.json')
source_identity={'analysis_and_repair_code':githead(CODE),'original_pair_execution_code':githead('/workspace/Football-Analysis'),'original_model_engine_sha256':sha('/workspace/Football-Analysis/runtime/nations_league/model.py')}
registry='/workspace/WCPP/runtime/active-model.json';registry_before=sha(registry);assert registry_before=='923e34fc44cda33fe965498a24a2435abb37a01a80c539108d8ec20d490bf013'
assert len(fs)==len(crs)==len(choices)==10 and audit['status']=='PASS'
prepared=[]
for f,cr in zip(fs,crs):
 choice=dict(choices[f['source_event_id']]);choice['primary']=None if choice['primary']=='待定' else choice['primary'];q=f['total_quote'];assert quote_audit(dict(f,cutoff_at=now()))['eligible']
 try:predict_models(dict(f,cutoff_at=now()))
 except ValueError as e:assert str(e)=='no validated identity/history model for this cohort'
 else:raise ValueError('active route changed')
 record=verify(read(cr['path']));assert record['record_sha256']==cr['sha256'];pair={r:record['payload'][r] for r in ['current','test']}
 selection={k:choice[k] for k in ['compared_scores','zero_vs_one','three_plus_path','total_reason']}
 selection.update(wdl_evidence={'reason':choice['wdl_reason'],'counterevidence':choice['wdl_counter']},total_evidence={'reason':choice['total_reason'],'counterevidence':choice['counter']})
 payload=dict(choice,selection_scope='candidate_research',method_version='WCPP-NATIONS-MANUAL-20261116-1',status='ABSTAIN_SCORE_PERSONNEL_UNRESOLVED' if choice['primary'] is None else 'RESEARCH_COMPREHENSIVE',total_line=q['line'],actual_quote=q,candidate_reference=cr,selection_evidence=selection,formal_kpi_eligible=False,active_model_promotion=False,numerical_weights_changed=False,exact_score_basis='regulation_90')
 check=comprehensive_audit(payload,{'current_model':pair['current'],'test_model':pair['test']})
 if choice['primary'] is not None:assert check['top3_ready'],(f['match_id'],check['missing_comparisons'])
 else:assert check['status']=='ABSTAIN'
 prepared.append((f,cr,pair,payload))
# All records pass evidence/comparison preflight before any new comprehensive freeze.
records=[]
for f,cr,pair,payload in prepared:
 failed={'status':'ABSTAIN_NO_ACTIVE_ROUTE','matrix':None,'primary':None,'input':f}
 active=save({'current_model':dict(failed,model_label='当前模型'),'test_model':dict(failed,model_label='test模型'),'active_registry_sha256':registry_before,'candidate_substitution':False},dict(f,cutoff_at=now()),stage='prematch',track='current-test-pair',root=F)
 candidate_outputs={}
 for role,p in pair.items():
  candidate_outputs[role]=dict(p,team_goal_analysis=summarize_prediction(p),score_distribution_audit=audit_prediction(p,payload['primary']),actual_total_settlement={s:total_settlement(np.asarray(p['matrix']),f['total_quote']['line'],s) for s in ['over','under']})
 relevant_ids={mid for w in pindex if w['fixture_id']==f['source_event_id'] for mid in w['event_ids']}
 payload.update(current_test_reference=active,candidate_outputs=candidate_outputs,repair_reference=updates[f['match_id']]['receipt'],current_edition_form=[x for x in forms if x['fixture_id']==f['source_event_id']],process_evidence=[x for x in process if x['match_id'] in relevant_ids],market_movement=analyze(dict(f,cutoff_at=now())),sources={'fixture':f['phase_evidence'],'process':str(R/'verified-process.json'),'source_audit':str(R/'source-audit.json'),'availability':str(R/'web-context/red-card-eligibility-check.json'),'market':str(R/'market-current/source-metadata.json')},xg_status='NO_VERIFIED_RECENT_SAME_PROVIDER_XG',lineups_status='NO_CURRENT_CONFIRMED_XI_RETURNED',club_and_friendly_workload='NOT_VERIFIED_COMPLETELY',source_identity=source_identity)
 comp=save(payload,dict(f,cutoff_at=now()),stage='prematch',track='comprehensive',root=F)
 rec=verify(read(comp['path']));assert rec['selection_audit']['top3_ready']==(payload['primary'] is not None)
 records.append({'fixture':f,'payload':payload,'active_receipt':active,'candidate_receipt':cr,'comprehensive_receipt':comp})
byid={x['fixture']['source_event_id']:x for x in records}
topids=['401861183','401861182','401861187']
reasons=['优先精确比分路径：爱沙尼亚近期1-0、0-0、1-0与低失球过程相符，选择1-0；自身创造有限，0-0是最大反证。','冰岛对该对手的首回合和近期过程均占优，选2-0；卢森堡曾有7次射正，3-0/2-1及小2.75半输风险保留。','北马其顿最近3场合计2次射正，斯洛文尼亚仍需守第二，选0-1；客队客场丢球与自身创造有限使1-1仍有风险。']
topitems=[]
for rank,(eid,reason) in enumerate(zip(topids,reasons),1):
 x=byid[eid];p=x['payload'];topitems.append({'rank':rank,'match_id':x['fixture']['match_id'],**{k:p[k] for k in ['primary','wdl','total_line','total_direction']},'comprehensive_reference':x['comprehensive_receipt'],'reason':reason,'risk':p['counter'],'kickoff_at':x['fixture']['kickoff_at']})
shell={'match_id':'nations-analysis-batch:20261116-evening','cohort':'uefa.nations','kickoff_at':min(f['kickoff_at'] for f in fs),'cutoff_at':now()}
top=save({'selection_scope':'candidate_research','population':[f['match_id'] for f in fs],'top3':topitems,'ranking_basis':'唯一精确比分的比赛路径、近期过程与反证；不是市场热门或矩阵最大概率排名，也不是已校准的命中率。','formal_kpi_eligible':False,'active_model_promotion':False},shell,stage='prematch',track='top3-selection',root=F)
lines=['# 欧国联赛前分析｜2026年11月16日晚至17日凌晨','','HELLO BOSS','','本批10场均为2026-27欧国联成年男子联赛阶段，全部尚未开赛；A/B/C/D分别2/2/4/2场。北京时间11月16日23:00两场、17日01:00三场、03:45五场；只分析这轮比赛，不把今天凌晨已经结束的比赛当赛前。90分钟含补时口径。','',
'**本版研究TOP3：爱沙尼亚1-0保加利亚、冰岛2-0卢森堡、北马其顿0-1斯洛文尼亚。** 立陶宛、哈萨克斯坦和塞尔维亚涉及上一场红牌后的资格/替代阵容缺口，相关三场唯一比分待定；胜平负和大小球独立判断。','',
'## 本轮边界与证据','',
'欧国联目前没有通过验收的活动Current/Test路由，实际调用10场均明确拒绝并冻结；下表Current/Test是可加载、未晋级的独立研究候选。Current只拟合分级均值及主场项；Test增加球队攻防。刷新候选和新算法也保持独立且未晋级。综合推荐是人工证据研究，不是模型概率重新校准或已证实命中率提升。','',
'旧候选训练截至10月4日（D）或6日（A/B/C）；20队中18队最新一战尚未进入旧训练。固定配方刷新及独立候选已训练至11月13日（D）、14日（B）、15日（A/C），但均尚未通过未来验收。新旧模型使用相同身份和真实盘口分别加载，原参数/工件/登记表不改。','',
'新查ESPN赛程与10场summary，身份、开球、等级/阶段、非中立场均核对；6组积分与本届20队成绩独立对算。核验42份历史原文，覆盖每队最近3场欧国联与首回合。31次新ESPN请求中有20次历史重取，均记录在账本；不将重取当新增独立样本。近期过程没有可核验xG，射门/射正不是xG。本场首发和完整伤停均未确认；官方网页与Transfermarkt尝试也未补齐。缺项没有转为0或健康证明。','',
'本轮实盘来自The Odds API，10场覆盖、287组合法报价（168组胜平负、119组总球）；下列10场均选Pinnacle，来源报价北京时间20:04:40、抓取20:04:41。历史对照来自17:14:51的同机构同线报价，两时点不是完整水位历史，也不是资金流或内幕。','',
'瑞士13分、斯洛伐克11分、马耳他7分已无法被追上第一；轮换只作风险情景，未认定已经发生。立陶宛4分、剩一场，已无法追上完赛8分的阿塞拜疆，不能写成争直接第一。完整俱乐部/友谊赛负荷未核实，两个欧国联日期之间不等于实际休息时间。','',
'## 全部比赛','',
'|北京时间|对阵|Current候选|Test候选|综合唯一比分|胜平负倾向|实际大小球倾向|','|---|---|---|---|---|---|---|']
for x in records:
 f,p=x['fixture'],x['payload'];c=p['candidate_outputs'];ou=f"{p['total_direction']} {p['total_line']:g}" if p['total_direction'] in ['大','小'] else f"观望（{p['total_line']:g}）"
 lines.append(f"|{bt(f['kickoff_at'])[:11]}|{p['name']}|{c['current']['primary']}|{c['test']['primary']}|**{display(p['primary'])}**|{p['wdl']}|{ou}|")
lines+=['','法罗群岛和德国的1-1是唯一精确比分判断，主胜是独立胜平负倾向：所有主胜比分的合计与单个比分不是同一概率。二者分别冻结、分别结算，不把1-1算作主胜命中。','',
'本版7场有唯一比分、3场待定；胜平负10场；大小球7场偏小、3场观望。没有为了分散方向而强选大球，也不能用这一分布证明小球更准。实际半赢/走盘单列，不算普通全赢。','',
'## 预先冻结的研究TOP3','',
'|排名|对阵与北京时间|唯一比分|胜平负|实际大小球|入选理由与主要风险|','|---|---|---|---|---|---|']
for rank,(eid,reason) in enumerate(zip(topids,reasons),1):
 x=byid[eid];p=x['payload'];lines.append(f"|{rank}|{p['name']} / {bt(x['fixture']['kickoff_at'])[:11]}|{p['primary']}|{p['wdl']}|{p['total_direction']} {p['total_line']:g}|{reason}|")
lines+=['','TOP3是三场比赛各一个第一比分；完整10场分母保留。小2.25遇2球半赢、3球全输；小2.75遇3球半输，不能把2-0预测理解为小球确定赢。第一比分、胜平负、大小球的推荐强度不相同：北马其顿场的客胜方向强于小球方向。','',
'## 单场分析与模型进球分布','']
diags={x['match_id']:x for x in read(R/'candidate-diagnostics.json')}
for x in records:
 f,p=x['fixture'],x['payload'];d=diags[f['match_id']];q=p['actual_quote'];form=p['current_edition_form']
 lines+=['### '+p['name'],'',f"北京时间{bt(f['kickoff_at'])[:11]}，{f['league_level']}级联赛阶段；唯一比分 **{display(p['primary'])}**，胜平负 **{p['wdl']}**，实际总球 **{p['total_direction']} {q['line']:g}**。",'',
 '|独立轨道|统计比分|主均值 / 80%区间|主0球 / ≥2 / ≥3|客均值 / 80%区间|客0球 / ≥2 / ≥3|主胜 / 平 / 客胜|训练截止|','|---|---|---|---|---|---|---|---|']
 for role,label in [('current','旧Current候选'),('test','旧Test候选'),('fixed_current','固定配方Current刷新'),('fixed_test','固定配方Test刷新'),('challenger','新算法未晋级候选')]:
  t=d['tracks'][role];g=t['team_goal_analysis'];cells=[]
  for side in ['home','away']:
   a=g[side];ci=a['central_interval'];cells.extend([f"{a['mean']:.2f} / {ci['lower']}–{ci['upper']}",' / '.join(pct(a[k]) for k in ['p0','p_ge_2','p_ge_3'])])
  lines.append('|'+label+'|'+t['primary']+'|'+'|'.join(cells)+'|'+' / '.join(pct(t['wdl'][k]) for k in ['主胜','平局','客胜'])+'|'+t['training_data_cutoff']+'|')
 lines+=['','均值、区间和概率均来自各轨道原矩阵，不是实测xG或综合人工概率；区间是模型内中央80%，不是已验证覆盖率。新算法候选的统计选分规则与联合众数可能不同，不能挑赛后较好的轨道。','',
 '本届窗口：'+'；'.join(f"{z['team']} {z['overall']['n']}场{z['overall']['W']}胜{z['overall']['D']}平{z['overall']['L']}负，进{z['overall']['GF']}失{z['overall']['GA']}" for z in form)+'。','',
 '**双方近期过程（各最近3场欧国联；射正按本队—对手）：**']
 for w in windows:
  if w['fixture_id']!=f['source_event_id']:continue
  text=[]
  for g in w['games']:
   t,o=g['team'],g['opponent'];text.append(f"{g['date']} {t['goals']}-{o['goals']} {o['name']}，射正{int(t['stats']['shotsOnTarget'])}-{int(o['stats']['shotsOnTarget'])}")
  lines.append('- '+w['games'][-1]['team']['name']+'：'+'；'.join(text)+'。')
 lines+=['','**综合路径：**'+p['reason'],'','**主要反证：**'+p['counter'],'',
 '比较候选：'+'、'.join(p['compared_scores'])+'。其他候选仅用于反证，不补算第一比分命中。','三球以上路径：'+p['three_plus_path']]
 for side,z in p['zero_vs_one'].items():lines+=['',f"零球与一球比较（{'主队' if side=='home' else '客队'}）："+z['reason']+' 反证：'+z['counterevidence']]
 lines+=['','**胜平负独立依据：**'+p['wdl_reason']+' 反证：'+p['wdl_counter'],'','**实际大小球独立依据：**'+p['total_reason'],'',f"Pinnacle真实盘线{q['line']:g}：大{q['over_odds']} / 小{q['under_odds']}；来源报价{bt(q['quoted_at'])}，抓取{bt(q['query_time'])}。"]
 last=sorted([s for s in f['market_snapshots'] if s['market']=='1x2'],key=lambda s:s['quoted_at'])[-1]['decimal_odds'];den=sum(1/v for v in last.values())
 lines+=['',f"同机构胜平负：主{last['home']} / 平{last['draw']} / 客{last['away']}；简单去水仅作价格参考："+' / '.join(pct((1/last[k])/den) for k in ['home','draw','away'])+'。']
 if p['total_direction'] in ['大','小']:
  side='over' if p['total_direction']=='大' else 'under'
  lines+=['','所选真实盘线的独立模型结算概率：','', '|轨道|全赢|半赢|走盘|半输|全输|','|---|---|---|---|---|---|']
  for role,label in [('test','旧Test'),('fixed_test','固定配方Test刷新')]:
   v=d['tracks'][role]['total'][side];lines.append('|'+label+'|'+'|'.join(pct(v[k]) for k in ['win','half_win','push','half_loss','loss'])+'|')
 for c in p['market_movement']['comparisons']:
  keys=['home','draw','away'] if c['market']=='1x2' else ['over','under'];label='胜平负（主/平/客）' if c['market']=='1x2' else f"总球{c['line']:g}（大/小）"
  fmt=lambda odds:' / '.join(str(odds[k]) for k in keys)
  lines+=['',f"同机构同市场同线对照：{label}，{bt(c['first_quoted_at'])} {fmt(c['first_decimal_odds'])} → {bt(c['last_quoted_at'])} {fmt(c['last_decimal_odds'])}。"]
 lines+=['','**人员及缺项：**'+p['availability'],'','近期同源xG未取得；完整俱乐部/友谊赛负荷未核实。当前过程仅用于定性判断，没有改变模型参数。',f"当前赛事来源：[ESPN比赛资料]({f['phase_evidence']['source_url']})；历史原文、时间与SHA见verified-process.json。",f"综合冻结 `{x['comprehensive_receipt']['freeze_id']}`，北京时间{bt(x['comprehensive_receipt']['recorded_at'])}；旧双候选冻结 `{x['candidate_receipt']['freeze_id']}`。",'']
lines+=['## 版本、冻结与评价','',
'执行分析和刷新候选的源码：`'+source_identity['analysis_and_repair_code']+'`；旧候选在其绑定原路径执行，源码：`'+source_identity['original_pair_execution_code']+'`，历史核心SHA：`'+source_identity['original_model_engine_sha256']+'`。保留真实执行身份，不修改工件哈希适配路径。','',
'综合采用WCPP-COMPREHENSIVE-REPAIR-1：比分、胜平负与实际大小球各自记录依据和反证。红牌原文只能确认上一场事件，不能单凭它宣布当前已停赛、已获豁免或已确认首发。网页摘要无日期的天气/里程碑消息未进入判断。','',
'原18场五轨首版研究冻结及所有历史推荐保持。此次相同比赛的新节点另行保存，不能增加独立比赛分母或替代首次业绩。新候选更新链接原始研究冻结，未晋级。未开赛样本均待结算；无未来命中率或收益结论。','',
'本版7个唯一比分、10个胜平负方向、7个大小球方向分别结算；3个比分待定、3个大小球观望保留在完整10场覆盖分母。TOP3单列，不能替代全批结果。模型统计比分和综合Primary也不能互换。','',
'原注册表SHA仍为`'+registry_before+'`。报告完整计算、证据索引、盘口记录、冻结链和CSV随本版归档；归档完成后提供仓库链接。','']
report='\n'.join(lines)
report_receipt=save({'report_markdown':report,'comprehensive_receipts':[x['comprehensive_receipt'] for x in records],'top3_receipt':top,'source_identity':source_identity,'formal_kpi_eligible':False,'old_first_freezes_preserved':True},dict(shell,cutoff_at=now()),stage='prematch',track='analysis-report',root=F)
(R/'欧国联赛前分析.md').write_text(report+'\n报告冻结 `'+report_receipt['freeze_id']+'`，北京时间'+bt(report_receipt['recorded_at'])+'。\n')
write(R/'analysis-records.json',records)
receipts=[x[k] for x in records for k in ['active_receipt','candidate_receipt','comprehensive_receipt']]+[x['receipt'] for x in updates.values()]+[top,report_receipt,read(R/'candidate-update/plan-receipt.json')]
for rr in receipts:
 rec=verify(read(rr['path']));assert rec['record_sha256']==rr['sha256']
 if rec['stage']=='prematch':assert datetime.fromisoformat(rec['recorded_at'])<datetime.fromisoformat(rec['fixture']['kickoff_at'].replace('Z','+00:00'))
assert sha(registry)==registry_before
write(R/'delivery.json',{'report_receipt':report_receipt,'top3_receipt':top,'all_receipts':receipts,'population':10,'comprehensive_scores':7,'score_abstentions':3,'wdl_selections':10,'total_selections':7,'total_abstentions':3,'total_qualified_quotes':10,'top3_count':3,'source_identity':source_identity,'active_registry_sha256':registry_before,'active_registry_changed':False,'all_receipts_verified':True,'all_before_kickoff':True,'source_checks':audit})
with (R/'比赛分析展示.csv').open('x',encoding='utf-8-sig',newline='') as h:
 w=csv.writer(h);w.writerow(['北京时间','比赛','旧Current候选','旧Test候选','综合唯一比分','胜平负','大小球','真实线','机构','大赔率','小赔率','报价时间','综合冻结'])
 for x in records:
  f,p=x['fixture'],x['payload'];q=p['actual_quote'];w.writerow([bt(f['kickoff_at']),p['name'],p['candidate_outputs']['current']['primary'],p['candidate_outputs']['test']['primary'],display(p['primary']),p['wdl'],p['total_direction'],q['line'],q['bookmaker'],q['over_odds'],q['under_odds'],bt(q['quoted_at']),x['comprehensive_receipt']['freeze_id']])
print(json.dumps({'report_receipt':report_receipt,'top3_receipt':top,'verified_freezes':len(receipts),'score_selections':7,'wdl_selections':10,'total_selections':7},ensure_ascii=False))
