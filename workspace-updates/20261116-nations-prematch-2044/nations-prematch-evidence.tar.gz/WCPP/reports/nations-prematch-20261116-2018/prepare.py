"""Read-only evidence validation and append-only real prematch candidate snapshots."""
import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
from datetime import datetime,timezone
import numpy as np
CODE=Path('/workspace/Football-Analysis-nations-repair-20261116')
sys.path.insert(0,str(CODE/'runtime'))
from automation.market_bridge import attach_total_quote
from research.market_movement import analyze
from research.analysis_freeze import save,verify
from research.team_goal_analysis import summarize_prediction
from research.score_distribution_audit import audit_prediction
from research_program.future_validation import quote_audit
from nations_league import safe_cli,repair
from v2.model import total_settlement
R=Path(__file__).resolve().parent;F=Path('/workspace/WCPP/forecasts/issued-analyses')
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):
 with Path(p).open('x') as h:json.dump(x,h,ensure_ascii=False,indent=2,allow_nan=False)
def now():return datetime.now(timezone.utc).isoformat()
original=verify(read('/workspace/kaka597000-Football-Analysis-Data/future/nations-repair-bundle/plan.json'))
fs=[f for f in original['payload']['fixtures_identity'] if f['date']=='2026-11-16']
assert len(fs)==10
board=read(R/'data/raw/scoreboard-20261116.raw.json');bm=read(R/'data/meta/scoreboard-20261116.meta.json')
assert bm['http_status']==200 and sha(R/'data/raw/scoreboard-20261116.raw.json')==bm['response_sha256']
assert {e['id'] for e in board['events']}=={f['source_event_id'] for f in fs}
market_sources=[('/workspace/kaka597000-Football-Analysis-Data/api-probes/43863271589-1/the-odds-api','market-current'),('/workspace/WCPP/research/nations-repair-20261116/market-revalidated','market-earlier')]
for source,name in market_sources:shutil.copytree(source,R/name)
prepared=[];market_audits=[];forms=[]
current_channel=read(R/'market-current/market-channel.json')
for original_fixture in fs:
 f={k:v for k,v in original_fixture.items() if k not in ('total_quote','market_attachment','market_snapshots')}
 f['cutoff_at']=now();p=R/'data/raw'/('summary-'+f['source_event_id']+'.raw.json');m=read(R/'data/meta'/('summary-'+f['source_event_id']+'.meta.json'))
 assert m['http_status']==200 and sha(p)==m['response_sha256']
 f['phase_evidence']={'source_path':str(p),'source_url':m['request_url'],'source_sha256':m['response_sha256'],'query_time':m['captured_at_utc']}
 raw=read(p);c=raw['header']['competitions'][0]
 assert c['status']['type']['state']=='pre' and c['status']['type']['completed'] is False
 safe_cli.validate_future(f)
 f,ma=attach_total_quote(f,R/'market-current',provider_order=('the-odds-api',),bookmaker_order=('pinnacle',),now=datetime.now(timezone.utc))
 assert ma['status']=='ATTACHED' and quote_audit(f)['eligible']
 market_audits.append({'match_id':f['match_id'],'audit':ma})
 book=f['total_quote']['bookmaker'];f['market_snapshots']=[]
 for _,name in market_sources:
  channel=read(R/name/'market-channel.json')
  for snap in channel['snapshots']:
   if snap['target']['match_id']!=f['match_id']:continue
   assert snap['target']['home_id']==f['home'] and snap['target']['away_id']==f['away']
   for row in snap['observations']:
    v=row['value'];e=row['evidence']
    if v['bookmaker']!=book or v['market'] not in ('h2h','totals'):continue
    assert sha(R/name/e['file'])==e['sha256']
    f['market_snapshots'].append({'match_id':f['match_id'],'bookmaker':book,'market':'1x2' if v['market']=='h2h' else 'totals','line':v.get('line'),'decimal_odds':v['odds'],'quoted_at':v['quoted_at'],'query_time':row['observed_at'],'source_url':e['url'],'source_sha256':e['sha256']})
 f['market_movement']=analyze(f)
 for t in raw['lastFiveGames']:
  tid=str(t['team']['id']);games=[]
  for e in t['events']:
   if e.get('competitionName')!='2026-27 UEFA Nations League' or e.get('roundName')!='League Phase':continue
   assert datetime.fromisoformat(e['gameDate'].replace('Z','+00:00'))<datetime.now(timezone.utc)
   home=str(e['homeTeamId'])==tid;assert home or str(e['awayTeamId'])==tid
   gf,ga=map(int,(e['homeTeamScore'],e['awayTeamScore']) if home else (e['awayTeamScore'],e['homeTeamScore']))
   games.append({'event_id':str(e['id']),'date':e['gameDate'],'home':home,'gf':gf,'ga':ga,'opponent':e['opponent']['displayName'],'opponent_id':str(e['opponent']['id'])})
  assert games and len(games)==len({x['event_id'] for x in games})
  old_index=read('/workspace/nations-model-20261110/models/candidates.json');art=read(old_index['routes'][f['league_level']]['test']['path']);train=read(art['dataset_path'])['rows'];train_ids={x['match_id'] for x in train}
  for game in games:game['included_in_old_training']='espn:'+game['event_id'] in train_ids
  def stats(gs):return {'n':len(gs),'W':sum(g['gf']>g['ga'] for g in gs),'D':sum(g['gf']==g['ga'] for g in gs),'L':sum(g['gf']<g['ga'] for g in gs),'GF':sum(g['gf'] for g in gs),'GA':sum(g['ga'] for g in gs)}
  forms.append({'fixture_id':f['source_event_id'],'team':t['team']['displayName'],'team_id':tid,'games':games,'overall':stats(games),'home':stats([x for x in games if x['home']]),'away':stats([x for x in games if not x['home']]),'old_training_omitted_games':[x['event_id'] for x in games if not x['included_in_old_training']],'source':f['phase_evidence']})
 prepared.append(f)
write(R/'prepared-fixtures.json',prepared);write(R/'verified-form.json',forms);write(R/'market-attachment-audit.json',market_audits)
# The original bound engine is executed at its retained path, with its hash checks intact.
env=os.environ.copy();env['PYTHONPATH']='/workspace/Football-Analysis/runtime';env['OPENBLAS_NUM_THREADS']='1'
subprocess.run(['/workspace/football-venv/bin/python','-m','nations_league.safe_cli','freeze-pairs','--index','/workspace/nations-model-20261110/models/candidates.json','--fixtures',str(R/'prepared-fixtures.json'),'--out',str(R/'candidate-update'),'--freeze-root',str(F)],cwd='/workspace/Football-Analysis',env=env,check=True)
index=read('/workspace/WCPP/research/nations-repair-20261116/experiment-v4/candidates.json');diagnostics=[];updates=[]
for f,cr in zip(prepared,read(R/'candidate-update/receipts.json')):
 pair=verify(read(cr['path']))['payload'];current={}
 for role in ('fixed_current','fixed_test','challenger'):
  ref=index['routes'][f['league_level']][role];assert sha(ref['path'])==ref['sha256']
  current[role]=repair.predict(ref['path'],dict(f,cutoff_at=now()))
 reference=Path('/workspace/WCPP/research/nations-repair-20261116/forward-v2/freezes')/(f['match_id'].replace(':','-')+'.json')
 original_comparison=verify(read(reference))
 receipt=save({'predictions':current,'original_comparison_reference':{'path':str(reference),'sha256':original_comparison['record_sha256']},'comparison_scope':'UPDATED_PREMATCH_RESEARCH_REFERENCE_NOT_NEW_FIRST_FREEZE_COHORT','formal_kpi_eligible':False,'active_model_promotion':False},dict(f,cutoff_at=now()),stage='prematch',track='nations-repair-reference-update',root=F)
 updates.append({'match_id':f['match_id'],'receipt':receipt,'predictions':current})
 tracks={**{role:pair[role] for role in ('current','test')},**current};d={}
 for role,p in tracks.items():
  d[role]={'primary':p['primary'],'expected_goals':p['expected_goals'],'wdl':p['wdl'],'training_data_cutoff':p['training_data_cutoff'],'primary_probability':p['primary_probability'],'team_goal_analysis':summarize_prediction(p),'distribution_audit':audit_prediction(p),'total':{side:total_settlement(np.asarray(p['matrix']),f['total_quote']['line'],side) for side in ('over','under')}}
 diagnostics.append({'match_id':f['match_id'],'home':f['home_name'],'away':f['away_name'],'actual_quote':f['total_quote'],'market_snapshots':f['market_snapshots'],'market_movement':f['market_movement'],'candidate_reference':cr,'repair_reference':receipt,'tracks':d})
write(R/'repair-updates.json',updates);write(R/'candidate-diagnostics.json',diagnostics)
print(json.dumps({'fixtures':len(prepared),'forms':len(forms),'candidate_pairs':len(diagnostics),'repair_reference_snapshots':len(updates),'market_coverage':len(market_audits)}))
