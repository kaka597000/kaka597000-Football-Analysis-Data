# Public web context — Nations League (16–17 Nov 2026)

Collected 2026-11-16 12:24 UTC (20:24 Beijing). This supplement did **not** verify a current national-team squad, injury, suspension, or rotation report for any listed fixture. The four requested priority fixture searches produced irrelevant Bing results; those response snapshots and SHA-256 hashes are in `search-log.json` and `search-snapshots/`. They are search-result pages only, not source articles. Search snippets are not evidence of article contents.

| Fixture (Beijing kickoff) | Latest squad / injuries / suspensions / rotation | Recent three-match xG/xGA |
|---|---|---|
| Germany–Netherlands (Nov 17 03:45) | Unknown; no verified current report captured | Unavailable |
| Switzerland–Scotland (Nov 17 03:45) | Unknown; no verified current report captured | Unavailable |
| Iceland–Luxembourg (Nov 17 01:00) | Unknown; no verified current report captured | Unavailable |
| Kazakhstan–Slovakia (Nov 16 23:00) | Unknown; no verified current report captured | Unavailable |
| Faroe Islands–Moldova (Nov 16 23:00) | Not independently established | Unavailable |
| Estonia–Bulgaria (Nov 17 01:00) | Not independently established | Unavailable |
| Lithuania–Liechtenstein (Nov 17 01:00) | Not independently established | Unavailable |
| Gibraltar–Malta (Nov 17 03:45) | Not independently established | Unavailable |
| North Macedonia–Slovenia (Nov 17 03:45) | Not independently established | Unavailable |
| Greece–Serbia (Nov 17 03:45) | Not independently established | Unavailable |

The supplied ESPN API inspection likewise lacked roster/starting-player flags, injury/suspension fields and xG. Understat/StatsBomb national-team coverage was not established; no shots-to-xG substitution was made. Unknown does not imply full availability. No historical XI was used as a lineup forecast.

Machine-readable fixture/status list: `context.json`.

## Direct official-page checks (additional review)

Eight direct page requests were made and stored in `official-checks.json` with URLs, request timestamps, HTTP states, titles, response hashes (where a body was available), and page-level findings. The Swiss FA news index is the sole captured page with clear current fixture-specific content: it carries a Switzerland–Scotland venue logistics note about wind canceling the fan village, plus another listing summary noting Monday’s match and milestones for Ricardo Rodriguez and Remo Freuler. The listing does not expose publication dates in the captured markup, and no article body was fetched; neither item identifies player absences or a lineup. Thus squad/injury status remains unknown.

DFB, Scottish FA, and KSI paths tried returned 404; the OnsOranje path returned a generic team overview, without relevant match/news terms. UEFA’s competition calendar loaded, but its captured HTML is a JS calendar shell without team-specific match/news text. Transfermarkt Germany and Netherlands squad URLs returned HTTP 202 with empty bodies. These outcomes establish access/content limits for the exact attempted URLs only; they do not establish that the organizations have no relevant news elsewhere.
