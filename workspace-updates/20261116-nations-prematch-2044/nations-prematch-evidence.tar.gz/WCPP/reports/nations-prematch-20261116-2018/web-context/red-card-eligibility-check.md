# Historical red cards and current eligibility

Checked 2026-11-16 12:37 UTC. The three saved ESPN event snapshots record the following historical red cards:

- Serbia–Germany (Nov 13): Vanja Dragojevic at 76′ and Andrija Zivkovic at 89′. Target: Greece–Serbia.
- Kazakhstan–Moldova (Nov 13): Maksim Samorodov received a second-yellow red at 90+4′. Target: Kazakhstan–Slovakia.
- Azerbaijan–Lithuania (Oct 4): Armandas Kucys was shown a red at 90+7′. Target: Lithuania–Liechtenstein.

The raw event snapshots, exact event text, event times, source metadata times, and SHA-256 values are recorded in `red-card-eligibility-check.json`. These historical events do not by themselves establish current eligibility. In six bounded requests, I could not capture the relevant UEFA automatic-suspension rule text from an accessible official page: UEFA’s regulations URL returned a JavaScript shell; a disciplinary-hub URL returned 404; the official disciplinary-bodies overview did not show the applicable rule in captured text. Search results did not provide usable authoritative evidence. Therefore all four players’ current suspension/eligibility status remains unknown. No claim is made that any ban is pending, served, lifted, appealed, or that a player is in the current squad.
