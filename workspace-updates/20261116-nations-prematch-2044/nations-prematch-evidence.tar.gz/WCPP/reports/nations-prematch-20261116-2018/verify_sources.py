"""Independent checks on actual captured and retained evidence. No network calls."""
import hashlib,json
from pathlib import Path
R=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
ledger=read(R/'data/collection-manifest.json');checks=[]
for m in ledger['requests']:
 path=R/'data/raw'/m['name'].replace('.meta.json','.raw.json')
 assert m['http_status']==200 and sha(path)==m['response_sha256']
 checks.append({'path':str(path),'sha256':m['response_sha256'],'query_time':m['captured_at_utc']})
fs=read(R/'prepared-fixtures.json');luna={f['match_id']:f for f in read(R/'data/verified-fixtures.json')['fixtures']}
for f in fs:
 p=luna[f['source_event_id']]
 assert p['league_level']==f['league_level'] and p['stage']==f['stage']
 assert p['teams']['home']['team_id']==f['home'] and p['teams']['away']['team_id']==f['away']
 assert p['neutral_site']==f['neutral'] and p['kickoff_at_utc']==f['kickoff_at']
history=read(R/'verified-process.json');hist_by_id={h['event_id']:h for h in history};comparisons=[]
for fresh in (R/'data/raw').glob('history-*.raw.json'):
 j=read(fresh);eid=str(j['header']['id'])
 if eid not in hist_by_id:continue
 old=hist_by_id[eid];c=j['header']['competitions'][0]
 for t in c['competitors']:
  tid='espn:'+str(t['team']['id']);assert int(t['score'])==old['teams'][tid]['goals']
 for t in j['boxscore']['teams']:
  tid='espn:'+str(t['team']['id']);stats={x['name']:x.get('value',x.get('displayValue')) for x in t['statistics']}
  for k in ['totalShots','shotsOnTarget','redCards']:
   assert float(stats[k])==old['teams'][tid]['stats'][k],(eid,tid,k)
 comparisons.append(eid)
for h in history:
 assert sha(h['source_path'])==h['source_sha256']
checks.extend({'path':h['source_path'],'sha256':h['source_sha256'],'query_time':h['source_query_time']} for h in history)
forms=read(R/'verified-form.json');groups=read(R/'data/standings.json')['groups']
standing_rows={e['team_id']:e for g in groups for e in g['entries']}
for t in forms:
 e=standing_rows['espn:'+t['team_id']];o=t['overall'];assert int(e['points'])==3*o['W']+o['D']
 assert int(e['played'])==o['n'] and int(e['goal_difference'])==o['GF']-o['GA']
report={'schema':'WCPP-PREMATCH-SOURCE-VERIFICATION-1','status':'PASS','fresh_espan_requests':len(ledger['requests']),'history_unique_verified':len(history),'latest_three_team_windows':20,'source_checks':checks,'fresh_vs_retained_process_comparisons':comparisons,'current_fixture_identities_checked':10,'standings_compared_with_own_form_rows':20,'old_training_missing_latest_team_matches':sum(bool(t['old_training_omitted_games']) for t in forms),'xg_records_observed':sum(bool(t['xg_available']) for h in history for t in h['teams'].values()),'fresh_history_requests_are_not_new_independent_samples':True,'sources_collected_by':'gpt-6-luna','source_validation_by':'root','numerical_models_retrained':False,'red_card_eligibility':'Unresolved; retrospective red events do not by themselves certify current eligibility.'}
with (R/'source-audit.json').open('x') as h:json.dump(report,h,ensure_ascii=False,indent=2)
print({k:v for k,v in report.items() if k not in ['source_checks','fresh_vs_retained_process_comparisons']})
