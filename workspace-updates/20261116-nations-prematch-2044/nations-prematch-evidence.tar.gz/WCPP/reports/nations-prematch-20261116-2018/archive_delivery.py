"""Archive issued evidence and complete freeze chains; never replace existing backups."""
from pathlib import Path
import hashlib,json,os,shutil,sys,tarfile
from datetime import datetime,timezone
sys.path.insert(0,'/workspace/Football-Analysis-nations-repair-20261116/runtime')
from research.analysis_freeze import verify
R=Path(__file__).resolve().parent;W=Path('/workspace/WCPP').resolve();D=Path('/workspace/kaka597000-Football-Analysis-Data/workspace-updates/20261116-nations-prematch-2044')
D.mkdir(parents=True,exist_ok=False)
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
delivery=read(R/'delivery.json');files={}
def add(p):
 p=Path(p).resolve();assert p.is_file() and p.is_relative_to(W)
 files['WCPP/'+str(p.relative_to(W))]=p
for p in R.rglob('*'):
 if p.is_file() and '__pycache__' not in p.parts:add(p)
chain_count=0
for receipt in delivery['all_receipts']:
 path=Path(receipt['path']);prior=None
 for p in sorted(path.parent.glob('[0-9]*.json')):
  if p.name>path.name:continue
  record=verify(read(p));assert record['previous_sha256']==prior;prior=record['record_sha256'];add(p);chain_count+=1
 for key in ['original_comparison_reference']:
  ref=read(path).get('payload',{}).get(key)
  if ref:
   record=verify(read(ref['path']));assert record['record_sha256']==ref['sha256'];add(ref['path'])
for f in read(R/'prepared-fixtures.json'):
 ref=f.get('supplemental_phase_evidence')
 if ref:assert sha(ref['source_path'])==ref['source_sha256'];add(ref['source_path'])
# Verify unchanged old and new artifacts against the immutable indexes.
for index_path in ['/workspace/nations-model-20261110/models/candidates.json','/workspace/WCPP/research/nations-repair-20261116/experiment-v4/candidates.json']:
 index=read(index_path)
 for route in index['routes'].values():
  for ref in route.values():assert sha(ref['path'])==ref['sha256']
secrets=[v.encode() for k,v in os.environ.items() if len(v)>=12 and any(s in k.upper() for s in ['SECRET','TOKEN','API_KEY','APIKEY'])]
for path in files.values():
 data=path.read_bytes()
 if any(secret in data for secret in secrets):raise ValueError('environment credential value detected; file omitted')
archive=D/'nations-prematch-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for name,p in sorted(files.items()):tar.add(p,arcname=name,recursive=False)
manifest={'schema':'WCPP-NATIONS-PREMATCH-DELIVERY-1','created_at':datetime.now(timezone.utc).isoformat(),'source_identity':delivery['source_identity'],'report_freeze':delivery['report_receipt'],'top3_freeze':delivery['top3_receipt'],'population':10,'scores':7,'wdl':10,'totals':7,'score_abstentions':3,'total_abstentions':3,'model_promotion':False,'registry_sha256':delivery['active_registry_sha256'],'restore_assets_from':'workspace-updates/20261116-nations-repair/ (existing durable model and runtime archive)','original_api_probe_evidence':'api-probes/43863271589-1/','archive':{'file':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive)},'files':[{'path':n,'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in sorted(files.items())]}
with tarfile.open(archive,'r:gz') as tar:
 entries={m.name:m for m in tar.getmembers()}
 assert set(entries)==set(files)
 for item in manifest['files']:
  member=entries[item['path']];assert member.isfile() and '..' not in Path(member.name).parts and not Path(member.name).is_absolute()
  body=tar.extractfile(member).read();assert len(body)==item['bytes'] and hashlib.sha256(body).hexdigest()==item['sha256']
(D/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
for name in ['欧国联赛前分析.md','比赛分析展示.csv','delivery.json','source-audit.json']:shutil.copyfile(R/name,D/name)
(D/'README.md').write_text('''# 2026-11-16 今晚至明晨欧国联赛前交付

[完整分析报告](欧国联赛前分析.md) · [表格副本](比赛分析展示.csv) · [冻结与校验回执](delivery.json) · [哈希及恢复清单](manifest.json)

北京时间20:43冻结，10场全部保持赛前。唯一比分7场，3场人员资格缺口待定；胜平负10场，实际大小球7场、3场观望。研究TOP3：爱沙尼亚1-0、冰岛2-0、北马其顿0-1。原始报价时间20:04:40，不能当作现在仍未变化的价格。

压缩包含本轮API原文、历史过程核验、网站缺项证据、同机构两时点盘口、逐模型原矩阵、逐场综合分析、TOP3与报告，以及所用冻结的完整前序链。逐文件SHA256已经从实际压缩包重新读回核验。活动模型未晋级，旧首版与18场研究队列保持。

恢复：先按仓库NEW-ENVIRONMENT.md及workspace-updates/20261116-nations-repair/恢复既有资产，再核验本manifest中的压缩包哈希；按WCPP/相对路径恢复本增量。已存在同名文件须先比较SHA，不覆盖不同内容。模型重新运行仍需保留原工件绑定路径与源码身份。本轮冻结和原始矩阵可直接用于复盘，不需要回填或重算赛前预测。
''')
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'files':len(files),'freeze_chain_records_examined':chain_count,'report_freeze':delivery['report_receipt']['freeze_id']},ensure_ascii=False))
