"""Verify retained historical sources for current form; no provider requests."""
from pathlib import Path
import json,hashlib,shutil
from datetime import datetime,timezone
R=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):
 with Path(p).open('x') as h:json.dump(x,h,ensure_ascii=False,indent=2,allow_nan=False)
fs=read(R/'prepared-fixtures.json');datasets={g:read(Path('/workspace/WCPP/research/nations-repair-20261116/experiment-v4')/g/'dataset.json')['rows'] for g in 'ABCD'}
needed={};windows=[];team_ids=set()
for f in fs:
 rows=[r for r in datasets[f['league_level']] if r['date']>='2026-01-01']
 for side in ['home','away']:
  tid=f[side];team_ids.add(tid);recent=sorted([r for r in rows if tid in (r['home'],r['away'])],key=lambda r:r['kickoff_at'])[-3:]
  for row in recent:needed[row['match_id']]=row
  windows.append({'fixture_id':f['source_event_id'],'team_id':tid,'side':side,'event_ids':[r['match_id'] for r in recent]})
 first=[r for r in rows if {r['home'],r['away']}=={f['home'],f['away']}]
 assert len(first)==1
 needed[first[0]['match_id']]=first[0]
 windows.append({'fixture_id':f['source_event_id'],'side':'first_leg','event_ids':[first[0]['match_id']]})
(R/'verified-history-raw').mkdir(exist_ok=False)
records=[]
for mid,row in sorted(needed.items()):
 p=Path(row['raw_path']);assert sha(p)==row['raw_sha256'];raw=read(p);c=raw['header']['competitions'][0]
 assert str(raw['header']['id'])==row['source_event_id'] and str(c['id'])==row['source_event_id']
 assert c['status']['type']['completed'] is True and c['status']['type']['name']=='STATUS_FULL_TIME'
 sides={x['homeAway']:'espn:'+str(x['team']['id']) for x in c['competitors']};assert sides=={'home':row['home'],'away':row['away']}
 assert datetime.fromisoformat(c['date'].replace('Z','+00:00'))==datetime.fromisoformat(row['kickoff_at'])
 assert datetime.fromisoformat(row['observed_at'])<datetime.now(timezone.utc)
 dest=R/'verified-history-raw'/(row['source_event_id']+'.json');shutil.copyfile(p,dest)
 teams={}
 for team in raw.get('boxscore',{}).get('teams',[]):
  tid='espn:'+str(team['team']['id']);assert tid in sides.values()
  stats={s['name']:s.get('value',s.get('displayValue')) for s in team.get('statistics',[])}
  keys=['totalShots','shotsOnTarget','redCards','yellowCards','possessionPct','wonCorners']
  selected={k:float(stats[k]) if k in stats else None for k in keys}
  xg={k:v for k,v in stats.items() if 'expectedgoal' in k.lower().replace('_','') or k.lower() in ['xg','xga']}
  teams[tid]={'name':team['team'].get('displayName'),'home':tid==row['home'],'goals':row['home_goals'] if tid==row['home'] else row['away_goals'],'stats':selected,'xg_fields':xg,'xg_available':bool(xg)}
 events=[]
 for e in raw.get('keyEvents',[]):
  text=json.dumps(e).lower()
  if any(k in text for k in ['red card','red-card','redcard','own goal','own-goal','penalty','yellowred']):events.append(e)
 records.append({'match_id':mid,'event_id':row['source_event_id'],'date':row['date'],'kickoff_at':row['kickoff_at'],'home_id':row['home'],'away_id':row['away'],'home_goals':row['home_goals'],'away_goals':row['away_goals'],'teams':teams,'special_events':events,'source_path':str(dest),'original_source_path':str(p),'source_sha256':row['raw_sha256'],'source_url':row['source_url'],'source_query_time':row['query_time'],'later_scoreboard_reverification_at':row['observed_at'],'training_scope':'Nations league phase only; not all competitions','stats_notice':'Shots are not xG. Aggregated saves/penalty counts are not used.'})
byid={x['match_id']:x for x in records};team_windows=[]
for w in windows:
 if w['side']=='first_leg':continue
 games=[]
 for mid in w['event_ids']:
  r=byid[mid];own=r['teams'].get(w['team_id']);opp=next((x for tid,x in r['teams'].items() if tid!=w['team_id']),None)
  games.append({'match_id':mid,'date':r['date'],'team':own,'opponent':opp})
 team_windows.append(dict(w,games=games))
write(R/'verified-process.json',records);write(R/'process-windows.json',team_windows);write(R/'process-window-index.json',windows)
print('Verified',len(records),'unique historical raw summaries;',len(team_windows),'team windows. XG rows:',sum(bool(t['xg_available']) for r in records for t in r['teams'].values()))
for w in team_windows:
 vals=[]
 for g in w['games']:
  t,o=g['team'],g['opponent'];vals.append((g['date'],t['name'],t['goals'],o['goals'],t['stats']['totalShots'],o['stats']['totalShots'],t['stats']['shotsOnTarget'],o['stats']['shotsOnTarget'],t['stats']['redCards'],o['stats']['redCards']))
 print(w['fixture_id'],w['side'],vals)
