"""Verify regulation scores, chronological event ownership, and prematch market IDs."""
import json,hashlib,sys,re
from pathlib import Path
from datetime import datetime,timezone
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from research.analysis_freeze import verify,aware,digest
from research_program.nations_phase import verify_period_scores,classify_source_phase
from research_program.future_validation import quote_audit
R=Path(__file__).resolve().parent;P=Path('/workspace/WCPP/reports/scope-prematch-20261115-2146')
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(name,x):
 with (R/name).open('x') as h:json.dump(x,h,ensure_ascii=False,indent=2,allow_nan=False)
lock=read(R/'review-scope-lock.json');now=datetime.now(timezone.utc).isoformat();sm=read(R/'second-source/source-metadata.json');sp=R/'second-source'/sm['raw_file'];assert sha(sp)==sm['sha256'] and sm['http_status']==200
assert aware(lock['locked_at'])<aware(sm['request_start_utc'])<=aware(sm['response_read_complete_utc'])<=aware(now)
secondraw=read(sp);market=read(P/'market/odds.json');board={str(e['id']):e for e in read(P/'schedule/raw/uefa.nations.json')['events']}
results=[];process=[];quotes=[];cross=[];issues=[]
for item in lock['fixtures']:
 f=item['fixture'];mid=f['match_id'];eid=f['source_event_id'];mp=R/'results'/(eid+'.meta.json');meta=read(mp);src=mp.parent/meta['raw_file'];assert sha(src)==meta['sha256'] and meta['http_status']==200
 assert aware(lock['locked_at'])<aware(meta['requested_at'])<=aware(meta['read_complete_at'])<=aware(now)
 raw=read(src);header=raw['header'];c=header['competitions'][0];assert str(header['id'])==eid and header['league']['slug']==f['competition'] and len(header['competitions'])==1
 assert str(c['id'])==eid and aware(c['date'])==aware(f['kickoff_at']) and c['neutralSite']==f['neutral']
 assert c['status']['type']['completed'] and c['status']['type']['name']=='STATUS_FULL_TIME'
 phase=classify_source_phase(board[eid]);assert phase['complete'] and phase['stage']==f['stage'] and phase['league_level']==f['league_level']
 sides={t['homeAway']:t for t in c['competitors']};assert set(sides)=={'home','away'};periods={};scores={};names={};team_side={}
 for side,t in sides.items():
  assert 'espn:'+str(t['team']['id'])==f[side];v=verify_period_scores(t,c['status']);assert v and v['extra_time']==0 and v['shootout'] is None;periods[side]=v;scores[side]=v['regulation'];names[side]=t['team']['displayName'];team_side[str(t['team']['id'])]=side
 result=dict(match_id=mid,status='completed',event_status='FT',score_basis='regulation_90',home_goals=scores['home'],away_goals=scores['away'],observed_at=meta['read_complete_at'],http_request_started=meta['requested_at'],http_read_complete=meta['read_complete_at'],root_verified_at=now,source_url=meta['url'],source_sha256=meta['sha256'],source_path=str(src),metadata_path=str(mp),regulation_evidence=periods,**{k:f[k] for k in ['competition','cohort','stage','home','away','kickoff_at']});results.append(result)
 roster={}
 for t in raw.get('rosters',[]):
  tid=str(t['team']['id']);assert tid in team_side
  for p in t.get('roster',[]):
   aid=str(p['athlete']['id']);assert aid not in roster or roster[aid]==tid;roster[aid]=tid
 stats={team_side[str(t['team']['id'])]:{v['name']:v.get('displayValue') for v in t.get('statistics',[])} for t in raw.get('boxscore',{}).get('teams',[])}
 goals=[];cards=[];before=[0,0];seen=set();special=[]
 for e in raw.get('keyEvents',[]):
  assert e['id'] not in seen;seen.add(e['id']);kind=e.get('type',{}).get('type','')
  if e.get('scoringPlay'):
   assert not e.get('shootout') and e['period']['number'] in [1,2]
   # ESPN spelling varies across header and goal text only for Türkiye/Turkey.
   label=lambda s:'(?:'+ '|'.join(re.escape(n) for n in ({s,'Turkey','Türkiye'} if s in ['Turkey','Türkiye'] else {s}))+')'
   found=re.findall(label(names['home'])+r' (\d+), '+label(names['away'])+r' (\d+)',e.get('text',''));assert len(found)==1,(eid,e['id'],e.get('text'))
   after=list(map(int,found[0]));delta=[b-a for a,b in zip(before,after)];assert delta in [[1,0],[0,1]]
   side=['home','away'][delta.index(1)];tid=f[side].split(':')[-1];assert str(e['team']['id'])==tid
   aid=str(e['participants'][0]['athlete']['id']);own=kind=='own-goal';actor=('away' if side=='home' else 'home') if own else side;assert roster.get(aid)==f[actor].split(':')[-1],(eid,'actor',e['id'])
   ds=[d for d in c.get('details',[]) if d.get('scoringPlay') and d['clock']['value']==e['clock']['value'] and str(d.get('team',{}).get('id'))==tid]
   assert len(ds)==1 and ds[0]['ownGoal']==own;pen=kind=='penalty---scored';assert ds[0]['penaltyKick']==pen
   goals.append(dict(event_id=e['id'],minute=e['clock']['displayValue'],before=before,after=after,beneficiary_side=side,actor_side=actor,athlete=e['participants'][0]['athlete']['displayName'],own_goal=own,penalty_goal=pen,text=e.get('text')));before=after
  if kind in ['red-card','second-yellow-card','yellow-red-card']:cards.append(dict(minute=e['clock']['displayValue'],team_side=team_side[str(e['team']['id'])],score_at_card=before.copy(),type=kind,text=e.get('text')))
  if 'penalty' in kind or 'var' in kind:special.append(dict(type=kind,minute=e['clock']['displayValue'],text=e.get('text')))
 assert before==[scores['home'],scores['away']]
 for side in ['home','away']:
  pen=sum(g['penalty_goal'] and g['beneficiary_side']==side for g in goals)
  if stats[side].get('penaltyKickGoals') is not None and int(stats[side]['penaltyKickGoals'])!=pen:issues.append(dict(match_id=mid,type='BOX_PENALTY_CONFLICT',side=side,box=stats[side]['penaltyKickGoals'],events=pen,used='verified scoring events'))
  other='away' if side=='home' else 'home';sot=stats[side].get('shotsOnTarget');saves=stats[other].get('saves');own=sum(g['own_goal'] and g['beneficiary_side']==side for g in goals)
  if sot is not None and saves is not None and float(saves)+scores[side]-own>float(sot):issues.append(dict(match_id=mid,type='SAVES_SOT_CONFLICT',side=side,sot=sot,opponent_saves=saves,interpretation='No keeper performance conclusion from inconsistent aggregate'))
  assert sum(z['team_side']==side for z in cards)==int(stats[side]['redCards'])
 def xg_fields(x,path=''):
  found=[]
  if isinstance(x,dict):
   for k,v in x.items():
    if re.search(r'expected.?goals|^xg$|^xga$',k,re.I) or k=='name' and re.search(r'expected.?goals|^xg$|^xga$',str(v),re.I):found.append(dict(path=path+'/'+k,value=v))
    found+=xg_fields(v,path+'/'+k)
  elif isinstance(x,list):
   for n,v in enumerate(x):found+=xg_fields(v,path+'/'+str(n))
  return found
 halftime=[int(sides[s]['linescores'][0]['displayValue']) for s in ['home','away']]
 process.append(dict(match_id=mid,teams=names,half_time=halftime,half_time_source='header validated first period; does not require a separate keyEvent',stats=stats,goals=goals,red_cards=cards,special_events=special,xg_fields=xg_fields(raw),source_path=str(src),source_sha256=meta['sha256'],goal_ownership_validation='ESPN score deltas + roster membership + header ownGoal flags. FotMob-only adapter not supplied fabricated inputs.'))
 rec=verify(read(item['published_candidate_update']['path']));assert rec['record_sha256']==item['published_candidate_update']['sha256'];ff=rec['payload']['current']['input'];q=ff['total_quote'];selected=ff['market_attachment']['selected'];channel=read(selected['channel_path']);snap=next(s for s in channel['snapshots'] if s['snapshot_sha256']==selected['snapshot_sha256'])
 assert digest({k:v for k,v in snap.items() if k!='snapshot_sha256'})==snap['snapshot_sha256'];assert all(snap['target'][k]==v for k,v in [('match_id',mid),('home_id',f['home']),('away_id',f['away'])])
 obs=next(o for o in snap['observations'] if digest(o)==selected['observation_sha256']);pid=obs['provider_match_id'];event=next(e for e in market if e['id']==pid)
 assert aware(event['commence_time'])==aware(f['kickoff_at']) and q['source_sha256']==sha(P/'market/odds.json')
 book=next(b for b in event['bookmakers'] if b['key']==q['bookmaker']);total=next(t for t in book['markets'] if t['key']=='totals');out={o['name']:o for o in total['outcomes']}
 assert set(out)=={'Over','Under'} and all(o['point']==q['line'] for o in out.values()) and out['Over']['price']==q['over_odds'] and out['Under']['price']==q['under_odds'] and total['last_update']==q['quoted_at'];qa=quote_audit(ff);assert qa['eligible']
 if item['published_comprehensive']:
  cm=verify(read(item['published_comprehensive']['path']));assert cm['payload']['actual_quote']==q and quote_audit(cm['fixture'])['eligible']
 quotes.append(dict(match_id=mid,source_path=str(P/'market/odds.json'),source_sha256=sha(P/'market/odds.json'),quote=q,provider_event_id=pid,quote_audit=qa,comprehensive_selected=bool(item['published_comprehensive']),candidate_direction_present='total' in rec['payload']['current']))
 e=next(e for e in secondraw if e['id']==pid);assert e['completed'] and e['home_team']==event['home_team'] and e['away_team']==event['away_team'];sv={v['name']:int(v['score']) for v in e['scores']};assert sv[e['home_team']]==scores['home'] and sv[e['away_team']]==scores['away']
 dt=(aware(e['commence_time'])-aware(f['kickoff_at'])).total_seconds();cross.append(dict(match_id=mid,provider_event_id=pid,score_agrees=True,kickoff_difference_seconds=dt,identity_basis='Prematch frozen snapshot observation provider_match_id; no result-based joining',source_path=str(sp),source_sha256=sm['sha256']))
write('verified-results.json',results);write('verified-process.json',process);write('quote-review-audit.json',quotes);write('second-source-verification.json',cross);write('source-conflicts.json',issues)
write('source-verification.json',dict(status='PASS',verified_at=now,population=len(results),raw_score_responses_verified=len(results)+1,regulation_90_verified=len(results),goal_events_reconciled=sum(len(x['goals']) for x in process),xg_games=sum(bool(x['xg_fields']) for x in process),missing_http_timestamps=0,source_conflicts=issues,second_source=cross))
print(json.dumps(dict(results=len(results),goals=sum(len(x['goals']) for x in process),conflicts=issues,independent_scores=len(cross)),ensure_ascii=False))
