"""Settle locked forecasts by track/version; never infer missing original selections."""
import json,sys,math,hashlib
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import numpy as np
sys.path[:0]=['/workspace/Football-Analysis/runtime','/workspace/Football-Analysis/runtime/v5','/workspace/Football-Analysis/runtime/optimization']
from research.analysis_freeze import verify,digest
from research.team_goal_analysis import summarize_prediction,review as goal_review
from research_program.future_validation import check_matrix
from v5.paired_review import review
from v2.model import total_settlement
from optimization.evaluate import settle_ou
from research_program.nations_phase import verify_period_scores
R=Path(__file__).resolve().parent;F=Path('/workspace/WCPP/forecasts/issued-analyses')
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(name,x):
 with (R/name).open('x') as h:json.dump(x,h,ensure_ascii=False,indent=2,allow_nan=False)
lock=read(R/'review-scope-lock.json');results=read(R/'verified-results.json');res={x['match_id']:x for x in results};assert len(res)==8
names=['拉脱维亚—亚美尼亚','塞浦路斯—黑山','白俄罗斯—阿尔巴尼亚','芬兰—圣马力诺','西班牙—英格兰','比利时—意大利','法国—土耳其','克罗地亚—捷克']
def record(ref):
 z=verify(read(ref['path']));assert z['record_sha256']==ref['sha256'];return z
def actual(mid):
 r=res[mid];h,a=r['home_goals'],r['away_goals'];return f'{h}-{a}',('主胜' if h>a else '客胜' if h<a else '平局')
def pair(ref,candidate=True):
 z=record(ref);p=z['payload'];a,b=('current','test') if candidate else ('current_model','test_model');return dict(match_id=z['match_id'],current_model=p[a],test_model=p[b])
def settle(mid,line,direction):
 side={'大':'over','小':'under'}.get(direction)
 if side is None:return None
 r=res[mid];m=np.zeros((51,51));m[r['home_goals'],r['away_goals']]=1
 out=next(k for k,v in total_settlement(m,line,side).items() if v==1.)
 assert {'win':'FULL_WIN','half_win':'HALF_WIN','push':'PUSH','half_loss':'HALF_LOSS','loss':'FULL_LOSS'}[out]==settle_ou(r['home_goals']+r['away_goals'],line,side)
 return out
def wilson(h,n):
 if not n:return None
 z=1.959963984540054;p=h/n;den=1+z*z/n;v=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den;c=(p+z*z/(2*n))/den;return [c-v,c+v]
def counts(rows):
 ph=[r['primary_hit'] for r in rows if r['primary_hit'] is not None];wh=[r['wdl_hit'] for r in rows if r['wdl_hit'] is not None];t=Counter(r['total_settlement'] for r in rows if r['total_settlement'] is not None);n=sum(t.values());non=n-t['push'];pop=len(rows)
 return dict(population=pop,settled=pop,pending=0,primary_n=len(ph),primary_hits=sum(ph),primary_accuracy=sum(ph)/len(ph) if ph else None,primary_coverage=len(ph)/pop,primary_failures_or_abstentions=pop-len(ph),primary_hits_over_population=sum(ph)/pop,primary_wilson_95=wilson(sum(ph),len(ph)),wdl_n=len(wh),wdl_hits=sum(wh),wdl_accuracy=sum(wh)/len(wh) if wh else None,wdl_coverage=len(wh)/pop,wdl_wilson_95=wilson(sum(wh),len(wh)),total_n=n,total_coverage=n/pop,total_non_push_n=non,total_strict_full_win_rate=t['win']/non if non else None,total_settlements={k:t[k] for k in ['win','half_win','push','half_loss','loss']})
comp=[];pairs={'first':[],'published_revision':[]};active=[];same=[]
for i,name in zip(lock['fixtures'],names):
 f=i['fixture'];mid=f['match_id'];score,wdl=actual(mid);first=record(i['tracks']['candidate']['first']);rev=record(i['published_candidate_update']);assert first['evaluation_slot']=='FIRST_PREMATCH'
 for label,ref in [('first',i['tracks']['candidate']['first']),('published_revision',i['published_candidate_update'])]:
  z=record(ref)
  for role in ['current','test']:check_matrix(z['payload'][role])
  pairs[label].append(pair(ref))
 same.append(dict(match_id=mid,matrix_identity={role:first['payload'][role]['matrix_hash']==rev['payload'][role]['matrix_hash'] for role in ['current','test']},artifact_identity={role:first['payload'][role]['artifact_sha256']==rev['payload'][role]['artifact_sha256'] for role in ['current','test']},first_ref=i['tracks']['candidate']['first'],revision_ref=i['published_candidate_update']))
 ar=i['tracks']['active']['first']
 if ar:active.append(pair(ar,False))
 cr=i['published_comprehensive']
 if cr:
  c=record(cr);p=c['payload'];assert c['evaluation_slot']=='FIRST_PREMATCH'
  row=dict(match_id=mid,name=name,level=f['league_level'],actual=score,primary=p['primary'],primary_hit=p['primary']==score,wdl=p['wdl'],wdl_hit=p['wdl']==wdl,total_line=p['total_line'],total_direction=p['total_direction'],total_settlement=settle(mid,p['total_line'],p['total_direction']),freeze_id=c['freeze_id'],record_sha256=c['record_sha256'],recorded_at=c['recorded_at'],delivery_status='FROZEN_PREMATCH')
 else:row=dict(match_id=mid,name=name,level=f['league_level'],actual=score,primary=None,primary_hit=None,wdl=None,wdl_hit=None,total_line=None,total_direction=None,total_settlement=None,freeze_id=None,delivery_status='FAILED_BEFORE_KICKOFF_NO_RECOMMENDATION')
 comp.append(row)
candidate_reviews={label:review(ps,results) for label,ps in pairs.items()};active_review=review(active,results)
top=[];tr=record(lock['top3_receipt'])
for n,t in enumerate(tr['payload']['top3'],1):
 row=next(x for x in comp if x['match_id']==t['match_id']);assert t['rank']==n
 for k in ['primary','wdl','total_line','total_direction']:assert row[k]==t[k]
 top.append(dict(row,rank=n))
net={};prob={}
def summarize_net(rows):
 dif=np.array([int(x['comprehensive_hit'])-int(x['candidate_hit']) for x in rows]);rng=np.random.default_rng(20261116);boot=rng.choice(dif,size=(20000,len(dif)),replace=True).mean(axis=1);right=int((dif>0).sum());wrong=int((dif<0).sum());n=right+wrong
 return dict(n=len(rows),changed_right=right,changed_wrong=wrong,net_hits=int(dif.sum()),descriptive_rate_difference_bootstrap_95=np.quantile(boot,[.025,.975]).tolist(),exact_discordant_sign_test_p=min(1.,2*sum(math.comb(n,k) for k in range(min(right,wrong)+1))/2**n) if n else 1.,not_promotion_evidence=True)
for role in ['current','test']:
 nr=[];wr=[];diag=[]
 for i in lock['fixtures']:
  mid=i['fixture']['match_id'];p=record(i['published_candidate_update'])['payload'][role];matrix=check_matrix(p);h,a=res[mid]['home_goals'],res[mid]['away_goals'];score,wdl=actual(mid);c=next(x for x in comp if x['match_id']==mid)
  if c['primary'] is not None:
   nr.append(dict(match_id=mid,version=p['version'],comprehensive=c['primary'],candidate=p['primary'],actual=score,comprehensive_hit=c['primary_hit'],candidate_hit=p['primary']==score))
   wr.append(dict(match_id=mid,version=p['version'],comprehensive=c['wdl'],candidate=p['wdl_reference'],actual=wdl,comprehensive_hit=c['wdl_hit'],candidate_hit=p['wdl_reference']==wdl))
  g=summarize_prediction(p);gr=goal_review(g,home_goals=h,away_goals=a);total=np.add.outer(np.arange(matrix.shape[0]),np.arange(matrix.shape[1]));line=i['fixture']['total_quote']['line']
  # This is probability quality, not an invented pre-match selected OU direction.
  probs=total_settlement(matrix,line,'under');actual_category=settle(mid,line,'小')
  diag.append(dict(match_id=mid,version=p['version'],level=i['fixture']['league_level'],training_cutoff=p['training_data_cutoff'],actual=[h,a],mean=[g[s]['mean'] for s in ['home','away']],mean_error=[gr[s]['mean_error'] for s in ['home','away']],absolute_error=[gr[s]['absolute_error'] for s in ['home','away']],interval_hit=[gr[s]['interval_hit'] for s in ['home','away']],interval=[g[s]['central_interval'] for s in ['home','away']],p_zero=[g[s]['p0'] for s in ['home','away']],observed_zero=[h==0,a==0],p_total_ge4=float(matrix[total>=4].sum()),observed_total_ge4=h+a>=4,p_total_ge9=float(matrix[total>=9].sum()),actual_score_probability=float(matrix[h,a]),score_log_loss=-math.log(max(float(matrix[h,a]),1e-15)),wdl_log_loss=-math.log(max(p['wdl'][wdl],1e-15)),wdl_brier_sum3=sum((v-int(k==wdl))**2 for k,v in p['wdl'].items()),actual_total_line=line,total_settlement_category_probabilities=probs,total_category_observed=actual_category,total_category_log_loss=-math.log(max(probs[actual_category],1e-15)),total_category_brier_sum5=sum((v-int(k==actual_category))**2 for k,v in probs.items())))
 def perversion(rows):return {v:summarize_net([x for x in rows if x['version']==v]) for v in sorted({x['version'] for x in rows})}
 net[role]=dict(score=dict(rows=nr,batch_descriptive=summarize_net(nr),by_version=perversion(nr)),wdl=dict(rows=wr,batch_descriptive=summarize_net(wr),by_version=perversion(wr)))
 def ps(ds):return dict(n=len(ds),**{k:np.mean([d[k] for d in ds],axis=0).tolist() for k in ['actual','mean','mean_error','absolute_error','interval_hit','p_zero','observed_zero','p_total_ge4','observed_total_ge4','p_total_ge9','score_log_loss','wdl_log_loss','wdl_brier_sum3','total_category_log_loss','total_category_brier_sum5']})
 prob[role]=dict(rows=diag,by_version={v:ps([d for d in diag if d['version']==v]) for v in sorted({d['version'] for d in diag})},no_post_result_fitting=True,total_probability_diagnostics_not_model_OU_recommendations=True)
# Re-read all prior settled original results and first candidate freezes, never sum revisions.
old=[]
for root in ['nations-review-20261113-0842','nations-review-20261114-1322','review-kashiwa-20261115-1540']:
 for r in read(Path('/workspace/WCPP/reports')/root/'verified-results.json'):
  if r.get('competition','uefa.nations')=='uefa.nations':old.append(r)
assert len(old)==26 and len({r['match_id'] for r in old+results})==34
oldpairs=[];cumulative_refs=[]
for r in old:
 assert sha(r['source_path'])==r['source_sha256'];raw=read(r['source_path']);c=raw['header']['competitions'][0]
 for side in ['home','away']:
  t=next(t for t in c['competitors'] if t['homeAway']==side);assert verify_period_scores(t,c['status'])['regulation']==r[side+'_goals']
 path=F/digest(dict(match_id=r['match_id'],stage='prematch',track='nations-paired-candidates'))/'000001.json';z=verify(read(path));assert z['evaluation_slot']=='FIRST_PREMATCH';ref=dict(path=str(path),sha256=z['record_sha256'],freeze_id=z['freeze_id']);oldpairs.append(pair(ref));cumulative_refs.append(ref)
cumulative=review(oldpairs+pairs['first'],old+results)
write('cumulative-inputs.json',dict(original_results=old,first_candidate_receipts=cumulative_refs,unique_n=34))
m=dict(schema='WCPP-NATIONS-REVIEW-20261116-1',calculated_at=datetime.now(timezone.utc).isoformat(),population=8,completed=8,pending=0,comprehensive=dict(summary=counts(comp),rows=comp),top3=dict(summary=counts(top),rows=top,original_receipt=lock['top3_receipt']),active_frozen_pairs=active_review,active_scope=dict(population=8,available=0,explicit_refusal_freezes=7,missing_freeze_due_delivery_failure=1),candidate_models=candidate_reviews,first_vs_revision_identity=same,manual_net=net,probability_diagnostics=prob,cumulative_first_candidates=cumulative,model_total_direction_note='First and updated numerical candidates have no frozen selected OU reference; original matrices may support probability diagnostics only. Do not assign directions after results.',active_registry_sha256=sha('/workspace/WCPP/runtime/active-model.json'),model_parameters_changed=False,model_promoted=False)
assert m['active_registry_sha256']==lock['active_registry_sha256'];write('metrics.json',m)
print(json.dumps(dict(comprehensive=m['comprehensive']['summary'],top3=m['top3']['summary'],net={r:{k:v['batch_descriptive'] for k,v in z.items()} for r,z in net.items()},candidate_by_version={role:z['by_version'] for role,z in m['candidate_models']['first']['models'].items()},cumulative=34),ensure_ascii=False))
