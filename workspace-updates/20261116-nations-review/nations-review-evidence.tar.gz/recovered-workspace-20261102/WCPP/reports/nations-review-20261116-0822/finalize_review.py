"""Reconcile review metrics, preserve failures, then freeze report and decisions."""
import json,csv,sys,hashlib,subprocess
from pathlib import Path
from datetime import datetime,timezone
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from research.analysis_freeze import save,verify,aware
R=Path(__file__).resolve().parent;read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();now=lambda:datetime.now(timezone.utc).isoformat()
def write(name,x):
 with (R/name).open('x') as h:json.dump(x,h,ensure_ascii=False,indent=2,allow_nan=False)
m=read(R/'metrics.json');lock=read(R/'review-scope-lock.json');results={r['match_id']:r for r in read(R/'verified-results.json')};process={r['match_id']:r for r in read(R/'verified-process.json')}
assert len(results)==len(m['comprehensive']['rows'])==8
for row in m['comprehensive']['rows']:
 a=results[row['match_id']];assert row['actual']==f"{a['home_goals']}-{a['away_goals']}"
 assert row['primary_hit']==(row['primary']==row['actual'] if row['primary'] is not None else None)
 if row['total_settlement'] is not None:
  line=row['total_line'];legs=[line] if line*2==int(line*2) else [line-.25,line+.25];g=a['home_goals']+a['away_goals'];net=sum((int(g<l)-int(g>l)) for l in legs)/len(legs)
  if row['total_direction']=='大':net=-net
  assert row['total_settlement']=={1:'win',.5:'half_win',0:'push',-.5:'half_loss',-1:'loss'}[net]
s=m['comprehensive']['summary'];assert (s['primary_hits'],s['primary_n'],s['wdl_hits'],s['wdl_n'])==(1,6,4,6);assert s['total_settlements']==dict(win=1,half_win=0,push=1,half_loss=1,loss=1);assert m['cumulative_first_candidates']['scope']==34
assert m['top3']['summary']['primary_hits']==1 and m['top3']['summary']['wdl_hits']==2
# Verify every actual old reference; review-stage delivery failure is not a prematch forecast.
def refs(x):
 if isinstance(x,dict):
  if x.get('freeze_id') and x.get('path') and x.get('sha256'):yield x
  for v in x.values():yield from refs(v)
 elif isinstance(x,list):
  for v in x:yield from refs(v)
oldrefs={x['sha256']:x for x in refs(lock)}
for ref in oldrefs.values():
 z=verify(read(ref['path']));assert z['record_sha256']==ref['sha256']
 if z['stage']=='prematch':assert aware(z['recorded_at'])<aware(z['fixture']['kickoff_at'])
registry_sha=sha('/workspace/WCPP/runtime/active-model.json');assert registry_sha==lock['active_registry_sha256'];assert not subprocess.check_output(['git','status','--porcelain'],cwd='/workspace/Football-Analysis').strip()
decision=dict(decision=['KEEP_CURRENT_TEST_PARAMETERS','KEEP_RESEARCH_CANDIDATES_INACTIVE','RETAIN_DELIVERY_FAILURES','SUPPLEMENT_FRESH_DATA_BEFORE_NEW_EXPERIMENT'],batch_unique=8,manual_selected=6,cumulative_nations_first=34,manual_summary=s,manual_net=m['manual_net'],reasons=['Manual score gained one against each referenced candidate on the same six matches; paired uncertainty includes zero and discordant sign-test p=1. No validated improvement or promotion.', 'Finland 7-2 was already 3-0 at 20 minutes and 5-1 at half-time, without a red card. Low-rate stale candidates and manual small-total selection missed a large winning margin and conceded goals. One penalty explains neither seven Finland goals nor the whole nine-goal tail.', 'Spain was 0-3 down before England red card. Strong prematch counterevidence was recorded but not resolved before TOP3 ranking; a low-confidence label did not make the choice reliable.', 'Belgium 4-1: manual draw lost a WDL hit versus both candidate home directions. Same-six WDL net benefit is zero despite Belarus direction improvement.', 'Croatia conceded at 84 minutes; known five-match concession record was relevant counterevidence to 2-0. A low away shot count does not ensure a clean sheet.', 'France exact hit includes an opponent own goal and a 90-minute away goal; one such hit does not validate the method.'],engineering_status=dict(prior_failed_oneoff_script='JSON list passed to ndarray settlement; already corrected in last delivery, originals retained',this_review='all calculations and rendering verified before review publication; original failures remain',market_available=8,model_OU_selected=0,model_OU_reason='Research pair contract stores actual line and probabilities but no explicit pre-frozen over/under selection; not an API access failure this batch'),next_checks=['Next complete original frozen batch: preserve all matches, incomplete deliveries and first/revision separation, with three KPI denominators.', 'For a future numerical OU experiment, fix the decision/abstention rule and explicit total.quote/reference_direction before results, then independently freeze; never add selections to these eight completed matches.', 'Before a fixed-recipe refresh, validate new 90-minute history and source times, preserve original fitted recipes and candidate IDs, and predeclare temporal training/calibration/holdout boundaries. This reviewed batch is not an untouched validation set for any change it motivates.', 'Apply existing TOP3 evidence rule: unresolved high-impact counterevidence is a reason to omit a slot; no requirement to force three picks. Do not uniformly add goals or switch all totals to over.'],training_run=False,parameters_changed=False,registry_changed=False,promotion=False)
write('review-decision.json',decision)
cn={None:'未选择','win':'全赢','half_win':'半赢','push':'走盘','half_loss':'半输','loss':'全输'}
lines=['# 欧国联复盘｜北京时间2026年11月16日','','HELLO BOSS','','**昨晚6场有效综合推荐：第一比分1/6（16.7%），胜平负4/6（66.7%）；实际大小球4场为1全赢、1走盘、1半输、1全输。** 排除走盘后的严格全赢率为1/3（33.3%），半输不能算半个命中。原8场范围全部完赛；两场交付失败保留，综合比分/方向覆盖6/8（75%），大小球覆盖4/8（50%）。按整批计比分命中1/8，不把失败从覆盖分母删除。','',
 '比分命中率95% Wilson区间约3.0%–56.4%，样本不足以证明稳定水平。法国2-1是唯一综合比分命中；没有达到项目目标，也不能将这一个命中当成算法优化成功。','',
 '|比赛|首版综合比分|90分钟赛果|比分|原胜平负|方向|原实际大小球|结算|','|---|---|---|---|---|---|---|---|']
for x in m['comprehensive']['rows']:
 total='未交付' if x['primary'] is None else '观望' if x['total_direction'] not in ['大','小'] else f"{x['total_direction']}{x['total_line']:g}"
 lines.append(f"|{x['name']}|{x['primary'] or '未交付'}|{x['actual']}|{'—' if x['primary_hit'] is None else '中' if x['primary_hit'] else '失'}|{x['wdl'] or '—'}|{'—' if x['wdl_hit'] is None else '中' if x['wdl_hit'] else '失'}|{total}|{'—' if x['total_settlement'] is None else cn[x['total_settlement']]}|")
lines+=['','22:00的拉脱维亚、塞浦路斯两场，昨晚综合交付脚本失败，未冻结的人工草稿不用于评价。它们的赛前数值候选已真实冻结，仍按对应研究轨结算。没有补发、倒签或按赛果挑版本。','',
 '## 原TOP3，不重选或换序','','|原排名|比赛|原比分→赛果|比分|胜平负|实际大小球|','|---|---|---|---|---|---|']
for x in m['top3']['rows']:
 lines.append(f"|{x['rank']}|{x['name']}|{x['primary']}→{x['actual']}|{'中' if x['primary_hit'] else '失'}|{'中' if x['wdl_hit'] else '失'}|{'观望' if x['total_settlement'] is None else str(x['total_direction'])+str(x['total_line'])+'：'+cn[x['total_settlement']]}|")
lines+=['','TOP3比分1/3，胜平负2/3；大小球1全赢、1全输、1观望。这是三场赛事的单一比分成绩，不用备选比分覆盖率代替。','',
 '## 主要失误及过程证据','',
 '**芬兰7-2圣马力诺：本轮最大偏差。** 芬兰8、17、20分钟已连进三球，半场5-1，全场射正11-2；没有红牌。圣马力诺26分钟点球、76分钟再进球。原3-0既低估主队进球，也错判客队零球，小4全输。赛前强调芬兰其他四场只进2球，未充分处理对手强弱差异，以及同对手首回合7-0所提示的上限；不能把九球全归因于一个点球。','',
 '原Test给芬兰/圣马力诺的均值为2.44/0.86，芬兰中央80%模型内区间1–5球，实际7球超出；原矩阵总球≥9概率约0.69%。这显示本次尾部失配，但单场极端结果不能证明概率应被改成多少，更不能给所有比赛统一加球。','',
 '**西班牙2-3英格兰：胜负和优先排序都失误。** 英格兰45分钟点球、53和57分钟再进球，63分钟被罚下一人时已3-0领先；西班牙65分钟点球、75分钟追至2-3。原主胜不能归因于英格兰的红牌。赛前已记录英格兰两客场9-0、Test主客胜概率接近、西班牙主胜赔率上升等反证，仍排第三优先；仅标低置信不足以化解这些矛盾，应落实允许TOP3不足三场的既有规则。','',
 '**比利时4-1意大利：把双方都有进攻依据误收缩为平局。** 意大利11分钟领先，比利时15、22、26分钟连入三球，80分钟再进；射正10-4，意大利补时还罚失点球。原1-1、平局均失，大小球原为观望。两数值候选边际方向都是主胜，人工改平局损失一个方向命中；不能把联合比分众数1-1等同于最优胜平负方向。','',
 '**克罗地亚2-1捷克：零封反证兑现。** 克罗地亚2分钟领先，捷克84分钟追平，87分钟主队再入球。射正8-1，但客队唯一射正得分；原主胜正确，2-0错误，小2.75半输。赛前已知克罗地亚五场均失球，不能因对手近期进球少就把客队1球路径排除。','',
 '**白俄罗斯0-2阿尔巴尼亚：方向正确，客队少估一球。** 阿尔巴尼亚28、57分钟进球，射正4-3；原0-1失、客胜中，小2走盘。没有把0-2备选补算为第一比分命中。','',
 '**法国2-1土耳其：唯一命中，也保留偶然性。** 半场0-0，49分钟土耳其球员Emir Han Topcu乌龙帮助法国领先，80分钟法国再入球，土耳其90分钟追回一球；射正8-3。比分、主胜、小3.5均中。乌龙球员属于土耳其、受益队为法国，已核对比分变化和名单；不能凭一次包含乌龙及晚失球的命中宣称选分规则可靠。','',
 '两场交付失败也保留过程：拉脱维亚0-0亚美尼亚，射正9-6但无进球；塞浦路斯1-4黑山，52分钟点球扳平后58、67、83分钟连失球。它们不计人工推荐命中或失败，仅作为覆盖失败和原候选结算。没有xG，射正不能直接当机会质量或必然进球。','',
 '## 数值候选、人工增量与概率质量','',
 '活动Current/Test没有已验收欧国联路由：8场有效预测覆盖0/8，其中7份明确拒绝冻结、1场因交付中断缺少该轨冻结。以下是独立未晋级候选WCPP-NATIONS-{等级}-{CURRENT/TEST}-0.1，训练截至10月6日，最新两轮未进入训练。','',
 '|等级/本批数量|Current比分|Test比分|Current胜平负|Test胜平负|','|---|---|---|---|---|']
for grade in ['A','C']:
 c=m['candidate_models']['first']['models']['当前模型']['by_version'][f'WCPP-NATIONS-{grade}-CURRENT-0.1'];t=m['candidate_models']['first']['models']['test模型']['by_version'][f'WCPP-NATIONS-{grade}-TEST-0.1'];n=c['primary_eligible'];lines.append(f"|{grade}/{n}|{c['primary_hits']}/{n}|{t['primary_hits']}/{n}|{c['wdl_hits']}/{n}|{t['wdl_hits']}/{n}|")
lines+=['','本批原始首版与昨晚21:52更新的模型工件/矩阵逐场相同，比分与方向成绩也相同；两版独立留档，不累计为16场。Current同等级共享基础进球率，本批统计首选均1-1，这是已知结构限制；Test仍未取得本批精确比分命中。不能靠人工统一加球修正这一问题。','',
 '**同场6场比较：** 综合比分对Current和Test各净增1场（均为法国），改错为对1、改对为错0；描述性配对区间含0、离散检验p=1，尚无稳定增益证据。胜平负人工在白俄罗斯改对、比利时改错，对两候选净增均0，不能把整体4/6写成新增方向优势。','',
 '**模型大小球分母仍为0的具体原因：** 本轮8/8真实盘口快照已核验，不是本轮API无法获取。候选原记录只有实际盘线和概率，没有预先冻结的大/小选向；因此不能在看到赛果后选择一边。人工综合4场则有明确方向，已正常结算。模型五类结算概率的Brier/log-loss可作诊断，不能冒充选向命中率。','',
 '双方均值误差、中央80%区间覆盖、零球概率、高比分尾部、比分log-loss、胜平负Brier/log-loss及实际盘口五类概率质量均逐场、逐版本保存在metrics.json；全部来自原矩阵，没有赛后重训。','',
 '累计34个不重复、已完赛首版候选，继续按等级分列：','',
 '|等级|样本|Current比分|Test比分|Current胜平负|Test胜平负|','|---|---|---|---|---|---|']
for grade in ['A','B','C','D']:
 c=m['cumulative_first_candidates']['models']['当前模型']['by_version'][f'WCPP-NATIONS-{grade}-CURRENT-0.1'];t=m['cumulative_first_candidates']['models']['test模型']['by_version'][f'WCPP-NATIONS-{grade}-TEST-0.1'];n=c['primary_eligible'];lines.append(f"|{grade}|{n}|{c['primary_hits']}/{n}|{t['primary_hits']}/{n}|{c['wdl_hits']}/{n}|{t['wdl_hits']}/{n}|")
lines+=['','每级仍未满足原协议至少30场及其他验收要求；样本达到门槛也不自动晋级。累计结果不等于活动模型成绩，更不等于综合人工Primary；既有未来计划中的未完赛样本仍待后续结算。','',
 '## 本次决定与来源','',
 '保持原模型参数和注册表，候选不晋级；本轮未训练或调整融合权重。优先补最新合格历史，后续固定配方刷新与尾部/选分实验分开登记、同场比较；这批已复盘样本不能再冒充新规则的未见留出。下次需要数值大小球研究时，先锁定选向/观望规则与实际报价并冻结，不能给本批补填。原交付脚本的矩阵类型错误已在昨晚修复，本次仍保留两场失败记录。','',
 '8场ESPN summary的身份、开球、主客、90分钟分节比分已核对；使用昨晚冻结市场观测中的provider_match_id连接独立The Odds赛果，8场一致，没有靠赛果倒推匹配。32个进球事件已与累计比分、球员队和乌龙标记对齐。比利时半场虽缺少独立keyEvent标记，但header分节明确3-1，已按分节核验。','',
 '原始点球汇总有4处为0而事件明示进球，保留原文并采用核验事件；西班牙射正7次、2球与对方扑救6次不一致，不据此量化门将表现。8场当前来源均无真实xG。本次9个赛果请求有真实HTTP起止时间和哈希，没有用文件时间冒充采集时间。所有赛后过程只用于诊断，不回填赛前特征。','',
 '[ESPN赛程](https://site.api.espn.com/apis/site/v2/sports/soccer/uefa.nations/scoreboard?dates=20261115)；逐场summary URL、独立来源响应及盘口原文保存在归档中。','',
 '原推理源码7a18cee715acb0633904af434b3f743d870c0951（PR #38）；源码与活动工件本次未变，CI回执为该源码已有成功结果，不能把它当成本次新训练验收。复盘和调整决定追加冻结，长期归档至数据仓库，环境不发布。']
report='\n'.join(lines)+'\n';(R/'复盘报告.md').write_text(report)
with (R/'复盘展示.csv').open('x',encoding='utf-8-sig',newline='') as h:
 w=csv.writer(h);w.writerow(['比赛','原综合比分','实际90分钟比分','比分命中','原胜平负','方向命中','实际盘线','大小球方向','结算','交付状态','冻结ID'])
 for x in m['comprehensive']['rows']:w.writerow([x['name'],x['primary'],x['actual'],x['primary_hit'],x['wdl'],x['wdl_hit'],x['total_line'],x['total_direction'],cn[x['total_settlement']],x['delivery_status'],x['freeze_id']])
validation=dict(status='PASS',verified_at=now(),original_freezes_verified=len(oldrefs),unique_results=8,independent_score_agreement=8,goal_events_verified=32,settlement_implementations=2,independent_sign_check=True,original_comprehensive_valid=6,delivery_failures_preserved=2,metrics_sha256=sha(R/'metrics.json'),active_registry_sha256=registry_sha,source_worktree_clean=True,source_files_changed=False)
write('verification.json',validation)
receipts=[]
for item in lock['fixtures']:
 mid=item['fixture']['match_id'];f=dict(item['fixture'],cutoff_at=now());row=next(x for x in m['comprehensive']['rows'] if x['match_id']==mid)
 receipts.append(save(dict(result=results[mid],process=process[mid],original_accounts=item,first_comprehensive_review=row,candidate_first_review=next(x for x in m['candidate_models']['first']['paired_rows'] if x['match_id']==mid),candidate_update_review=next(x for x in m['candidate_models']['published_revision']['paired_rows'] if x['match_id']==mid),decision=decision,metrics_sha256=sha(R/'metrics.json'),prematch_records_modified=False),f,stage='review',track='comprehensive'))
shell=dict(match_id='review-nations:20261116-0822',kickoff_at=min(x['kickoff_at'] for x in results.values()),cutoff_at=now())
top=save(dict(top3=m['top3'],ranking_changed=False),shell,stage='review',track='top3-selection')
rr=save(dict(report_markdown=report,metrics=m,decision=decision,scope_lock=read(R/'scope-lock-receipt.json'),match_review_receipts=receipts,top3_review_receipt=top,verification=validation,source_commit=lock['source_commit'],environment_published=False),dict(shell,cutoff_at=now()),stage='review',track='analysis-report')
allrefs=[read(R/'scope-lock-receipt.json')]+receipts+[top,rr]
for ref in allrefs+list(oldrefs.values()):assert verify(read(ref['path']))['record_sha256']==ref['sha256']
assert sha('/workspace/WCPP/runtime/active-model.json')==registry_sha
write('delivery.json',dict(report_receipt=rr,match_review_receipts=receipts,top3_review_receipt=top,all_receipts=allrefs,review_population=8,review_settled=8,review_pending=0,manual_recommendations=6,preserved_delivery_failures=2,cumulative_nations_first=34,source_commit=lock['source_commit'],source_main_commit=lock['source_main_commit'],source_pr='https://github.com/kaka597000/Football-Analysis/pull/38',active_registry_sha256=registry_sha,active_model_changed=False,prematch_records_changed=False,environment_published=False))
print(json.dumps(dict(report=rr,new_receipts=len(allrefs),original_freezes_unchanged=len(oldrefs)),ensure_ascii=False))
