# ESPN 赛后原文采集过程摘要

按锁定名单依序请求 401861171–401861178。每场单次 GET，间隔约 1.2 秒；无重试。所有请求 HTTP 200，状态为 Full Time。原文逐字节存档，SHA-256 与实际请求/读取完成时间、最终 URL 记录于对应 `.meta.json`。

## 赛果简报

| ESPN ID | 主队 | 半场 | 全场90分钟 | 射门/射正 主-客 |
|---|---|---|---|---|
| 401861171 | Latvia | First Half ends, Latvia 0, Armenia 0. | 0-0 | 20/9 - 21/6 |
| 401861172 | Cyprus | First Half ends, Cyprus 0, Montenegro 1. | 1-4 | 14/4 - 12/6 |
| 401861173 | Belarus | First Half ends, Belarus 0, Albania 1. | 0-2 | 12/3 - 13/4 |
| 401861174 | Finland | First Half ends, Finland 5, San Marino 1. | 7-2 | 18/11 - 6/2 |
| 401861175 | Spain | First Half ends, Spain 0, England 1. | 2-3 | 23/7 - 9/5 |
| 401861176 | Belgium | 缺失 | 4-1 | 22/10 - 12/4 |
| 401861177 | France | First Half ends, France 0, Türkiye 0. | 2-1 | 23/8 - 13/3 |
| 401861178 | Croatia | First Half ends, Croatia 1, Czechia 0. | 2-1 | 21/8 - 8/1 |

进球累计比分、分钟及红牌/点球/乌龙/VAR等关键事件见 `results-index.json`；ESPN 未提供 xG 时保留为空值，不作推断。该摘要未计算命中率。
