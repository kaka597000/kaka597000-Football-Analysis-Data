import sys,json,hashlib
from pathlib import Path
from datetime import datetime,timezone
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from research.analysis_freeze import verify,save,digest,aware
R=Path(__file__).resolve().parent;P=Path('/workspace/WCPP/reports/scope-prematch-20261115-2146');F=Path('/workspace/WCPP/forecasts/issued-analyses')
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ref(p):
 z=verify(read(p));assert z['stage']=='prematch' and aware(z['recorded_at'])<aware(z['fixture']['kickoff_at'])
 return dict(path=str(p),sha256=z['record_sha256'],freeze_id=z['freeze_id'],recorded_at=z['recorded_at'],revision=z['revision'],evaluation_slot=z['evaluation_slot'])
def chain(mid,track):
 ps=sorted((F/digest(dict(match_id=mid,stage='prematch',track=track))).glob('[0-9]*.json'));prev=None
 for p in ps:
  z=verify(read(p));assert z['previous_sha256']==prev;prev=z['record_sha256']
 return [ref(p) for p in ps]
fixtures=read(P/'prepared-fixtures.json');records={x['fixture']['match_id']:x for x in read(P/'analysis-records.json')};updates={verify(read(x['path']))['match_id']:x for x in read(P/'candidate-update/receipts.json')};d=read(P/'delivery.json');out=[]
for f in fixtures:
 mid=f['match_id'];tracks={}
 for key,track in [('candidate','nations-paired-candidates'),('active','current-test-pair'),('comprehensive','comprehensive')]:
  cs=chain(mid,track);tracks[key]=dict(first=cs[0] if cs else None,revisions=cs[1:])
 assert tracks['candidate']['first'];current=updates[mid];verify(read(current['path']))
 if mid in records:assert records[mid]['comprehensive_receipt']['sha256']==tracks['comprehensive']['first']['sha256']
 else:assert tracks['comprehensive']['first'] is None
 out.append(dict(fixture=f,tracks=tracks,published_candidate_update=current,published_comprehensive=records[mid]['comprehensive_receipt'] if mid in records else None,comprehensive_status='FROZEN_PREMATCH' if mid in records else 'FAILED_BEFORE_KICKOFF_NO_RECOMMENDATION'))
lock=dict(schema='WCPP-NATIONS-REVIEW-LOCK-20261116',locked_at=datetime.now(timezone.utc).isoformat(),population=8,fixtures=out,published_report_receipt=read(P/'report-delivery-receipt.json'),original_report_receipt=d['report_receipt'],top3_receipt=d['top3_receipt'],failure_receipt=read(P/'delivery-failure-receipt.json'),source_commit='7a18cee715acb0633904af434b3f743d870c0951',source_main_commit='1257fdde7b6746b7ba6d2aa919382214a2cfb589',active_registry_sha256=sha('/workspace/WCPP/runtime/active-model.json'),prematch_archive_path='/workspace/kaka597000-Football-Analysis-Data/workspace-updates/20261115-evening-scope/manifest.json',prematch_archive_manifest_sha256=sha('/workspace/kaka597000-Football-Analysis-Data/workspace-updates/20261115-evening-scope/manifest.json'),policy='FIRST_PREMATCH per track default; Nov15 candidate revision separate; six comprehensive and original TOP3; two failed comprehensive deliveries retained in eight-match coverage. No invented first editions or retrospective selection.')
with (R/'review-scope-lock.json').open('x') as h:json.dump(lock,h,ensure_ascii=False,indent=2)
r=save(lock,dict(match_id='review-nations:20261116-0822',kickoff_at=min(f['kickoff_at'] for f in fixtures),cutoff_at=datetime.now(timezone.utc).isoformat()),stage='review',track='review-scope-lock')
with (R/'scope-lock-receipt.json').open('x') as h:json.dump(r,h,ensure_ascii=False,indent=2)
print(json.dumps(dict(population=8,comprehensive=6,candidate_pairs=8,active_freezes=sum(bool(x['tracks']['active']['first']) for x in out),freeze=r),ensure_ascii=False))
