"""Durable evidence with content-verified reuse of prior archives."""
import json,os,sys,hashlib,tarfile,shutil,subprocess,platform,importlib.metadata
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
R=Path(__file__).resolve().parent;REPO=Path('/workspace/kaka597000-Football-Analysis-Data');DEST=REPO/'workspace-updates/20261116-nations-review'
sys.path.insert(0,'/workspace/Football-Analysis/scripts')
from check_repository import BINDINGS,PATTERNS
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):
 if Path(p).exists():
  assert read(p)==x,str(p)
  return
 with Path(p).open('x') as h:json.dump(x,h,ensure_ascii=False,indent=2,allow_nan=False)
delivery=read(R/'delivery.json');source=delivery['source_commit'];paths={};catalog={};archive_hashes={}
# Public HTML can contain the site's own client keys. Publish a redacted derivative,
# retain the original SHA and metadata, and never pretend the derivative is raw.
redactions=[];excluded_public_raw=set()
for p in R.rglob('*.html'):
 if p.name.endswith('.redacted.html'):continue
 b=p.read_bytes();txt=b.decode('utf-8',errors='replace');spans=[]
 for name,pattern in PATTERNS.items():
  for m in pattern.finditer(txt):
   if name=='literal_credential' and m.group(1).upper().startswith(('TEST_','SYNTHETIC_','EXAMPLE_')):continue
   spans.append((m.start(),m.end()))
 if spans:
  clean=txt
  for a,b in sorted(set(spans),reverse=True):clean=clean[:a]+'[REDACTED_PUBLIC_PAGE_CREDENTIAL]'+clean[b:]
  derivative=p.with_suffix('.redacted.html')
  if derivative.exists():assert derivative.read_text()==clean
  else:derivative.write_text(clean)
  excluded_public_raw.add(str(p.resolve()))
  redactions.append(dict(original_path=str(p),original_sha256=sha(p),original_not_uploaded=True,redacted_path=str(derivative),redacted_sha256=sha(derivative),redactions=len(set(spans)),reason='Public webpage credential-like literal omitted from public archive; structured schedule API preserved independently.'))
write(R/'public-page-redactions.json',dict(files=redactions))
def add(p):
 p=Path(p)
 if p.is_file() and '__pycache__' not in p.parts and str(p.resolve()) not in excluded_public_raw:paths[str(p)]=p
def collect(x):
 if isinstance(x,dict):
  for v in x.values():collect(v)
 elif isinstance(x,list):
  for v in x:collect(v)
 elif isinstance(x,str) and x.startswith('/workspace/') and '\n' not in x:
  add(x)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd='/workspace/Football-Analysis').decode().strip()==source
assert not subprocess.check_output(['git','status','--porcelain'],cwd='/workspace/Football-Analysis').strip()
write(R/'inference-environment.json',dict(python=platform.python_version(),packages={n:importlib.metadata.version(n) for n in ['numpy','scipy','lightgbm','scikit-learn']},source_commit=source,source_main_commit=delivery['source_main_commit'],source_branch='analysis/remaining-nations-brazil-20261115',source_changed_this_delivery=False,model_promotion=False))
folders=['20261110-nations-model','20261113-nations-review','20261113-nations-evening','20261114-nations-review','20261114-nations-prematch','20261115-remaining-nations-brazil','20261111-jleague-cup','20261111-jleague-cup-quarterfinals','20261111-jleague-cup-lineups','20261112-jleague-cup-review','20261115-review-kashiwa','20261115-evening-scope']
for folder in folders:
 root=REPO/'workspace-updates'/folder;m=read(root/'manifest.json');digest=m.get('archive_sha256')
 if not isinstance(digest,str):continue
 candidates=[root/m['archive']] if m.get('archive') else list(root.glob('*.tar.gz'))
 archive=next(p for p in candidates if sha(p)==digest);name=str(archive.relative_to(REPO));archive_hashes[name]=dict(sha256=digest)
 for row in m.get('members',m.get('files',[])):
  path=row.get('original_path',row.get('path',row.get('workspace_path')));member=row.get('archive_member',row.get('archive_path'))
  if path and member:catalog[(str(Path(path).resolve()),row['sha256'])]=dict(original_path=path,repository_archive=name,archive_member=member,sha256=row['sha256'])
 rp=root/'recovery-map.json'
 if rp.exists():
  old=read(rp);archive_hashes.update(old['reused_archives'])
  for row in old['reused_files']:catalog[(str(Path(row['original_path']).resolve()),row['sha256'])]=row
for p in R.rglob('*'):add(p)
raw_json_parse_gaps=[]
for p in list(paths.values()):
 if p.suffix=='.json':
  try: value=read(p)
  except (UnicodeDecodeError,json.JSONDecodeError) as exc:
   raw_json_parse_gaps.append(dict(path=str(p),error=type(exc).__name__,retained_as_raw_bytes=True))
  else: collect(value)
# All frozen versions needed to validate hash chains and every referenced first edition.
done=set()
while True:
 pending=[p for p in paths.values() if '/forecasts/issued-analyses/' in str(p) and str(p) not in done]
 if not pending:break
 for p in pending:
  done.add(str(p));collect(read(p))
  for q in p.parent.glob('[0-9]*.json'):add(q)
nidx=Path('/workspace/nations-model-20261110/models/candidates.json');add(nidx)
for route in read(nidx)['routes'].values():
 for ref in route.values():
  p=Path(ref['path']);assert sha(p)==ref['sha256'];add(p);a=read(p)
  for k in ['dataset_path','protocol_path']:add(a[k])
registry=Path('/workspace/WCPP/runtime/active-model.json');add(registry)
for name in ['odds.json','source-metadata.json']:add('/workspace/WCPP/reports/remaining-nations-brazil-20261115-0240/market-nations/'+name)
add('/workspace/Football-Analysis/configs/analysis-scope.json')
new=[];reused=[];secrets=[os.environ[k].encode() for k in BINDINGS if os.environ.get(k) and len(os.environ[k])>=8]
for original,p in sorted(paths.items()):
 b=p.read_bytes()
 if any(v in b for v in secrets):raise ValueError('configured credential detected in '+p.name)
 try:txt=b.decode('utf-8')
 except UnicodeDecodeError:txt=None
 if txt is not None:
  for name,pattern in PATTERNS.items():
   for match in pattern.finditer(txt):
    if name=='literal_credential' and match.group(1).upper().startswith(('TEST_','SYNTHETIC_','EXAMPLE_')):continue
    raise ValueError('credential pattern '+name+' in '+str(p))
 digest=hashlib.sha256(b).hexdigest();prior=catalog.get((str(p.resolve()),digest))
 if prior and not p.is_relative_to(R):reused.append(dict(prior,original_path=original));continue
 new.append(dict(original_path=original,archive_member=str(Path(original).relative_to('/workspace')),sha256=digest,bytes=len(b)))
DEST.mkdir(exist_ok=False);archive=DEST/'nations-review-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for e in new:t.add(e['original_path'],arcname=e['archive_member'],recursive=False)
used={e['repository_archive']:archive_hashes[e['repository_archive']] for e in reused}
for name,v in used.items():assert sha(REPO/name)==v['sha256']
write(DEST/'recovery-map.json',dict(reused_archives=used,reused_files=reused,absolute_path_aliases={'/workspace/WCPP':'/workspace/recovered-workspace-20261102/WCPP'},no_frozen_path_or_hash_rewrite=True,source_checkout_separate=source,restore_notice='Stage in a fresh directory and verify all bytes/chains first. Preserve original absolute paths and WCPP alias. Never rerun expired fixtures as prematch or overwrite existing user data.'))
sidecars=['复盘报告.md','复盘报告_交付版.md','复盘展示.csv','metrics.json','review-decision.json','delivery.json','report-delivery-receipt.json','verification.json','source-verification.json','second-source-verification.json','source-conflicts.json','source-ci.json','inference-environment.json']
for name in sidecars:shutil.copy2(R/name,DEST/name)
shutil.copy2(REPO/'workspace-updates/20261115-evening-scope/verify_archive.py',DEST/'verify_archive.py')
(DEST/'README.md').write_text("""# 11月16日欧国联复盘

[完整复盘](复盘报告_交付版.md) · [CSV展示](复盘展示.csv) · [Python指标](metrics.json) · [调整决定](review-decision.json) · [最新报告回执](report-delivery-receipt.json)

原8场已完赛，6场有效综合第一比分1/6、胜平负4/6；实际大小球4场为1全赢、1走盘、1半输、1全输。TOP3比分1/3、胜平负2/3。两场交付失败继续保留在覆盖分母。8场赛果经ESPN及赛前绑定The Odds provider_match_id交叉核对，32个进球事件完成身份/比分增量核验。

原候选首次与11月15日晚修订分列，两个等级本批比分均未中。累计34场首版研究候选按等级统计，不混成单一活动模型成绩。8场盘口可用，但数值候选没有赛前冻结大/小选向，因此模型OU命中率不补造；人工4场正常结算。没有改模型参数、注册表、旧冻结或发布环境。

08:33报告v1中把0-2误称为备选，08:34的v2已删除这一不准确描述。原实际推荐0-1、赛果0-2及全部指标/决定不变；两份报告和冻结链均保留，以交付版为准。

恢复：在本目录运行 `python verify_archive.py --stage /tmp/NEW-nations-review-restore`。核验新增归档、复用长期归档、文件字节与冻结链后，再按recovery-map.json恢复原路径和WCPP别名；源码另检出精确commit，依赖见inference-environment.json。复盘只读取原矩阵和预测，禁止将已结束比赛重新发布为赛前。

执行源码7a18cee715acb0633904af434b3f743d870c0951，PR #38仍开放、已有源码CI成功，main为1257fdde7b6746b7ba6d2aa919382214a2cfb589。本轮只有数据/报告提交，未新增源码PR；manifest中的data_parent_commit是本轮归档前的数据版本。
""")
manifest=dict(schema='WCPP-NATIONS-REVIEW-ARCHIVE-20261116',created_at_beijing=datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),source_commit=source,source_main_commit=delivery['source_main_commit'],data_parent_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO).decode().strip(),archive=archive.name,archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,non_json_raw_responses=raw_json_parse_gaps,public_html_redactions=redactions,members=new,reused_files=len(reused),sidecar_files=[dict(path=p.name,sha256=sha(p)) for p in sorted(DEST.iterdir()) if p.is_file() and p!=archive],report_receipt=read(R/'report-delivery-receipt.json'),original_report_receipt=delivery['report_receipt'],credential_scan=dict(scanned_files=len(paths),configured_bindings_checked=len(secrets),findings=0),active_model_changed=False,environment_published=False)
write(DEST/'manifest.json',manifest)
latest=read(REPO/'latest-source.json');key=str(DEST.relative_to(REPO));latest['additional_workspace_updates'].append(key);latest['latest_review']=key+'/复盘报告_交付版.md';latest['latest_nations_review']=key+'/manifest.json';latest['latest_review_source_commit']=source;latest['synchronized_at']=datetime.now(ZoneInfo('Asia/Shanghai')).isoformat()
latest['latest_chat_review_runtime']=dict(source_commit=source,source_main_commit=delivery['source_main_commit'],population=8,settled=8,manual_selected=6,preserved_delivery_failures=2,cumulative_nations_first=34,report_receipt=read(R/'report-delivery-receipt.json'),active_registry_sha256=delivery['active_registry_sha256'],models_changed=False)
(REPO/'latest-source.json').write_text(json.dumps(latest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(destination=str(DEST),new_files=len(new),reused_files=len(reused),archives=len(used)+1,archive_bytes=archive.stat().st_size,credential_findings=0),ensure_ascii=False))
