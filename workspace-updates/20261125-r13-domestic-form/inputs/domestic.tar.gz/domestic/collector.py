#!/usr/bin/env python3
"""Collect month/day ESPN public soccer scoreboard JSON; no credentials."""
import concurrent.futures, gzip, hashlib, json, time
from datetime import datetime, timezone
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent
RAW = ROOT / 'raw'; RAW.mkdir(exist_ok=True)
API = 'https://site.api.espn.com/apis/site/v2/sports/soccer/{}/scoreboard'
# ESPN public league codes; ordered priorities for ambiguity/fallback are documented in manifest.
LEAGUES = ['eng.1','esp.1','ger.1','ita.1','fra.1','ned.1','por.1','bel.1','sco.1','tur.1','ukr.1','gre.1','cze.1','aut.1','sui.1','nor.1','den.1','jpn.1','kor.1','aus.1','chn.1','tha.1','mas.1','ksa.1','uae.1','qat.1','irn.1']
# Complete months for 2023-2025 and Jan-Oct 2026. For Nov 2026, query each requested UTC date only.
queries = [(c, f'{y}{m:02d}') for c in LEAGUES for y in range(2023,2027) for m in range(1,13) if (y < 2026 or m <= 10)]
queries += [(c, f'202611{d:02d}') for c in LEAGUES for d in range(1,25)]
manifest_path = ROOT / 'manifest.json'
if manifest_path.exists(): manifest = json.loads(manifest_path.read_text())
else:
    manifest = {
      'schema':'r13-domestic-intake-1', 'provider':'ESPN public site API',
      'capture_started_at':datetime.now(timezone.utc).isoformat(),
      'requested_utc_dates':{'start_inclusive':'2023-01-01','end_inclusive':'2026-11-24'},
      'endpoint_template':API+'?dates={YYYYMM_or_YYYYMMDD}&limit=1000', 'limit':1000,
      'same_service_max_concurrency':3,
      'competition_codes_priority':LEAGUES,
      'responses':[], 'failed_queries':[], 'known_limitations':[
        'R5 seed was inspected: scratch/r12-data/seed has 9,127 normalized rows but no original ESPN scoreboard response bytes to reuse; therefore no seed rows are presented as byte-verifiable scoreboard evidence.',
        'The ESPN scoreboard endpoint supports YYYYMM month requests and YYYYMMDD day requests. November 2026 is queried one requested UTC day at a time to avoid over-querying dates after 2026-11-24.',
        'League code availability is empirical; unsupported code responses are reported as coverage gaps, not silently substituted.'
      ]
    }
seen = {(x['competition'], x['query_period']) for x in manifest['responses']}
failed_seen = {(x['competition'],x['query_period']) for x in manifest['failed_queries']}

def fetch(task):
    comp, period = task
    url = API.format(comp) + f'?dates={period}&limit=1000'
    req = Request(url, headers={'User-Agent':'R13-domestic-intake/1.0 (public scoreboard evidence)','Accept':'application/json','Accept-Encoding':'identity'})
    for attempt in range(4):
        try:
            with urlopen(req, timeout=45) as response:
                raw = response.read(); code = response.status
            if code != 200: return {'ok':False,'competition':comp,'query_period':period,'url':url,'http_status':code,'error':'non-200'}
            data = json.loads(raw)
            if not isinstance(data,dict) or not isinstance(data.get('events'),list):
                return {'ok':False,'competition':comp,'query_period':period,'url':url,'http_status':code,'error':'unexpected JSON shape'}
            sha = hashlib.sha256(raw).hexdigest()
            gz = gzip.compress(raw, compresslevel=9, mtime=0)
            path = RAW / f'{comp}_{period}_{sha}.json.gz'
            path.write_bytes(gz)
            return {'ok':True,'competition':comp,'query_period':period,'url':url,'captured_at':datetime.now(timezone.utc).isoformat(),
                    'http_status':code,'source_sha256':sha,'gzip_sha256':hashlib.sha256(gz).hexdigest(),
                    'raw_bytes':len(raw),'gzip_bytes':len(gz),'raw_gzip':str(path.relative_to(ROOT)),
                    'event_count':len(data['events']),'limit':1000,'truncation_suspected':len(data['events'])>=1000,
                    'http_response_headers':{'content_type':response.headers.get('Content-Type'),'date':response.headers.get('Date'),'etag':response.headers.get('ETag')}}
        except HTTPError as e:
            try: body=e.read().decode('utf-8','replace')[:500]
            except Exception: body=''
            if e.code in (400,404): return {'ok':False,'competition':comp,'query_period':period,'url':url,'http_status':e.code,'error':body or 'unsupported/unavailable'}
            err=f'HTTP {e.code}: {body}'
        except (URLError,TimeoutError,ValueError) as e: err=f'{type(e).__name__}: {e}'
        if attempt < 3: time.sleep(1.5*(attempt+1))
    return {'ok':False,'competition':comp,'query_period':period,'url':url,'error':err}

pending = [q for q in queries if q not in seen and q not in failed_seen]
print(f'queries_total={len(queries)} already_archived={len(seen)} previously_failed={len(failed_seen)} pending={len(pending)}', flush=True)
# Only three concurrent requests to ESPN; manifest is persisted after each result.
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    for result in pool.map(fetch, pending):
        if result['ok']:
            del result['ok']; manifest['responses'].append(result)
            if result['truncation_suspected']:
                manifest.setdefault('truncation_followups',[]).append({'competition':result['competition'],'query_period':result['query_period'],'action':'NEEDS_SPLIT_REQUERY'})
        else:
            del result['ok']; manifest['failed_queries'].append(result)
        manifest['responses'].sort(key=lambda x:(LEAGUES.index(x['competition']),x['query_period']))
        manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
        if len(manifest['responses']) % 50 == 0: print(f"archived={len(manifest['responses'])}/{len(queries)} failures={len(manifest['failed_queries'])}",flush=True)
print(f"done responses={len(manifest['responses'])} failed={len(manifest['failed_queries'])}",flush=True)
