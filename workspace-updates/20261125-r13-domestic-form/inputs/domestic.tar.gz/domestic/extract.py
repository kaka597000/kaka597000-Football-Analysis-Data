#!/usr/bin/env python3
"""Rebuild domestic.jsonl and coverage.json from archived ESPN scoreboard bytes."""
import argparse, gzip, hashlib, json, re
from collections import Counter, defaultdict
from datetime import date, datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
START = date(2023, 1, 1)
END = date(2026, 11, 24)
MANIFEST = ROOT / 'manifest.json'

def digest(b): return hashlib.sha256(b).hexdigest()
def iso_day(s): return datetime.fromisoformat(s.replace('Z', '+00:00')).astimezone(timezone.utc).date().isoformat()
def as_int(value):
    if isinstance(value, bool): raise ValueError('boolean score')
    s = str(value).strip()
    if not re.fullmatch(r'\d+', s): raise ValueError(f'non-integer score: {s!r}')
    return int(s)
def load_manifest(): return json.loads(MANIFEST.read_text())

def phase_tags(season_name, phase_notes):
    text = ' '.join(str(n.get('text') or n.get('headline') or '') if isinstance(n,dict) else str(n) for n in phase_notes).lower()
    season = (season_name or '').lower()
    tags=[]
    rules=(
      ('playoff', ('playoff',)), ('semi_final', ('semi-final','semifinal')),
      ('quarter_final', ('quarter-final','quarterfinal')), ('final_phase', ('final',)),
      ('group_stage', ('group-stage',)), ('championship_round', ('championship-round',)),
      ('relegation_round', ('relegation-round',)),
      ('two_leg_tie', ('1st leg','2nd leg','first leg','second leg','aggregate')),
    )
    for tag, marks in rules:
        if any(mark in season for mark in marks) or any(mark in text for mark in marks): tags.append(tag)
    return tags

def extract():
    manifest = load_manifest()
    candidates = defaultdict(list)
    exclusions = Counter(); per_comp_events = Counter(); invalid_sources = []
    parse_errors = []; seen_event_responses = set()
    for item in manifest['responses']:
        p = ROOT / item['raw_gzip']
        raw = gzip.decompress(p.read_bytes())
        sha = digest(raw)
        if sha != item['source_sha256']: raise ValueError(f'raw SHA mismatch: {p}')
        data = json.loads(raw)
        if not isinstance(data, dict) or not isinstance(data.get('events'), list):
            invalid_sources.append({'competition':item['competition'],'url':item['url'],'reason':'invalid scoreboard JSON/events shape','source_sha256':sha}); continue
        # Never accept an ESPN default/fallback scoreboard for a different requested league.
        leagues = data.get('leagues') or []
        slugs = sorted({str(x.get('slug','')).lower() for x in leagues if isinstance(x,dict) and x.get('slug')})
        requested = item['competition'].lower()
        if requested not in slugs:
            invalid_sources.append({'competition':requested,'url':item['url'],'returned_league_slugs':slugs,'reason':'requested competition missing from response leagues.slug','source_sha256':sha})
            exclusions['source_league_mismatch_responses'] += len(data['events'])
            continue
        if len(data['events']) != item['event_count']: raise ValueError(f"event count mismatch: {item['url']}")
        comp = requested
        for e in data['events']:
            try:
                day = iso_day(e['date'])
                if not START.isoformat() <= day <= END.isoformat(): exclusions['outside_requested_utc_date_range'] += 1; continue
                status = (e.get('status') or {}).get('type') or {}
                period = (e.get('status') or {}).get('period')
                status_name = str(status.get('name') or '').upper()
                status_detail = str(status.get('detail') or status.get('shortDetail') or '').strip().upper()
                if any(x in status_name for x in ('AWARDED','ABANDONED','FORFEIT','CANCEL','SUSPEND')) or any(x in status_detail for x in ('AWARDED','ABANDONED','FORFEIT','CANCEL','SUSPEND')):
                    exclusions['awarded_abandoned_forfeit_or_other_nonstandard'] += 1; continue
                if not status.get('completed') or status.get('state') != 'post' or not (status_name == 'STATUS_FULL_TIME' or status_detail == 'FT'):
                    exclusions['not_explicit_full_time'] += 1; continue
                if period not in (None, 2): exclusions['extra_time_or_nonregulation_period'] += 1; continue
                detail_text = ' '.join(str(status.get(k, '')) for k in ('name','description','detail','shortDetail')).lower()
                if any(x in detail_text for x in ('extra time','penalt','after aet','after extra')):
                    exclusions['extra_time_or_penalties'] += 1; continue
                event_comp = (e.get('competitions') or [{}])[0]
                season_name = str((e.get('season') or {}).get('slug') or '')
                phase_notes = event_comp.get('notes') or []
                tags = phase_tags(season_name, phase_notes)
                phase_class = 'multi_stage_or_knockout' if tags else 'regular_stage'
                competitors = event_comp.get('competitors') or []
                home = next((x for x in competitors if x.get('homeAway') == 'home'), None)
                away = next((x for x in competitors if x.get('homeAway') == 'away'), None)
                if not home or not away: exclusions['missing_home_away'] += 1; continue
                home_nested = str((home.get('team') or {}).get('id') or '')
                away_nested = str((away.get('team') or {}).get('id') or '')
                home_id = str(home.get('id') or home_nested)
                away_id = str(away.get('id') or away_nested)
                if (home_nested and home.get('id') and home_nested != str(home.get('id'))) or (away_nested and away.get('id') and away_nested != str(away.get('id'))):
                    exclusions['competitor_team_id_conflict'] += 1; continue
                if not home_id.isdigit() or not away_id.isdigit() or home_id == away_id:
                    exclusions['invalid_or_conflicting_home_away_ids'] += 1; continue
                def score(team, side):
                    full = as_int(team.get('score'))
                    lines = team.get('linescores')
                    if not lines: return full, 'scoreboard_score_no_linescores'
                    if not isinstance(lines, list): raise ValueError(f'{side} linescores is not a list')
                    period_values = {}
                    for idx, line in enumerate(lines, start=1):
                        if not isinstance(line,dict): raise ValueError(f'{side} malformed linescore')
                        lp = line.get('period', idx)
                        try: lp = int(lp)
                        except (ValueError, TypeError): raise ValueError(f'{side} invalid linescore period')
                        if lp in period_values: raise ValueError(f'{side} duplicate period {lp} linescore')
                        period_values[lp] = as_int(line.get('displayValue',line.get('value')))
                    if 1 not in period_values or 2 not in period_values:
                        raise ValueError(f'{side} linescores missing period 1 or 2')
                    regulation = period_values[1] + period_values[2]
                    if regulation != full: raise ValueError(f'{side} period1+2={regulation} conflicts with full-time score={full}')
                    return regulation, 'period1_plus_period2_verified'
                hg,hsrc = score(home,'home'); ag,asrc = score(away,'away')
                eid = str(e.get('id') or '')
                if not eid.isdigit(): raise ValueError(f'non-numeric event ID: {eid!r}')
                row = {
                    'competition':comp, 'id':eid, 'date':day, 'home_id':home_id, 'away_id':away_id,
                    'home_goals':hg, 'away_goals':ag, 'source_sha256':sha,
                    'score_source':{'home':hsrc,'away':asrc}, 'status':'FT', 'regulation_period':period,
                    'phase_classification':phase_class, 'phase_tags':tags,
                    'phase_evidence':{'event_name':e.get('name'),'season_name':season_name,'notes':phase_notes},
                    'source_url':item['url'], 'source_query_period':item['query_period']
                }
                candidates[eid].append(row); per_comp_events[comp] += 1
                seen_event_responses.add((sha,eid))
            except Exception as ex:
                parse_errors.append({'competition':comp,'event_id':e.get('id'),'source_sha256':sha,'error':str(ex)})
    # Cross-source duplicate IDs are reconciled as a set. If any source disagrees on
    # date/teams/score, no variant is allowed into the training-ready output.
    rows=[]; conflicts=[]; exact_dupes=[]; cross_league_ids={}
    for eid, group in candidates.items():
        leagues=sorted({r['competition'] for r in group})
        if len(leagues)>1: cross_league_ids[eid]=leagues
        signatures={(r['date'],r['home_id'],r['away_id'],r['home_goals'],r['away_goals']) for r in group}
        if len(signatures)>1:
            conflicts.append({'id':eid,'competitions':leagues,'source_sha256s':sorted({r['source_sha256'] for r in group}),'variants':group,'reason':'cross-source event ID numeric/date/team conflict; all variants excluded'})
            exclusions['conflicting_duplicate_event_ids_all_variants_excluded'] += 1
            continue
        # Identical source copies collapse to one deterministic row, with all sources recorded.
        group.sort(key=lambda r:(r['competition'],r['source_sha256'],r['source_query_period']))
        keep=group[0]
        if len(group)>1:
            keep['duplicate_sources']=[{'competition':r['competition'],'source_sha256':r['source_sha256'],'source_url':r['source_url']} for r in group]
            exact_dupes.append({'id':eid,'competitions':leagues,'copies':len(group)})
        rows.append(keep)
    rows.sort(key=lambda x:(x['date'],x['competition'],int(x['id'])))
    regular_rows=[r for r in rows if r['phase_classification']=='regular_stage']
    phase_rows=[r for r in rows if r['phase_classification']=='multi_stage_or_knockout']
    for filename, output_rows in (('domestic.jsonl',rows),('domestic-regular.jsonl',regular_rows)):
        with (ROOT/filename).open('w') as f:
            for row in output_rows: f.write(json.dumps(row,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n')
    # Validate and count failed HTTP response bodies too: each requested URL has archived byte evidence.
    failed_archives=[]
    for item in manifest.get('failed_queries',[]):
        if item.get('raw_gzip'):
            body=gzip.decompress((ROOT/item['raw_gzip']).read_bytes())
            if digest(body)!=item['source_sha256']: raise ValueError(f"failed-response raw SHA mismatch: {item['url']}")
            failed_archives.append(item)
    volume={'gzip_bytes':sum(x['gzip_bytes'] for x in manifest['responses']+failed_archives),'raw_response_bytes':sum(x['raw_bytes'] for x in manifest['responses']+failed_archives),'success_gzip_bytes':sum(x['gzip_bytes'] for x in manifest['responses']),'error_gzip_bytes':sum(x['gzip_bytes'] for x in failed_archives),'success_raw_response_bytes':sum(x['raw_bytes'] for x in manifest['responses']),'error_raw_response_bytes':sum(x['raw_bytes'] for x in failed_archives),'response_count':len(manifest['responses'])+len(failed_archives)}
    periods_by_comp=defaultdict(lambda:Counter())
    for x in manifest['responses']: periods_by_comp[x['competition']]['success']+=1
    for x in manifest.get('failed_queries',[]): periods_by_comp[x['competition']]['failed']+=1
    all_by_comp=Counter(r['competition'] for r in rows)
    regular_by_comp=Counter(r['competition'] for r in regular_rows)
    phase_by_comp=Counter(r['competition'] for r in phase_rows)
    comp_coverage={k:{'success_queries':v['success'],'failed_queries':v['failed'],'requested_queries':v['success']+v['failed'],'all_ft_matches':all_by_comp[k],'regular_stage_matches':regular_by_comp[k],'multi_stage_or_knockout_matches':phase_by_comp[k]} for k,v in sorted(periods_by_comp.items())}
    phase_counts={k:{'all_ft':all_by_comp[k],'regular_stage':regular_by_comp[k],'multi_stage_or_knockout':phase_by_comp[k]} for k in sorted(all_by_comp)}
    coverage={
      'requested_utc_dates':{'start_inclusive':START.isoformat(),'end_inclusive':END.isoformat()},
      'responses':[{k:v for k,v in x.items() if k!='raw_gzip'} for x in manifest['responses']],
      'failed_queries':manifest.get('failed_queries',[]),'query_count':len(manifest['responses'])+len(manifest.get('failed_queries',[])),
      'coverage_by_competition':comp_coverage,
      'events_returned':sum(x['event_count'] for x in manifest['responses']),
      'rows_by_competition':dict(sorted(all_by_comp.items())),
      'outputs':{'domestic.jsonl':{'rows':len(rows),'denominator':'all eligible, explicit regulation-time FT including evidenced phases'},'domestic-regular.jsonl':{'rows':len(regular_rows),'denominator':'same eligibility rules, excluding rows tagged as multi-stage/knockout'}},
      'phase_counts_by_competition':phase_counts,
      'phase_rule':'Rows are phase-tagged from ESPN season slug and competition notes; both files retain the same source evidence and regulation-score checks.',
      'dual_denominator_policy':{'selected_by_model_result':False,'domestic.jsonl':{'rows':len(rows),'includes_phase_tagged_rows':True,'phase_rows':len(phase_rows)},'domestic-regular.jsonl':{'rows':len(regular_rows),'includes_phase_tagged_rows':False,'purpose':'predeclared sensitivity recomputation'},'phase_tags_preserve_source_evidence':True},
      'included_rows':len(rows),'regular_stage_rows':len(regular_rows),'phase_rows':len(phase_rows),'exclusions':dict(exclusions),'invalid_source_responses':invalid_sources,
      'conflicts_excluded':conflicts,'exact_duplicate_rows_collapsed':exact_dupes,
      'cross_league_duplicate_event_id_count':len(cross_league_ids),'cross_league_duplicate_event_ids':cross_league_ids,
      'parse_errors':parse_errors,'collection_volume':volume,
      'known_limitations':manifest.get('known_limitations',[])
    }
    (ROOT/'coverage.json').write_text(json.dumps(coverage,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'rows':len(rows),'regular_rows':len(regular_rows),'phase_rows':len(phase_rows),'phase_counts_by_competition':phase_counts,'cross_league_duplicate_event_id_count':len(cross_league_ids),'conflicts_excluded':len(conflicts),'invalid_source_responses':len(invalid_sources),'parse_errors':len(parse_errors),'volume':volume},ensure_ascii=False))

if __name__=='__main__':
    argparse.ArgumentParser(description=__doc__).parse_args(); extract()
