# R13 国内赛程 intake 封存记录

封存时间：2026-11-25T08:20:53.680183+00:00
状态：内容已定稿；本目录文件与子目录设为只读。封存后不再修改。

## 固定分母

- `domestic.jsonl`：21497 场明确常规时间 FT，含 774 场 phase 标签比赛。
- `domestic-regular.jsonl`：20723 场标准阶段 FT。
- 两种口径均保留；未按模型结果选择。

## 归档体积

- ESPN 请求及归档响应：1890 个；gzip 原件 1890 个。
- gzip 响应总字节：18098823；raw 目录实际占用文件字节：18098823。

## 定稿文件 SHA-256

- `extract.py` — `caacc7feaae1bb216e7b4dbfdddbf05d750acaf6aa7557f54c8a59f6d5491446`
- `domestic.jsonl` — `4ef2be976c00be12118b54b90d4dbb34adb04d384adbcc7cddcae495df8a19cf`
- `domestic-regular.jsonl` — `dff4f56094f07717ac32a0a41f51e35b0260ba2147f7a88958fa26e5e3f65b8b`
- `coverage.json` — `599bc62267cbaba997741b361834d300f82af8444b0703b409f10748119cdb87`
- `manifest.json` — `ae4e676dfba923ac6272e798e462d26f3de42faf7e82f9ad02442c28b395745c`
- `README.md` — `f58a109f8e370c20f77f8686874f168818c2af53b278624b153e8423b11dff3f`
