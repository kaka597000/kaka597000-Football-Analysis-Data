#!/usr/bin/env python3
"""Archive exact decompressed bodies for failed ESPN requests, max concurrency 3."""
import concurrent.futures,gzip,hashlib,json
from datetime import datetime,timezone
from pathlib import Path
from urllib.request import Request,urlopen
from urllib.error import HTTPError,URLError
ROOT=Path(__file__).resolve().parent; MAN=ROOT/'manifest.json'; RAW=ROOT/'raw'
m=json.loads(MAN.read_text()); todo=[x for x in m.get('failed_queries',[]) if not x.get('source_sha256')]
def fetch(x):
 req=Request(x['url'],headers={'User-Agent':'R13-domestic-intake/1.0 (public scoreboard evidence)','Accept':'application/json','Accept-Encoding':'identity'})
 try:
  with urlopen(req,timeout=45) as r: body=r.read(); status=r.status; headers=r.headers
 except HTTPError as e: body=e.read();status=e.code;headers=e.headers
 except Exception as e:return x|{'capture_error':f'{type(e).__name__}: {e}','captured_at':datetime.now(timezone.utc).isoformat()}
 # urllib does not decode HTTPError bodies; normalize to the representation bytes before hashing.
 if headers.get('Content-Encoding','').lower()=='gzip': body=gzip.decompress(body)
 sha=hashlib.sha256(body).hexdigest(); gz=gzip.compress(body,compresslevel=9,mtime=0)
 path=RAW/f"error_{x['competition']}_{x['query_period']}_{sha}.json.gz";path.write_bytes(gz)
 return x|{'captured_at':datetime.now(timezone.utc).isoformat(),'http_status':status,'source_sha256':sha,'gzip_sha256':hashlib.sha256(gz).hexdigest(),'raw_bytes':len(body),'gzip_bytes':len(gz),'raw_gzip':str(path.relative_to(ROOT)),'response_headers':{'content_type':headers.get('Content-Type'),'content_encoding':headers.get('Content-Encoding'),'date':headers.get('Date')}}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
 revised=list(ex.map(fetch,todo))
by={(x['competition'],x['query_period']) for x in revised}
it=iter(revised)
m['failed_queries']=[next(it) if (x['competition'],x['query_period']) in by and not x.get('source_sha256') else x for x in m['failed_queries']]
MAN.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'attempted':len(todo),'archived':sum(bool(x.get('source_sha256')) for x in revised),'capture_errors':[x for x in revised if x.get('capture_error')]},ensure_ascii=False))
