#!/usr/bin/env python3
"""Rebuild R13 identities.jsonl, extension.jsonl and coverage.json from archived inputs."""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import gzip, hashlib, json

ROOT=Path(__file__).resolve().parent
COMPS=('uefa.champions','uefa.europa','uefa.europa.conf','afc.champions')
def read_jsonl(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
def dump_jsonl(path, rows):
    path.write_text(''.join(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n' for x in rows))
def sha(data): return hashlib.sha256(data).hexdigest()
def utc(s):
    d=datetime.fromisoformat(s.replace('Z','+00:00')).astimezone(timezone.utc)
    return d.isoformat(timespec='seconds').replace('+00:00','Z')

source_map={}
for s in read_jsonl(ROOT/'source-manifest.jsonl'):
    b=gzip.decompress((ROOT/s['raw_file']).read_bytes())
    if sha(b)!=s['sha256']: raise ValueError(f'raw SHA mismatch {s["sha256"]}')
    obj=json.loads(b)
    if 'response' in obj: obj=obj['response']
    source_map[(s['url'],s['sha256'])]=obj
# Also retain the exact dated R5 input scoreboard referenced by the first issues.
extra_sha='2248458d50c5f4dc0c0b6414fd7eb2fcd88bdfd8068735f5a7a0248235dcbb88'
extra_url='https://site.api.espn.com/apis/site/v2/sports/soccer/uefa.champions/scoreboard?dates=20261124'
extra_raw=gzip.decompress((ROOT/'raw/scoreboard'/f'{extra_sha}.json.gz').read_bytes())
if sha(extra_raw)!=extra_sha: raise ValueError('R5 dated scoreboard source SHA mismatch')
extra_obj=json.loads(extra_raw)
if 'response' in extra_obj: extra_obj=extra_obj['response']
source_map[(extra_url,extra_sha)]=extra_obj

def get_event(url, source_sha, event_id):
    obj=source_map.get((url,source_sha))
    if obj is None: raise ValueError(f'missing archived source {url} {source_sha}')
    found=[e for e in obj.get('events',[]) if str(e.get('id'))==str(event_id)]
    if len(found)!=1: raise ValueError(f'event ID {event_id} count {len(found)} in {source_sha}')
    return found[0]
def competitors(event):
    c=event['competitions'][0]
    t={x['homeAway']:x for x in c['competitors']}
    if set(t)!={'home','away'}: raise ValueError(f'bad homeAway values in {event.get("id")}')
    return c,t['home'],t['away']

identities=[]
panel_counts={}
panel_ids=set()
for comp in COMPS:
    rows=read_jsonl(ROOT/f'inputs/panels/{comp}.jsonl')
    panel_counts[comp]=len(rows)
    for r in rows:
        if r['competition']!=comp: raise ValueError(f'panel competition mismatch {r["id"]}')
        sb=next(s for s in r['sources'] if '/scoreboard?' in s['url'])
        eid=r['id'].split(':',1)[1]
        e=get_event(sb['url'],sb['sha256'],eid)
        _,h,a=competitors(e)
        hn,an=h['team']['displayName'],a['team']['displayName']
        if (hn,an)!=(r['home'],r['away']): raise ValueError(f'formal panel name mismatch {r["id"]}: {(r["home"],r["away"])} != {(hn,an)}')
        source_date=e['date'][:10]
        rec={'date':r['date'],'id':r['id'],'competition':comp,'home_id':str(h['team']['id']),'away_id':str(a['team']['id']),
             'source_sha256':sb['sha256'],'source_url':sb['url'],'source_event_date':source_date,'kickoff_utc':utc(e['date']),
             'home_name':hn,'away_name':an,'date_differs_from_source':r['date']!=source_date,'input':'R5 panel','panel_source_sha256':r.get('source_sha256')}
        identities.append(rec);panel_ids.add(rec['id'])

r10=read_jsonl(ROOT/'inputs/r10/extend.jsonl')
r10rec={r['id']:r for r in read_jsonl(ROOT/'inputs/r10/reconciliation.jsonl')}
for r in r10:
    if r['id'] in panel_ids: continue
    sb=r['sources'][0];eid=r['id'].split(':',1)[1]
    e=get_event(sb['url'],sb['sha256'],eid);_,h,a=competitors(e)
    d=e['date'][:10]
    if d!=r['date']: raise ValueError(f'R10 date mismatch {r["id"]}: {d} vs {r["date"]}')
    rr=r10rec.get(r['id'])
    actual=[str(h['team']['id']),str(a['team']['id'])]
    if not rr or rr.get('team_ids')!=actual: raise ValueError(f'R10 reconciled home/away ID mismatch {r["id"]}')
    identities.append({'date':r['date'],'id':r['id'],'competition':'afc.champions','home_id':actual[0],'away_id':actual[1],
       'source_sha256':sb['sha256'],'source_url':sb['url'],'source_event_date':d,'kickoff_utc':utc(e['date']),
       'home_name':h['team']['displayName'],'away_name':a['team']['displayName'],'input_home_label':r['home'],'input_away_label':r['away'],
       'input_name_labels_exact_match':(r['home']==h['team']['displayName'] and r['away']==a['team']['displayName']),
       'r10_reconciliation_team_ids':rr['team_ids'],'date_differs_from_source':False,'input':'R10 AFC extend'})

r7root=ROOT/'inputs/r7'
r7_results=json.load(open(r7root/'results.json'))
r7_freeze=json.load(open(r7root/'review-freeze.json'))
if sha((r7root/'results.json').read_bytes())!=r7_freeze['payload']['results_sha256']:
    raise ValueError('R7 results.json hash differs from actual review freeze')
target=set(COMPS)
r7day=[r for r in r7_results if r.get('cohort') in target and r.get('kickoff_at','').startswith('2026-11-24')]
issues={}
for p in (r7root/'issues').glob('*.json'):
    d=json.load(open(p))
    if d.get('evaluation_slot')=='FIRST_PREMATCH' and d.get('revision')==1: issues[d['match_id']]=(p,d)
identity_by_id={r['id']:r for r in identities}
extension=[]
afc_covered=read_jsonl(r7root/'afc-already-covered-original.jsonl')
for r in r7day:
    if r.get('event_status')!='FT' or r.get('score_basis')!='regulation_90' or not r.get('evidence',{}).get('identity_verified'):
        raise ValueError(f'R7 fixture is not verified FT regulation time: {r["match_id"]}')
    ip,issue=issues[r['match_id']]
    summary_path=ROOT/'raw/r7/summary'/f'{r["match_id"].split(":",1)[1]}.json'
    raw=summary_path.read_bytes(); actual_sha=sha(raw)
    if actual_sha!=r['evidence']['sha256']: raise ValueError(f'R7 summary SHA mismatch {r["match_id"]}')
    data=json.loads(raw); hc=data['header']['competitions'][0]
    t={x['homeAway']:x for x in hc['competitors']};h,a=t['home'],t['away']
    if str(h['team']['id'])!=r['home'].split(':',1)[1] or str(a['team']['id'])!=r['away'].split(':',1)[1]: raise ValueError('R7 numeric identity mismatch')
    if h['team']['displayName']!=issue['payload']['home_name'] or a['team']['displayName']!=issue['payload']['away_name']: raise ValueError('R7 frozen names do not match official summary')
    if hc['date'][:10]!=r['kickoff_at'][:10]: raise ValueError('R7 source date mismatch')
    if len(h.get('linescores',[]))<2 or len(a.get('linescores',[]))<2: raise ValueError('R7 source does not have both period scores')
    hg=sum(int(x['displayValue']) for x in h['linescores'][:2]);ag=sum(int(x['displayValue']) for x in a['linescores'][:2])
    if (hg,ag)!=(r['home_goals'],r['away_goals']): raise ValueError('R7 two-period sums do not equal frozen 90-minute result')
    canonical=(r['cohort']+':'+r['match_id'].split(':',1)[1]) if r['cohort']=='afc.champions' else r['match_id']
    if canonical not in identity_by_id:
        ident={'date':hc['date'][:10],'id':canonical,'competition':r['cohort'],'home_id':str(h['team']['id']),'away_id':str(a['team']['id']),
          'source_sha256':actual_sha,'source_url':r['evidence']['url'],'source_event_date':hc['date'][:10],'kickoff_utc':utc(hc['date']),
          'home_name':h['team']['displayName'],'away_name':a['team']['displayName'],'date_differs_from_source':False,'input':'R7 official summary identity supplement'}
        identities.append(ident);identity_by_id[canonical]=ident
    if r['cohort']!='uefa.champions':
        continue
    # The exact R5 first-issued record is the input receipt frozen by R7.
    r5idx=json.load(open(ROOT/'inputs/r5-first-issues-index.json'))
    receipt=r5idx[r['match_id']]
    r5path=ROOT/receipt['path']; r5bytes=r5path.read_bytes(); r5= json.loads(r5bytes)
    if sha(r5bytes)!=receipt['file_sha256'] or r5.get('record_sha256')!=receipt['record_sha256']:
        raise ValueError(f'R5 first issue integrity mismatch {r["match_id"]}')
    if issue['payload'].get('input_sha256')!=r5['record_sha256']:
        raise ValueError(f'R7 first issue input receipt != R5 first issue {r["match_id"]}')
    issue_bytes=ip.read_bytes(); issue_file_sha=sha(issue_bytes)
    if not r5.get('payload',{}).get('model_stage'):
        raise ValueError(f'R5 first issue lacks model_stage {r["match_id"]}')
    r5f=r5['fixture']; r5p=r5['payload']
    if r5f.get('match_id')!=r['match_id'] or r5p.get('home_name')!=h['team']['displayName'] or r5p.get('away_name')!=a['team']['displayName']:
        raise ValueError(f'R5 first issue identity differs from verified event {r["match_id"]}')
    if r5f.get('home')!=f'espn:{h["team"]["id"]}' or r5f.get('away')!=f'espn:{a["team"]["id"]}':
        raise ValueError(f'R5 first issue numeric IDs differ from verified event {r["match_id"]}')
    if r5f.get('kickoff_at','')[:10]!=hc['date'][:10]: raise ValueError(f'R5 first issue date mismatch {r["match_id"]}')
    ev=r5p.get('market_evidence',{}); h2ev=ev.get('h2h',{}); outev=ev.get('total',{})
    if not h2ev.get('source_sha256') or h2ev.get('source_sha256')!=outev.get('source_sha256'):
        raise ValueError(f'R5 market evidence missing paired source {r["match_id"]}')
    source_sha=h2ev['source_sha256']; source_url=h2ev['source_url']
    r5sb=get_event(source_url,source_sha,r['match_id'].split(':',1)[1]);_,r5h,r5a=competitors(r5sb)
    if (str(r5h['team']['id']),str(r5a['team']['id']))!=(str(h['team']['id']),str(a['team']['id'])):
        raise ValueError(f'R5 odds source IDs differ from verified R7 event {r["match_id"]}')
    if source_url not in [x['url'] for x in read_jsonl(ROOT/'source-manifest.jsonl') if x['sha256']==source_sha] and source_sha!=extra_sha:
        raise ValueError(f'R5 odds raw source not in source manifest {r["match_id"]}')
    r7_first_candidate=issue['payload']['forecasts'].get('candidate')
    r7_market_forecast=issue['payload']['forecasts'].get('market')
    season_year=r5p.get('source_season',{}).get('year')
    season=(f'{season_year}-{str(season_year+1)[-2:]}' if isinstance(season_year,int) else None)
    extension.append({'competition':r['cohort'],'id':canonical,'r7_match_id':r['match_id'],'date':identity_by_id[canonical]['date'],
      'home':h['team']['displayName'],'away':a['team']['displayName'],'home_goals':hg,'away_goals':ag,
      'bookmaker':h2ev.get('bookmaker'),'h2h':r5p['prices'].get('h2h'),'total':r5p['prices'].get('total'),
      'neutral':bool(r5p.get('neutral',False)),'paired_market':True,
      'market_time_basis':{'source':'R5 first frozen pre-match input','snapshot_label':r5p.get('displayed_label'),
        'observed_at':h2ev.get('observed_at'),'quoted_at':h2ev.get('quoted_at')},
      'score_basis':'regulation_90 (sum of official ESPN first- and second-half linescores)','season':season,
      'source_sha256':actual_sha,'sources':[{'sha256':actual_sha,'url':r['evidence']['url']}],
      'source_stage':r5p.get('source_stage'),'r7_source_stage':r['stage'],'stage':r5p['model_stage'],
      'kickoff_utc':utc(hc['date']),'home_id':str(h['team']['id']),'away_id':str(a['team']['id']),
      'r7_forecast':r7_first_candidate,'market_forecast':r7_market_forecast,'r7_all_forecasts':issue['payload']['forecasts'],
      'r5_first_issue_id':r5['freeze_id'],'r5_first_issue_record_sha256':r5['record_sha256'],
      'r5_first_issue_file_sha256':receipt['file_sha256'],'r5_first_issue_file':receipt['path'],
      'r5_market_source_sha256':source_sha,'r5_market_source_url':source_url,
      'r5_market_source_raw_file':f'raw/scoreboard/{source_sha}.json.gz',
      'original_frozen_id':issue['freeze_id'],'original_frozen_sha256':issue['record_sha256'],'original_frozen_file_sha256':issue_file_sha,
      'original_frozen_record_file':str(ip.relative_to(ROOT)),'original_result_sha256':actual_sha,
      'r7_result_row_sha256':sha(json.dumps(r,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()),
      'r7_results_file_sha256':r7_freeze['payload']['results_sha256'],'r7_result_file':'inputs/r7/results.json',
      'r7_summary_raw_file':str(summary_path.relative_to(ROOT)),'r7_summary_url':r['evidence']['url'],'event_status':r['event_status']})

identities.sort(key=lambda x:(x['competition'],x['date'],x['id']))
extension.sort(key=lambda x:(x['competition'],x['date'],x['id']))
dump_jsonl(ROOT/'identities.jsonl',identities);dump_jsonl(ROOT/'extension.jsonl',extension)
dump_jsonl(ROOT/'afc-already-covered.jsonl',afc_covered)
by=Counter(x['competition'] for x in identities)
mismatch=[{'id':x['id'],'input_date':x['date'],'source_event_date':x['source_event_date']} for x in identities if x['date_differs_from_source']]
r10_label_diffs=[{'id':x['id'],'input_home_label':x['input_home_label'],'official_home_name':x['home_name'],
                   'input_away_label':x['input_away_label'],'official_away_name':x['away_name']}
                  for x in identities if x.get('input')=='R10 AFC extend' and not x.get('input_name_labels_exact_match')]
coverage={'schema':'R13-CONTINENTAL-COVERAGE-1','counts_by_competition':dict(sorted(by.items())),
 'r5_rows_by_competition':panel_counts,'r10_afc_extend_rows':len(r10),'identities_total':len(identities),
 'r7_extension_rows':len(extension),'r7_target_fixtures_seen':len(r7day),'r7_afc_already_covered_rows':len(afc_covered),'source_date_mismatch_count':len(mismatch),
 'source_date_mismatches':mismatch,'domestic_signal_start_utc_date':'2023-01-01',
 'pre_signal_rows_retained_by_competition':dict(sorted(Counter(x['competition'] for x in identities if x['date']<'2023-01-01').items())),
 'before_signal_rows_are_in_denominator':True,'r10_exact_name_label_differences':len(r10_label_diffs),
 'r10_name_label_differences_detail':r10_label_diffs,'unmatched':[]}
(ROOT/'coverage.json').write_text(json.dumps(coverage,ensure_ascii=False,indent=2)+'\n')
# Flat checksums for every deliverable/input except this self-referential index.
checksum_rows=[]
for p in sorted(ROOT.rglob('*')):
    if p.is_file() and p.name!='artifact-sha256.jsonl':
        b=p.read_bytes()
        checksum_rows.append({'path':str(p.relative_to(ROOT)),'bytes':len(b),'sha256':sha(b)})
dump_jsonl(ROOT/'artifact-sha256.jsonl',checksum_rows)
print(json.dumps(coverage,ensure_ascii=False,indent=2))
