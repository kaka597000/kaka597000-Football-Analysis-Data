# R13 continental identity intake

This directory contains a reproducible identity intake for the R5 UEFA Champions League, UEFA Europa League, UEFA Conference League, and AFC Champions League panels, plus the 55 R10 AFC additions.

## Files

- `identities.jsonl`: one row per unique R5/R10 event, with the competition-specific ID, panel/input date, official ESPN home/away team IDs and names, exact source SHA-256, source URL, ESPN source event date, and UTC kickoff.
- `extension.jsonl`: only the 9 completed UEFA Champions League fixtures on 2026-11-24 UTC. `stage` is the matching R5 first issue `payload.model_stage`. `r7_forecast` is the R7 first frozen candidate object; `market_forecast` remains separate; `r7_all_forecasts` preserves the full R7 forecast dictionary. `h2h` and `total` are copied from the same matching R5 first issue `payload.prices`.
- `afc-already-covered.jsonl`: the 8 R7 AFC fixtures already represented in R10, moved from the initial combined extension as-is.
- `raw/scoreboard/<sha256>.json.gz`: gzip files whose decompressed bytes hash to the source SHA-256. The source index records official ESPN URL, original archive location, byte count and local raw path.
- `raw/r7/summary/` and `raw/r7/first-issues/`: exact source bytes for R7 score and first issue records.
- `inputs/`: copied panel rows, R10 extend/reconciliation records, the full R7 results/freeze records, selected R5 first issues and their index.
- `source-manifest.jsonl`, `references.jsonl`, `manifest.json`: source and archive provenance.
- `coverage.json`: row counts, source date differences, pre-2023 rows retained, and R10 text-label differences.
- `artifact-sha256.jsonl`: per-file byte count and SHA-256 for every deliverable and input except the checksum index itself.
- `extract.py`: rebuilds `identities.jsonl`, `extension.jsonl`, `afc-already-covered.jsonl`, and `coverage.json` from the archived inputs and raw sources.

## Recompute

Run `python extract.py` from this directory. The script validates each raw SHA, strict event ID, homeAway assignment, team IDs, date, the R5 panel's exact official team names, R10 reconciliation IDs, the R7 first issue input receipt, and the two official half scores against the R7 90-minute result.

R5 archive team names are exact-match gates. R10's 55 supplemental AFC labels are retained verbatim alongside ESPN's official display names; when they differ, identity is joined by event ID, date, and the pre-existing R10 numeric home/away reconciliation. No fuzzy name join is performed.
