# 前 2010 年独立历史面板

数据窗口完全早于 R6 最早 2010-08 的输入。范围为 2006/07、2007/08 训练，2008/09 校准，2009/10 测试；英超、西甲、德甲、意甲、法甲、荷甲。每场记录含 `independent_split_role`。

24 个 football-data.co.uk 原始 CSV 保存在 `raw/`，`raw/receipts.json` 逐份保留实际 URL、北京时间抓取时间、HTTP 状态、字节数、SHA-256 及源表头；按 R5 字段结构生成 `panels/{competition}.jsonl`。比分为 FTHG/FTAG 常规时间全场，胜平负仅保留同场 Bet365 H/D/A。2.5 球价格如存在，必须 over 和 under 都大于 1；`price_pair_basis` 精确为 `same_book` 或 `cross_book`。跨机构均价不冒充 Bet365；赔率缺失不删比赛：`h2h=null`，合法总球独立保存；所有符合有效日期、球队及FTHG/FTAG的行均在面板中。逐源对账见 `reconciliation.json`。价格缺失为 null，不合成。

意甲 2010/11 源 CSV 有 380 场，但 Chievo–Bologna 和 Genoa–Brescia 两行没有 Bet365 H/D/A，故无法进入要求的配对市场面板；原行信息见 `../independent/italy-1011-exclusions.json`。数据交付仅含来源、收据、解析及字段审计，不含预测或效果分析。
