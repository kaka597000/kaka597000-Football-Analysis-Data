# 独立历史面板原始资料

抓取时间：2026-11-23（收据记录北京时间）；来源为 Football-Data.co.uk 每赛季联赛 CSV。范围 2010/11、2011/12、2012/13、2013/14 的英超、西甲、德甲、意甲、法甲、荷甲。

`raw/` 保存 24 个逐字节下载响应；`raw/receipts.json` 逐份记录请求 URL、HTTP 状态、抓取时间、字节数、SHA-256、原文件名和 CSV 表头。`panels/{competition}.jsonl` 沿用 R5 的赛事字段结构。日期解析为 ISO 日期，比分为来源的 FTHG/FTAG 常规时间全场比分，主客身份按源 CSV。胜平负为同场 Bet365 B365H/B365D/B365A。总球线固定 2.5：若数据有同机构 Bet365 双边价格则保留；否则 BbAv>2.5 和 BbAv<2.5 仅标作跨机构平均历史报价代理，不称 Bet365，也不合成缺失价格。价格时刻未发布，凡有实际总球线的记录，双边均严格大于 1，并附 `price_pair_basis=same_book` 或 `cross_book`；均标记 `historical_price_observation_proxy` / 无报价时钟。赛事行附 `independent_split_role`。缺 Bet365 H/D/A 的合格赛果仍保留在全体分母，`h2h=null`；意甲 2010/11 两行详见 `italy-1011-exclusions.json`。逐源对账见 `reconciliation.json`。

`summary.json` 统计逐文件和逐联赛记录数；`r5-r6-overlap-audit.json` 对照前轮早期面板、回放预测和拟合截止信息。此交付只含原始资料、解析和来源审计，不含模型或效果分析。
