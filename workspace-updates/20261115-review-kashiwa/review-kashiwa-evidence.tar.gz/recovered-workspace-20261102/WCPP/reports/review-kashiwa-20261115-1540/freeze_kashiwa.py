"""Freeze an explicitly manual Cup analysis; no substitute model probabilities."""
import json,sys,hashlib,re
from pathlib import Path
from datetime import datetime,timezone
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from research.analysis_freeze import save,verify,aware
from jleague_cup.safe_cli import load_artifact
R=Path(__file__).resolve().parent;D=R/'kashiwa-analysis';K=R/'kashiwa-data';OLD=Path('/workspace/jleague-cup-today-20261111')
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=lambda:datetime.now(timezone.utc).isoformat()
def write(p,x):
 with Path(p).open('x') as h:json.dump(x,h,ensure_ascii=False,indent=2,allow_nan=False)
active=read(D/'active-validated-attempt.json');f=active['fixture'];f['cutoff_at']=now()
assert aware(f['cutoff_at'])<aware(f['kickoff_at'])
ledger=read(K/'http-ledger.json')
for meta in ledger:
 assert sha(K/meta['path'])==meta['sha256']
 assert aware(meta['request_start_utc'])<=aware(meta['response_read_utc'])<=aware(f['cutoff_at'])
first=read(K/'first_leg-header-root.json');assert len(first)==1
h=first[0];assert h['type']=='post-game' and h['tournament']=='leaguecup' and h['isExtended'] is False
assert h['homeTeam']['code']=='kawasakif' and h['awayTeam']['code']=='kashiwa' and [h[s+'Team']['score'] for s in ['home','away']]==[1,2]
current_xi=read(K/'official-lineups-root.json');old_xi=read(K/'first_leg-lineups-root.json');changes={}
for side,oldside in [('home','away'),('away','home')]:
 players=current_xi[side+'Team']['players'];old=old_xi[oldside+'Team']['players'];assert len(players)==len(old)==11
 names={p['name'] for p in players};prior={p['name'] for p in old}
 changes[side]=dict(kept=sorted(names&prior),in_names=sorted(names-prior),out_names=sorted(prior-names),changed=len(names-prior))
 assert {p['name'] for p in read(K/'lineups.json')[side]['starters']}==names
assert changes['home']['changed']==6 and changes['away']['changed']==4
forms=[x for x in read(OLD/'verified-recent-j1.json') if x['team'] in ['Kashiwa','Kawasaki']];assert len(forms)==2
for team in forms:
 source=team['source'];path=OLD/'staging'/source['raw_path'];assert sha(path)==source['sha256'];raw=read(path)
 events={str(e['id']):e for e in raw['events']}
 for g in team['matches']:
  e=events[g['event_id']];c=e['competitions'][0];assert c['status']['type']['completed']
  us=next(t for t in c['competitors'] if str(t['team']['id'])==team['team_id']);them=next(t for t in c['competitors'] if str(t['team']['id'])!=team['team_id'])
  def goals(t):
   x=t['score'];return int(x['value'] if isinstance(x,dict) else x)
  assert [goals(us),goals(them)]==[g['gf'],g['ga']] and us['homeAway']==g['home_away'] and aware(e['date'])==aware(g['date_bjt'])
 team['root_verified_source_path']=str(path);team['freshness']='collected 2026-11-11; independent current refresh status recorded separately'
recent=next(x for x in read(OLD/'verified-process.json') if x['id']=='401877560');assert sha(recent['raw_path'])==recent['sha256']
raw=read(recent['raw_path']);c=raw['header']['competitions'][0];assert str(c['id'])=='401877560' and c['status']['type']['completed']
stats={str(t['team']['id']):{s['name']:s.get('displayValue') for s in t['statistics']} for t in raw['boxscore']['teams']}
assert [int(stats[t]['shotsOnTarget']) for t in ['7476','7112']]==[9,3]
assert [int(stats[t]['totalShots']) for t in ['7476','7112']]==[22,9]
artifacts=[]
for role in ['current','test']:
 p=Path('/workspace/jcup-qf-expansion-20261111/final-models/leg2')/(role+'-artifact.json');a=load_artifact(p)
 artifacts.append(dict(role=role,path=str(p),sha256=sha(p),version=a['version'],fit_n=a['core']['fit_n'],fit_end=a['core']['fit_end'],formal_acceptance_passed=a['formal_acceptance_passed'],loaded=True,prediction_issued=False))
attempt=read(D/'candidate-attempt/receipts.json');assert len(attempt['deferred'])==1 and attempt['receipts']==[]
evidence=dict(first_leg_header=h,first_leg_facts=read(K/'facts.json')['leg1'],current_starting_xi=current_xi,first_leg_starting_xi=old_xi,lineup_changes=changes,historical_j1_forms=forms,recent_direct_meeting=recent,current_refresh_files=[str(p) for p in sorted(K.glob('*schedule*'))],missing=['verified current same-provider xG/xGA','complete five-match Cup form','independent injury/suspension bulletin','all-competition workload','qualified real-time market quotes'],model_artifacts=artifacts)
write(D/'verified-context.json',evidence)
payload=dict(name='柏太阳神 vs 川崎前锋',status='MANUAL_RESEARCH_MODEL_BLOCKED',method_version='WCPP-JCUP-MANUAL-20261115-1',primary='2-1',wdl='主胜',total_line=None,total_direction='观望',actual_quote=None,confidence='低；仅人工研究参考',selection_scope='active_reference',current_test_reference=active['freeze_receipt'],candidate_attempt=attempt,model_outputs={'current':None,'test':None},formal_kpi_eligible=False,active_model_promotion=False,numerical_weights_changed=False,exact_score_basis='regulation_90',evidence=evidence,selection_evidence={
 'compared_scores':['2-1','1-1','1-0','1-2'],
 'candidate_comparison':[
  {'score':'2-1','support':'11月7日主场2-1、射门22-9/射正9-3，首回合客场2-1及23-9/6-1构成连续机会生成证据；柏五场联赛缓存10进球，川崎五场均进球且均失球。','counterevidence':'柏总比分领先，平局即可晋级；首发更换6人，近期两次优势不能保证重现或准确进两球。'},
  {'score':'1-1','support':'柏可控制风险，川崎必须追平总比分，双方均有一次进球路径。','counterevidence':'近两次直接交锋柏均在射门/射正端占优，不能仅因柏接受平局便把1-1当作最高概率结论。'},
  {'score':'1-0','support':'川崎首回合仅一次射正，柏有压缩进攻空间的条件。','counterevidence':'川崎此前五场联赛全部进球，首回合也先得分；此次首发更换4人，不能稳定外推其仅一次射正。'},
  {'score':'1-2','support':'川崎追分且柏可能回收，若早失球可转入开放比赛。','counterevidence':'已核验两次交锋的机会数量均偏柏，尚无新的同源xG或盘口证据支持反转为川崎优势。'}],
 'zero_vs_one':{'home':{'reason':'柏最近已核验五场联赛进10球，近两次对川崎均进2球；选至少1球有过程支持。','counterevidence':'五场中有0-0；领先总比分时可能降低节奏，6名首发变化增加不确定性。'},'away':{'reason':'川崎五场联赛全部进球、首回合先得分，追分要求提供至少1球路径。','counterevidence':'首回合仅1次射正，柏主场且无需冒进，川崎0球同样可能。'}},
 'three_plus_path':'比较2-1与1-2：川崎必须争取净胜，压上可能给柏反击空间；先失球的一方追分会增加3球以上路径。但总比分领先也允许柏降速，不能机械加球；无可用矩阵，未赋予概率。',
 'total_reason':'The Odds当次联赛目录/赔率诊断未返回该杯赛，BSD无目标赛事，5Dollar参数请求400；无机构、实际盘线和真实报价时间，大小球观望。不能将2-1总和换成大2.5推荐。'},
 nonmarket_evidence_classes=['prior verified league opportunity generation and results','verified Cup first-leg process','confirmed lineup changes','two-leg aggregate incentives'],
 main_reason='柏在两次已核验交锋中持续创造更多射门和射正，本场回到主场；川崎存在进球与追分路径，研究首选2-1。',
 counter='柏总比分领先，平局即可晋级；双方合计更换10名首发、无近期同源xG和实盘，1-1及反向1-2不可忽视。',
 source_commit='7a18cee715acb0633904af434b3f743d870c0951')
comp=save(payload,dict(f,cutoff_at=now()),stage='prematch',track='comprehensive');record=verify(read(comp['path']));assert record['selection_audit']['top3_ready'] is False
shell=dict(match_id='jcup-analysis:20261115-kashiwa',kickoff_at=f['kickoff_at'],cutoff_at=now())
top=save(dict(top3=[],population=[f['match_id']],reason='Only one researched match; unavailable active pair and blocked QF candidates fail current TOP3 eligibility. Do not fill with already-started Cup fixtures.',comprehensive_reference=comp,formal_kpi_eligible=False),shell,stage='prematch',track='top3-selection')
plan=save(dict(population=[f['match_id']],comprehensive_reference=comp,current_test_reference=active['freeze_receipt'],candidate_attempt=attempt,top3_reference=top,status='PENDING_NOT_STARTED',score_basis='regulation_90',primary='2-1',wdl='主胜',total_direction='观望',total_line=None,default_evaluation='first prematch per track; subsequent revisions separate; no alternative score credit',formal_kpi_eligible=False),dict(shell,cutoff_at=now()),stage='prematch',track='forward-validation-plan')
lines=['# 柏太阳神—川崎前锋赛前研究｜2026年11月15日16:00（北京时间）','','HELLO BOSS','','**唯一研究第一比分：柏太阳神2–1川崎前锋；胜平负：主胜（低信心）；实际盘口大小球：观望。** 只结算90分钟含补时，不把晋级、加时或点球结果当作本场胜平负。','',
 '日联杯八强次回合，柏主场三协弗隆提尔柏体育场。日职官方15:39抓取确认双方首发；首回合川崎1–2柏，总比分柏2–1领先，柏本场打平即可晋级。','',
 '主要依据：11月7日联赛柏主场2–1川崎，射门22–9、射正9–3；11月11日杯赛首回合柏客场2–1逆转，射门23–9、射正6–1。两场过程都支持柏能够创造机会，不能仅凭总比分领先就机械选择低比分。首回合川崎47分钟领先，柏84、87分钟逆转，显示领先后的比赛状态会明显影响后段。','',
 '此前保存并重新核验的五场联赛：柏3胜1平1负，进10失6；川崎3胜2负，进11失10，五场均进球且均失球。该缓存采集于11月11日，不能冒充本次重新抓取的完整近况；本次刷新另存原文。日职联数据只进入人工背景，不套用日职联模型代替日联杯。','',
 '首发相比首回合：柏保留5人、更换6人；川崎保留7人、更换4人。柏由藤尾翔太、山内日向汰首发，久保藤次郎仍在；川崎德利基·拉塞尔达、马尔西尼奥、伊藤达哉在列。轮换数量是已核实事实，尚无球员增减球参数，不能声称这一阵容必然更强。','',
 '|候选|支持与反证|','|---|---|']
for x in payload['selection_evidence']['candidate_comparison']:lines.append('|'+x['score']+'|'+x['support']+' 反证：'+x['counterevidence']+'|')
lines+=['','两队0与1球、三球以上路径已另存结构化比较。2–1是独立人工选择，没有校准后的命中概率，也不把其他候选比分补算成命中。','',
 '模型实测：活动Current/Test没有日联杯路由，已冻结拒绝状态。两份次回合研究工件成功校验加载（各12场历史，训练至2025年9月7日），但BetExplorer返回通用首页，旧入口所需的首回合证据记录未取得，因此本场没有生成数值矩阵。官方首回合赛果是真实可用的人工背景，不能据此伪造另一来源的模型输入。工件、注册表和数值权重均未改。','',
 '盘口：本次没有合格的本场报价、实际盘线和来源报价时间；不报大/小2.5，也不推测水位走势。最新同源xG、独立伤停/停赛公告、完整全赛事负荷及杯赛近五场仍缺。','',
 'TOP3赛事榜：本轮没有达到现有准入条件的记录，保留空榜；以上为单场研究参考。其余已开赛的日联杯比赛不补进赛前榜。','',
 '完整首发：','',
 '柏：'+ '、'.join(p['name'] for p in current_xi['homeTeam']['players'])+'。','',
 '川崎：'+ '、'.join(p['name'] for p in current_xi['awayTeam']['players'])+'。','',
 '官方来源：[本场](https://www.jleague.jp/match/leaguecup/2026/111504/)；[首回合](https://www.jleague.jp/match/leaguecup/2026/111104/)。','',
 '综合冻结：`'+comp['freeze_id']+'`，北京时间 '+comp['recorded_at']+'；后续只追加，不覆盖。']
report='\n'.join(lines)+'\n';(D/'柏太阳神赛前分析.md').write_text(report)
rr=save(dict(markdown=report,comprehensive_receipt=comp,top3_receipt=top,forward_plan_receipt=plan,evidence_sha256={str(p):sha(p) for p in [D/'verified-context.json',K/'raw/official.bin',K/'raw/first_leg.bin']},model_promotion=False),dict(shell,cutoff_at=now()),stage='prematch',track='analysis-report')
receipts=[active['freeze_receipt'],read(D/'active-attempt.json')['freeze_receipt'],attempt['scope_freeze'],comp,top,plan,rr]
for ref in receipts:
 v=verify(read(ref['path']));assert v['record_sha256']==ref['sha256'] and aware(v['recorded_at'])<aware(v['fixture']['kickoff_at'])
assert sha('/workspace/WCPP/runtime/active-model.json')==active['payload']['active_registry_sha256']
write(D/'delivery.json',dict(comprehensive_receipt=comp,report_receipt=rr,top3_receipt=top,forward_plan_receipt=plan,all_receipts=receipts,all_before_kickoff=True,active_models_available=False,candidate_models_issued=False,manual_prediction_issued=True,active_registry_changed=False,environment_published=False))
print(json.dumps(dict(primary=payload['primary'],wdl=payload['wdl'],total=payload['total_direction'],freeze=comp,report_freeze=rr),ensure_ascii=False))
