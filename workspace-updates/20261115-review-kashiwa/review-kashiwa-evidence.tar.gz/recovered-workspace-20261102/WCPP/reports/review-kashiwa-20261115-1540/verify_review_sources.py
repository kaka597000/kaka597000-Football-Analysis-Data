"""Verify retained bytes against the population locked before result collection."""
import hashlib,json,re,sys
from pathlib import Path
from datetime import datetime,timezone
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from research.analysis_freeze import verify,aware,digest
from research_program.nations_phase import verify_period_scores,classify_source_phase
from research_program.future_validation import quote_audit
R=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(name,x):
 with (R/name).open('x') as h:json.dump(x,h,ensure_ascii=False,indent=2,allow_nan=False)
lock=read(R/'review-scope-lock.json');ledger=read(R/'results/source-ledger.json')['requests']
observed=datetime.now(timezone.utc).isoformat();meta={m['id']:m for m in ledger}
for m in ledger:
 assert m['http_status']==200 and sha(m['file'])==m['sha256']
 if m.get('request_start'):
  assert aware(lock['created_at'])<aware(m['request_start'])<=aware(m['response_read_complete'])<=aware(observed)
boards={}
for code in ['brazil','nations']:
 boards.update({str(e['id']):e for e in read(R/f'results/raw/espn-scoreboard-{code}.json')['events']})
results=[];process=[];issues=[];quotes=[];second=[]
for item in lock['fixtures']:
 f=item['fixture'];mid=f['match_id'];eid=f['source_event_id'];m=meta['espn-summary-'+eid]
 raw=read(m['file']);head=raw['header'];c=head['competitions'][0];b=boards[eid]['competitions'][0]
 assert str(head['id'])==eid and head['league']['slug']==f['competition'] and len(head['competitions'])==1
 assert str(c['id'])==eid and aware(c['date'])==aware(f['kickoff_at']) and c['neutralSite']==f['neutral']
 assert c['status']['type']['completed'] and b['status']['type']['completed']
 if f['competition']=='uefa.nations':
  phase=classify_source_phase(boards[eid]);assert phase['complete'] and phase['stage']==f['stage'] and phase['league_level']==f['league_level']
 sides={t['homeAway']:t for t in c['competitors']};assert set(sides)=={'home','away'}
 periods={};scores={};names={};team_side={}
 for side,t in sides.items():
  assert 'espn:'+str(t['team']['id'])==f[side]
  periods[side]=verify_period_scores(t,c['status']);assert periods[side] and periods[side]['extra_time']==0 and periods[side]['shootout'] is None
  scores[side]=periods[side]['regulation'];names[side]=t['team']['displayName'];team_side[str(t['team']['id'])]=side
  bc=next(t for t in b['competitors'] if t['homeAway']==side)
  assert str(bc['team']['id'])==str(t['team']['id']) and int(bc['score'])==scores[side]
 result=dict(match_id=mid,status='completed',event_status='FT',score_basis='regulation_90',home_goals=scores['home'],away_goals=scores['away'],observed_at=observed,observation_basis='root verified retained response bytes at this time; not HTTP retrieval time',http_read_complete=m.get('response_read_complete'),source_url=m['url'],source_sha256=m['sha256'],source_path=m['file'],regulation_evidence=periods,**{k:f[k] for k in ['competition','cohort','stage','home','away','kickoff_at']})
 results.append(result)
 roster={}
 for t in raw.get('rosters',[]):
  tid=str(t['team']['id']);assert tid in team_side
  for p in t.get('roster',[]):
   aid=str(p['athlete']['id']);assert aid not in roster or roster[aid]==tid;roster[aid]=tid
 stats={team_side[str(t['team']['id'])]:{v['name']:v.get('displayValue') for v in t.get('statistics',[])} for t in raw.get('boxscore',{}).get('teams',[])}
 goals=[];cards=[];before=[0,0];seen=set()
 for e in raw.get('keyEvents',[]):
  assert e['id'] not in seen;seen.add(e['id']);kind=e.get('type',{}).get('type','')
  if e.get('scoringPlay'):
   assert not e.get('shootout') and e['period']['number'] in [1,2]
   found=re.findall(re.escape(names['home'].replace('Bosnia-Herzegovina','Bosnia and Herzegovina'))+r' (\d+), '+re.escape(names['away'].replace('Bosnia-Herzegovina','Bosnia and Herzegovina'))+r' (\d+)',e.get('text',''));assert len(found)==1,(eid,e)
   after=list(map(int,found[0]));delta=[b-a for a,b in zip(before,after)];assert delta in [[1,0],[0,1]]
   side=['home','away'][delta.index(1)];tid=f[side].split(':')[-1];assert str(e['team']['id'])==tid
   aid=str(e['participants'][0]['athlete']['id']);own=kind=='own-goal';actor=('away' if side=='home' else 'home') if own else side
   assert roster.get(aid)==f[actor].split(':')[-1],(eid,'actor team',e)
   ds=[d for d in c.get('details',[]) if d.get('scoringPlay') and d['clock']['value']==e['clock']['value'] and str(d.get('team',{}).get('id'))==tid]
   assert len(ds)==1 and ds[0]['ownGoal']==own
   pen=kind=='penalty---scored';assert ds[0]['penaltyKick']==pen
   goals.append(dict(event_id=e['id'],minute=e['clock']['displayValue'],before=before,after=after,beneficiary_side=side,actor_side=actor,athlete=e['participants'][0]['athlete']['displayName'],own_goal=own,penalty_goal=pen,text=e.get('text')));before=after
  if kind in ['red-card','second-yellow-card','yellow-red-card']:
   cards.append(dict(minute=e['clock']['displayValue'],team_side=team_side[str(e['team']['id'])],score_at_card=before.copy(),type=kind,text=e.get('text')))
 assert before==[scores['home'],scores['away']]
 for side in ['home','away']:
  pen=sum(g['penalty_goal'] and g['beneficiary_side']==side for g in goals)
  if stats[side].get('penaltyKickGoals') is not None and int(stats[side]['penaltyKickGoals'])!=pen:issues.append(dict(match_id=mid,type='BOX_PENALTY_CONFLICT',side=side,box=stats[side]['penaltyKickGoals'],events=pen,used='events'))
  other='away' if side=='home' else 'home';sot=stats[side].get('shotsOnTarget');saves=stats[other].get('saves');own=sum(g['own_goal'] and g['beneficiary_side']==side for g in goals)
  if sot is not None and saves is not None and float(saves)+scores[side]-own>float(sot):issues.append(dict(match_id=mid,type='SAVES_SOT_CONFLICT',side=side,sot=sot,opponent_saves=saves,interpretation='No keeper ability inference'))
  assert sum(c['team_side']==side for c in cards)==int(stats[side]['redCards'])
 def xg_fields(x,path=''):
  found=[]
  if isinstance(x,dict):
   for k,v in x.items():
    if re.search(r'expected.?goals|^xg$|^xga$',k,re.I) or k=='name' and re.search(r'expected.?goals|^xg$|^xga$',str(v),re.I):found.append(dict(path=path+'/'+k,value=v))
    found+=xg_fields(v,path+'/'+k)
  elif isinstance(x,list):
   for j,v in enumerate(x):found+=xg_fields(v,path+'/'+str(j))
  return found
 process.append(dict(match_id=mid,teams=names,stats=stats,goals=goals,red_cards=cards,xg_fields=xg_fields(raw),source_sha256=m['sha256'],own_goal_validation='ESPN score deltas + roster membership + header ownGoal flags; FotMob-only adapter not given fake input'))
 # Audit each distinct original comprehensive edition against its retained quote bytes.
 refs={x['sha256']:x for x in [item['tracks']['comprehensive_receipt']['first']]+item['tracks']['comprehensive_receipt']['revisions']}
 for ref in refs.values():
  rec=verify(read(ref['path']));assert rec['record_sha256']==ref['sha256'] and aware(rec['recorded_at'])<aware(f['kickoff_at'])
  p=rec['payload'];q=p.get('actual_quote')
  if not q:
   assert p.get('total_direction') not in ['大','小'];quotes.append(dict(match_id=mid,freeze_id=rec['freeze_id'],eligible=False,reason='NO_QUOTE_AND_NO_SELECTION'));continue
  candidates=[Path('/workspace/WCPP/reports/nations-prematch-20261114-2051/market/odds.json'),Path('/workspace/WCPP/reports/remaining-nations-brazil-20261115-0240/market-nations/odds.json'),Path('/workspace/WCPP/reports/remaining-nations-brazil-20261115-0240/market-brazil/odds.json')]
  source=next(path for path in candidates if path.is_file() and sha(path)==q['source_sha256'])
  es=[e for e in read(source) if aware(e['commence_time'])==aware(f['kickoff_at']) and any(b['key']==q['bookmaker'] and any(t['key']=='totals' and len(t['outcomes'])==2 and all(o['point']==q['line'] for o in t['outcomes']) for t in b['markets']) for b in e['bookmakers'])]
  # The existing validated bridge binds provider ID to exact ESPN IDs. Read the frozen observation.
  selected=rec['fixture'].get('market_attachment',{}).get('selected',{});channel=read(selected['channel_path']);snap=next(s for s in channel['snapshots'] if s['snapshot_sha256']==selected['snapshot_sha256'])
  assert snap['snapshot_sha256']==digest({k:v for k,v in snap.items() if k!='snapshot_sha256'})
  assert snap['target']['home_id']==f['home'] and snap['target']['away_id']==f['away'] and snap['target']['match_id']==mid
  obs=next(o for o in snap['observations'] if digest(o)==selected['observation_sha256'])
  provider_id=obs.get('provider_match_id')
  if provider_id:es=[e for e in es if e['id']==provider_id]
  # Exact names from ESPN or the original bridge alias mapping, never scores, resolve the event.
  alias={'Atlético-MG':'Atletico Mineiro','Vasco da Gama':'Vasco da Gama','Bosnia-Herzegovina':'Bosnia & Herzegovina'}
  es=[e for e in es if e['home_team']==alias.get(names['home'],names['home']) and e['away_team']==alias.get(names['away'],names['away'])]
  assert len(es)==1,(mid,source,[e['id'] for e in es]);event=es[0]
  book=next(b for b in event['bookmakers'] if b['key']==q['bookmaker']);total=next(t for t in book['markets'] if t['key']=='totals');out={o['name']:o for o in total['outcomes']}
  assert set(out)=={'Over','Under'} and all(o['point']==q['line'] for o in out.values()) and out['Over']['price']==q['over_odds'] and out['Under']['price']==q['under_odds'] and total['last_update']==q['quoted_at']
  assert aware(q['quoted_at'])<=aware(q['query_time'])<=aware(rec['fixture']['cutoff_at'])<aware(rec['recorded_at'])<aware(f['kickoff_at'])
  audit=quote_audit(dict(rec['fixture'],total_quote=q));assert audit['eligible'],(mid,audit)
  quotes.append(dict(match_id=mid,freeze_id=rec['freeze_id'],eligible=True,provider_event_id=event['id'],quote_audit=audit,source_path=str(source),source_sha256=sha(source),line=q['line'],original_unchanged=True))
 # Independent result feed, joined by the already frozen provider ID rather than hindsight score.
 ids={q['provider_event_id'] for q in quotes if q['match_id']==mid and q['eligible']}
 feeds=read(R/('results/raw/odds-nations.json' if f['competition']=='uefa.nations' else 'results/raw/odds-brazil.json'))
 matches=[e for e in feeds if e['id'] in ids and e['completed']]
 if len(matches)==1:
  e=matches[0];z={s['name']:int(s['score']) for s in e['scores']};assert z[e['home_team']]==scores['home'] and z[e['away_team']]==scores['away']
  dt=(aware(e['commence_time'])-aware(f['kickoff_at'])).total_seconds()
  second.append(dict(match_id=mid,provider_event_id=e['id'],score_agrees=True,kickoff_difference_seconds=dt,identity_basis='prematch-frozen provider event ID; no result-based join',source_sha256=sha(R/('results/raw/odds-nations.json' if f['competition']=='uefa.nations' else 'results/raw/odds-brazil.json'))))
 else:second.append(dict(match_id=mid,score_agrees=None,reason='No original qualified provider event mapping'))
write('verified-results.json',results);write('verified-process.json',process);write('quote-review-audit.json',quotes);write('second-source-verification.json',second);write('source-conflicts.json',issues)
write('source-verification.json',dict(status='PASS',verified_at=observed,population=len(results),raw_responses_verified=len(ledger),regulation_90_verified=len(results),goal_events_reconciled=sum(len(x['goals']) for x in process),xg_games=sum(bool(x['xg_fields']) for x in process),missing_http_timestamps=sum(m.get('request_start') is None for m in ledger),source_conflicts=issues,second_source=second))
print(json.dumps(dict(results=len(results),goals=sum(len(x['goals']) for x in process),conflicts=len(issues),quotes=len(quotes),independent_scores=sum(x['score_agrees'] is True for x in second))))
