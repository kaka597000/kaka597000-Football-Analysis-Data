"""Settle every locked track and edition without hindsight selection."""
import json,sys,math,hashlib
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import numpy as np
sys.path[:0]=['/workspace/Football-Analysis/runtime','/workspace/Football-Analysis/runtime/v5','/workspace/Football-Analysis/runtime/optimization']
from research.analysis_freeze import verify,aware
from research_program.future_validation import check_matrix
from v5.paired_review import review
from v2.model import total_settlement
from optimization.evaluate import settle_ou
R=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())
def write(name,x):
 with (R/name).open('x') as h:json.dump(x,h,ensure_ascii=False,indent=2,allow_nan=False)
lock=read(R/'review-scope-lock.json');results=read(R/'verified-results.json');res={r['match_id']:r for r in results}
def record(ref):
 r=verify(read(ref['path']));assert r['record_sha256']==ref['sha256'];return r
def actual(mid):
 r=res[mid];h,a=r['home_goals'],r['away_goals'];return f'{h}-{a}',('主胜' if h>a else '客胜' if h<a else '平局')
def settle(mid,line,direction):
 side={'大':'over','小':'under'}.get(direction)
 if side is None:return None
 r=res[mid];m=np.zeros((51,51));m[r['home_goals'],r['away_goals']]=1
 out=next(k for k,v in total_settlement(m,line,side).items() if v==1.)
 assert {'win':'FULL_WIN','half_win':'HALF_WIN','push':'PUSH','half_loss':'HALF_LOSS','loss':'FULL_LOSS'}[out]==settle_ou(r['home_goals']+r['away_goals'],line,side)
 return out
def wilson(h,n):
 if not n:return None
 z=1.959963984540054;p=h/n;den=1+z*z/n;v=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den;c=(p+z*z/(2*n))/den;return [c-v,c+v]
def counts(rows):
 ph=[r['primary_hit'] for r in rows if r['primary_hit'] is not None];wh=[r['wdl_hit'] for r in rows if r['wdl_hit'] is not None];t=Counter(r['total_settlement'] for r in rows if r['total_settlement'] is not None);n=sum(t.values());non=n-t['push'];pop=len(rows)
 return dict(population=pop,settled=pop,pending=0,primary_n=len(ph),primary_hits=sum(ph),primary_accuracy=sum(ph)/len(ph) if ph else None,primary_coverage=len(ph)/pop if pop else 0,primary_wilson_95=wilson(sum(ph),len(ph)),wdl_n=len(wh),wdl_hits=sum(wh),wdl_accuracy=sum(wh)/len(wh) if wh else None,wdl_coverage=len(wh)/pop if pop else 0,wdl_wilson_95=wilson(sum(wh),len(wh)),total_n=n,total_coverage=n/pop if pop else 0,total_non_push_n=non,total_strict_full_win_rate=t['win']/non if non else None,total_settlements={k:t[k] for k in ['win','half_win','push','half_loss','loss']})
def comp_row(ref):
 r=record(ref);p=r['payload'];mid=r['match_id'];score,wdl=actual(mid)
 return dict(match_id=mid,name=p.get('name',mid),actual=score,primary=p['primary'],primary_hit=p['primary']==score if p['primary'] is not None else None,wdl=p['wdl'],wdl_hit=p['wdl']==wdl if p['wdl'] in ['主胜','平局','客胜'] else None,total_line=p.get('total_line'),total_direction=p['total_direction'],total_settlement=settle(mid,p.get('total_line'),p['total_direction']),freeze_id=r['freeze_id'],record_sha256=r['record_sha256'],recorded_at=r['recorded_at'])
def pair(ref,candidate=False):
 r=record(ref);p=r['payload'];a,b=('current','test') if candidate else ('current_model','test_model')
 return dict(match_id=r['match_id'],current_model=p[a],test_model=p[b])
first=[];active=[];candidate=[];same=[]
for i in lock['fixtures']:
 c=record(i['tracks']['comprehensive_receipt']['first']);assert c['evaluation_slot']=='FIRST_PREMATCH'
 first.append(comp_row(i['tracks']['comprehensive_receipt']['first']));active.append(pair(i['tracks']['active_receipt']['first']))
 if 'candidate_receipt' in i['tracks']:
  ref=i['tracks']['candidate_receipt']['first'];candidate.append(pair(ref,True));p=record(ref)['payload']
  same.append(dict(match_id=c['match_id'],revisions=[dict(freeze_id=r['freeze_id'],matrix_identity={role:record(r)['payload'][role]['matrix_hash']==p[role]['matrix_hash'] for role in ['current','test']}) for r in i['tracks']['candidate_receipt']['revisions']]))
ar=review(active,results);cr=review(candidate,results)
batches=[]
for b in lock['batches']:
 rows=[comp_row(x['comprehensive']) for x in b['edition_receipts']]
 tops=[]
 for label in ['first_top3','published_top3']:
  ref=b[label];tr=record(ref);items=[]
  for t in tr['payload']['top3']:
   row=comp_row(t['comprehensive_reference'])
   for k in ['primary','wdl','total_line','total_direction']:assert row[k]==t[k]
   items.append(dict(row,rank=t['rank']))
  tops.append(dict(edition=label,freeze_id=tr['freeze_id'],summary=counts(items),rows=items,ranking_changed=False))
 batches.append(dict(batch=b['batch'],summary=counts(rows),rows=rows,top3=tops,active_models=review([pair(x['active']) for x in b['edition_receipts']],results),candidate_models=review([pair(x['candidate'],True) for x in b['edition_receipts'] if x['candidate']],results)))
# Net effect of manual selection against the exact matrix referenced by that first selection.
net={};prob={}
for role in ['current','test']:
 rows=[];diag=[]
 for i in lock['fixtures']:
  c=record(i['tracks']['comprehensive_receipt']['first']);p=c['payload'];mid=c['match_id']
  cand=p.get('candidate_reference');ref=cand or p['current_test_reference'];rp=record(ref)['payload'];f=rp[role if cand else role+'_model']
  if f.get('matrix') is None:continue
  m=check_matrix(f);score,wdl=actual(mid);h=res[mid]['home_goals'];a=res[mid]['away_goals'];n=np.indices(m.shape);t=n[0]+n[1]
  rows.append(dict(match_id=mid,competition=i['fixture']['competition'],version=f['version'],comprehensive=p['primary'],candidate=f['primary'],actual=score,comprehensive_hit=p['primary']==score,candidate_hit=f['primary']==score))
  w={'主胜':float(m[n[0]>n[1]].sum()),'平局':float(m[n[0]==n[1]].sum()),'客胜':float(m[n[0]<n[1]].sum())}
  diag.append(dict(match_id=mid,version=f['version'],competition=i['fixture']['competition'],actual=[h,a],mean=[float((m*n[s]).sum()) for s in [0,1]],p_zero=[float(m[0,:].sum()),float(m[:,0].sum())],observed_zero=[h==0,a==0],p_total_ge4=float(m[t>=4].sum()),observed_total_ge4=h+a>=4,actual_score_probability=float(m[h,a]),score_log_loss=float(-math.log(max(m[h,a],1e-15))),wdl_brier_sum3=sum((v-int(k==wdl))**2 for k,v in w.items()),wdl_log_loss=float(-math.log(max(w[wdl],1e-15)))))
 def net_summary(rr):
  dif=np.array([int(x['comprehensive_hit'])-int(x['candidate_hit']) for x in rr]);rng=np.random.default_rng(20261115);boot=rng.choice(dif,size=(20000,len(dif)),replace=True).mean(axis=1);right=int((dif>0).sum());wrong=int((dif<0).sum());n=right+wrong
  return dict(paired_n=len(rr),changed_right=right,changed_wrong=wrong,net_hits=int(dif.sum()),rate_difference_bootstrap_95=np.quantile(boot,[.025,.975]).tolist(),exact_discordant_sign_test_p=min(1.,2*sum(math.comb(n,k) for k in range(min(right,wrong)+1))/2**n) if n else 1.,not_promotion_evidence=True)
 net[role]=dict(rows=rows,descriptive_mixed_versions=net_summary(rows),by_competition={c:net_summary([r for r in rows if r['competition']==c]) for c in sorted({r['competition'] for r in rows})})
 def ps(ds):
  return dict(n=len(ds),**{k:np.mean([d[k] for d in ds],axis=0).tolist() for k in ['actual','mean','p_zero','observed_zero','p_total_ge4','observed_total_ge4','score_log_loss','wdl_log_loss','wdl_brier_sum3']})
 prob[role]=dict(rows=diag,by_version={v:ps([d for d in diag if d['version']==v]) for v in sorted({d['version'] for d in diag})},no_post_result_fitting=True)
# Append prior 18 first-candidate records, preserving each grade/version and all IDs.
O=Path('/workspace/WCPP/reports/nations-review-20261114-1322');A=Path('/workspace/WCPP/reports/nations-review-20261113-0842')
old_results=read(O/'verified-results.json')+read(A/'verified-results.json');old_pairs=[]
for i in read(O/'population-lock.json')['population']:old_pairs.append(pair(i['candidate_first'],True))
for i in read(A/'frozen-accounts.json')['fixtures']:
 ref=i['tracks']['nations-paired-candidates']['first'];r=verify(read(ref['path']));assert r['record_sha256']==ref['record_sha256']
 old_pairs.append(dict(match_id=i['match_id'],current_model=r['payload']['current'],test_model=r['payload']['test']))
for r in old_results:assert hashlib.sha256(Path(r['source_path']).read_bytes()).hexdigest()==r['source_sha256']
assert len({r['match_id'] for r in old_results+results})==28
cumulative=review(old_pairs+candidate,old_results+[r for r in results if r['competition']=='uefa.nations'])
m=dict(schema='WCPP-REVIEW-20261115-1',calculated_at=datetime.now(timezone.utc).isoformat(),population=10,completed=10,pending=0,comprehensive_first=dict(summary=counts(first),rows=first),active_first=ar,candidate_first=cr,batches=batches,manual_net=net,probability_quality=prob,candidate_matrix_revision_identity=same,cumulative_nations_first=cumulative,formal_kpi_eligible=False,weights_changed=False)
write('metrics.json',m)
print(json.dumps(dict(first=counts(first),batches=[dict(batch=b['batch'],summary=b['summary'],top3=[x['summary'] for x in b['top3']]) for b in batches],net={k:v['descriptive_mixed_versions'] for k,v in net.items()}),ensure_ascii=False))
