"""Write, independently reconcile and freeze the complete retrospective."""
import json,csv,sys,hashlib,subprocess
from pathlib import Path
from datetime import datetime,timezone
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from research.analysis_freeze import save,verify,aware
R=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=lambda:datetime.now(timezone.utc).isoformat()
def write(name,x):
 with (R/name).open('x') as h:json.dump(x,h,ensure_ascii=False,indent=2,allow_nan=False)
m=read(R/'metrics.json');lock=read(R/'review-scope-lock.json');results={r['match_id']:r for r in read(R/'verified-results.json')};process={r['match_id']:r for r in read(R/'verified-process.json')}
assert len(results)==len(m['comprehensive_first']['rows'])==10
for row in m['comprehensive_first']['rows']:
 actual=results[row['match_id']];assert row['actual']==f"{actual['home_goals']}-{actual['away_goals']}"
 assert row['primary_hit']==(row['primary']==row['actual'])
assert m['comprehensive_first']['summary']['primary_hits']==1 and m['comprehensive_first']['summary']['wdl_hits']==6
assert m['batches'][1]['summary']['primary_hits']==1 and m['batches'][1]['summary']['wdl_hits']==4
assert m['cumulative_nations_first']['scope']==26
def refs(x):
 if isinstance(x,dict):
  if x.get('freeze_id') and x.get('path') and x.get('sha256'):yield x
  for v in x.values():yield from refs(v)
 elif isinstance(x,list):
  for v in x:yield from refs(v)
oldrefs={r['sha256']:r for r in refs(lock)}
for ref in oldrefs.values():
 v=verify(read(ref['path']));assert v['record_sha256']==ref['sha256'] and aware(v['recorded_at'])<aware(v['fixture']['kickoff_at'])
registry_sha=sha('/workspace/WCPP/runtime/active-model.json');assert registry_sha=='923e34fc44cda33fe965498a24a2435abb37a01a80c539108d8ec20d490bf013'
assert not subprocess.check_output(['git','status','--porcelain'],cwd='/workspace/Football-Analysis').strip()
decision=dict(decision=['KEEP_CURRENT_TEST','SUPPLEMENT_DATA','REGISTER_INDEPENDENT_DIAGNOSTICS'],batch_unique=10,cumulative_nations_first=26,primary_kpi='unique first comprehensive score hit',manual_first=m['comprehensive_first']['summary'],manual_net=m['manual_net'],reason='Only one exact hit in ten. Manual selection gained one against the referenced Current candidate and none against Test; uncertainty includes no gain. No evidence supports numerical parameter change or promotion.',findings=['Portugal 1-4: penalty at 43 then three further Denmark goals; offensive shot volume did not justify a narrow home-win path.','Sweden 3-2: early goal plus two first-half penalties; cannot treat five goals as a stable new scoring mean.','Austria 1-0 despite 8-7 shots on target: shots do not measure chance quality and conversion.','Kosovo 0-0 and Mirassol 0-0: preserve zero-goal cases; late red card in Mirassol is not an explanation for earlier low conversion.','Cup verified official first leg cannot enter a source-specific BetExplorer-only schema; loading and actual prediction availability are separate.'],next_checks=['At the next complete frozen match batch, include the full population and versions; settle original actual-line totals separately.','Any proposed score selection/zero-goal/tail adjustment requires a predeclared independent recipe and untouched future holdout; this reviewed batch is diagnostic development data.','Implement any Cup official-evidence support in a separately versioned adapter with identity/time/integrity tests, retaining all hash-pinned legacy artifacts; no forecast was synthesized in this delivery.'],model_parameters_changed=False,active_registry_changed=False,model_promoted=False)
write('review-decision.json',decision)
cn={None:'观望','win':'全赢','half_win':'半赢','push':'走盘','half_loss':'半输','loss':'全输'}
lines=['# 完整复盘｜北京时间2026年11月15日','','HELLO BOSS','','**按每场首次赛前综合冻结结算：10场，唯一第一比分1/10（10%），胜平负6/10（60%）；大小球6场有明确方向，2全赢、1走盘、3全输，4场观望。** 剔除走盘后的全赢率为2/5（40%）。比分与胜平负覆盖10/10，大小球覆盖6/10，全部完赛，无待结算。','',
 '这不是有效提升：综合比分相对所引用Current统计首选净增1场，相对Test净增0场。10场描述性配对净增率区间分别为0至30个百分点、0至0；离散差异检验均p=1，不能据此宣称改分有效。Primary命中率95% Wilson区间为1.8%–40.4%，样本很小；没有达到项目目标。','',
 '范围在读取赛果前冻结：此前欧国联8场，加上凌晨新增巴甲2场，共10个独立比赛。凌晨“剩余7场”包含5场欧国联修订及2场巴甲，是另一个发布版本，不重复算成15场。所有比分均为90分钟含补时。','',
 '|比赛|首版唯一比分|实际比分|比分|首版胜平负|方向|首版实际大小球|结算|','|---|---|---|---|---|---|---|---|']
for x in m['comprehensive_first']['rows']:
 total='观望' if x['total_direction'] not in ['大','小'] else f"{x['total_direction']}{x['total_line']:g}"
 lines.append(f"|{x['name']}|{x['primary']}|{x['actual']}|{'中' if x['primary_hit'] else '失'}|{x['wdl']}|{'中' if x['wdl_hit'] else '失'}|{total}|{cn[x['total_settlement']]}|")
lines+=['','**凌晨剩余7场版本**：比分1/7（14.3%），胜平负4/7（57.1%）；大小球4场，2全赢、2全输，3场观望。北爱尔兰1–0是唯一命中比分。该版从葡萄牙小3.25改观望3、北爱观望1.75改小2、瑞典无合格线改小3，必须按新版本单列，不能用修订覆盖首版失误。','',
 '**原TOP3赛事名单分别复盘**：','',
 '|发布批次|原排序（不重排）|第一比分|胜平负|大小球|','|---|---|---|---|---|',
 '|欧国联8场版|科索沃、格鲁吉亚、葡萄牙|0/3|1/3|1全赢、1走盘、1全输|',
 '|凌晨剩余7场版|葡萄牙、北爱尔兰、瑞典|1/3|2/3|1全赢、1全输、1观望|','',
 '这里TOP3指三场赛事，各自只有一个比分；没有用备选比分补算命中。','',
 '逐场诊断：','',
 '- 科索沃0–0以色列：射门16–6、射正3–3；科索沃66分钟两黄变红，当时仍0–0。主胜及1–0落空，小2.5命中。机会数量没有形成有效射正优势，红牌是后段状态变化，不能抹掉此前未进球。',
 '- 格鲁吉亚0–2匈牙利：射正1–6，客胜方向成立；73分钟乌龙受益队是匈牙利，85分钟再入一球。0–1少算一球，小2走盘，不能算全赢。乌龙已通过分数变化、球员所属队和原始事件标记三方核验。',
 '- 挪威3–1威尔士：射正6–5，原2–1在88分钟挪威点球后变成3–1；主胜中，小3.5失。尾部必须保留，不能赛后删除点球场次。',
 '- 奥地利1–0爱尔兰：射正8–7，直到78分钟才破门；主胜正确，但2–1及大2.5失。此前“大球较弱、模型分布不支持多数”的反证应被更认真对待；缺少真实xG，不能把高射正数直接变成三球保证。',
 '- 北爱尔兰1–0乌克兰：射正5–2，68分钟制胜；比分和主胜均中。首版大小球观望，凌晨小2全赢，两个版本各归各。',
 '- 葡萄牙1–4丹麦：43分钟点球先失，49、57、75分钟继续失球，补时才追回一球；射正8–6不代表葡萄牙比赛路径更优。2–1和主胜均失；首版小3.25失、临场观望不结算。这是本轮优先排序的主要失败，不能全归因于首个点球。',
 '- 罗马尼亚2–1波兰：射正4–3，主队68、72分钟连续得分；原1–2及客胜均失。客队控球、射门数量优势没有兑现成更好的射正或进球，大小球原为观望。',
 '- 瑞典3–2波黑：5分钟先入球，11分钟和上半场补时两次点球，波黑下半场连追两球；射正7–7。主胜中，1–1及临场小3失。保留早进球和点球对比分路径的作用，但不把单场五球直接改成永久进球率。',
 '- 米拉索尔0–0米内罗竞技：射正2–1，双方终结产量低；原1–1及主胜失，小2.5中。主队红牌发生于90+6，不能据此解释此前整场0–0。',
 '- 沙佩科恩斯0–2瓦斯科：射正2–6，客队36、81分钟进球；客胜中，原1–2多给了主队一球，大小球观望。零球与一球判断仍是主要诊断对象。','',
 '各数值轨独立结算：欧国联活动Current/Test本批8场仍不可用，覆盖0/8；以下欧国联是未晋级候选，不把人工成绩记入模型。巴甲两场是已登记研究模型。','',
 '|轨道与版本|本批比分|本批胜平负|本批实际大小球|','|---|---|---|---|']
for key in ['candidate_first','active_first']:
 for role,z in m[key]['models'].items():
  for version,v in z.get('by_version',{}).items():
   if version=='UNSPECIFIED':continue
   ts=v['total_settlements'];tot='无首版合格盘口方向' if not v['total_eligible'] else f"{ts['win']}全赢/{ts['push']}走/{ts['loss']}全输"
   lines.append(f"|{version}|{v['primary_hits']}/{v['primary_eligible']}|{v['wdl_hits']}/{v['wdl_eligible']}|{tot}|")
lines+=['','欧国联首版候选没有盘口方向，不能把后来附加的盘口反填进去；修订版逐场结算另见metrics.json。巴甲MAIN训练至10月9日、ML融合alpha=0.25，本轮没有更新权重。','',
 '累计欧国联首版候选已有26个不重复完赛样本，按等级与版本分开：','',
 '|等级|Current比分|Test比分|Current胜平负|Test胜平负|','|---|---|---|---|---|']
for grade in ['A','B','C','D']:
 c=m['cumulative_nations_first']['models']['当前模型']['by_version'][f'WCPP-NATIONS-{grade}-CURRENT-0.1'];t=m['cumulative_nations_first']['models']['test模型']['by_version'][f'WCPP-NATIONS-{grade}-TEST-0.1'];n=c['primary_eligible']
 lines.append(f"|{grade}|{c['primary_hits']}/{n}|{t['primary_hits']}/{n}|{c['wdl_hits']}/{n}|{t['wdl_hits']}/{n}|")
lines+=['','这些是首版研究预测的前向结算，不是正式活动模型验收；每级样本仍少，不能混成单一模型准确率，也没有证明稳定的精确比分增益。','',
 '概率质量逐场和逐版本保存在metrics.json：精确比分log-loss、胜平负Brier/log-loss、双方零球概率与实际零球、高比分尾部概率与实际四球以上。只报告原矩阵，没有赛后重新拟合；小样本不能称为已校准。','',
 '本次决定：保持Current/Test、原权重和注册表；补齐数据并登记独立诊断。优先核查零球与一球、领先/落后后比分尾部和人工改分增益。新规则需先固定配方、训练/校准/留出时间边界，再看未参与选择的未来完整批次；本轮数据一旦用于改规则，就属于开发样本。','',
 '来源与限制：10场ESPN scoreboard、summary的身份/主客/90分钟分节比分一致；通过赛前已冻结的The Odds事件ID，10场独立赛果均同分。沙佩科恩斯该来源开球时间比ESPN晚1分钟，保留冲突，用原绑定事件ID核验而未按比分找比赛。9次早期HTTP未留完整起止时间，明确置空；本次root核验时间只表示读取保存原文的时点，不冒充采集完成时间。没有真实xG；3处点球汇总字段为0但逐事件有明确进球，保留原文并采用已交叉核验的事件。','',
 '源码仍为7a18cee715acb0633904af434b3f743d870c0951，PR #38仍开放，远端CI成功；本轮没有源码、模型或环境发布。统计由Python计算，并用两种现有大小球结算实现交叉核对。复盘、调整决定及柏太阳神赛前研究均追加冻结并长期归档。']
report='\n'.join(lines)+'\n';(R/'复盘报告.md').write_text(report)
with (R/'复盘展示.csv').open('x',encoding='utf-8-sig',newline='') as h:
 w=csv.writer(h);w.writerow(['评价版本','比赛','预测比分','实际比分','比分命中','胜平负','方向命中','实际盘线','大小球方向','大小球结算','冻结ID'])
 for label,rows in [('逐场首版',m['comprehensive_first']['rows'])]+[(b['batch'],b['rows']) for b in m['batches']]:
  for x in rows:w.writerow([label,x['name'],x['primary'],x['actual'],x['primary_hit'],x['wdl'],x['wdl_hit'],x['total_line'],x['total_direction'],cn[x['total_settlement']],x['freeze_id']])
validation=dict(status='PASS',verified_at=now(),original_freezes_verified=len(oldrefs),unique_results=10,independent_score_agreement=10,settlement_implementations=2,metrics_sha256=sha(R/'metrics.json'),registry_sha256=registry_sha,source_worktree_clean=True,source_files_changed=False,cup_all_before_kickoff=read(R/'kashiwa-analysis/delivery.json')['all_before_kickoff'])
write('verification.json',validation)
receipts=[]
for item in lock['fixtures']:
 mid=item['fixture']['match_id'];f=dict(item['fixture'],cutoff_at=now());row=next(x for x in m['comprehensive_first']['rows'] if x['match_id']==mid)
 receipts.append(save(dict(result=results[mid],process=process[mid],original_accounts=item,first_comprehensive_review=row,edition_reviews=[x for b in m['batches'] for x in b['rows'] if x['match_id']==mid],decision=decision,metrics_sha256=sha(R/'metrics.json'),report_sha256=sha(R/'复盘报告.md'),prematch_records_modified=False),f,stage='review',track='comprehensive'))
top_receipts=[]
for b in m['batches']:
 shell=dict(match_id='review-top3:'+b['batch'],kickoff_at=min(r['kickoff_at'] for r in results.values()),cutoff_at=now())
 top_receipts.append(save(dict(batch=b['batch'],top3_reviews=b['top3'],ranking_changed=False),shell,stage='review',track='top3-selection'))
shell=dict(match_id='review-batch:20261115-nations-brazil',kickoff_at=min(r['kickoff_at'] for r in results.values()),cutoff_at=now())
rr=save(dict(report_markdown=report,metrics=m,decision=decision,scope_lock=read(R/'scope-lock-receipt.json'),match_review_receipts=receipts,top3_review_receipts=top_receipts,verification=validation,source_commit='7a18cee715acb0633904af434b3f743d870c0951',environment_published=False),shell,stage='review',track='analysis-report')
allrefs=[read(R/'scope-lock-receipt.json')]+receipts+top_receipts+[rr]+read(R/'kashiwa-analysis/delivery.json')['all_receipts']+[read(R/'kashiwa-analysis/freshness-receipt.json')]
for ref in allrefs+list(oldrefs.values()):assert verify(read(ref['path']))['record_sha256']==ref['sha256']
assert sha('/workspace/WCPP/runtime/active-model.json')==registry_sha
write('delivery.json',dict(report_receipt=rr,match_review_receipts=receipts,top3_review_receipts=top_receipts,all_receipts=allrefs,review_population=10,review_settled=10,review_pending=0,kashiwa_delivery=read(R/'kashiwa-analysis/delivery.json'),source_commit='7a18cee715acb0633904af434b3f743d870c0951',source_main_commit='1257fdde7b6746b7ba6d2aa919382214a2cfb589',source_pr='https://github.com/kaka597000/Football-Analysis/pull/38',active_registry_sha256=registry_sha,active_model_changed=False,prematch_records_changed=False,environment_published=False))
print(json.dumps(dict(review_report_receipt=rr,new_receipts=len(allrefs),original_freezes_unchanged=len(oldrefs)),ensure_ascii=False))
