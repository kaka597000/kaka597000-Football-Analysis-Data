# Kashiwa vs Kawasaki data staging

Independent staging only. No database, model, registry, or code was changed.

The official fixture identity and first-leg 90-minute result were checked on 2026-11-15 shortly before scheduled kickoff. Raw HTTP bodies are in `raw/`; `http-ledger.json` records actual request start and response read times, status, hash, and relevance. `fixture.json` and `facts.json` separate confirmed values from missing fields.

The ESPN public endpoint request was a false match ID (2014-15 Portuguese Liga Maritimo-Nacional) and is explicitly excluded. Do not treat it as Kashiwa evidence.

Current official page also contains the announced starting XIs and stadium. First-leg official response was parsed for XI, event timeline, substitutions, score and match statistics. See `lineups.json`, `first-leg-lineups.json`, `first-leg-substitutions.json`, and `first-leg-events.json`.

A BetExplorer request returned HTTP 200 but only its generic homepage, without event rows. This is not the required BetExplorer first-leg list evidence; candidate source gate remains blocked. Club pages were retrieved, but their page bodies did not provide parsable recent match lists. ESPN date-range scoreboard returned HTTP 400, and the accidentally tried summary event ID was verified to be an unrelated 2014-15 Portuguese match. Recent five competition and league fixtures, latest injury/suspension report, xG, and full-schedule rest therefore remain unavailable in this staging.
