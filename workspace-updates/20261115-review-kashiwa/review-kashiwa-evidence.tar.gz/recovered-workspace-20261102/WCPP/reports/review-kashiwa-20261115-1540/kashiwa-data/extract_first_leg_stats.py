"""Offline extraction from the retained official J.League Next.js RSC response."""
import hashlib
import json
import re
import sys
from pathlib import Path

RAW = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).parent / "raw/first_leg.bin"
raw_bytes = RAW.read_bytes()
raw = raw_bytes.decode("utf-8")
chunks = re.findall(r'self\.__next_f\.push\(\[1,("(?:\\.|[^"\\])*")\]\)', raw)
decoded = "".join(json.loads(chunk) for chunk in chunks)

# Each row is emitted as a div key such as "シュート数-info-home".
# The numeric value is in that div's p child (Next RSC children array).
def rows(label, side):
    pat = re.compile(r'","' + re.escape(label) + r'-info-' + side + r'",')
    out = []
    for m in pat.finditer(decoded):
        tail = decoded[m.end():m.end() + 700]
        n = re.search(r'"children":\["\$","p".*?"children":\[(\d+)', tail)
        if n:
            out.append({"value": int(n.group(1)), "decoded_char_offset": m.start(),
                        "context": decoded[m.start():m.start() + 410]})
    return out

def raw_rows(label, side):
    out = []
    key = label + "-info-" + side
    pos = 0
    while True:
        i = raw.find(key, pos)
        if i < 0:
            break
        tail = raw[i + len(key):i + len(key) + 600]
        n = re.search(r'children.{0,8}\[(\d+)', tail)
        if n:
            out.append({"value": int(n.group(1)), "raw_char_offset": i,
                        "context": raw[i:i + 390]})
        pos = i + 1
    return out

result = {
    "source_path": str(RAW),
    "source_sha256": hashlib.sha256(raw_bytes).hexdigest(),
    "decoded_rsc_frames": len(chunks),
    "first_match_summary_marker_char_offset": decoded.find("o-team-comparison--game-average-matchup"),
    "rows": {
        "shots_home_kawasaki": rows("シュート数", "home"),
        "shots_away_kashiwa": rows("シュート数", "away"),
        "shots_on_target_home_kawasaki": rows("枠内シュート数", "home"),
        "shots_on_target_away_kashiwa": rows("枠内シュート数", "away"),
        "possession_home_kawasaki": rows("ボール支配率", "home"),
        "possession_away_kashiwa": rows("ボール支配率", "away"),
    },
    "raw_rows": {
        "shots_home_kawasaki": raw_rows("シュート数", "home"),
        "shots_away_kashiwa": raw_rows("シュート数", "away"),
        "shots_on_target_home_kawasaki": raw_rows("枠内シュート数", "home"),
        "shots_on_target_away_kashiwa": raw_rows("枠内シュート数", "away"),
        "possession_home_kawasaki": raw_rows("ボール支配率", "home"),
        "possession_away_kashiwa": raw_rows("ボール支配率", "away"),
    },
}
# The first full-time match-summary values in the RSC stream are repeated in
# desktop/mobile render trees. The first row per key is the primary occurrence.
selected = {key: value[0]["value"] if value else None
            for key, value in result["rows"].items()}
result["selected_first_occurrence"] = selected
result["selected_first_occurrence_is_expected"] = selected == {
    "shots_home_kawasaki": 9,
    "shots_away_kashiwa": 23,
    "shots_on_target_home_kawasaki": 1,
    "shots_on_target_away_kashiwa": 6,
    "possession_home_kawasaki": 52,
    "possession_away_kashiwa": 48,
}
print(json.dumps(result, ensure_ascii=False, indent=2))
