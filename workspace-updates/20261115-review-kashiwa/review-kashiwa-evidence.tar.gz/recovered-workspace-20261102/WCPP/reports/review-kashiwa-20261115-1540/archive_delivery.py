"""Durable evidence with content-verified reuse of prior archives."""
import json,os,sys,hashlib,tarfile,shutil,subprocess,platform,importlib.metadata
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
R=Path(__file__).resolve().parent;REPO=Path('/workspace/kaka597000-Football-Analysis-Data');DEST=REPO/'workspace-updates/20261115-review-kashiwa'
sys.path.insert(0,'/workspace/Football-Analysis/scripts')
from check_repository import BINDINGS,PATTERNS
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):
 with Path(p).open('x') as h:json.dump(x,h,ensure_ascii=False,indent=2,allow_nan=False)
delivery=read(R/'delivery.json');source=delivery['source_commit'];paths={};catalog={};archive_hashes={}
def add(p):
 p=Path(p)
 if p.is_file() and '__pycache__' not in p.parts:paths[str(p)]=p
def collect(x):
 if isinstance(x,dict):
  for v in x.values():collect(v)
 elif isinstance(x,list):
  for v in x:collect(v)
 elif isinstance(x,str) and x.startswith('/workspace/') and '\n' not in x:
  add(x)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd='/workspace/Football-Analysis').decode().strip()==source
assert not subprocess.check_output(['git','status','--porcelain'],cwd='/workspace/Football-Analysis').strip()
write(R/'inference-environment.json',dict(python=platform.python_version(),packages={n:importlib.metadata.version(n) for n in ['numpy','scipy','lightgbm','scikit-learn']},source_commit=source,source_main_commit=delivery['source_main_commit'],source_branch='analysis/remaining-nations-brazil-20261115',source_changed_this_delivery=False,model_promotion=False))
folders=['20261110-nations-model','20261113-nations-review','20261113-nations-evening','20261114-nations-review','20261114-nations-prematch','20261115-remaining-nations-brazil','20261111-jleague-cup','20261111-jleague-cup-quarterfinals','20261111-jleague-cup-lineups','20261112-jleague-cup-review']
for folder in folders:
 root=REPO/'workspace-updates'/folder;m=read(root/'manifest.json');digest=m.get('archive_sha256')
 if not isinstance(digest,str):continue
 candidates=[root/m['archive']] if m.get('archive') else list(root.glob('*.tar.gz'))
 archive=next(p for p in candidates if sha(p)==digest);name=str(archive.relative_to(REPO));archive_hashes[name]=dict(sha256=digest)
 for row in m.get('members',m.get('files',[])):
  path=row.get('original_path',row.get('path',row.get('workspace_path')));member=row.get('archive_member',row.get('archive_path'))
  if path and member:catalog[(str(Path(path).resolve()),row['sha256'])]=dict(original_path=path,repository_archive=name,archive_member=member,sha256=row['sha256'])
 rp=root/'recovery-map.json'
 if rp.exists():
  old=read(rp);archive_hashes.update(old['reused_archives'])
  for row in old['reused_files']:catalog[(str(Path(row['original_path']).resolve()),row['sha256'])]=row
for p in R.rglob('*'):add(p)
for p in list(paths.values()):
 if p.suffix=='.json':collect(read(p))
# All frozen versions needed to validate hash chains and every referenced first edition.
done=set()
while True:
 pending=[p for p in paths.values() if '/forecasts/issued-analyses/' in str(p) and str(p) not in done]
 if not pending:break
 for p in pending:
  done.add(str(p));collect(read(p))
  for q in p.parent.glob('[0-9]*.json'):add(q)
# Explicit cumulative review sources; do not recursively copy whole historical datasets.
for root in [Path('/workspace/WCPP/reports/nations-review-20261114-1322'),Path('/workspace/WCPP/reports/nations-review-20261113-0842')]:
 for name in ['verified-results.json','population-lock.json','frozen-accounts.json']:
  p=root/name
  if p.exists():add(p);collect(read(p))
 for row in read(root/'verified-results.json'):add(row['source_path'])
for p in list(paths.values()):
 if '/forecasts/issued-analyses/' in str(p):
  collect(read(p))
  for q in p.parent.glob('[0-9]*.json'):add(q)
# Exact model dependencies, including the immutable legacy Cup source files.
cup=Path('/workspace/jcup-qf-expansion-20261111/final-models/candidates.json');add(cup)
for role in ['current','test']:
 p=cup.parent/'leg2'/(role+'-artifact.json');add(p)
 for dep in read(p)['dependencies'].values():assert sha(dep['path'])==dep['sha256'];add(dep['path'])
for name in ['safe_cli.py','safe_evidence.py']:add('/workspace/Football-Analysis/runtime/jleague_cup/'+name)
add('/workspace/Football-Analysis/runtime/v2/model.py')
nidx=Path('/workspace/nations-model-20261110/models/candidates.json');add(nidx)
for route in read(nidx)['routes'].values():
 for ref in route.values():
  p=Path(ref['path']);assert sha(p)==ref['sha256'];add(p);a=read(p)
  for k in ['dataset_path','protocol_path']:add(a[k])
registry=Path('/workspace/WCPP/runtime/active-model.json');add(registry);route=read(registry)['models']['bra.1']
for k in ['artifact_path','test_artifact_path']:add(route[k])
new=[];reused=[];secrets=[os.environ[k].encode() for k in BINDINGS if os.environ.get(k) and len(os.environ[k])>=8]
for original,p in sorted(paths.items()):
 b=p.read_bytes()
 if any(v in b for v in secrets):raise ValueError('configured credential detected in '+p.name)
 try:txt=b.decode('utf-8')
 except UnicodeDecodeError:txt=None
 if txt is not None:
  for name,pattern in PATTERNS.items():
   for match in pattern.finditer(txt):
    if name=='literal_credential' and match.group(1).upper().startswith(('TEST_','SYNTHETIC_','EXAMPLE_')):continue
    raise ValueError('credential pattern '+name+' in '+str(p))
 digest=hashlib.sha256(b).hexdigest();prior=catalog.get((str(p.resolve()),digest))
 if prior and not p.is_relative_to(R):reused.append(dict(prior,original_path=original));continue
 new.append(dict(original_path=original,archive_member=str(Path(original).relative_to('/workspace')),sha256=digest,bytes=len(b)))
DEST.mkdir(exist_ok=False);archive=DEST/'review-kashiwa-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for e in new:t.add(e['original_path'],arcname=e['archive_member'],recursive=False)
used={e['repository_archive']:archive_hashes[e['repository_archive']] for e in reused}
for name,v in used.items():assert sha(REPO/name)==v['sha256']
write(DEST/'recovery-map.json',dict(reused_archives=used,reused_files=reused,absolute_path_aliases={'/workspace/WCPP':'/workspace/recovered-workspace-20261102/WCPP'},no_frozen_path_or_hash_rewrite=True,source_checkout_separate=source,restore_notice='Stage in a fresh directory and verify all bytes/chains first. Preserve original absolute paths and WCPP alias. Never rerun expired fixtures as prematch or overwrite existing user data.'))
sidecars={'复盘报告.md':'复盘报告.md','复盘展示.csv':'复盘展示.csv','metrics.json':'metrics.json','delivery.json':'delivery.json','verification.json':'verification.json','source-verification.json':'source-verification.json','review-decision.json':'review-decision.json','source-ci.json':'source-ci.json','inference-environment.json':'inference-environment.json','kashiwa-analysis/柏太阳神赛前分析.md':'柏太阳神赛前分析.md','kashiwa-analysis/delivery.json':'柏太阳神冻结回执.json','kashiwa-analysis/freshness-verification.json':'柏太阳神数据核验.json'}
for old,newname in sidecars.items():shutil.copy2(R/old,DEST/newname)
shutil.copy2(REPO/'workspace-updates/20261115-remaining-nations-brazil/verify_archive.py',DEST/'verify_archive.py')
(DEST/'README.md').write_text('''# 11月15日复盘及柏太阳神日联杯赛前研究

[完整复盘](复盘报告.md) · [复盘CSV](复盘展示.csv) · [柏太阳神赛前分析](柏太阳神赛前分析.md) · [冻结回执](delivery.json)

首版10场比分1/10、胜平负6/10；实际大小球6场为2全赢1走盘3全输，4场观望。凌晨7场版本及两批原TOP3分别统计。10场赛果及23个进球事件完成原文核验，独立赛果一致；完整原始响应与缺项留存。HTTP时间缺失明确标注，未伪造抓取时间。累计欧国联26场首版候选按A/B/C/D及Current/Test分列。

柏太阳神—川崎前锋于北京时间15:50冻结，16:00开球：人工研究2-1/主胜，大小球观望。15:51补充独立证据核验。官方首发及首回合已核实；两个J1赛程本轮刷新与此前五场缓存一致。活动日联杯路由不可用，次回合候选虽能加载，但BetExplorer首回合证据缺失而拒绝输出；没有伪造模型矩阵。模型、注册表和旧冻结全部保持。

长期恢复：在本目录运行 `python verify_archive.py --stage /tmp/NEW-review-kashiwa-restore`；验证新归档、复用长期归档、每个文件字节与冻结链。再按recovery-map.json恢复绝对路径/WCPP别名，源码另检出精确commit，依赖见inference-environment.json。不得绕过已过开球时间的校验来重跑赛前发布。

源码7a18cee715acb0633904af434b3f743d870c0951，PR #38仍开放且CI成功；main仍1257fdde7b6746b7ba6d2aa919382214a2cfb589。本轮只追加数据/报告，没有源码或活动模型改动，不发布环境。原模型无需回滚；保留所有历史冻结。必要时可用manifest中的数据父commit查看归档前状态，不能删除新冻结记录来美化成绩。
''')
manifest=dict(schema='WCPP-REVIEW-KASHIWA-ARCHIVE-20261115',created_at_beijing=datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),source_commit=source,source_main_commit=delivery['source_main_commit'],data_parent_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO).decode().strip(),archive=archive.name,archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,members=new,reused_files=len(reused),sidecar_files=[dict(path=p.name,sha256=sha(p)) for p in sorted(DEST.iterdir()) if p.is_file() and p!=archive],report_receipt=delivery['report_receipt'],kashiwa_report_receipt=delivery['kashiwa_delivery']['report_receipt'],credential_scan=dict(scanned_files=len(paths),configured_bindings_checked=len(secrets),findings=0),active_model_changed=False,environment_published=False)
write(DEST/'manifest.json',manifest)
latest=read(REPO/'latest-source.json');key=str(DEST.relative_to(REPO));latest['additional_workspace_updates'].append(key);latest['latest_review']=key+'/复盘报告.md';latest['latest_nations_review']=key+'/manifest.json';latest['latest_jleague_cup_analysis']=key+'/柏太阳神赛前分析.md';latest['latest_jleague_cup_analysis_manifest']=key+'/manifest.json';latest['synchronized_at']=datetime.now(ZoneInfo('Asia/Shanghai')).isoformat();latest['latest_review_source_commit']=source
latest['latest_chat_review_runtime']=dict(source_commit=source,population=10,settled=10,report_receipt=delivery['report_receipt'],active_registry_sha256=delivery['active_registry_sha256'],models_changed=False)
latest['latest_chat_jleague_cup_runtime']=dict(source_commit=source,competition='jpn.league_cup',match_id='jleague:111504',scope='MANUAL_RESEARCH_NO_AVAILABLE_NUMERICAL_PAIR',report_receipt=delivery['kashiwa_delivery']['report_receipt'],active_model_promotion=False)
(REPO/'latest-source.json').write_text(json.dumps(latest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(destination=str(DEST),new_files=len(new),reused_files=len(reused),archives=len(used)+1,archive_bytes=archive.stat().st_size,credential_findings=0),ensure_ascii=False))
