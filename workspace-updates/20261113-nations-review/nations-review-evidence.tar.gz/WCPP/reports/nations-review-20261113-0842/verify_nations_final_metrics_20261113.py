import json, hashlib, math
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo

D=Path('/workspace/WCPP/reports/nations-review-20261113-0842')
M=D/'metrics.json'; I=Path('/tmp/nations-review-independent-check-20261113.json'); L=Path('/tmp/nations-review-accounts-20261113.json')
m=json.loads(M.read_text()); i=json.loads(I.read_text()); lock=json.loads(L.read_text()); checks=[]
def eq(a,b,name):
    assert a==b,(name,a,b)
    checks.append(name)
def strip_ineligibility(v):
    if isinstance(v,dict): return {k:strip_ineligibility(x) for k,x in v.items() if k != 'total_ineligible_reasons'}
    if isinstance(v,list): return [strip_ineligibility(x) for x in v]
    return v
def summary(a,b,name):
    pairs={'population':b['population'],'settled':b['settled_population'],'primary_n':b['primary']['eligible'],'primary_hits':b['primary']['hits'],'primary_accuracy':b['primary']['accuracy'],'primary_hits_over_population':b['primary']['full_population_hit_rate'],'wdl_n':b['wdl']['eligible'],'wdl_hits':b['wdl']['hits'],'wdl_accuracy':b['wdl']['accuracy'],'total_n':b['total']['eligible'],'total_non_push_n':b['total']['non_push_denominator'],'total_strict_full_win_rate':b['total']['strict_full_win_rate'],'total_settlements':b['total']['settlements']}
    for key,v in pairs.items(): eq(a[key],v,f'{name}.{key}')
    if b['population']:
        for key,v in [('primary_coverage',b['primary']['coverage']),('wdl_coverage',b['wdl']['coverage']),('total_coverage',b['total']['coverage'])]: eq(a[key],v,f'{name}.{key}')
def rows(a,b,name):
    aa={x['match_id']:x for x in a}; bb={x['match_id']:x for x in b};eq(set(aa),set(bb),name+'.IDs')
    for mid,v in aa.items():
        for key in ['primary_hit','wdl_hit','total_line','total_direction','total_settlement']:
            eq(v.get(key),bb[mid].get(key),name+'.'+mid+'.'+key)
eq(m['population'],lock['population'],'population.order');eq(m['completed'],8,'all_completed');eq(m['pending'],0,'no_pending');eq(m['formal_model_promotion'],False,'no_promotion')
for version in ['first','latest']:
    summary(m['comprehensive'][version]['summary'],i['comprehensive'][version],'comprehensive.'+version)
    rows(m['comprehensive'][version]['rows'],i['comprehensive'][version]['rows'],'comprehensive.'+version)
for a in m['top3']:
    summary(a['summary'],i['top3'][a['account']],'top3.'+a['account'])
    rows(a['rows'],i['top3'][a['account']]['rows'],'top3.'+a['account'])
for track in ['current-test-pair','nations-paired-candidates']:
    for version in ['first','latest']:
        for part in ['models','paired_rows']:
            a=m['model_reviews'][track][version][part]; b=i[track][part]
            if track=='nations-paired-candidates' and version=='latest':
                eq(strip_ineligibility(a),strip_ineligibility(b),track+'.'+version+'.'+part+'.metrics')
            else:
                eq(a,b,track+'.'+version+'.'+part)
    if track=='nations-paired-candidates':
        for role, value in m['model_reviews'][track]['latest']['models'].items():
            for version, data in value['by_version'].items():
                eq(data['total_ineligible_reasons'],{'NO_FROZEN_TOTAL_DIRECTION':4,'FROZEN_TOTAL_QUOTE_MISMATCH':4},version+'.latest.OU_reasons')
for role in ['current','test']:
    a=m['latest_separate_derived_candidate_totals'][role]
    rows(a['rows'],i['derived_candidate_totals'][role]['rows'],'derived_total.'+role)
    total={k:sum(v['total_settlements'][k] for v in a['by_version'].values()) for k in ['win','half_win','push','half_loss','loss']}
    eq(total,i['derived_candidate_totals'][role]['total']['settlements'],'derived_total.'+role+'.sum')
    name='当前模型' if role=='current' else 'test模型'; b=i['same_match_comprehensive_vs_candidate'][name]; a=m['first_comprehensive_vs_referenced_candidates'][role]
    for key,v in [('paired_n',b['common_n']),('net_hits',b['net_extra_hits']),('changed_right',b['gained']),('changed_wrong',b['lost'])]: eq(a[key],v,'gain.'+role+'.'+key)
    discord=b['gained']+b['lost']; lower=min(b['gained'],b['lost']); expected=min(1.,2*sum(math.comb(discord,k) for k in range(lower+1))/2**discord)
    eq(a['exact_two_sided_discordant_sign_test_p'],expected,'gain.'+role+'.exact_sign_test')
eq(m['result_evidence']['ESPN_completed_90_verified'],8,'results.90min');eq(m['result_evidence']['second_source_score_agreement'],8,'results.crosscheck');eq(m['result_evidence']['second_source_alone_certifies_90'],False,'results.crosscheck90limit');eq(m['result_evidence']['xg_verified'],0,'results.xg_missing')
registry=Path('/workspace/WCPP/runtime/active-model.json');eq(hashlib.sha256(registry.read_bytes()).hexdigest(),m['assets_unchanged']['active_registry_sha256'],'active_registry_unchanged')
for version in ['first','latest']:
    for row in m['comprehensive'][version]['rows']:
        expected=next(f for f in lock['fixtures'] if f['match_id']==row['match_id'])['tracks']['comprehensive'][version]
        eq(row['freeze_id'],expected['freeze_id'],'freeze.'+version+'.'+row['match_id'])
        eq(row['record_sha256'],expected['record_sha256'],'freezehash.'+version+'.'+row['match_id'])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
output={'schema':'WCPP-NATIONS-INDEPENDENT-VERIFICATION-1','status':'PASS','reviewer':'nations_review_accounts_v2','verified_at':datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),'metrics_path':str(M),'metrics_sha256':sha(M),'calculation_script_sha256':sha(D/'calculate_review.py'),'account_lock_sha256':sha(L),'independent_calculation_sha256':sha(I),'independent_script_sha256':sha(Path('/tmp/check_nations_review_20261113.py')),'verification_script_sha256':sha(Path(__file__)),'checks_count':len(checks),'checks':checks,
 'verified_report_statements':['First and latest comprehensive primary 4/7 (57.14%), full population 4/8 (50%), WDL 7/7 with 7/8 coverage.','First totals 1 win, 2 half wins, 1 half loss; strict full-win rate 25%. Latest 2 half wins; strict full-win rate 0%.','Original research and revised research TOP3 both primary 1/3, WDL 3/3; original OU half loss, revised no direction (rate null).','First comprehensive vs Test on same 7 scored matches: net +2, 3 improved and 1 worsened (England); exact sign p=0.625. Versus Current net +3, sign p=0.25.','Candidate A and C results remain separately versioned; original candidate OU denominator zero; latest derived OU reference separate.','Active Current/Test remain 8 ABSTAIN each. No activity/model promotion.'],
 'qualifications':['This verifies accounting and local retained source consistency; it is not independent new network collection.','Exact sign tests and small sample do not establish promotion or target attainment; empirical bootstrap alone is insufficient.','ESPN future-dated advancement ingest notes excluded; crosscheck alone does not certify regulation time; Montenegro provider kickoff differs one minute.','Active ABSTAIN freeze wrapper cutoff differs slightly from identical actual model inputs; unchanged actual model inputs used.','xG missing all 8; no causal attribution of Albania early goals to later Finland red card.','Original candidate OU has no real quote; latest candidate has quote but still no frozen total direction/total object. Both denominators remain zero, with different appropriate ineligibility reasons.','Report prose has not yet been written at verification time; listed statements are verified for inclusion.']}
(D/'independent-verification.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':'PASS','checks':len(checks),'metrics_sha256':output['metrics_sha256'],'output':str(D/'independent-verification.json')},ensure_ascii=False))
