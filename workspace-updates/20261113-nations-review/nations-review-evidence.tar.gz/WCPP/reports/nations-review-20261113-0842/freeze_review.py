"""Append review freezes only. Never regenerate or alter a prematch forecast."""
import json
import hashlib
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
from research.analysis_freeze import save, verify
R=Path(__file__).resolve().parent
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,d):Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
if (R/'delivery.json').exists():raise SystemExit('Review already frozen; inspect existing delivery instead of creating a duplicate.')
metrics=read(R/'metrics.json');accounts=read(R/'frozen-accounts.json')
assert read(R/'independent-verification.json')['metrics_sha256']==sha(R/'metrics.json')
results={r['match_id']:r for r in read(R/'verified-results.json')}
process={r['event_id']:r for r in read(R/'data/espn/results.json')['matches']}
refs={r['match_id']:r for r in accounts['fixtures']}
decision='KEEP_PARAMETERS; SUPPLEMENT_DATA_AND_CONTINUE_INDEPENDENT_FORWARD_VALIDATION; NO_PROMOTION'
now=lambda:datetime.now(ZoneInfo('Asia/Shanghai')).isoformat()
receipts=[]
for first,latest in zip(metrics['comprehensive']['first']['rows'],metrics['comprehensive']['latest']['rows']):
    mid=first['match_id'];old=refs[mid]['tracks']['comprehensive']['first']
    f=dict(verify(read(old['path']))['fixture'],cutoff_at=now())
    evidence={'result':results[mid],'process':process[mid.split(':')[-1]],'first_review':first,'latest_review':latest,
        'prior_freeze_accounts':refs[mid],'review_decision':decision,'no_retrospective_selection':True,
        'full_report_sha256':sha(R/'review.md'),'metrics_sha256':sha(R/'metrics.json')}
    receipt=save(evidence,f,stage='review',track='comprehensive',idempotency_key='nations-20261113-review-1:'+mid)
    assert verify(read(receipt['path']))['record_sha256']==receipt['sha256']
    receipts.append(receipt)
files=[p for p in R.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
payload={'report_markdown':(R/'review.md').read_text(),'metrics':metrics,'results':list(results.values()),
    'review_decision':decision,'source_commit':'ddfbc43197df8944072c70135e2a2831ae1a3ef5',
    'prior_accounts':accounts,'review_receipts':receipts,'verification':read(R/'verification.json'),
    'independent_verification':read(R/'independent-verification.json'),
    'evidence_sha256':{str(p.relative_to(R)):sha(p) for p in sorted(files)}}
fixture={'match_id':'nations-analysis-batch:20261112-evening','cohort':'uefa.nations',
    'kickoff_at':'2026-11-13T01:00:00+08:00','cutoff_at':now()}
receipt=save(payload,fixture,stage='review',track='analysis-report',idempotency_key='nations-20261113-review-report-1')
assert verify(read(receipt['path']))['record_sha256']==receipt['sha256']
write(R/'delivery.json',{'report_receipt':receipt,'match_review_receipts':receipts,'population':8,
    'report_file':'review.md','report_sha256':sha(R/'review.md'),'metrics_sha256':sha(R/'metrics.json'),
    'prematch_records_modified':False,'active_model_changed':False,'environment_published':False})
print(json.dumps(receipt,ensure_ascii=False))
