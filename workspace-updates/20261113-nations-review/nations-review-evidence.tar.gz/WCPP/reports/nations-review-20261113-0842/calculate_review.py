"""Recompute this fixed review from original freezes and raw result evidence.

Read-only with respect to forecasts, models and databases. Outputs review JSON.
Run with runtime, runtime/optimization and runtime/v5 on PYTHONPATH.
"""
import hashlib
import json
import math
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import numpy as np
from research.analysis_freeze import verify, aware
from v5.paired_review import review
from v2.model import total_settlement, digest
from research_program.future_validation import quote_audit
from research_program.selection_review import compare

ROOT = Path(__file__).resolve().parent
def read(p): return json.loads(Path(p).read_text())
def write(p, x): Path(p).write_text(json.dumps(x, ensure_ascii=False, indent=2, allow_nan=False)+'\n')
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
accounts = read(ROOT/'frozen-accounts.json')
fixtures = {x['match_id']:x for x in accounts['fixtures']}
ids = accounts['population']
def record(mid, track, which='first'):
    ref = fixtures[mid]['tracks'][track][which]
    r = verify(read(ref['path']))
    assert r['record_sha256'] == ref['record_sha256']
    assert aware(r['fixture']['cutoff_at']) <= aware(r['recorded_at']) < aware(r['fixture']['kickoff_at'])
    return r

# Source hashes, ordered IDs and two-half regulation scores are checked again here.
metadata = read(ROOT/'data/espn/metadata.json')['requests']
for meta in metadata:
    assert meta['http_status'] == 200 and sha(ROOT/'data/espn'/meta['raw_file']) == meta['sha256']
cross = {str(x['market_identity_event_id']):x for x in read(ROOT/'data/crosscheck/crosscheck-results.json')['results']}
process = {str(x['event_id']):x for x in read(ROOT/'data/espn/results.json')['matches']}
scoreboard = read(ROOT/'data/espn/raw/scoreboard_20261112.json')
scoreboard_events = {str(x['id']):x for x in scoreboard['events']}
results=[]
for mid in ids:
    eid=mid.split(':')[-1]
    meta=next(x for x in metadata if x['event_id']==eid)
    raw=read(ROOT/'data/espn'/meta['raw_file'])
    header=raw['header']; c=header['competitions'][0]
    f=record(mid,'comprehensive')['fixture']
    assert str(header['id'])==eid and header['league']['slug']=='uefa.nations'
    assert aware(c['date'])==aware(f['kickoff_at'])
    status=c['status']['type']
    assert status['name']=='STATUS_FULL_TIME' and status['state']=='post' and status['completed'] is True
    competitors={x['homeAway']:x for x in c['competitors']}
    goals=[]
    for side in ('home','away'):
        team=competitors[side]
        assert str(team['id'])==str(f[side]).split(':')[-1]
        score=int(team['score']); halves=team['linescores']
        assert len(halves)==2 and sum(int(x['displayValue']) for x in halves)==score
        goals.append(score)
    board=scoreboard_events[eid]['competitions'][0]
    board_goals={x['homeAway']:int(x['score']) for x in board['competitors']}
    assert board_goals==dict(zip(('home','away'),goals))
    assert process[eid]['extra_time_or_shootout']['observed'] is False
    assert cross[eid]['completed'] is True and [cross[eid]['score_home'],cross[eid]['score_away']]==goals
    assert goals==[int(process[eid]['home']['score']),int(process[eid]['away']['score'])]
    results.append({'match_id':mid,'status':'completed','event_status':'FT','score_basis':'regulation_90',
        'home_goals':goals[0],'away_goals':goals[1],'source_url':meta['url'],
        'observed_at':meta['completed_utc'],'source_sha256':meta['sha256'],
        'home_team_id':competitors['home']['id'],'away_team_id':competitors['away']['id'],
        'phase':f['stage'],'league_level':f['league_level'],
        'regulation_evidence':'league-phase; STATUS_FULL_TIME/post/completed; exactly two half scores sum to final; no extra-time/shootout',
        'second_source':cross[eid],'source_path':str(ROOT/'data/espn'/meta['raw_file'])})
write(ROOT/'verified-results.json',results)
res={r['match_id']:r for r in results}
def actual(mid):
    r=res[mid]; h,a=r['home_goals'],r['away_goals']
    return f'{h}-{a}',('主胜' if h>a else '客胜' if h<a else '平局')

def settle(mid, line, direction):
    side={'大':'over','小':'under','over':'over','under':'under'}.get(direction)
    if side is None:return None
    m=np.zeros((51,51));r=res[mid];m[r['home_goals'],r['away_goals']]=1.
    return next(k for k,v in total_settlement(m,line,side).items() if v==1.)

def wilson(hit,n):
    if not n:return None
    z=1.959963984540054;p=hit/n;den=1+z*z/n
    center=(p+z*z/(2*n))/den;half=z*((p*(1-p)/n+z*z/(4*n*n))**.5)/den
    return [center-half,center+half]

def summarize(rows,population=None):
    pop=len(rows) if population is None else population
    ph=[x['primary_hit'] for x in rows if x['primary_hit'] is not None]
    wh=[x['wdl_hit'] for x in rows if x['wdl_hit'] is not None]
    totals=Counter(x['total_settlement'] for x in rows if x['total_settlement'] is not None)
    n=sum(totals.values());nonpush=n-totals['push']
    return {'population':pop,'selected_rows':len(rows),'settled':len(rows),'primary_n':len(ph),'primary_hits':sum(ph),
       'primary_accuracy':sum(ph)/len(ph) if ph else None,'primary_coverage':len(ph)/pop if pop else 0,
       'primary_hits_over_population':sum(ph)/pop if pop else None,'primary_wilson_95':wilson(sum(ph),len(ph)),
       'wdl_n':len(wh),'wdl_hits':sum(wh),'wdl_accuracy':sum(wh)/len(wh) if wh else None,
       'wdl_coverage':len(wh)/pop if pop else 0,'wdl_wilson_95':wilson(sum(wh),len(wh)),
       'total_n':n,'total_coverage':n/pop if pop else 0,'total_non_push_n':nonpush,
       'total_strict_full_win_rate':totals['win']/nonpush if nonpush else None,
       'total_settlements':{k:totals[k] for k in ('win','half_win','push','half_loss','loss')}}

comprehensive={}
for which in ('first','latest'):
    rows=[]
    for mid in ids:
        rec=record(mid,'comprehensive',which);p=rec['payload'];score,wdl=actual(mid)
        q=p['actual_quote']; audit=quote_audit({**rec['fixture'],'total_quote':q})
        assert audit['eligible'],audit
        rows.append({'match_id':mid,'name':p['name'],'actual':score,'actual_wdl':wdl,'primary':p['primary'],
            'primary_hit':p['primary']==score if p['primary'] is not None else None,
            'wdl':p['wdl'],'wdl_hit':p['wdl']==wdl if p['wdl'] in ('主胜','平局','客胜') else None,
            'total_line':p['total_line'],'total_direction':p['total_direction'],
            'total_settlement':settle(mid,p['total_line'],p['total_direction']),
            'freeze_id':rec['freeze_id'],'record_sha256':rec['record_sha256'],
            'method_version':p['method_version'],'actual_quote':q,'quote_audit':audit})
    comprehensive[which]={'summary':summarize(rows),'rows':rows}

model_reviews={}
for track in ('current-test-pair','nations-paired-candidates'):
    model_reviews[track]={}
    for which in ('first','latest'):
        pairs=[]
        for mid in ids:
            r=record(mid,track,which);p=r['payload']
            keys=('current_model','test_model') if track=='current-test-pair' else ('current','test')
            # The activity freeze wrapper records publication cutoff a few seconds
            # after the unchanged shared forecast input. Pass the actual forecast
            # pair to its native evaluator; it validates both original inputs.
            pairs.append({'match_id':mid,'current_model':p[keys[0]],'test_model':p[keys[1]]})
        model_reviews[track][which]=review(pairs,results)

# Do not add totals to candidate records: this is the distinct frozen derived reference.
derived_totals={}
for role in ('current','test'):
    rows=[]
    for mid in ids:
        r=record(mid,'comprehensive','latest');p=r['payload'];d=p['candidate_totals_reference'][role]
        assert d['source_matrix_hash']==p['candidate_outputs'][role]['matrix_hash']
        rows.append({'match_id':mid,'primary_hit':None,'wdl_hit':None,'total_direction':d['reference_direction'],
                     'total_line':d['line'],'total_settlement':settle(mid,d['line'],d['reference_direction']),
                     'freeze_id':r['freeze_id'],'version':p['candidate_outputs'][role]['version']})
    derived_totals[role]={'scope':'latest comprehensive separately frozen derived reference; not original model OU',
        'rows':rows,'by_version':{v:summarize([r for r in rows if r['version']==v]) for v in sorted({r['version'] for r in rows})}}

top3=[]
for acct in accounts['top3_accounts']:
    frozen=verify(read(acct['receipt']['path']));assert frozen['record_sha256']==acct['receipt']['record_sha256']
    rows=[]
    for p in acct['items']:
        mid=p['match_id'];score,wdl=actual(mid)
        rows.append({**p,'actual':score,'primary_hit':p['primary']==score if p.get('primary') else None,
            'wdl_hit':p['wdl']==wdl if p.get('wdl') in ('主胜','平局','客胜') else None,
            'total_settlement':settle(mid,p.get('total_line'),p.get('total_direction'))})
    top3.append({'account':acct['account'],'receipt':acct['receipt'],'summary':summarize(rows),
                 'full_batch_population':len(ids),'full_batch_ids':ids,
                 'selected_from_full_population':len(rows)/len(ids),'rows':rows})

# Compare actual referenced activity pair via the project's existing implementation.
activity_comparison=compare([{'comprehensive':record(mid,'comprehensive'),
    'pair':verify(read(record(mid,'comprehensive')['payload']['current_test_reference']['path']))} for mid in ids],results)

candidate_comparison={}
for role in ('current','test'):
    rows=[]
    for mid in ids:
        c=record(mid,'comprehensive');p=c['payload'];ref=verify(read(p['candidate_reference']['path']))
        assert ref['record_sha256']==p['candidate_reference']['sha256']
        f=ref['payload'][role];score,_=actual(mid)
        if p['primary'] is None:continue
        rows.append({'match_id':mid,'version':f['version'],'comprehensive':p['primary'],'candidate':f['primary'],
            'comprehensive_hit':p['primary']==score,'candidate_hit':f['primary']==score,
            'changed_right':p['primary']==score and f['primary']!=score,
            'changed_wrong':p['primary']!=score and f['primary']==score})
    n=len(rows);diff=np.array([int(r['comprehensive_hit'])-int(r['candidate_hit']) for r in rows])
    rng=np.random.default_rng(20261113);boot=rng.choice(diff,size=(20000,n),replace=True).mean(axis=1)
    discordant=int(np.count_nonzero(diff));lower=min(int((diff>0).sum()),int((diff<0).sum()))
    exact_p=min(1.,2*sum(math.comb(discordant,k) for k in range(lower+1))/(2**discordant)) if discordant else 1.
    candidate_comparison[role]={'scope':'first comprehensive vs its actual referenced research candidate; A/C are separate versions',
        'paired_n':n,'net_hits':int(diff.sum()),'changed_right':sum(r['changed_right'] for r in rows),
        'changed_wrong':sum(r['changed_wrong'] for r in rows),'descriptive_paired_rate_difference_bootstrap_95':np.quantile(boot,[.025,.975]).tolist(),
        'bootstrap_note':'fixed seed 20261113; 20000 resamples; small batch descriptive only, not promotion proof',
        'exact_two_sided_discordant_sign_test_p':exact_p,
        'by_version':{v:{'n':sum(r['version']==v for r in rows),'net_hits':sum(int(r['comprehensive_hit'])-int(r['candidate_hit']) for r in rows if r['version']==v)} for v in sorted({r['version'] for r in rows})},'rows':rows}

probability={}
for role in ('current','test'):
    rows=[]
    for mid in ids:
        f=record(mid,'nations-paired-candidates')['payload'][role];m=np.array(f['matrix']);h=res[mid]['home_goals'];a=res[mid]['away_goals'];score,wdl=actual(mid)
        assert digest(f['matrix'])==f['matrix_hash'] and np.isclose(m.sum(),1)
        marg=[m.sum(axis=1),m.sum(axis=0)];means=[float(np.dot(np.arange(len(x)),x)) for x in marg]
        intervals=[[int(np.searchsorted(np.cumsum(x),.1)),int(np.searchsorted(np.cumsum(x),.9))] for x in marg]
        iy,ix=np.indices(m.shape)
        probs=f['wdl']
        rows.append({'match_id':mid,'version':f['version'],'training_cutoff':f['training_data_cutoff'],
           'means':means,'observed':[h,a],'central80_intervals':intervals,
           'interval_covered':[intervals[i][0]<=v<=intervals[i][1] for i,v in enumerate([h,a])],
           'zero_prob':[float(x[0]) for x in marg],'observed_zero':[h==0,a==0],
           'prob_total_ge4':float(m[iy+ix>=4].sum()),'observed_total_ge4':h+a>=4,
           'score_log_loss':float(-np.log(max(m[h,a],1e-15))),
           'wdl_log_loss':float(-np.log(max(probs[wdl],1e-15))),
           'wdl_brier_sum3':sum((p-int(k==wdl))**2 for k,p in probs.items())})
    def prob_stats(rs):
        return {'n':len(rs),'expected_goals_mean':np.mean([x['means'] for x in rs],axis=0).tolist(),
            'observed_goals_mean':np.mean([x['observed'] for x in rs],axis=0).tolist(),
            'mean_error_pred_minus_actual':np.mean([np.array(x['means'])-x['observed'] for x in rs],axis=0).tolist(),
            'central80_coverage':np.mean([x['interval_covered'] for x in rs],axis=0).tolist(),
            'zero_probability_mean':np.mean([x['zero_prob'] for x in rs],axis=0).tolist(),
            'zero_observed_frequency':np.mean([x['observed_zero'] for x in rs],axis=0).tolist(),
            'prob_total_ge4_mean':float(np.mean([x['prob_total_ge4'] for x in rs])),
            'observed_total_ge4_frequency':float(np.mean([x['observed_total_ge4'] for x in rs])),
            **{k:float(np.mean([x[k] for x in rs])) for k in ('score_log_loss','wdl_log_loss','wdl_brier_sum3')}}
    probability[role]={'rows':rows,'by_version':{v:prob_stats([r for r in rows if r['version']==v]) for v in sorted({r['version'] for r in rows})},
        'limitation':'4 observations per grade; descriptive probability checks, not certified calibration'}

metrics={'schema':'WCPP-NATIONS-REVIEW-20261113-1','calculated_at':datetime.now(timezone.utc).isoformat(),
    'population':ids,'completed':8,'pending':0,'formal_model_promotion':False,
    'comprehensive':comprehensive,'model_reviews':model_reviews,'top3':top3,
    'latest_separate_derived_candidate_totals':derived_totals,
    'first_comprehensive_vs_referenced_activity':activity_comparison,
    'first_comprehensive_vs_referenced_candidates':candidate_comparison,'probability_diagnostics':probability,
    'result_evidence':{'ESPN_completed_90_verified':8,'second_source_score_agreement':8,'second_source_alone_certifies_90':False,
       'kickoff_discrepancy':'MNE-LVA same provider event ID; prior quote/ESPN 19:45Z vs score provider19:46Z; no schedule rewrite',
       'xg_verified':0,'red_cards_and_penalties_retained':True,'own_goals_observed':0,
       'excluded_source_fields':'ESPN event-ingest-note advancement annotations have timestamps later than capture; excluded from stage/qualification facts',
       'review_events_adapter':'FotMob-only normalize_fotmob_goal not applicable to ESPN source; no own-goal events observed; no fabricated adapter input'},
    'assets_unchanged':{'source_commit':'ddfbc43197df8944072c70135e2a2831ae1a3ef5',
       'active_registry_sha256':sha('/workspace/WCPP/runtime/active-model.json')}}
write(ROOT/'metrics.json',metrics)
print(json.dumps({'comprehensive':{k:v['summary'] for k,v in comprehensive.items()},'top3':[{k:a[k] for k in ('account','summary')} for a in top3]},ensure_ascii=False,indent=2))
