import json
import hashlib
from pathlib import Path
from collections import Counter
from datetime import datetime
from zoneinfo import ZoneInfo
import numpy as np

from research.analysis_freeze import verify, aware
from research_program.future_validation import quote_audit
from v5.paired_review import review as paired_review
from v2.model import total_settlement

BASE = Path('/workspace/WCPP/reports/nations-review-20261113-0842/data')
LOCK_PATH = Path('/tmp/nations-review-accounts-20261113.json')
lock = json.loads(LOCK_PATH.read_text())
source = json.loads((BASE / 'espn/results.json').read_text())
meta = json.loads((BASE / 'espn/metadata.json').read_text())
requests = {r['event_id']: r for r in meta['requests'] if r.get('event_id')}
cross = {r['market_identity_event_id']: r for r in json.loads((BASE / 'crosscheck/crosscheck-results.json').read_text())['results']}
frozen = {x['match_id']: x for x in lock['fixtures']}
results = []
process = []
for r in source['matches']:
    mid = 'espn:' + r['event_id']
    f = frozen[mid]['tracks']['comprehensive']['first']['fixture']
    assert 'espn:' + r['home']['team_id'] == f['home']
    assert 'espn:' + r['away']['team_id'] == f['away']
    assert aware(r['kickoff_utc']) == aware(f['kickoff_at'])
    assert r['status']['completed'] and r['status']['shortDetail'] == 'FT'
    assert set(r['periods_observed']) == {1, 2}
    assert not r['extra_time_or_shootout']['observed']
    assert all(len(r[s]['linescores']) == 2 for s in ['home', 'away'])
    assert all(sum(int(v['displayValue']) for v in r[s]['linescores']) == int(r[s]['score']) for s in ['home', 'away'])
    q = requests[r['event_id']]
    path = BASE / 'espn' / q['raw_file']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == q['sha256']
    raw = json.loads(path.read_text())
    assert raw['header']['id'] == r['event_id']
    assert raw['format']['regulation']['periods'] == 2
    assert raw['format']['regulation']['clock'] == 2700.0
    c = raw['header']['competitions'][0]
    assert c['status']['type']['completed'] and c['status']['type']['shortDetail'] == 'FT'
    teams = {v['homeAway']: v for v in c['competitors']}
    assert all(teams[s]['id'] == r[s]['team_id'] and teams[s]['score'] == r[s]['score'] for s in ['home', 'away'])
    z = cross[r['event_id']]
    assert z['completed'] and z['score_home'] == int(r['home']['score']) and z['score_away'] == int(r['away']['score'])
    results.append({'match_id': mid, 'status': 'FT', 'score_basis': 'regulation_90', 'home_goals': int(r['home']['score']), 'away_goals': int(r['away']['score']), 'source_url': q['url'], 'observed_at': q['completed_utc']})
    notes = c.get('notes', [])
    process.append({'match_id': mid, 'name': r['fixture_expected'], 'score': r['home']['score'] + '-' + r['away']['score'],
                    'statistics': {s: r[s]['statistics'] for s in ['home', 'away']},
                    'goals': [{k: g[k] for k in ['clock', 'period', 'event_type', 'team', 'text']} for g in r['goals']],
                    'incidents': [{k: g[k] for k in ['clock', 'period', 'event_type', 'team', 'text']} for g in r['key_incidents']],
                    'no_own_goals_reported': not r['own_goals'], 'xg_missing': all(r[s]['statistics']['xG'] is None for s in ['home', 'away']),
                    'crosscheck_kickoff_gap': z.get('gap'),
                    'unused_future_dated_ingest_notes': [n for n in notes if n.get('date') and aware(n['date']) > aware(q['completed_utc'])]})
assert set(frozen) == {r['match_id'] for r in results}
rmap = {r['match_id']: r for r in results}

def settle(h, a, line, side):
    sign = lambda x: (x > 0) - (x < 0)
    quarters = int(round(line * 4))
    legs = [line - .25, line + .25] if quarters % 2 else [line]
    value = sum(sign(h + a - leg) for leg in legs) / len(legs)
    if side in ['小', 'under']:
        value = -value
    expected = {1: 'win', .5: 'half_win', 0: 'push', -.5: 'half_loss', -1: 'loss'}[value]
    point = np.zeros((51, 51)); point[h, a] = 1
    actual = total_settlement(point, line, 'under' if side in ['小', 'under'] else 'over')
    assert actual[expected] == 1 and sum(actual.values()) == 1
    return expected

def rate(a, n):
    return a / n if n else None

def calc(rows, population):
    evaluated = []
    for p in rows:
        r = rmap[p['match_id']]
        actual = f"{r['home_goals']}-{r['away_goals']}"
        wdl = '主胜' if r['home_goals'] > r['away_goals'] else '客胜' if r['home_goals'] < r['away_goals'] else '平局'
        q = p.get('actual_quote')
        if p.get('total_direction'):
            assert q and quote_audit({**p['fixture'], 'total_quote': q})['eligible']
            assert q['line'] == p['total_line']
        evaluated.append({'match_id': p['match_id'], 'prediction': p.get('primary'), 'actual': actual,
                           'primary_hit': p.get('primary') == actual if p.get('primary') is not None else None,
                           'wdl': p.get('wdl'), 'wdl_hit': p['wdl'] == wdl if p.get('wdl') in ['主胜', '客胜', '平局'] else None,
                           'total_line': p.get('total_line'), 'total_direction': p.get('total_direction'),
                           'total_settlement': settle(r['home_goals'], r['away_goals'], p['total_line'], p['total_direction']) if p.get('total_direction') else None})
    eligible = {k: [r[k] for r in evaluated if r[k] is not None] for k in ['primary_hit', 'wdl_hit', 'total_settlement']}
    settlements = Counter(eligible['total_settlement']); nonpush = len(eligible['total_settlement']) - settlements['push']
    return {'population': population, 'settled_population': len(evaluated), 'pending': 0,
            'primary': {'hits': sum(eligible['primary_hit']), 'eligible': len(eligible['primary_hit']), 'accuracy': rate(sum(eligible['primary_hit']), len(eligible['primary_hit'])), 'coverage': rate(len(eligible['primary_hit']), population), 'full_population_hit_rate': rate(sum(eligible['primary_hit']), population)},
            'wdl': {'hits': sum(eligible['wdl_hit']), 'eligible': len(eligible['wdl_hit']), 'accuracy': rate(sum(eligible['wdl_hit']), len(eligible['wdl_hit'])), 'coverage': rate(len(eligible['wdl_hit']), population)},
            'total': {'eligible': len(eligible['total_settlement']), 'coverage': rate(len(eligible['total_settlement']), population), 'settlements': {k:settlements[k] for k in ['win', 'half_win', 'push', 'half_loss', 'loss']}, 'non_push_denominator': nonpush, 'strict_full_win_rate': rate(settlements['win'], nonpush)},
            'rows': evaluated}

out = {'checked_at': datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(), 'account_lock_path': str(LOCK_PATH), 'account_lock_sha256': hashlib.sha256(LOCK_PATH.read_bytes()).hexdigest(), 'all_8_results_identity_status_periods_raw_hash_and_crosscheck_passed': True,
       'crosscheck_does_not_independently_establish_90min': True, 'comprehensive': {}, 'top3': {}, 'derived_candidate_totals': {}, 'process': process}
comp_rows = {}
for version in ['first', 'latest']:
    rows = []
    for mid, f in frozen.items():
        raw = verify(json.load(open(f['tracks']['comprehensive'][version]['path'])))
        rows.append({'match_id': mid, 'fixture': raw['fixture'], **raw['payload']})
    comp_rows[version] = rows
    out['comprehensive'][version] = calc(rows, len(rows))

for account in lock['top3_accounts']:
    rows = []
    for p in account['items']:
        reference = p['comprehensive_reference']
        raw = verify(json.load(open(reference['path'])))
        assert raw['record_sha256'] == reference['sha256']
        assert all(p[k] == raw['payload'][k] for k in ['primary', 'wdl', 'total_line', 'total_direction'])
        rows.append({'match_id': p['match_id'], 'fixture': raw['fixture'], **raw['payload']})
    out['top3'][account['account']] = calc(rows, len(rows))

for track in ['current-test-pair', 'nations-paired-candidates']:
    pairs = []
    for mid, f in frozen.items():
        raw = verify(json.load(open(f['tracks'][track]['first']['path'])))
        names = ['current', 'test'] if track == 'nations-paired-candidates' else ['current_model', 'test_model']
        a, b = raw['payload'][names[0]], raw['payload'][names[1]]
        assert a['input'] == b['input']
        if track == 'current-test-pair':
            assert all(raw['fixture'].get(k) == a['input'].get(k) for k in set(raw['fixture']) | set(a['input']) if k != 'cutoff_at')
        pairs.append({'match_id': mid, 'current_model': a, 'test_model': b})
    out[track] = paired_review(pairs, results)

for role in ['current', 'test']:
    rows = []
    for p in comp_rows['latest']:
        d = p['candidate_totals_reference'][role]
        rows.append({'match_id': p['match_id'], 'fixture': p['fixture'], 'primary': None, 'wdl': None,
                     'total_line': d['line'], 'total_direction': d['reference_direction'], 'actual_quote': p['actual_quote']})
    out['derived_candidate_totals'][role] = calc(rows, len(rows))

paired = out['nations-paired-candidates']['paired_rows']
out['same_match_comprehensive_vs_candidate'] = {}
for role in ['当前模型', 'test模型']:
    comparison = []
    for row in out['comprehensive']['first']['rows']:
        if row['primary_hit'] is None:
            continue
        cand = next(v for v in paired if v['match_id'] == row['match_id'])['models'][role]
        comparison.append({'match_id': row['match_id'], 'comprehensive_hit': row['primary_hit'], 'candidate_hit': cand['primary_hit'], 'delta': int(row['primary_hit']) - int(cand['primary_hit'])})
    out['same_match_comprehensive_vs_candidate'][role] = {'common_n': len(comparison), 'net_extra_hits': sum(x['delta'] for x in comparison), 'gained': sum(x['delta'] == 1 for x in comparison), 'lost': sum(x['delta'] == -1 for x in comparison), 'rows': comparison}

out['process_interpretation_constraints'] = [
    'ALB-FIN: goals at 35 and 50, Finland red card at 67; red card cannot explain already scored goals.',
    'CZE-ESP: Spain penalty at 39, Czech red card at 72, second goal at 90+6; do not attribute full match shot totals only to red card.',
    'ENG-CRO: candidate Test 2-1 hit; comprehensive changed to 3-1 and missed; 64-minute penalty is part of observed match, not grounds for exclusion.',
    'MNE-LVA: Montenegro red card at 57, goals 70/72/90+1; retained result and recommendation still count.',
    'SMR-BLR: away goals 12/17, Belarus red card 90+3; red card did not generate early two-goal lead.',
    'All eight ESPN xG fields missing; shots are not xG. Future-dated advances notes not used.',
    'Old active ABSTAIN freeze outer fixture cutoff is 1-2 seconds later than mutually identical current/test input cutoff; paired_review uses unchanged actual model inputs without the optional envelope fixture.'
]
dest = Path('/tmp/nations-review-independent-check-20261113.json')
dest.write_text(json.dumps(out, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
print(json.dumps({'path': str(dest), 'comprehensive': {k:{a:b for a,b in v.items() if a!='rows'} for k,v in out['comprehensive'].items()}, 'top3':{k:{a:b for a,b in v.items() if a!='rows'} for k,v in out['top3'].items()}, 'candidate_versions': out['nations-paired-candidates']['models'], 'derived_total':{k:v['total'] for k,v in out['derived_candidate_totals'].items()}, 'net_gain':{k:{a:b for a,b in v.items() if a!='rows'} for k,v in out['same_match_comprehensive_vs_candidate'].items()}},ensure_ascii=False,indent=2))
