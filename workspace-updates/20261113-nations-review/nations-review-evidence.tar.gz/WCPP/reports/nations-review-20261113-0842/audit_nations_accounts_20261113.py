import json
import sys
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo

sys.path.insert(0, '/workspace/Football-Analysis/runtime')
from research.analysis_freeze import verify, digest, aware

ROOT = Path('/workspace/WCPP/forecasts/issued-analyses')
IDS = ['espn:' + str(i) for i in [401861146, 401861145, 401861147, 401861148, 401861150, 401861151, 401861152, 401861149]]
BATCH = 'nations-analysis-batch:20261112-evening'
records = []
for path in ROOT.glob('*/*.json'):
    try:
        record = json.loads(path.read_text())
    except (OSError, ValueError):
        continue
    if record.get('match_id') in IDS + [BATCH] and record.get('stage') == 'prematch':
        records.append((path, record))

def receipt(path, r):
    return {'path': str(path), **{k: r[k] for k in ['freeze_id', 'recorded_at', 'record_sha256', 'evaluation_slot', 'revision', 'track', 'match_id']}}

def forecast_summary(f):
    return {k: f.get(k) for k in ['status', 'version', 'primary', 'wdl_reference', 'matrix_hash', 'artifact_sha256', 'training_data_cutoff', 'actual_line', 'actual_line_status', 'total']}

def summary(path, r):
    out = receipt(path, r)
    p = r['payload']
    out['fixture'] = {k: r['fixture'].get(k) for k in ['home', 'home_name', 'away', 'away_name', 'competition', 'league_level', 'cohort', 'stage', 'kickoff_at', 'cutoff_at', 'score_basis']}
    if r['track'] == 'comprehensive':
        out['prediction'] = {k: p.get(k) for k in ['name', 'primary', 'wdl', 'total_line', 'total_direction', 'actual_quote', 'status', 'method_version', 'selection_scope', 'formal_kpi_eligible']}
    elif r['track'] in ['nations-paired-candidates', 'current-test-pair']:
        keys = ['current', 'test'] if r['track'] == 'nations-paired-candidates' else ['current_model', 'test_model']
        out['models'] = {key: forecast_summary(p[key]) for key in keys}
    return out

groups = {}
for path, r in records:
    verify(r)
    expected_scope = digest({k: r[k] for k in ['match_id', 'stage', 'track']})
    assert path.parent.name == expected_scope
    groups.setdefault((r['match_id'], r['track']), []).append((path, r))

checks = []
for key, rows in groups.items():
    rows.sort(key=lambda row: row[1]['revision'])
    previous = None
    previous_at = None
    for revision, (path, r) in enumerate(rows, 1):
        assert r['revision'] == revision
        assert r['previous_sha256'] == previous
        assert aware(r['fixture']['cutoff_at']) <= aware(r['recorded_at']) < aware(r['fixture']['kickoff_at'])
        if previous_at:
            assert previous_at < aware(r['recorded_at'])
        assert r['evaluation_slot'] == ('FIRST_PREMATCH' if revision == 1 else 'SEPARATE_REVISION_OR_STAGE')
        previous = r['record_sha256']
        previous_at = aware(r['recorded_at'])
    checks.append({'match_id': key[0], 'track': key[1], 'records': len(rows), 'hash_chain_verified': True, 'all_before_kickoff': True})

out = {'schema': 'nations-review-account-lock-1', 'locked_at': datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),
       'results_read_at_lock': False, 'population': IDS, 'population_count': len(IDS), 'record_count': len(records),
       'review_basis': 'FIRST_PREMATCH_PER_FIXTURE_PER_TRACK; revisions and original/revised TOP3 separate; no best of versions',
       'source_commit': 'ddfbc43197df8944072c70135e2a2831ae1a3ef5',
       'data_commit': '28f30ca3b7df0cb0827900937bae339e3dc1ab61', 'checks': checks, 'fixtures': []}

for mid in IDS:
    item = {'match_id': mid, 'tracks': {}}
    for track in ['comprehensive', 'current-test-pair', 'nations-paired-candidates']:
        rows = groups[(mid, track)]
        entry = {'first': summary(*rows[0]), 'latest': summary(*rows[-1]), 'all_receipts': [receipt(*row) for row in rows]}
        if track == 'nations-paired-candidates':
            entry['all_matrices_unchanged'] = all(all(r['payload'][role]['matrix_hash'] == rows[0][1]['payload'][role]['matrix_hash'] for role in ['current', 'test']) for _, r in rows)
        item['tracks'][track] = entry
    out['fixtures'].append(item)

top_rows = groups[(BATCH, 'top3-selection')]
report_rows = groups[(BATCH, 'analysis-report')]
out['top3_accounts'] = []
for label, pair, field in [('first_formal_top3', top_rows[0], 'top3'), ('research_supplement_top3', report_rows[1], 'research_top3'), ('latest_candidate_research_top3', top_rows[-1], 'top3')]:
    path, r = pair
    p = r['payload']
    items = [{k: x.get(k) for k in ['rank', 'match_id', 'primary', 'wdl', 'total_line', 'total_direction', 'comprehensive_reference']} for x in p[field]]
    out['top3_accounts'].append({'account': label, 'receipt': receipt(path, r), 'selection_scope': p.get('selection_scope') or p.get('ranking_scope'),
                                'full_population': p.get('population') or IDS, 'items': items, 'score_selected': sum(x['primary'] is not None for x in items),
                                'wdl_selected': sum(x['wdl'] in ['主胜', '平局', '客胜'] for x in items),
                                'total_selected': sum(x['total_direction'] in ['大', '小', 'over', 'under'] for x in items)})
out['report_receipts'] = [receipt(*row) for row in report_rows]
out['first_vs_latest_comprehensive'] = []
for item in out['fixtures']:
    t = item['tracks']['comprehensive']
    a, b = t['first']['prediction'], t['latest']['prediction']
    out['first_vs_latest_comprehensive'].append({'match_id': item['match_id'], 'first': {k: a[k] for k in ['primary', 'wdl', 'total_line', 'total_direction']}, 'latest': {k: b[k] for k in ['primary', 'wdl', 'total_line', 'total_direction']}})
out['denominators_before_results'] = {}
for version in ['first', 'latest']:
    values = [f['tracks']['comprehensive'][version]['prediction'] for f in out['fixtures']]
    out['denominators_before_results'][version] = {'population': len(values), 'primary_selected': sum(v['primary'] is not None for v in values), 'wdl_selected': sum(v['wdl'] in ['主胜', '平局', '客胜'] for v in values), 'total_selected': sum(v['total_direction'] in ['大', '小', 'over', 'under'] for v in values)}
dest = Path('/tmp/nations-review-accounts-20261113.json')
dest.write_text(json.dumps(out, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'path': str(dest), 'record_count':len(records), 'chains': len(groups), 'denominators':out['denominators_before_results'], 'first_vs_latest':out['first_vs_latest_comprehensive'], 'top3': [{'account':a['account'], 'freeze_id':a['receipt']['freeze_id'], 'items':[{k:v for k,v in x.items() if k!='comprehensive_reference'} for x in a['items']], 'total_selected':a['total_selected']} for a in out['top3_accounts']], 'all_candidate_matrices_unchanged': all(f['tracks']['nations-paired-candidates']['all_matrices_unchanged'] for f in out['fixtures'])}, ensure_ascii=False, indent=2))
