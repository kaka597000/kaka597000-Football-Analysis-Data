# 欧国联 2026-11-12 ESPN 赛后采集

- 赛事计划先锁定于 `collection_plan.json`；请求 9 次，按 scoreboard 后逐个 summary 顺序执行，未触发停止码。ESPN ESPN public API 全部 HTTP 200。
- 所有八场 scoreboard 及 summary 均为 `STATUS_FULL_TIME`。summary 两队通过 `homeAway` 和 team ID 识别，保留实际 linescores、事件时间/阶段、积分组级别、射门、射正和首发名册。
- 比分：ARM-CYP 1-1；TUR-BEL 1-2；ALB-FIN 2-0；CZE-ESP 0-2；ENG-CRO 2-1；ITA-FRA 3-1；MNE-LVA 2-1；SMR-BLR 0-2。
- 关键过程：ALB-FIN 第67分钟芬兰 Miro Tenho 红牌；CZE-ESP 第39分钟西班牙 Álex Baena 点球得分、第72分钟捷克 Ladislav Krejcí 红牌；ENG-CRO 第64分钟 Harry Kane 点球制胜；ITA-FRA 第60分钟 Sebastiano Esposito 罚失点球、第75分钟 Francesco Pio Esposito 点球得分；MNE-LVA 第57分钟 Montenegro Stefan Savic 两黄变一红；SMR-BLR 第90+3分钟 Belarus Aleksandr Svirepa 两黄变一红。其余进球顺序均见 `results.json`。
- ESPN提供两队射门/射正；摘要响应中没有 actual expected-goals 字段，xG保留为 null。未发现加时/点球大战；全场状态及事件仅含常规上下半场。首发来自赛事summary roster；响应不含赛前确认伤停/停赛清单，故缺席项不作猜测。
- 所有原始响应逐字节保存在 `raw/`；请求 URL、UTC/北京时间请求完成时间、HTTP 状态、SHA-256、字节数记于 `metadata.json`。
- Slug核对：已搜索仓库旧 ESPN nations URL/cache 元数据但没有找到匹配记录；本批依据任务指定的 `uefa.nations` endpoint 路径采集，已在计划中如实注明这一来源边界。
