Research-only World Cup group-stage pair. No Champion change.
Predict using worldcup/index.json with its SHA and absolute path resolved in the new environment.
The model and index are immutable copies. source-path-map.json maps old evidence paths to raw retained bytes.
Reproduction: from this directory run python -m research_program.fin_world_pair_adapter --manifest source-manifest.json --out NEW-DIRECTORY --competition fifa.world.
Historical data capture times are not historical first-known; final fit metadata timestamps will differ on rerun.
Finland has been removed from new analysis scope by the user. New build, training and inference reject Finland. Historical evidence remains preserved; no further Finland collection is authorized.
