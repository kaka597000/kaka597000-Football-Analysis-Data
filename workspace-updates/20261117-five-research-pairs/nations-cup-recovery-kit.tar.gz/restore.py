#!/usr/bin/env python3
"""Restore immutable research inputs from two verified Git-backed archives."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import tarfile
import tempfile


def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def exclusive(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if path.read_bytes() != data:
            raise ValueError('existing file differs, not overwritten: ' + str(path))
        return
    fd, temporary = tempfile.mkstemp(prefix='.restore-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        try:
            os.link(temporary, path)
        except FileExistsError:
            if path.read_bytes() != data:
                raise ValueError('concurrent conflicting destination: ' + str(path))
    finally:
        os.unlink(temporary)


def restore(manifest_path, archive_dir, root):
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    if manifest['schema'] != 'WCPP-NATIONS-CUP-PORTABLE-ASSETS-1':
        raise ValueError('unsupported manifest')
    root = root.resolve(); archive_dir = archive_dir.resolve()
    objects = manifest['objects']
    for checksum, ref in objects.items():
        if len(checksum) != 64 or any(c not in '0123456789abcdef' for c in checksum):
            raise ValueError('invalid object identity')
        target = root / 'objects' / checksum
        if target.exists() and (target.stat().st_size != ref['bytes'] or sha(target) != checksum):
            raise ValueError('existing object differs, not overwritten: ' + str(target))
    registry = manifest['registry']
    mapping = {p: str(root / 'objects' / checksum) for p, checksum in manifest['path_sha256'].items()}
    for route in registry['routes'].values():
        route['dependency_paths'] = mapping
    registry_data = (json.dumps(registry, ensure_ascii=False, indent=2) + '\n').encode()
    destination = root / 'research-registry.json'
    if destination.exists() and destination.read_bytes() != registry_data:
        raise ValueError('existing registry differs, not overwritten')
    # Validate both complete source archives before creating any restored files.
    for filename, ref in manifest['archives'].items():
        archive = archive_dir / filename
        if archive.stat().st_size != ref['bytes'] or sha(archive) != ref['sha256']:
            raise ValueError('source archive size/checksum mismatch: ' + filename)
    restored = set()
    for filename in manifest['archives']:
        members = {ref['member']: (checksum, ref) for checksum, ref in objects.items() if ref['archive'] == filename}
        with tarfile.open(archive_dir / filename, 'r|gz') as archive:
            for member in archive:
                if member.name not in members:
                    continue
                checksum, ref = members[member.name]
                if not member.isfile() or member.size != ref['bytes'] or checksum in restored:
                    raise ValueError('invalid or duplicate archive member: ' + member.name)
                data = archive.extractfile(member).read()
                if hashlib.sha256(data).hexdigest() != checksum:
                    raise ValueError('member checksum mismatch: ' + member.name)
                exclusive(root / 'objects' / checksum, data)
                restored.add(checksum)
    if restored != set(objects):
        raise ValueError('archive missing required objects')
    exclusive(destination, registry_data)
    receipt = dict(schema='WCPP-NATIONS-CUP-RESTORE-RECEIPT-1', manifest_sha256=sha(manifest_path),
                   registry_sha256=sha(destination), objects=len(restored), bytes=sum(x['bytes'] for x in objects.values()),
                   object_sha256=sorted(restored), active_registry_changed=False, predictions_issued=0)
    exclusive(root / 'restore-receipt.json', (json.dumps(receipt, indent=2) + '\n').encode())
    return receipt


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--manifest', type=Path, default=Path(__file__).with_name('manifest.json'))
    p.add_argument('--archive-dir', type=Path, required=True)
    p.add_argument('--root', type=Path, required=True)
    a = p.parse_args()
    result = restore(a.manifest, a.archive_dir, a.root)
    print(json.dumps({key: result[key] for key in ('objects', 'bytes', 'registry_sha256')}, indent=2))
