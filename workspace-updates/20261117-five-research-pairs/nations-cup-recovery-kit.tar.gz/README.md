# 双轨研究资产最小恢复交付

交付只需 `restore.py` 与 `manifest.json`。无需重复上传原归档。原仓库：
`kaka597000/kaka597000-Football-Analysis-Data`

固定读取提交：`0e06c14e8338c7bca9b9f07ee68345dfe6930e41`

| 本地名称 | 仓库路径 | SHA256 |
|---|---|---|
| nations.tar.gz | workspace-updates/20261116-nations-repair/nations-repair-evidence.tar.gz | 4ce0a909d6c3e0079101106dcd0c88abac17459f4a01b18d844795f6f7161c43 |
| cup.tar.gz | workspace-updates/20261111-jleague-cup-quarterfinals/quarterfinal-research.tar.gz | 213115e752dae26595ba477af1dd7b3dbd1e346fa9d4c2d3430997a900769fb0 |

从已授权克隆只读取出（DATA_REPO 为本地数据仓库）：

```sh
mkdir -p /tmp/research-archives
COMMIT=0e06c14e8338c7bca9b9f07ee68345dfe6930e41
git -C "$DATA_REPO" show "$COMMIT:workspace-updates/20261116-nations-repair/nations-repair-evidence.tar.gz" > /tmp/research-archives/nations.tar.gz
git -C "$DATA_REPO" show "$COMMIT:workspace-updates/20261111-jleague-cup-quarterfinals/quarterfinal-research.tar.gz" > /tmp/research-archives/cup.tar.gz
python restore.py --archive-dir /tmp/research-archives --root /absolute/NEW_RESEARCH_ROOT
```

脚本先校验两原归档大小/SHA，再逐件校验并恢复35个独立对象，共9,946,263字节。包含欧国联A/B/C/D固定双轨、日联杯八强首/次回合双轨的静态数据/协议/证书/工件依赖。数据与候选仍为研究用途；不加载challenger，不晋级。

新root生成 `objects/<sha256>`、`research-registry.json` 与 `restore-receipt.json`。dependency_paths自动指向新root，保留原工件登记路径作为映射键，不改工件字节。重复恢复相同内容允许；已有对象或registry不同则停止，不覆盖。仅按白名单成员读数据，不执行tar通用路径解压。脚本不写旧活动注册表、冻结或源代码，不访问密钥。

执行源代码仍需另行部署：以Football-Analysis `3eca355a`为基线加适配器提交 `8513187`、`b69a1e1`。源代码由适配器按原工件登记的模块SHA核验。Cup仍仅支持2026/27八强；次回合必须另提供已核验首回合90分钟记录。真实未来fixture及其原文不是静态模型资产，须由当次任务提供，并可另向dependency_paths追加精确已校验路径映射。不把旧赛程搬到未来、不补造盘口。

已验证：全新root恢复成功；相同root第二次恢复成功；不同已有对象被拒绝且原文件未改。最小恢复的静态依赖另经真实欧国联输入加载核验；测试仅计算，不发布。
