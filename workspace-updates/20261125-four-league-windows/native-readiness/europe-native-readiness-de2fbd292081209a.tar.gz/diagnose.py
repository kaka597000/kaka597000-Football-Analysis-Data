#!/usr/bin/env python3
"""Local, read-only native availability diagnostic. Persist only coverage, identities and hashes."""
import argparse
import csv
import io
import json
import os
import platform
import socket
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from importlib.metadata import version
from pathlib import Path
from tempfile import TemporaryDirectory

from readiness_inputs import (DATA, DATA_PIN, INTAKE, REGISTRY, RUNTIME, VERIFY_PIN, VERIFY_SOURCE, WINDOW,
                      ROLES, SIDES, SIZES, Files, calendar, clock, club, fixture_inputs, git,
                      index, models, objsha, read, registration, require, sha, stamp, verify_upstream)

HERE = Path(__file__).resolve().parent
FILES = ('fixtures.jsonl', 'fixtures.csv', 'clubs.csv', 'manifest.json')
PROFILE = dict(GIT_OPTIONAL_LOCKS='0', PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
               MKL_NUM_THREADS='1', OPENBLAS_CORETYPE='Haswell', NPY_DISABLE_CPU_FEATURES='AVX512F',
               WCPP_RUNTIME_ROOT='/workspace/WCPP')
LABELS = ('SUCCESS', 'PRIOR', 'FAILURE')
ENGINES = {'current': ('legacy_weighted_anchor', 'v5/weighted_model.py'),
           'test': ('v6.ml_model.predict', 'v6/ml_model.py')}
SOURCES = ('prediction_service.py', 'prediction_engine.py', 'prediction_diagnostics.py', 'predict_active.py',
           'runtime_config.py', 'competition_scope.py', '../configs/analysis-scope.json', 'active_route_engines.py',
           'v2/model.py', 'v2/evidence.py', 'v3/context.py', 'v4/main_model.py', 'v4/context_learning.py',
           'v4/competition_router.py', 'v4/decision_audit.py', 'database/registry.py', 'v5/weighted_model.py',
           'v6/ml_model.py', 'ml_core.py', 'model_source_identity.py', 'asof_contract.py', 'ml-source-compatibility.json')


def offline(event, args):
    if event in ('socket.getaddrinfo', 'socket.gethostbyname', 'socket.gethostbyaddr') or (
            event in ('socket.connect', 'socket.sendto') and args[0].family in (socket.AF_INET, socket.AF_INET6)):
        raise RuntimeError('native readiness permits local archived sources only')


def now():
    return datetime.now(timezone.utc)


def csv_bytes(rows):
    stream = io.StringIO(newline='')
    wr = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator='\n')
    wr.writeheader()
    wr.writerows(rows)
    return stream.getvalue().encode()


def pretty(value):
    return (json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2, sort_keys=True) + '\n').encode()


def failed(why):
    return {'status': 'FAILURE', 'reason': why, 'matrix_valid': False}


def classify(role, output, proof, request, clubs, model, notes):
    import numpy as np
    expected, engine_path = ENGINES[role]
    if proof.get('execution_failure') or str(output.get('status', '')).startswith('ABSTAIN'):
        fault = proof.get('execution_failure') or {}
        return failed('native abstained: ' + str(fault.get('stage', output.get('status'))) + ' ' + str(fault.get('error_type', '')))
    if output.get('matrix') is None:
        return failed('native returned no matrix')
    require(proof['engine'] == expected and proof['engine_sha256'] == sha((RUNTIME / engine_path).read_bytes()) and
            proof['artifact'] == notes['resolved_artifact_path'] and proof['artifact_sha256'] == notes['artifact_sha256']
            and proof['reported_version'] == output['version'] == notes['native_version']
            and output['model_hash'] == notes['native_object_sha256'] and output['code_hash'] == notes['native_code_hash']
            and output['recipe'] == notes['recipe'] and output['input'] == request, f'{role} native attestation mismatch')
    mat = np.asarray(output['matrix'], dtype=float)
    if mat.shape != (51, 51) or not np.isfinite(mat).all() or np.any(mat < 0) or abs(mat.sum() - 1.) > 1e-10:
        return failed('native matrix violates support, finiteness, nonnegativity or normalization')
    missing = []
    for side in SIDES:
        c = clubs[side][role]
        if not (c['attack_key'] and c['defence_key'] and c['training_matches']):
            missing.append(side)
    if role == 'current':
        unseen = output['rates']['unseen_teams']
        require(set(unseen) <= set(request[s] for s in SIDES), 'unrecognized Current unseen ID')
        missing = [s for s in SIDES if s in missing or request[s] in unseen]
        reason = 'Both ESPN IDs have fitted attack/concede entries and closed team history; native unseen list empty.'
    else:
        ml = output['ml']
        columns = model['feature_names']
        features = ml['feature_values']
        require(ml['selected_alpha'] == model['alpha'] and ml['feature_count'] == len(columns)
                and len(features) == 2 and all(len(v) == len(columns) for v in features), 'Test native booster inputs')
        for j, side in enumerate(SIDES):
            c = clubs[side]['test']
            # Test side_features uses the last six strictly prior closed rows. Verify the actual feature columns.
            for field, key in [('own_xg_coverage', 'recent_native_xg_rows'), ('own_process_coverage', 'recent_native_process_rows')]:
                require(abs(features[j][columns.index(field)] - c[key] / max(c['recent_native_rows'], 1)) < 1e-12,
                        f'{request["match_id"]} Test native feature provenance')
        reason = 'Both ESPN IDs have fitted DC attack/defence and team history; native LightGBM features returned.'
    if missing:
        reason = 'Valid native matrix with league/default inputs for ' + ', '.join(missing) + ' (missing fitted team rates or history).'
    return dict(status='PRIOR' if missing else 'SUCCESS', prior_sides=missing, reason=reason, matrix_valid=True,
                engine=expected, engine_sha256=proof['engine_sha256'], artifact_sha256=proof['artifact_sha256'],
                native_version=output['version'], recipe=output['recipe'])


def execute(service, request, ev, clubs, fitted, notes, source_commit):
    mid = ev['match_id']
    started = now()
    require(clock(request['cutoff_at']) <= started < clock(request['kickoff_at']), f'{mid} genuine prematch clock required')
    obj = None
    try:
        obj = service.run(request, str(REGISTRY), retain_current_on_test_failure=True)
    except (ValueError, OSError, ImportError, RuntimeError, KeyError, TypeError) as error:
        frames = []
        tb = error.__traceback__
        while tb is not None:
            frames.append((Path(tb.tb_frame.f_code.co_filename).name, tb.tb_frame.f_code.co_name))
            tb = tb.tb_next
        if ('main_model.py', 'predict') in frames:
            current = 'Current rejected fixture: ' + str(error)
            test = 'Paired Test was not reached because Current failed.'
        else:
            site = '.'.join(frames[-1])
            current = test = f'No verified pair from prediction_service.run: {site} {type(error).__name__}: {error}'
        roles = dict(current=failed(current), test=failed(test))
    generated = {}
    if obj is not None:
        audit = obj['execution_audit']
        require(audit['fixture_sha256'] == ev['fixture_sha256'] and audit['registry_sha256'] == ev['registry_sha256']
                and audit['registry'] == str(REGISTRY.resolve()) and audit['prediction_values_modified'] is False
                and audit['source_identity']['commit'] == source_commit
                and obj['match_id'] == mid and obj['route_key'] == request['cohort'], 'service execution audit')
        for name in request['analysis_modules']:
            require(obj['match_analysis']['modules'][name]['status'] == request['analysis_modules'][name]['status'],
                    f'{mid} supplementary evidence rejected: {name}')
        roles = {}
        for role in ROLES:
            output = obj[role + '_model']
            roles[role] = classify(role, output, audit[role], request, clubs, fitted[role], notes[role])
            if output.get('generated_at'):
                generated[role] = output['generated_at']
    finished = now()
    require(finished < clock(request['kickoff_at']) and all(started <= clock(t) <= finished for t in generated.values()),
            f'{mid} native execution clock')
    ev['roles'] = roles
    statuses = {r['status'] for r in roles.values()}
    ev['status'] = next(s for s in ('FAILURE','PRIOR','SUCCESS') if s in statuses)
    return dict(match_id=mid, fixture_sha256=ev['fixture_sha256'], started_utc=stamp(started), ended_utc=stamp(finished),
                native_generated_at=generated, roles={role: roles[role]['status'] for role in ROLES})


def flat_club(c):
    row = {k: v for k, v in c.items() if k not in ROLES}
    for role in ROLES:
        row.update({role + '_' + k: v for k, v in c[role].items()})
    return row


def flat_fixture(ev, by_id):
    row = {k: ev[k] for k in ('competition','registration_slot','match_id','fotmob_match_id','kickoff_utc','cutoff_utc')}
    for s in SIDES:
        tid = ev['teams'][s]
        c = by_id[ev['competition'], tid]
        row.update({s + '_name': c['name'], s + '_espn': tid, s + '_fotmob': c['fotmob_id'],
                    s + '_new_to_top_tier': c['new_to_top_tier_2026_27'], s + '_target_listed_players': ev['target_roster_entries'][s]})
        for role in ROLES:
            row[s + '_' + role + '_training_matches'] = c[role]['training_matches']
    row['status'] = ev['status']
    for role in ROLES:
        r = ev['roles'][role]
        row.update({role + '_status': r['status'], role + '_reason': r['reason'],
                    role + '_artifact_sha256': ev['bound_artifact_sha256'][role]})
    row.update({k: ev[k] for k in ('identity','registration_id','registration_sha256','summary_sha256','fixture_sha256','registry_sha256')})
    row['bookmaker_rows'] = len(ev['bookmakers'])
    row['provider_quote_timestamps'] = ev['provider_quote_timestamps']
    return row


def counts(rows, clubs):
    return dict(matches=len(rows), clubs=len(clubs), entrants=sum(c['new_to_top_tier_2026_27'] for c in clubs),
                matches_with_entrant=sum(r['has_new_top_tier_club'] for r in rows),
                entrant_pair_success=sum(r['has_new_top_tier_club'] and r['status'] == 'SUCCESS' for r in rows),
                joint={s: sum(r['status'] == s for r in rows) for s in LABELS},
                roles={role: {s: sum(r['roles'][role]['status'] == s for r in rows) for s in LABELS} for role in ROLES},
                fixtures_with_two_confirmed_XI=sum(all(r['target_listed_starters'][side] == 11 for side in SIDES) for r in rows),
                target_sides_with_roster_entries=sum(n > 0 for r in rows for n in r['target_roster_entries'].values()),
                with_quotes=sum(bool(r['bookmakers']) for r in rows), quote_rows=sum(len(r['bookmakers']) for r in rows),
                provider_quote_timestamps=sum(r['provider_quote_timestamps'] for r in rows),
                distinct_prior_matches=len(set((c['competition'],c['recent_ft_fotmob_id']) for c in clubs)))


def scan(env, out, wall_start):
    files = Files()
    verify_upstream(env, files)
    files.pinned(DATA / 'model-evidence/registry.json')
    registry_sha = files.add(REGISTRY)
    require(registry_sha == sha((DATA / 'model-evidence/registry.json').read_bytes()), 'active registry differs from PR #57')
    registry = read(REGISTRY)
    require(registry['status'] == 'ACTIVE_RESEARCH', 'registry status')
    for rel in SOURCES:
        files.add((RUNTIME / rel).resolve())
    for name in ('readiness_inputs.py', 'diagnose.py'):
        files.add(HERE / name)
    slate_path = INTAKE / 'inputs/first-window-40.jsonl'
    files.add(slate_path)
    slate = index((json.loads(line) for line in slate_path.read_text().splitlines()), lambda r: 'espn:' + r['espn_source_match_id'])
    require(len(slate) == len({r['fotmob_source_match_id'] for r in slate.values()}) == 40, 'ESPN/FotMob 40 unique slots')
    derived = INTAKE / 'derived'
    recent = index(read(derived / 'team-recent-match-index.json')['rows'], lambda r: (r['competition'], 'espn:' + r['espn_team_id']))
    quotes = defaultdict(list)
    all_quotes = read(derived / 'espn-sportsbook-quotes.json')['rows']
    for (mid, _), q in index(all_quotes, lambda q: ('espn:' + q['event_id_espn'], q['provider_id'])).items():
        require(mid in slate, 'quote outside first window')
        quotes[mid].append(q)
    cap = derived / 'espn-summary-capture-manifest.json'
    files.add(cap)
    captures = index(read(cap)['sources'], lambda m: 'espn:' + m['event_id'])
    require(slate.keys() == captures.keys(), 'summary manifest population')
    source_commit = git(RUNTIME, 'rev-parse', 'HEAD')
    dirty = bool(git(RUNTIME, 'status', '--porcelain'))
    sys.path.insert(0, str(RUNTIME))
    import prediction_service as service
    import prediction_engine as engine
    require(Path(service.__file__).resolve() == RUNTIME / 'prediction_service.py'
            and service.predict_models is engine.predict_models
            and Path(sys.modules[engine.legacy.rates.__module__].__file__).resolve() == RUNTIME / 'v2/model.py',
            'unexpected native module resolution')
    all_clubs, fixtures, receipts, leagues = {}, [], [], {}
    for code, (wanted, population) in SIZES.items():
        reg, freeze = registration(code, files)
        fitted, bound = models(code, reg, registry, registry_sha, files)
        sources, board, fm, seasons, season_counts = calendar(code, files)
        clubs = {tid: club(code, row, fitted, seasons, board, fm, sources, files)
                 for (league, tid), row in recent.items() if league == code}
        require(len(clubs) == population and {x['espn_id'][5:] for x in clubs.values()} == seasons[2026]
                and len({c['fotmob_id'] for c in clubs.values()}) == population, f'{code} club roster crosswalk')
        all_clubs.update({(code, k): v for k, v in clubs.items()})
        identity = reg['payload']['identity']
        window = identity['slates'][WINDOW]
        require(set(window) == {mid for mid, r in slate.items() if r['competition'] == code}, 'registration/population mismatch')
        league_rows = []
        for slot, mid in enumerate(window, 1):
            f = reg['payload']['fixtures'][mid]
            s_clubs = {s: clubs[f[s]] for s in SIDES}
            prior = {s: recent[code, f[s]] for s in SIDES}
            request, ev = fixture_inputs(slate[mid], f, freeze, slot, prior, s_clubs, quotes[mid], captures[mid],
                                         sources, board, fm, files)
            ev.update(registry_sha256=registry_sha, has_new_top_tier_club=any(c['new_to_top_tier_2026_27'] for c in s_clubs.values()),
                      bound_artifact_sha256={role: bound[role]['artifact_sha256'] for role in ROLES},
                      earlier_firsts_at_registration={k: v is not None for k, v in identity['earlier_firsts'][mid].items()})
            require(all(clock(n['observed_at']) <= clock(ev['cutoff_utc']) and clock(n['built_at']) <= clock(ev['cutoff_utc'])
                        and n['train_end'] < min(clock(ev['kickoff_utc']).date().isoformat(),
                                                 *(v['latest_match_date_utc'] for v in prior.values())) for n in bound.values()),
                    'closed artifact or audit chronology')
            receipts.append(execute(service, request, ev, s_clubs, fitted, bound, source_commit))
            fixtures.append(ev)
            league_rows.append(ev)
        require(len(league_rows) == wanted, 'missing native invocations')
        leagues[code] = dict(registration=freeze, weights=bound, season_rosters=season_counts,
                            calendar_evidence=sources, counts=counts(league_rows, clubs.values()))
        print(code, json.dumps(leagues[code]['counts']['joint']), flush=True)
    require(set(r['match_id'] for r in fixtures) == set(slate) and len(all_clubs) == len(recent) == 76, 'final grain')
    club_rows = sorted(all_clubs.values(), key=lambda c: (c['competition'], c['espn_id']))
    csv_rows = [flat_fixture(r, all_clubs) for r in fixtures]
    payload = {'fixtures.csv': csv_bytes(csv_rows), 'clubs.csv': csv_bytes([flat_club(c) for c in club_rows]),
               'fixtures.jsonl': b''.join((json.dumps(r, ensure_ascii=False, sort_keys=True, allow_nan=False) + '\n').encode() for r in fixtures)}
    manifest = dict(schema='europe-native-readiness-v1', window=WINDOW, original_data_commit=DATA_PIN,
                    registration_verifier_commit=VERIFY_PIN, registration_verifier_source=str(VERIFY_SOURCE),
                    active_source_commit=source_commit, active_source_dirty=dirty, active_runtime=str(RUNTIME),
                    registry_sha256=registry_sha, entrypoint='prediction_service.run -> prediction_engine.predict_models',
                    runtime_profile=PROFILE, python=sys.version.split()[0], architecture=platform.machine(),
                    packages={p: version(p) for p in ('numpy','scipy','lightgbm')},
                    leagues=leagues, total=counts(fixtures, club_rows), source_files=files.hashes,
                    outputs={n: sha(v) for n, v in payload.items()})
    payload['manifest.json'] = pretty(manifest)
    receipt = dict(schema='europe-native-execution-v1', manifest_sha256=sha(payload['manifest.json']),
                   actual_wall_start_utc=stamp(wall_start), actual_wall_end_utc=stamp(now()), per_match=receipts)
    # Write only into a new run directory or beside this tool. Never overwrite an existing receipt.
    for name, body in [*payload.items(), ('execution.json', pretty(receipt))]:
        with (out / name).open('xb') as handle:
            handle.write(body)


def verify_bundle(folder):
    manifest = read(folder / 'manifest.json')
    for path, h in manifest['source_files'].items():
        require(sha(Path(path).read_bytes()) == h, f'input SHA mismatch: {path}')
    for name, h in manifest['outputs'].items():
        require(sha((folder / name).read_bytes()) == h, f'output SHA mismatch: {name}')
    rows = index((json.loads(line) for line in (folder / 'fixtures.jsonl').read_text().splitlines()), lambda r: r['match_id'])
    with (folder / 'clubs.csv').open() as f:
        clubs = list(csv.DictReader(f))
    with (folder / 'fixtures.csv').open() as f:
        csvrows = index(csv.DictReader(f), lambda r: r['match_id'])
    require(len(rows) == len(csvrows) == 40 and len(clubs) == 76, 'bundle populations')
    for mid, r in rows.items():
        require(csvrows[mid]['fixture_sha256'] == r['fixture_sha256'] and csvrows[mid]['status'] == r['status']
                and all(csvrows[mid][role + '_status'] == r['roles'][role]['status'] for role in ROLES), 'CSV/JSON role counts')
    receipt_paths = [folder / 'execution.json']
    if (folder / 'repeat-execution.json').exists():
        receipt_paths.append(folder / 'repeat-execution.json')
    for p in receipt_paths:
        rec = read(p)
        require(rec['manifest_sha256'] == sha((folder / 'manifest.json').read_bytes()), 'receipt/manifest mismatch')
        rr = index(rec['per_match'], lambda r: r['match_id'])
        require(rr.keys() == rows.keys(), 'receipt slots')
        for mid, r in rows.items():
            w = rr[mid]
            begin, end = clock(w['started_utc']), clock(w['ended_utc'])
            require(w['fixture_sha256'] == r['fixture_sha256'] and clock(r['cutoff_utc']) <= begin <= end < clock(r['kickoff_utc'])
                    and clock(rec['actual_wall_start_utc']) <= begin <= end <= clock(rec['actual_wall_end_utc'])
                    and w['roles'] == {role: r['roles'][role]['status'] for role in ROLES}
                    and all(role in w['native_generated_at'] for role in ROLES if w['roles'][role] != 'FAILURE')
                    and all(begin <= clock(t) <= end for t in w['native_generated_at'].values()), 'native wall-clock receipt mismatch')
    print(f'OK: {len(rows)} registered matches, {len(clubs)} clubs, {len(receipt_paths)} real native run(s); all source and output hashes verified.')


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    grp = ap.add_mutually_exclusive_group(required=True)
    grp.add_argument('--out', type=Path, help='fresh local output directory for a genuine prematch run')
    grp.add_argument('--verify', type=Path, help='verify captured run, paths, byte hashes and actual clocks, even after kickoff')
    args = ap.parse_args()
    if args.verify:
        verify_bundle(args.verify)
        return
    out = args.out.resolve()
    require(not any(out.is_relative_to(p.resolve()) for p in (DATA.parents[1], INTAKE, REGISTRY.parents[1], RUNTIME.parent, VERIFY_SOURCE)),
            'output must be separate from originals')
    require(not any((out / n).exists() for n in (*FILES,'execution.json','repeat-execution.json')), 'existing run in output directory')
    out.mkdir(parents=True, exist_ok=True)
    wall_start = now()
    sys.dont_write_bytecode = True
    with TemporaryDirectory(prefix='readiness-runtime-') as tmp:
        os.environ.update(PROFILE, MPLCONFIGDIR=tmp)
        sys.addaudithook(offline)
        scan(dict(os.environ), out, wall_start)


if __name__ == '__main__':
    main()
