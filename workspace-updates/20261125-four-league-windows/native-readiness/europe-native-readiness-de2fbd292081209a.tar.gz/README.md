# 四联赛第一窗口 · 活动双模型赛前可用性

PR #57 的首窗登记共 40 场、76 支球队。2026-11-25 北京时间 20:31–20:32，两次独立 Python 进程均从 `prediction_service.run` 进入 `prediction_engine.predict_models`，读取本机活动注册表和八份绑定工件。每次 Current 和 Test 各成功 40 场，使用联赛先验回退 0 场，失败 0 场。全部 80 个角色输出均通过球队参数、工件身份和矩阵有效性核验。两轮的逐场表、球队表和清单逐字节相同。操作范围为可用性诊断，正式三轨首发仍由后续窗口办理。

| 联赛 | 登记场次 | Current 成功 | Test 成功 | 有任一角色回退 | 有任一角色失败 | 新升入球队 | 涉及场次 | 有机构行的场次 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 西甲 | 12 | 12 | 12 | 0 | 0 | 3 | 3 | 10 |
| 德甲 | 9 | 9 | 9 | 0 | 0 | 3 | 2 | 9 |
| 意甲 | 10 | 10 | 10 | 0 | 0 | 3 | 3 | 10 |
| 法甲 | 9 | 9 | 9 | 0 | 0 | 2 | 2 | 9 |
| **合计** | **40** | **40** | **40** | **0** | **0** | **11** | **10** | **38** |

## 逐场查阅

- 逐场表中一行对应一个登记席位。主客 ESPN 和 FotMob ID、开球与输入截止、两个角色的状态与原因、训练场数、原登记 SHA、请求 SHA、摘要 SHA 与两份权重 SHA 均可直接查阅。`registration_slot` 是该联赛首窗冻结数组内从 1 开始的位置。[fixtures.csv](/workspace/scratch/europe-native-readiness-20261125/fixtures.csv)
- 逐场明细同时记录冻结时已有首发情况、赛前摘要查询和接收时间、名单条目数、机构来源数、引擎 SHA，以及真实入口核验后的两个角色版本。四个联赛在本次窗口登记时，40 个席位的原双模型与综合首发栏均为空。[fixtures.jsonl](/workspace/scratch/europe-native-readiness-20261125/fixtures.jsonl)
- 球队表按联赛和 ESPN ID 唯一。两份工件各有独立的攻防键、主客场训练行数、首末日期。每队还可追到上一场完成赛的 ESPN/FotMob ID、原件和索引行 SHA。[clubs.csv](/workspace/scratch/europe-native-readiness-20261125/clubs.csv)
- 完整清单含四份首登记的记录 SHA 与文件 SHA、八份压缩工件及原始权重 SHA、活动引擎版本、绝对路径，以及本次使用的 239 个文件指纹。[manifest.json](/workspace/scratch/europe-native-readiness-20261125/manifest.json)

登记席位由 PR #57 原校验器从 ESPN/FotMob 赛历和权重重建，再选取四个 `nov27_dec04` 数组。40 个 ESPN 赛事 ID 与 40 个 FotMob 赛事 ID 均唯一。每场通过冻结主客键、双源赛历、ESPN 当场摘要的联赛、主客、开球、赛前状态和明确的场地标记。时钟一律带时区。四份登记完成于北京时间 20:01:19–20:01:20；各场可用输入截止为 20:04:40–20:11:01，取登记与该场所用原件完整接收时间的最大值。原请求时间另存。最早开球为北京时间 11 月 28 日 03:30。

## 成功与先验的判据

| 角色状态 | 判据 |
|---|---|
| `SUCCESS` 成功 | 活动入口返回 51 × 51 的有限、非负、归一化矩阵，运行审计与冻结权重和请求 SHA 吻合，且双方均有本角色实际读取的攻防键和球队训练行。 |
| `PRIOR` 使用先验 | 角色返回有效矩阵，但至少一方缺少该路线的球队参数或历史，需要联赛默认输入；逐场标明主队或客队。 |
| `FAILURE` 失败 | 原入口拒绝、配对角色未执行、角色弃权或矩阵无效。数据来源或运行链的完整性冲突会直接中止核验。 |

Current 绑定 `WCPP-WEIGHTED-0.1`，活动调度实际调用其中的 `WCPP-MAIN-1.2` anchor。四联赛执行的 `baseline` 都从联赛主客均值出发，乘以双方各自拟合的攻、防系数。逐场检查实际取用的字典键和原生 `unseen_teams`，40 场均为空列表。Test 独立加载 `WCPP-ML-0.1`，以双方 Dixon–Coles 强度和工件历史构造特征，再执行 LightGBM；逐场核验真实返回的特征列与工件历史覆盖。比赛级状态取两角色中最差的一项。

新升入球队按同一顶级联赛 2025/26 与 2026/27 两季的已完成常规赛名册之差识别。赛前留档的 ESPN 2026 年记分板在两个赛季均覆盖全部 20/18/20/18 支球队。西甲为 Racing Santander、Deportivo、Málaga，德甲为 SV Elversberg、Schalke 04、SC Paderborn 07，意甲为 Venezia、Monza、Frosinone，法甲为 Troyes、Le Mans。Paderborn 与 Schalke 04 同场，故 11 队对应 10 场。这 11 队在两个角色的各自工件里每队已有 4–8 场历史，10 场双模型均成功。对工件从未见过的球队，当前活动 anchor 会在 `unseen_teams` 非空时拒绝，随后配对 Test 无法执行。本次样本覆盖的是已有本季训练记录的新队。

## 赛前证据边界

- 原始本场摘要中，80 个球队侧的球员名单条目均为 0。球队近期索引则有 76/76 支球队上一场联赛的 FT90、xG、射正和 11 人首发，对应 38 份不同的 FotMob 完成赛原件，并与 ESPN 赛果吻合。上一场数据通过原服务的补充证据模块传入。
- Test 读取封闭工件内的近期历史。西、德、法工件训练截至 10 月 9 日，意甲截至 9 月 20 日。所有 76 支球队的原生近期 xG 覆盖均为 0。西甲 20 队的原生近期过程数据各有 6 行，其余 56 队为 0。这些是特征缺项；四联赛球队攻防参数均有实际训练行。
- 38 场的 ESPN 摘要合计 63 个机构行，63 行均缺机构原生报价时刻。有两场摘要没有机构行，为皇家社会对皇家马德里（ESPN 401882698）及巴塞罗那对马德里竞技（401882700）。入口收到机构覆盖信息，`total_quote` 留空。执行回执只记录诊断状态、请求指纹与时钟。

## 本地复算

使用本机 `/workspace/football-venv/bin/python`。数据登记原提交为 `1a0024993f613cf72d8002be2eee7ed2881d2e85`，登记校验源码为 `e11bb6f8144828a84e99973d69518ae5364133d0`，实跑活动代码为 `ee250cc21bc41f2a1e04eaf8decd0b69e6d1175d`。注册表文件 SHA-256 为 `923e34fc44cda33fe965498a24a2435abb37a01a80c539108d8ec20d490bf013`。文件名和完整工件指纹均在清单内。

随时检查本地原件、输出与两轮实跑回执可执行

```bash
cd /workspace/scratch/europe-native-readiness-20261125
sha256sum --check SHA256SUMS
/workspace/football-venv/bin/python -B diagnose.py --verify "$PWD"
```

在 40 场仍全部处于未来时，以下命令会从原登记重建名单，在临时目录从原件重建球队和机构索引，并逐场重新调用活动双模型。输出写入新的临时目录。运行环境自行设置单线程、Haswell、`NPY_DISABLE_CPU_FEATURES=AVX512F` 和临时 Matplotlib 缓存。赛后可使用上面的文件与回执校验。原生预测入口按真实系统时钟要求尚未开球。

```bash
cd /workspace/scratch/europe-native-readiness-20261125
replay_dir=$(mktemp -d /tmp/europe-native-replay-XXXXXXXX)
/workspace/football-venv/bin/python -B diagnose.py --out "$replay_dir"
/workspace/football-venv/bin/python -B diagnose.py --verify "$replay_dir"
for file in fixtures.csv fixtures.jsonl clubs.csv manifest.json; do
  cmp "$file" "$replay_dir/$file" || exit 1
done
```

首轮运行时间为北京时间 20:31:23–20:31:34，第二轮为 20:31:55–20:32:07。两轮回执均保留每场的真实调用起止和 Current/Test 引擎生成时间。回执关联同一份诊断清单，小数精度完整的 UTC 时间可在原件内核查。[首轮回执](/workspace/scratch/europe-native-readiness-20261125/execution.json) · [第二轮回执](/workspace/scratch/europe-native-readiness-20261125/repeat-execution.json)
