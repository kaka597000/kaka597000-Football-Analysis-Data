"""Reconstruct the first-window model requests exclusively from the local prematch captures."""
import gzip
import hashlib
import json
import math
import shutil
import subprocess
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from tempfile import TemporaryDirectory

DATA = Path('/workspace/scratch/europe-window-data/workspace-updates/20261125-four-league-windows')
INTAKE = Path('/workspace/scratch/europe-stage-team-intake-20261125')
VERIFY_SOURCE = Path('/workspace/scratch/europe-window-source')
RUNTIME = Path('/workspace/Football-Analysis/runtime')
REGISTRY = Path('/workspace/WCPP/runtime/active-model.json')
DATA_PIN = '1a0024993f613cf72d8002be2eee7ed2881d2e85'
VERIFY_PIN = 'e11bb6f8144828a84e99973d69518ae5364133d0'
WINDOW = 'nov27_dec04'
SIZES = {'esp.1': (12, 20), 'ger.1': (9, 18), 'ita.1': (10, 20), 'fra.1': (9, 18)}
SIDES = ('home', 'away')
ROLES = ('current', 'test')


def require(test, detail):
    if not test:
        raise ValueError(detail)


def sha(body):
    return hashlib.sha256(body).hexdigest()


def objsha(obj):
    return sha(json.dumps(obj, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode())


def read(path):
    return json.loads(path.read_bytes())


def clock(value):
    d = datetime.fromisoformat(value.replace('Z', '+00:00'))
    require(d.utcoffset() is not None, 'missing timezone')
    return d.astimezone(timezone.utc)


def stamp(d):
    return d.isoformat().replace('+00:00', 'Z')


def index(seq, key):
    result = {}
    for item in seq:
        k = key(item)
        require(k not in result, f'duplicate input key {k}')
        result[k] = item
    return result


def git(root, *args):
    return subprocess.check_output(['git', '--no-optional-locks', '-C', str(root), *args], text=True).strip()


class Files:
    def __init__(self):
        self.hashes = {}

    def add(self, path):
        name = str(path.absolute())
        if name not in self.hashes:
            self.hashes[name] = sha(path.read_bytes())
        return self.hashes[name]

    def pinned(self, path):
        # Authenticate original PR #57 objects even if another task advances its branch.
        root = DATA.parents[1]
        rel = path.relative_to(root).as_posix()
        require(git(root, 'hash-object', '--no-filters', str(path)) == git(root, 'rev-parse', DATA_PIN + ':' + rel),
                f'file differs from frozen PR #57 blob: {rel}')
        return self.add(path)


def verify_upstream(env, files):
    verifier = DATA / 'verify_registrations.py'
    for p in (verifier, DATA / 'data/verify_calendars.py', DATA / 'data/source-manifest.json', DATA / 'data/fixtures.json'):
        files.pinned(p)
    # The verifier also reconstructs the complete calendars, protocol, original track and slot receipts.
    require(git(VERIFY_SOURCE, 'rev-parse', 'HEAD') == VERIFY_PIN, 'registration verifier source pin')
    subprocess.run([sys.executable, '-B', str(verifier)], cwd=DATA,
                   env=dict(env, PYTHONPATH=str(VERIFY_SOURCE / 'runtime')), check=True, stdout=subprocess.DEVNULL)
    script = INTAKE / 'build_team_evidence.py'
    files.add(script)
    with TemporaryDirectory(prefix='readiness-intake-') as tmp:
        scratch = Path(tmp)
        for name in ('inputs', 'raw'):
            (scratch / name).symlink_to(INTAKE / name, target_is_directory=True)
        (scratch / 'derived').mkdir()
        shutil.copyfile(script, scratch / script.name)
        subprocess.run([sys.executable, '-B', str(scratch / script.name)], cwd=scratch, env=env,
                       check=True, stdout=subprocess.DEVNULL)
        for name in ('team-recent-match-index.json', 'espn-sportsbook-quotes.json'):
            require(sha((scratch / 'derived' / name).read_bytes()) == files.add(INTAKE / 'derived' / name),
                    f'raw rebuild differs: {name}')


def source(url, start, end, digest):
    require(url.startswith('https://') and clock(start) <= clock(end), 'invalid capture source or clock')
    # The service accepts a query observation time. Here it is when the entire local response was available.
    return dict(source_url=url, request_started_at=start, query_time=end, known_at=end, sha256=digest)


def calendar(code, files):
    tag = code.split('.')[0]
    paths = {'ESPN': ('espn-season', 'espn', tag + '-2026.json'),
             'FotMob': ('calendar', 'fotmob', tag + '-2026-2027.json')}
    entries, sources = {}, {}
    for provider, (directory, archive_dir, name) in paths.items():
        path = INTAKE / 'inputs' / directory / name
        meta_path = path.with_suffix('.meta.json')
        files.add(meta_path)
        m = read(meta_path)
        h = files.add(path)
        archive = DATA / 'data/raw' / archive_dir / (name + '.gz')
        files.pinned(archive)
        require(m['competition'] == code and m['http_status'] == 200 and h == m['sha256']
                and sha(gzip.decompress(archive.read_bytes())) == h, f'{code} {provider} calendar bytes')
        sources[provider] = source(m['url'], m['observed_request_start_utc'], m['observed_response_end_utc'], h)
        entries[provider] = read(path)

    board = entries['ESPN']
    require(board['leagues'][0]['slug'] == code, 'ESPN league slug')
    participation = defaultdict(set)
    completed = Counter()
    for event in board['events']:
        detail = event['competitions'][0]
        status = detail['status']['type']
        if status.get('completed') and status['name'] == 'STATUS_FULL_TIME':
            require(clock(event['date']) < clock(sources['ESPN']['known_at']), 'late season history')
            year = event['season']['year']
            participation[year].update(c['team']['id'] for c in detail['competitors'])
            completed[year] += 1
    require(set(participation) == {2025, 2026} and all(len(v) == SIZES[code][1] for v in participation.values()),
            f'{code} incomplete top-tier membership')
    fm = entries['FotMob']
    require(fm['details']['selectedSeason'] == '2026/2027', 'FotMob season')
    return (sources, index(board['events'], lambda e: str(e['id'])),
            index(fm['fixtures']['allMatches'], lambda e: str(e['id'])), participation,
            {str(y): {'clubs': len(participation[y]), 'completed_matches_in_capture': completed[y]}
             for y in sorted(participation)})


def registration(code, files):
    directory = DATA / code / 'registration'
    ref_path = directory / 'plan.json'
    files.pinned(ref_path)
    ref = read(ref_path)
    path = directory / ref['file']
    file_hash = files.pinned(path)
    r = read(path)
    require(r['freeze_id'] == ref['id'] and r['recorded_at'] == ref['recorded_at'] and
            r['revision'] == 1 and r['previous_sha256'] is None and r['evaluation_slot'] == 'FIRST_PREMATCH'
            and r['track'] == code.replace('.', '-') + '-comprehensive-windows-20261125-registration'
            and ref['sha256'] == r['record_sha256'] == objsha({k: v for k, v in r.items() if k != 'record_sha256'}),
            f'{code} original registration')
    identity = r['payload']['identity']
    slots = identity['slates'][WINDOW]
    require(len(slots) == len(set(slots)) == SIZES[code][0], 'first-window slate size')
    window = next(w for w in identity['protocol']['windows'] if w['name'] == WINDOW)
    for mid in slots:
        f = r['payload']['fixtures'][mid]
        require(f['match_id'] == mid and f['cohort'] == code and f['stage'] == 'regular'
                and clock(window['from']) <= clock(f['kickoff_at']) < clock(window['until'])
                and clock(ref['recorded_at']) < clock(f['kickoff_at']), f'{mid} slot outside registration')
    return r, dict(id=ref['id'], record_sha256=ref['sha256'], file_sha256=file_hash,
                   path=str(path), recorded_at=ref['recorded_at'], track=r['track'], window=window)


def models(code, reg, registry, registry_sha, files):
    identity = reg['payload']['identity']['model_inputs']
    require(identity['registry_sha256'] == registry_sha, 'registration/active registry mismatch')
    route = registry['models'][code]
    notes, fitted = {}, {}
    for role, prefix in [('current', ''), ('test', 'test_')]:
        ref = identity['native_models'][role.title()]
        path = Path(route[prefix + 'artifact_path'])
        archive = DATA / 'model-evidence' / code / (role + '.json.gz')
        gz_hash = files.pinned(archive)
        raw = gzip.decompress(archive.read_bytes())
        h = files.add(path)
        require(h == sha(raw) == ref['sha256'] == route[prefix + 'artifact_sha256']
                and path.name == ref['artifact_file'], f'{code} {role} bound weights')
        artifact = json.loads(raw)
        native = artifact['anchor'] if role == 'current' else artifact
        require(artifact['version'] == ref['version'] and native['cohort'] == code, 'weight version/cohort')
        if role == 'current':
            require(route.get('current_engine', 'legacy_weighted_anchor') == 'legacy_weighted_anchor'
                    and native['execution_recipe'] == 'baseline' and native['core']['baseline']['method'] == 'v01_baseline',
                    'unreviewed Current recipe')
        else:
            require(not route.get('test_engine') and route['test_version'] == native['version'] == 'WCPP-ML-0.1'
                    and native['booster_model'] and 0 < native['alpha'] <= 1, 'unreviewed Test recipe')
        require(all(h['date'] <= native['train_end'] and h['cohort'] == code for h in native['history']),
                'invalid closed training history')
        fitted[role] = native
        notes[role] = dict(artifact_path=str(path), resolved_artifact_path=str(path.resolve()),
                           archive_path=str(archive), archive_sha256=gz_hash, artifact_sha256=h,
                           bound_version=ref['version'], native_version=native['version'],
                           native_object_sha256=objsha(native), native_code_hash=native['code_hash'],
                           train_end=native['train_end'], observed_at=native['observed_at'], built_at=native['built_at'],
                           recipe=native.get('execution_recipe', 'dc_lightgbm_poisson_residual'))
    return fitted, notes


def club(code, prior, fitted, seasons, board, fm, sources, files):
    eid, fid = prior['espn_team_id'], prior['fotmob_team_id']
    key = 'espn:' + eid
    require(eid in seasons[2026], f'{code} absent from current roster: {key}')
    pid = prior['latest_league_match_id_fotmob']
    previous = fm[pid]
    side = prior['team_side_in_latest_match']
    ep = board[prior['espn_crosscheck_match_id']]['competitions'][0]
    date = clock(prior['latest_match_utc'])
    require(str(previous[side]['id']) == fid and previous['status']['reason']['short'] == 'FT'
            and ep['status']['type']['name'] == 'STATUS_FULL_TIME' and clock(ep['date']) == date
            and next(t['team']['id'] for t in ep['competitors'] if t['homeAway'] == side) == eid
            and prior['ft90_status'] == 'FT' and not prior['awarded'] and prior['espn_crosscheck_result_matches_fotmob']
            and prior['selection_calendar_sha256'] == sources['FotMob']['sha256']
            and prior['espn_crosscheck_source_sha256'] == sources['ESPN']['sha256'], f'{key} prior identity')
    path = INTAKE / 'raw/fotmob-details' / (pid + '.json')
    meta_path = path.with_suffix('.meta.json')
    files.add(meta_path)
    meta = read(meta_path)
    require(path.relative_to(INTAKE).as_posix() == prior['fotmob_raw_file'] and meta['match_id'] == pid
            and meta['http_status'] == 200 and files.add(path) == meta['sha256'] == prior['fotmob_source_sha256']
            and meta['query_time_utc'] == prior['fotmob_query_time_utc']
            and meta['retrieval_time_utc'] == prior['fotmob_retrieval_time_utc']
            and date < clock(meta['query_time_utc']), f'{key} prior capture')
    require(prior['starter_count'] == len(set(x['player_id'] for x in prior['starters'])) == 11
            and all(math.isfinite(float(prior[k])) for k in ('xg_for','xg_against','shots_on_target_for','shots_on_target_against')),
            'invalid completed-match process evidence')
    info = dict(competition=code, espn_id=key, fotmob_id=fid, name=prior['team_espn_name'],
                new_to_top_tier_2026_27=eid not in seasons[2025], recent_ft_fotmob_id=pid,
                recent_ft_espn_id=prior['espn_crosscheck_match_id'], recent_ft_kickoff=prior['latest_match_utc'],
                recent_ft_raw_sha256=meta['sha256'], recent_index_row_sha256=objsha(prior))
    for role, a in fitted.items():
        history = sorted((h for h in a['history'] if key in (h['home'], h['away'])), key=lambda h: (h['date'],h['match_id']))
        if role == 'current':
            row = a['core']['baseline']['teams'].get(key, {})
            in_attack = 'attack' in row and math.isfinite(row['attack'])
            in_defence = 'concede' in row and math.isfinite(row['concede'])
        else:
            strength = a['core']['long']
            in_attack = key in strength['attack'] and math.isfinite(strength['attack'][key])
            in_defence = key in strength['defence'] and math.isfinite(strength['defence'][key])
        info[role] = dict(attack_key=in_attack, defence_key=in_defence, training_matches=len(history),
                          home_matches=sum(h['home'] == key for h in history), away_matches=sum(h['away'] == key for h in history),
                          first_history_date=history[0]['date'] if history else None,
                          last_history_date=history[-1]['date'] if history else None)
        if role == 'test':
            recent = history[-6:]
            info[role].update(recent_native_rows=len(recent), recent_native_xg_rows=sum(bool(h.get('xg_evidence')) for h in recent),
                              recent_native_process_rows=sum(bool(h.get('process_evidence')) for h in recent))
    return info


def module(mid, cutoff, summary, facts, sources, status='available'):
    return dict(match_id=mid, as_of=cutoff, summary=summary, facts=facts, sources=sources, status=status)


def fixture_inputs(row, registered, freeze, slot, prior, clubs, quotes, meta, calendars, board, fm, files):
    code, eid, fid = row['competition'], row['espn_source_match_id'], row['fotmob_source_match_id']
    mid, ko = registered['match_id'], clock(registered['kickoff_at'])
    path = INTAKE / 'raw/espn-summaries' / (eid + '.json')
    mp = path.with_suffix('.meta.json')
    meta_hash = files.add(mp)
    h = files.add(path)
    require(read(mp) == meta and h == meta['sha256'] and path.stat().st_size == meta['bytes']
            and meta['http_status'] == 200 and meta['competition'] == code and meta['event_id'] == eid
            and meta['url'] == f'https://site.api.espn.com/apis/site/v2/sports/soccer/{code}/summary?event={eid}',
            f'{mid} summary provenance')
    raw = read(path)
    head = raw['header']
    require(len(head['competitions']) == 1, 'ambiguous ESPN summary event')
    e, b, fp = head['competitions'][0], board[eid], fm[fid]
    require(mid == 'espn:' + eid and row['stage'] == 'regular season' and row['w1_match'] and not row['w2_match']
            and row['identity_match'] and row['kickoff_exact_match'] and row['espn_time_valid']
            and row['fotmob_time_valid_or_nonplaceholder'] and row['espn_status'] == 'STATUS_SCHEDULED'
            and row['fotmob_status'] == 'scheduled' and head['id'] == e['id'] == eid and head['league']['slug'] == code
            and e['status']['type']['name'] == b['status']['type']['name'] == 'STATUS_SCHEDULED'
            and e['status']['type']['state'] == 'pre' and e['status']['type']['completed'] is False
            and not any(fp['status'].get(k) for k in ('started','finished','cancelled','awarded'))
            and all(clock(t) == ko for t in (row['kickoff_utc'], row['espn_kickoff_utc'], row['fotmob_kickoff_utc'],
                                              e['date'], b['date'], fp['status']['utcTime']))
            and type(e.get('neutralSite')) is bool
            and ('neutralSite' not in b['competitions'][0] or b['competitions'][0]['neutralSite'] == e['neutralSite']),
            f'{mid} source identity, kickoff or pre-state')
    for provider, s in calendars.items():
        sr = row['sources'][provider]
        es = source(sr['url'], sr['observed_request_start_utc'], sr['observed_response_end_utc'], sr['sha256'])
        require(es == s and sr['match_id'] == (eid if provider == 'ESPN' else fid), 'slate/calendar capture mismatch')

    players, starters = {}, {}
    participants = index(e['competitors'], lambda t: t['homeAway'])
    on_board = index(b['competitions'][0]['competitors'], lambda t: t['homeAway'])
    roster = index(raw.get('rosters', []), lambda t: t['homeAway'])
    require(set(participants) == set(on_board) == set(SIDES) and registered['home'] != registered['away'], 'competing sides')
    for side in SIDES:
        team = participants[side]['team']['id']
        require(registered[side] == clubs[side]['espn_id'] == 'espn:' + team
                and team == row['espn_' + side + '_id'] == on_board[side]['team']['id']
                and clubs[side]['fotmob_id'] == row['fotmob_' + side + '_id'] == str(fp[side]['id'])
                and eid in prior[side]['target_window_espn_event_ids'] and fid in prior[side]['target_window_fotmob_event_ids'],
                f'{mid} {side} identity')
        block = roster.get(side, {})
        if block:
            require(block['team']['id'] == team, f'{mid} squad team ID')
        entries = block.get('roster') or []
        players[side] = len(entries)
        starters[side] = sum(t.get('starter') is True for t in entries)

    summary = source(meta['url'], meta['query_time_utc'], meta['retrieval_time_utc'], h)
    recent_sources = []
    for side in SIDES:
        v = prior[side]
        recent_sources.append(source(v['fotmob_url'], v['fotmob_query_time_utc'], v['fotmob_retrieval_time_utc'],
                                     v['fotmob_source_sha256']))
    sources = list({s['source_url']: s for s in [*calendars.values(), summary, *recent_sources]}.values())
    cutoff = max(clock(freeze['recorded_at']), *(clock(s['known_at']) for s in sources))
    require(cutoff < ko and all(clock(v['latest_match_utc']) < cutoff for v in prior.values()), 'late input')
    require(len(quotes) == meta['odds_rows'] == len(raw.get('odds', []))
            and sorted(q['provider_id'] for q in quotes) == sorted(o['provider']['id'] for o in raw.get('odds', []))
            and all(q['source_sha256'] == h and q['event_id_espn'] == eid and q['competition'] == code
                    and q['retrieval_time_utc'] == meta['retrieval_time_utc'] for q in quotes), 'quote inventory')
    providers = [q['bookmaker'] for q in quotes]
    quoted_times = sum(q['provider_quote_time_utc'] is not None for q in quotes)
    cut = stamp(cutoff)
    request = dict(registered, competition=code, phase='PreMatch', score_basis='regulation_90', identity_verified=True,
                   neutral=e['neutralSite'], cutoff_at=cut, sources=sources)
    modules = {}
    for name, fields in [('form', ('latest_match_utc','latest_league_match_id_fotmob','team_side_in_latest_match')),
                         ('xg', ('xg_for','xg_against')), ('shots', ('shots_on_target_for','shots_on_target_against'))]:
        facts = {side: {k: prior[side][k] for k in fields} for side in SIDES}
        modules[name] = module(mid, cut, 'Latest completed same-league match per team', facts, recent_sources)
    modules['lineup'] = module(mid, cut, 'Previous-match XI and target ESPN squad coverage',
                               {side: dict(previous_starter_count=prior[side]['starter_count'], previous_formation=prior[side]['formation'],
                                           target_listed_players=players[side], target_listed_starters=starters[side]) for side in SIDES},
                               [*recent_sources, summary], 'partial')
    modules['market'] = module(mid, cut, 'Local target ESPN summary bookmaker coverage',
                               dict(bookmakers=providers, provider_timestamps=quoted_times), [summary],
                               'partial' if quotes else 'unknown')
    request['analysis_modules'] = modules
    evidence = dict(registration_id=freeze['id'], registration_sha256=freeze['record_sha256'], registration_slot=slot,
                    match_id=mid, fotmob_match_id=fid, competition=code, kickoff_utc=stamp(ko), cutoff_utc=cut,
                    neutral=e['neutralSite'], identity='FROZEN_ESPN_AND_FOTMOB_HOME_AWAY_KICKOFF_AGREE',
                    slate_row_sha256=objsha(row), summary_path=str(path), summary_sha256=h, summary_meta_sha256=meta_hash,
                    summary_requested_utc=meta['query_time_utc'], summary_received_utc=meta['retrieval_time_utc'],
                    target_roster_entries=players, target_listed_starters=starters,
                    bookmakers=providers, provider_quote_timestamps=quoted_times, quote_row_sha256=[objsha(q) for q in quotes],
                    fixture_sha256=objsha(request), teams={side: clubs[side]['espn_id'] for side in SIDES},
                    prior_source_sha256={side: clubs[side]['recent_ft_raw_sha256'] for side in SIDES})
    return request, evidence
