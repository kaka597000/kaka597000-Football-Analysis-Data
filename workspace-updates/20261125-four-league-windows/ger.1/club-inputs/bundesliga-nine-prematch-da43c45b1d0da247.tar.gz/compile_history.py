from independent_espn import *
from decimal import Decimal
from collections import Counter
from datetime import timezone
import math

# Clubs outside the 18-team window, checked against the named opponents in both
# original calendars and match reports. IDs are scoped to their providers.
OTHER_CLUBS = {
    '8295': '4471',  # Karlsruher SC
    '8480': '7017',  # Dynamo Dresden
    '8262': '3812',  # SV Darmstadt 98
    '9906': '1068',  # Atlético Madrid
    '8188': '10382', # 1. FC Magdeburg
    '9911': '121',   # VfL Bochum
    '8637': '432',   # Galatasaray
    '9752': '997',   # Trabzonspor
    '8721': '138',   # VfL Wolfsburg
    '8588': '175',   # Lens
    '8456': '382',   # Manchester City
    '9826': '384',   # Crystal Palace
    '8150': '7884',  # Holstein Kiel
    '94941': '6631', # SG Sonnenhof Großaspach
    '9825': '359',   # Arsenal
    '8603': '244',   # Real Betis
    '8592': '176',   # Marseille
    '8165': '269',   # 1. FC Nürnberg
}

def ref(key):
    m=meta(key)
    return {k:m.get(k) for k in ('key','url','requested_utc','received_utc','sha256','raw_path')}
def scoreboard(g,league,side_map,ids,records):
    ft=str(g['id']); utc=instant(g['status']['utcTime'])
    if league==54:
        c=next(c for c in records if instant(c['date'])==utc and all(str(t['id'])==side_map[str(g[t['homeAway']]['id'])] for t in c['competitors']))
        src='espn-season'
    else:
        e,_=ids[ft];src='espn-historical-'+e['id'];d=content(src);c=d['header']['competitions'][0]
        assert str(c['id'])==e['id'] and instant(c['date'])==utc and str(d['header']['id'])==e['id']
    es={s:next(t for t in c['competitors'] if t['homeAway']==s) for s in ('home','away')}
    assert all(str(es[s]['id'])==side_map[str(g[s]['id'])] for s in ('home','away'))
    status=c['status']['type']
    assert status['completed'] and status['state']=='post'
    if status['name']=='STATUS_FULL_TIME':
        score=[int(es[s]['score']) for s in ('home','away')];basis='ESPN full time, regulation'
    elif status['name'] in ('STATUS_FINAL_PEN','STATUS_FINAL_AET','STATUS_FULL_TIME_EXTRA_TIME'):
        score=[sum(int(x['displayValue']) for x in es[s]['linescores'][:2]) for s in ('home','away')]
        assert all(len(es[s]['linescores'])>=2 for s in ('home','away'));basis='sum of first two ESPN period linescores'
    else:score=None;basis=status['name']
    return dict(espn_event_id=str(c['id']),home_id=str(es['home']['id']),away_id=str(es['away']['id']),
                home_name=es['home']['team']['displayName'],away_name=es['away']['team']['displayName'],
                status=status['name'],ft90=score,basis=basis,source=ref(src))
def period_stats(period,key):
    rows=[r for grp in period.get('stats',[]) for r in grp['stats'] if r.get('key')==key]
    values=[]
    for i in (0,1):
        observed={Decimal(str(row['stats'][i])) for row in rows if row['stats'][i] not in (None,'','-')}
        if len(observed)>1:raise ValueError('conflicting measured stat: '+key)
        value=next(iter(observed),None)
        if value is not None and (not value.is_finite() or value<0 or (key=='ShotsOnTarget' and int(value)!=value)):raise ValueError(key)
        values.append(value)
    return values
def history_game(g,ids,teams,board):
    mid=str(g['id']);src='fotmob-history-'+mid;d=content(src);gen=d['general'];h=d['header'];status=h['status'];lg=g['tournament']['leagueId']
    assert str(gen['matchId'])==mid and lg in (gen.get('parentLeagueId'),gen.get('leagueId'))
    assert [str(r['id']) for r in h['teams']]==[str(g[s]['id']) for s in ('home','away')]
    assert instant(status['utcTime'])==instant(g['status']['utcTime']) and status['finished'] and not status.get('awarded') and not status.get('cancelled')
    assert instant(meta(src)['received_utc'])>instant(status['utcTime'])
    regular=status.get('reason',{}).get('short')=='FT'
    if regular:
        score=[t['score'] for t in h['teams']];periods=['All'];basis='FotMob finished FT header'
    else:
        full=[e for e in d['content']['matchFacts']['events']['events'] if e.get('type')=='Half' and e.get('halfStrShort')=='FT' and e.get('time')==90]
        assert len(full)==1
        score=[full[0]['homeScore'],full[0]['awayScore']];periods=['FirstHalf','SecondHalf'];basis='FotMob regulation-end event; first and second half stats only'
    assert all(type(v) is int and v>=0 for v in score)
    independent=scoreboard(g,lg,teams,ids,board)
    fields={}
    for key,name in [('expected_goals','xg'),('ShotsOnTarget','sot')]:
        parts=[period_stats((d['content'].get('stats',{}).get('Periods',{}).get(p) or {}),key) for p in periods]
        fields[name]=[None if any(pair[i] is None for pair in parts) else (float if name=='xg' else int)(sum(pair[i] for pair in parts)) for i in (0,1)]
    players={}
    for side in ('home','away'):
        team=d['content'].get('lineup',{}).get(side+'Team',{});tid=str(g[side]['id'])
        if team:assert str(team['id'])==tid
        side_players=[]
        for kind in ('starters','subs'):
            for pl in team.get(kind,[]):
                st=(d['content'].get('playerStats') or {}).get(str(pl['id'])) or {}
                if st:assert str(st['teamId'])==tid
                mins=[item['stat']['value'] for group in st.get('stats',[]) for item in group.get('stats',{}).values() if item.get('key')=='minutes_played']
                side_players.append(dict(fotmob_id=str(pl['id']),opta_id=pl.get('optaId'),name=pl.get('name'),starter=kind=='starters',
                                         minutes_played_full_match=mins[0] if mins else None))
        players[side]=side_players
    venue=(d['content']['matchFacts'].get('infoBox') or {}).get('Stadium') or {}
    return dict(fotmob_id=mid,kickoff_utc=status['utcTime'],competition=g['tournament']['name'],fotmob_league_id=lg,
        home_id=str(h['teams'][0]['id']),away_id=str(h['teams'][1]['id']),home=h['teams'][0]['name'],away=h['teams'][1]['name'],
        provider_final_label=status['reason']['short'],ft90=score,espn=independent,score_crosschecked=score==independent['ft90'],ft90_basis=basis,
        periods=periods,venue={k:venue.get(k) for k in ('name','city','country')},players=players,source=ref(src),**fields)
def compile_data():
    teams,fixtures=selection();known={tid:str(t['espn_team_id']) for tid,t in teams.items()};ids=find_ids()
    assert not set(known).intersection(OTHER_CLUBS)
    known.update(OTHER_CLUBS)
    board=[e['competitions'][0] for e in content('espn-season')['events']]
    unique={mid:history_game(g,ids,known,board) for mid,g in fixtures.items()}
    data={}
    for g in targets():
        for side in ('home','away'):
            tid=str(g['fotmob_'+side+'_id']);team=teams[tid];kick=instant(g['kickoff_utc'])
            sched=content('fotmob-team-'+tid)['fixtures']['allFixtures']['fixtures']
            done=sorted([r for r in sched if r['status'].get('finished') and not r['status'].get('awarded') and not r['status'].get('cancelled') and 'friendl' not in r['tournament']['name'].lower() and instant(r['status']['utcTime'])<SNAP],key=lambda r:instant(r['status']['utcTime']))
            projected=[r for r in team['intermediate']];last=instant(done[-1]['status']['utcTime'])
            load=dict(last_played_fotmob_id=str(done[-1]['id']),last_completed_kickoff_utc=done[-1]['status']['utcTime'],
                kickoff_gap_from_last_completed_hours=(kick-last).total_seconds()/3600,
                scheduled_before_target=[{'fotmob_id':str(r['id']),'competition':r['tournament']['name'],'kickoff_utc':r['status']['utcTime'],
                      'home':r['home']['name'],'away':r['away']['name'],'source_status':r['status']} for r in projected],
                projected_kickoff_gap_hours=(kick-(instant(projected[-1]['status']['utcTime']) if projected else last)).total_seconds()/3600,
                completed_matches_in_7_14_28_days_asof={str(n):sum(0 < (SNAP-instant(r['status']['utcTime'])).total_seconds()<=n*86400 for r in done) for n in (7,14,28)},
                additional_club_friendlies_in_history_span=[dict(fotmob_id=str(r['id']),kickoff_utc=r['status']['utcTime'],home=r['home']['name'],away=r['away']['name']) for r in team['friendlies_in_span']],
                team_calendar=ref('fotmob-team-'+tid))
            scopes={}
            for scope,mids in team['fixture_lists'].items():
                rows=[]
                for n,mid in enumerate(mids,1):
                    r=unique[mid];k=instant(r['kickoff_utc']);i=0 if tid==r['home_id'] else 1
                    prev=[e for e in done if instant(e['status']['utcTime'])<k]
                    rows.append(dict(recency=n,fotmob_id=mid,espn_event_id=r['espn']['espn_event_id'],date_utc=r['kickoff_utc'][:10],kickoff_utc=r['kickoff_utc'],
                        competition=r['competition'],team_side=('home','away')[i],opponent=(r['away'],r['home'])[i],opponent_fotmob_id=(r['away_id'],r['home_id'])[i],
                        ft90_for=r['ft90'][i],ft90_against=r['ft90'][1-i],score_crosschecked=r['score_crosschecked'],
                        xg_for=r['xg'][i],xg_against=r['xg'][1-i],sot_for=r['sot'][i],sot_against=r['sot'][1-i],
                        preceding_competitive_kickoff_gap_hours=(k-instant(prev[-1]['status']['utcTime'])).total_seconds()/3600 if prev else None,
                        source=r['source'],score_source=r['espn']['source']))
                nums={}
                for name in ('ft90_for','ft90_against','xg_for','xg_against','sot_for','sot_against'):
                    vs=[r[name] for r in rows if r[name] is not None]
                    nums[name]=dict(available=len(vs),total=round(sum(vs),3) if vs else None,mean=round(sum(vs)/len(vs),3) if vs else None)
                scopes[scope]=dict(matches=rows,five_match_metrics=nums)
            workload={}
            for mid in team['fixture_lists']['all_competitions']:
                r=unique[mid];s='home' if r['home_id']==tid else 'away'
                for p in r['players'][s]:
                    entry=workload.setdefault(p['fotmob_id'],dict(name=p['name'],opta_id=p['opta_id'],starts=0,minutes_with_data=0,minutes_full_match=0))
                    entry['starts']+=p['starter']
                    if p['minutes_played_full_match'] is not None:
                        entry['minutes_with_data']+=1;entry['minutes_full_match']+=p['minutes_played_full_match']
            data[tid]=dict(fotmob_team_id=tid,espn_team_id=known[tid],team=team['name'],target_event_id=g['espn_source_match_id'],
                target_fotmob_id=g['fotmob_source_match_id'],load=load,player_workload_last_five=workload,**scopes)
    return unique,data
if __name__=='__main__':
    unique,teams=compile_data()
    save(ROOT/'history-fixtures.json',unique);save(ROOT/'team-last-five.json',teams)
    print('unique',len(unique),'dual scores',sum(r['score_crosschecked'] for r in unique.values()),'xg/SOT',Counter((None not in r['xg'],None not in r['sot']) for r in unique.values()))
