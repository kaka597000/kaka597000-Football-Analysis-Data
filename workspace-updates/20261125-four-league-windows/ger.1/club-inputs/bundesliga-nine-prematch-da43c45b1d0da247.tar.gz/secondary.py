from public_pages import *
from concurrent.futures import ThreadPoolExecutor
def kicker():
    urls=[h for h,t in distinct_links('kicker-md11') if '/spielinfo' in h and '2026-bundesliga-' in h]
    if len(urls)!=9:raise ValueError(urls)
    for url in urls:
        kid=re.search(r'-(\d+)/spielinfo',url).group(1)
        get('kicker-info-'+kid,url)
        suffixes=[h for h,t in distinct_links('kicker-info-'+kid) if h.endswith('/aufstellung') and kid in h]
        for u in suffixes[:1]:get('kicker-lineup-'+kid,u)
def dfl():
    for i in range(1,10):
        p=page('dfl-game-'+str(i));ds=json.loads(next(v for a,v in p.scripts if a.get('id')=='ng-state'))
        url=next(val['u'] for val in ds.values() if isinstance(val,dict) and val.get('u','').split('?')[0].endswith('/lineup.json'))
        get('dfl-api-'+str(i),url)
if __name__=='__main__':
    with ThreadPoolExecutor(max_workers=2) as p:list(p.map(lambda f:f(),[kicker,dfl]))
