from compile_history import ref
from evidence import *
from fractions import Fraction
from urllib.parse import unquote
import re

def american(value):
    if value is None:return None
    a=float(str(value).replace('−','-'))
    if abs(a)<100:raise ValueError(('american',value))
    return round(1+(a/100 if a>0 else 100/(-a)),6)
def fractional(value):
    if value is None:return None
    return round(1+float(Fraction(str(value))),6)
def quoted(o,name):
    if 'value' in o and name=='draw':return o.get('value')
    return (o.get('odds') or {}).get('value')
def market(o):
    book=o['provider'];dk=str(book['id'])=='100';b=(o.get('bettingOdds') or {}).get('teamOdds',{})
    one={}; prices={}; ids={}
    for name in ('home','draw','away'):
        v=o.get(name+('Odds' if name=='draw' else 'TeamOdds')) or {}
        if dk:
            q=v.get('moneyLine')
            if q is None:q=((o.get('moneyline') or {}).get(name,{}).get('close') or {}).get('odds')
            one[name]=dict(american=q,decimal=american(q))
        else:
            key='preMatchFullTimeResult'+name.title();line=b.get(key) or {}
            vq=quoted(v,name);q=line.get('value') or v.get('summary') or (v.get('odds') or {}).get('summary')
            one[name]=dict(fractional=q,decimal=float(vq) if vq is not None else fractional(q))
            ids[name]=line.get('oddId')
        prices[name]=one[name]['decimal']
    if dk:
        line=o.get('overUnder')
        for name in ('over','under'):
            value=o.get(name+'Odds')
            if value is None:value=((o.get('total') or {}).get(name,{}).get('close') or {}).get('odds')
            one[name]=dict(american=value,decimal=american(value))
    else:
        line=(b.get('preMatchOverUnderHandicap') or {}).get('value')
        for name in ('over','under'):
            obj=b.get('preMatchGoalLine'+name.title()) or {};value=obj.get('value')
            one[name]=dict(fractional=value,decimal=fractional(value));ids[name]=obj.get('oddId')
    one['total_line']=float(line) if line not in (None,'') else None
    event_id=None
    if dk:
        rawurl=str(o.get('moneyline',{}).get('home',{}).get('close',{}).get('link',{}).get('href',''))
        mt=re.search(r'sportsbook\.draftkings\.com/event/(\d+)',unquote(rawurl));event_id=mt[1] if mt else None
    else:
        url=(b.get('preMatchFullTimeResultHome') or {}).get('betSlipUrl','')
        mt=re.search(r'[?&]bs=(\d+)-',unquote(url));event_id=mt[1] if mt else None
    return dict(bookmaker=book['name'],espn_bookmaker_id=str(book['id']),bookmaker_event_id=event_id,
                bookmaker_selection_ids=ids,regulation_markets=one,provider_market_as_of=None,bookmaker_own_updated_at=None,
                h2h_complete=all(v is not None for v in prices.values()),total_complete=one['total_line'] is not None and all(one[s]['decimal'] is not None for s in ('over','under')))
def compile_data():
    signed=read(ROOT/'signed-first-index.json');data={}
    for g in targets():
        eid=g['espn_source_match_id'];pair=[]
        original=signed['espn:'+eid];old_keys={e['raw_key'] for e in original['market_evidence'].values()}
        for original_key in old_keys:
            if not original_key.startswith('r5-board'):continue
            c=next(e for e in content(original_key)['events'] if e['id']==eid)['competitions'][0]
            assert instant(c['date'])==instant(g['kickoff_utc']) and all(str(t['id'])==str(g['espn_'+t['homeAway']+'_id']) for t in c['competitors'])
            orig=next(market(o) for o in c['odds'] if o['provider']['name']==original['bookmaker'])['regulation_markets']
            for side in ('home','draw','away'):assert abs(orig[side]['decimal']-original['prices']['h2h'][side])<1e-6
            assert orig['total_line']==original['prices']['total']['line']
            for side in ('over','under'):assert abs(orig[side]['decimal']-original['prices']['total'][side])<1e-6
        for stage in ('first','refresh','core','handoff'):
            k='espn-'+stage+'-'+eid;doc=content(k);m=meta(k)
            assert instant(m['received_utc'])<instant(g['kickoff_utc'])
            if stage=='core':
                odds=doc['items']
                assert all('/events/'+eid+'/competitions/'+eid+'/odds/' in o['$ref'] for o in odds)
            else:
                c=doc['header']['competitions'][0];assert c['id']==eid==doc['header']['id'] and instant(c['date'])==instant(g['kickoff_utc'])
                assert all(str(t['id'])==str(g['espn_'+t['homeAway']+'_id']) for t in c['competitors']) and c['status']['type']['state']=='pre'
                odds=doc['odds']
            pair.append(dict(stage={'first':'archived_Nov25_ESPN_summary','refresh':'new_ESPN_summary','core':'new_ESPN_core','handoff':'handoff_ESPN_summary'}[stage],
                             source=ref(k),markets=[market(o) for o in odds]))
        data[eid]=dict(signed_R5=original,provider_reads=pair)
    return data
if __name__=='__main__':
    out=ROOT/'markets.json';tmp=out.with_suffix('.new');save(tmp,compile_data());tmp.replace(out)
