"""Verify this fixed prematch evidence package using local bytes only (Python 3.10+)."""
import csv
import json
import sys
from decimal import Decimal
from pathlib import Path
from tempfile import TemporaryDirectory
from urllib.parse import urlsplit

from evidence import ROOT, content, digest, instant, raw, read, targets
from odds_archive import canon

REGISTRATION = '0b34a327ba0ca6e52d888af82a73fe4f4d8335c3227c48e38a4896a419a27035'
REGISTRATION_FILE = 'b688993f055b195bcae3de843c9c4a9da000f98c7b1d0c9c8302ae7293095a36'


def deny_network(event, args):
    if event.startswith('socket.'):
        raise RuntimeError('Offline verification attempted network access')


def records(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def csvrows(name):
    with (ROOT/name).open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))


def verify_sources():
    sources = records(ROOT/'source-manifest.jsonl')
    assert sources == [read(p) for p in sorted((ROOT/'sources').glob('*.json'))]
    by_key = {m['key']: m for m in sources}
    assert len(by_key) == len(sources)
    expected_raw = set()
    for m in sources:
        assert urlsplit(m['url']).scheme == 'https' and urlsplit(m['url']).hostname
        if 'raw_path' in m:
            assert m['raw_path'] == 'raw/' + m['sha256'] + '.gz' and m['http_status'] is not None
            raw(m)
            expected_raw.add(ROOT/m['raw_path'])
        else:
            assert m['http_status'] is None and m['error']
        if m['mode'] == 'signed_R5_source_bytes':
            assert not m['requested_utc']
            if not m['received_utc']:
                q = m['original_query_record']
                assert q['sha256'] == m['sha256'] and q['query_observed_at'] == m['original_observed_at_utc']
                assert q['query_time_basis']
        else:
            assert instant(m['requested_utc']) <= instant(m['received_utc'])
    assert expected_raw == set((ROOT/'raw').glob('*.gz'))
    return by_key


def verify_identity_and_firsts(sources):
    gset = targets()
    rg = ROOT/'registration'
    plan = read(rg/'plan.json')
    reg = read(rg/plan['file'])
    nine = read(ROOT/'registered-nine.json')
    assert canon(reg) == plan['sha256'] == reg['record_sha256'] == nine['record_sha256'] == REGISTRATION
    assert digest((rg/plan['file']).read_bytes()) == nine['record_file_sha256'] == REGISTRATION_FILE
    assert digest((rg/'first-window-40.jsonl').read_bytes()) == nine['join_file_sha256']
    joined = [r for r in records(rg/'first-window-40.jsonl') if r['competition'] == 'ger.1']
    by_event = {r['espn_source_match_id']: r for r in joined}
    assert len(by_event) == len(joined) == 9 and nine['window'] == 'nov27_dec04'
    assert all(by_event[g['espn_source_match_id']] == g for g in gset)
    assert reg['previous_sha256'] is None and reg['revision'] == 1
    ids = ['espn:'+g['espn_source_match_id'] for g in gset]
    assert ids == reg['payload']['identity']['slates'][nine['window']] and len(set(ids)) == 9
    es = {e['id']: e['competitions'][0] for e in content('espn-season')['events']}
    fm = {str(e['id']): e for e in content('fotmob-season')['fixtures']['allMatches']}
    signed = read(ROOT/'signed-first-index.json')
    files = set()
    for mid,g in zip(ids,gset,strict=True):
        fixture = reg['payload']['fixtures'][mid]
        e = es[g['espn_source_match_id']]
        f = fm[g['fotmob_source_match_id']]
        assert fixture['cohort'] == 'ger.1' and fixture['stage'] == 'regular' and fixture['match_id'] == mid
        ko = instant(g['kickoff_utc'])
        assert instant(fixture['kickoff_at']) == instant(f['status']['utcTime']) == instant(e['date']) == ko
        assert int(f['round']) == 11 and e['status']['type']['name']=='STATUS_SCHEDULED'
        for side in ('home','away'):
            team, = [t for t in e['competitors'] if t['homeAway'] == side]
            assert fixture[side]=='espn:'+team['id'] and team['id']==g['espn_'+side+'_id']
            assert str(f[side]['id']) == g['fotmob_'+side+'_id']
        for name, label in [('ESPN','espn-season'),('FotMob','fotmob-season')]:
            assert g['sources'][name]['sha256'] == sources[label]['sha256']
        first = signed[mid]
        contract = first['source_contract_record']
        for archive in (first, contract):
            p = ROOT/archive['file']
            signed_row = read(p)
            assert digest(p.read_bytes()) == archive['file_sha256'] and canon(signed_row) == signed_row['record_sha256'] == archive['record_sha256']
            assert signed_row['revision'] == 1 and signed_row['previous_sha256'] is None and signed_row['match_id'] == mid
            assert all(signed_row['fixture'][s] == fixture[s] for s in ('home','away'))
            assert instant(signed_row['fixture']['kickoff_at']) == ko and instant(signed_row['recorded_at']) < ko
            assert signed_row['payload']['prices'] == archive['prices'] == first['prices']
            for market,stored in archive['market_evidence'].items():
                assert {k:v for k,v in stored.items() if k != 'raw_key'} == signed_row['payload']['market_evidence'][market]
            files.add(p)
        assert contract['record_sha256'] != first['record_sha256']
        for market, ev in first['market_evidence'].items():
            m=sources[ev['raw_key']]
            assert ev['source_url'] == m['url'] and ev['source_sha256'] == m['sha256']
            assert instant(ev['observed_at']) <= instant(first['recorded_at'])
            if ev['raw_key'].startswith('r5-infer-'):
                doc=content(ev['raw_key'])
                assert doc['event_id'] in m['url'] and instant(ev['quoted_at']) <= instant(ev['observed_at'])
                want=first['prices'][market]
                match_rows=[q for q in doc['odds'] if q['bookmaker']==ev['bookmaker'] and q['as_of']==ev['quoted_at']
                            and q['period']=='full_time' and q['status']=='open']
                assert any(all(q['prices'].get(k)==v for k,v in want.items() if k!='line')
                           and (market=='h2h' or q['line']==want['line']) for q in match_rows)
            else:
                assert ev['quoted_at'] is None  # scoreboard price is rederived in compile_market
    assert len(files)==18 and files==set((ROOT/'signed-firsts').glob('*.json'))
    assert len({g['fotmob_'+s+'_id'] for s in ('home','away') for g in gset})==18


def independent_history_check(teams):
    """Re-select the slots and sum the period statistics directly from provider bytes."""
    cutoff=instant(read(ROOT/'execution.json')['snapshot_started_utc'])
    for tid,team in teams.items():
        calendar=content('fotmob-team-'+tid)['fixtures']['allFixtures']['fixtures']
        completed=[m for m in calendar if m['status'].get('finished') and
                   not any(m['status'].get(f) for f in ('cancelled','awarded')) and
                   'friendl' not in m['tournament']['name'].casefold() and instant(m['status']['utcTime'])<cutoff]
        completed.sort(key=lambda m: instant(m['status']['utcTime']), reverse=True)
        for label in ('all_competitions','bundesliga'):
            selected=[m for m in completed if label=='all_competitions' or m['tournament']['leagueId']==54][:5]
            for g,entry in zip(selected,team[label]['matches'],strict=True):
                assert str(g['id']) == entry['fotmob_id']
                d=content(entry['source']['key'])
                header=d['header']
                idx,=[i for i,t in enumerate(header['teams']) if str(t['id'])==tid]
                assert (idx==0)==(entry['team_side']=='home')
                if header['status']['reason']['short']=='FT':
                    score=[t['score'] for t in header['teams']]
                    periods=['All']
                else:
                    event,=[x for x in d['content']['matchFacts']['events']['events'] if
                            x.get('type')=='Half' and x.get('time')==90 and x.get('halfStrShort')=='FT']
                    score=[event['homeScore'],event['awayScore']]
                    periods=['FirstHalf','SecondHalf']
                assert [score[idx],score[1-idx]]==[entry['ft90_for'],entry['ft90_against']]
                for metric,key in [('xg','expected_goals'),('sot','ShotsOnTarget')]:
                    by_side=[Decimal(0),Decimal(0)]
                    for period in periods:
                        group=d['content']['stats']['Periods'][period]['stats']
                        candidates=[st['stats'] for grp in group for st in grp['stats'] if st['key']==key]
                        for i in (0,1):
                            values={Decimal(str(pair[i])) for pair in candidates if pair[i] not in (None,'','-')}
                            measured,=values
                            by_side[i]+=measured
                    assert [float(by_side[idx]),float(by_side[1-idx])] == [entry[metric+'_for'],entry[metric+'_against']]


def verify_documented_coverage(counts):
    rows=csvrows('availability.csv')
    measured={p:sum(bool(r[p+'_person_id']) for r in rows) for p in ('fotmob','espn','dfl')}
    assert measured==counts['availability_identifiers']=={'fotmob':81,'espn':79,'dfl':80}
    assert [r['person'] for r in rows if r['also_projected']=='True']==['Han-Noah Massengo']
    assert [(r['person'],r['provider_category']) for r in rows if r['role']=='coach']==[('Manuel Baum','suspension')]
    assert [(r['person'],r['fotmob_person_id']) for r in rows if not r['dfl_person_id']]==[('Ayman Gülasi','1816238')]
    doc=read(ROOT/'delivery.json')
    assert doc['requested_driver_attempt']['completed'] is False and doc['actual_executor']=='Codex current-session driver'
    assert doc['last_prematch_evidence_read_utc']==counts['latest_source_read_utc']
    assert doc['early_market_archive_sha256']==read(ROOT/'coordination/infersports-early-result.json')['sha256']
    for r in records(ROOT/'nine-fixtures.jsonl'):
        latest = r['market']['provider_reads'][-1]
        raw_espn=content(latest['source']['key'])
        assert all(not p.get('starter') for s in raw_espn.get('rosters',[]) for p in s.get('roster',[]))
        for side,t in r['sides'].items():
            api=content(t['XI']['api']['key'])
            assert list(api[side])==['startingElevenPredicted']
            official=api[side]['startingElevenPredicted']
            assert {(p['dflDatalibraryObjectId'],p['name']) for p in official['persons']}=={
                (p['dfl_player_id'],p['name']) for p in t['XI']['persons']}


def verify_data():
    from compile_history import compile_data as history
    from compile_lineups import compile_data as personnel
    from compile_market import compile_data as market
    from handoff import build
    sources = verify_sources()
    verify_identity_and_firsts(sources)
    games,teams=history()
    assert games==read(ROOT/'history-fixtures.json') and teams==read(ROOT/'team-last-five.json')
    independent_history_check(teams)
    assert len(games)==len({g['espn']['espn_event_id'] for g in games.values()})==67
    assert sum(g['score_crosschecked'] for g in games.values())==67
    kiel=games['6162747']
    assert kiel['home_id']=='8150' and kiel['away_id']=='8226' and kiel['espn']['espn_event_id']=='401917034'
    assert kiel['periods']==['FirstHalf','SecondHalf'] and kiel['ft90']==[1,1] and kiel['xg']==[0.72,0.46] and kiel['sot']==[3,3]
    for t in teams.values():
        for sc in ('all_competitions','bundesliga'):
            rows=t[sc]['matches']
            assert len({r['fotmob_id'] for r in rows})==5 and [r['recency'] for r in rows]==list(range(1,6))
            assert all(instant(older['kickoff_utc'])<instant(newer['kickoff_utc']) for newer,older in zip(rows,rows[1:]))
    matches=personnel()
    assert matches==read(ROOT/'match-personnel.json') and market()==read(ROOT/'markets.json')
    for m in matches.values():
        for t in m['sides'].values():
            people=t['projected_XI']['persons']
            for field in ('espn_player_id','fotmob_player_id','dfl_player_id'):
                assert None not in {p[field] for p in people} and len({p[field] for p in people})==11
            assert t['confirmed_matchday_squad'] is None and t['confirmed_matchday_XI'] is None
    with TemporaryDirectory() as tmp:
        replay=Path(tmp)
        counts=build(replay)
        for rebuilt in replay.iterdir():
            assert rebuilt.read_bytes()==(ROOT/rebuilt.name).read_bytes(), rebuilt.name
    for name, n in [('fixtures-coverage.csv',9),('last-five-fixtures.csv',180),('last-five-metrics.csv',36),
                    ('projected-lineups.csv',198),('availability.csv',81),('prices.csv',77)]:
        assert len(csvrows(name))==n, name
    assert len(records(ROOT/'nine-fixtures.jsonl'))==9
    assert all(all(x==90 for x in scope.values()) for scope in counts['history'].values())
    assert counts['current_book_rows']==17 and counts['current_bookmaker_native_timestamps']==0
    assert (counts['early_infersports_companion']['eligible_rows'], counts['early_infersports_companion']['suspended_rows'])==(333,19)
    verify_documented_coverage(counts)
    return counts


if __name__=='__main__':
    if not __debug__:
        raise SystemExit('Run without -O; evidence checks require assertions')
    sys.addaudithook(deny_network)
    from bundle import verify_manifest
    verify_manifest(ROOT)
    info=verify_data()
    print(f"Offline verification passed. {info['fixtures']} fixtures, 18 teams, 67 dual-score matches, "
          "90/90 slots per history scope, 198 projected players, 81 availability entries, "
          "9 signed firsts, 17 ESPN book rows and 352 early InferSports rows.")
