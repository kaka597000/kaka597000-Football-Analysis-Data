from collections import Counter
from pathlib import Path
import csv,json
from evidence import ROOT,read,targets,meta,instant
from medical_index import assemble
from companion_market import early_market
from compile_history import ref

def jsonfile(path,obj):
    p=Path(path);b=(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
    if not p.exists() or p.read_bytes()!=b:
        tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_bytes(b);tmp.replace(p)
def csvfile(path,rows):
    with Path(path).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader()
        for r in rows:w.writerow({k:json.dumps(v,ensure_ascii=False,separators=(',',':')) if isinstance(v,(list,dict)) else v for k,v in r.items()})
def lines(path,rows):
    Path(path).write_text(''.join(json.dumps(o,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n' for o in rows),encoding='utf8')
def srccols(src,prefix=''):
    return {prefix+k:src.get(k) for k in ('key','url','requested_utc','received_utc','sha256')}
def build(output=ROOT):
    roster=read(ROOT/'match-personnel.json');teams=read(ROOT/'team-last-five.json');markets=read(ROOT/'markets.json')
    history_fixtures=read(ROOT/'history-fixtures.json')
    news=assemble(False);jsonfile(output/'medical-news.json',news)
    early,early_counts=early_market()
    jsonfile(output/'early-market-by-fixture.json',early)
    adopted = {v[k]['member']: v[k] for v in early.values() for k in ('calendar_source','source')}
    lines(output/'companion-source-manifest.jsonl',[adopted[k] for k in sorted(adopted)])
    squad_rows=[];absences=[];matchrows=[];hx=[];means=[];prices=[];full=[]
    for g in targets():
        eid=g['espn_source_match_id'];m=roster[eid];od=markets[eid];f=dict(espn_match_id=eid,fotmob_match_id=m['fotmob_match_id'],dfl_match_id=m['dfl_match_id'],
             kickoff_beijing=m['kickoff_beijing'],home=m['sides']['home']['name'],away=m['sides']['away']['name'])
        counts=dict(f);summaries={}
        for side,t in m['sides'].items():
            team=teams[t['fotmob_team_id']];proj=t['projected_XI'];linked=[n for n in news if n['team_fotmob_id']==t['fotmob_team_id']]
            prefix=dict(**f,side=side,team=t['name'],fotmob_team_id=t['fotmob_team_id'],espn_team_id=t['espn_team_id'],dfl_team_id=t['dfl_team_id'])
            for player in proj['persons']:
                squad_rows.append(dict(**prefix,dfl_player_id=player['dfl_player_id'],fotmob_player_id=player['fotmob_player_id'],espn_player_id=player['espn_player_id'],
                    player=player['name'],shirt=player['shirt_number'],position=player['role'],formation=proj['formation'],
                    classification=proj['status'],official_matchday_confirmed=False,club_identity_match=player['id_match_basis'],
                    provider_updated_at=proj['provider_lineup_updated_at'],blog_posted_at=proj['match_blog_posted_at'],**srccols(proj['api'])))
            for a in t['reported_unavailable']:
                absences.append(dict(**prefix,person=a['name'],role=a['person_role'],fotmob_person_id=a['fotmob_player_or_staff_id'],espn_person_id=a['espn_id'],
                   dfl_person_id=a['dfl_id'],dfl_directory_source=a['dfl_id_source'],
                   provider_category=a['provider_category'],provider_expected_return=a['provider_detail'].get('expectedReturn'),provider_raw_detail=a['provider_detail'],
                   also_projected=a['also_in_projected_XI'],direct_or_secondary_notes=[{'source_key':n['source']['key'],'scope':n['scope'],'publisher':n['publisher'],'observation':n['observation']} for n in a['club_or_federation_evidence']],
                   **srccols(t['reported_unavailable_source'])))
            for scope in ('all_competitions','bundesliga'):
                a=team[scope]
                for e in a['matches']:
                    historical=history_fixtures[e['fotmob_id']]
                    opp='away' if e['team_side']=='home' else 'home'
                    hx.append(dict(**prefix,scope=scope,opponent_espn_id=historical['espn'][opp+'_id'],
                        **{k:v for k,v in e.items() if k not in ('source','score_source')},**srccols(e['source'],'fotmob_'),**srccols(e['score_source'],'espn_')))
                d={'scope':scope,**prefix}
                for stat,x in a['five_match_metrics'].items():
                    for k,v in x.items():d[stat+'_'+k]=v
                means.append(d)
            counts.update({side+'_XI_projected':len(proj['persons']),side+'_XI_confirmed':0,side+'_named_availability_entries':len(t['reported_unavailable']),
                side+'_club_target_preview_or_preparation':len({n['source']['key'] for n in t['article_notes'] if n['scope'] in ('target_preparation','target_match_preview')}),
                side+'_actual_news_articles_secondary':len(linked),side+'_intervening_games':len(team['load']['scheduled_before_target']),
                side+'_upcoming_gap_hours':team['load']['projected_kickoff_gap_hours']})
            lookups=[]
            for key in ('club-index-'+t['fotmob_team_id'],'club-more-'+t['fotmob_team_id'],'li-club-'+t['fotmob_team_id']):
                if (ROOT/'sources'/(key+'.json')).is_file():
                    lookups.append(dict(**ref(key),http_status=meta(key)['http_status'],
                        role='secondary_news_index' if key.startswith('li-club') else 'first_party_club_index'))
            summaries[side]=dict(team=t['name'],fotmob_id=t['fotmob_team_id'],espn_id=t['espn_team_id'],dfl_id=t['dfl_team_id'],club_roster_sources=t['club_roster_sources'],
                 last5_all=team['all_competitions']['five_match_metrics'],last5_league=team['bundesliga']['five_match_metrics'],
                 load=team['load'],XI=proj,official_XI=t['confirmed_matchday_XI'],official_matchday_squad=t['confirmed_matchday_squad'],availability=t['reported_unavailable'],
                 availability_source=t['reported_unavailable_source'],club_and_disciplinary_notes=t['article_notes'],recent_secondary_medical_reports=linked,
                 first_party_club_lookup=t['club_homepage_checked'],first_party_club_lookup_status=t['club_homepage_http_status'],publication_lookups=lookups)
        first=od['signed_R5'];counts.update(signed_R5_sha256=first['record_sha256'],R5_book=first['bookmaker'],
                        R5_quote_asof_h2h=first['market_evidence']['h2h']['quoted_at'],R5_quote_asof_total=first['market_evidence']['total']['quoted_at'],
                        current_complete_books=[o['bookmaker'] for o in od['provider_reads'][-1]['markets'] if o['h2h_complete'] and o['total_complete']],
                        current_bookmaker_timestamp_count=sum(x.get('bookmaker_own_updated_at') is not None for x in od['provider_reads'][-1]['markets']))
        rawfirst=meta(first['market_evidence']['h2h']['raw_key'])
        infer_key=rawfirst['key'].removeprefix('r5-infer-') if rawfirst['key'].startswith('r5-infer-') else None
        prices.append(dict(**f,stage='signed_R5_first',feed='InferSports' if infer_key else 'ESPN',feed_event_id=infer_key or eid,
                   book=first['bookmaker'],espn_bookmaker_id=None,bookmaker_event_id=None,
                   home_decimal=first['prices']['h2h']['home'],draw_decimal=first['prices']['h2h']['draw'],away_decimal=first['prices']['h2h']['away'],
                   line=first['prices']['total']['line'],over_decimal=first['prices']['total']['over'],under_decimal=first['prices']['total']['under'],
                   origin_feed_h2h_asof=first['market_evidence']['h2h']['quoted_at'],origin_feed_total_asof=first['market_evidence']['total']['quoted_at'],
                   bookmaker_own_updated_at=None,recorded_or_observed_utc=first['market_evidence']['h2h']['observed_at'],signed_sha256=first['record_sha256'],**srccols(rawfirst)))
        for snap in od['provider_reads']:
            for o in snap['markets']:
                v=o['regulation_markets']
                prices.append(dict(**f,stage=snap['stage'],feed='ESPN',feed_event_id=eid,book=o['bookmaker'],espn_bookmaker_id=o['espn_bookmaker_id'],bookmaker_event_id=o['bookmaker_event_id'],
                      home_decimal=v['home']['decimal'],draw_decimal=v['draw']['decimal'],away_decimal=v['away']['decimal'],line=v['total_line'],over_decimal=v['over']['decimal'],under_decimal=v['under']['decimal'],
                      origin_feed_h2h_asof=None,origin_feed_total_asof=None,bookmaker_own_updated_at=o['bookmaker_own_updated_at'],recorded_or_observed_utc=snap['source']['received_utc'],signed_sha256=None,**srccols(snap['source'])))
        matchrows.append(counts)
        counts['infer_early_same_book_pairs']=early[eid]['same_book_pairs']
        counts['infer_early_equal_and_fresh_pairs']=early[eid]['fresh_equal_pairs']
        full.append(dict(**f,statuses=m['provider_statuses'],source_statuses=m['source_statuses'],sides=summaries,market=od,early_infersports=early[eid]))
    csvfile(output/'fixtures-coverage.csv',matchrows);csvfile(output/'last-five-fixtures.csv',hx);csvfile(output/'last-five-metrics.csv',means)
    csvfile(output/'projected-lineups.csv',squad_rows);csvfile(output/'availability.csv',absences);csvfile(output/'prices.csv',prices);lines(output/'nine-fixtures.jsonl',full)
    sources=[read(f) for f in sorted((ROOT/'sources').glob('*.json'))]
    lines(output/'source-manifest.jsonl',sources)
    agg=dict(fixtures=len(full),teams=len(teams),unique_historical_fixtures=len(read(ROOT/'history-fixtures.json')),
         history={sc:dict(slots=len(a),dual_ft90=sum(r['score_crosschecked'] for r in a),xg_for_and_against=sum(all(r[k] is not None for k in ('xg_for','xg_against')) for r in a),
             sot_for_and_against=sum(all(r[k] is not None for k in ('sot_for','sot_against')) for r in a)) for sc in ('all_competitions','bundesliga') if (a:=[r for r in hx if r['scope']==sc])},
         dfl_projected=len(squad_rows),crosswalk_all_three_player_ids=sum(all(r[k] for k in ('dfl_player_id','fotmob_player_id','espn_player_id')) for r in squad_rows),
         confirmed_matchday_xi_teams=0,confirmed_matchday_squad_teams=0,availability=Counter((r['role']+'_'+r['provider_category']) for r in absences),
         availability_identifiers={provider:sum(bool(r[provider+'_person_id']) for r in absences) for provider in ('fotmob','espn','dfl')},
         simultaneous_predicted_and_reported_unavailable=[p['person'] for p in absences if p['also_projected']],
         pending_intermediate_fixtures=sum(len(t['load']['scheduled_before_target']) for t in teams.values()),
         verified_signed_R5_firsts=len(markets),current_book_rows=sum(len(r['current_complete_books']) for r in matchrows),current_fixtures_with_quote=sum(bool(r['current_complete_books']) for r in matchrows),
         current_bookmaker_native_timestamps=sum(r['current_bookmaker_timestamp_count'] for r in matchrows),archived_R5_feed_timestamp_fixtures=sum(bool(r['R5_quote_asof_h2h'] and r['R5_quote_asof_total']) for r in matchrows),
         secondary_medical_articles=len(news),direct_article_scopes=Counter(n['scope'] for m in roster.values() for t in m['sides'].values() for n in t['article_notes']),
         source_response_or_attempts=len(sources),with_raw_bytes=sum('raw_path' in r for r in sources),
         early_infersports_companion=early_counts,
         latest_source_read_utc=max(r['received_utc'] for r in sources if r.get('received_utc')))
    jsonfile(output/'coverage.json',agg)
    return agg
if __name__=='__main__':print(json.dumps(build(),ensure_ascii=False))
