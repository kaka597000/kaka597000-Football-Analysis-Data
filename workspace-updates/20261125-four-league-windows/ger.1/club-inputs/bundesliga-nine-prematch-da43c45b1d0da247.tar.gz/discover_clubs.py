from public_pages import *
from concurrent.futures import ThreadPoolExecutor
jobs=[('li-availability','https://www.ligainsider.de/bundesliga/verletzte-und-gesperrte-spieler/'),
      ('tm-availability','https://www.transfermarkt.de/bundesliga/sperrenundverletzungen/wettbewerb/L1')]
for tid in ('9788','9823','9789','178475','9810','10269','8149'):
 u=urlsplit(CLUBS[tid]);jobs.append(('club-robots-'+tid,u.scheme+'://'+u.netloc+'/robots.txt'))
for lab,idx,needle in [('fca-ban','club-more-8406','zwei-spiele-sperre-fuer-juma-bah'),
        ('fca-banks','club-more-8406','noahkai-banks-verletzt'),
        ('scf-availability','club-more-8358','gute-personalsituation-vor-elversberg')]:
 for h,t in distinct_links(idx):
  if needle in h:jobs.append((lab,h));break
for label,src,needle in [('dfl-bayern-lille','bundesliga-news','osc-lille-fc-bayern'),('dfl-vfb-inter','bundesliga-news','vfb-stuttgart-inter'),
      ('dfl-tsg-graz','bundesliga-news','hoffenheim-sk-sturm-graz'),('dfl-b04-zagreb','bundesliga-news','leverkusen-dinamo-zagreb'),
      ('dfl-scf-twente','bundesliga-news','sc-freiburg-twente')]:
 for h,t in distinct_links(src):
  if needle in h:jobs.append((label,h));break
with ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(lambda j:get(*j),jobs))
