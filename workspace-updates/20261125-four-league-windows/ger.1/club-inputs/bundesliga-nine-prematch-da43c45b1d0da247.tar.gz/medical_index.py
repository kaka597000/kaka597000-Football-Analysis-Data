from public_pages import *
from compile_history import ref
from datetime import datetime
OFFICIAL_HOSTS={urlsplit(u).hostname.lstrip('www.'):tid for tid,u in CLUBS.items()}
def clubhost(h,root):
    return bool(h and (h==root or h.endswith('.'+root)))
def assemble(fetch=False):
    rows=[]
    saved_urls = {}
    for sidecar in sorted((ROOT/'sources').glob('*.json')):
        source = read(sidecar)
        if source.get('http_status') == 200:
            for address in (source['url'], source.get('resolved_url')):
                if address:
                    saved_urls.setdefault(address, sidecar.stem)
    for path in sorted((ROOT/'sources').glob('medical-*.json')):
        m=read(path)
        if m.get('http_status')!=200:continue
        tid=path.stem.split('-')[1];p=page(path.stem)
        ix=next((i for i,s in enumerate(p.parts) if 'Gemeldet von' in s and re.search(r'\d\.\d\d\.20\d\d',s)),None)
        if ix is None:continue
        body=[]
        for s in p.parts[ix+1:]:
            if s.startswith(('Quelle:', 'LIGAINSIDER-', 'KOMMENTARE','Letzte Änderung','Bilanz','WORKLOAD','LIGAINSIDER ')):break
            if len(s)>39 and not 'Kommentare' in s:body.append(s)
            if len(body)>=5:break
        name=p.parts[ix-2].split(' | ')[0] if ' | ' in p.parts[ix-2] else None
        src_title=p.parts[ix-1]
        stamp=p.metatags.get('article:published_time')
        urls=distinct_links(path.stem);clubrefs=[]
        for url,title in urls:
            h=urlsplit(url).hostname or '';root=(urlsplit(CLUBS[tid]).hostname or '').removeprefix('www.')
            if not (clubhost(h,root) or clubhost(h,'dfb.de')):continue
            if len(urlsplit(url).path.strip('/'))<12:continue
            lab='medical-primary-'+tid+'-'+digest(url.encode())[:10]
            lab=saved_urls.get(url,lab)
            if fetch and not (ROOT/'sources'/(lab+'.json')).exists():get(lab,url)
            got=(ROOT/'sources'/(lab+'.json')).exists()
            clubrefs.append(dict(url=url,link_text=title,raw_source_key=lab if got else None,
                                 http_status=meta(lab).get('http_status') if got else None))
        if not stamp:stamp=p.parts[ix].split(' Gemeldet')[0]
        rows.append(dict(team_fotmob_id=tid,person_or_team_as_reported=name,title_original=src_title,body_original=body,
            provider_player_id=(re.search(r'_(\d+)/',urlsplit(m['url']).path).group(1) if re.search(r'_(\d+)/',urlsplit(m['url']).path) else None),
            source=ref(path.stem),publication_as_supplied=stamp,source_role='secondary report, not a confirmed matchday squad',
            direct_club_or_federation_links=clubrefs))
    return rows
if __name__=='__main__':
 import sys
 v=assemble('--fetch' in sys.argv);print(len(v),'articles',sum(len(r['direct_club_or_federation_links']) for r in v),'official links')
 if '--fetch' not in sys.argv:save(ROOT/'medical-news.json',v)
