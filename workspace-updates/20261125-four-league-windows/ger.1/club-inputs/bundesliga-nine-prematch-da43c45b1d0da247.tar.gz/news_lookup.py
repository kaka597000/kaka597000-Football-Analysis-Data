from public_pages import *
from urllib.parse import urlencode
from concurrent.futures import ThreadPoolExecutor
jobs=[('dfb-news','https://www.dfb.de/news'),('union-map','https://www.fc-union-berlin.de/sitemap.xml'),
      ('fcb-map','https://fcbayern.com/index-sitemap.xml'),('sge-map','https://profis.eintracht.de/sitemap-index.xml'),
      ('vfb-inter-pk','https://www.vfb.de/de/vfb/aktuell/neues/profis/2627/pressekonferenz-vor-inter-mailand-gegen-vfb-stuttgart/')]
for k,q in [('kabak','"Ozan Kabak" Sperre November 2026 DFB Hoffenheim'),('vdb','"Van Den Bosch" Sperre November 2026 Union DFB'),
            ('baum','"Manuel Baum" Sperre November 2026 DFB Augsburg')]:
 jobs.append(('bing-'+k,'https://www.bing.com/search?'+urlencode(dict(q=q,format='rss',setlang='de-DE'))))
 jobs.append(('gnews-'+k,'https://news.google.com/rss/search?'+urlencode(dict(q=q.split(' November')[0]+' Sperre when:10d',hl='de',gl='DE',ceid='DE:de'))))
with ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(lambda j:get(*j),jobs))
