from history import *
from collections import defaultdict
LEAGUE_NAMES={54:'German Bundesliga',209:'German Cup',42:'UEFA Champions League',73:'UEFA Europa League',10216:'UEFA Conference League'}
def find_ids():
    teams,cs=selection();known={k:str(t['espn_team_id']) for k,t in teams.items()}
    events=defaultdict(list)
    for g in targets():
        src='espn-refresh-'+g['espn_source_match_id']
        for grp in content(src).get('lastFiveGames',[]):
            for e in grp.get('events',[]):
                events[(instant(e['gameDate']),e['leagueName'])].append((e,src))
    ids={}
    for mid,r in cs.items():
        league=r['tournament']['leagueId'];key=(instant(r['status']['utcTime']),LEAGUE_NAMES[league])
        sides={s:known[str(r[s]['id'])] for s in ('home','away') if str(r[s]['id']) in known}
        choices={e['id']:(e,src) for e,src in events.get(key,[]) if all(str(e[s+'TeamId'])==t for s,t in sides.items())}
        if len(choices)>1:raise ValueError(mid)
        if choices:ids[mid]=next(iter(choices.values()))
    return ids
if __name__=='__main__':
    ids=find_ids();_,cs=selection()
    for mid,r in cs.items():
        if r['tournament']['leagueId']==54:continue
        if mid not in ids:print('missing',mid);continue
        e,_=ids[mid];code=KNOWN_TOURNAMENTS[r['tournament']['leagueId']]
        get('espn-historical-'+e['id'],f"https://site.api.espn.com/apis/site/v2/sports/soccer/{code}/summary?event={e['id']}")
