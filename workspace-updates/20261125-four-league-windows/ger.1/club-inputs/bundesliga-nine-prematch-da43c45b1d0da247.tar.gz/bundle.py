"""Build a deterministic archive or verify one by extracting into a fresh, offline directory."""
import argparse
import gzip
import hashlib
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import tarfile
from tempfile import TemporaryDirectory

ROOT = Path(__file__).resolve().parent
PREFIX = 'bundesliga-nine-prematch-'
FOLDERS = ('raw', 'sources', 'registration', 'signed-firsts', 'companion')
COORDINATION = ('coordination/infersports-early-owner.json', 'coordination/infersports-early-result.json')


def file_sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()


def inventory(root):
    paths = [root/'README.md', *(root/name for name in COORDINATION)]
    for suffix in ('.py','.csv','.json','.jsonl'):
        paths.extend(root.glob('*' + suffix))
    for folder in FOLDERS:
        paths.extend(p for p in (root/folder).rglob('*') if p.is_file())
    if any(not p.is_file() or p.is_symlink() for p in paths):
        raise ValueError('Missing file or symlink in release')
    return sorted(p.relative_to(root).as_posix() for p in paths)


def manifest(root):
    return ''.join(file_sha(root/name)+'  '+name+'\n' for name in inventory(root))


def verify_manifest(root):
    if manifest(root) != (root/'SHA256SUMS').read_text(encoding='utf-8'):
        raise ValueError('Bundle file list or checksums differ')


def build():
    index = manifest(ROOT)
    sums = ROOT/'SHA256SUMS'
    if sums.exists() and sums.read_text() != index:
        raise ValueError('This directory already contains a different sealed release')
    if not sums.exists():
        sums.write_text(index, encoding='utf-8')
    with TemporaryDirectory(dir=ROOT, prefix='.build-') as work:
        tmp=Path(work)/'archive'
        with tmp.open('wb') as stream, gzip.GzipFile(filename='',mode='wb',fileobj=stream,mtime=0,compresslevel=6) as gz:
            with tarfile.open(fileobj=gz,mode='w|',format=tarfile.USTAR_FORMAT) as out:
                for name in sorted([*inventory(ROOT), 'SHA256SUMS']):
                    path=ROOT/name
                    member=tarfile.TarInfo(name)
                    member.size=path.stat().st_size
                    member.mode=0o644
                    with path.open('rb') as f:
                        out.addfile(member,f)
        sha=file_sha(tmp)
        dest=ROOT/(PREFIX+sha[:16]+'.tar.gz')
        if dest.exists() and file_sha(dest)!=sha:
            raise ValueError('Archive identifier collision')
        if not dest.exists():
            tmp.rename(dest)
        checksum=dest.with_name(dest.name+'.sha256')
        line=sha+'  '+dest.name+'\n'
        if checksum.exists() and checksum.read_text()!=line:
            raise ValueError('Conflicting existing companion checksum')
        if not checksum.exists():
            checksum.write_text(line)
        print(sha+'  '+dest.name)
        return dest


def replay(archive):
    sha=file_sha(archive)
    if archive.name != PREFIX+sha[:16]+'.tar.gz':
        raise ValueError('Archive hash mismatch')
    checksum=archive.with_name(archive.name+'.sha256')
    if checksum.exists() and checksum.read_text()!=sha+'  '+archive.name+'\n':
        raise ValueError('Detached checksum mismatch')
    with TemporaryDirectory(prefix='bundesliga-replay-') as temp:
        out=Path(temp)
        seen=set()
        with tarfile.open(archive,mode='r:gz') as package:
            for m in package:
                rel=PurePosixPath(m.name)
                if not m.isfile() or rel.as_posix()!=m.name or rel.is_absolute() or '..' in rel.parts or m.name in seen:
                    raise ValueError('Invalid member '+m.name)
                seen.add(m.name)
                dest=out/m.name
                dest.parent.mkdir(exist_ok=True,parents=True)
                with package.extractfile(m) as src, dest.open('xb') as f:
                    shutil.copyfileobj(src,f)
        if seen!=set(inventory(out)) | {'SHA256SUMS'}:
            raise ValueError('Unexpected archive members')
        verify_manifest(out)
        # Isolated interpreter, no external paths and socket operations blocked by verify.py.
        command="import pathlib,runpy,sys; sys.path.insert(0,str(pathlib.Path.cwd())); runpy.run_path('verify.py',run_name='__main__')"
        subprocess.run([sys.executable,'-I','-B','-c',command],cwd=out,
                       env={'LANG':'C.UTF-8','TZ':'UTC'},check=True)
        print(f'{len(seen)} members verified. Archive SHA-256 {sha}')


if __name__=='__main__':
    cli=argparse.ArgumentParser(description=__doc__)
    sub=cli.add_subparsers(dest='cmd',required=True)
    sub.add_parser('build')
    sub.add_parser('replay').add_argument('archive',type=Path)
    args=cli.parse_args()
    if args.cmd=='build':
        build()
    else:
        replay(args.archive.resolve())
