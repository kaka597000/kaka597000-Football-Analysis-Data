from public_pages import *
supp={
'8178':'https://www.bayer04.de/de-de/page/newscenter','9788':'https://www.borussia.de/de',
'9810':'https://profis.eintracht.de/','9823':'https://fcbayern.com/de','8226':'https://www.tsg-hoffenheim.de/aktuelles/news',
'9789':'https://www.bvb.de/de/de.html','8358':'https://www.scfreiburg.com/aktuell/nachrichten/profis/',
'10269':'https://www.vfb.de/de/','178475':'https://rbleipzig.com/de/news','10189':'https://schalke04.de/bundesliga/',
'9905':'https://www.mainz05.de/news-page','8232':'https://sv07elversberg.de/feed/','8460':'https://www.scp07.de/Teams/Profis/News-Profis/',
'8149':'https://www.fc-union-berlin.de/de/','8406':'https://www.fcaugsburg.de/news/profis'}
jobs=[('club-more-'+i,url) for i,url in supp.items() if url!=CLUBS[i]]
extra=[('club-8722-castro','https://fc.de/aktuelles/news/personal-update-pause-fuer-castro-montes'),
       ('club-8722-personal','https://fc.de/aktuelles/news/personal-fc-profi-muss-kuerzertreten'),
       ('club-8722-week','https://fc.de/aktuelles/news/fc-woche-training-pk-elversberg'),
       ('club-9790-bayern','https://www.hsv.de/news/personal-update-zum-start-in-die-bayern-woche'),
       ('club-9790-muheim','https://www.hsv.de/news/miro-muheim-faellt-vorerst-aus')]
def run(job):return get(*job)
if __name__=='__main__':
    with ThreadPoolExecutor(max_workers=5) as pool:list(pool.map(run,jobs+extra))
