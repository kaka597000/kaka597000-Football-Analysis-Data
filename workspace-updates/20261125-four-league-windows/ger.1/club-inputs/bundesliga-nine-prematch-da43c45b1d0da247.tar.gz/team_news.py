from public_pages import *
import re
SLUG={'fc-bayern-muenchen':'9823','borussia-dortmund':'9789','rb-leipzig':'178475','vfb-stuttgart':'10269','tsg-hoffenheim':'8226','bayer-04-leverkusen':'8178','sc-freiburg':'8358','eintracht-frankfurt':'9810','fc-augsburg':'8406','1-fsv-mainz-05':'9905','1-fc-union-berlin':'8149','borussia-moenchengladbach':'9788','hamburger-sv':'9790','1-fc-koeln':'8722','sv-werder-bremen':'8697','fc-schalke-04':'10189','sv-07-elversberg':'8232','sc-paderborn-07':'8460'}
def indexes():
 for url,title in distinct_links('ligainsider-XI'):
  if '/verein/news/' in url:
   slug=urlsplit(url).path.split('/')[1]
   if slug in SLUG:get('li-club-'+SLUG[slug],url)
if __name__=='__main__':
 get('fca-week-target','https://www.fcaugsburg.de/article/kw-48-die-fca-woche-im-ueberblick-23712')
 indexes()
