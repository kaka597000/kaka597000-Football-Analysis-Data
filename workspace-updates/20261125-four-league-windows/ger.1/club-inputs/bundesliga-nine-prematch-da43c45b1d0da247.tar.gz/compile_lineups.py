from public_pages import *
from compile_history import ref
from collections import defaultdict,Counter

DFL_TEAMS={'8697':'SV Werder Bremen','9788':'Borussia Mönchengladbach','8460':'SC Paderborn 07','10189':'FC Schalke 04',
 '8722':'1. FC Köln','8232':'SV Elversberg','9790':'Hamburger SV','9823':'FC Bayern München','9905':'1. FSV Mainz 05',
 '8149':'1. FC Union Berlin','10269':'VfB Stuttgart','9810':'Eintracht Frankfurt','8358':'Sport-Club Freiburg',
 '178475':'RB Leipzig','8226':'TSG Hoffenheim','8406':'FC Augsburg','9789':'Borussia Dortmund','8178':'Bayer 04 Leverkusen'}
def norm(x):
    x=unicodedata.normalize('NFKD',x or '').casefold()
    x=x.translate(str.maketrans({'ł':'l','ø':'o','æ':'ae','đ':'d'}))
    return ''.join(c for c in x if c.isalnum())
def lookup(catalog,names):
    wanted={norm(n) for n in names if n}
    found=[p for p in catalog if wanted & {norm(p.get(k)) for k in ('name','fullName','displayName','shortName') if p.get(k)}]
    unique={str(p['id']):p for p in found}
    return next(iter(unique.values())) if len(unique)==1 else {}

def dfl_squads():
    squads = {}
    for path in sorted((ROOT/'sources').glob('dfl-club-*.json')):
        key = path.stem
        if meta(key)['http_status'] != 200:
            continue
        state = json.loads(next(v for a,v in page(key).scripts if a.get('id')=='ng-state'))
        embedded, = [v for v in state.values() if isinstance(v,dict) and
                     str(v.get('u','')).startswith('https://wapp.bapi.bundesliga.com/person/personsbyclub/')]
        club_id = embedded['u'].rsplit('/',1)[1]
        assert club_id.startswith('DFL-CLU-') and club_id not in squads
        people = []
        for kind, groups in embedded['b'].items():
            if kind not in ('players','roles'):continue
            for role, members in groups.items():
                for p in members:
                    assert p['id'] == p['externalPersonIds']['dflDatalibraryPersonId']
                    n=p['name']
                    people.append(dict(id=p['id'],name=n['full'],shortName=n.get('shortName'),displayName=n.get('alias'),
                                       shirt=p.get('shirtNumber'),role=role,kind=kind))
        squads[club_id]=dict(persons=people,source=ref(key),embedded_provider_url=embedded['u'])
    assert len(squads)==18
    return squads

def espn_roster_match(roster, player):
    direct = lookup(roster,[player.get('name')])
    if direct or not player.get('dateOfBirth'):
        return direct
    birth = player['dateOfBirth'][:10]
    tokens = sorted(norm(s) for s in player['name'].split())
    matches = [p for p in roster if (p.get('dateOfBirth') or '')[:10] == birth and
               sorted(norm(s) for s in (p.get('fullName') or '').split()) == tokens]
    return matches[0] if len(matches)==1 else {}
def official():
    events={}
    for i in range(1,10):
        key='dfl-game-'+str(i);p=page(key)
        state=json.loads(next(v for a,v in p.scripts if a.get('id')=='ng-state'))
        match=next(v[0] for k,v in state.items() if k.startswith('_get') and 'slugLong' in k)
        embedded=next(v for k,v in state.items() if k.endswith('/lineup'))
        api_key='dfl-api-'+str(i);lines=content(api_key)
        assert embedded==lines and match['dflDatalibraryMatchId'] in meta(api_key)['url']
        assert match['matchStatus']=='PRE_MATCH' and match['matchday']==11 and match['dflDatalibraryCompetitionId']=='DFL-COM-000001'
        events[tuple(match['teams'][s]['nameFull'] for s in ('home','away'))]=(match,lines,key,api_key)
    return events
def source_notes():
    """Human-read first-party statements, with scope and publication precision from each page."""
    statements=[
     ('8722','club-8722-castro','2026-11-24','target_preparation',['Alessio Castro-Montes'],'calf injury; club says he must pause for now','Wadenverletzung'),
     ('8722','club-8722-personal','2026-11-23','target_preparation',['Marvin Schwäbe'],'reduced workload for back problems; weekend availability unresolved','Rückenproblemen'),
     ('8722','club-8722-personal','2026-11-23','target_preparation',['Rav van den Berg','Timo Hübers','Ellyes Skhiri','Imad Rondic','Thijs Dallinga'],'continuing rehabilitation','Reha-Bereich'),
     ('8722','club-8722-week','2026-11-23','target_preparation',[],'club training and press-conference schedule before Elversberg','Mittwoch ist frei'),
     ('9790','club-9790-bayern','2026-11-25','target_preparation',['Fabio Vieira'],'completed full team training','komplette Mannschaftstraining'),
     ('9790','club-9790-bayern','2026-11-25','target_preparation',['Shafiq Nandja','Jordan Torunarigha','Nicolas Capaldo'],'individual training; Capaldo had managed workload','individuelle Einheit'),
     ('9790','club-9790-bayern','2026-11-25','target_preparation',['Albert Sambi Lokonga','Bilal Nadir'],'working towards return to team training','Rückkehr ins Teamtraining'),
     ('9790','club-9790-muheim','2026-11-23','current_club_medical',['Miro Muheim'],'right calf injury; unavailable for now by club statement','rechten Wade'),
     ('9823','fcb-lille','2026-11-24','intervening_UCL_squad',['Harry Kane','Michael Olise','Manuel Neuer','Serge Gnabry','Ismael Saibari','Alphonso Davies'],'club lists six injured absences for Lille','Die Bayern sind die Reise nach Lille ohne'),
     ('9823','fcb-lille','2026-11-24','intervening_UCL_squad',['Luis Díaz'],'returns to the squad for Lille after thigh injury','erstmals wieder dabei'),
     ('10269','vfb-inter-pk','2026-11-24','intervening_UCL_squad',['Angelo Stiller','Luca Jaquez'],'back in the squad for Inter by club press conference','Angelo Stiller und Verteidiger Luca Jaquez'),
     ('9810','sge-vfb','2026-11-24','target_match_preview',[],'club match preview for Stuttgart', 'VfB Stuttgart'),
     ('8226','dfb-kabak','2026-11-24','federation_disciplinary_decision',['Ozan Kabak'],'DFB single-judge decision: suspension for four league matches','vier Meisterschaftsspielen'),
     ('8226','li-kabak-appeal','2026-11-24','secondary_appeal_report',['Ozan Kabak'],'LigaInsider reports an appeal by Hoffenheim; final duration requires an updated decision','Einspruch'),
     ('8406','fca-week-target','2026-11-23','target_preparation',[],'official Hoffenheim matchweek schedule; Friday 13:30 local press conference listed','Am Freitag um 13.30 Uhr'),
     ('8178','b04-zagreb','2026-11-24','intervening_match_preview',[],'Bayer published a preview of the Europa League match in Zagreb','Der kroatische Rekordmeister GNK Dinamo Zagreb'),
     ('8358','dfl-scf-twente','2026-11-24','league_intervening_match_preview',[],'league preview of the Twente match on Thursday, before Leipzig','am Donnerstag wieder prall gefüllt'),
     ('8226','dfl-tsg-graz','2026-11-24','league_intervening_match_preview',[],'league preview of Hoffenheim versus Sturm Graz before Augsburg','Sturm Graz'),
     ('8406','dfb-kabak','2026-11-24','federation_disciplinary_decision',['Manuel Baum'],'coach banned from the technical area for the next league match','Innenraumverbot für das nächste Meisterschaftsspiel'),
     ('8406','fca-current-23717','2026-11-24','target_club_disciplinary_confirmation',['Manuel Baum'],'Augsburg confirms its head coach is banned from the technical area at Hoffenheim','Innenraumverbot für das nächste'),
     ('8149','dfl-union-vdb',None,'official_season_card_count',['Zeno Van Den Bosch'],'DFL player statistics show five yellow cards; status for the fixture separately attributed to FotMob','Yellow cards'),
    ]
    result=defaultdict(list)
    for tid,src,day,scope,names,claim,needle in statements:
        p=page(src);evidence=next((s for s in p.parts if needle in s),None)
        if evidence is None:raise ValueError((src,needle))
        if src=='dfl-union-vdb':
            assert p.parts[p.parts.index('Yellow cards')+1]=='5';evidence='Yellow cards: 5'
        stamp=p.metatags.get('article:published_time')
        if not stamp:
            for a,script in p.scripts:
                hits=re.findall(r'"datePublished"\s*:\s*"([^"]+)"',script)
                if hits:stamp=hits[0];break
        if not stamp and day:stamp=day
        if stamp and len(stamp)>10:assert instant(stamp)<=instant(meta(src)['received_utc'])
        result[tid].append(dict(source=ref(src),publisher='secondary_reporting' if scope=='secondary_appeal_report' else 'official_source',
            scope=scope,persons=names,observation=claim,original_excerpt=evidence[:1000],publication_as_supplied=stamp,
            publication_precision=('date' if len(stamp)==10 else 'timestamp') if stamp else None))
    return result
def compile_data():
    events=official();notes=source_notes();out={};teams_report=read(ROOT/'team-last-five.json');squads=dfl_squads()
    for g in targets():
        eid=g['espn_source_match_id'];mid=g['fotmob_source_match_id']
        match,lines,k,api=events[tuple(DFL_TEAMS[str(g['fotmob_'+s+'_id'])] for s in ('home','away'))]
        assert instant(match['plannedKickOff'])==instant(g['kickoff_utc'])
        target_key='fotmob-target-'+mid;d=content(target_key)
        assert str(d['general']['matchId'])==mid and d['general']['parentLeagueId']==54 and instant(d['header']['status']['utcTime'])==instant(g['kickoff_utc'])
        assert not any(d['header']['status'].get(z) for z in ('started','finished','cancelled'))
        sides={}
        for side in ('home','away'):
            tid=str(g['fotmob_'+side+'_id']);et=str(g['espn_'+side+'_id'])
            assert str(d['general'][side+'Team']['id'])==tid
            edoc=content('espn-squad-'+et);assert str(edoc['team']['id'])==et
            fm_team=content('fotmob-team-'+tid)
            players=[dict(p,group=grp['title']) for grp in fm_team['squad']['squad'] for p in grp['members']]
            eroster=edoc.get('athletes') or []
            ft=d['content']['lineup'];part=ft[side+'Team'];assert str(part['id'])==tid
            # ESPN's full club roster and FotMob's prior XI have different scope from the DFL match-specific projection.
            prev=part.get('lastMatch') or {}; lineup=lines[side];pro= lineup['startingElevenPredicted']
            assert set(lineup)=={'startingElevenPredicted'} and len(pro['persons'])==11
            ids=[v['dflDatalibraryObjectId'] for v in pro['persons']];assert len(set(ids))==11
            post=match['liveBlogEntries']['lineup_'+side];assert post['detail']['predicted'] and post['matchSection']=='PRE_MATCH' and post['side']==side
            assert {p['dflDatalibraryObjectId'] for p in post['detail']['lineup']}==set(ids)
            assert instant(post['entryDate']) <= instant(meta(k)['received_utc']) < instant(g['kickoff_utc'])
            assert instant(pro['lastUpdateDateTime']) <= instant(meta(api)['received_utc']) < instant(g['kickoff_utc'])
            predicted=[]
            for p in pro['persons']:
                fm=lookup(players,[p['name'],p.get('tacticalName')]);esp=lookup(eroster,[p['name'],p.get('tacticalName'),fm.get('name')])
                method='unique current-team name'
                if not fm:
                    previous=lookup(part.get('starters',[])+part.get('subs',[]),[p['name'],p.get('tacticalName')])
                    if previous and str(previous.get('shirtNumber'))==str(p.get('shirtNumber')):
                        fm=previous;method='same club, name and shirt in FotMob prior lineup'
                if not fm or not esp:
                    jersey=str(p['shirtNumber'])
                    fjer=[a for a in players if str(a.get('shirtNumber'))==jersey]
                    ejer=[a for a in eroster if str(a.get('jersey'))==jersey]
                    if len(fjer)==len(ejer)==1:
                        f,e=fjer[0],ejer[0]
                        tokens=lambda n:{norm(t) for t in re.findall(r'[^\W_]+',n or '') if len(t)>2}
                        matched_names=tokens(p['name']) & (tokens(f['name']) | tokens(e['displayName']))
                        dob=f.get('dateOfBirth')
                        if (dob and dob==str(e.get('dateOfBirth',''))[:10] and matched_names
                                and (not fm or int(fm['id'])==int(f['id'])) and (not esp or int(esp['id'])==int(e['id']))):
                            fm,esp=f,e;method='same club and unique DFL shirt; overlapping names and identical FotMob/ESPN date of birth'
                predicted.append(dict(id_match_basis=method,fotmob_name=fm.get('name'),espn_name=esp.get('displayName'),dfl_player_id=p['dflDatalibraryObjectId'],name=p['name'],shirt_number=p.get('shirtNumber'),role=p.get('role'),
                    fotmob_player_id=str(fm['id']) if fm else None,espn_player_id=str(esp['id']) if esp else None,opta_id=fm.get('optaId'),
                    recent_minutes=teams_report[tid]['player_workload_last_five'].get(str(fm.get('id')))))
            league_squad=squads[match['teams'][side]['dflDatalibraryClubId']]
            assert instant(league_squad['source']['received_utc'])<instant(g['kickoff_utc'])
            league_people=league_squad['persons']
            roster=[dict(name=p['name'],fotmob_id=str(p['id']),group=p['group'],opta_id=p.get('optaId'),
                         espn_id=str(es['id']) if (es:=espn_roster_match(eroster,p)) else None,
                         dfl_id=lookup(league_people,[p['name']]).get('id')) for p in players]
            un=[]
            for p in part.get('unavailable') or []:
                fm=next((x for x in players if str(x['id'])==str(p['id'])),{});es=espn_roster_match(eroster,fm or p);u=p['unavailability']
                league=lookup(league_people,[p['name'],fm.get('name'),es.get('fullName')])
                un.append(dict(name=p['name'],fotmob_player_or_staff_id=str(p['id']),espn_id=str(es['id']) if es else None,
                   dfl_id=league.get('id'),dfl_id_source=league_squad['source']['key'] if league else None,
                   person_role='coach' if fm.get('group')=='coach' else 'player',provider_category=u['type'],provider_detail=u,
                   source_key=target_key,club_or_federation_evidence=[v for v in notes[tid] if norm(p['name']) in {norm(n) for n in v['persons']}],
                   also_in_projected_XI=any(str(p['id'])==x['fotmob_player_id'] or norm(p['name'])==norm(x['name']) for x in predicted)))
            sides[side]=dict(name=match['teams'][side]['nameFull'],dfl_team_id=match['teams'][side]['dflDatalibraryClubId'],espn_team_id=et,fotmob_team_id=tid,
                projected_XI=dict(status='league_published_prediction',formation=pro.get('tacticalFormationName'),persons=predicted,source=ref(k),api=ref(api),
                    provider_lineup_updated_at=pro['lastUpdateDateTime'],match_blog_posted_at=post['entryDate']),
                confirmed_matchday_XI=None,confirmed_matchday_squad=None,confirmed_status_basis='official league shows predicted lineup; ESPN summary has no confirmed starter roster',
                club_roster_scope='season club roster at read time',club_roster=roster,club_roster_sources=[ref('fotmob-team-'+tid),ref('espn-squad-'+et),league_squad['source']],
                dfl_club_directory=league_squad,
                fotmob_lineup_type=ft['lineupType'],fotmob_lineup_source=ft['source'],prior_XI_reference=dict(match=prev,formation=part.get('formation'),
                    names=[dict(name=p['name'],fotmob_player_id=str(p['id'])) for p in part.get('starters',[])]),
                reported_unavailable=un,reported_unavailable_source=ref(target_key),article_notes=notes[tid],
                club_homepage_checked=ref('club-index-'+tid),club_homepage_http_status=meta('club-index-'+tid)['http_status'])
        e=content('espn-refresh-'+eid)
        for s in e.get('rosters',[]):
            assert not any(p.get('starter') for p in s.get('roster',[]))
        out[eid]=dict(espn_event_id=eid,fotmob_match_id=mid,dfl_match_id=match['dflDatalibraryMatchId'],dfl_season_id=match['dflDatalibrarySeasonId'],
             dfl_matchday_id=match['dflDatalibraryMatchdayId'],competition='ger.1',matchday=11,kickoff_utc=g['kickoff_utc'],kickoff_beijing=g['kickoff_beijing'],
             venue=match['stadiumName'],provider_statuses=dict(dfl=match['matchStatus'],fotmob=d['header']['status'],espn=e['header']['competitions'][0]['status']['type']),
             source_statuses=[ref(k),ref(target_key),ref('espn-refresh-'+eid)],sides=sides)
    return out
if __name__=='__main__':
    out=ROOT/'match-personnel.json';tmp=out.with_suffix('.new');save(tmp,compile_data());tmp.replace(out)
