from evidence import *
import tarfile,re
from urllib.parse import parse_qs,urlsplit,unquote
R5=Path('/workspace/scratch/r14-data/workspace-updates/20261123-all-scope-kpi')
def canon(x):return digest(json.dumps({k:v for k,v in x.items() if k!='record_sha256'},sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode())
def archive():
    manifest=read(R5/'manifest.json');names=('forward-first-issues.tar.gz','forward-observations.tar.gz')
    assert digest((R5/'manifest.json').read_bytes())=='f3b6fa64903e97a6c74966362894c3378dfe5bca03a4a84709d4c694946ed3d8'
    for n in names:assert digest((R5/n).read_bytes())==manifest['files'][n]
    tg={'espn:'+g['espn_source_match_id']:g for g in targets()};selected={};contract={}
    with tarfile.open(R5/names[0]) as bundle:
        for nam in bundle.getnames():
            if not nam.endswith('v000001.json') or nam.split('/')[0] not in ('issued','original-issued'):continue
            b=bundle.extractfile(nam).read();r=json.loads(b);key=r['match_id']
            if key not in tg:continue
            store=selected if nam.startswith('original-issued/') else contract
            g=tg[key];f=r['fixture'];assert key not in store and r['record_sha256']==canon(r) and r['revision']==1 and r['previous_sha256'] is None
            assert instant(f['kickoff_at'])==instant(g['kickoff_utc']) and all(f[s]=='espn:'+g['espn_'+s+'_id'] for s in ('home','away'))
            stored=ROOT/'signed-firsts'/nam.rsplit('/',1)[1];stored.parent.mkdir(exist_ok=True)
            if not stored.exists():stored.write_bytes(b)
            assert stored.read_bytes()==b
            store[key]=dict(track=r['track'],record_sha256=r['record_sha256'],file_sha256=digest(b),file=str(stored.relative_to(ROOT)),recorded_at=r['recorded_at'],
                cutoff_at=f['cutoff_at'],prices=r['payload']['prices'],bookmaker=r['payload']['market_evidence']['h2h']['bookmaker'],market_evidence=r['payload']['market_evidence'])
    assert set(selected)==set(contract)==set(tg)
    for key in selected:
        assert selected[key]['prices']==contract[key]['prices']
        selected[key]['source_contract_record']=contract[key]
    with tarfile.open(R5/names[1]) as bundle:
        queries=json.load(bundle.extractfile('forward/queries.json'));print('queries',type(queries),str(queries)[:240])
        if isinstance(queries,dict):queries=next(v for v in queries.values() if isinstance(v,list))
        for key,s in selected.items():
            for market,ev in s['market_evidence'].items():
                url=ev['source_url']
                if url.startswith('https://api.infersports.dev/'):
                    anchor=read(R5/'evidence/source-index.json')[ev['source_sha256']]
                    ext=R5.parents[1]/anchor['repository_path']
                    with tarfile.open(ext) as xb:
                        data=xb.extractfile(anchor['member']).read();assert digest(data)==ev['source_sha256']
                        cap=json.load(xb.extractfile('context/raw-live-20261123T0403Z/capture-manifest.json'))
                        a=next(z for z in cap['records'] if z['sha256']==ev['source_sha256'] and z['espn_match_id']==key)
                        assert a['retrieved_at_utc']==ev['observed_at']
                        z=json.loads(data);assert z['event_id']==a['event_id']
                        matches=[o for o in z['odds'] if o['as_of']==ev['quoted_at'] and o['bookmaker']==ev['bookmaker'] and o['period']=='full_time' and o['status']=='open']
                        wanted=s['prices'][market]
                        assert any(all(o['prices'].get(k)==v for k,v in wanted.items() if k!='line') and (market=='h2h' or float(o['line'])==wanted['line']) for o in matches)
                        lab='r5-infer-'+a['event_id']
                        if not (ROOT/'sources'/(lab+'.json')).exists():
                            write_source(lab,data,dict(mode='signed_R5_source_bytes',url=url,http_status=a['status'],requested_utc=None,received_utc=a['retrieved_at_utc'],capture_batch_started_utc=cap['capture_started_by_process_utc'],original_member=anchor['member']))
                        ev['raw_key']=lab
                    continue
                stamp=parse_qs(urlsplit(url).query)['dates'][0];name='forward/raw/ger_1_'+stamp+'.json'
                rawbody=bundle.extractfile(name).read();assert digest(rawbody)==ev['source_sha256']
                matches=[q for q in queries if q.get('url')==url and q.get('sha256')==ev['source_sha256']];q=matches[0] if matches else {}
                assert key.split(':')[1] in {str(x['id']) for x in json.loads(rawbody)['events']}
                lab='r5-board-'+stamp
                if not (ROOT/'sources'/(lab+'.json')).exists():
                    write_source(lab,rawbody,dict(url=url,mode='signed_R5_source_bytes',requested_utc=q.get('requested_at_utc') or q.get('query_time_utc'),
                        received_utc=q.get('received_at_utc') or q.get('captured_at_utc'),original_observed_at_utc=ev['observed_at'],
                        original_archive_sha256=manifest['files'][names[1]],original_member=name,original_query_record=q,http_status=q.get('status')))
                ev['raw_key']=lab
    save(ROOT/'signed-first-index.json',selected)
def probe():
    ids=[]
    for g in targets():
        eid=g['espn_source_match_id'];odds=content('espn-refresh-'+eid).get('odds',[])
        dk=next((o for o in odds if str(o['provider']['id'])=='100'),None)
        a=dk and dk['moneyline']['home']['close']['link']['href']
        if a:
            url=parse_qs(urlsplit(a).query).get('preurl',[None])[0];match=re.search(r'https://sportsbook.draftkings.com/event/(\d+)',url or '')
            if match:ids.append((eid,match[1]))
    if ids:
        e,n=ids[0];get('dk-direct-'+e,'https://sportsbook.draftkings.com/event/'+n)
    for prov in ('100','2000'):
        eid=targets()[0]['espn_source_match_id'];o=content('espn-core-'+eid)
        available={str(z['provider']['id']) for z in o['items']}
        if prov not in available:continue
        get('espn-movement-check-'+prov,f'https://sports.core.api.espn.com/v2/sports/soccer/leagues/ger.1/events/{eid}/competitions/{eid}/odds/{prov}/history')
if __name__=='__main__':archive();probe()
