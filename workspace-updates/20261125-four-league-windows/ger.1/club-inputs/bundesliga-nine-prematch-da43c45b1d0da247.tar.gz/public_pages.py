from evidence import *
from html.parser import HTMLParser
from urllib.parse import urljoin,urlsplit
from concurrent.futures import ThreadPoolExecutor
import re, sys, unicodedata

CLUBS={
'8697':'https://www.werder.de/','9788':'https://www.borussia.de/','8460':'https://www.scp07.de/','10189':'https://schalke04.de/',
'8722':'https://fc.de/','8232':'https://sv07elversberg.de/','9790':'https://www.hsv.de/','9823':'https://fcbayern.com/de/news',
'9905':'https://www.mainz05.de/','8149':'https://www.fc-union-berlin.de/de/','10269':'https://www.vfb.de/de/vfb/aktuell/neues/',
'9810':'https://profis.eintracht.de/news/','8358':'https://www.scfreiburg.com/','178475':'https://rbleipzig.com/de',
'8226':'https://www.tsg-hoffenheim.de/','8406':'https://www.fcaugsburg.de/','9789':'https://www.bvb.de/de/de/aktuelles/news.html',
'8178':'https://www.bayer04.de/de-de/news'}
def clean(s):return ' '.join(s.split())
class Page(HTMLParser):
    def __init__(self,b):
        super().__init__(convert_charrefs=True);self.links=[];self.parts=[];self.metatags={};self.scripts=[];self.script=None;self.anchor=None;self.tag=None;self.chunk=[]
        self.feed(b.decode('utf-8','replace'));self.flush()
    def flush(self):
        if self.chunk:
            val=clean(' '.join(self.chunk));self.chunk=[]
            if val:self.parts.append(val)
    def handle_starttag(self,t,attrs):
        a=dict(attrs)
        if t in ('script','style'):self.script=[a,[]];return
        if self.script is not None:return
        if t=='meta':self.metatags[a.get('property') or a.get('name') or '']=a.get('content')
        if t=='a':
            self.anchor=[a.get('href',''),[a.get('title','') or '',a.get('aria-label','') or '']]
        if t in ('p','div','br','li','h1','h2','h3','h4','tr','section','article','time','td'):self.flush()
    def handle_endtag(self,t):
        if t in ('script','style') and self.script is not None:
            if t=='script':self.scripts.append((self.script[0],''.join(self.script[1])))
            self.script=None
        if self.script is not None:return
        if t=='a' and self.anchor is not None:
            self.links.append((self.anchor[0],clean(' '.join(self.anchor[1]))));self.anchor=None
        if t in ('p','div','br','li','h1','h2','h3','h4','tr','section','article','time','td'):self.flush()
    def handle_data(self,d):
        if self.script is not None:self.script[1].append(d);return
        if self.anchor is not None:self.anchor[1].append(d)
        self.chunk.append(d)
def page(key):return Page(decoded(meta(key)))
def distinct_links(key):
    m=meta(key);base=m.get('resolved_url',m['url']);seen={}
    for a,t in page(key).links:
        link=urljoin(base,a)
        if urlsplit(link).scheme in ('http','https'):seen[link]=max(t,seen.get(link,''),key=len)
    return list(seen.items())
def roots():
    jobs=[('club-index-'+t,u) for t,u in CLUBS.items()]
    jobs += [('kicker-md11','https://www.kicker.de/bundesliga/spieltag/2026-27/11'),
             ('ligainsider-XI','https://www.ligainsider.de/bundesliga/aufstellungen/')]
    with ThreadPoolExecutor(max_workers=5) as pool:list(pool.map(lambda job:get(*job),jobs))
if __name__=='__main__':roots()
