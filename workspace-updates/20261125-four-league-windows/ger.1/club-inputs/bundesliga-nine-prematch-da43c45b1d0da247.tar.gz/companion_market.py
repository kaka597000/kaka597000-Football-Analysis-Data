"""Read the preserved PR #57 early-control archive in memory, without network access."""
import csv
import io
import json
import tarfile
from datetime import timedelta
from pathlib import Path

from evidence import ROOT, digest, instant, read, targets

COMPANION_SHA = '70f2c00ae86331b66981bd8a2e65c75adcf4099c5ad4afed0e013e7ce5b4270d'


def canonical(row):
    return digest(json.dumps(row, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode())


def early_market():
    receipt = read(ROOT/'coordination/infersports-early-result.json')
    path = ROOT/'companion'/Path(receipt['bundle']).name
    assert digest(path.read_bytes()) == receipt['sha256'] == COMPANION_SHA
    with tarfile.open(path, 'r:gz') as arch:
        def member(name):
            return arch.extractfile(name).read()

        def payload(name):
            return json.loads(member(name))

        def source(name):
            raw = member(name)
            m = payload(name.removesuffix('.json') + '.meta.json')
            assert m['path'] == name and m['method'] == 'GET' and m['http_status'] == 200
            assert m['sha256'] == digest(raw) and m['bytes'] == len(raw)
            assert instant(m['request_started_utc']) <= instant(m['response_received_utc'])
            ref = dict(archive=str(path.relative_to(ROOT)), archive_sha256=COMPANION_SHA, member=name,
                       url=m['url'], sha256=m['sha256'], requested_utc=m['request_started_utc'],
                       received_utc=m['response_received_utc'])
            return json.loads(raw), ref

        for name, hash_value in receipt['normalized'].items():
            assert digest(member('derived/' + Path(name).name)) == hash_value
        identities = payload('derived/fixtures.json')
        metrics = payload('derived/readback.json')
        assert metrics == receipt['metrics'] and metrics['fixtures'] == len(identities) == 9
        quote_rows = list(csv.DictReader(io.StringIO(member('derived/quotes.csv').decode())))
        pairs = list(csv.DictReader(io.StringIO(member('derived/same-book.csv').decode())))
        out = {}
        for f, g in zip(identities, targets(), strict=True):
            eid = g['espn_source_match_id']
            assert f['espn_event_id'] == eid and f['fotmob_event_id'] == g['fotmob_source_match_id']
            assert f['registration_sha256'] == read(ROOT/'registered-nine.json')['record_sha256']
            for side, team in f['sides'].items():
                assert team['espn_id'] == g['espn_' + side + '_id'] and team['fotmob_id'] == g['fotmob_' + side + '_id']
            listing, calendar_source = source(f['source_calendar_path'])
            event, = (e for e in listing['data'] if e['id'] == f['infer_event_id'])
            assert all(event[s+'_team'] == dict(id=t['infer_id'], name=t['infer_name']) for s,t in f['sides'].items())
            kickoff = instant(g['kickoff_utc'])
            assert instant(event['scheduled_at']) == kickoff == instant(f['kickoff_utc'])
            assert event['status'] == 'scheduled' and event['league'] == f['infer_league']
            doc, raw = source('raw/infersports/' + event['id'] + '-odds.json')
            assert doc['event_id'] == event['id'] and doc['stale'] is False
            assert instant(calendar_source['received_utc']) <= instant(raw['requested_utc'])
            assert instant(raw['received_utc']) < kickoff - timedelta(hours=24)
            field_rows = [r for r in quote_rows if r['match_id'] == f['match_id']]
            observed = []
            for i, (q,r) in enumerate(zip(doc['odds'], field_rows, strict=True)):
                assert i == int(r['row_index']) and canonical(q) == r['row_sha256']
                assert r['quote_as_of_utc'] == q['as_of'] and instant(q['as_of']) <= instant(raw['received_utc'])
                assert (r['raw_sha256'], r['source_url']) == (raw['sha256'],raw['url'])
                observed.append(dict(row_index=i, row_sha256=r['row_sha256'], **q,
                                     eligible=r['eligible'] == 'True', exclusion=r['exclusion'] or None))
            local_pairs = [r for r in pairs if r['match_id'] == f['match_id']]
            for r in local_pairs:
                money = observed[int(r['moneyline_raw_index'])]
                total = observed[int(r['total_raw_index'])]
                assert money['eligible'] and total['eligible'] and money['market_type']=='1x2' and total['market_type']=='totals'
                assert money['bookmaker'] == r['bookmaker'] == total['bookmaker']
                assert (money['row_sha256'],total['row_sha256']) == (r['moneyline_row_sha256'],r['total_row_sha256'])
                assert (money['as_of'],total['as_of']) == (r['moneyline_quote_utc'],r['total_quote_utc'])
            out[eid] = dict(control=metrics['control'], collector=receipt['sender'], infer_event_id=event['id'],
                            sides=f['sides'], calendar_source=calendar_source, source=raw, response_as_of=doc['as_of'],
                            clock_scope='per-book per-market as_of published by InferSports',
                            independently_observed_bookmaker_system_updated_at=None, source_rows=observed,
                            same_book_pairs=len(local_pairs), fresh_equal_pairs=sum(r['same_time_and_within_one_hour']=='True' for r in local_pairs))
    assert sum(len(v['source_rows']) for v in out.values()) == metrics['source_rows']
    assert sum(v['same_book_pairs'] for v in out.values()) == metrics['same_book_pairs']
    return out, metrics
