from evidence import *
import sys,re,html
from collections import defaultdict

def init():
    plan=read(REG/'plan.json');rec=read(REG/plan['file'])
    checksum=digest(json.dumps({k:v for k,v in rec.items() if k!='record_sha256'},sort_keys=True,ensure_ascii=False,separators=(',',':')).encode())
    if checksum!=plan['sha256'] or checksum!=rec['record_sha256']:raise ValueError('registration checksum')
    originals=ROOT/'registration';originals.mkdir(exist_ok=True)
    for name in ('plan.json',plan['file']):shutil.copyfile(REG/name,originals/name)
    key='nov27_dec04';slate=rec['payload']['identity']['slates'][key]
    mapping={'espn:'+str(x['espn_source_match_id']):x for l in (PREVIOUS/'inputs/first-window-40.jsonl').read_text().splitlines() if (x:=json.loads(l))['competition']=='ger.1'}
    assert set(slate)==set(mapping) and len(slate)==len(set(slate))==9
    fixtures=[]
    for eid in slate:
        a=rec['payload']['fixtures'][eid];b=mapping[eid]
        assert a['cohort']=='ger.1' and a['stage']=='regular' and a['match_id']==eid
        assert all(a[s]=='espn:'+str(b['espn_'+s+'_id']) for s in ('home','away'))
        assert instant(a['kickoff_at'])==instant(b['kickoff_utc'])==instant(b['fotmob_kickoff_utc'])
        fixtures.append(b)
    assert len({str(b['fotmob_'+s+'_id']) for b in fixtures for s in ('home','away')})==18
    save(ROOT/'registered-nine.json',dict(window=key,official_pool='data PR #57 ger.1/registration',record_sha256=checksum,
            record_file_sha256=digest((REG/plan['file']).read_bytes()),join_file_sha256=digest((PREVIOUS/'inputs/first-window-40.jsonl').read_bytes()),fixtures=fixtures))
    for tag,p in [('fotmob-season','inputs/calendar/ger-2026-2027'),('espn-season','inputs/espn-season/ger-2026')]:
        reuse(tag,PREVIOUS/(p+'.json'),PREVIOUS/(p+'.meta.json'))
    for f in fixtures:
        eid=f['espn_source_match_id'];p=PREVIOUS/'raw/espn-summaries'/eid
        reuse('espn-first-'+eid,p.with_suffix('.json'),p.with_suffix('.meta.json'))
    for p in (PREVIOUS/'raw/fotmob-details').glob('588*.meta.json'):
        mid=p.name.split('.')[0];reuse('fotmob-history-'+mid,p.with_name(mid+'.json'),p)
    save(ROOT/'execution.json',dict(requested_collector='gpt-6-luna',luna_completed=False,
            blocked='Codex model endpoint returned HTTP 401; no subagent response',review_collector='local public HTTP evidence and archived source verification',
            snapshot_started_utc='2026-11-25T13:23:02Z'))
def fotmob():
    f=targets()
    for g in f:
        mid=g['fotmob_source_match_id'];get('fotmob-target-'+mid,'https://www.fotmob.com/api/data/matchDetails?matchId='+mid)
    for g in f:
        for side in ('home','away'):
            t=str(g['fotmob_'+side+'_id']);get('fotmob-team-'+t,'https://www.fotmob.com/api/data/teams?id='+t+'&ccode3=USA')
def espn():
    for g in targets():
        eid=g['espn_source_match_id']
        get('espn-refresh-'+eid,'https://site.api.espn.com/apis/site/v2/sports/soccer/ger.1/summary?event='+eid)
def core():
    for g in targets():
        eid=g['espn_source_match_id'];url=f'https://sports.core.api.espn.com/v2/sports/soccer/leagues/ger.1/events/{eid}/competitions/{eid}/odds'
        m=get('espn-core-'+eid,url)
        if m.get('http_status')!=200:continue
        for o in json.loads(raw(m)).get('items',[]):
            provider=str(o.get('provider',{}).get('id',''))
            if not provider:continue
            ref=(o.get('movement') or {}).get('$ref')
            if ref and ref.startswith(('https://sports.core.api.espn.com/','http://sports.core.api.espn.com/')):
                get('espn-odds-history-'+eid+'-'+provider,ref.replace('http://','https://',1))
def league():
    links=list(dict.fromkeys(html.unescape(x) for x in re.findall(r'href="([^"]+)"',raw(meta('bundesliga-md11')).decode())))
    paths=[x for x in links if '/matchday/2026-2027/11/' in x and x.endswith('/liveticker')]
    assert len(paths)==9
    for i,p in enumerate(paths):get('dfl-game-'+str(i+1),'https://www.bundesliga.com'+p)
    get('dfl-predictions-index','https://www.bundesliga.com/en/bundesliga/news')
if __name__=='__main__':{'init':init,'fotmob':fotmob,'espn':espn,'core':core,'league':league}[sys.argv[1]]()
