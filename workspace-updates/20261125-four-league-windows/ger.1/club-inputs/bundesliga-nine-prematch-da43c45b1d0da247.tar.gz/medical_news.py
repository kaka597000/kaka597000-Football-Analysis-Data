from team_news import *
import re
CHOSEN={'8697':[421115,421072],'9788':[421109,421104,421107],'8460':[421141,421030],'8232':[421037,420995],'8722':[421143,421092],
'9790':[421147],'9823':[421123],'9905':[420946],'8149':[421119,421001],'10269':[421129],'9810':[421114],
'8358':[420913],'178475':[421145,421076],'8226':[421060],'8406':[],'9789':[421079,421071],'8178':[421007]}
def collect():
 for tid, wanted in CHOSEN.items():
    src='li-club-'+tid
    if meta(src).get('http_status')!=200:continue
    for url,t in distinct_links(src):
        n=re.search(r'-(\d{6})/$',url)
        if n and int(n[1]) in wanted:
            if n[1]=='421060':continue
            get('medical-'+tid+'-'+n[1],url)
 src='li-lineup-schalke'
 get(src,'https://www.ligainsider.de/fc-schalke-04/13/')
 if meta(src).get('http_status')==200:
    candidates=[u for u,t in distinct_links(src) if re.search('-421[01][0-9]{2}/$',u) and any(z in u for z in ('training','verletzt','rueckkehr','ausfall','aus-','comeback','kader'))]
    for u in candidates[:4]:get('medical-10189-'+u.rstrip('/').split('-')[-1],u)
if __name__=='__main__':collect()
