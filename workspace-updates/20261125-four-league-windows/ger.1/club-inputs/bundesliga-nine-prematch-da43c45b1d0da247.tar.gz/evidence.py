"""Timestamp and retain public source responses. Each label identifies one immutable read."""
from datetime import datetime, timezone
from pathlib import Path
import csv, fcntl, gzip, hashlib, io, json, os, shutil, time, urllib.error, urllib.request
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parent
PREVIOUS = Path('/workspace/scratch/europe-stage-team-intake-20261125')
REG = Path('/workspace/scratch/europe-window-data/workspace-updates/20261125-four-league-windows/ger.1/registration')
def now():
    return datetime.now(timezone.utc).isoformat(timespec='microseconds').replace('+00:00','Z')
def instant(s):
    v = datetime.fromisoformat(s.replace('Z','+00:00'))
    if v.tzinfo is None: raise ValueError('timezone missing: ' + s)
    return v
def read(path):
    return json.loads(Path(path).read_bytes())
def save(path,data):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    b=(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
    if p.exists():
        if p.read_bytes()!=b: raise ValueError('different content exists: '+str(path))
    else: p.write_bytes(b)
def digest(raw): return hashlib.sha256(raw).hexdigest()
def meta(label): return read(ROOT/'sources'/(label+'.json'))
def raw(m): 
    data=gzip.decompress((ROOT/m['raw_path']).read_bytes())
    if len(data)!=m['bytes'] or digest(data)!=m['sha256']: raise ValueError('corrupt: '+m['key'])
    return data
def decoded(m):
    data=raw(m)
    return gzip.decompress(data) if data.startswith(bytes.fromhex('1f8b')) else data
def content(label): return json.loads(decoded(meta(label)))
def write_source(label, data, details):
    s=digest(data)
    p=ROOT/'raw'/(s+'.gz')
    p.parent.mkdir(exist_ok=True)
    if not p.exists():p.write_bytes(gzip.compress(data,compresslevel=6,mtime=0))
    details=dict(key=label,raw_path=str(p.relative_to(ROOT)),bytes=len(data),sha256=s,**details)
    save(ROOT/'sources'/(label+'.json'),details)
    return details
def reuse(label,path,sidecar):
    m=read(sidecar);data=Path(path).read_bytes()
    if digest(data)!=m['sha256'] or m.get('http_status')!=200:raise ValueError(str(path))
    req=m.get('query_time_utc') or m.get('observed_request_start_utc') or m.get('requested_at_utc')
    resp=m.get('retrieval_time_utc') or m.get('observed_response_end_utc') or m.get('captured_at_utc')
    if not req or not resp or instant(resp)<instant(req):raise ValueError('incomplete clocks: '+str(path))
    return write_source(label,data,dict(mode='retained_response',url=m.get('source_url') or m.get('url'),
                requested_utc=req,received_utc=resp,http_status=200,content_type=m.get('content_type'),
                original_path=str(path),original_sidecar=str(sidecar)))
def get(label,url,*,encoding=None):
    path=ROOT/'sources'/(label+'.json')
    if path.exists():
        m=read(path)
        if url!=m['url']:raise ValueError('URL changed: '+label)
        if 'raw_path' in m:raw(m)
        return m
    host=urlsplit(url).netloc
    lockdir=ROOT/'.locks';lockdir.mkdir(exist_ok=True)
    with (lockdir/host).open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        if path.exists():return read(path)
        block=lockdir/(host+'.blocked')
        if block.exists():
            return dict(key=label,url=url,http_status=None,error='provider paused after '+block.read_text())
        begin=now()
        headers={'Accept':'application/json,text/html;q=0.9,*/*;q=0.5','User-Agent':'Mozilla/5.0 (compatible; football research; public source evidence)'}
        if encoding:headers['Accept-Encoding']=encoding
        try:
            response=urllib.request.urlopen(urllib.request.Request(url,headers=headers),timeout=22)
        except urllib.error.HTTPError as e:
            response=e
        except (urllib.error.URLError,TimeoutError,OSError) as e:
            m=dict(key=label,url=url,mode='public_http',requested_utc=begin,received_utc=now(),http_status=None,error=str(e))
            save(path,m);print(label,'network failure',str(e)[:100],flush=True);return m
        with response as f:
            data=f.read();end=now();code=f.status
            head={k:v for k,v in f.headers.items() if k.lower() in {'date','last-modified','age','etag','content-encoding','content-type','cache-control'}}
            m=write_source(label,data,dict(mode='public_http',url=url,resolved_url=f.geturl(),requested_utc=begin,
              received_utc=end,http_status=code,content_type=f.headers.get('Content-Type'),response_headers=head))
        if code in (401,403,429):block.write_text(str(code)+' '+label)
        print(label,code,len(data),flush=True);return m

def targets():return read(ROOT/'registered-nine.json')['fixtures']
