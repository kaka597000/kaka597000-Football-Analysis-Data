from evidence import *
from datetime import timedelta
from collections import defaultdict
import re,sys

KNOWN_TOURNAMENTS={54:'ger.1',209:'ger.dfb_pokal',42:'uefa.champions',73:'uefa.europa',10216:'uefa.europa.conf'}
SNAP=instant(read(ROOT/'execution.json')['snapshot_started_utc'])
def selection():
    out={};catalog={}
    for game in targets():
        for side in ('home','away'):
            tid=str(game['fotmob_'+side+'_id'])
            doc=content('fotmob-team-'+tid);assert str(doc['details']['id'])==tid and doc['details']['primaryLeagueId']==54
            rows=doc['fixtures']['allFixtures']['fixtures']
            assert len(rows)==len({str(r['id']) for r in rows})
            rows=sorted(rows,key=lambda r:(instant(r['status']['utcTime']),int(r['id'])))
            def official(r):
                return 'friendl' not in r['tournament']['name'].lower() and not r['status'].get('awarded') and not r['status'].get('cancelled')
            for r in rows:
                assert tid in {str(r[s]['id']) for s in ('home','away')}
            finished=[r for r in rows if official(r) and r['status'].get('finished') and instant(r['status']['utcTime'])<SNAP]
            scopes={'all_competitions':finished[-5:][::-1], 'bundesliga':[r for r in finished if r['tournament']['leagueId']==54][-5:][::-1]}
            pending=[r for r in rows if official(r) and not r['status'].get('finished') and instant(r['status']['utcTime'])<instant(game['kickoff_utc']) and instant(r['status']['utcTime'])>instant(finished[-1]['status']['utcTime'])]
            last=instant(finished[-1]['status']['utcTime'])
            friendlies=[r for r in rows if not official(r) and not r['status'].get('awarded') and not r['status'].get('cancelled') and instant(scopes['all_competitions'][-1]['status']['utcTime'])<=instant(r['status']['utcTime'])<instant(game['kickoff_utc'])]
            out[tid]=dict(espn_team_id=game['espn_'+side+'_id'],fotmob_team_id=tid,target_fotmob_id=game['fotmob_source_match_id'],
                    name=game['fotmob_'+side],schedule_source='fotmob-team-'+tid,fixture_lists={k:[str(r['id']) for r in v] for k,v in scopes.items()},
                    intermediate=pending,friendlies_in_span=friendlies,prior_to_oldest={})
            for scope,selected in scopes.items():
                assert len(selected)==5
                prev=[r for r in finished if instant(r['status']['utcTime'])<instant(selected[-1]['status']['utcTime'])]
                out[tid]['prior_to_oldest'][scope]=prev[-1] if prev else None
                for r in selected:
                    mid=str(r['id'])
                    if mid in catalog:
                        old=catalog[mid]
                        assert all(old[k]['id']==r[k]['id'] for k in ('home','away')) and old['status']==r['status'] and old['tournament']['leagueId']==r['tournament']['leagueId']
                    catalog[mid]=r
    return out,catalog
def fetch():
    teams,catalog=selection();save(ROOT/'selection.json',dict(teams=teams,fixtures=catalog))
    for mid,r in sorted(catalog.items()):
        lab='fotmob-history-'+mid
        if not (ROOT/'sources'/(lab+'.json')).exists():get(lab,'https://www.fotmob.com/api/data/matchDetails?matchId='+mid)
def boards():
    teams,catalog=selection()
    for league in sorted({r['tournament']['leagueId'] for r in catalog.values()}-{54}):
        key=KNOWN_TOURNAMENTS[league]
        matches=[r for r in catalog.values() if r['tournament']['leagueId']==league]
        lo=min(r['status']['utcTime'][:10] for r in matches).replace('-','');hi=max(r['status']['utcTime'][:10] for r in matches).replace('-','')
        get('espn-board-'+str(league),f'https://site.api.espn.com/apis/site/v2/sports/soccer/{key}/scoreboard?dates={lo}-{hi}&limit=1000')
if __name__=='__main__':{'fetch':fetch,'boards':boards}[sys.argv[1]]()
