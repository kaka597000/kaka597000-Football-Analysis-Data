from public_pages import *
from urllib.parse import urlencode
from concurrent.futures import ThreadPoolExecutor
import xml.etree.ElementTree as ET
jobs=[('fcb-lille','https://fcbayern.com/de/news/vorberichte/2026/11/vorschau-champions-league-osc-lille-fc-bayern'),
      ('sge-vfb','https://profis.eintracht.de/news/vorschau-anknuepfen-vfb-stuttgart-eintracht-frankfurt-bundesliga-2026-27-180585/')]
# Find links as given by verified first-party pages or site maps.
for k,tid,terms in [('club-more-8178','8178',['dinamo','gegnercheck','zagreb']),('club-index-9905','9905',['union','kohr']),('club-index-8460','8460',['Schnell-abhaken']),
       ('club-index-10189','10189',['vitalie-becker-das-war-genau']),('club-more-8358','8358',['laenderspielabstellungen-in-der-uebersicht'])]:
    for h,t in distinct_links(k):
        if urlsplit(h).netloc != urlsplit(meta(k)['resolved_url']).netloc:continue
        if any(w in h for w in terms) and not re.search('shop|ticket|faninfo|fans/|frauen|u19',h) and len(urlsplit(h).path)>27:
            jobs.append(('club-review-'+tid+'-'+digest(h.encode())[:8],h))
for i,g in enumerate(targets(),1):
 q='("'+g['fotmob_home']+'" "'+g['fotmob_away']+'") (Personal OR Ausfälle OR Pressekonferenz OR Verletzung) when:5d'
 jobs.append(('gnews-fixture-'+str(i),'https://news.google.com/rss/search?'+urlencode(dict(q=q,hl='de',gl='DE',ceid='DE:de'))))
def job(arg):return get(*arg)
with ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(job,jobs))
get('li-availability-compressed',meta('li-availability')['url'],encoding='gzip')
