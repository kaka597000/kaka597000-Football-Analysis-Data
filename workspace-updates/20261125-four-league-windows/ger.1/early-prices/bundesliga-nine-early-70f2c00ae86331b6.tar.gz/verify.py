"""Offline byte-for-byte rebuild plus direct independent extraction of every market and clock."""
from collections import Counter
import csv
from datetime import timedelta
import json

from build import derive
from fetch import ROOT, digest, load, response
from identity import canonical, check, dt


def csv_rows(name):
    with (ROOT / 'derived' / name).open() as handle:
        return list(csv.DictReader(handle))


def main():
    for name, content in derive().items():
        check((ROOT / 'derived' / name).read_bytes() == content, 'rebuild mismatch: ' + name)
    sources = ROOT / 'raw/infersports'
    raw_paths = sorted(p for p in sources.glob('*.json') if not p.name.endswith('.meta.json'))
    check(len(raw_paths) == 13 and len(list(sources.glob('*.meta.json'))) == 13, 'one anchor, three slates, nine new price reads')
    for p in raw_paths:
        _, m = response(p.stem)
        check(dt(m['request_started_utc']) <= dt(m['response_received_utc']), 'request clock')
    ref = ROOT / 'reference'
    clock_doc = ref / 'infer-public-guide.txt'
    schema = load(ref / 'infer-public-schema.json')
    check(digest(clock_doc.read_bytes()) == load(ref / 'infer-public-guide.meta.json')['sha256'] ==
          '29f28a777ed60dd71214d138cde9b5255b116e32628d60a0f3913aff619e58c9' and
          'last upstream update applied' in clock_doc.read_text().split('### OddsQuote — one bookmaker × one market line')[1].split('###')[0]
          and 'as_of' in schema['components']['schemas']['OddsQuote']['required'], 'native timestamp definition')
    fixtures = load(ROOT / 'derived/fixtures.json')
    quotes = csv_rows('quotes.csv')
    idx = {(r['match_id'], int(r['row_index'])): r for r in quotes}
    check(len(quotes) == len(idx), 'unique source row')
    expected_pairs, source_keys = {}, set()
    books, open_by_market = set(), Counter()
    suspended = 0
    for f in fixtures:
        mid = f['match_id']
        doc, meta = response(f['infer_event_id'] + '-odds')
        receipt = dt(meta['response_received_utc'])
        check(doc['event_id'] == f['infer_event_id'] and doc['stale'] is False and
              receipt < dt(f['kickoff_utc']) - timedelta(hours=24), 'valid control time')
        money, totals = {}, []
        for i, q in enumerate(doc['odds']):
            r = idx[mid, i]
            source_keys.add((mid, i))
            age = (receipt - dt(q['as_of'])).total_seconds()
            check(r['quote_as_of_utc'] == q['as_of'] and age >= 0 and float(r['quote_age_seconds_at_receipt']) == age
                  and r['response_received_utc'] == meta['response_received_utc'] and r['response_as_of_utc'] == doc['as_of']
                  and r['row_sha256'] == canonical(q) and r['raw_sha256'] == meta['sha256'] and
                  r['bookmaker'] == q['bookmaker'] and r['market'] == q['market_type'] and r['status'] == q['status']
                  and (None if r['line'] == '' else float(r['line'])) == q['line']
                  and json.loads(r['split_components']) == q['handicap_components'], 'source row identity/line/clock')
            for side in ('home', 'draw', 'away', 'over', 'under'):
                cell = r[side + '_price']
                check((None if cell == '' else float(cell)) == q['prices'].get(side), 'posted source price')
            check(q['format'] == 'decimal' and q['period'] == 'full_time', 'native scope')
            if q['status'] == 'open':
                check(all(v > 1 for v in q['prices'].values()) and r['eligible'] == 'True', 'open complete row')
                books.add(q['bookmaker'])
                open_by_market[q['market_type']] += 1
                if q['market_type'] == '1x2':
                    check(q['bookmaker'] not in money and set(q['prices']) == {'home','draw','away'}, 'unique complete 1x2')
                    money[q['bookmaker']] = (i, q, age)
                if q['market_type'] == 'totals':
                    check(set(q['prices']) == {'over','under'}, 'both sides')
                    totals.append((i, q, age))
            else:
                check(q['status'] == 'suspended' and r['eligible'] == 'False', 'suspended original')
                suspended += 1
        for j, total, total_age in totals:
            if total['bookmaker'] in money:
                i, h, h_age = money[total['bookmaker']]
                equal = dt(h['as_of']) == dt(total['as_of'])
                fresh = max(h_age, total_age) <= 3600
                expected_pairs[mid, i, j] = (h['as_of'], total['as_of'], equal, fresh, total['line'], total['bookmaker'])
    check(source_keys == idx.keys(), 'all source rows represented')
    observed = {}
    for p in csv_rows('same-book.csv'):
        k = p['match_id'], int(p['moneyline_raw_index']), int(p['total_raw_index'])
        check(k not in observed, 'duplicate same-book pair')
        observed[k] = (p['moneyline_quote_utc'], p['total_quote_utc'], p['same_time']=='True',
                       p['both_within_one_hour']=='True', float(p['total_line']), p['bookmaker'])
    check(observed == expected_pairs, 'all pairs, both clocks and book/line')
    strict = {k[0] for k, v in observed.items() if v[2] and v[3]}
    check((len(fixtures), len(idx), sum(open_by_market.values()), suspended, len(books), len(observed), len(strict)) ==
          (9, 352, 333, 19, 5, 144, 7), 'observed snapshot metrics')
    print('Offline verification passed: 9 registered, 352 raw rows, 333 open, 19 suspended, 144 same-book pairs, 7/9 equal and within one hour.')


if __name__ == '__main__':
    main()
