"""Pack and verify the registered German early control with Python's standard library."""
import argparse
import gzip
from hashlib import sha256
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import tarfile
from tempfile import TemporaryDirectory

ROOT = Path(__file__).resolve().parent
PREFIX = 'bundesliga-nine-early-'


def sha(path):
    return sha256(path.read_bytes()).hexdigest()


def inventory(root):
    files = [root / 'README.md', *root.glob('*.py')]
    for folder in ('raw', 'registration', 'reference', 'coordination', 'derived'):
        files.extend(p for p in (root / folder).rglob('*') if p.is_file())
    if any(p.is_symlink() or not p.is_file() for p in files):
        raise ValueError('non-regular input')
    return sorted(p.relative_to(root).as_posix() for p in files)


def sums(root):
    return ''.join(sha(root / f) + '  ' + f + '\n' for f in inventory(root))


def build():
    (ROOT / 'SHA256SUMS').write_text(sums(ROOT))
    members = sorted(['SHA256SUMS', *inventory(ROOT)])
    with TemporaryDirectory(dir=ROOT, prefix='.pack-') as tmp:
        work = Path(tmp) / 'temp.tar.gz'
        with work.open('wb') as fd, gzip.GzipFile(fileobj=fd, mode='wb', filename='', mtime=0, compresslevel=6) as gz:
            with tarfile.open(fileobj=gz, mode='w|', format=tarfile.USTAR_FORMAT) as tar:
                for name in members:
                    p = ROOT / name
                    obj = tarfile.TarInfo(name)
                    obj.size, obj.mode = p.stat().st_size, 0o644
                    with p.open('rb') as source:
                        tar.addfile(obj, source)
        h = sha(work)
        out = ROOT / (PREFIX + h[:16] + '.tar.gz')
        if out.exists():
            if sha(out) != h:
                raise ValueError('archive name collision')
        else:
            work.rename(out)
        (ROOT / (out.name + '.sha256')).write_text(h + '  ' + out.name + '\n')
        print(h, out.name, len(members), 'files')


VERIFY = """
import pathlib, runpy, sys
def block(event, args):
    if event.startswith('socket.'):
        raise RuntimeError('offline replay')
sys.addaudithook(block)
sys.path.insert(0, str(pathlib.Path.cwd()))
runpy.run_path('verify.py', run_name='__main__')
"""


def replay(archive):
    h = sha(archive)
    if archive.name != PREFIX + h[:16] + '.tar.gz':
        raise ValueError('wrong archive identifier')
    sidecar = archive.with_name(archive.name + '.sha256')
    if sidecar.exists() and sidecar.read_text() != h + '  ' + archive.name + '\n':
        raise ValueError('outer checksum')
    with TemporaryDirectory(dir=ROOT, prefix='.replay-') as tmp:
        destination = Path(tmp)
        seen = set()
        with tarfile.open(archive, 'r:gz') as tar:
            for m in tar:
                name = PurePosixPath(m.name)
                if not m.isfile() or name.is_absolute() or '..' in name.parts or m.name in seen or name.as_posix() != m.name:
                    raise ValueError('unsafe or duplicate member')
                seen.add(m.name)
                p = destination / m.name
                p.parent.mkdir(exist_ok=True, parents=True)
                with tar.extractfile(m) as src, p.open('xb') as dst:
                    shutil.copyfileobj(src, dst)
        if seen != set(inventory(destination)) | {'SHA256SUMS'} or sums(destination) != (destination / 'SHA256SUMS').read_text():
            raise ValueError('member list or hashes')
        subprocess.run([sys.executable, '-I', '-B', '-c', VERIFY], cwd=destination, check=True, env={'LC_ALL':'C.UTF-8'})
        print('Archive SHA-256', h, len(seen), 'members verified')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='cmd', required=True)
    commands.add_parser('build')
    commands.add_parser('replay').add_argument('archive', type=Path)
    args = parser.parse_args()
    build() if args.cmd == 'build' else replay(args.archive.resolve())
