"""One immutable read per URL in this early window. All readback paths are local."""
import argparse
import fcntl
import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path
import re
import tempfile
import time
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import build_opener, HTTPRedirectHandler, Request

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'raw' / 'infersports'
BASE = 'https://api.infersports.dev'
ANCHOR = 'evt_5KC30XTH'  # Hamburg–Bayern, also identified by the earlier R5 source


def now():
    return datetime.now(timezone.utc).isoformat(timespec='microseconds').replace('+00:00', 'Z')


def digest(content):
    return hashlib.sha256(content).hexdigest()


def jbytes(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()


def load(path):
    return json.loads(path.read_bytes())


def response(label):
    path = OUT / (label + '.json')
    meta = load(path.with_suffix('.meta.json'))
    value = path.read_bytes()
    if meta['path'] != str(path.relative_to(ROOT)) or meta['bytes'] != len(value) or meta['sha256'] != digest(value):
        raise ValueError('raw hash or path mismatch: ' + label)
    if meta['http_status'] != 200:
        raise ValueError('recorded HTTP ' + str(meta['http_status']) + ' for ' + label)
    return json.loads(value), meta


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args):
        return None


def get(label, path, query):
    url = BASE + path + ('?' + urlencode(query) if query else '')
    OUT.mkdir(parents=True, exist_ok=True)
    dest = OUT / (label + '.json')
    side = dest.with_suffix('.meta.json')
    with (OUT.parent.parent / '.capture.lock').open('a+b') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        if dest.exists() or side.exists():
            data, meta = response(label)
            if meta['url'] != url:
                raise ValueError('capture URL collision')
            return data
        key = os.environ.get('WCPP_INFERSPORTS_KEY') or os.environ.get('infer_yapan_zhishu')
        if not key:
            raise ValueError('authorized InferSports credential unavailable')
        req = Request(url, headers={'Authorization': 'Bearer ' + key, 'Accept': 'application/json',
                                    'Accept-Encoding': 'identity'})
        start = now()
        try:
            handle = build_opener(NoRedirect()).open(req, timeout=30)
        except HTTPError as err:
            handle = err
        with handle:
            data = handle.read()
            end = now()
            h, status = handle.headers, handle.status
        if key.encode() in data:
            raise ValueError('provider echoed a credential')
        meta = dict(provider='InferSports', method='GET', url=url, http_status=status, path=str(dest.relative_to(ROOT)),
                    sha256=digest(data), bytes=len(data), request_started_utc=start, response_received_utc=end,
                    http_date=h.get('Date'), last_modified=h.get('Last-Modified'), content_type=h.get('Content-Type'),
                    content_encoding=h.get('Content-Encoding'), rate_remaining=h.get('X-RateLimit-Remaining'),
                    rate_limit=h.get('X-RateLimit-Limit'), rate_reset=h.get('X-RateLimit-Reset'))
        with tempfile.TemporaryDirectory(dir=ROOT) as tmp:
            b = Path(tmp) / 'body'
            m = Path(tmp) / 'meta'
            b.write_bytes(data)
            m.write_bytes(jbytes(meta))
            os.replace(b, dest)
            os.replace(m, side)
        print(label, status, meta['bytes'], end, flush=True)
        return response(label)[0]


def calendars():
    event = get('anchor-' + ANCHOR, '/v1/events/' + ANCHOR, {})
    if event.get('id') != ANCHOR:
        raise ValueError('anchor event shape/identity')
    league_id = event['league']['id']
    if not re.fullmatch(r'lg_[A-Z0-9]+', league_id):
        raise ValueError('unexpected league id')
    fixtures = load(ROOT / 'registration/registered-nine.json')['fixtures']
    for day in sorted({f['kickoff_utc'][:10] for f in fixtures}):
        get('events-' + day, '/v1/events', dict(sport='football', league=league_id, date=day, limit='100'))


def prices():
    from identity import joined
    for fixture in joined():
        eid = fixture['infer_event_id']
        get(eid + '-odds', '/v1/events/' + eid + '/odds', dict(period='full_time', format='decimal'))
        time.sleep(1)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('step', choices=['calendars', 'prices'])
    command = parser.parse_args().step
    (calendars if command == 'calendars' else prices)()
