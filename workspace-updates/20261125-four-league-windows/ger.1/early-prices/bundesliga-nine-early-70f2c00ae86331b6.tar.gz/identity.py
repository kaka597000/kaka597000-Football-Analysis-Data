"""Replay the PR #57 signed slate and the three original provider identity lists."""
import csv
from datetime import datetime, timezone
import gzip
import json
from urllib.parse import parse_qs, urlsplit

from fetch import ANCHOR, ROOT, digest, load, response

RECORD = '5309613785dd4a40-v000001'
SIGNATURE = '0b34a327ba0ca6e52d888af82a73fe4f4d8335c3227c48e38a4896a419a27035'
SLATE = 'nov27_dec04'
LEAGUE = {'id': 'lg_PGYWSDEA', 'name': 'GER'}
# Exact names and IDs as observed. The registry and each of the three providers
# must also agree on ordered opponents and UTC kickoff before we accept a match.
CLUBS = {
    '137': ('8697', 'Werder Bremen', 'tm_CRF9P3BP', 'W.Bremen'),
    '268': ('9788', 'Borussia Mönchengladbach', 'tm_YSXSBW2M', 'Monchengladbach'),
    '3307': ('8460', 'SC Paderborn 07', 'tm_D73A8PZV', 'Paderborn'),
    '133': ('10189', 'Schalke 04', 'tm_PNKKWSDE', 'Schalke 04'),
    '122': ('8722', 'FC Cologne', 'tm_QWGMCSBR', 'Koln'),
    '10388': ('8232', 'SV Elversberg', 'tm_WGQTR6XB', 'Elversberg'),
    '127': ('9790', 'Hamburg SV', 'tm_E21F3MDQ', 'Hamburger'),
    '132': ('9823', 'Bayern Munich', 'tm_VT8ES270', 'B.Munchen'),
    '2950': ('9905', 'Mainz', 'tm_PBVWSDEA', 'Mainz'),
    '598': ('8149', '1. FC Union Berlin', 'tm_A8ZNX7VJ', 'Union Berlin'),
    '134': ('10269', 'VfB Stuttgart', 'tm_80KM79R8', 'Stuttgart'),
    '125': ('9810', 'Eintracht Frankfurt', 'tm_8Z1EM79R', 'Frankfurt'),
    '126': ('8358', 'SC Freiburg', 'tm_HXM526EK', 'Freiburg'),
    '11420': ('178475', 'RB Leipzig', 'tm_Y08VBW2M', 'RB Leipzig'),
    '7911': ('8226', 'TSG Hoffenheim', 'tm_GVA9Y6EA', 'Hoffenheim'),
    '3841': ('8406', 'FC Augsburg', 'tm_HXFP26EK', 'Augsburg'),
    '124': ('9789', 'Borussia Dortmund', 'tm_QW64CSBR', 'Dortmund'),
    '131': ('8178', 'Bayer Leverkusen', 'tm_G61Y6EAN', 'Leverkusen'),
}


def check(ok, message):
    if not ok:
        raise ValueError(message)


def dt(value):
    result = datetime.fromisoformat(value.replace('Z', '+00:00'))
    check(result.utcoffset() is not None, 'timezone missing')
    return result.astimezone(timezone.utc)


def canonical(value):
    return digest(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode())


def original(name):
    path = ROOT / name
    raw = path.read_bytes()
    m = load(path.with_suffix('.meta.json'))
    check(m['http_status'] == 200 and m['path'] == name and m['bytes'] == len(raw) and
          m['sha256'] == digest(raw) and m['competition'] == 'ger.1', 'calendar source ' + name)
    return json.loads(gzip.decompress(raw) if raw[:2] == b'\x1f\x8b' else raw), m


def joined():
    regdir = ROOT / 'registration'
    record_file = regdir / (RECORD + '.json')
    reg, plan, nine = load(record_file), load(regdir / 'plan.json'), load(regdir / 'registered-nine.json')
    check(reg['freeze_id'] == plan['id'] == RECORD and reg['previous_sha256'] is None and reg['revision'] == 1
          and reg['record_sha256'] == plan['sha256'] == nine['record_sha256'] == SIGNATURE
          and canonical({k: v for k, v in reg.items() if k != 'record_sha256'}) == SIGNATURE
          and digest(record_file.read_bytes()) == nine['record_file_sha256'] ==
          'b688993f055b195bcae3de843c9c4a9da000f98c7b1d0c9c8302ae7293095a36', 'signed first registration')
    slate = reg['payload']['identity']['slates'][SLATE]
    fields = nine['fixtures']
    check(nine['window'] == SLATE and len(set(slate)) == 9 and
          ['espn:' + f['espn_source_match_id'] for f in fields] == slate, 'registered nine/order')
    with (regdir / 'ger.1.csv').open() as handle:
        table = {r['match_id']: r for r in csv.DictReader(handle) if r['window'] == SLATE}
    check(set(table) == set(slate), 'PR #57 CSV membership')
    esp, em = original('raw/espn/ger-2026.json')
    fm, fm_meta = original('raw/fotmob/ger-2026-2027.json')
    check(esp['leagues'][0]['slug'] == 'ger.1' and str(fm['details']['id']) == '54' and
          fm['details']['selectedSeason'] == '2026/2027', 'competition/season')
    esp_events = {str(e['id']): e for e in esp['events']}
    fm_events = {str(e['id']): e for e in fm['fixtures']['allMatches']}
    official = {}
    for day in sorted({f['kickoff_utc'][:10] for f in fields}):
        listing, meta = response('events-' + day)
        url = urlsplit(meta['url'])
        check(url.netloc == 'api.infersports.dev' and url.path == '/v1/events' and parse_qs(url.query) ==
              {'league': [LEAGUE['id']], 'sport': ['football'], 'date': [day], 'limit': ['100']}
              and listing['page']['next_cursor'] is None, 'InferSports unpaginated league/date list')
        for e in listing['data']:
            check(e['sport'] == 'football' and e['league'] == LEAGUE and e['scheduled_at'].startswith(day)
                  and e['status'] == 'scheduled' and dt(meta['response_received_utc']) < dt(e['scheduled_at']),
                  'InferSports prematch calendar')
            key = (e['home_team']['id'], e['away_team']['id'], dt(e['scheduled_at']))
            check(key not in official, 'ambiguous source identity')
            official[key] = (e, meta)
    anchor, _ = response('anchor-' + ANCHOR)
    check(anchor in [e for e, _ in official.values()] and len(official) == 9, 'anchored league and full window')
    output = []
    for slot, (mid, f) in enumerate(zip(slate, fields), 1):
        signed = reg['payload']['fixtures'][mid]
        r = table[mid]
        kickoff = dt(f['kickoff_utc'])
        e = esp_events[f['espn_source_match_id']]
        c, = e['competitions']
        m = fm_events[f['fotmob_source_match_id']]
        check(signed['match_id'] == mid and signed['cohort'] == r['competition'] == 'ger.1' and signed['stage'] == 'regular'
              and dt(signed['kickoff_at']) == dt(r['kickoff_at']) == dt(c['date']) == dt(m['status']['utcTime']) == kickoff
              and c['timeValid'] is True and c['status']['type']['name'] == 'STATUS_SCHEDULED' and
              all(m['status'][k] is False for k in ('started', 'cancelled', 'finished')) and
              int(m['round']) == f['fotmob_round'] == 11 and r['fotmob_match_id'] == 'fotmob:' + str(m['id']),
              mid + ' kickoff/status')
        check(r['espn_source_sha256'] == f['sources']['ESPN']['sha256'] == em['sha256'] and
              r['fotmob_source_sha256'] == f['sources']['FotMob']['sha256'] == fm_meta['sha256'], 'pinned original calendars')
        sides = {}
        for side in ('home', 'away'):
            et, = [t['team'] for t in c['competitors'] if t['homeAway'] == side]
            espid = et['id']
            fmid, name, inferid, infername = CLUBS[espid]
            check('espn:' + espid == signed[side] == r[side + '_espn_id'] and espid == f['espn_' + side + '_id']
                  and str(m[side]['id']) == f['fotmob_' + side + '_id'] == fmid and r[side + '_fotmob_id'] == 'fotmob:' + fmid
                  and et['displayName'] == name == f['espn_' + side] and m[side]['name'] == f['fotmob_' + side], mid + ' club')
            sides[side] = dict(espn_id=espid, espn_name=name, fotmob_id=fmid, fotmob_name=m[side]['name'],
                               infer_id=inferid, infer_name=infername)
        ie, im = official[(sides['home']['infer_id'], sides['away']['infer_id'], kickoff)]
        check(all(ie[s + '_team'] == {'id': sides[s]['infer_id'], 'name': sides[s]['infer_name']} for s in sides), 'provider clubs')
        output.append(dict(slot=slot, registration_id=RECORD, registration_sha256=SIGNATURE, match_id=mid,
                           competition='ger.1', stage='regular season', round=11, kickoff_utc=f['kickoff_utc'],
                           kickoff_bjt=f['kickoff_beijing'], espn_event_id=e['id'], fotmob_event_id=str(m['id']),
                           infer_event_id=ie['id'], infer_league=LEAGUE, sides=sides, source_calendar_path=im['path'],
                           source_calendar_sha256=im['sha256'], source_calendar_received_utc=im['response_received_utc']))
    check(len({x['infer_event_id'] for x in output}) == 9 and
          len({x['sides'][s]['infer_id'] for x in output for s in ('home', 'away')}) == 18, 'provider ID bijection')
    return output
