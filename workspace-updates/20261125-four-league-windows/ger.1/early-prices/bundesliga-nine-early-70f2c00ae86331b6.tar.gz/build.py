"""Derive early Bundesliga control rows from the fixed signed slate and original HTTP bodies."""
from collections import Counter
import csv
from datetime import timedelta, timezone
import json
from math import isfinite
from pathlib import Path

from fetch import ROOT, jbytes, response
from identity import SIGNATURE, canonical, check, dt, joined

BJT = timezone(timedelta(hours=8))
OUT = ROOT / 'derived'
MARKET_SIDES = {
    '1x2': ('home', 'draw', 'away'),
    'totals': ('over', 'under'),
    'asian_handicap': ('home', 'away'),
}


def csv_bytes(rows):
    from io import StringIO
    s = StringIO(newline='')
    writer = csv.DictWriter(s, fieldnames=list(rows[0]), lineterminator='\n')
    writer.writeheader()
    writer.writerows(rows)
    return s.getvalue().encode()


def number(v):
    return type(v) in (float, int) and isfinite(v)


def native_row(q, receipt, response_stale):
    kind, line, split = q['market_type'], q.get('line'), q.get('handicap_components')
    source_time = q.get('as_of')
    age = (receipt - dt(source_time)).total_seconds() if source_time else None
    reasons = []
    if source_time is None or age < 0:
        reasons.append('missing_or_future_native_clock')
    if response_stale is not False:
        reasons.append('provider_response_stale_or_unknown')
    if q['period'] != 'full_time' or q['format'] != 'decimal' or kind not in MARKET_SIDES:
        reasons.append('unsupported_period_market_or_format')
    if q['status'] != 'open':
        reasons.append(q['status'])
    elif not all(number(q['prices'].get(s)) and q['prices'][s] > 1 for s in MARKET_SIDES.get(kind, ())):
        reasons.append('incomplete_prices')
    if kind == '1x2':
        if line is not None or split is not None:
            reasons.append('unexpected_moneyline_line')
    elif kind in ('totals', 'asian_handicap'):
        if (not number(line) or line * 4 != round(line * 4) or (kind == 'totals' and
                (line <= 0 or any(q.get(k, line) != line for k in ('over_line', 'under_line'))))):
            reasons.append('invalid_line')
        if split is not None and (not number(line) or not isinstance(split, list)
                                  or sorted(split) != [line - .25, line + .25]):
            reasons.append('invalid_split')
    return age, reasons


def derive():
    fixtures = joined()
    all_rows, pairs, coverage = [], [], []
    with (ROOT / 'registration/quote-times.csv').open() as handle:
        deadlines = {r['match_id']: r for r in csv.DictReader(handle)}
    for f in fixtures:
        doc, meta = response(f['infer_event_id'] + '-odds')
        start, receipt, kickoff = (dt(x) for x in (meta['request_started_utc'], meta['response_received_utc'], f['kickoff_utc']))
        d = deadlines[f['match_id']]
        t24, t1 = dt(d['quote_24h_bjt']), dt(d['quote_1h_bjt'])
        check(kickoff - t24 == timedelta(hours=24) and kickoff - t1 == timedelta(hours=1) and
              dt(d['kickoff_bjt']) == kickoff and dt(f['source_calendar_received_utc']) <= start <= receipt < t24,
              'early control versus registered checkpoints')
        check(doc['event_id'] == f['infer_event_id'] and meta['url'] ==
              'https://api.infersports.dev/v1/events/' + doc['event_id'] + '/odds?period=full_time&format=decimal',
              'source event/URL')
        base = dict(control='early_prospective', slot=f['slot'], match_id=f['match_id'], competition=f['competition'],
                    home=f['sides']['home']['espn_name'], away=f['sides']['away']['espn_name'],
                    kickoff_bjt=f['kickoff_bjt'], kickoff_utc=f['kickoff_utc'], infer_event_id=doc['event_id'],
                    source_url=meta['url'], raw_file=meta['path'], raw_sha256=meta['sha256'],
                    request_started_utc=meta['request_started_utc'], response_received_utc=meta['response_received_utc'],
                    response_received_bjt=receipt.astimezone(BJT).isoformat(), http_date=meta.get('http_date'),
                    response_as_of_utc=doc.get('as_of'), response_stale=doc.get('stale'),
                    seconds_until_kickoff=(kickoff - receipt).total_seconds())
        local = []
        for i, q in enumerate(doc['odds']):
            age, reasons = native_row(q, receipt, doc.get('stale'))
            row = dict(base, row_index=i, row_sha256=canonical(q), bookmaker=q['bookmaker'], period=q['period'],
                       market=q['market_type'], status=q['status'], format=q['format'], line=q.get('line'),
                       split_components=json.dumps(q.get('handicap_components'), separators=(',', ':')),
                       **{k + '_price': q['prices'].get(k) for k in ('home', 'draw', 'away', 'over', 'under')},
                       quote_as_of_utc=q.get('as_of'), quote_age_seconds_at_receipt=age,
                       within_one_hour_at_receipt=age is not None and 0 <= age <= 3600,
                       eligible=not reasons, exclusion='|'.join(reasons))
            local.append(row)
        eligible = [r for r in local if r['eligible']]
        group = {(r['bookmaker'], r['market'], r['line']) for r in eligible}
        check(len(group) == len(eligible), 'conflicting or duplicate live bookmaker/market/line')
        money = {r['bookmaker']: r for r in eligible if r['market'] == '1x2'}
        local_pairs = []
        for total in (r for r in eligible if r['market'] == 'totals' and r['bookmaker'] in money):
            h = money[total['bookmaker']]
            exact = dt(h['quote_as_of_utc']) == dt(total['quote_as_of_utc'])
            fresh = h['within_one_hour_at_receipt'] and total['within_one_hour_at_receipt']
            local_pairs.append(dict(base, bookmaker=h['bookmaker'], total_line=total['line'],
                                    split_components=total['split_components'],
                                    home_price=h['home_price'], draw_price=h['draw_price'], away_price=h['away_price'],
                                    over_price=total['over_price'], under_price=total['under_price'],
                                    moneyline_quote_utc=h['quote_as_of_utc'], total_quote_utc=total['quote_as_of_utc'],
                                    moneyline_age_seconds=h['quote_age_seconds_at_receipt'],
                                    total_age_seconds=total['quote_age_seconds_at_receipt'], same_time=exact,
                                    both_within_one_hour=fresh, same_time_and_within_one_hour=exact and fresh,
                                    moneyline_raw_index=h['row_index'], total_raw_index=total['row_index'],
                                    moneyline_row_sha256=h['row_sha256'], total_row_sha256=total['row_sha256']))
        all_rows.extend(local)
        pairs.extend(local_pairs)
        coverage.append(dict(base, checkpoint_24h_bjt=d['quote_24h_bjt'], checkpoint_1h_bjt=d['quote_1h_bjt'],
                             raw_rows=len(local), eligible_rows=len(eligible), full_time_1x2=sum(r['market']=='1x2' for r in eligible),
                             full_time_totals=sum(r['market']=='totals' for r in eligible),
                             full_time_asian_handicap=sum(r['market']=='asian_handicap' for r in eligible),
                             suspended_rows=sum(r['status']=='suspended' for r in local),
                             bookmakers_with_pairs=','.join(sorted({r['bookmaker'] for r in local_pairs})),
                             same_book_pairs=len(local_pairs), equal_clock_pairs=sum(r['same_time'] for r in local_pairs),
                             both_within_one_hour_pairs=sum(r['both_within_one_hour'] for r in local_pairs),
                             equal_and_within_one_hour_pairs=sum(r['same_time_and_within_one_hour'] for r in local_pairs)))
    metrics = dict(control='early_prospective', registration_sha256=SIGNATURE, fixtures=len(fixtures),
                   source_earliest_request_utc=min(c['request_started_utc'] for c in coverage),
                   source_latest_receipt_utc=max(c['response_received_utc'] for c in coverage),
                   hours_to_kickoff_min=min(c['seconds_until_kickoff'] for c in coverage)/3600,
                   hours_to_kickoff_max=max(c['seconds_until_kickoff'] for c in coverage)/3600,
                   source_rows=len(all_rows), eligible_rows=sum(r['eligible'] for r in all_rows),
                   suspended_rows=sum(r['status']=='suspended' for r in all_rows),
                   open_rows_by_market=dict(sorted(Counter(r['market'] for r in all_rows if r['eligible']).items())),
                   books=sorted({r['bookmaker'] for r in all_rows}), pairs=len(pairs))
    for field in ('same_book_pairs','equal_clock_pairs','both_within_one_hour_pairs','equal_and_within_one_hour_pairs'):
        metrics[field] = sum(r[field] for r in coverage)
        metrics['fixtures_with_' + field] = sum(r[field] > 0 for r in coverage)
    metrics['eligible_row_age_seconds_range'] = [fn(r['quote_age_seconds_at_receipt'] for r in all_rows if r['eligible'])
                                                  for fn in (min, max)]
    return {'fixtures.json': jbytes(fixtures), 'quotes.csv': csv_bytes(all_rows), 'same-book.csv': csv_bytes(pairs),
            'fixture-coverage.csv': csv_bytes(coverage), 'readback.json': jbytes(metrics)}


if __name__ == '__main__':
    OUT.mkdir(exist_ok=True)
    for name, content in derive().items():
        (OUT / name).write_bytes(content)
    print((OUT / 'readback.json').read_text())
