#!/usr/bin/env python3
"""Reuse timestamped FotMob details where possible; fetch only missing provenance/data."""
import datetime as dt, hashlib, json, pathlib, re, shutil, subprocess, time, urllib.request, urllib.error

ROOT=pathlib.Path(__file__).resolve().parent
BASE=pathlib.Path('/workspace/scratch/europe-stage-calendars-20261125')
COMPS={'esp.1':'esp','fra.1':'fra','ger.1':'ger','ita.1':'ita'}
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def utc(): return dt.datetime.now(dt.timezone.utc).isoformat(timespec='microseconds').replace('+00:00','Z')
def read(p): return json.loads(p.read_text(encoding='utf-8'))
def is_completed_regular_ft(p):
    try:
        d=read(p); s=d.get('header',{}).get('status',{})
        return bool(s.get('finished')) and not s.get('cancelled') and not s.get('awarded') and s.get('reason',{}).get('short')=='FT'
    except Exception:return False

target=[json.loads(x) for x in (ROOT/'inputs/first-window-40.jsonl').read_text().splitlines()]
team_ids={}
for e in target:
    c=e['competition']
    for side in ('home','away'):
        ft=str(e[f'fotmob_{side}_id']); et=str(e[f'espn_{side}_id'])
        team_ids[(c,ft)]={'competition':c,'fotmob_team_id':ft,'espn_team_id':et,
          'fotmob_name':e[f'fotmob_{side}'],'espn_name':e[f'espn_{side}']}

latest={}
for comp,tag in COMPS.items():
    allm=read(ROOT/f'inputs/calendar/{tag}-2026-2027.json')['fixtures']['allMatches']
    # Cross-check these are still the same retained source bytes used by the calendar task.
    source_meta=read(ROOT/f'inputs/calendar/{tag}-2026-2027.meta.json')
    raw=ROOT/f'inputs/calendar/{tag}-2026-2027.json'
    if sha(raw)!=source_meta['sha256']: raise ValueError(f'calendar hash mismatch {tag}')
    for key,team in list(team_ids.items()):
        if key[0]!=comp: continue
        matches=[]
        for m in allm:
            s=m.get('status',{})
            if not s.get('finished') or s.get('cancelled') or s.get('awarded') or s.get('reason',{}).get('short')!='FT': continue
            if str(m['home']['id'])==key[1] or str(m['away']['id'])==key[1]: matches.append(m)
        if not matches: continue
        latest[key]=max(matches,key=lambda m:m['status']['utcTime'])
if len(latest)!=len(team_ids): raise ValueError(f'teams without completed national-league match: {len(team_ids)-len(latest)}')

fixtures={str(m['id']):m for m in latest.values()}
(ROOT/'derived/latest-fixture-selection.json').write_text(json.dumps({'selection_asof_utc':'2026-11-25 calendar capture','rules':'per target FotMob team ID: latest season fixture with finished=true, cancelled=false, awarded=false, reason.short=FT','unique_match_count':len(fixtures),'team_count':len(latest),'matches':list(fixtures.values())},ensure_ascii=False,indent=2)+'\n')

# Project-retained provenance is accepted only when its raw SHA matches a candidate raw response.
listed=subprocess.run(['rg','--files','/workspace/WCPP/reports','/workspace/scratch'],capture_output=True,text=True,check=True).stdout.splitlines()
candidate_paths={}
for mid in fixtures:
    candidate_paths[mid]=[pathlib.Path(p) for p in listed if re.search(r'(?<!\d)'+re.escape(mid)+r'(?!\d)',pathlib.Path(p).name) and pathlib.Path(p).suffix=='.json']
manifest_paths=subprocess.run(['rg','--files','/workspace/WCPP/reports'],capture_output=True,text=True,check=True).stdout.splitlines()
manifest_paths=[pathlib.Path(p) for p in manifest_paths if p.endswith('.json') and any(k in p.lower() for k in ('manifest','metadata','retrieval'))]
refs={mid:[] for mid in fixtures}
def walk(v,mp):
    if isinstance(v,dict):
        url=' '.join(str(v.get(k,'')) for k in ('url','source_url','public_url'))
        sha256=v.get('sha256')
        times={k:v[k] for k in ('queried_at_utc','requested_at_utc','captured_at_utc','observed_at_utc','observed_at') if v.get(k)}
        for mid in fixtures:
            if re.search(r'matchDetails\?matchId='+re.escape(mid)+r'(?:&|$)',url) and sha256 and times:
                refs[mid].append((sha256,times,url,str(mp)))
        for child in v.values():walk(child,mp)
    elif isinstance(v,list):
        for child in v:walk(child,mp)
for mp in manifest_paths:
    try: walk(read(mp),mp)
    except Exception: pass

results=[]; need_fetch=[]
for mid,m in fixtures.items():
    dst=ROOT/'raw/fotmob-details'/f'{mid}.json'; dst_meta=ROOT/'raw/fotmob-details'/f'{mid}.meta.json'
    if dst.exists() and dst_meta.exists():
        local_meta=read(dst_meta)
        if local_meta.get('http_status')==200 and local_meta.get('sha256')==sha(dst) and is_completed_regular_ft(dst):
            results.append(local_meta);continue
    found=None
    for expected,times,url,manifest in refs[mid]:
        for p in candidate_paths[mid]:
            try:
                if p.is_file() and sha(p)==expected and is_completed_regular_ft(p):
                    found=(p,expected,times,url,manifest); break
            except OSError: pass
        if found: break
    if found:
        p,expected,times,url,manifest=found; shutil.copyfile(p,dst)
        meta={'provider':'FotMob public API','match_id':mid,'source_url':url,'http_status':200,
              'sha256':expected,'byte_count':dst.stat().st_size,'query_time_utc':times.get('requested_at_utc') or times.get('queried_at_utc') or times.get('observed_at_utc') or times.get('observed_at'),
              'retrieval_time_utc':times.get('captured_at_utc'),'evidence_mode':'reused_retained_raw','retained_source_file':str(p),
              'retained_source_manifest':manifest}
        (ROOT/'raw/fotmob-details'/f'{mid}.meta.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
        results.append(meta)
    else: need_fetch.append((mid,m,dst))

blocked=None
for ix,(mid,m,dst) in enumerate(need_fetch):
    url=f'https://www.fotmob.com/api/data/matchDetails?matchId={mid}'
    q=utc(); req=urllib.request.Request(url,headers={'Accept':'application/json','User-Agent':'Mozilla/5.0 (compatible; public football research)'})
    try:
        with urllib.request.urlopen(req,timeout=25) as r:
            body=r.read(); status=r.status; ctype=r.headers.get('Content-Type')
    except urllib.error.HTTPError as e:
        status=e.code
        meta={'provider':'FotMob public API','match_id':mid,'source_url':url,'query_time_utc':q,'retrieval_time_utc':utc(),'http_status':status,'evidence_mode':'fetch_failed','failure_kind':'http_error_no_body_retained'}
        (ROOT/'raw/fotmob-details'/f'{mid}.meta.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
        results.append(meta)
        if status in (401,403,429): blocked=f'HTTP {status}'; break
        continue
    except Exception as e:
        meta={'provider':'FotMob public API','match_id':mid,'source_url':url,'query_time_utc':q,'retrieval_time_utc':utc(),'http_status':None,'evidence_mode':'fetch_failed','failure_kind':type(e).__name__}
        (ROOT/'raw/fotmob-details'/f'{mid}.meta.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
        results.append(meta); continue
    if status in (401,403,429):
        meta={'provider':'FotMob public API','match_id':mid,'source_url':url,'query_time_utc':q,'retrieval_time_utc':utc(),'http_status':status,'evidence_mode':'fetch_failed','failure_kind':'access_or_rate_limit_no_body_retained'}
        (ROOT/'raw/fotmob-details'/f'{mid}.meta.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n');results.append(meta);blocked=f'HTTP {status}';break
    try: json.loads(body)
    except Exception: raise ValueError(f'non-JSON FotMob body on successful status for {mid}')
    dst.write_bytes(body);meta={'provider':'FotMob public API','match_id':mid,'source_url':url,'query_time_utc':q,'retrieval_time_utc':utc(),'http_status':status,'content_type':ctype,'byte_count':len(body),'sha256':sha(dst),'evidence_mode':'fresh_public_fetch'}
    (ROOT/'raw/fotmob-details'/f'{mid}.meta.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n');results.append(meta)
    time.sleep(1.0)

(ROOT/'derived/fotmob-capture-manifest.json').write_text(json.dumps({'detail_count':len(fixtures),'retained_reused_count':sum(x.get('evidence_mode')=='reused_retained_raw' for x in results),'fresh_capture_count':sum(x.get('evidence_mode')=='fresh_public_fetch' for x in results),'blocked':blocked,'sources':results},ensure_ascii=False,indent=2)+'\n')
print('teams',len(latest),'unique matches',len(fixtures),'reused',sum(x.get('evidence_mode')=='reused_retained_raw' for x in results),'fresh',sum(x.get('evidence_mode')=='fresh_public_fetch' for x in results),'blocked',blocked)
