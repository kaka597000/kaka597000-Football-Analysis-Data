# 欧洲首窗球队近期比赛与盘口证据

范围来自 `europe-stage-calendars-20261125/out` 的西甲/法甲/德甲/意甲首窗。40场首窗对应76支不同球队：西甲20、法甲18、德甲18、意甲20；首窗内马德里竞技、巴塞罗那、皇家马德里和皇家社会各出赛两次。

## 主要结果

- `derived/team-recent-match-index.csv` / `.json`：每队最近一场本国联赛完成赛的球队 xG、对手 xG、双方射正、FT比分、比赛日期/轮次/ID、上一场阵型和首发11人；同时有目标赛程ESPN/FotMob球队ID及该队对应的目标赛事ID、最近赛FotMob比赛ID、ESPN赛果交叉核对ID、各原件抓取时间、URL和SHA-256。
- 覆盖：76/76队有正常FT90赛果、xG、射正和11人首发；38场最近比赛覆盖76队。ESPN赛季赛果逐场独立核对38/38（球队展开为76/76）。最近比赛日期为11月20日至23日。
- `derived/espn-sportsbook-quotes.csv` / `.json`：40场ESPN public summary中，38场有实际sportsbook报价行，共63个机构/赛事行。每行独立保留同一机构的1X2和大小球原生字段，不跨机构拼接。
- 当前完整1X2与大小球同机构报价为38/40场：DraftKings 36场、Bet 365 27场，覆盖重叠25场。分联赛为西甲10/12、法甲9/9、德甲9/9、意甲10/10。缺报价的两场为西甲 Real Sociedad—Real Madrid（ESPN event 401882698）与 Barcelona—Atlético Madrid（401882700）。
- 这些ESPN赔率响应均未提供机构原生报价时间（0/63）。索引分别保存API查询时间与响应接收时间，`provider_quote_time_utc`留空；抓取时刻不替代报价时刻。
- FotMob matchDetails请求时间范围为2026-11-25 12:04:05–12:11:00 UTC；ESPN summary查询/接收范围为12:01:31–12:07:50 UTC（全部响应成功）。
- 不调用The Odds API或InferSports付费/额度接口。The Odds API本环境此前已用尽额度；InferSports当前免费请求额度没有可核实的项目账本。市场部分仅使用无需鉴权的ESPN public summary。

## 字段复算

在本目录运行 `python3 build_team_evidence.py`，从原始季历、比赛详情、ESPN赛季记分板和ESPN逐场summary重建两个索引与覆盖统计。脚本会核对每份原件SHA-256、赛事身份、团队映射和状态。

1. 读 `inputs/first-window-40.jsonl` 确定目标球队和ESPN/FotMob ID；以赛季FotMob `fixtures.allMatches` 中完全相同的球队ID找每队最近一条 `finished=true`、`cancelled=false`、`awarded=false`、`reason.short=FT` 的联赛赛程。
2. 读该FotMob matchDetails原件。使用 `header.status` 与 `header.teams` 复核FT比分；在 `content.stats.Periods.All.stats[*].stats[*]` 取 `key=expected_goals` 和 `key=ShotsOnTarget`，两元素数组按主队、客队顺序。以ID确定团队视角的for/against。`content.lineup.homeTeam/awayTeam`给阵型与首发。
3. 用赛历中同一队的ESPN ID，在ESPN 2026赛季记分板按联赛、主客ID和UTC日期匹配，核对FT状态及双方比分。
4. 市场字段直接取同一个`odds[]`机构行。DraftKings保留美式`moneyLine`、`overUnder`、`overOdds`、`underOdds`；Bet 365保留summary/value的十进制与分数显示、`preMatchOverUnderHandicap`及`preMatchGoalLineOver/Under`。原件未给机构更新时间，不能用查询时刻补填。

## 原件与时钟

- `inputs/calendar/`：4份FotMob 2026/27本国联赛赛季季历及来源元数据，用来选择“最近一场”。
- `inputs/espn-season/`：4份ESPN 2026赛季公开记分板及元数据，独立核对赛果。
- `raw/fotmob-details/`：38份逐场原始matchDetails及来源sidecar。4份历史留档原件虽有抓取时间但实际是在比赛开始前请求，已剔除并用当前公开API刷新；最终38份均为完成赛后原件且有请求/接收时间。
- `raw/espn-summaries/`：40份逐场公开summary与抓取元数据。机构报价逐条保留原生字段。
- `inputs/calendar-source-manifest.json` 和 `inputs/calendar-coverage-audit.json`：原赛历采集清单和窗口覆盖审计。

该材料留在独立scratch中，不包含预测、冻结、训练、推送或定时任务。公共API原件仅用于本地证据复算，本包不声称第三方数据再分发许可。
