#!/usr/bin/env python3
"""Capture current public ESPN summaries for the 40 scheduled target events."""
import datetime as dt, hashlib, json, pathlib, time, urllib.request, urllib.error
ROOT=pathlib.Path(__file__).resolve().parent
def utc():return dt.datetime.now(dt.timezone.utc).isoformat(timespec='microseconds').replace('+00:00','Z')
def sha(b):return hashlib.sha256(b).hexdigest()
events=[json.loads(x) for x in (ROOT/'inputs/first-window-40.jsonl').read_text().splitlines()]
records=[]; blocked=None
for idx,e in enumerate(events):
    comp=e['competition'];eid=str(e['espn_source_match_id']);dst=ROOT/'raw/espn-summaries'/f'{eid}.json';mp=ROOT/'raw/espn-summaries'/f'{eid}.meta.json'
    if dst.exists() and mp.exists():
        records.append(json.loads(mp.read_text()));continue
    url=f'https://site.api.espn.com/apis/site/v2/sports/soccer/{comp}/summary?event={eid}'
    queried=utc();req=urllib.request.Request(url,headers={'Accept':'application/json','User-Agent':'Mozilla/5.0 (compatible; public football research)'})
    try:
        with urllib.request.urlopen(req,timeout=25) as r:
            body=r.read();status=r.status;ctype=r.headers.get('Content-Type')
    except urllib.error.HTTPError as ex:
        rec={'provider':'ESPN public summary','competition':comp,'event_id':eid,'url':url,'query_time_utc':queried,'retrieval_time_utc':utc(),'http_status':ex.code,'failure_kind':'http_error_no_body_retained','odds_rows':None}
        mp.write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n');records.append(rec)
        if ex.code in (401,403,429):blocked=f'HTTP {ex.code}';break
        # Do not repeatedly probe a failing public endpoint in a batch.
        blocked=f'HTTP {ex.code}';break
    except Exception as ex:
        rec={'provider':'ESPN public summary','competition':comp,'event_id':eid,'url':url,'query_time_utc':queried,'retrieval_time_utc':utc(),'http_status':None,'failure_kind':type(ex).__name__,'odds_rows':None}
        mp.write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n');records.append(rec);blocked=type(ex).__name__;break
    try:doc=json.loads(body)
    except Exception:raise ValueError(f'non-JSON successful summary for event {eid}')
    dst.write_bytes(body)
    meta={'provider':'ESPN public summary','competition':comp,'event_id':eid,'url':url,'query_time_utc':queried,
      'retrieval_time_utc':utc(),'http_status':status,'content_type':ctype,'bytes':len(body),'sha256':sha(body),
      'odds_rows':len(doc.get('odds',[])),'odds_providers':[o.get('provider',{}).get('name') for o in doc.get('odds',[])],
      'provider_quote_time_fields':sorted({k for o in doc.get('odds',[]) for k in o if 'time' in k.lower() or 'date' in k.lower()})}
    mp.write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n');records.append(meta)
    time.sleep(1.0)
(ROOT/'derived/espn-summary-capture-manifest.json').write_text(json.dumps({'requested_events':len(events),'captured_or_reused':len(records),'blocked':blocked,'sources':records},ensure_ascii=False,indent=2)+'\n')
print('events',len(events),'records',len(records),'raw available',sum(1 for x in records if x.get('http_status')==200),'with odds rows',sum(1 for x in records if x.get('odds_rows',0)>0),'blocked',blocked)
