#!/usr/bin/env python3
"""Reconstruct the 76-team recent-match index and ESPN quote inventory from raw bytes."""
import csv, datetime as dt, hashlib, json, pathlib
ROOT=pathlib.Path(__file__).resolve().parent
COMPS={'esp.1':'esp','fra.1':'fra','ger.1':'ger','ita.1':'ita'}
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def stat_pair(doc,key):
    for section in doc['content']['stats']['Periods']['All']['stats']:
        for item in section.get('stats',[]):
            if item.get('key')==key:return item['stats']
    return None

targets=[json.loads(x) for x in (ROOT/'inputs/first-window-40.jsonl').read_text().splitlines()]
if len(targets)!=40:raise ValueError('expected 40 w1 target fixtures')
teammap={}
for e in targets:
    for side in ('home','away'):
        tid=str(e[f'fotmob_{side}_id']); key=(e['competition'],tid)
        val={'competition':e['competition'],'fotmob_team_id':tid,'fotmob_name':e[f'fotmob_{side}'],
             'espn_team_id':str(e[f'espn_{side}_id']),'espn_name':e[f'espn_{side}']}
        if key in teammap and teammap[key]['espn_team_id']!=val['espn_team_id']:raise ValueError(f'conflicting target team map {key}')
        teammap[key]=val

selected={}; calendar_meta={}
for comp,tag in COMPS.items():
    calpath=ROOT/f'inputs/calendar/{tag}-2026-2027.json'; metapath=ROOT/f'inputs/calendar/{tag}-2026-2027.meta.json'
    cm=read(metapath)
    if sha(calpath)!=cm['sha256'] or cm.get('http_status')!=200:raise ValueError(f'calendar source hash/status failed: {tag}')
    calendar_meta[comp]=cm
    allm=read(calpath)['fixtures']['allMatches']
    for (c,tid),team in teammap.items():
        if c!=comp:continue
        done=[m for m in allm if str(m['home']['id'])==tid or str(m['away']['id'])==tid
              if m.get('status',{}).get('finished') and not m['status'].get('cancelled') and not m['status'].get('awarded')
              and m['status'].get('reason',{}).get('short')=='FT']
        if not done:continue
        selected[(comp,tid)]=max(done,key=lambda m:m['status']['utcTime'])
if len(selected)!=len(teammap):raise ValueError(f'missing team history {len(teammap)-len(selected)}')
unique={str(m['id']):m for m in selected.values()}
if len(teammap)!=76 or len(unique)!=38:raise ValueError(f'unexpected coverage team={len(teammap)} games={len(unique)}')

# ESPN 2026 scoreboard index, keyed by exact source team IDs.
espn_events={}; espn_source_meta={}
for comp,tag in COMPS.items():
    p=ROOT/f'inputs/espn-season/{tag}-2026.json'; meta=read(ROOT/f'inputs/espn-season/{tag}-2026.meta.json')
    if sha(p)!=meta['sha256'] or meta.get('http_status')!=200:raise ValueError(f'ESPN season source hash/status failed: {tag}')
    espn_source_meta[comp]=meta
    for ev in read(p).get('events',[]):
        comps=ev.get('competitions') or []
        if not comps:continue
        competitors=comps[0].get('competitors',[])
        h=next((str(x.get('id')) for x in competitors if x.get('homeAway')=='home'),None)
        a=next((str(x.get('id')) for x in competitors if x.get('homeAway')=='away'),None)
        if h and a:espn_events[(comp,h,a,ev.get('date','')[:10])]=ev

rows=[]
for (comp,tid),team in sorted(teammap.items()):
    m=selected[(comp,tid)]; mid=str(m['id']); raw=ROOT/f'raw/fotmob-details/{mid}.json'; meta_path=ROOT/f'raw/fotmob-details/{mid}.meta.json'
    if not raw.exists() or not meta_path.exists():continue
    meta=read(meta_path); bodysha=sha(raw)
    if meta.get('http_status')!=200 or meta.get('sha256')!=bodysha:raise ValueError(f'raw detail hash/status failed: {mid}')
    d=read(raw); general=d.get('general',{}); status=d.get('header',{}).get('status',{})
    if str(general.get('matchId'))!=mid:raise ValueError(f'FotMob match ID mismatch {mid}')
    if not status.get('finished') or status.get('awarded') or status.get('reason',{}).get('short')!='FT':raise ValueError(f'not ordinary FT {mid}')
    ftteams=d['header']['teams']; hteam=d['content']['lineup']['homeTeam']; ateam=d['content']['lineup']['awayTeam']
    fxg=stat_pair(d,'expected_goals'); fsot=stat_pair(d,'ShotsOnTarget')
    if not fxg or not fsot:raise ValueError(f'xG/SoT missing {mid}')
    ishome=str(ftteams[0]['id'])==tid
    if not ishome and str(ftteams[1]['id'])!=tid:raise ValueError(f'team absent from recent fixture {mid} {team}')
    idx=0 if ishome else 1; opponent=ftteams[1-idx]
    opponent_tid=str(opponent['id']); opponent_espn=teammap.get((comp,opponent_tid),{}).get('espn_team_id')
    board=espn_events.get((comp,team['espn_team_id'] if ishome else opponent_espn,
                          opponent_espn if ishome else team['espn_team_id'],status.get('utcTime','')[:10])) if opponent_espn else None
    # ESPN home/away ordering must match the selected FotMob event.
    if board is None:
        board=espn_events.get((comp,teammap.get((comp,str(ftteams[0]['id'])),{}).get('espn_team_id'),
                               teammap.get((comp,str(ftteams[1]['id'])),{}).get('espn_team_id'),status.get('utcTime','')[:10]))
    e_status='MISSING'; e_id=e_home=e_away=e_score_home=e_score_away=None
    if board:
        e_id=str(board['id']); e_status=(board.get('competitions') or [{}])[0].get('status',{}).get('type',{}).get('shortDetail') or (board.get('status') or {}).get('type',{}).get('shortDetail')
        ec=(board.get('competitions') or [{}])[0].get('competitors',[])
        eh=next((x for x in ec if x.get('homeAway')=='home'),{});ea=next((x for x in ec if x.get('homeAway')=='away'),{})
        e_home=eh.get('team',{}).get('displayName') or eh.get('team',{}).get('name');e_away=ea.get('team',{}).get('displayName') or ea.get('team',{}).get('name')
        e_score_home=eh.get('score');e_score_away=ea.get('score')
    sidekey='homeTeam' if ishome else 'awayTeam'; lineup=d['content']['lineup'][sidekey]
    starters=[{'name':x.get('name'),'player_id':x.get('id')} for x in lineup.get('starters',[])]
    target_events=[e for e in targets if e['competition']==comp and tid in (str(e['fotmob_home_id']),str(e['fotmob_away_id']))]
    rows.append({'competition':comp,'team_name':team['fotmob_name'],'team_espn_name':team['espn_name'],'espn_team_id':team['espn_team_id'],'fotmob_team_id':tid,
      'target_window_fixture_count_for_team':sum(1 for e in targets if e['competition']==comp and tid in (str(e['fotmob_home_id']),str(e['fotmob_away_id']))),
      'target_window_espn_event_ids':[str(e['espn_source_match_id']) for e in target_events],
      'target_window_fotmob_event_ids':[str(e['fotmob_source_match_id']) for e in target_events],
      'target_window_fixtures':[e['home']+' vs '+e['away'] for e in target_events],
      'latest_league_match_id_fotmob':mid,'latest_match_round':general.get('leagueRoundName') or general.get('matchRound'),'latest_match_utc':status.get('utcTime'),
      'latest_match_date_utc':status.get('utcTime','')[:10],'latest_match_home':ftteams[0]['name'],'latest_match_home_fotmob_id':str(ftteams[0]['id']),
      'latest_match_away':ftteams[1]['name'],'latest_match_away_fotmob_id':str(ftteams[1]['id']),'ft90_status':status.get('reason',{}).get('short'),
      'awarded':status.get('awarded'),'score_ft90':status.get('scoreStr'),'home_score':ftteams[0].get('score'),'away_score':ftteams[1].get('score'),
      'team_side_in_latest_match':'home' if ishome else 'away','xg_for':fxg[idx],'xg_against':fxg[1-idx],
      'shots_on_target_for':fsot[idx],'shots_on_target_against':fsot[1-idx],'formation':lineup.get('formation'),'starters':starters,'starter_count':len(starters),
      'fotmob_url':meta.get('source_url'),'fotmob_query_time_utc':meta.get('query_time_utc'),'fotmob_retrieval_time_utc':meta.get('retrieval_time_utc'),
      'fotmob_evidence_mode':meta.get('evidence_mode'),'fotmob_source_sha256':bodysha,'fotmob_raw_file':str(raw.relative_to(ROOT)),
      'selection_calendar_url':calendar_meta[comp].get('url'),'selection_calendar_query_time_utc':calendar_meta[comp].get('observed_request_start_utc'),
      'selection_calendar_retrieval_time_utc':calendar_meta[comp].get('observed_response_end_utc'),'selection_calendar_sha256':calendar_meta[comp].get('sha256'),
      'espn_crosscheck_match_id':e_id,'espn_crosscheck_status':e_status,'espn_crosscheck_home':e_home,'espn_crosscheck_away':e_away,
      'espn_crosscheck_home_score':e_score_home,'espn_crosscheck_away_score':e_score_away,
      'espn_crosscheck_source_url':espn_source_meta[comp].get('url'),'espn_crosscheck_query_time_utc':espn_source_meta[comp].get('observed_request_start_utc'),
      'espn_crosscheck_retrieval_time_utc':espn_source_meta[comp].get('observed_response_end_utc'),'espn_crosscheck_source_sha256':espn_source_meta[comp].get('sha256'),
      'espn_crosscheck_result_matches_fotmob':bool(board and str(e_score_home)==str(ftteams[0].get('score')) and str(e_score_away)==str(ftteams[1].get('score')) and e_status in ('FT','Full Time'))})
rows.sort(key=lambda r:(r['competition'],r['team_name']))
if len(rows)!=76:raise ValueError(f'index rows incomplete: {len(rows)}')
with (ROOT/'derived/team-recent-match-index.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();
    for r in rows:
        out=dict(r)
        for k in ('starters','target_window_espn_event_ids','target_window_fotmob_event_ids','target_window_fixtures'):
            out[k]=json.dumps(out[k],ensure_ascii=False)
        w.writerow(out)
(ROOT/'derived/team-recent-match-index.json').write_text(json.dumps({'coverage':{'target_fixtures':40,'unique_teams':len(teammap),'selected_latest_matches':len(unique),
    'ft90':sum(r['ft90_status']=='FT' and not r['awarded'] for r in rows),'xg':sum(r['xg_for'] is not None for r in rows),
    'shots_on_target':sum(r['shots_on_target_for'] is not None for r in rows),'XI':sum(r['starter_count']==11 for r in rows),
    'ESPN_score_crosschecks':sum(r['espn_crosscheck_result_matches_fotmob'] for r in rows)},'rows':rows},ensure_ascii=False,indent=2)+'\n')

quotes=[]
def odds_parts(o,key,bet365_key):
    x=o.get(key) or {}
    american=x.get('moneyLine')
    nested=x.get('odds') or {}
    if isinstance(nested,dict):
        dec=nested.get('value'); frac=nested.get('summary')
    else: dec=frac=None
    if dec is None: dec=x.get('value')
    if frac is None: frac=x.get('summary')
    bo=(o.get('bettingOdds') or {}).get('teamOdds') or {}
    bval=bo.get(bet365_key)
    if isinstance(bval,dict): bval=bval.get('value')
    if frac is None and isinstance(bval,str): frac=bval
    return american,dec,frac
for e in targets:
    eid=str(e['espn_source_match_id']);raw=ROOT/f'raw/espn-summaries/{eid}.json';mp=ROOT/f'raw/espn-summaries/{eid}.meta.json'
    if not raw.exists() or not mp.exists():continue
    meta=read(mp);d=read(raw)
    if meta.get('http_status')!=200 or meta.get('sha256')!=sha(raw):raise ValueError(f'ESPN summary hash/status failed {eid}')
    for o in d.get('odds',[]):
        provider=o.get('provider',{})
        qclock=next((o.get(k) for k in ('lastUpdated','updatedAt','asOf','date') if o.get(k)),None)
        h=odds_parts(o,'homeTeamOdds','preMatchFullTimeResultHome'); dr=odds_parts(o,'drawOdds','preMatchFullTimeResultDraw'); a=odds_parts(o,'awayTeamOdds','preMatchFullTimeResultAway')
        bo=(o.get('bettingOdds') or {}).get('teamOdds') or {}
        total_line=o.get('overUnder')
        if total_line is None: total_line=bo.get('preMatchOverUnderHandicap')
        if isinstance(total_line,dict): total_line=total_line.get('value')
        over_frac=bo.get('preMatchGoalLineOver');under_frac=bo.get('preMatchGoalLineUnder')
        if isinstance(over_frac,dict):over_frac=over_frac.get('value')
        if isinstance(under_frac,dict):under_frac=under_frac.get('value')
        quotes.append({'competition':e['competition'],'event_id_espn':eid,'fixture':e['home']+' vs '+e['away'],'kickoff_utc':e['kickoff_utc'],
          'bookmaker':provider.get('name'),'provider_id':provider.get('id'),
          'home_1x2_american':h[0],'home_1x2_decimal':h[1],'home_1x2_fractional':h[2],
          'draw_1x2_american':dr[0],'draw_1x2_decimal':dr[1],'draw_1x2_fractional':dr[2],
          'away_1x2_american':a[0],'away_1x2_decimal':a[1],'away_1x2_fractional':a[2],
          'total_line':total_line,'over_american':o.get('overOdds'),'under_american':o.get('underOdds'),
          'over_fractional':over_frac,'under_fractional':under_frac,
          'provider_raw_market_fields':','.join(sorted(o.keys())),
          'provider_quote_time_utc':qclock,'provider_clock_status':'supplied' if qclock else 'not_supplied',
          'query_time_utc':meta.get('query_time_utc'),'retrieval_time_utc':meta.get('retrieval_time_utc'),
          'source_url':meta.get('url'),'source_sha256':sha(raw),'source_raw_file':str(raw.relative_to(ROOT))})
with (ROOT/'derived/espn-sportsbook-quotes.csv').open('w',newline='',encoding='utf-8') as f:
    fields=list(quotes[0]) if quotes else ['competition','event_id_espn','fixture']
    w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(quotes)
(ROOT/'derived/espn-sportsbook-quotes.json').write_text(json.dumps({'coverage':{'events_with_quotes':len({q['event_id_espn'] for q in quotes}),'events_total':40,'sportsbook_rows':len(quotes),
    'provider_clock_rows':sum(q['provider_quote_time_utc'] is not None for q in quotes),
    'events_with_complete_1x2':len({q['event_id_espn'] for q in quotes if any(q.get(k) is not None for k in ('home_1x2_american','home_1x2_decimal','home_1x2_fractional')) and any(q.get(k) is not None for k in ('draw_1x2_american','draw_1x2_decimal','draw_1x2_fractional')) and any(q.get(k) is not None for k in ('away_1x2_american','away_1x2_decimal','away_1x2_fractional'))}),
    'events_with_complete_totals':len({q['event_id_espn'] for q in quotes if q.get('total_line') is not None and (q.get('over_american') is not None or q.get('over_fractional') is not None) and (q.get('under_american') is not None or q.get('under_fractional') is not None)}),
    'events_with_complete_1x2_and_totals_same_provider':len({q['event_id_espn'] for q in quotes if q.get('total_line') is not None and (q.get('over_american') is not None or q.get('over_fractional') is not None) and (q.get('under_american') is not None or q.get('under_fractional') is not None) and any(q.get(k) is not None for k in ('home_1x2_american','home_1x2_decimal','home_1x2_fractional')) and any(q.get(k) is not None for k in ('draw_1x2_american','draw_1x2_decimal','draw_1x2_fractional')) and any(q.get(k) is not None for k in ('away_1x2_american','away_1x2_decimal','away_1x2_fractional'))})},'rows':quotes},ensure_ascii=False,indent=2)+'\n')
cov={'w1_fixtures':40,'unique_teams':76,'latest_league_match_details':len(unique),'team_rows':len(rows),
     'normal_ft_rows':sum(r['ft90_status']=='FT' and not r['awarded'] for r in rows),'xg_rows':sum(r['xg_for'] is not None for r in rows),
     'sot_rows':sum(r['shots_on_target_for'] is not None for r in rows),'xi_11_rows':sum(r['starter_count']==11 for r in rows),
     'espn_result_crosschecks':sum(r['espn_crosscheck_result_matches_fotmob'] for r in rows),
     'espn_summaries_200':sum(1 for e in targets if read(ROOT/f"raw/espn-summaries/{e['espn_source_match_id']}.meta.json").get('http_status')==200),
     'espn_events_with_market_rows':len({q['event_id_espn'] for q in quotes}),'sportsbook_quote_rows':len(quotes),
     'sportsbook_provider_quote_clocks':sum(q['provider_quote_time_utc'] is not None for q in quotes)}
(ROOT/'derived/coverage.json').write_text(json.dumps(cov,ensure_ascii=False,indent=2)+'\n')
def has_h2h(q):return all(any(q.get(f'{s}_1x2_{fmt}') is not None for fmt in ('american','decimal','fractional')) for s in ('home','draw','away'))
def has_totals(q):return q.get('total_line') is not None and any(q.get(f'over_{fmt}') is not None for fmt in ('american','fractional')) and any(q.get(f'under_{fmt}') is not None for fmt in ('american','fractional'))
per={}
for comp in COMPS:
    t=[e for e in targets if e['competition']==comp];tr=[r for r in rows if r['competition']==comp];qr=[q for q in quotes if q['competition']==comp]
    per[comp]={'target_fixtures':len(t),'unique_teams':len({r['fotmob_team_id'] for r in tr}),
      'latest_matches':len({r['latest_league_match_id_fotmob'] for r in tr}),'ft90':sum(r['ft90_status']=='FT' and not r['awarded'] for r in tr),
      'xg':sum(r['xg_for'] is not None for r in tr),'shots_on_target':sum(r['shots_on_target_for'] is not None for r in tr),
      'XI_11':sum(r['starter_count']==11 for r in tr),'espn_result_crosschecks':sum(r['espn_crosscheck_result_matches_fotmob'] for r in tr),
      'espn_summaries_http_200':sum(read(ROOT/f"raw/espn-summaries/{e['espn_source_match_id']}.meta.json").get('http_status')==200 for e in t),
      'events_with_quotes':len({q['event_id_espn'] for q in qr}),'sportsbook_quote_rows':len(qr),
      'events_with_complete_1x2':len({q['event_id_espn'] for q in qr if has_h2h(q)}),
      'events_with_complete_totals':len({q['event_id_espn'] for q in qr if has_totals(q)}),
      'events_with_1x2_and_totals_same_bookmaker':len({q['event_id_espn'] for q in qr if has_h2h(q) and has_totals(q)}),
      'provider_quote_clock_rows':sum(q['provider_quote_time_utc'] is not None for q in qr)}
(ROOT/'derived/coverage-by-competition.json').write_text(json.dumps(per,ensure_ascii=False,indent=2)+'\n')
(ROOT/'derived/coverage.json').write_text(json.dumps(cov,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(cov,ensure_ascii=False))
