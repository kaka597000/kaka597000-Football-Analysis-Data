# Forward fixtures and market observations

Requested interval: Beijing 2026-11-24 00:00 inclusive to 2026-12-01 00:00 exclusive, equal to UTC `[2026-11-23T16:00:00Z, 2026-11-30T16:00:00Z)`. Final acquisition cutoff: `2026-11-23T05:25:20Z`.

## Fixture inventory

`fixtures.jsonl` contains 192 fixtures: 186 returned by ESPN league scoreboards and 6 K League 1 matches from the official K League endpoint. Each record has a source ID, competition/stage, season/date, aware kickoff, home/away names and IDs, source URL/SHA-256, identity basis, and market availability. `coverage.json` records each of the 20 competition slates, including empty slates and source failures. `queries.json` and `raw/` hold the 160 ESPN per-day scoreboard requests and response bodies.

All 186 ESPN rows meet the requested single-source identity rule: the competition-specific scoreboard and event competition label agree; the event has a complete scheduled pre-match status, event time, season, both team IDs and both team names. No ESPN row was rejected on these checks. Fifty-four rows also match the reviewed R4 Big Five and Champions League event/team IDs and kickoff. The six K League 1 fixtures are verified against official league game IDs and team IDs. `stage` retains ESPN `altGameNote` when present, otherwise the ESPN season slug; the K League source stage is Final A or Final B.

For the J.League Cup, the official J.League announcement in `raw/official-jleague-levain-schedule-2026-27.html` states 2026 quarterfinal legs on Nov 11 and 15, 2027 semifinal legs on Mar 24 and 28, and the final on May 8. The existing 8-row official 2026/27 schedule inventory contains only the quarterfinals, all before this window. Therefore the official tournament calendar confirms no Cup fixture in the requested interval. Details, source hash and provenance are in `jpn-league-cup-window-check.json`. JFA is not the Cup organizer; current JFA and J.LEAGUE Data Site requests returned HTTP 503. ESPN's `jpn.league_cup` scoreboard returned HTTP 400 for the daily queries. Alternative ESPN slugs and current official-page routes were attempted and their HTTP responses are preserved in `cup-alt-source-checks.json` and `jleague-jfa-sources.json`.

The FIFA World Cup and Nations League scoreboards returned no events in this interval. Their full daily ESPN query records are preserved. No inference is made about competitions outside the configured scope.

## Markets

`market-ready.jsonl` contains only fixtures with a complete same-DraftKings-object opening and closing 1X2 plus over/under prices, with both total sides on the same numeric line. This yields 146 fixtures across 16 competitions (17 competitions had in-window fixtures, including K League 1 with no ESPN DraftKings prices). `market-status.jsonl` records market availability/rejection status for every fixture, and `market-coverage.json` reports counts and fractions by competition plus failure reasons.

Each market-ready record carries raw American prices beside decimal-normalized prices. American odds use `decimal = 1 + 100 / abs(odds)` for negative values and `decimal = 1 + odds / 100` for positive values; calculated decimals are rounded to six places. The actual numeric total line is parsed from the provider's line labels and cross-checked among the ESPN main line, Over, Under, opening and closing fields. Raw odds bodies in `raw/` are unchanged; the normalized JSONL is derived output.

ESPN's DraftKings object presents `open` and `close` labels, but does not provide provider quote timestamps. Every market `quoted_at` is null. `observed_at` is only the ESPN response capture time and is not substituted for a provider quote time. The 146 complete same-source rows therefore establish publicly observed prices in ESPN's response, but not timestamped bookmaker snapshots. Eight fixtures had missing or internally inconsistent total-line/side fields; 2 had non-DraftKings odds only; 30 ESPN fixtures had no odds object; the six official K League fixtures have no ESPN market query or odds. See `market-status.jsonl` for event-level reasons.

`team-aliases.json` crosswalks the six official K League fixtures to historical English panel names and FotMob IDs, retaining the official Korean names and K League IDs. Sources are the official K League response and the existing K1 panel file (both SHA-recorded).

`kleague-ft-replay-sample.json` retains a real completed official K League row (`gameId` 213, Gangwon 1–3 Daejeon) and a normalized FT candidate. Its capture clock is over 90 minutes after kickoff and the official response has `gameStatus=FE`, `endYn=Y`, and scores. This candidate is **not formally FT-accepted by the current replay path**: `research_program.replay._finished_espn_label` validates only ESPN-hosted result payloads with ESPN `STATUS_FULL_TIME` and ESPN team IDs; the generic v2 observation schema also has no result-score field. An official K League source adapter and result contract are needed before treating it as an accepted formal label.

Run `python scripts/generate_market_ready.py` to reproduce decimal conversion and coverage from the retained raw source bodies. The script does not edit fixture or raw files.
