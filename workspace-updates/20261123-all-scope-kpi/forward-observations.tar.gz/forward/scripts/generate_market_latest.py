#!/usr/bin/env python3
"""Emit per-provider current market status without cross-bookmaker pairing."""
import json, math, hashlib, os
from collections import defaultdict, Counter
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
R4=Path('/workspace/WCPP/reports/kpi-optimization-20261123-r4')
CUTOFF='2026-11-23T05:25:20Z'
fixtures=[json.loads(s) for s in (ROOT/'fixtures.jsonl').read_text().splitlines() if s.strip()]
queries=json.loads((ROOT/'queries.json').read_text()); query_by_sha={q['sha256']:q for q in queries}

def dt(s):
    if not s:return None
    try:return datetime.fromisoformat(str(s).replace('Z','+00:00')).astimezone(timezone.utc)
    except (ValueError,TypeError):return None

def american_dec(v):
    if v is None:return None
    s=str(v).strip().replace('−','-')
    try:n=float(s)
    except (ValueError,TypeError):return None
    if not math.isfinite(n) or n==0:return None
    return round(1+100/abs(n),6) if n<0 else round(1+n/100,6)

def num(v):
    if v is None:return None
    s=str(v).strip().lower()
    if s.startswith(('o','u')):s=s[1:]
    try:x=float(s)
    except (ValueError,TypeError):return None
    return x if math.isfinite(x) else None

def nonempty(x):return x is not None and x!=''

def provider_bucket(allp,name):
    if name not in allp:
        allp[name]={'bookmaker':name,'h2h_candidates':[],'total_candidates':[],'observed_line_only':[],'sources':[]}
    return allp[name]

def evidence(source_type,**kwargs):
    return {'source_type':source_type,**kwargs}

def add_espn(allp,f):
    out=[]; source=f.get('sources',[{}])[0]; q=query_by_sha.get(source.get('sha256'))
    if not q:return out
    try:j=json.loads((ROOT/q['path']).read_bytes())
    except Exception:return out
    ev=next((e for e in j.get('events',[]) if str(e.get('id'))==str(f.get('event_id'))),None)
    if not ev:return out
    c=(ev.get('competitions') or [{}])[0]
    src=evidence('ESPN scoreboard odds',url=q['url'],file=q['path'],sha256=q['sha256'],query_observed_at=q.get('query_observed_at'),quoted_at=None,quote_time_basis='not supplied by ESPN')
    for o in c.get('odds') or []:
        if not isinstance(o,dict):continue
        p=o.get('provider') or {}; name=p.get('name')
        if not name:continue
        b=provider_bucket(allp,name);b['sources'].append(src)
        # DraftKings has open/close American odds; keep both snapshots, accept a complete close independently.
        ml=o.get('moneyline')
        if isinstance(ml,dict):
            openp={side:american_dec((ml.get(side) or {}).get('open',{}).get('odds')) for side in ('home','draw','away')}
            closep={side:american_dec((ml.get(side) or {}).get('close',{}).get('odds')) for side in ('home','draw','away')}
            rawopen={side:(ml.get(side) or {}).get('open',{}).get('odds') for side in ('home','draw','away')}
            rawclose={side:(ml.get(side) or {}).get('close',{}).get('odds') for side in ('home','draw','away')}
            if all(v is not None for v in closep.values()):
                b['h2h_candidates'].append({'snapshot_label':'close','prices':{s:{'decimal':closep[s],'line':None,'american':rawclose[s]} for s in closep},'quoted_at':None,'observed_at':q.get('query_observed_at'),'source':src,'raw_open':rawopen})
        # Bet365 uses decimal values and team IDs; verify its sides against the scoreboard fixture.
        if all(k in o for k in ('homeTeamOdds','awayTeamOdds','drawOdds')):
            h=o.get('homeTeamOdds') or {}; a=o.get('awayTeamOdds') or {}; d=o.get('drawOdds') or {}
            if str((h.get('team') or {}).get('id'))==str(f.get('home_id')) and str((a.get('team') or {}).get('id'))==str(f.get('away_id')):
                vals={'home':h.get('value'),'draw':d.get('value'),'away':a.get('value')}
                if all(type(v) in (int,float) and v>1 for v in vals.values()):
                    b['h2h_candidates'].append({'snapshot_label':'current','prices':{s:{'decimal':round(float(v),6),'line':None,'american':None} for s,v in vals.items()},'quoted_at':None,'observed_at':q.get('query_observed_at'),'source':src})
        total=o.get('total')
        if isinstance(total,dict):
            main_line=num(o.get('overUnder'))
            close={s:(total.get(s) or {}).get('close',{}) for s in ('over','under')}
            values={s:american_dec(close[s].get('odds')) for s in close}
            lines={s:num(close[s].get('line')) for s in close}
            if all(v is not None for v in values.values()):
                line=(lines['over'] if lines['over'] is not None and lines['over']==lines['under'] else (main_line if lines['over'] is None and lines['under'] is None else None))
                if line is not None:
                    opens={s:(total.get(s) or {}).get('open',{}) for s in ('over','under')}
                    open_lines={s:num(opens[s].get('line')) for s in opens}
                    b['total_candidates'].append({'snapshot_label':'close','line':line,'over':{'decimal':values['over'],'line':line,'american':close['over'].get('odds')},'under':{'decimal':values['under'],'line':line,'american':close['under'].get('odds')},'quoted_at':None,'observed_at':q.get('query_observed_at'),'source':src,'open_line':open_lines,'open_odds':{s:opens[s].get('odds') for s in opens}})
            elif main_line is not None:
                b['observed_line_only'].append({'line':main_line,'snapshot_label':'ESPN overUnder','reason':'main numeric line present but complete closing Over/Under pair absent','quoted_at':None,'observed_at':q.get('query_observed_at'),'source':src})
        elif num(o.get('overUnder')) is not None:
            b['observed_line_only'].append({'line':num(o.get('overUnder')),'snapshot_label':'ESPN overUnder','reason':'numeric provider main line without a complete two-sided total quote','quoted_at':None,'observed_at':q.get('query_observed_at'),'source':src})
    return out

def add_r4_infersports(allp,f):
    mid=f.get('match_id'); found=None
    # Exactly one reviewed R4 odds capture is used per event; raw provider event ID and hash are verified below.
    for p in (list((R4/'live-36').glob('*.json'))+list((R4/'live-36').glob('*/*.json'))):
        try:x=json.loads(p.read_text()); rf=x.get('fixture',{})
        except Exception:continue
        if rf.get('match_id')!=mid:continue
        me=rf.get('market_evidence') or {}; odds=me.get('odds') or (rf.get('source_evidence') or {}).get('odds')
        if odds and odds.get('file'):
            found=(rf,odds);break
    if not found:return
    rf,odds=found
    rel=odds['file']; path=Path(rel)
    if not path.is_absolute():path=Path('/workspace/WCPP/reports')/rel
    if not path.is_file():return
    data=path.read_bytes();sha=hashlib.sha256(data).hexdigest()
    if sha!=odds.get('sha256'):return
    raw=json.loads(data)
    provider_event=odds.get('url','').split('/events/')[-1].split('/odds')[0]
    if raw.get('event_id')!=provider_event or raw.get('stale') is True:return
    captured=odds.get('captured_at'); source=evidence('R4 retained Infersports event odds',url=odds.get('url'),file=os.path.relpath(path,ROOT),sha256=sha,provider_event_id=provider_event,captured_at=captured,quote_time_basis='market quote as_of per provider/market')
    quote_ref={'match_id':mid,'provider_match_id':provider_event,'bookmaker':None,'query_time':captured,'source_sha256':sha,'source_url':odds.get('url'),'source_file':os.path.relpath(path,ROOT),'verified_event_identity':True}
    for z in raw.get('odds',[]):
        if z.get('period')!='full_time' or z.get('status') not in ('open','available'):continue
        qt=z.get('as_of'); qdt=dt(qt)
        if qdt is None or qdt>=dt(f.get('kickoff_at')) or qdt>dt(CUTOFF):continue
        name=z.get('bookmaker')
        if not name:continue
        b=provider_bucket(allp,name);b['sources'].append(source)
        prices=z.get('prices') or {}; fmt=z.get('format')
        if fmt!='decimal':continue
        if z.get('market_type')=='1x2':
            vals={s:prices.get(s) for s in ('home','draw','away')}
            if all(type(v) in (int,float) and v>1 for v in vals.values()):
                b['h2h_candidates'].append({'snapshot_label':'current_feed','prices':{s:{'decimal':round(float(v),6),'line':None,'american':None} for s,v in vals.items()},'quoted_at':qt,'observed_at':captured,'source':source})
        elif z.get('market_type')=='totals':
            line=num(z.get('line')); over=prices.get('over');under=prices.get('under')
            if line is not None and type(over) in (int,float) and over>1 and type(under) in (int,float) and under>1:
                b['total_candidates'].append({'snapshot_label':'current_feed','line':line,'over':{'decimal':round(float(over),6),'line':line,'american':None},'under':{'decimal':round(float(under),6),'line':line,'american':None},'quoted_at':qt,'observed_at':captured,'source':source,'feed_status':z.get('status')})
            elif line is not None:
                b['observed_line_only'].append({'line':line,'snapshot_label':'current_feed','reason':'numeric line present without both current sides','quoted_at':qt,'observed_at':captured,'source':source})

def add_hkjc(allp,f):
    p=R4/'uefa-prices/hkjc-espn-uefa-window.json'
    if not p.exists():return
    body=json.loads(p.read_text());r=next((x for x in body['records'] if str(x.get('espn_event_id',x.get('id')))==str(f.get('event_id')) and x.get('hkjc_frontend_id')),None)
    if not r:return
    m=r['markets'];name='HKJC';b=provider_bucket(allp,name)
    rawrel=m['source_response_file'];path=R4/'uefa-prices'/rawrel;data=path.read_bytes();sha=hashlib.sha256(data).hexdigest()
    if sha!=m.get('source_response_sha256'):return
    metafile=m.get('source_response_metadata_file');meta=json.loads((R4/'uefa-prices'/metafile).read_text()) if metafile else {}
    src=evidence('HKJC official match-market response',url=m['source_request_url'],file=os.path.relpath(path,ROOT),sha256=sha,capture_started_at=meta.get('capture_request_started_utc'),response_complete_at=meta.get('capture_response_complete_utc'),quote_time_basis='market-pool update timestamp, not selection-level timestamp',hkjc_match_id=r.get('hkjc_match_id'),frontend_id=r.get('hkjc_frontend_id'))
    b['sources'].append(src)
    hda=m.get('hda') or {}; hlines=hda.get('lines') or []; hline=next((l for l in hlines if l.get('main') and l.get('line_status')=='AVAILABLE'),None)
    if hline:
        sm={s.get('side_code'):s for s in hline.get('selections',[]) if s.get('available')}
        hvals={'home':sm.get('H',{}).get('price_decimal'),'draw':sm.get('D',{}).get('price_decimal'),'away':sm.get('A',{}).get('price_decimal')}
        if all(type(v) in (int,float) and v>1 for v in hvals.values()):
            qt=hda.get('market_update_utc')
            b['h2h_candidates'].append({'snapshot_label':'current_pool','prices':{s:{'decimal':round(float(v),6),'line':None,'american':None} for s,v in hvals.items()},'quoted_at':qt,'observed_at':meta.get('capture_response_complete_utc'),'source':src,'raw_pool_update':hda.get('market_update_at_original'),'pool_status':hda.get('market_status')})
    totals=m.get('totals') or {}; tlines=totals.get('lines') or []; tline=next((l for l in tlines if l.get('main') and l.get('line_status')=='AVAILABLE' and l.get('line_decimal') is not None),None)
    if tline:
        sm={s.get('side_code'):s for s in tline.get('selections',[]) if s.get('available')}
        over=sm.get('H',{}).get('price_decimal');under=sm.get('L',{}).get('price_decimal');line=tline['line_decimal']
        if type(over) in (int,float) and type(under) in (int,float) and over>1 and under>1:
            qt=totals.get('market_update_utc')
            b['total_candidates'].append({'snapshot_label':'current_pool','line':line,'over':{'decimal':round(float(over),6),'line':line,'american':None},'under':{'decimal':round(float(under),6),'line':line,'american':None},'quoted_at':qt,'observed_at':meta.get('capture_response_complete_utc'),'source':src,'raw_pool_update':totals.get('market_update_at_original'),'pool_status':totals.get('market_status'),'alternatives':[{'line_original':l.get('line_original'),'line_decimal':l.get('line_decimal'),'line_components':l.get('line_components')} for l in tlines if not l.get('main')]})

def sortable(candidate):
    return dt(candidate.get('quoted_at')) or dt(candidate.get('observed_at')) or datetime.min.replace(tzinfo=timezone.utc)

def build_provider(b):
    h=max(b['h2h_candidates'],key=sortable) if b['h2h_candidates'] else None
    # Keep current paired two-sided totals by actual line, one freshest quote per numeric line.
    latest_by_line={}
    for t in b['total_candidates']:
        key=round(float(t['line']),6)
        if key not in latest_by_line or sortable(t)>sortable(latest_by_line[key]):latest_by_line[key]=t
    totals=sorted(latest_by_line.values(),key=sortable,reverse=True)
    t=totals[0] if totals else None
    h2h_close=None
    if h:
        h2h_close={'home':h['prices']['home'],'draw':h['prices']['draw'],'away':h['prices']['away'],'bookmaker':b['bookmaker'],'snapshot_label':h['snapshot_label'],'quoted_at':h.get('quoted_at'),'observed_at':h.get('observed_at'),'source':h['source']}
    total_close=None
    if t:
        total_close={'line':t['line'],'over':t['over'],'under':t['under'],'bookmaker':b['bookmaker'],'snapshot_label':t['snapshot_label'],'quoted_at':t.get('quoted_at'),'observed_at':t.get('observed_at'),'source':t['source'],'alternatives':[{k:v for k,v in x.items() if k in ('line','over','under','quoted_at','observed_at','snapshot_label','raw_pool_update','pool_status','feed_status','source')} for x in totals[1:]]}
    paired=bool(h and t and h['source'].get('sha256')==t['source'].get('sha256'))
    open_change=None
    if t and 'open_line' in t:
        ol=t.get('open_line') or {};openvals=[v for v in ol.values() if v is not None]
        open_change=bool(openvals and any(abs(v-t['line'])>1e-8 for v in openvals))
    return {'bookmaker':b['bookmaker'],'h2h':{'close':h2h_close} if h2h_close else None,'total':{'close':total_close} if total_close else None,'paired_market':paired,'market_line_changed_since_open':open_change,'observed_line_only':b['observed_line_only'],'sources':b['sources'],'source_market_count':len(b['h2h_candidates'])+len(b['total_candidates'])}

records=[];by_comp=defaultdict(lambda:{'fixtures':0,'with_current_hda':0,'with_current_two_sided_same_line_ou':0,'with_same_book_paired_hda_ou':0,'with_unpaired_market_only':0,'provider_book_count':0}); bybook=defaultdict(lambda:{'fixtures':set(),'hda':0,'ou':0,'paired':0})
for f in fixtures:
    allp={}
    add_espn(allp,f);add_r4_infersports(allp,f);add_hkjc(allp,f)
    ps=[build_provider(b) for b in allp.values()]
    ps=[p for p in ps if p['h2h'] or p['total'] or p['observed_line_only']]
    # Choose one same-source provider for status-compatible top-level fields; never combine books.
    def rank(p):
        pair=bool(p['paired_market']); both=bool(p['h2h'] and p['total']); h=bool(p['h2h']); t=bool(p['total'])
        priority={'DraftKings':0,'HKJC':1,'Bet 365':2,'nova88':3,'m8bet':4,'sbobet':5,'crown':6}
        return (pair,both,h or t,-priority.get(p['bookmaker'],99))
    primary=max(ps,key=rank) if ps else None
    rec={'id':f.get('id'),'match_id':f.get('match_id'),'event_id':f.get('event_id'),'competition':f.get('competition'),'stage':f.get('stage'),'season':f.get('season'),'date':f.get('date'),'kickoff_at':f.get('kickoff_at'),'home':f.get('home'),'away':f.get('away'),'home_id':f.get('home_id'),'away_id':f.get('away_id'),'identity_verified':f.get('identity_verified'),'cutoff_at':CUTOFF,'observed_at':f.get('observed_at'),'bookmaker':primary['bookmaker'] if primary else None,'h2h':primary['h2h'] if primary else None,'total':primary['total'] if primary else None,'paired_market':primary['paired_market'] if primary else False,'provider_markets':ps,'observed_line_only':[x for p in ps for x in p['observed_line_only']],'market_status':'COMPLETE_SAME_BOOK_HDA_AND_OU' if primary and primary['paired_market'] else ('SINGLE_MARKET_OR_UNPAIRED_BOOKS' if ps else 'NO_CURRENT_PRICE'),'source_status':'same-source/same-book only; see provider_markets; no cross-book interpolation'}
    records.append(rec)
    c=by_comp[f['competition']];c['fixtures']+=1
    h=set(p['bookmaker'] for p in ps if p['h2h']);t=set(p['bookmaker'] for p in ps if p['total']);pair=set(p['bookmaker'] for p in ps if p['paired_market'])
    if h:c['with_current_hda']+=1
    if t:c['with_current_two_sided_same_line_ou']+=1
    if pair:c['with_same_book_paired_hda_ou']+=1
    if (h or t) and not pair:c['with_unpaired_market_only']+=1
    c['provider_book_count']+=len(ps)
    for p in ps:
        b=bybook[(f['competition'],p['bookmaker'])];b['fixtures'].add(f.get('match_id'))
        if p['h2h']:b['hda']+=1
        if p['total']:b['ou']+=1
        if p['paired_market']:b['paired']+=1

(ROOT/'market-latest-status.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in records))
for c in by_comp.values():
    n=c['fixtures'];
    for k in ('with_current_hda','with_current_two_sided_same_line_ou','with_same_book_paired_hda_ou'):c[k+'_fraction']=round(c[k]/n,4) if n else None
bybookout={f'{c}|{b}':{'fixtures':len(v['fixtures']),'hda':v['hda'],'two_sided_same_line_ou':v['ou'],'same_book_paired':v['paired']} for (c,b),v in sorted(bybook.items())}
coverage={'schema':'WCPP-MARKET-LATEST-COVERAGE-1','as_of_at':CUTOFF,'source_scope':'ESPN odds response for all ESPN fixtures; exact R4 retained Infersports odds for 36 Big Five fixtures; exact R4 retained HKJC markets for 9 Champions League fixtures.','rules':{'h2h':'Accept only complete home/draw/away from one source/bookmaker.','totals':'Accept only complete over+under at the same numeric line from one source/bookmaker; retain all valid current-line alternatives in provider_markets.','pairing':'paired_market is true only when HDA and OU are available for the same bookmaker in the same response. Cross-book combinations are never made.','timestamps':'Keep source quote time when the provider exposes it; otherwise quoted_at=null and observed_at remains capture time.','line_only':'Any numeric source main line without a complete two-sided price is preserved in observed_line_only with evidence.'},'overall':{'fixtures':len(records),'with_current_hda':sum(v['with_current_hda'] for v in by_comp.values()),'with_current_two_sided_same_line_ou':sum(v['with_current_two_sided_same_line_ou'] for v in by_comp.values()),'with_same_book_paired_hda_ou':sum(v['with_same_book_paired_hda_ou'] for v in by_comp.values()),'with_unpaired_market_only':sum(v['with_unpaired_market_only'] for v in by_comp.values())},'by_competition':dict(sorted(by_comp.items())),'by_competition_bookmaker':bybookout}
(ROOT/'market-latest-coverage.json').write_text(json.dumps(coverage,ensure_ascii=False,indent=2))
print(coverage['overall'])
for c,x in sorted(by_comp.items()):print(c,x['fixtures'],x['with_current_hda'],x['with_current_two_sided_same_line_ou'],x['with_same_book_paired_hda_ou'],x['with_unpaired_market_only'])
