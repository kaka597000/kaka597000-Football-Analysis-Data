#!/usr/bin/env python3
"""Normalize complete same-provider ESPN/DraftKings open and close markets.
Original payloads remain in ../raw; this emits only derived Decimal fields.
"""
import json, math
from collections import defaultdict, Counter
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
fixtures=[json.loads(s) for s in (ROOT/'fixtures.jsonl').read_text().splitlines() if s.strip()]
queries=json.loads((ROOT/'queries.json').read_text())
query_by_sha={q['sha256']:q for q in queries}

def decimal_from_american(raw):
    if raw is None:return None
    s=str(raw).strip().replace('−','-')
    if not s:return None
    try:n=float(s)
    except (TypeError,ValueError):return None
    if not math.isfinite(n) or n==0:return None
    d=1+100/abs(n) if n<0 else 1+n/100
    return round(d,6)

def numeric_line(v):
    if v is None:return None
    s=str(v).strip().lower()
    if s.startswith(('o','u')):s=s[1:]
    try:return float(s)
    except (TypeError,ValueError):return None

def market_side(obj,side,period):
    x=(obj or {}).get(side) or {}
    p=x.get(period) or {}
    return {'american':p.get('odds'),'decimal':decimal_from_american(p.get('odds')),'line':numeric_line(p.get('line'))}

def complete_pair(obj,side,period):
    x=market_side(obj,side,period)
    return x['american'] is not None and x['decimal'] is not None

def line_equal(a,b):return a is not None and b is not None and abs(a-b)<1e-8

def extract(f):
    sha=f.get('sources',[{}])[0].get('sha256')
    q=query_by_sha.get(sha)
    if not q:return None,'no ESPN raw query mapping'
    try:body=json.loads((ROOT/q['path']).read_bytes())
    except Exception:return None,'raw response unreadable'
    ev=next((e for e in body.get('events',[]) if str(e.get('id'))==str(f.get('event_id'))),None)
    if ev is None:return None,'event missing from raw response'
    c=(ev.get('competitions') or [{}])[0]
    odds=c.get('odds') or []
    dk=next((o for o in odds if isinstance(o,dict) and isinstance(o.get('provider'),dict) and str(o['provider'].get('name','')).strip().lower()=='draftkings'),None)
    if dk is None:return None,'no DraftKings odds object'
    ml=dk.get('moneyline') or {}; total=dk.get('total') or {}
    sides=['home','draw','away']
    hda_ok=all(complete_pair(ml,s,p) for s in sides for p in ('open','close'))
    over_open=market_side(total,'over','open');under_open=market_side(total,'under','open')
    over_close=market_side(total,'over','close');under_close=market_side(total,'under','close')
    ou_price_ok=all(x['american'] is not None and x['decimal'] is not None for x in (over_open,under_open,over_close,under_close))
    lineopen=line_equal(over_open['line'],under_open['line'])
    lineclose=line_equal(over_close['line'],under_close['line'])
    main_line=numeric_line(dk.get('overUnder'))
    rawline_agree=(main_line is not None and all(line_equal(main_line,x['line']) for x in (over_open,under_open,over_close,under_close)))
    ou_ok=ou_price_ok and lineopen and lineclose and rawline_agree
    if not hda_ok:reason='incomplete open/close HDA prices'
    elif not ou_ok:reason='incomplete or inconsistent numeric total line / over-under prices'
    else:reason=None
    evidence={'provider':'DraftKings','source_url':q['url'],'source_sha256':q['sha256'],'raw_path':q['path'],'observed_at':q.get('query_observed_at'),'quoted_at':None,'time_basis':'ESPN response exposes open/close labels but no provider quote timestamp'}
    row={'id':f.get('id'),'match_id':f.get('match_id'),'event_id':f.get('event_id'),'competition':f.get('competition'),'stage':f.get('stage'),'season':f.get('season'),'kickoff_at':f.get('kickoff_at'),'cutoff_at':f.get('cutoff_at'),'home':f.get('home'),'away':f.get('away'),'home_id':f.get('home_id'),'away_id':f.get('away_id'),'identity_verified':f.get('identity_verified',False),'crosswalk_status':f.get('crosswalk_status'),'bookmaker':'DraftKings','market_evidence':evidence,'h2h':{'open':{'quoted_at':None,'market_time_basis':'provider quote time not exposed','prices':{s:market_side(ml,s,'open') for s in sides}},'close':{'quoted_at':None,'market_time_basis':'provider quote time not exposed','prices':{s:market_side(ml,s,'close') for s in sides}}} if hda_ok else None,'total':{'line':main_line,'open':{'quoted_at':None,'market_time_basis':'provider quote time not exposed','over':over_open,'under':under_open},'close':{'quoted_at':None,'market_time_basis':'provider quote time not exposed','over':over_close,'under':under_close}} if ou_ok else None,'complete_hda':hda_ok,'complete_same_line_total':ou_ok,'market_ready':hda_ok and ou_ok,'omission_reason':reason}
    return row,reason

rows=[]; all_rows=[]; rejection_counts=Counter(); counts=defaultdict(lambda:{'fixtures':0,'identity_verified_fixtures':0,'has_dk_object':0,'complete_hda_open_close':0,'complete_same_line_ou_open_close':0,'complete_hda_and_ou':0,'verified_identity_complete_hda_and_ou':0})
for f in fixtures:
    d=counts[f['competition']];d['fixtures']+=1
    if f.get('identity_verified'):d['identity_verified_fixtures']+=1
    row,err=extract(f)
    if row is None:
        status={'id':f.get('id'),'match_id':f.get('match_id'),'competition':f.get('competition'),'kickoff_at':f.get('kickoff_at'),'identity_verified':f.get('identity_verified',False),'market_ready':False,'reason':err}
        all_rows.append(status);rejection_counts[err]+=1;continue
    d['has_dk_object']+=1
    if row['complete_hda']:d['complete_hda_open_close']+=1
    if row['complete_same_line_total']:d['complete_same_line_ou_open_close']+=1
    if not row['market_ready']:rejection_counts[row['omission_reason']]+=1
    if row['market_ready']:
        d['complete_hda_and_ou']+=1
        rows.append(row)
        if row['identity_verified']:d['verified_identity_complete_hda_and_ou']+=1
    all_rows.append(row)
(ROOT/'market-ready.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
(ROOT/'market-status.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in all_rows))
all_codes=[c['code'] for c in json.loads(Path('/workspace/Football-Analysis-kpi-20261123-r4/configs/analysis-scope.json').read_text())['competitions']]
for code in all_codes: counts.setdefault(code,{'fixtures':0,'identity_verified_fixtures':0,'has_dk_object':0,'complete_hda_open_close':0,'complete_same_line_ou_open_close':0,'complete_hda_and_ou':0,'verified_identity_complete_hda_and_ou':0})
for d in counts.values(): d['complete_hda_and_ou_fraction']=(round(d['complete_hda_and_ou']/d['fixtures'],4) if d['fixtures'] else None)
(ROOT/'market-coverage.json').write_text(json.dumps({'normalization':'American signed odds converted to decimal and rounded to 6 decimals; raw American values retained alongside. Raw ESPN odds payloads are unmodified.','eligibility':'One DraftKings object must contain all open and close 1X2 sides plus open and close over/under numeric lines and prices; total line must agree between main line, both sides, and opening/closing labels.','quote_time':'No DraftKings quote timestamp is provided by ESPN. quoted_at remains null; observed_at is response capture time and must not be substituted for provider time.','overall':{'fixtures':len(fixtures),'market_ready_complete_same_source':len(rows),'verified_identity_market_ready':sum(bool(r.get('identity_verified')) for r in rows)},'market_failure_reasons':dict(rejection_counts),'by_competition':dict(sorted(counts.items()))},ensure_ascii=False,indent=2))
print('fixtures',len(fixtures),'ready',len(rows),'identity verified ready',sum(bool(r.get('identity_verified')) for r in rows))
for c,d in sorted(counts.items()):print(c,d)
