import json,hashlib,collections
from pathlib import Path
R=Path(__file__).resolve().parents[1];rows=[json.loads(s) for s in open(R/'panel.jsonl')]
scorefiles=[]
for f in sorted((R/'raw').glob('*-scoreboard.json')):
 parts=f.stem.rsplit('-',2);comp='-'.join(parts[:-2]);year=parts[-2];b=f.read_bytes();scorefiles.append({'competition':comp,'query_year':int(year),'url':f'https://site.api.espn.com/apis/site/v2/sports/soccer/{comp}/scoreboard?dates={year}&limit=1000','sha256':hashlib.sha256(b).hexdigest(),'file':str(f.relative_to(R)),'bytes':len(b)})
summary_sources={}
for r in rows:
 for s in r['sources']:
  if '/summary?' in s.get('url',''):summary_sources[s['url']]=s['sha256']
seasons={}
for r in rows:
 d=seasons.setdefault(r['season'],{'rows':0,'regulation_90_verified':0,'unverified':0})
 d['rows']+=1
 if r['score_basis'].startswith('regulation_90'):d['regulation_90_verified']+=1
 else:d['unverified']+=1
manifest={'provider':'ESPN public site API','captured_at_utc':'2026-11-23','cutoff_date':'2026-11-22','scope':{'competitions':['uefa.champions','uefa.europa','uefa.europa.conf'],'seasons':'2018-19 through 2026-27 fixtures dated through 2026-11-22','approved_stages':['group-stage','league-phase','knockout-round-playoffs','round-of-32','round-of-16','quarterfinals','semifinals','final'],'excluded_stages':['preliminary-round','qualifying-first-round','qualifying-second-round','qualifying-third-round','qualification playoffs']},'panel_rows':len(rows),'rows_by_competition':dict(collections.Counter(r['competition'] for r in rows)),'rows_by_season':seasons,'season_2025_26_by_competition':dict(collections.Counter(r['competition'] for r in rows if r['season']=='2025-26')),'regulation_90_verified':sum(r['score_basis'].startswith('regulation_90') for r in rows),'score_basis_unverified':sum(not r['score_basis'].startswith('regulation_90') for r in rows),'markets':{'hda_complete':sum(r['h2h'] is not None for r in rows),'ou_complete':sum(r['total'] is not None for r in rows),'both_complete':sum(r['h2h'] is not None and r['total'] is not None for r in rows),'provider':'Bet 365','basis':'ESPN summary explicit preMatch fields; timestamp/open-close not supplied; decimalized from fractional values'},'score_rule':'Use ESPN first+second-half linescores when captured; otherwise STATUS_FULL_TIME period 2 (no extra-time state); for AET/penalty use scoring events at clock <=5400 seconds and exclude extra-time/shootout. Two clock=0 event records with no scoring detail remain unverified and have 90-minute scores null; their listed scoreboard result is retained separately.','scoreboard_capture_files':scorefiles,'summary_responses':len(summary_sources),'summary_url_sha256':summary_sources,'markets_not_inferred_from_results':True}
(R/'sources.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
