#!/usr/bin/env python3
"""Backward-compatible entry point for offline score/market enrichment."""
from enrich_markets_offline import main
if __name__ == '__main__':
    main()
