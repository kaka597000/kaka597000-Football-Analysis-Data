#!/usr/bin/env python3
"""Capture ESPN public soccer scoreboards (2018-2026) for UEFA men's senior cups.
Markets are deliberately not inferred from scores; no historical market feed is exposed by this endpoint.
"""
import hashlib, json, time, urllib.request
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
RAW=ROOT/'raw'; RAW.mkdir(exist_ok=True)
COMPS=('uefa.champions','uefa.europa','uefa.europa.conf')
CUTOFF='2026-11-22'

def get(url):
    req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 (compatible; data research)'});return urllib.request.urlopen(req,timeout=45).read()
def sha(b): return hashlib.sha256(b).hexdigest()
def goal(x):
    try:return int(float(x))
    except (ValueError,TypeError):return None

def main():
    captured={}; events={}
    for comp in COMPS:
      for yr in range(2018,2027):
        url=f'https://site.api.espn.com/apis/site/v2/sports/soccer/{comp}/scoreboard?dates={yr}&limit=1000'
        body=get(url); fn=RAW/f'{comp}-{yr}-scoreboard.json';fn.write_bytes(body); digest=sha(body)
        captured[str(fn.relative_to(ROOT))]={'url':url,'sha256':digest,'bytes':len(body)}
        data=json.loads(body)
        for e in data.get('events',[]):
          evdate=e.get('date','')[:10]
          if evdate>CUTOFF or not evdate: continue
          c=e.get('competitions',[{}])[0]
          status=c.get('status',e.get('status',{})).get('type',{})
          if not status.get('completed') or status.get('state')!='post':continue
          teams={x.get('homeAway'):x for x in c.get('competitors',[])}
          if 'home' not in teams or 'away' not in teams:continue
          hg,ag=goal(teams['home'].get('score')),goal(teams['away'].get('score'))
          if hg is None or ag is None:continue
          season_year=(e.get('season') or {}).get('year')
          if not season_year: season_year=int(evdate[:4]) if int(evdate[5:7])>=7 else int(evdate[:4])-1
          season=f'{season_year}-{str(season_year+1)[-2:]}'
          slug=(e.get('season') or {}).get('slug','unknown')
          notes=c.get('notes') or []
          round_name='; '.join(dict.fromkeys(n.get('text','') for n in notes if n.get('text')))
          stage=slug.replace('-','_')
          if round_name: stage += ':'+round_name.lower().replace(' ','_')
          venue=c.get('venue') or e.get('venue') or {}
          neutral=bool(venue.get('neutralSite',False) or c.get('neutralSite',False))
          row={'id':f'espn:{e["id"]}','competition':comp,'stage':stage,'season':season,'date':evdate,
             'home':teams['home'].get('team',{}).get('displayName'),'away':teams['away'].get('team',{}).get('displayName'),
             'home_goals':hg,'away_goals':ag,'neutral':neutral,
             'sources':[{'url':url,'sha256':digest,'match_url':f'https://www.espn.com/soccer/match/_/gameId/{e["id"]}'}],
             'h2h':None,'total':None,'bookmaker':None,'market_time_basis':None,'paired_market':None,
             'source_stage_slug':slug,'source_round_label':round_name or None,'score_basis':'ESPN event scoreboard score; regulation-time basis pending summary cross-check'}
          events[row['id']]=row
        time.sleep(.15)
    rows=sorted(events.values(),key=lambda x:(x['date'],x['competition'],x['id']))
    with (ROOT/'panel.jsonl').open('w') as f:
      for r in rows:f.write(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n')
    (ROOT/'sources.json').write_text(json.dumps({'provider':'ESPN public site API','captured_at_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'cutoff':CUTOFF,'scope':{'competitions':COMPS,'seasons':'2018-19 through 2026-27 (matches through 2026-11-22)','senior_men':True},'capture_files':captured,'rows':len(rows),'markets':'ESPN scoreboard response has odds=[null] in inspected events; markets left null; no scores-to-odds imputation.'},ensure_ascii=False,indent=2)+'\n')
    print(f'{len(rows)} events')
if __name__=='__main__':main()
