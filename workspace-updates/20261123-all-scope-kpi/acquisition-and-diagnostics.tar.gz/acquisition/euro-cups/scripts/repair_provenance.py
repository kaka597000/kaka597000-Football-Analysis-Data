import json,hashlib
from pathlib import Path
R=Path(__file__).resolve().parents[1];P=R/'panel.jsonl';lookup={}
for f in (R/'raw').glob('*-scoreboard.json'):
 parts=f.stem.rsplit('-',2);comp='-'.join(parts[:-2]);year=parts[-2];b=f.read_bytes();digest=hashlib.sha256(b).hexdigest();url=f'https://site.api.espn.com/apis/site/v2/sports/soccer/{comp}/scoreboard?dates={year}&limit=1000'
 for e in json.loads(b).get('events',[]):lookup[(comp,str(e.get('id')))]=(url,digest)
rows=[]
for line in P.read_text().splitlines():
 x=json.loads(line);comp=x['competition'];eid=x['id'].split(':')[-1];x['sources']=[s for s in x['sources'] if 'dates=scoreboard' not in s.get('url','')]
 if (comp,eid) in lookup:
  u,h=lookup[(comp,eid)]
  if not any(s.get('url')==u for s in x['sources']):x['sources'].append({'url':u,'sha256':h})
 if not x['score_basis'].startswith('regulation_90'):
  source=lookup.get((comp,eid));reported={'home':None,'away':None}
  if source:
   u,h=source
   for f in (R/'raw').glob(f'{comp}-*-scoreboard.json'):
    d=json.loads(f.read_bytes())
    for ev in d.get('events',[]):
     if str(ev.get('id'))==eid:
      ct=(ev.get('competitions') or [{}])[0];tt={t.get('homeAway'):t for t in ct.get('competitors',[])}
      for side in ('home','away'):
       try:reported[side]=int(float(tt[side]['score']))
       except Exception:pass
      break
  x['scoreboard_result']=reported;x['home_goals']=None;x['away_goals']=None
 rows.append(x)
P.write_text(''.join(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n' for x in rows))
print(len(rows),'rows; repaired source urls')
