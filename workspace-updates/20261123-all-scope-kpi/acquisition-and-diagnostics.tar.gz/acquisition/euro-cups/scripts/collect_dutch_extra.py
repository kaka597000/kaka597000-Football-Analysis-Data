#!/usr/bin/env python3
"""Extract Dutch Eredivisie Conference League playoff matches from retained ESPN event archive."""
import json,hashlib,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];RAW=ROOT/'raw';RAW.mkdir(exist_ok=True)
SRC=Path('/workspace/WCPP/reports/jingcai-20261009-evening/ned.1-history.json')
archive=json.loads(SRC.read_bytes());selected=[]
for e in archive.get('events',[]):
 slug=(e.get('season') or {}).get('slug','')
 if slug not in ('conference-league-playoffs---semifinals','conference-league-playoffs---final'):continue
 c=(e.get('competitions') or [{}])[0];competitors={x.get('homeAway'):x for x in c.get('competitors',[])}
 if 'home' not in competitors or 'away' not in competitors:continue
 id_to_side={str(t.get('id')):side for side,t in competitors.items()};goals={'home':0,'away':0}
 for de in c.get('details') or []:
  clock=(de.get('clock') or {}).get('value');tid=str((de.get('team') or {}).get('id'))
  if not de.get('scoringPlay') or de.get('shootout') or clock is None or float(clock)>5400:continue
  side=id_to_side.get(tid)
  if side:goals[side]+=int(de.get('scoreValue') or 1)
 season_year=int((e.get('season') or {}).get('year') or 2025)
 selected.append({'id':f'espn:{e["id"]}','competition':'ned.1','stage':slug,'season':f'{season_year}-{str(season_year+1)[-2:]}','date':e.get('date','')[:10],'home':competitors['home'].get('team',{}).get('displayName'),'away':competitors['away'].get('team',{}).get('displayName'),'home_goals':goals['home'],'away_goals':goals['away'],'neutral':bool(c.get('neutralSite',False)),'sources':[],'h2h':None,'total':None,'bookmaker':None,'market_time_basis':None,'paired_market':None,'score_basis':'regulation_90 (retained ESPN goal-event clock ≤5400 seconds; extra time and shootout excluded)','source_full_time_status':c.get('status',{}).get('type',{}).get('name'),'source_reported_result':{side:int(float(team.get('score'))) for side,team in competitors.items()},'regulation_goal_event_count':sum(1 for de in c.get('details') or [] if de.get('scoringPlay') and not de.get('shootout') and (de.get('clock') or {}).get('value') is not None and float(de['clock']['value'])<=5400)})
raw=RAW/'ned.1-2025-26-playoffs-extracted-events.json';raw.write_text(json.dumps({'provider':'ESPN scoreboard event payloads retained in WCPP archive','source_archive':str(SRC),'events':[{k:v for k,v in e.items() if k in ('id','date','name','season','competitions')} for e in archive.get('events',[]) if e.get('id') in {x['id'].split(':')[-1] for x in selected}]},ensure_ascii=False,separators=(',',':'))+'\n')
digest=hashlib.sha256(raw.read_bytes()).hexdigest();url='https://site.api.espn.com/apis/site/v2/sports/soccer/ned.1/scoreboard?dates=2025&limit=1000'
for r in selected:r['sources']=[{'url':url,'sha256':digest,'capture_note':'SHA-256 is for the extracted retained event collection; original per-query response was not retained in WCPP.'}]
selected.sort(key=lambda r:(r['date'],r['stage'],r['id']))
(ROOT/'dutch-extra.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n' for x in selected))
(ROOT/'dutch-extra-scope.json').write_text(json.dumps({'scope_requested':'Dutch Eredivisie European-qualification / Conference League playoffs, seasons 2018-19 through fixtures 2026-11-22','local_archive_found':len(selected),'archive_seasons_covered':['2025-26'],'decision':'These three fixtures are separately administered stage-coded matches inside ESPN ned.1 (conference-league-playoffs), not regular-season N1 fixtures. No equivalent events were present in the retained local archive for 2018-19 through 2024-25; absence in this local archive is not evidence that no qualifying event was scheduled. Promotion/relegation playoffs are not included; they are outside this European-qualification stage and require a separate ned.2/KNVB scope.','source_archive':str(SRC),'source_archive_sha256':hashlib.sha256(SRC.read_bytes()).hexdigest(),'extracted_event_file':str(raw.relative_to(ROOT)),'extracted_event_sha256':digest,'current_rows':[{'id':x['id'],'date':x['date'],'stage':x['stage'],'home':x['home'],'away':x['away'],'score90':[x['home_goals'],x['away_goals']],'score_after_extra_time_or_penalties':x['source_reported_result']} for x in selected]},ensure_ascii=False,indent=2)+'\n')
print('dutch rows',len(selected),'scores90',[(x['home'],x['away'],x['home_goals'],x['away_goals']) for x in selected])
