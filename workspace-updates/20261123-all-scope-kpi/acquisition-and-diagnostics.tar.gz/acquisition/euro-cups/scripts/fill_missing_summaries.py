#!/usr/bin/env python3
import concurrent.futures,json,time,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];RAW=ROOT/'raw';PANEL=ROOT/'panel.jsonl'
rows=[]
for l in PANEL.read_text().splitlines():
 r=json.loads(l)
 if r['season']<'2018-19' or r['season']<'2023-24':continue
 p=RAW/f"{r['competition']}-{r['id'].split(':')[-1]}-summary.json"
 if not p.exists():rows.append(r)
print('missing targeted recent summaries',len(rows),flush=True)
def fetch(r):
 comp=r['competition'];eid=r['id'].split(':')[-1];p=RAW/f'{comp}-{eid}-summary.json';url=f'https://site.api.espn.com/apis/site/v2/sports/soccer/{comp}/summary?event={eid}';req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 (compatible; match research)'})
 for n in range(5):
  try:
   b=urllib.request.urlopen(req,timeout=45).read();p.write_bytes(b);return True,None
  except Exception as e:time.sleep(min(15,1+2**n));err=e
 return False,str(err)
errors=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
 fs={ex.submit(fetch,r):r for r in rows}
 for i,f in enumerate(concurrent.futures.as_completed(fs),1):
  ok,err=f.result()
  if not ok:errors.append({'id':fs[f]['id'],'error':err})
  if i%100==0:print(i,'/',len(rows),'failed',len(errors),flush=True)
(ROOT/'summary-retry-errors.json').write_text(json.dumps(errors,ensure_ascii=False,indent=2)+'\n')
print('complete',len(rows),'failed',len(errors),flush=True)
