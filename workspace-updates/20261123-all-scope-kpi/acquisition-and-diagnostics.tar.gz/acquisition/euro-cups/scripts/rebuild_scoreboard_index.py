import json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; RAW=ROOT/'raw'; cutoff='2026-11-22'; allowed={'group-stage','league-phase','knockout-round-playoffs','round-of-32','round-of-16','quarterfinals','semifinals','final'}
def val(v):
 try:return int(float(v))
 except:return None
rows={}
for p in RAW.glob('*-scoreboard.json'):
 comp=p.name.rsplit('-',2)[0]; b=p.read_bytes(); h=hashlib.sha256(b).hexdigest(); url=f'https://site.api.espn.com/apis/site/v2/sports/soccer/{comp}/scoreboard?dates={p.stem.rsplit("-",1)[1]}&limit=1000'
 for e in json.loads(b).get('events',[]):
  dt=e.get('date','')[:10]
  if not dt or dt>cutoff:continue
  c=(e.get('competitions') or [{}])[0]; slug=(e.get('season') or {}).get('slug','unknown')
  if slug not in allowed:continue
  st=c.get('status',e.get('status',{})).get('type',{})
  if st.get('state')!='post' or not st.get('completed'):continue
  teams={t.get('homeAway'):t for t in c.get('competitors',[])}
  if 'home' not in teams or 'away' not in teams:continue
  hg=val(teams['home'].get('score'));ag=val(teams['away'].get('score'))
  if hg is None or ag is None:continue
  sy=(e.get('season') or {}).get('year') or (int(dt[:4]) if int(dt[5:7])>=7 else int(dt[:4])-1)
  if sy < 2018: continue
  notes=c.get('notes') or [];rn='; '.join(dict.fromkeys(n.get('text','') for n in notes if n.get('text')))
  venue=c.get('venue') or e.get('venue') or {}; eid=e['id']
  rows[f'espn:{eid}']={'id':f'espn:{eid}','competition':comp,'stage':slug,'season':f'{sy}-{str(sy+1)[-2:]}','date':dt,'home':teams['home'].get('team',{}).get('displayName'),'away':teams['away'].get('team',{}).get('displayName'),'home_goals':hg,'away_goals':ag,'neutral':bool(venue.get('neutralSite',False) or c.get('neutralSite',False)),'sources':[{'url':url,'sha256':h,'match_url':f'https://www.espn.com/soccer/match/_/gameId/{eid}'}],'h2h':None,'total':None,'bookmaker':None,'market_time_basis':None,'paired_market':None,'round_label':rn or None,'leg':rn or None,'score_basis':'scoreboard_full_time; pending event summary regulation cross-check'}
out=sorted(rows.values(),key=lambda x:(x['date'],x['competition'],x['id']))
(ROOT/'panel.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n' for x in out));print(len(out))
