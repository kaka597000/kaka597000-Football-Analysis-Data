#!/usr/bin/env python3
"""Build the final 90-minute panel and enrich only genuine ESPN pre-match prices."""
import json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];RAW=ROOT/'raw';PANEL=ROOT/'panel.jsonl'
def dec(v):
 if v is None:return None
 try:
  s=str(v).strip()
  if '/' in s:
   a,b=s.split('/',1);return 1+float(a)/float(b)
  return float(s)
 except:return None
def main():
 rows=[json.loads(x) for x in PANEL.read_text().splitlines() if x.strip()]
 scoreboards={}
 for sp in RAW.glob('*-scoreboard.json'):
  parts=sp.stem.rsplit('-',2);comp='-'.join(parts[:-2]);yr=parts[-2]
  b=sp.read_bytes();digest=hashlib.sha256(b).hexdigest();url=f'https://site.api.espn.com/apis/site/v2/sports/soccer/{comp}/scoreboard?dates={yr}&limit=1000'
  for ev in json.loads(b).get('events',[]):scoreboards[(comp,str(ev.get('id')))]=(ev,digest,url)
 counts={'scoreboard_rows':len(rows),'summary_available':0,'regulation_90_verified':0,'unverified':0,'aet_or_pen_resolved_from_goal_events':0,'hda_complete':0,'ou_complete':0,'both_markets':0,'bet365':0}
 for r in rows:
  comp=r['competition'];eid=r['id'].split(':')[-1];r['sources']=[x for x in r['sources'] if not ('scoreboard' in x.get('url','') and 'dates=scoreboard' in x.get('url',''))];r['h2h']=None;r['total']=None;r['bookmaker']=None;r['market_time_basis']=None;r['paired_market']=None
  sb=scoreboards.get((comp,eid))
  if sb:
   ev,sdigest,surl=sb
   if not any(x.get('url')==surl for x in r['sources']):r['sources'].append({'url':surl,'sha256':sdigest})
   c=(ev.get('competitions') or [{}])[0];status=c.get('status',ev.get('status',{}));st=status.get('type',{}).get('name');period=status.get('period')
  else: ev=c=status={};st=None;period=None
  sp=RAW/f'{comp}-{eid}-summary.json'
  if sp.exists():
   b=sp.read_bytes();d=json.loads(b);counts['summary_available']+=1;url=f'https://site.api.espn.com/apis/site/v2/sports/soccer/{comp}/summary?event={eid}'
   if not any(x.get('url')==url for x in r['sources']):r['sources'].append({'url':url,'sha256':hashlib.sha256(b).hexdigest()})
   hc=(d.get('header',{}).get('competitions') or [{}])[0];teams={x.get('homeAway'):x for x in hc.get('competitors',[])}
   def reg(team):
    vals=[]
    for z in (team.get('linescores') or [])[:2]:
     try:vals.append(int(float(z.get('displayValue',z.get('value')))))
     except:pass
    return sum(vals) if len(vals)==2 else None
   hg,ag=reg(teams.get('home',{})),reg(teams.get('away',{}))
   if hg is not None and ag is not None:
    r['home_goals']=hg;r['away_goals']=ag;r['score_basis']='regulation_90 (sum of ESPN first- and second-half linescores)'
   else:r['score_basis']='scoreboard_full_time; summary has no two regulation half linescores'
   r['home']=teams.get('home',{}).get('team',{}).get('displayName',r['home']);r['away']=teams.get('away',{}).get('team',{}).get('displayName',r['away']);r['neutral']=bool(hc.get('neutralSite',r['neutral']))
   # HDA and O/U must come from the same provider's explicitly pre-match family.
   for q in d.get('odds') or []:
    if q.get('provider',{}).get('name')!='Bet 365':continue
    bo=q.get('bettingOdds',{}).get('teamOdds',{})
    if not bo:break
    hda={k:dec(bo.get(f'preMatchFullTimeResult{k.title()}',{}).get('value')) for k in ('home','draw','away')}
    line=dec(bo.get('preMatchOverUnderHandicap',{}).get('value'));over=dec(bo.get('preMatchGoalLineOver',{}).get('value'));under=dec(bo.get('preMatchGoalLineUnder',{}).get('value'))
    if all(v is not None for v in hda.values()):r['h2h']=hda;counts['hda_complete']+=1
    if line is not None and over is not None and under is not None:r['total']={'line':line,'over':over,'under':under};counts['ou_complete']+=1
    if r['h2h'] is not None or r['total'] is not None:
     r['bookmaker']='Bet 365';r['market_time_basis']='ESPN fields explicitly labeled preMatch; quote timestamp and open/close status not supplied';r['paired_market']='paired Bet 365 HDA and O/U from same ESPN event summary response' if r['h2h'] is not None and r['total'] is not None else 'single Bet 365 preMatch market; counterpart unavailable';counts['bet365']+=1
    break
  # Summary linescores are preferred. Resolve any remaining match score from the scoreboard event's own regulation status or goal timeline.
  if not r['score_basis'].startswith('regulation_90') and sb:
   comps={t.get('homeAway'):t for t in c.get('competitors',[])}
   if st=='STATUS_FULL_TIME' and period==2:
    r['home_goals']=int(float(comps['home']['score']));r['away_goals']=int(float(comps['away']['score']));r['score_basis']='regulation_90 (ESPN scoreboard STATUS_FULL_TIME, period=2; no extra-time state)'
   elif st in ('STATUS_FINAL_AET','STATUS_FINAL_PEN'):
    team_side={t.get('id'):t.get('homeAway') for t in c.get('competitors',[])};g={'home':0,'away':0};seen=False
    for evd in c.get('details') or []:
     clk=(evd.get('clock') or {}).get('value');team=(evd.get('team') or {}).get('id')
     if not evd.get('scoringPlay') or evd.get('shootout') or clk is None or float(clk)>5400:continue
     side=team_side.get(str(team))
     if side in g:g[side]+=int(evd.get('scoreValue') or 1);seen=True
    if seen:
     r['home_goals']=g['home'];r['away_goals']=g['away'];r['score_basis']='regulation_90 (ESPN scoring events through 5400 seconds; extra-time and shootout goals excluded)';counts['aet_or_pen_resolved_from_goal_events']+=1
    else:r['score_basis']='scoreboard result after extra time/penalties; regulation_90 not established'
   else:r['score_basis']='scoreboard full-time result; regulation_90 not established'
  if r['score_basis'].startswith('regulation_90'):counts['regulation_90_verified']+=1
  else:counts['unverified']+=1
  r['source_full_time_status']=st
 for r in rows:
  if r['h2h'] is not None and r['total'] is not None:counts['both_markets']+=1
 rows.sort(key=lambda x:(x['date'],x['competition'],x['id']))
 PANEL.write_text(''.join(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n' for x in rows))
 (ROOT/'summary-crosscheck.json').write_text(json.dumps({**counts,'odds_policy':'Bet 365 explicitly preMatch values only; same-summary paired markets; no inferred odds','score_policy':'summary half linescores preferred; STATUS_FULL_TIME period 2 accepted as normal 90; AET/penalty scores derived only from goal-event clock timeline, excluding extra time and shootouts'},ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(counts,ensure_ascii=False))
if __name__=='__main__':main()
