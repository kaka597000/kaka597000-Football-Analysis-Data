# UEFA club cups and Dutch increment

This package contains the senior men's UEFA Champions League (`uefa.champions`), Europa League (`uefa.europa`) and Conference League (`uefa.europa.conf`) panel, plus a separate Dutch European-playoff increment. The UEFA panel covers seasons 2018–19 through 2026–27, fixtures through 2026-11-22. Per-year scoreboard files and SHA-256 values are in `sources.json`; event summary captures are retained beside them in `raw/`.

## UEFA panel

`panel.jsonl` has 3,455 unique fixtures across all configured stage routes. It excludes preliminary and qualifying rounds and includes group/league stage and principal knockouts. The 2025–26 coverage is complete at 189 Champions League, 189 Europa League and 153 Conference League fixtures. The panel preserves ESPN's stage slug and round/leg note.

Scores use first- and second-half summary linescores where available. For event summaries that were unavailable, normal `STATUS_FULL_TIME` period-2 events use the ESPN scoreboard result. Extra-time and penalty matches use event-level scoring clocks through 5,400 seconds, excluding extra-time and shootouts. Two older events have no period or goal details (ESPN clock 0): their actual regulation scores are null, and the ESPN-listed event results remain in `scoreboard_result` for audit.

## Markets

The panel contains real Bet 365 pre-match prices where ESPN's event summary exposes complete values: 2,181 complete HDA sets, 2,182 complete O/U sets, and 2,181 matches with both. HDA and O/U are taken from the same Bet 365 preMatch family and response where paired; the source URL and response hash are recorded on the event. Fractional prices are stored as decimal odds. ESPN does not provide a capture timestamp or open/close label for these preMatch fields, so `market_time_basis` identifies the field family but does not assert a quote time. Incomplete markets stay null; no outcome-derived odds are present.

## Dutch extra

`dutch-extra.jsonl` lists three 2025–26 fixtures ESPN classifies in `ned.1` as `conference-league-playoffs---semifinals/final`. These belong to the Eredivisie competition route but are separate from regular-season fixtures. First- and second-round goals are calculated from retained goal-event clocks through 5,400 seconds; the final was 0–0 after 90, then 1–1 after extra time and Ajax won the shootout. See `dutch-extra-scope.json` for the retained archive location, SHA-256 and scope decision. The local evidence archive did not retain equivalent stage-coded events for 2018–19 through 2024–25; this is reported as an archive coverage gap, not proof no fixture occurred. Promotion/relegation playoffs are not included in this European-qualification increment.

## Reproduction

- `scripts/collect_espn_scoreboards.py` fetches the UEFA scoreboard year files.
- `scripts/rebuild_scoreboard_index.py` applies the approved stage scope and season cutoff.
- `scripts/enrich_markets_offline.py` reconstructs 90-minute scores from captured summaries/scoreboards and parses only explicit Bet 365 pre-match prices.
- `scripts/repair_provenance.py` drops any non-year scoreboard URL and nulls the 90-minute field for events without regulation evidence.
- `scripts/collect_dutch_extra.py` extracts the Dutch increment from its retained ESPN event archive.
