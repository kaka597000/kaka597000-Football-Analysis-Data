# WCPP-ALL-SCOPE-5 configured competition odds supplement

Collection time: 2026-11-23 UTC. Normal public HTTP requests only. No China Sports Lottery or mirror, paywall bypass, or blocked-source circumvention. This directory's normalized files intersect only competitions registered in ../protocol.json.

## Actual odds records

- config20_historical_odds.csv: 21,311 legacy 1X2 closing-aggregate rows from the public Kaggle dataset austro/beat-the-bookie-worldwide-football-dataset, filtered to ten of the 20 configured competition IDs. Real average and maximum 1X2 prices, bookmaker names/counts, source match ID, date, teams, source row, URL and original source SHA-256 are included. Exact counts by all 20 IDs are in config20_quote_counts.json.
- config20_espn_valid_odds.csv: two completed-event ESPN summary rows with complete actual preMatch 1X2 and O/U (line and both prices): one MLS event and one UEFA Champions League event. The quote time is unknown and left blank. Raw summaries and individual hashes are retained in raw/espn/.
- espn_manifest.json: all five event probes. Three returned no parseable complete preMatch price set and are not included as normalized quote rows.

Kaggle source is declared CC BY-SA 4.0. Its rows all end by 2015-06-30, so none overlap the selection, evaluation, or locked recent dates in the registered protocol. They are legacy odds only; do not assign them into the protocol time windows. This source has 1X2 only; its actual OU count is zero. Several historical league labels map across competition-era changes, so retain source_competition and isolate era/phase before any use.

ESPN normalized prices are a direct sample only, not a full-season pull. Its summary route is https://site.api.espn.com/apis/site/v2/sports/soccer/{league}/summary?event={id}. In a summary with complete markets, use odds[0].provider.name, odds[0].bettingOdds.teamOdds.preMatchFullTimeResultHome/Draw/Away.value, preMatchOverUnderHandicap.value (line), and preMatchGoalLineOver/Under.value (paired prices). Values are fractional strings, converted to decimal as 1 + numerator / denominator. Filter on literal preMatch keys; completed-game summaries also carry live markets. The source gives no separate quote timestamp.

ESPN completed-event summary probes:

- MLS sample: event 692995, St. Louis CITY SC–LA Galaxy, Bet 365; H/D/A 2.375/3.70/2.70; O/U 3.5 at 2.00/1.85. Summary URL and SHA are in espn_manifest.json.
- UCL sample: event 720418, Juventus–PSV, Bet 365; H/D/A 1.833333/3.80/4.10; O/U 2.5 at 1.91/1.99. Summary URL and SHA are in espn_manifest.json.
- J1, Brazil Serie A and UEFA Nations League probes exposed event-level odds objects but no complete parseable preMatch prices, so they are retained only as failed probes, not odds rows.

## Source probes and failure evidence

OddsPortal and BetExplorer homepages responded HTTP 200 to ordinary GETs, but no auditable full 1X2 plus O/U match quote was extracted in this pass. They are not counted as usable data here.

The Kaggle API exposes a newer dataset archangel0x01/football-odds-movements-2018-2026 (declared MIT, with 1X2/O-U history and match-closing files). Its public dataset listing endpoint succeeded; direct official downloads of match_closing.csv, matches.csv and match_closing.parquet each returned HTTP 503. No workaround or alternate mirror was attempted. This newer collection has no extracted records in this supplement.

config20_quote_counts.json is per this supplement only and does not include prices gathered by sibling collection agents. Kaggle rows are outside protocol dates; the ESPN two rows are in-config event samples but not protocol-season coverage. Full paired-market counts for actual evaluation must be recomputed after lawful source data from all collectors is identity-joined and time-filtered.


## Expanded one-date ESPN provider probe (20 competitions)

A separate one-date-per-competition probe was attempted on the protocol's 20 ESPN league paths, using a 2025/26 European date, calendar 2025 domestic date, Nations League 2024-09-07 and World Cup 2026-06-11. All 20 scoreboard requests returned HTTP 503 in that pass. URLs and requested dates are recorded in espn_representative_probe.json. No alternative endpoint, proxy, or access-control workaround was used. This means provider/market support beyond the retained 2024 MLS and UCL positive samples remains UNKNOWN; it is not evidence that those leagues have no ESPN markets.
