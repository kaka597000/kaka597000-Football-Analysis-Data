#!/usr/bin/env python3
"""Reproduce ESPN historical regular-season result and exposed opening-market extraction.

ESPN site API provides calendar-year league scoreboards for NOR.1/SWE.1/BRA.1.
Summary odds are fetched per event; only explicitly exposed opening quote values are
retained. No scoreboard current/live quote is treated as a pre-match quote.
"""
import concurrent.futures, datetime as dt, hashlib, json, pathlib, shutil, sqlite3, time, urllib.error, urllib.request
ROOT=pathlib.Path(__file__).resolve().parent
RAW=ROOT/'raw'; SUM=RAW/'summaries'; SUM.mkdir(parents=True,exist_ok=True)
LOCAL_SUM=RAW/'local-summaries'; LOCAL_SUM.mkdir(parents=True,exist_ok=True)
UNIFIED='/workspace/WCPP/data/unified/WCPP_统一赛事库.sqlite'
SLUGS={'nor.1':'Norwegian Eliteserien','swe.1':'Swedish Allsvenskan','bra.1':'Brazilian Serie A'}
START='2018-01-01'; CUTOFF='2026-11-22'
def sha(b): return hashlib.sha256(b).hexdigest()
def get(url):
    req=urllib.request.Request(url,headers={'User-Agent':'WCPP historical-panel collector/1.0','Accept':'application/json'})
    for retry in range(3):
        try:
            with urllib.request.urlopen(req,timeout=20) as r: return r.status,r.read(),r.geturl()
        except urllib.error.HTTPError as e:
            return e.code,e.read(),e.geturl()
        except Exception:
            if retry==2: raise
            time.sleep(.5*(retry+1))
def save_body(path,b): path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(b)
def decimal(x):
    try: v=float(x['decimal'])
    except (TypeError,KeyError,ValueError): return None
    return v if v>1 else None
def odds_extract(blob):
    try: root=json.loads(blob)
    except Exception: return None,None,None
    hda=total=book=None
    # ESPN can expose stale/current odds after a game; only explicit open quotes qualify.
    for o in root.get('odds') or []:
        provider=(o.get('provider') or {}).get('name')
        ho=(o.get('homeTeamOdds') or {}).get('open') or {}
        ao=(o.get('awayTeamOdds') or {}).get('open') or {}
        draw=(o.get('drawOdds') or {}).get('open') or {}
        hm=decimal(ho.get('moneyLine') or {})
        am=decimal(ao.get('moneyLine') or {})
        dm=decimal(draw.get('moneyLine') or {})
        if hda is None and hm and dm and am:
            hda={'home':hm,'draw':dm,'away':am};book=provider
        op=o.get('open') or {}; ln=op.get('total') or {}; line=None
        # ESPN's open.total.value is sometimes the over price, not the line.
        # The source line is the explicit alternateDisplayValue in these payloads.
        try: line=float(ln.get('alternateDisplayValue'))
        except (TypeError,ValueError):
            try: line=float(ln.get('displayValue'))
            except (TypeError,ValueError): line=None
        over=decimal(op.get('over') or {}); under=decimal(op.get('under') or {})
        if total is None and line is not None and over and under:
            total={'line':line,'over':over,'under':under};book=book or provider
    return hda,total,book
def main():
    assets=[]; event_records=[]; scoreboards=[]
    for slug in SLUGS:
      for year in range(2018,2027):
        url=f'https://site.api.espn.com/apis/site/v2/sports/soccer/{slug}/scoreboard?dates={year}&limit=1000'
        name=f'{slug.replace(".","_")}-{year}-scoreboard.json'; scoreboard_path=RAW/name
        if scoreboard_path.exists():
            body=scoreboard_path.read_bytes(); status=200; final=url
        else:
            status,body,final=get(url);save_body(scoreboard_path,body)
        if status!=200: raise RuntimeError(f'ESPN scoreboard HTTP {status}: {url}')
        x=json.loads(body); scoreboards.append({'competition':slug,'calendar_year':year,'url':final,'http_status':status,'file':'raw/'+name,'bytes':len(body),'sha256':sha(body)})
        for e in x.get('events') or []:
            c=(e.get('competitions') or [{}])[0]; date=(e.get('date') or c.get('date') or '')[:10]
            if not date or date<START or date>CUTOFF: continue
            # Postseason promotion/relegation playoffs use the same ESPN league slug; their
            # competition note explicitly identifies legs, so only regular league rounds remain.
            notes=c.get('notes') or []
            if any(('leg' in (n.get('text') or '').lower() or 'playoff' in (n.get('text') or '').lower()) for n in notes): continue
            status_obj=e.get('status') or {}; st=status_obj.get('type') or {}
            if not st.get('completed') or st.get('state')!='post': continue
            comp=c
            competitors=comp.get('competitors') or []
            h=next((q for q in competitors if q.get('homeAway')=='home'),None)
            a=next((q for q in competitors if q.get('homeAway')=='away'),None)
            if not h or not a: continue
            try: hg=int(h['score']); ag=int(a['score'])
            except (KeyError,TypeError,ValueError): continue
            if hg<0 or ag<0: continue
            event_season=(e.get('season') or {}).get('year',year)
            event_records.append({'id':str(e['id']),'competition':slug,'season':str(event_season),'calendar_query_year':year,'date':date,'home':h.get('team',{}).get('displayName') or h.get('team',{}).get('name'),'away':a.get('team',{}).get('displayName') or a.get('team',{}).get('name'),'home_goals':hg,'away_goals':ag,'neutral':bool(comp.get('neutralSite') or (comp.get('venue') or {}).get('neutralSite')),'score_url':final,'score_file':'raw/'+name,'score_sha':sha(body),'stage':'regular','event_url':f'https://site.api.espn.com/apis/site/v2/sports/soccer/{slug}/summary?event={e["id"]}'})
    # Fetch full event summaries to identify archived prematch-open quotes and preserve raw evidence.
    def fetch_summary(row):
        try:
            fn=f'{row["competition"].replace(".","_")}-{row["id"]}-summary.json';save_path=SUM/fn
            if save_path.exists():
                body=save_path.read_bytes(); final=row['event_url']
                try:
                    cached=json.loads(body); status=200 if any(k in cached for k in ('header','boxscore','odds','pickcenter')) else 503
                except Exception: status=503
            else: status,body,final=get(row['event_url']);save_body(SUM/fn,body)
            if status != 200: return {'id':row['id'],'url':final,'http_status':status,'file':'raw/summaries/'+fn,'bytes':len(body),'sha256':sha(body),'error':'upstream_http_'+str(status)}
            hda,total,book=odds_extract(body)
            return {'id':row['id'],'url':final,'http_status':status,'file':'raw/summaries/'+fn,'bytes':len(body),'sha256':sha(body),'h2h':hda,'total':total,'bookmaker':book,'market_time_basis':'ESPN event summary explicit opening market fields; quote time not provided' if hda or total else None}
        except Exception as ex:
            return {'id':row['id'],'url':row['event_url'],'error':type(ex).__name__+': '+str(ex)[:200]}
    summaries={}
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        for q in pool.map(fetch_summary,event_records): summaries[q['id']]=q
    local_assets=[]; local_quotes={}
    db=sqlite3.connect(f'file:{UNIFIED}?mode=ro',uri=True)
    source_meta={p:(u,t,h) for p,u,h,t in db.execute("SELECT path,url,sha256,observed_at FROM sources WHERE url LIKE '%/summary?event=%'")}
    db.close()
    import re
    target_map={r['id']:r for r in event_records}
    target_ids=set(target_map)
    for srcpath in pathlib.Path('/workspace/WCPP/reports').rglob('*.json'):
        if 'summary' not in srcpath.name.lower() or srcpath.stat().st_size>5_000_000: continue
        try:
            blob=srcpath.read_bytes(); root=json.loads(blob)
            if not isinstance(root,dict): continue
            header=root.get('header') or {}; league=header.get('league') or {}
            if league.get('slug') not in SLUGS: continue
            slug=league['slug']; eid=str(header.get('id') or '')
            if eid not in target_ids: continue
            hda,total,book=odds_extract(blob)
            if not hda and not total: continue
            actual=sha(blob); meta=source_meta.get(str(srcpath)) or source_meta.get(str(srcpath.resolve()))
            stored_url,observed,expected_sha=meta if meta else (None,None,None)
            if expected_sha and expected_sha!=actual: continue
            url=stored_url or f'https://site.api.espn.com/apis/site/v2/sports/soccer/{slug}/summary?event={eid}'
            observed=observed or dt.datetime.fromtimestamp(srcpath.stat().st_mtime,dt.timezone.utc).isoformat()
            candidate={'competition':slug,'url':url,'file':'raw/local-summaries/'+srcpath.name.replace('/','_'),'sha256':actual,'h2h':hda,'total':total,'bookmaker':book,'observed_at_utc':observed,'original_file':str(srcpath)}
            prev=local_quotes.get(eid)
            def quality(z):
                try: pregame=z['observed_at_utc'][:10] < target_map[eid]['date']
                except Exception: pregame=False
                return (int(bool(z['h2h']))+int(bool(z['total'])),int(pregame),z['observed_at_utc'])
            if prev and quality(prev)[:2]>quality(candidate)[:2]: continue
            if prev and quality(prev)[:2]==quality(candidate)[:2] and quality(prev)[2] <= quality(candidate)[2]: continue
            dest=LOCAL_SUM/f'{slug.replace(".","_")}-{eid}-{actual[:12]}.json';shutil.copyfile(srcpath,dest);candidate['file']='raw/local-summaries/'+dest.name
            local_quotes[eid]=candidate
        except Exception: continue
    for eid,q in local_quotes.items():
        q['market_time_basis']='ESPN archived event summary explicit opening market fields; capture '+str(q['observed_at_utc'])+' UTC; provider quote timestamp not supplied'
        local_assets.append({k:q[k] for k in ('competition','event_id','url','original_file','file','observed_at_utc','sha256') if k!='event_id'}|{'event_id':eid,'h2h_available':bool(q['h2h']),'total_available':bool(q['total'])})
    output=[]; raw_summaries=[]
    for r in event_records:
        q=summaries[r['id']]
        local=local_quotes.get(r['id'])
        if local: q={**q,'h2h':local['h2h'],'total':local['total'],'bookmaker':local['bookmaker'],'market_time_basis':local['market_time_basis']}
        src=[{'provider':'ESPN site API scoreboard','url':r['score_url'],'file':r['score_file'],'sha256':r['score_sha']}]
        if q.get('http_status')==200 and q.get('sha256'): src.append({'provider':'ESPN site API event summary','url':q['url'],'file':q['file'],'sha256':q['sha256']})
        if local: src.append({'provider':'WCPP archived ESPN event summary','url':local['url'],'file':local['file'],'sha256':local['sha256']})
        output.append({'id':f'ESPN:{r["competition"]}:{r["id"]}','competition':r['competition'],'stage':'regular','season':r['season'],'date':r['date'],'home':r['home'],'away':r['away'],'home_goals':r['home_goals'],'away_goals':r['away_goals'],'neutral':r['neutral'],'sources':src,'h2h':q.get('h2h'),'total':q.get('total'),'bookmaker':q.get('bookmaker'),'market_time_basis':q.get('market_time_basis') or 'No qualifying historical paired quote; ESPN summary absent/unavailable or lacks explicit opening values. Current/live odds excluded.','paired_market':bool(q.get('h2h') and q.get('total'))})
        raw_summaries.append({k:v for k,v in q.items() if k not in ['h2h','total']})
    output.sort(key=lambda x:(x['competition'],x['season'],x['date'],x['home'],x['away']))
    with (ROOT/'panel.jsonl').open('w',encoding='utf8') as f:
        for x in output:f.write(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n')
    manifest={'built_at_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'scope':{'from':START,'through':CUTOFF,'competitions':SLUGS,'season_definition':'event season year reported by ESPN; Brazil cross-year carryovers follow the event season; final 2026 matches capped 2026-11-22','stage':'regular league fixtures; event notes identifying playoff legs excluded','result_status':'completed post-game ESPN events only; competition final score retained as regulation league score'},'scoreboards':scoreboards,'local_reused_event_summaries':local_assets,'event_summary_calls':raw_summaries}
    (ROOT/'raw-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    counts={}
    for x in output:
        k=(x['competition'],x['season']); z=counts.setdefault(k,{'matches':0,'h2h':0,'total':0,'paired':0}); z['matches']+=1;z['h2h']+=bool(x['h2h']);z['total']+=bool(x['total']);z['paired']+=x['paired_market']
    errors=[x for x in raw_summaries if 'error' in x]
    error_status={}
    for e in errors:
        k=str(e.get('http_status','exception'));error_status[k]=error_status.get(k,0)+1
    (ROOT/'coverage.json').write_text(json.dumps({'source':'ESPN site API; WCPP archived event summaries reused where available','coverage_by_competition_season':[{'competition':k[0],'season':k[1],**v} for k,v in sorted(counts.items())],'matches':len(output),'missing_open_hda':sum(not x['h2h'] for x in output),'missing_open_total':sum(not x['total'] for x in output),'paired_market_rows':sum(x['paired_market'] for x in output),'local_reused_summaries':len(local_assets),'summary_fetch_error_count':len(errors),'summary_fetch_error_status_counts':error_status,'summary_fetch_error_examples':errors[:12]},ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    print('matches',len(output),'summaries',len(raw_summaries),'errors',sum('error' in x for x in raw_summaries),'hda',sum(bool(x['h2h']) for x in output),'total',sum(bool(x['total']) for x in output),'paired',sum(x['paired_market'] for x in output))
if __name__=='__main__':main()
