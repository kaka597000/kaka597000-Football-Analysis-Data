#!/usr/bin/env python3
"""Build the final NOR/SWE/BRA full-time panel from archived Football-Data new CSVs.
Use ESPN event summaries only for explicitly recorded opening totals, and never use
post-match current/live values. The intermediate ESPN result file remains untouched.
"""
import csv,datetime as dt,difflib,hashlib,json,pathlib,re,unicodedata,collections
ROOT=pathlib.Path(__file__).resolve().parent
RAW=ROOT/'raw/football-data-new'
ESPN=ROOT/'panel-espn-open-markets.jsonl'
START=dt.date(2018,1,1); CUTOFF=dt.date(2026,11,22)
META=json.loads((RAW/'sources.json').read_text(encoding='utf8'))
SRC={x['name']:x for x in META}
MAP={'NOR':('nor.1','Norwegian Eliteserien',240),'SWE':('swe.1','Swedish Allsvenskan',240),'BRA':('bra.1','Brazilian Serie A',380)}
def digest(b):return hashlib.sha256(b).hexdigest()
def norm(s):
    s=unicodedata.normalize('NFKD',s or '').encode('ascii','ignore').decode().lower().replace('&',' and ')
    s=s.replace('odds','odd')
    for a,b in [('red bull bragantino','bragantino'),('america mineiro','america'),('america mg','america'),('atletico mineiro','atleticomg'),('atletico mg','atleticomg'),('athletico pr','atleticopr'),('atletico pr','atleticopr'),('vasco da gama','vasco'),('atletico goianiense','atleticogo'),('varbergs bois','varberg'),('hamarkameratene','hamkam'),('halmstads','halmstad'),('sport recife','sport')]:s=s.replace(a,b)
    ignored={'bk','fk','if','il','sk','ik','ff','afc','fc','cf','ifk','rb','sc','rj','rs','ba','ce','sp','pa','ms','08','gif','oif','ek','kif','aif','club','deportivo'}
    return ''.join(w for w in re.findall(r'[a-z]+',s) if w not in ignored and not w.isdigit())
def fnum(row,field):
    try:
        x=float((row.get(field) or '').strip())
        return x if x>1 else None
    except (ValueError,AttributeError):return None
def parse_day(s):return dt.datetime.strptime(s.strip(),'%d/%m/%Y').date()
def odds_open_provider(x):
    b=x.get('bookmaker')
    return b.get('total') if isinstance(b,dict) else b
def main():
    espn=[json.loads(s) for s in ESPN.read_text(encoding='utf8').splitlines() if s.strip()]
    # Index ESPN results by normalized sides and a one-day window for UTC/local-date differences.
    eidx=collections.defaultdict(list)
    allidx=collections.defaultdict(list)
    for e in espn:
        allidx[(e['competition'],norm(e['home']),norm(e['away']))].append(e)
        if e.get('total'):
            eidx[(e['competition'],norm(e['home']),norm(e['away']))].append(e)
    records=[]; season_rows=collections.defaultdict(list); source_meta=[]; csv_meta={}
    for code,(comp,name,expected) in MAP.items():
        fn=f'{code}.csv'; path=RAW/fn; blob=path.read_bytes(); sha=digest(blob); source=SRC[fn]
        if sha!=source['sha256']:raise ValueError('source SHA mismatch '+fn)
        csv_meta[code]={'url':source['url'],'retrieved_at_utc':source['fetch_time'],'file':'raw/football-data-new/'+fn,'bytes':len(blob),'sha256':sha}
        text=blob.decode('utf-8-sig',errors='replace');reader=csv.DictReader(text.splitlines());rows=[]
        for lineno,row in enumerate(reader,2):
            if not row.get('Date') or not row.get('Home') or not row.get('Away'):continue
            try:d=parse_day(row['Date']);hg=int(row['HG']);ag=int(row['AG']);season=str(int(row['Season']))
            except (ValueError,TypeError):continue
            if d<START or d>CUTOFF:continue
            rec={'code':code,'competition':comp,'name':name,'season':season,'date':d.isoformat(),'home':row['Home'].strip(),'away':row['Away'].strip(),'hg':hg,'ag':ag,'row':row,'lineno':lineno,'expected':expected,'source':csv_meta[code]}
            rows.append(rec);season_rows[(code,season)].append(rec)
        # Season fixture participation count identifies only low-count clubs supplied
        # as same-code promotion/relegation tie legs; retain those under a separate stage.
        all_season={}
        for r in rows:
            k=(code,r['season']);all_season.setdefault(k,collections.Counter());all_season[k][norm(r['home'])]+=1;all_season[k][norm(r['away'])]+=1
        for r in rows:
            d=dt.date.fromisoformat(r['date'])
            counts=all_season[(code,r['season'])]
            r['stage']='promotion_relegation_playoff' if min(counts[norm(r['home'])],counts[norm(r['away'])])<8 else 'regular'
            # Independent local ESPN result crosscheck, keyed by competition,
            # normalized team identity, season and a +/-1 calendar-day allowance.
            audit=[]
            for e in allidx.get((comp,norm(r['home']),norm(r['away'])),[]):
                delta=abs((dt.date.fromisoformat(e['date'])-d).days)
                if delta<=1:
                    audit.append((int(str(e.get('season'))!=r['season']),delta,int(e['home_goals']!=r['hg'])+int(e['away_goals']!=r['ag']),e))
            audit.sort(key=lambda z:z[:3]);audit_event=audit[0][3] if audit else None
            r['score_crosscheck']=bool(audit_event);r['score_agreement']=bool(audit_event and audit_event['home_goals']==r['hg'] and audit_event['away_goals']==r['ag']);r['audit_event']=audit_event
            r['neutral']=bool(audit_event.get('neutral',False)) if audit_event else False
            r['h2h']=None;r['h2h_book']=None;r['h2h_fields']=None
            # Prefer a same-book pair when a matching total archive exists; otherwise
            # Pinnacle closing prices are primary, then Bet365, then the mixed average.
            candidates=[]
            for book,fields,source_name,same in [
                ('Bet365',['B365CH','B365CD','B365CA'],'football-data Bet365 closing 1X2',True),
                ('Pinnacle',['PSCH','PSCD','PSCA'],'football-data Pinnacle closing 1X2',True),
                ('Football-Data market average',['AvgCH','AvgCD','AvgCA'],'football-data multi-book closing average 1X2',False)]:
                vals=[fnum(r['row'],f) for f in fields]
                if all(v is not None for v in vals):candidates.append((book,fields,source_name,same,vals))
            # Look for a qualifying archived total from the same event and align it
            # by both team names plus date +/- one day; choose only a unique best event.
            cand_events=[]
            for e in eidx.get((comp,norm(r['home']),norm(r['away'])),[]):
                delta=abs((dt.date.fromisoformat(e['date'])-d).days)
                if delta<=1:
                    mismatch=int(str(e.get('season'))!=r['season'])
                    scorefit=int(e['home_goals']==r['hg'])+int(e['away_goals']==r['ag'])
                    cand_events.append((mismatch,0,delta,-scorefit,e))
            if not cand_events:
                for (ec,eh,ea),es in eidx.items():
                    if ec!=comp:continue
                    sh=difflib.SequenceMatcher(None,norm(r['home']),eh).ratio();sa=difflib.SequenceMatcher(None,norm(r['away']),ea).ratio()
                    if sh<0.78 or sa<0.78:continue
                    for e in es:
                        delta=abs((dt.date.fromisoformat(e['date'])-d).days)
                        if delta<=1:
                            mismatch=int(str(e.get('season'))!=r['season'])
                            scorefit=int(e['home_goals']==r['hg'])+int(e['away_goals']==r['ag'])
                            cand_events.append((mismatch,2-sh-sa,delta,-scorefit,e))
            cand_events.sort(key=lambda x:x[:4])
            market_event=None
            if cand_events:
                if len(cand_events)==1 or cand_events[0][:4]!=cand_events[1][:4]:market_event=cand_events[0][4]
            ou=market_event.get('total') if market_event else None
            ou_book=odds_open_provider(market_event) if market_event else None
            # Prefer Bet365 HDA if the matching total is also from Bet365; otherwise
            # use Pinnacle close, with a disclosed multi-book average fallback.
            pick=None
            if ou and ou_book and 'bet365' in ou_book.lower():pick=next((c for c in candidates if c[0]=='Bet365'),None)
            if not pick:pick=next((c for c in candidates if c[0]=='Pinnacle'),None)
            if not pick:pick=next((c for c in candidates if c[0]=='Bet365'),None)
            if not pick:pick=next((c for c in candidates if c[0]=='Football-Data market average'),None)
            if pick:r['h2h']={'home':pick[4][0],'draw':pick[4][1],'away':pick[4][2]};r['h2h_book']=pick[0];r['h2h_fields']=pick[1];r['h2h_basis']=pick[2]
            r['total']=ou;r['total_book']=ou_book;r['market_event']=market_event
            r['source_fields']={'home_goals':'HG','away_goals':'AG','h2h':r['h2h_fields']}
            records.append(r)
    output=[]
    for r in records:
        sources=[{'provider':'football-data.co.uk new NOR/SWE/BRA CSV','url':r['source']['url'],'file':r['source']['file'],'sha256':r['source']['sha256'],'source_row':r['lineno']}]
        if r.get('score_crosscheck'):
            for s in r['audit_event'].get('sources',[]):
                if 'scoreboard' in s.get('provider','').lower():sources.append(s)
        if r['market_event']:
            for s in r['market_event'].get('sources',[]):
                if 'summary' in (s.get('provider','').lower()):sources.append(s)
        books={'h2h':r['h2h_book'],'total':r['total_book']}
        nonnull={v for v in books.values() if v}
        bookmaker=next(iter(nonnull)) if len(nonnull)==1 else (books if nonnull else None)
        time_basis={'h2h':'Football-Data closing-category price fields; quote timestamp is not provided' if r['h2h'] else None,'total':'ESPN archived opening-market fields; provider quote timestamp is not provided' if r['total'] else None}
        paired=bool(r['h2h'] and r['total'] and r['h2h_book'] and r['total_book'] and r['h2h_book']==r['total_book'])
        key=f'{r["code"]}|{r["season"]}|{r["lineno"]}|{r["date"]}|{r["home"]}|{r["away"]}'
        score_basis='football-data.co.uk HG/AG full-time fields; regulation-time league result' if r['stage']=='regular' else 'football-data.co.uk HG/AG full-time fields; same-code play-off; source does not separately provide extra-time score'
        output.append({'id':'football-data:new:'+hashlib.sha256(key.encode()).hexdigest()[:24],'competition':r['competition'],'stage':r['stage'],'season':r['season'],'date':r['date'],'home':r['home'],'away':r['away'],'home_goals':r['hg'],'away_goals':r['ag'],'score_basis':score_basis,'neutral':bool(r['neutral']),'neutral_basis':'ESPN neutralSite when exact local crosscheck exists; otherwise inferred false from league home/away designation and Football-Data has no neutral flag','sources':sources,'h2h':r['h2h'],'total':r['total'],'bookmaker':bookmaker,'market_bookmakers':books,'market_time_basis':time_basis,'paired_market':paired,'score_crosscheck_espn':r['score_crosscheck'],'score_agrees_espn':r['score_agreement']})
    output.sort(key=lambda x:(x['competition'],x['season'],x['stage'],x['date'],x['home'],x['away']))
    (ROOT/'panel.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n' for x in output),encoding='utf8')
    cov=[]
    for (code,season),rs in sorted(season_rows.items()):
        kept=[r for r in rs if r['stage']=='regular'];po=[r for r in rs if r['stage']!='regular'];team_count=len({t for r in kept for t in (r['home'],r['away'])})
        team_count=len({norm(t) for r in kept for t in (r['home'],r['away'])})
        cov.append({'competition':code.lower()+'.1','season':season,'regular_completed_matches':len(kept),'separate_same_code_playoff_matches':len(po),'team_count':team_count,'expected_teams':20 if code=='BRA' else 16,'expected_full_regular_matches':kept[0]['expected'],'h2h_pinnacle_rows':sum(bool(r['h2h'] and r['h2h_book']=='Pinnacle') for r in kept),'h2h_bet365_rows':sum(bool(r['h2h'] and r['h2h_book']=='Bet365') for r in kept),'h2h_average_rows':sum(bool(r['h2h'] and r['h2h_book']=='Football-Data market average') for r in kept),'total_rows':sum(bool(r['total']) for r in kept),'paired_same_book_rows':sum(bool(r['h2h'] and r['total'] and r['h2h_book']==r['total_book']) for r in kept),'espn_score_crosschecks':sum(r['score_crosscheck'] for r in kept),'espn_score_agreements':sum(r['score_agreement'] for r in kept),'status':'PARTIAL_AT_2026-11-22' if season=='2026' else ('CARDINALITY_COMPLETE' if len(kept)==kept[0]['expected'] else 'GAP_OR_SOURCE_EXCEPTION')})
    (ROOT/'coverage.json').write_text(json.dumps({'source':'Football-Data.co.uk new NOR/SWE/BRA CSV plus locally archived ESPN event-summary opening totals','scope':{'date_from':START.isoformat(),'date_through':CUTOFF.isoformat(),'regular_league_codes':['NOR','SWE','BRA'],'same_code_playoffs':'retained with stage promotion_relegation_playoff when one participant has fewer than 8 normalized season appearances'},'rows':cov,'totals':{'all_rows':len(output),'regular_rows':sum(x['stage']=='regular' for x in output),'separate_playoff_rows':sum(x['stage']!='regular' for x in output),'hda_rows':sum(bool(x['h2h']) for x in output),'ou_rows':sum(bool(x['total']) for x in output),'paired_same_book_rows':sum(x['paired_market'] for x in output),'score_crosscheck_espn':sum(x['score_crosscheck_espn'] for x in output),'score_agreements_espn':sum(x['score_agrees_espn'] for x in output)},'football_data_sources':csv_meta},ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    raw_manifest=ROOT/'raw-manifest.json'
    rm=json.loads(raw_manifest.read_text(encoding='utf8'))
    rm['football_data_new_league_files']=csv_meta
    rm['football_data_market_mapping']={'h2h_priority':'Bet365 if same-provider archived total exists and complete; otherwise Pinnacle close PSCH/PSCD/PSCA; then Bet365 close B365CH/B365CD/B365CA; then mixed-market average AvgCH/AvgCD/AvgCA','total_fields':'ESPN archived explicit opening total line (alternateDisplayValue/displayValue only) and decimal over/under; ESPN open.total.value is never used as a line','quote_clock':'Neither Football-Data close categories nor ESPN opening archive provides an independently verifiable quote timestamp'}
    rm['derived_artifacts']={}
    for name in ('panel.jsonl','panel-espn-open-markets.jsonl','coverage.json','README.md','build_final_panel.py','extract_cached_markets.py'):
        path=ROOT/name
        if path.exists():
            b=path.read_bytes();rm['derived_artifacts'][name]={'bytes':len(b),'sha256':digest(b)}
    raw_manifest.write_text(json.dumps(rm,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    print('rows',len(output),'regular',sum(x['stage']=='regular' for x in output),'playoffs',sum(x['stage']!='regular' for x in output),'hda',sum(bool(x['h2h']) for x in output),'totals',sum(bool(x['total']) for x in output),'same-book paired',sum(x['paired_market'] for x in output))
if __name__=='__main__':main()
