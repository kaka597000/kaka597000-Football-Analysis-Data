# NOR / SWE / BRA regular-season historical panel

`panel.jsonl` is the final match panel for Norway Eliteserien (`nor.1`), Sweden Allsvenskan (`swe.1`), and Brazil Serie A (`bra.1`), 2018-01-01 through 2026-11-22. It contains completed full-time result rows with stage, season, source file and SHA-256, HDA prices when the source published all three, and actual over/under line and both prices only when an archived source explicitly supplied them.

## Sources and market handling

The primary result and HDA source is Football-Data.co.uk's `new` league files. Their source records are in `raw/football-data-new/sources.json`; the three CSV bodies are archived beside it. `PSCH/PSCD/PSCA` are retained as Pinnacle closing 1X2 when complete; `B365CH/B365CD/B365CA` are used where available and preferred if the aligned total quote is also Bet365; the Football-Data `AvgCH/AvgCD/AvgCA` average is a disclosed fallback. The source does not contain O/U prices.

Opening O/U quotes come only from matching locally archived ESPN event-summary JSON in `raw/local-summaries/` or retained ESPN event-summary responses in `raw/summaries/`. The extractor uses the source's explicitly displayed `alternateDisplayValue`/`displayValue` as the line and decimal values for over/under. It does not treat `open.total.value` as a line because ESPN payloads use that field for a price in some records. Current/live odds are excluded. The source supplies no quote timestamp, so each market's `market_time_basis` says that explicitly. HDA and O/U use different providers in all 62 aligned records; `paired_market` is false for them, and `market_bookmakers` identifies each source separately.

Football-Data `NOR.csv`/`SWE.csv` classifies some same-code promotion/relegation tie matches with the league. Those results are retained separately as `promotion_relegation_playoff`; regular-season cardinality and team counts exclude them. Their score basis remains explicitly separate because the CSV does not supply a separate extra-time score field. The 2026 rows are partial at the stated cutoff.

## Coverage

`coverage.json` contains row counts by competition and season, expected team and full-season fixture counts, stage-separated playoff rows, each HDA source's availability, totals coverage, and an ESPN score crosscheck. All full years 2018-2025 meet expected regular-season cardinality: 240 NOR, 240 SWE, 380 BRA. At 2026-11-22, the panel has 208 NOR, 224 SWE, and 350 BRA regular matches.

The Football-Data HDA is complete for all 7,684 output rows (including the separate stage rows). Explicit opening O/U lines and both prices are available for 62 rows; 0 rows have HDA and O/U from the same bookmaker. Of 7,603 rows matched to an ESPN scoreboard result by competition, normalized team names, season, and date ±1, 7,601 scores agree; two NOR 2026-05-29 scores remain flagged as disagreements in the panel and coverage. Football-Data's score is retained as the primary row source.

## Reproduction

Run offline from this folder:

```bash
python extract_cached_markets.py
python build_final_panel.py
```

`panel-espn-open-markets.jsonl` is the intermediate ESPN event panel. `raw-manifest.json` records raw URLs, fetch/status data, SHA-256 hashes, local archived summaries, and Football-Data source mappings. No market prices are imputed when missing.
