#!/usr/bin/env python3
"""Re-extract only locally archived ESPN opening markets; performs no network requests."""
import datetime as dt,hashlib,json,pathlib
ROOT=pathlib.Path(__file__).resolve().parent
PANEL=ROOT/'panel-espn-open-markets.jsonl'
def dec(x):
    try:v=float(x.get('decimal'))
    except (AttributeError,TypeError,ValueError):return None
    return v if v>1 else None
def extract(blob):
    try:x=json.loads(blob)
    except Exception:return None
    if not isinstance(x,dict):return None
    hda=total=None;hbook=obook=None
    for o in x.get('odds') or []:
        if not isinstance(o,dict):continue
        provider=(o.get('provider') or {}).get('name')
        ho=(o.get('homeTeamOdds') or {}).get('open') or {};ao=(o.get('awayTeamOdds') or {}).get('open') or {};do=(o.get('drawOdds') or {}).get('open') or {}
        h=dec(ho.get('moneyLine') or {});a=dec(ao.get('moneyLine') or {});d=dec(do.get('moneyLine') or {})
        if not hda and h and d and a:hda={'home':h,'draw':d,'away':a};hbook=provider
        op=o.get('open') or {};line_obj=op.get('total') or {}
        try:line=float(line_obj.get('alternateDisplayValue'))
        except (TypeError,ValueError):
            try:line=float(line_obj.get('displayValue'))
            except (TypeError,ValueError):line=None
        over=dec(op.get('over') or {});under=dec(op.get('under') or {})
        # Keep an explicitly displayed conventional full-match total-line range only;
        # price-valued .value fields and non-line decimals are not relabeled as lines.
        if line is not None and (line<0.5 or line>6.5 or abs(line*4-round(line*4))>1e-8):line=None
        if total is None and line is not None and over and under:total={'line':line,'over':over,'under':under};obook=provider
    if not hda and not total:return None
    return {'h2h':hda,'total':total,'h2h_book':hbook,'total_book':obook,'event_id':str((x.get('header') or {}).get('id') or ''),'competition':((x.get('header') or {}).get('league') or {}).get('slug')}
def main():
    manifest=json.loads((ROOT/'raw-manifest.json').read_text(encoding='utf8'))
    localmeta={x['file']:x for x in manifest.get('local_reused_event_summaries',[])}
    candidates={}
    for folder in [ROOT/'raw/summaries',ROOT/'raw/local-summaries']:
        if not folder.exists():continue
        for path in folder.glob('*.json'):
            b=path.read_bytes();q=extract(b)
            if not q or q['competition'] not in ('nor.1','swe.1','bra.1') or not q['event_id']:continue
            local=folder.name=='local-summaries'; rel='raw/'+folder.name+'/'+path.name
            meta=localmeta.get(rel,{})
            url=meta.get('source_url') or f'https://site.api.espn.com/apis/site/v2/sports/soccer/{q["competition"]}/summary?event={q["event_id"]}'
            obs=meta.get('observed_at_utc')
            rec={**q,'source':{'provider':'WCPP archived ESPN event summary' if local else 'ESPN site API event summary','url':url,'file':rel,'sha256':hashlib.sha256(b).hexdigest()},'observed_at_utc':obs,'local':local}
            prev=candidates.get(q['event_id'])
            quality=lambda z:(int(bool(z['h2h']))+int(bool(z['total'])),int(z['local']),z.get('observed_at_utc') or '')
            if prev and quality(prev)>=quality(rec):continue
            candidates[q['event_id']]=rec
    out=[]
    for line in PANEL.read_text(encoding='utf8').splitlines():
        r=json.loads(line);eid=r['id'].split(':')[-1];q=candidates.get(eid)
        if q and r['competition']==q['competition']:
            r['h2h']=q['h2h'];r['total']=q['total'];books={'h2h':q['h2h_book'],'total':q['total_book']};r['market_bookmakers']=books
            nonnull={v for v in books.values() if v};r['bookmaker']=next(iter(nonnull)) if len(nonnull)==1 else (books if nonnull else None)
            r['market_time_basis']={'h2h':'ESPN event summary explicit opening 1X2 fields; quote timestamp not supplied' if q['h2h'] else None,'total':'ESPN event summary explicit opening O/U line and prices; quote timestamp not supplied' if q['total'] else None}
            r['paired_market']=bool(q['h2h'] and q['total'] and q['h2h_book']==q['total_book'])
            r['sources']=[s for s in r['sources'] if 'summary' not in s.get('provider','').lower()]+[q['source']]
        else:
            r['h2h']=None;r['total']=None;r['bookmaker']=None;r['market_bookmakers']={'h2h':None,'total':None};r['market_time_basis']={'h2h':None,'total':None};r['paired_market']=False
        out.append(r)
    PANEL.write_text(''.join(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n' for r in out),encoding='utf8')
    print('cached event markets',len(candidates),'panel total',sum(bool(r['total']) for r in out),'HDA',sum(bool(r['h2h']) for r in out),'same-book paired',sum(bool(r['paired_market']) for r in out))
if __name__=='__main__':main()
