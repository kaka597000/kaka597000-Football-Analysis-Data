# Asia/America historical match and market panel

Panel coverage is 10,629 completed matches dated 2018-01-01 through 2026-11-22: J1 3,022; K League 1 1,974; A-League 1,388; MLS 4,245. Every row has a source URL and SHA256. Raw ESPN season scoreboards and FotMob K League season responses are retained under `raw/`; repeat normalization with `python scripts/collect_panel.py`. `source_manifest.json` and `coverage.json` index the normalized output.

## Competition phases

- J1 retains ESPN season/stage slug. In 2026 the 100 Year Vision League is `centenary-special` (180 fixtures), the placement playoffs (18) and championship (2) are separately `centenary-special:<provider slug>`, and the new J1 regular-season fixtures from September onward are `season=2026-27, stage=regular` (150). A 2018–2025 J1 promotion/relegation playoff remains separated by its exact slug.
- K League rounds 1–33 are regular phase. The 34–38 phase is split into two six-club groups from the disconnected fixture graph. `split_A` is the higher table group using pre-split points, goal difference, and goals scored; `split_B` is the other group. The 2020 season had no split phase. Per-season clubs and reproducible source hashes are in `k1_split_groups.json`; current Korean short-name to English ID/history crosswalk is `k1_team_identity_map_2026.csv`.
- A-League and MLS post-season stage names preserve the provider's season slug (finals, grand final, conference rounds, and play-ins are distinct).

## Match scores

ESPN scoreboard rows are filtered to completed matches. K League rows use FotMob's finished full-time fixture score; FotMob does not expose 90-minute status detail in these fixture records, so that basis is marked `provider_fulltime_90m_unverified`. For ESPN matches whose provider status indicates AET or penalties, the score is replaced from the event scoring timeline when period 1–2 events are available. Otherwise `score_basis=extra_time_90m_unresolved` remains explicit (78 matches); their displayed goal totals must not be assumed to be 90-minute totals. No additional goals were inferred.

## Odds

- Football-Data.co.uk `new/JPN.csv` and `new/USA.csv` provide same-source, same-bookmaker Pinnacle closing H/D/A for 2,308 J1 and 3,310 MLS rows after strict date/team/90-score reconciliation. Sources, SHA256, CSV line, date offset, and identity similarity are attached to each row. The 939 one-day date offsets are mostly ESPN UTC match dates versus the CSV's local date; date offset and exact team/score match are recorded. Quote timestamps are not certified. Raw CSVs are retained in `raw/`.
- ESPN core summaries were actually queried for recent/held-out events. From 188 retained summary responses, 86 A-League matches (2024-10-18 through 2026-02-06) had complete Bet365 `preMatchFullTimeResultHome/Draw/Away` and `preMatchOverUnderHandicap/GoalLineOver/Under` pairs. Both sides are from the same provider; absolute quote timestamps are absent. Exact summary URL and SHA are in each panel row and `espn_market_evidence.jsonl`. ESPN reports `hasOdds=false` on these responses despite the retained explicit prematch quote fields; the actual raw fields, rather than that flag, were parsed.
- A JPN/MLS Football-Data CSV does not contain over/under fields. No O/U line or prices were imputed. K League historical quote coverage was not found in available local archives at this stage. ESPN 2026-11-21/22 summaries for one recent match in J1, A-League, and MLS returned HTTP 503; failures are recorded in `espn_recent_fetch_failures.json`.
- `h2h` and `total` remain null where a paired source is not available. Raw ESPN summary probes with no usable prematch pair are indexed in `espn_odds_probe_manifest.json`.

Run `python scripts/join_football_data_odds.py`, `python scripts/merge_espn_odds_cache.py`, `python scripts/classify_k1_split.py`, and `python scripts/build_manifest.py` to reproduce the joins and phase classification from retained raw sources. The collector and merge scripts make no model or performance calculations.

## AsianOdds archive snapshots

A separate cross-match against retained WCPP AsianOdds raw snapshots added 10 A-League and 8 K League 1 matches dated 2026-10-31 through 2026-11-01. The captured snapshot time precedes each fixture kickoff; panel values use the snapshot's `markets` current 1X2 and OU sides. The source's `opening` values remain separately in `market_opening`, and `quote_time` remains unknown. Exact event ID, source capture time, raw path, team-match similarity, URL, and uncompressed SHA256 are retained in each row and `asianodds_join_manifest.json`. Raw compressed JSON is copied into `raw/asianodds/`.
