#!/usr/bin/env python3
"""Merge only explicit ESPN preMatch quote fields from retained core summaries."""
import pathlib,json,hashlib,collections
root=pathlib.Path(__file__).resolve().parents[1]
panel_path=root/'panel.jsonl'; rows=[json.loads(x) for x in panel_path.open()]
index={r['id']:r for r in rows}; counts=collections.Counter(); evidence=[]
def dec(x):
 if not isinstance(x,dict) or x.get('value') in (None,''):return None
 s=str(x['value']).strip()
 try:
  if '/' in s:
   a,b=s.split('/',1); return round(1+float(a)/float(b),6)
  return float(s)
 except Exception:return None
for path in sorted((root/'raw'/'espn_odds').glob('*.json')):
 d=json.loads(path.read_text()); name=path.stem; league,event=name.rsplit('_',1); mid=f'espn:{event}'
 r=index.get(mid)
 if not r:continue
 raw=path.read_bytes(); sha=hashlib.sha256(raw).hexdigest(); url=f'https://site.api.espn.com/apis/site/v2/sports/soccer/{league}/summary?event={event}'
 quotes=[]
 for o in d.get('odds') or []:
  bk=(o.get('provider') or {}).get('name'); t=((o.get('bettingOdds') or {}).get('teamOdds') or {})
  h2h={k:dec(t.get(f'preMatchFullTimeResult{v}')) for k,v in [('home','Home'),('draw','Draw'),('away','Away')]}
  total_line=dec(t.get('preMatchOverUnderHandicap')); over=dec(t.get('preMatchGoalLineOver')); under=dec(t.get('preMatchGoalLineUnder'))
  q={}
  if all(v is not None for v in h2h.values()):q['h2h']=h2h
  if total_line is not None and over is not None and under is not None:q['total']={'line':total_line,'over':over,'under':under}
  if q:quotes.append({'bookmaker':bk,**q})
 if not quotes:counts[(league,'no_explicit_prematch_fields')]+=1;continue
 ev={'id':mid,'competition':league,'date':r['date'],'url':url,'sha256':sha,'quotes':quotes};evidence.append(ev)
 tq=next((q for q in quotes if q.get('total')),None)
 hq=next((q for q in quotes if q.get('h2h')),None)
 if hq and r.get('h2h') is None:
  r['h2h']=hq['h2h'];r['bookmaker']=hq['bookmaker'];r['source']='ESPN core prematch';r['market_time_basis']='ESPN preMatchFullTimeResult; absolute quote timestamp unavailable';r['sources'].append({'url':url,'sha256':sha})
 if tq and r.get('total') is None:
  r['total']=tq['total']
  if hq and r.get('bookmaker') and r['bookmaker']!=tq['bookmaker']:
   old=(r['bookmaker'],r['source'],r['market_time_basis'])
   r['bookmaker']={'h2h':old[0],'total':tq['bookmaker']};r['source']={'h2h':old[1],'total':'ESPN core prematch'}
   r['market_time_basis']={'h2h':old[2],'total':'ESPN preMatchGoalLine; absolute quote timestamp unavailable'}
  elif r.get('bookmaker') is None:
   r['bookmaker']=tq['bookmaker'];r['source']='ESPN core prematch';r['market_time_basis']='ESPN preMatchGoalLine; absolute quote timestamp unavailable'
  r['sources'].append({'url':url,'sha256':sha})
 counts[(league,'quoted')]+=1
(root/'espn_market_evidence.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n' for x in evidence))
panel_path.write_text(''.join(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n' for x in rows))
print(dict(counts),'quoted_rows',len(evidence))
