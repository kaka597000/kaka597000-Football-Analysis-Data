#!/usr/bin/env python3
"""Fetch ESPN core summaries for heldout/recent completed games and keep quoted markets only."""
import concurrent.futures,hashlib,json,pathlib,urllib.request,time,re,collections
ROOT=pathlib.Path(__file__).resolve().parents[1]; RAW=ROOT/'raw'/'espn_odds'; RAW.mkdir(parents=True,exist_ok=True)
PANEL=ROOT/'panel.jsonl'; ODDSOUT=ROOT/'espn_market_evidence.jsonl'
LEAGUES={'jpn.1','aus.1','usa.1'}
YEARS={'2025','2026'}

def dec(x):
    if not isinstance(x,dict): return None
    v=x.get('value')
    if v in (None,''):return None
    s=str(v).strip()
    try:
        if '/' in s:
            a,b=s.split('/',1); return round(1+float(a)/float(b),6)
        return float(s)
    except Exception:return None
def fetch(row):
    league=row['competition']; mid=row['id'].split(':',1)[-1]
    url=f'https://site.api.espn.com/apis/site/v2/sports/soccer/{league}/summary?event={mid}'
    p=RAW/f'{league}_{mid}.json'
    if p.exists(): raw=p.read_bytes()
    else:
        req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 WCPP research archive'})
        err=None
        for i in range(3):
            try:
                with urllib.request.urlopen(req,timeout=25) as r: raw=r.read()
                p.write_bytes(raw); break
            except Exception as e:
                err=e
                if i<2: time.sleep(.7*(i+1))
        else:return {'id':row['id'],'status':'fetch_error','error':str(err),'url':url}
    sha=hashlib.sha256(raw).hexdigest()
    try:d=json.loads(raw)
    except Exception:return {'id':row['id'],'status':'bad_json','url':url,'sha256':sha}
    out={'id':row['id'],'competition':league,'season':row['season'],'date':row['date'],'url':url,'sha256':sha,
         'hasOdds':d.get('hasOdds'),'matches':d.get('header',{}).get('competitions',[{}])[0].get('competitors',[])}
    candidates=[]
    for item in d.get('odds') or []:
        prov=(item.get('provider') or {}).get('name')
        t=((item.get('bettingOdds') or {}).get('teamOdds') or {})
        h2h={k:dec(t.get(f'preMatchFullTimeResult{label}')) for k,label in [('home','Home'),('draw','Draw'),('away','Away')]}
        total_line=dec(t.get('preMatchOverUnderHandicap'))
        over=dec(t.get('preMatchGoalLineOver')); under=dec(t.get('preMatchGoalLineUnder'))
        total={'line':total_line,'over':over,'under':under} if total_line is not None and over is not None and under is not None else None
        if all(v is not None for v in h2h.values()) or total:
            candidates.append({'bookmaker':prov,'h2h':h2h if all(v is not None for v in h2h.values()) else None,'total':total})
    out['quotes']=candidates; out['status']='quoted' if candidates else 'no_quote'
    return out

def main():
    panel=[json.loads(x) for x in PANEL.open()]
    targets=[r for r in panel if r['competition'] in LEAGUES and r['season'].split('/')[0] in YEARS
             and r['date'][:4] in YEARS and (r.get('h2h') is None or r.get('total') is None)]
    # Event ids are deduplicated prior to API access.
    uniq={r['id']:r for r in targets}; targets=list(uniq.values())
    print('ESPN summaries requested',len(targets),dict(collections.Counter(r['competition'] for r in targets)))
    result=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
        for n,x in enumerate(pool.map(fetch,targets),1):
            result.append(x)
            if n%100==0: print('progress',n,'/',len(targets))
    # Preserve all collected summary evidence, including no-odds responses.
    ODDSOUT.write_text(''.join(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n' for x in result))
    byid={x['id']:x for x in result}
    for r in panel:
        x=byid.get(r['id'])
        if not x or not x.get('quotes'):continue
        # Use one provider atomically for paired markets. A given market can use
        # a different source, recorded explicitly in bookmaker/source/basis maps.
        q=next((q for q in x['quotes'] if q.get('h2h')),None)
        if q and r.get('h2h') is None:
            r['h2h']=q['h2h']; r['bookmaker']=q['bookmaker']; r['source']='ESPN core prematch market'
            r['market_time_basis']='ESPN prematch odds object; quote timestamp unavailable'
            r['sources'].append({'url':x['url'],'sha256':x['sha256']})
        tq=next((q for q in x['quotes'] if q.get('total')),None)
        if tq:
            if r.get('total') is None:
                r['total']=tq['total']
                old_bk=r.get('bookmaker'); old_source=r.get('source'); old_basis=r.get('market_time_basis')
                if old_bk and old_bk!=tq['bookmaker']:
                    r['bookmaker']={'h2h':old_bk,'total':tq['bookmaker']}; r['source']={'h2h':old_source,'total':'ESPN core prematch market'}
                    r['market_time_basis']={'h2h':old_basis,'total':'ESPN prematch odds object; quote timestamp unavailable'}
                else:
                    r['bookmaker']=tq['bookmaker']; r['source']='ESPN core prematch market'; r['market_time_basis']='ESPN prematch odds object; quote timestamp unavailable'
                r['sources'].append({'url':x['url'],'sha256':x['sha256']})
    PANEL.write_text(''.join(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n' for r in panel))
    print('SUMMARY',dict(collections.Counter(x['status'] for x in result)),'ODDS rows',sum(bool(x.get('quotes')) for x in result))
if __name__=='__main__':main()
