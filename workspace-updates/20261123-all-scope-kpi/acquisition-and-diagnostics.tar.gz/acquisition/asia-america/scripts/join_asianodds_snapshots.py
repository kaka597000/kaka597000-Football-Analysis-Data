#!/usr/bin/env python3
"""Join retained pre-kickoff AsianOdds current/opening quote snapshots to K1/AUS results."""
import json,gzip,pathlib,hashlib,shutil,datetime,unicodedata,re,difflib,collections
ROOT=pathlib.Path(__file__).resolve().parents[1]
R4=pathlib.Path('/workspace/Football-Data-kpi-20261123-r4')
meta_path=R4/'market-snapshots.jsonl'; raw_root=R4/'raw'; dest=ROOT/'raw'/'asianodds'; dest.mkdir(parents=True,exist_ok=True)
panel_path=ROOT/'panel.jsonl'; panel=[json.loads(x) for x in panel_path.open()]
def norm(s):
 s=unicodedata.normalize('NFKD',s or '').encode('ascii','ignore').decode().lower()
 s=re.sub(r'\b(fc|cf|sc|united|city|club)\b',' ',s)
 return re.sub(r'[^a-z0-9]+','',s)
def num(x):
 try:return float(x) if x not in ('',None) else None
 except Exception:return None
def market(v):
 if not isinstance(v,dict):return None
 h=v.get('1x2') or {};o=v.get('ou') or {}
 w={k:num(h.get(k)) for k in ('home','draw','away')}
 h2h=w if all(x is not None and x>1 for x in w.values()) else None
 total=None
 line=num(o.get('line'));over=num(o.get('over'));under=num(o.get('under'))
 if line is not None and over is not None and under is not None and over>1 and under>1:total={'line':line,'over':over,'under':under}
 return {'h2h':h2h,'total':total}
def add_market(row,typ,bookmaker,src,basis,reference):
 old={k:row.get(k) for k in ('bookmaker','source','market_time_basis')}
 row[typ]=src[typ]
 if old['bookmaker'] and old['bookmaker']!=bookmaker:
  if not isinstance(row.get('bookmaker'),dict):
   row['bookmaker']={'h2h':old['bookmaker'],'total':old['bookmaker']}
   row['source']={'h2h':old['source'],'total':old['source']}
   row['market_time_basis']={'h2h':old['market_time_basis'],'total':old['market_time_basis']}
  row['bookmaker'][typ]=bookmaker;row['source'][typ]='AsianOdds event snapshot';row['market_time_basis'][typ]=basis
 else:
  row['bookmaker']=bookmaker;row['source']='AsianOdds event snapshot';row['market_time_basis']=basis
 row['sources'].append(reference)

snapshots=[]
for l in meta_path.open():
 try:m=json.loads(l)
 except:continue
 ref=m.get('raw_reference') or {}
 if not ref.get('sha256') or 'asianodds.org' not in ref.get('source_url',''):continue
 p=raw_root/(ref['sha256']+'.json.gz')
 if not p.exists():continue
 compressed=p.read_bytes(); raw=gzip.decompress(compressed)
 digest=hashlib.sha256(raw).hexdigest()
 if digest!=ref['sha256']:continue
 captured=m.get('captured_at')
 try:captured_dt=datetime.datetime.fromisoformat(captured.replace('Z','+00:00'))
 except Exception:continue
 try:d=json.loads(raw)
 except:continue
 snapshots.append((captured_dt,m,d,p,raw,compressed))
snapshots.sort(key=lambda x:x[0])

# Event choices must be captured before kickoff. Keep the latest valid snapshot.
event_sources={}
for captured,m,d,p,raw,compressed in snapshots:
 for ev in d.get('events',[]):
  comp=(ev.get('competition_name') or '').lower()
  if 'k league 1' in comp or comp in ('k-league 1','korea k league 1'):league='kor.1'
  elif 'a-league' in comp and ('australia' in comp or 'men' in comp):league='aus.1'
  else:continue
  try:kick=datetime.datetime.fromisoformat(ev['start_ts'].replace('Z','+00:00'))
  except Exception:continue
  if captured>=kick:continue
  h=norm(ev.get('home'));a=norm(ev.get('away'))
  candidates=[]
  for r in panel:
   if r['competition']!=league or r['date']!=ev['start_ts'][:10]:continue
   hs=difflib.SequenceMatcher(None,h,norm(r['home'])).ratio();as_=difflib.SequenceMatcher(None,a,norm(r['away'])).ratio()
   if min(hs,as_)>=.67 and (hs+as_)/2>=.76:candidates.append(((hs+as_)/2,r,hs,as_))
  candidates.sort(key=lambda x:x[0],reverse=True)
  if not candidates or len(candidates)>1 and candidates[0][0]-candidates[1][0]<.04:continue
  _,r,hs,as_=candidates[0]
  # Captured before kickoff: the source's current prices are a documented prematch snapshot.
  key=r['id']
  current=market(ev.get('markets')); opening=market(ev.get('opening'))
  if not current or not any(current.values()):continue
  old=event_sources.get(key)
  if old and old['captured_at']>=captured.isoformat():continue
  event_sources[key]={'row':r,'event':ev,'league':league,'captured_at':captured.isoformat(),'metadata':m,
    'source':p,'raw':raw,'compressed':compressed,'sha':hashlib.sha256(raw).hexdigest(),
    'current':current,'opening':opening,'similarity':round((hs+as_)/2,4),'kickoff':kick.isoformat()}

joined=collections.Counter()
for key,x in event_sources.items():
 r=x['row'];m=x['metadata'];ev=x['event'];league=x['league']
 compressed=x['compressed'];sha=x['sha'];rawfile=dest/f"{sha}.json.gz"
 if not rawfile.exists():rawfile.write_bytes(compressed)
 basis=f"AsianOdds current snapshot captured_at={x['captured_at']} before kickoff={x['kickoff']}; quote_time=UNKNOWN_NOT_CAPTURE_TIME"
 ref={'url':m['raw_reference']['source_url'],'sha256':sha,'captured_at':x['captured_at'],'quote_time':None,
      'raw_path':str(rawfile.relative_to(ROOT)),'event_id':ev.get('event_id'),'event_competition':ev.get('competition_name'),
      'identity_name_similarity':x['similarity']}
 for typ in ('h2h','total'):
  if x['current'].get(typ) and not r.get(typ):add_market(r,typ,m.get('bookmaker') or 'BetInAsia via AsianOdds',x['current'],basis,ref)
 # Keep source opening prices alongside current snapshot without mixing them into current panel fields.
 if x['opening'] and any(x['opening'].values()):
  r.setdefault('market_opening',{})
  for typ in ('h2h','total'):
   if x['opening'].get(typ):r['market_opening'][typ]={'bookmaker':m.get('bookmaker') or 'BetInAsia via AsianOdds','source':'AsianOdds event snapshot','market_time_basis':'site-designated opening quote; absolute quote time unavailable','price':x['opening'][typ]}
 joined[league]+=1
panel_path.write_text(''.join(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n' for x in panel))
manifest={'snapshots_with_matched_events':len(event_sources),'matches_by_league':dict(joined),
 'matched_events':[{'id':k,'date':x['row']['date'],'competition':x['league'],'home':x['row']['home'],'away':x['row']['away'],
   'captured_at':x['captured_at'],'kickoff':x['kickoff'],'sha256':x['sha'],'similarity':x['similarity'],'event_id':x['event'].get('event_id')}
  for k,x in event_sources.items()]}
(ROOT/'asianodds_join_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(dict(joined),len(event_sources))
