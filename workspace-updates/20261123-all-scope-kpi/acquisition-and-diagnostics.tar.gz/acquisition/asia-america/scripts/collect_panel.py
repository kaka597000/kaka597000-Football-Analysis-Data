#!/usr/bin/env python3
"""Fetch season result sources and normalize into a provenance-carrying panel.

Keeps public ESPN scoreboard and FotMob league responses byte-for-byte in raw/.
Odds are intentionally left null unless a same-match, same-source quoted pair is
available; this collector does not infer prices from scores.
"""
import hashlib, json, pathlib, urllib.request, urllib.error, time

ROOT = pathlib.Path(__file__).resolve().parents[1]
RAW = ROOT / "raw"
OUT = ROOT / "panel.jsonl"
RAW.mkdir(exist_ok=True)

def get(url, fname):
    p=RAW/fname
    if p.exists(): b=p.read_bytes()
    else:
        req=urllib.request.Request(url,headers={"User-Agent":"Mozilla/5.0 WCPP research archive"})
        err=None
        for attempt in range(4):
            try:
                with urllib.request.urlopen(req,timeout=45) as r: b=r.read()
                break
            except Exception as e:
                err=e
                if attempt==3: raise
                time.sleep(1+attempt*2)
        p.write_bytes(b)
    return json.loads(b), hashlib.sha256(b).hexdigest()

def espn(league, yr):
    url=f"https://site.api.espn.com/apis/site/v2/sports/soccer/{league}/scoreboard?dates={yr}&limit=1000"
    try: d,h=get(url,f"espn_{league}_{yr}.json")
    except Exception as e:
        print("ESPN_FAIL",league,yr,str(e)); return []
    rows=[]
    for ev in d.get("events",[]):
        comp=(ev.get("competitions") or [{}])[0]
        season=ev.get("season") or {}
        s_type=season.get("type") or {}
        if not isinstance(s_type,dict): s_type={}
        slug=(season.get("slug") or "").lower()
        typ=(s_type.get("name") or s_type.get("abbreviation") or "").lower()
        status=(ev.get("status") or {}).get("type") or {}
        if status.get("state") != "post": continue
        teams=comp.get("competitors") or []
        home=next((t for t in teams if t.get("homeAway")=="home"),None)
        away=next((t for t in teams if t.get("homeAway")=="away"),None)
        if not home or not away: continue
        try: hg=int(home["score"]); ag=int(away["score"])
        except (KeyError,ValueError,TypeError): continue
        day=(ev.get("date") or "")[:10]
        if not day: continue
        phase="regular"
        low=(slug+" "+typ+" "+(ev.get("name") or "")).lower()
        if any(k in low for k in ("playoff","postseason","final","knockout")):
            phase="playoffs:"+(slug or typ or "round_unknown")
        if league=="jpn.1" and yr==2026:
            # Keep the 100-year special competition distinct from normal J1.
            if "100-year-vision" in slug or "centenary" in low:
                phase="centenary-special"
            elif slug in ("placement-playoffs","championship"):
                phase="centenary-special:"+slug
            elif slug=="regular-season":
                phase="regular"
        # Season is from competition metadata, which differs from calendar year for AUS.
        season_name=str(season.get("year") or yr)
        if league=="aus.1" and season_name.isdigit(): season_name=f"{season_name}/{int(season_name)+1}"
        if league=="jpn.1" and yr==2026 and slug=="regular-season": season_name="2026-27"
        neutral=comp.get("venue",{}).get("neutral")
        # ESPN scoreboard scores can contain extra-time results. Mark ET candidates
        # explicitly for later 90-minute correction from event summary.
        clock=((ev.get("status") or {}).get("clock") or 0)
        period=((ev.get("status") or {}).get("period") or 0)
        basis="regulation_90" if clock<=5500 and period<=2 else "review_extra_time_90m"
        sources=[{"url":url,"sha256":h}]
        detail=(status.get("detail") or status.get("shortDetail") or "").lower()
        if clock>5500 or period>2 or "aet" in detail or "pens" in detail or "pen" in detail:
            su=f"https://site.api.espn.com/apis/site/v2/sports/soccer/{league}/summary?event={ev.get('id')}"
            try:
                sd,sh=get(su,f"espn_summary_{league}_{ev.get('id')}.json")
                sources.append({"url":su,"sha256":sh})
                # Goal timeline is the only basis used to replace scoreboard totals
                # for extra-time games. Include regulation periods only, excluding shootouts.
                ids={str(home.get("team",{}).get("id")):"home",str(away.get("team",{}).get("id")):"away"}
                g={"home":0,"away":0}; seen=False
                for ke in sd.get("keyEvents",[]):
                    if not ke.get("scoringPlay") or ke.get("shootout"): continue
                    pn=(ke.get("period") or {}).get("number")
                    if pn not in (1,2): continue
                    tid=str((ke.get("team") or {}).get("id"))
                    side=ids.get(tid)
                    if not side: continue
                    if ke.get("ownGoal"):
                        side="away" if side=="home" else "home"
                    g[side]+=1; seen=True
                if seen:
                    hg,ag=g["home"],g["away"]
                    basis="regulation_90_from_scoring_timeline"
                else:
                    basis="extra_time_90m_unresolved"
            except Exception as e:
                basis="extra_time_90m_unresolved"
        rows.append({
          "id":f"espn:{ev.get('id')}","competition":league,"stage":phase,"season":season_name,"date":day,
          "home":home.get("team",{}).get("displayName"),"away":away.get("team",{}).get("displayName"),
          "home_goals":hg,"away_goals":ag,"neutral":neutral if isinstance(neutral,bool) else None,
          "sources":sources,"h2h":None,"total":None,"bookmaker":None,
          "source":None,"market_time_basis":None,"score_basis":basis,"provider_stage_slug":slug,
          "provider_status":status.get("detail") or status.get("shortDetail")})
    print("ESPN",league,yr,len(rows),"sha",h)
    return rows

def fotmob(yr):
    url=f"https://www.fotmob.com/api/data/leagues?id=9080&ccode3=KOR&season={yr}"
    try: d,h=get(url,f"fotmob_kor1_{yr}.json")
    except Exception as e:
        print("FOTMOB_FAIL",yr,str(e)); return []
    rows=[]
    for ev in d.get("fixtures",{}).get("allMatches",[]):
        st=ev.get("status") or {}
        if not st.get("finished") or st.get("cancelled"): continue
        score=st.get("scoreStr") or ""
        # Accept only a conventional full-time score token; ET/pens are not silently mixed.
        import re
        m=re.fullmatch(r"\s*(\d+)\s*[-–:]\s*(\d+)\s*",score)
        if not m: continue
        date=(st.get("utcTime") or "")[:10]
        if not date: continue
        rnd=ev.get("roundName") or ev.get("round")
        try: rn=int(rnd)
        except (TypeError,ValueError): rn=None
        # K League 1 split begins after 33 match rounds; preserve group labels.
        stage="regular" if rn is None or rn<=33 else ("split_final" if rn<=38 else "split_unknown")
        rows.append({
          "id":f"fotmob:{ev.get('id')}","competition":"kor.1","stage":stage,"season":str(yr),"date":date,
          "home":(ev.get("home") or {}).get("name"),"away":(ev.get("away") or {}).get("name"),
          "home_goals":int(m.group(1)),"away_goals":int(m.group(2)),"neutral":None,
          "sources":[{"url":url,"sha256":h}],"h2h":None,"total":None,"bookmaker":None,
          "source":None,"market_time_basis":None,"score_basis":"provider_fulltime_90m_unverified",
          "provider_round":rnd,"provider_round_name":ev.get("roundName"),"provider_status":st.get("reason",{}).get("short")})
    print("FOTMOB",yr,len(rows),"sha",h)
    return rows

def main():
    rows=[]
    # Calendar-year queries are retained separately; season metadata keeps league seasons distinct.
    for y in range(2018,2027):
        for lg in ("jpn.1","aus.1","usa.1"):
            rows.extend(espn(lg,y))
        rows.extend(fotmob(y))
    # Keep the source's newest updates only through the requested cutoff.
    rows=[r for r in rows if "2018-01-01" <= r["date"] <= "2026-11-22"]
    unique={}
    for r in rows: unique.setdefault(r["id"],r)
    rows=sorted(unique.values(),key=lambda r:(r["competition"],r["date"],r["id"]))
    OUT.write_text("".join(json.dumps(r,ensure_ascii=False,separators=(",",":"))+"\n" for r in rows))
    from collections import Counter
    print("PANEL",len(rows),dict(Counter(x['competition'] for x in rows)),"OUT",OUT)
if __name__=="__main__": main()
