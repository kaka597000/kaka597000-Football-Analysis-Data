#!/usr/bin/env python3
import collections,hashlib,json,pathlib
root=pathlib.Path(__file__).resolve().parents[1]
rows=[json.loads(x) for x in (root/'panel.jsonl').open()]
sources={}
for x in rows:
    for s in x.get('sources') or []:
        sources[(s['url'],s['sha256'])]=s
(root/'source_manifest.json').write_text(json.dumps([{'url':u,'sha256':h} for u,h in sorted(sources)],indent=2,ensure_ascii=False)+'\n')
stats={}
for comp in sorted({r['competition'] for r in rows}):
    sub=[r for r in rows if r['competition']==comp]
    stats[comp]={'matches':len(sub),'seasons':dict(sorted(collections.Counter(r['season'] for r in sub).items())),
      'stages':dict(sorted(collections.Counter(r['stage'] for r in sub).items())),
      'score_basis':dict(sorted(collections.Counter(r['score_basis'] for r in sub).items())),
      'h2h_present':sum(r['h2h'] is not None for r in sub),'total_present':sum(r['total'] is not None for r in sub)}
summary={'date_cutoff':'2018-01-01 through 2026-11-22 inclusive','rows':len(rows),'competitions':stats,'distinct_sources':len(sources)}
(root/'coverage.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(summary,ensure_ascii=False))
