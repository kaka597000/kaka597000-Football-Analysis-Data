#!/usr/bin/env python3
"""Join public Football-Data JPN/USA closing 1X2 on strict team/date/score identity."""
import csv,json,hashlib,pathlib,re,shutil,unicodedata,collections,difflib
ROOT=pathlib.Path(__file__).resolve().parents[1]
PANEL=ROOT/'panel.jsonl'
SRCROOT=pathlib.Path('/workspace/WCPP/reports/kpi-optimization-20261123/data/extra-raw')
DEST=ROOT/'raw'; DEST.mkdir(exist_ok=True)
META={'JPN':('https://www.football-data.co.uk/new/JPN.csv','fde887273c6c64bf238624ae4510359744534b95024efa74cfa1742f6881d7b7'),
      'USA':('https://www.football-data.co.uk/new/USA.csv','69f630281c59f391bca3f9a05b552fd20d0c4b79e2c09c78e7170583526ca0ff')}

def norm(s):
    s=unicodedata.normalize('NFKD',s or '').encode('ascii','ignore').decode().lower()
    s=re.sub(r'\b(fc|cf|sc|afc|club)\b',' ',s)
    return re.sub(r'[^a-z0-9]+','',s)
def num(x):
    try: return float(x) if x not in ('',None,'NA','N/A') else None
    except ValueError:return None
def odds(row):
    for prefix,bk in [('PS','Pinnacle'),('B365','Bet365'),('Avg','Football-Data average closing')]:
        # Football-Data's C suffix marks its closing field family.
        vals=[num(row.get(prefix+'C'+x)) for x in ('H','D','A')]
        if all(v is not None and v>1 for v in vals):return bk,dict(zip(('home','draw','away'),vals))
    return None,None

panel=[json.loads(x) for x in PANEL.open()]
for p in panel:
    if any(s.get('url','').startswith('https://www.football-data.co.uk/new/') for s in p.get('sources',[])):
        p['sources']=[s for s in p['sources'] if not s.get('url','').startswith('https://www.football-data.co.uk/new/')]
        p['h2h']=None; p['bookmaker']=None; p['source']=None; p['market_time_basis']=None
for code,comp in [('JPN','jpn.1'),('USA','usa.1')]:
    src=SRCROOT/f'{code}.csv'; copy=DEST/src.name; shutil.copyfile(src,copy)
    digest=hashlib.sha256(copy.read_bytes()).hexdigest(); url,expected=META[code]
    if digest!=expected: raise SystemExit(f'CSV hash mismatch {code}: {digest} != {expected}')
    recs=[]
    with src.open(encoding='utf-8-sig',newline='') as f:
        for i,r in enumerate(csv.DictReader(f),2):
            date=r.get('Date','')
            try:
                # Football-Data new datasets use UK day/month/year notation.
                d,m,y=date.split('/'); date=f'{int(y):04d}-{int(m):02d}-{int(d):02d}'
            except Exception: continue
            if not '2018-01-01'<=date<='2026-11-22':continue
            if not r.get('HG','').isdigit() or not r.get('AG','').isdigit():continue
            bk,h2h=odds(r)
            recs.append({'date':date,'home':r.get('Home',''),'away':r.get('Away',''),'hg':int(r['HG']),'ag':int(r['AG']),
              'bk':bk,'h2h':h2h,'line':i,'raw':r})
    # Candidate lookup by date to avoid a cross-competition or cross-season fuzzy match.
    bydate=collections.defaultdict(list)
    for r in recs: bydate[r['date']].append(r)
    matched=0; ambiguity=0; conflicts=0; unmatched=0
    for p in panel:
        if p['competition']!=comp or not (p['h2h'] is None):continue
        choices=[]
        for delta in (0,-1,1):
            import datetime
            day=(datetime.date.fromisoformat(p['date'])+datetime.timedelta(days=delta)).isoformat()
            for r in bydate.get(day,[]):
                hs=difflib.SequenceMatcher(None,norm(p['home']),norm(r['home'])).ratio()
                aw=difflib.SequenceMatcher(None,norm(p['away']),norm(r['away'])).ratio()
                # Require exact scores and strong name match to prevent false odds attachment.
                score=(hs+aw)/2
                if (p['home_goals'],p['away_goals'])==(r['hg'],r['ag']) and min(hs,aw)>=.68 and score>=.77:
                    choices.append((score,r,hs,aw,delta))
            if choices: break
        choices.sort(key=lambda z:z[0],reverse=True)
        if not choices: unmatched+=1; continue
        top=choices[0]
        if len(choices)>1 and top[0]-choices[1][0]<.04: ambiguity+=1; continue
        _,r,hs,aw,delta=top
        # Attach local source and correct unique record ID only if all three prices exist.
        if not r['h2h']:continue
        p['h2h']=r['h2h']; p['bookmaker']=r['bk']; p['source']='Football-Data.co.uk new CSV';
        p['market_time_basis']='closing fields (C suffix; no quote timestamp certification)'
        p['sources'].append({'url':url,'sha256':digest,'source_line':r['line'],'match_date_offset_days':delta,
          'identity_name_similarity':round((hs+aw)/2,4)})
        matched+=1
    print(code,'CSV rows',len(recs),'joined',matched,'ambiguous',ambiguity,'unmatched',unmatched)
PANEL.write_text(''.join(json.dumps(p,ensure_ascii=False,separators=(',',':'))+'\n' for p in panel))
