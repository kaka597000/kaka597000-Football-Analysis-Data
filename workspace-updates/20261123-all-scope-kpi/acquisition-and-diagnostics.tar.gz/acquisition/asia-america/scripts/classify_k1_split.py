#!/usr/bin/env python3
"""Derive split A/B groups from season fixture graph and first-33 match table."""
import json,pathlib,collections
root=pathlib.Path(__file__).resolve().parents[1]
panel_path=root/'panel.jsonl'; panel=[json.loads(x) for x in panel_path.open()]
assign={}
diagnostics={}
for year in range(2018,2027):
    raw_path=root/'raw'/f'fotmob_kor1_{year}.json'
    d=json.load(raw_path.open())
    import hashlib
    source={'url':f'https://www.fotmob.com/api/data/leagues?id=9080&ccode3=KOR&season={year}',
            'sha256':hashlib.sha256(raw_path.read_bytes()).hexdigest()}
    edges=collections.defaultdict(set); teams=set(); points=collections.Counter(); gd=collections.Counter(); gf=collections.Counter()
    matches=d.get('fixtures',{}).get('allMatches',[])
    for m in matches:
        h=m.get('home',{}).get('name'); a=m.get('away',{}).get('name')
        if not h or not a: continue
        teams.update((h,a))
        try:rnd=int(m.get('round') or 0)
        except (TypeError,ValueError): continue
        try: hg,ag=map(int,(m.get('status',{}).get('scoreStr') or '').split('-'))
        except Exception: continue
        if rnd<=33:
            gf[h]+=hg;gf[a]+=ag;gd[h]+=hg-ag;gd[a]+=ag-hg
            if hg>ag:points[h]+=3
            elif ag>hg:points[a]+=3
            else:points[h]+=1;points[a]+=1
        elif rnd>=34:
            edges[h].add(a);edges[a].add(h)
    comps=[]; seen=set()
    for t in sorted(teams):
        if t in seen: continue
        stack=[t]; group=set()
        while stack:
            x=stack.pop()
            if x in group:continue
            group.add(x); stack.extend(edges[x]-group)
        seen|=group; comps.append(group)
    viable=[c for c in comps if len(c)>1]
    if len(viable)==2 and all(len(c)==6 for c in viable):
        viable.sort(key=lambda c:(sum(points[t] for t in c),sum(gd[t] for t in c),sum(gf[t] for t in c)),reverse=True)
        for label,c in zip(('split_A','split_B'),viable):
            for team in c:assign[(str(year),team)]=label
        diagnostics[str(year)]={'split_A':sorted(viable[0]),'split_B':sorted(viable[1]),'matchdays':38,
          'basis':'rounds 34-38 fixture graph; group A ranked by aggregate pre-split points/GD/GF from rounds 1-33',
          'source':source}
    else:
        diagnostics[str(year)]={'stage':'no_split_group_assignment','rounds_observed':sorted({int(m.get('round') or 0) for m in matches if str(m.get('round','')).isdigit()}),
          'fixture_component_sizes':sorted(len(c) for c in comps),'source':source}
    # Provider round/source team names are from cached original API response.
    for m in matches:
        key=(str(year),m.get('id'))
        h=m.get('home',{}).get('name'); a=m.get('away',{}).get('name')
        try:rnd=int(m.get('round') or 0)
        except (TypeError,ValueError):rnd=0
        if rnd>=34 and h and a and (str(year),h) in assign and assign.get((str(year),h))==assign.get((str(year),a)):
            assign[key]=assign[(str(year),h)]
for row in panel:
    if row.get('competition')=='jpn.1' and row.get('season')=='2026':
        slug=row.get('provider_stage_slug')
        if slug=='2026-j1-100-year-vision-league':row['stage']='centenary-special'
        elif slug in ('placement-playoffs','championship'):row['stage']='centenary-special:'+slug
        elif slug=='regular-season':row['stage']='regular';row['season']='2026-27'
        continue
    if row.get('competition')!='kor.1':continue
    stage=row.get('provider_round')
    try:rnd=int(stage)
    except (ValueError,TypeError):continue
    if rnd>=34:
        # Stable FotMob match ID -> split group from its six-team fixture component.
        group=next((v for (y,k),v in assign.items() if k==row['id'].split(':',1)[-1] and y==row['season']),None)
        if group:row['stage']=group
    elif rnd>0:
        row['stage']='regular'
(root/'k1_split_groups.json').write_text(json.dumps(diagnostics,ensure_ascii=False,indent=2)+'\n')
panel_path.write_text(''.join(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n' for x in panel))
print({y:(len(v.get('split_A',[])),len(v.get('split_B',[])),v.get('stage')) for y,v in diagnostics.items()})
