#!/usr/bin/env python3
"""Collect ESPN public scoreboard/summary evidence for specified cup tournaments.
Network snapshots and HTTP metadata are saved in raw/online. No market values inferred.
"""
import json, urllib.request, urllib.error, hashlib, pathlib, datetime, re, time
ROOT=pathlib.Path('/workspace/WCPP'); OUT=ROOT/'reports/kpi-optimization-20261123-r5/special-cups'; RAW=OUT/'raw/online'; RAW.mkdir(parents=True,exist_ok=True)
BASE='https://site.api.espn.com/apis/site/v2/sports/soccer/'
JOBS={
 'fifa.world':[2018,2022,2026],
 'uefa.nations':[2022,2023,2024,2025,2026],
 'afc.champions':[2024,2025,2026],
 'jpn.league_cup':[2022,2023,2024,2025,2026],
}
def fetch(url,path):
 req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0','Accept':'application/json'})
 try:
  with urllib.request.urlopen(req,timeout=45) as r: body=r.read(); status=r.status; headers=dict(r.headers)
 except urllib.error.HTTPError as e: body=e.read();status=e.code;headers=dict(e.headers)
 path.write_bytes(body); meta={'url':url,'retrieved_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'http_status':status,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest(),'content_type':headers.get('Content-Type'),'path':str(path.relative_to(OUT))}
 path.with_suffix(path.suffix+'.meta.json').write_text(json.dumps(meta,indent=2)+'\n')
 if status!=200: return None,meta
 try:return json.loads(body),meta
 except Exception:return None,meta
def stage_for(comp,event,competition):
 note=competition.get('altGameNote') or ''; slug=event.get('season',{}).get('slug','')
 txt=(note+' '+slug).lower()
 if 'group' in txt: return 'group-stage'
 for pat,label in [(r'round of 32','round-of-32'),(r'round of 16','round-of-16'),(r'quarter.?final','quarterfinals'),(r'semi.?final','semifinals'),(r'third.place|3rd.place','3rd-place-match'),(r'final','final'),(r'league phase','league_phase'),(r'league stage','league_phase'),(r'round of 16','round_of_16'),(r'round of 8|quarterfinal','quarterfinals'),(r'round of 4|semi.?final','semifinals')]:
  if re.search(pat,txt): return label
 return 'stage-unresolved'
def event_score(comp,event,evurl):
 c=event.get('competitions',[{}])[0]; status=c.get('status',event.get('status',{})); typ=status.get('type',{}).get('name','')
 if not status.get('type',{}).get('completed'):return None
 teams=c.get('competitors',[])
 if len(teams)!=2:return None
 # ESPN scoreboard result is regulation for FT; AET/PEN totals are not regulation, so fetch period details.
 if any(z in typ for z in ('AET','PEN')):
  eid=event.get('id'); su=BASE+comp+'/summary?event='+eid; sx,meta=fetch(su,RAW/(comp+'-'+eid+'-summary.json'))
  if not sx:return None
  hc=sx.get('header',{}).get('competitions',[{}])[0].get('competitors',[])
  if len(hc)!=2:return None
  vals=[]
  for z in hc:
   ls=z.get('linescores',[])
   if len(ls)<2:return None
   vals.append(sum(int(q.get('displayValue','0')) for q in ls[:2] if str(q.get('displayValue','0')).isdigit()))
  hs,as_=vals
  src2={'url':su,'sha256':meta['sha256']}
 else:
  by={z.get('homeAway'):int(z['score']) for z in teams if str(z.get('score','')).isdigit()}
  if 'home' not in by or 'away' not in by:return None
  hs,as_=by['home'],by['away'];src2=None
 by={z.get('homeAway'):z for z in teams}
 h=by['home']['team'].get('displayName');a=by['away']['team'].get('displayName')
 season=str(event.get('season',{}).get('year') or event.get('date','')[:4]);date=event.get('date','')[:10]
 src=[{'url':evurl,'sha256':None}]
 if src2:src.append(src2)
 return {'id':comp+':'+event['id'],'competition':comp,'stage':stage_for(comp,event,c),'season':season,'date':date,'home':h,'away':a,'home_goals':hs,'away_goals':as_,'neutral':bool(c.get('neutralSite',False)),'sources':src,'h2h':None,'total':None,'bookmaker':None,'market_time_basis':None,'paired_market':False}
rows=[]; summary=[]
for comp,years in JOBS.items():
 for y in years:
  url=BASE+comp+'/scoreboard?dates='+str(y)+'&limit=1000'; data,meta=fetch(url,RAW/(comp+'-'+str(y)+'-scoreboard.json')); summary.append(meta)
  if not data:continue
  evs=data.get('events',[]); print(comp,y,meta['http_status'],len(evs),flush=True)
  for ev in evs:
   row=event_score(comp,ev,url)
   if row: row['sources'][0]['sha256']=meta['sha256']; rows.append(row)
  time.sleep(.15)
# Merge by full provider event ID; network rows replace score/stage for same event.
panel=OUT/'panel.jsonl'; existing={}
for line in panel.read_text().splitlines():
 x=json.loads(line); existing[x['competition']+':'+str(x['id']).split(':')[-1]]=x
for x in rows:existing[x['id']]=x
panel.write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in sorted(existing.values(),key=lambda z:(z['competition'],z['date'],z['id']))))
(OUT/'online-coverage.json').write_text(json.dumps({'requests':summary,'online_rows':len(rows),'merged_rows':len(existing),'years_requested':JOBS},indent=2)+'\n')
print('online rows',len(rows),'merged',len(existing))
