# International and cup score panels

`panel.jsonl` combines recovered local data with live ESPN scoreboard responses. `raw/` contains the source exports and HTTP request metadata; `raw-manifest.json` hashes every retained file. `index.json` reports event, season, stage and split coverage, plus failed request statuses. Rebuild the panel with `python .../rebuild.py`, then refresh manifests and coverage with `python .../build_index.py`. The separate `collect_online.py` reproduces the live ESPN retrieval attempts and records both successful and failed responses.

## FIFA World Cup

The three requested editions are now complete: 2018 training (64), 2022 validation (64), and 2026 holdout (104). Stage counts match each edition's full schedule in `index.json`. ESPN scoreboard event details provide goal events with match minutes. The collector counts goals through the end of minute 90, including stoppage time, and excludes extra-time goals and penalty shootout kicks. This recovers 90-minute scores for the AET/PEN matches while keeping all 64/104 match IDs. For standard full-time matches the goal-event totals agree with the scoreboard result. The 2022 scoreboard is an archived successful HTTP 200 ESPN response; the 2018 and 2026 scoreboard captures were fetched during this task.

## Other competitions

UEFA Nations League has 807 regulation-score rows across season editions 2018, 2020, 2022, 2024 and 2026. Stage names retain level and phase, and group number where present. The 2026/27 archive reaches 2026-11-17, within the requested 2026-11-22 cutoff.

AFC Champions has 279 rows: 30 legacy-format knockout matches in 2023/24, 112 scored 2024/25 matches, 115 scored 2025/26 matches, and 22 scored 2026/27 opening league-phase matches. The 2024/25 season has 89 scored league-phase fixtures and 23 scored knockout matches; seven canceled group fixtures are listed in `excluded-rows.json`. The 2025/26 season has 96 scored league-phase fixtures and 19 scored knockout matches; four postponed Round-of-16 fixtures are listed separately. The 2026/27 rows are through the 2026-10-13 ESPN capture. East and West region labels are retained when the source supplied them; rows without a region note remain `region_unresolved`. Legacy-format rounds remain distinct from ELITE league-phase records.

J League Cup has 237 verified 90-minute scores: 21 2022 knockout records, 212 2023-2025 records, and four official 2026/27 quarterfinal first-leg results on 2026-11-11. Each row carries a retained export hash and the exact raw source-page hash. The second-leg fixtures on 2026-11-15 exist in a pre-match page capture, but no scored post-match result was recovered, so they are excluded. ESPN returned HTTP 400/503 during live retrieval attempts.

## Markets and completeness

Inspected ESPN scoreboard responses had null odds arrays. No paired, same-match HDA or totals prices and lines were recovered. Market fields remain null throughout; no line or odds were estimated. Failed ESPN and GitHub requests, including their HTTP status and response hashes, are retained in `raw/online/` and `index.json`.
