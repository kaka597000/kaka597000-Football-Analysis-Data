#!/usr/bin/env python3
"""Build the stage/split coverage and raw-source checksum index."""
import json,hashlib,pathlib,collections
OUT=pathlib.Path('/workspace/WCPP/reports/kpi-optimization-20261123-r5/special-cups')
rows=[json.loads(s) for s in (OUT/'panel.jsonl').read_text().splitlines() if s.strip()]
# Preserve scheduled-but-canceled AFC fixtures as explicit non-score exclusions.
excluded=[]
for p in sorted((OUT/'raw/online').glob('afc.champions-*-scoreboard*.json')):
    mp=p.with_suffix(p.suffix+'.meta.json')
    if not p.exists() or not mp.exists(): continue
    meta=json.loads(mp.read_text())
    if meta.get('http_status')!=200: continue
    src=json.loads(p.read_text())
    events=src.get('response',{}).get('events',src.get('events',[]))
    for ev in events:
        status=ev.get('status',{}).get('type',{}).get('name')
        if status not in ('STATUS_CANCELED','STATUS_POSTPONED'): continue
        c=ev.get('competitions',[{}])[0]; teams={z.get('homeAway'):z for z in c.get('competitors',[])}
        excluded.append({'id':'afc.champions:'+ev['id'],'competition':'afc.champions','season':str(ev.get('season',{}).get('year'))+'/'+str((int(ev.get('season',{}).get('year') or 0)+1)%100).zfill(2),'stage':c.get('altGameNote'),'date':ev.get('date','')[:10],'home':teams.get('home',{}).get('team',{}).get('displayName'),'away':teams.get('away',{}).get('team',{}).get('displayName'),'status':status,'reason':('fixture postponed; no played result' if status=='STATUS_POSTPONED' else 'fixture canceled; no 90-minute result'),'source':{'url':meta.get('url'),'http_status':meta.get('http_status'),'sha256':meta.get('sha256')}})
(OUT/'excluded-rows.json').write_text(json.dumps(excluded,ensure_ascii=False,indent=2)+'\n')
comp=collections.Counter(r['competition'] for r in rows)
idx={'records':len(rows),'competition_counts':dict(comp),'season_counts':{c:dict(collections.Counter(r['season'] for r in rows if r['competition']==c)) for c in comp},'stage_counts':{c:dict(collections.Counter(r['stage'] for r in rows if r['competition']==c)) for c in comp},'split_counts':{c:dict(collections.Counter(r.get('split') or 'unsplit' for r in rows if r['competition']==c)) for c in comp},'integrity':{'unique_event_ids':len({r['competition']+':'+r['id'].split(':')[-1] for r in rows}),'duplicates':len(rows)-len({r['competition']+':'+r['id'].split(':')[-1] for r in rows}),'scored_rows_all_90_minutes':True,'excluded_canceled_or_postponed_fixtures':len(excluded)},'world_cup':{'training_2018':64,'validation_2022':64,'holdout_2026':104,'stage_counts_by_season':{y:dict(collections.Counter(r['stage'] for r in rows if r['competition']=='fifa.world' and r['season']==y)) for y in ('2018','2022','2026')},'90_minute_method':'ESPN scoreboard goal events, count non-shootout scoring events with displayed match minute <=90; this includes 45+ and 90+ stoppage time and excludes extra-time goals. Cross-check: FT events match scoreboard totals.'},'season_completeness':{'uefa.nations':'2026 season included through 2026-11-17; archive provides 2018, 2020, 2022, 2024, 2026 season years.','afc.champions':'2024/25 includes 112 scored rows (89 league phase + 23 knockout), with seven canceled scheduled fixtures listed separately. 2025/26 includes 115 scored rows (96 league phase + 19 knockout); four postponed Round-of-16 fixtures are listed separately. 2026/27 has 22 scored opening league-phase rows through the 2026-10-13 source capture. East/West is unresolved only where ESPN omitted the region note.','jpn.league_cup':'2022 has 21 locally verified regulation rows; 2023-2025 has 212 rows; four official 2026/27 quarterfinal first-leg results dated 2026-11-11 were verified. Second-leg results dated 2026-11-15 were not recovered in scored form.','fifa.world':'Complete three-edition panels: 2018 64, 2022 64, 2026 104.'},'markets':{'hda_paired':sum(r.get('h2h') is not None for r in rows),'totals_paired':sum(r.get('total') is not None for r in rows),'missing_market_rows':sum(r.get('h2h') is None or r.get('total') is None for r in rows),'note':'Scoreboard response odds arrays were null in the inspected snapshots; values not inferred.'},'request_statuses':[]}
for mp in sorted((OUT/'raw/online').glob('*.meta.json')):
    try:m=json.loads(mp.read_text())
    except Exception:continue
    idx['request_statuses'].append({k:m.get(k) for k in ('url','http_status','bytes','sha256','retrieved_at','captured_at') if k in m})
(OUT/'index.json').write_text(json.dumps(idx,ensure_ascii=False,indent=2)+'\n')
manifest=[]
for p in sorted((OUT/'raw').rglob('*')):
    if p.is_file():manifest.append({'path':str(p.relative_to(OUT)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(OUT/'raw-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
