#!/usr/bin/env python3
"""Rebuild panel from the WCPP archived score extracts; intentionally emits null markets."""
import json, sqlite3, pathlib, re, hashlib, shutil
ROOT=pathlib.Path('/workspace/WCPP')
OUT=ROOT/'reports/kpi-optimization-20261123-r5/special-cups'
rows=[]
def emit(**kw):
    kw.update(h2h=None,total=None,bookmaker=None,market_time_basis=None,paired_market=False)
    rows.append(kw)
for comp in ('fifa.world','afc.champions'):
    for p in sorted((ROOT/'research/all-scope-20261104/numerical-inputs').glob(comp+'__*/merged-history.json')):
        stage=p.parent.name.split('__',1)[1]
        shutil.copy2(p,OUT/'raw'/f'{p.parent.name}.json')
        for x in json.loads(p.read_text()):
            if x.get('score_basis')!='regulation_90' or x.get('home_goals') is None or x.get('away_goals') is None: continue
            ev=x.get('evidence',{})
            emit(id=x['match_id'],competition=comp,stage=stage,season=x['date'][:4],date=x['date'],home=x.get('display_home',x['home']),away=x.get('display_away',x['away']),home_goals=x['home_goals'],away_goals=x['away_goals'],neutral=x.get('neutral'),sources=[{'url':ev.get('summary_url'),'sha256':ev.get('summary_sha256')},{'url':ev.get('scoreboard_url'),'sha256':ev.get('scoreboard_sha256')}])
db=ROOT/'research/nations-repair-20261116/database-v2/nations.sqlite'; shutil.copy2(db,OUT/'raw/nations.sqlite'); c=sqlite3.connect(db)
teams=dict(c.execute('select team_id,name from teams')); sources={r[0]:r[1:] for r in c.execute('select source_id,source_url,raw_sha256 from source_records')}
for r in c.execute('select provider_event_id,season_year,league_level,stage,group_id,date,home_id,away_id,home_90,away_90,neutral,source_id from events'):
    pid,season,level,stage,group,date,h,a,hg,ag,neutral,sid=r
    if hg is None or ag is None: continue
    url,sha=sources.get(sid,(None,None))
    emit(id=pid,competition='uefa.nations',stage='level-'+str(level or 'unknown')+':'+str(stage or 'unknown')+(':'+group if group else ''),season=str(season or date[:4]),date=date,home=teams.get(h,h),away=teams.get(a,a),home_goals=hg,away_goals=ag,neutral=bool(neutral) if neutral is not None else None,sources=[{'url':url,'sha256':sha}])
p=ROOT.parent/'jleague-cup-20261111/staging/history.jsonl'; shutil.copy2(p,OUT/'raw/jleague_cup_history.jsonl')
for line in p.read_text().splitlines():
    x=json.loads(line)
    if x.get('h90') is None or x.get('a90') is None: continue
    raw_src=ROOT.parent/'jleague-cup-20261111/staging'/x.get('source_path','')
    copied=None; actual_sha=None
    if raw_src.is_file():
        dest=OUT/'raw/jleague_sources'/raw_src.name; dest.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(raw_src,dest)
        actual_sha=hashlib.sha256(dest.read_bytes()).hexdigest(); copied=str(dest.relative_to(OUT))
    srcs=[{'url':x.get('source_url'),'sha256':x.get('source_sha256') if x.get('source_sha256')==actual_sha else None},{'provider':'retained database/export','file':'raw/jleague_cup_history.jsonl','sha256':hashlib.sha256((OUT/'raw/jleague_cup_history.jsonl').read_bytes()).hexdigest()}]
    if copied: srcs.append({'provider':'retained raw source','file':copied,'sha256':actual_sha})
    emit(id=x['match_id'],competition='jpn.league_cup',stage=x.get('stage') or 'stage-unknown',season=str(x['season']),date=x['date'],home=x.get('home_name'),away=x.get('away_name'),home_goals=x['h90'],away_goals=x['a90'],neutral=x.get('neutral'),sources=srcs)
# Restore verified 2022 J League Cup knockout rounds from the expanded local archive.
jdb=ROOT/'data/jleague-cup/jleague-cup-expanded-20261111.sqlite'
if jdb.exists():
    shutil.copy2(jdb,OUT/'raw/jleague_cup_expanded.sqlite')
    import sqlite3 as _sql
    jc=_sql.connect(jdb); jt=dict(jc.execute('select team_id,name from teams'));
    src={r[0]:r[1:] for r in jc.execute('select source_id,source_url,raw_sha256,raw_path from sources')}
    for r in jc.execute("select m.match_id,m.date,m.home_id,m.away_id,m.stage,m.home_90,m.away_90,m.neutral,m.research_eligible,o.source_id from matches m left join observations o on m.match_id=o.match_id where m.season='2022'"):
        mid,date,h,a,stage,hg,ag,neutral,eligible,sid=r
        if not eligible or hg is None or ag is None: continue
        url,digest,raw_path=src.get(sid,(None,None,None))
        copied=None; actual_sha=None
        if raw_path and pathlib.Path(raw_path).is_file():
            dest=OUT/'raw/jleague_sources'/pathlib.Path(raw_path).name; dest.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(raw_path,dest)
            actual_sha=hashlib.sha256(dest.read_bytes()).hexdigest(); copied=str(dest.relative_to(OUT))
        srcs=[{'url':url,'sha256':digest if digest==actual_sha else None},{'provider':'retained database/export','file':'raw/jleague_cup_expanded.sqlite','sha256':hashlib.sha256((OUT/'raw/jleague_cup_expanded.sqlite').read_bytes()).hexdigest()}]
        if copied: srcs.append({'provider':'retained raw source','file':copied,'sha256':actual_sha})
        emit(id=mid,competition='jpn.league_cup',stage=stage or 'stage-unresolved',season='2022',date=date,home=jt.get(h,h),away=jt.get(a,a),home_goals=hg,away_goals=ag,neutral=bool(neutral) if neutral is not None else None,score_basis='regulation_90',sources=srcs)
    jc.close()
# Reconstruct WC 2018/2022/2026 regulation score directly from ESPN scoring events.
for year, filename in [('2018','fifa.world-2018-scoreboard.json'),('2022','fifa.world-2022-scoreboard-archived.json'),('2026','fifa.world-2026-scoreboard-successful-snapshot.json')]:
    p=OUT/'raw/online'/filename
    if not p.exists(): continue
    body=p.read_bytes(); digest=hashlib.sha256(body).hexdigest(); data=json.loads(body)
    for ev in data.get('events',[]):
        c=ev.get('competitions',[{}])[0]; tm={z.get('homeAway'):z for z in c.get('competitors',[])}
        if 'home' not in tm or 'away' not in tm: continue
        side={z.get('team',{}).get('id'):k for k,z in tm.items()}; score={'home':0,'away':0}; valid=True
        for d in c.get('details',[]):
            if not d.get('scoringPlay') or d.get('shootout'): continue
            minute=re.match(r'^(\d+)',str(d.get('clock',{}).get('displayValue','')))
            tid=d.get('team',{}).get('id')
            if not minute or tid not in side: valid=False; break
            if int(minute.group(1))<=90: score[side[tid]]+=int(d.get('scoreValue',1))
        if not valid: continue
        label=c.get('altGameNote','').lower()
        if 'group' in label: stage='group-stage'
        elif 'round of 32' in label: stage='round-of-32'
        elif 'round of 16' in label: stage='round-of-16'
        elif 'quarter' in label: stage='quarterfinals'
        elif 'semi' in label: stage='semifinals'
        elif 'third' in label or '3rd' in label: stage='3rd-place-match'
        elif 'final' in label: stage='final'
        else: stage='stage-unresolved'
        url=f'https://site.api.espn.com/apis/site/v2/sports/soccer/fifa.world/scoreboard?dates={year}&limit=1000'
        emit(id='fifa.world:'+ev['id'],competition='fifa.world',stage=stage,season=year,split={'2018':'training','2022':'validation','2026':'holdout'}[year],score_basis='regulation_90_scoring_events_excluding_extra_time_and_shootout',date=ev.get('date','')[:10],home=tm['home']['team'].get('displayName'),away=tm['away']['team'].get('displayName'),home_goals=score['home'],away_goals=score['away'],neutral=bool(c.get('neutralSite',False)),sources=[{'url':url,'sha256':digest}])
# Add successfully retrieved ESPN annual scoreboard rows for Nations League and AFC.
for comp in ('uefa.nations','afc.champions'):
    for p in sorted((OUT/'raw/online').glob(comp+'-*-scoreboard.json')):
        meta_path=p.with_suffix(p.suffix+'.meta.json')
        if not meta_path.exists(): continue
        meta=json.loads(meta_path.read_text())
        if meta.get('http_status')!=200: continue
        try: data=json.loads(p.read_text())
        except Exception: continue
        digest=meta.get('sha256'); url=meta.get('url')
        for ev in data.get('events',[]):
            c=ev.get('competitions',[{}])[0]; teams={z.get('homeAway'):z for z in c.get('competitors',[])}
            if 'home' not in teams or 'away' not in teams: continue
            typ=c.get('status',ev.get('status',{})).get('type',{}).get('name','')
            if not c.get('status',ev.get('status',{})).get('type',{}).get('completed'): continue
            if any(q in typ for q in ('AET','PEN')):
                side={z.get('team',{}).get('id'):k for k,z in teams.items()}; score={'home':0,'away':0}; valid=True
                for d in c.get('details',[]):
                    if not d.get('scoringPlay') or d.get('shootout'): continue
                    minute=re.match(r'^(\d+)',str(d.get('clock',{}).get('displayValue',''))); tid=d.get('team',{}).get('id')
                    if not minute or tid not in side: valid=False; break
                    if int(minute.group(1))<=90: score[side[tid]]+=int(d.get('scoreValue',1))
                if not valid: continue
                hg,ag=score['home'],score['away']
            else:
                if not all(str(teams[k].get('score','')).isdigit() for k in ('home','away')): continue
                hg,ag=int(teams['home']['score']),int(teams['away']['score'])
            note=c.get('altGameNote',''); slug=ev.get('season',{}).get('slug',''); note_low=note.lower()
            if comp=='uefa.nations':
                grp=c.get('group',{}).get('name',''); gm=re.search(r'Group ([A-D])([0-9]+)',note) or re.search(r'Group ([A-D])([0-9]+)',grp)
                if gm: stage=f'level-{gm.group(1)}:league-phase:group-{gm.group(2)}'
                elif 'relegation' in note_low: stage='level-unresolved:promotion-relegation-playoffs'
                elif 'final' in note_low: stage='level-A:final'
                elif 'semi' in note_low: stage='level-A:semifinals'
                else: stage='level-unresolved:'+(slug or 'stage-unresolved')
                season=str(ev.get('season',{}).get('year') or ev.get('date','')[:4])
            else:
                season_year=str(ev.get('season',{}).get('year') or ev.get('date','')[:4]); season=season_year+'/'+str((int(season_year)+1)%100).zfill(2)
                pretty=slug.replace('-','_') or 'stage-unresolved'
                if int(season_year)>=2024 and ('group east' in note_low or 'group west' in note_low):
                    region='east_region' if 'group east' in note_low else 'west_region'; stage='ELITE:league_phase:'+region
                elif int(season_year)>=2024 and ('league-stage' in slug or 'league phase' in note_low or 'group' in note_low):
                    stage='ELITE:league_phase:region_unresolved'
                else: stage='legacy:'+('group_stage' if 'group' in note_low else pretty)
            hs=teams['home']['team'].get('displayName'); aw=teams['away']['team'].get('displayName')
            emit(id=comp+':'+ev['id'],competition=comp,stage=stage,season=season,date=ev.get('date','')[:10],home=hs,away=aw,home_goals=hg,away_goals=ag,neutral=bool(c.get('neutralSite',False)),sources=[{'url':url,'sha256':digest}])
# AFC 2024/25 and 2025/26 scoreboard archive adds East/West region evidence and 90'-only AET scores.
p=OUT/'raw/online/afc.champions-2025-scoreboard-archived.json'
if p.exists():
    body=p.read_bytes(); digest=hashlib.sha256(body).hexdigest(); data=json.loads(body)
    url='https://site.api.espn.com/apis/site/v2/sports/soccer/afc.champions/scoreboard?dates=2025&limit=1000'
    for ev in data.get('events',[]):
        c=ev.get('competitions',[{}])[0]; tm={z.get('homeAway'):z for z in c.get('competitors',[])}
        if 'home' not in tm or 'away' not in tm or not c.get('status',{}).get('type',{}).get('completed'): continue
        typ=c.get('status',{}).get('type',{}).get('name','')
        if any(q in typ for q in ('AET','PEN')):
            side={z.get('team',{}).get('id'):k for k,z in tm.items()}; sc={'home':0,'away':0}; valid=True
            for d in c.get('details',[]):
                if not d.get('scoringPlay') or d.get('shootout'): continue
                minute=re.match(r'^(\d+)',str(d.get('clock',{}).get('displayValue',''))); tid=d.get('team',{}).get('id')
                if not minute or tid not in side: valid=False; break
                if int(minute.group(1))<=90: sc[side[tid]]+=int(d.get('scoreValue',1))
            if not valid: continue
            hg,ag=sc['home'],sc['away']
        else:
            if not all(str(tm[k].get('score','')).isdigit() for k in ('home','away')): continue
            hg,ag=int(tm['home']['score']),int(tm['away']['score'])
        note=c.get('altGameNote','').lower(); slug=ev.get('season',{}).get('slug',''); yr=int(ev.get('season',{}).get('year') or ev.get('date','')[:4])
        if 'group east' in note: stage='ELITE:league_phase:east_region'
        elif 'group west' in note: stage='ELITE:league_phase:west_region'
        elif slug=='league-stage': stage='ELITE:league_phase:region_unresolved'
        else: stage='ELITE:'+slug.replace('-','_')
        season=f'{yr}/{(yr+1)%100:02d}'
        emit(id='afc.champions:'+ev['id'],competition='afc.champions',stage=stage,season=season,date=ev.get('date','')[:10],home=tm['home']['team'].get('displayName'),away=tm['away']['team'].get('displayName'),home_goals=hg,away_goals=ag,neutral=bool(c.get('neutralSite',False)),score_basis='regulation_90',sources=[{'url':url,'sha256':digest}])
# AFC 2025/26 knockout archive and 2026/27 opening league phase (HTTP 200, 2026-10-13 capture).
p=OUT/'raw/online/afc.champions-2026-scoreboard-archived.json'
if p.exists():
    wrapper=json.loads(p.read_text()); data=wrapper.get('response',{}); digest=hashlib.sha256(p.read_bytes()).hexdigest(); url=wrapper.get('url')
    for ev in data.get('events',[]):
        c=ev.get('competitions',[{}])[0]; tm={z.get('homeAway'):z for z in c.get('competitors',[])}
        if 'home' not in tm or 'away' not in tm or not ev.get('status',{}).get('type',{}).get('completed'): continue
        typ=ev.get('status',{}).get('type',{}).get('name','')
        if any(q in typ for q in ('AET','PEN')):
            side={z.get('team',{}).get('id'):k for k,z in tm.items()}; sc={'home':0,'away':0}; valid=True
            for d in c.get('details',[]):
                if not d.get('scoringPlay') or d.get('shootout'): continue
                minute=re.match(r'^(\d+)',str(d.get('clock',{}).get('displayValue',''))); tid=d.get('team',{}).get('id')
                if not minute or tid not in side: valid=False; break
                if int(minute.group(1))<=90: sc[side[tid]]+=int(d.get('scoreValue',1))
            if not valid: continue
            hg,ag=sc['home'],sc['away']
        else:
            if not all(str(tm[k].get('score','')).isdigit() for k in ('home','away')): continue
            hg,ag=int(tm['home']['score']),int(tm['away']['score'])
        yr=int(ev.get('season',{}).get('year') or ev.get('date','')[:4]); season=f'{yr}/{(yr+1)%100:02d}'; slug=ev.get('season',{}).get('slug',''); note=c.get('altGameNote','').lower()
        if slug=='league-stage':
            if 'group east' in note: stage='ELITE:league_phase:east_region'
            elif 'group west' in note: stage='ELITE:league_phase:west_region'
            else: stage='ELITE:league_phase:region_unresolved'
        else: stage='ELITE:'+slug.replace('-','_')
        emit(id='afc.champions:'+ev['id'],competition='afc.champions',stage=stage,season=season,date=ev.get('date','')[:10],home=tm['home']['team'].get('displayName'),away=tm['away']['team'].get('displayName'),home_goals=hg,away_goals=ag,neutral=bool(c.get('neutralSite',False)),score_basis='regulation_90',sources=[{'url':url,'sha256':digest}])
# Add the four officially verified 2026 quarterfinal first-leg results from the local post-match review.
review=ROOT.parent/'jcup-review-20261112/verified-results.json'
if review.exists():
    shutil.copy2(review,OUT/'raw/jleague_official_review_20261112.json')
    review_sha=hashlib.sha256(review.read_bytes()).hexdigest(); matches=json.loads(review.read_text())['matches']
    names={'111101':('Vissel Kobe','FC Machida Zelvia'),'111102':('Urawa Red Diamonds','Cerezo Osaka'),'111103':('Yokohama F. Marinos','Kashima Antlers'),'111104':('Kawasaki Frontale','Kashiwa Reysol')}
    for m in matches:
        mid=str(m['match_id']).split(':')[-1]; raw_path=pathlib.Path(m['raw_path'])
        if not raw_path.is_file(): continue
        dest=OUT/'raw/jleague_sources'/f'official-{mid}.html';dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(raw_path,dest)
        page_sha=hashlib.sha256(dest.read_bytes()).hexdigest()
        if page_sha!=m.get('sha256'): continue
        home,away=names.get(mid,(m['home'],m['away']))
        emit(id='jleague:'+mid,competition='jpn.league_cup',stage='quarterfinals:leg-1',season='2026/27',split='holdout',score_basis='regulation_90',date='2026-11-11',home=home,away=away,home_goals=m['home_goals'],away_goals=m['away_goals'],neutral=None,sources=[{'url':m['source_url'],'sha256':page_sha},{'provider':'retained official review','file':'raw/jleague_official_review_20261112.json','sha256':review_sha},{'provider':'retained raw source','file':str(dest.relative_to(OUT)),'sha256':page_sha}])
unique={x['competition']+':'+x['id'].split(':')[-1]:x for x in rows}
rows=sorted(unique.values(),key=lambda x:(x['competition'],x['date'],x['id']))
for x in rows:
    if x['competition']=='fifa.world': x['split']={'2018':'training','2022':'validation','2026':'holdout'}.get(x['season'])
    elif x['competition']=='uefa.nations': x['split']='training' if x['season'] in ('2018','2020','2022') else ('validation' if x['season']=='2024' else ('holdout' if x['season']=='2026' else None))
    elif x['competition']=='afc.champions': x['split']='training' if x['season']=='2023/24' else ('validation' if x['season']=='2024/25' else ('holdout' if x['season'] in ('2025/26','2026/27') else None))
    elif x['competition']=='jpn.league_cup': x['split']='training' if x['season'] in ('2022','2023','2024') else ('validation' if x['season']=='2025' else ('holdout' if x['season']=='2026/27' else None))
(OUT/'panel.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rows))
print(f'{len(rows)} unique rows -> {OUT}/panel.jsonl')
