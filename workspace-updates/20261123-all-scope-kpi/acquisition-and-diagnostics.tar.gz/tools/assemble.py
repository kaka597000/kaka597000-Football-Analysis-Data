"""Assemble one independently sourced, regulation-only panel per configured competition."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import unicodedata

FIVE={'eng.1','esp.1','ger.1','ita.1','fra.1'}
GROUPS={'west-regular':FIVE|{'ned.1'}, 'nordic-brazil':{'nor.1','swe.1','bra.1'},
        'asia-america':{'jpn.1','kor.1','aus.1','usa.1'},'euro-cups':{'uefa.champions','uefa.europa','uefa.europa.conf'},
        'special-cups':{'uefa.nations','jpn.league_cup','afc.champions','fifa.world'}}
def encode(v):
    return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def name(s):
    return ''.join(c for c in unicodedata.normalize('NFKD',s.casefold()) if c.isalnum())
def stage_key(code, stage,leg=None):
    s=stage.strip().lower().replace('_','-')
    if code=='uefa.nations':
        s=re.sub(r'(:league-phase):(?:group-)?[0-9]+$',r'\1',s)
    if code in ('uefa.champions','uefa.europa','uefa.europa.conf','afc.champions','jpn.league_cup','uefa.nations'):
        if s in ('league-stage','league phase'):s='league-phase'
        if leg and str(leg).strip().lower() not in ('none','single','0','neutral','n/a'):
            v=str(leg).casefold().strip().replace('_','-')
            if v in ('1','1st leg','1st-leg','first leg','first-leg','leg1','leg-1'):v='leg-1'
            elif v in ('2','2nd leg','2nd-leg','second leg','second-leg','leg2','leg-2'):v='leg-2'
            if v in ('leg-1','leg-2') and not s.endswith(v):s+=':'+v
    return s
def excluded(r):
    c,s=r['competition'],r['stage'].casefold()
    if str(r['date'])[:10]>'2026-11-22':return 'after_cutoff'
    if c=='jpn.1' and (any(k in s for k in ('centen','hundred','special','100-year')) or ('placement-playoffs' in s and '2026-01-01'<=r['date']<'2026-07-01')):return 'separate_J100_competition'
    if c=='afc.champions' and r['date']<'2024-07-01':return 'pre_Elite_format'
    if c=='usa.1' and 'all-star' in (s+' '+str(r.get('provider_stage_slug',''))):return 'all_star_exhibition'
    if any(k in s for k in ('qualifying','qualifier','qualification-round')) and c in ('uefa.champions','uefa.europa','uefa.europa.conf','afc.champions','fifa.world'):return 'qualifying_outside_main_tournament'
    if any(type(r.get(k))!=int or r[k]<0 for k in ('home_goals','away_goals')):return 'unresolved_regulation_score'
    if re.search(r'unresolved|extra.time.included|shootout.included',str(r.get('score_basis','')),re.I):return 'unresolved_regulation_score'
    return None
def reference(sources):
    if isinstance(sources,dict):sources=[sources]
    for s in sources:
        if isinstance(s,dict):
            checksum=s.get('sha256') or s.get('source_sha256') or s.get('response_sha256')
            if checksum and re.fullmatch('[0-9a-f]{64}',checksum):return checksum
    raise ValueError('retained source checksum required: '+str(sources)[:250])
def attach_quote(r,index):
    ident=str(r['id']).split(':')[-1]
    candidate=index.get((r['competition'],ident))
    if not candidate:
        return r
    # Provider IDs must be backed by the same event date and both explicit team names.
    if (candidate['date']!=r['date'][:10] or any(name(candidate[k])!=name(r[k]) for k in ('home','away'))
            or r.get('paired_market') is True):
        return r
    t=r.get('total') or {}
    if candidate['paired_market'] or (not t.get('over') and (candidate.get('total') or {}).get('over')):
        hda=candidate.get('h2h') or r.get('h2h')
        return dict(r,h2h=hda,total=candidate['total'],paired_market=candidate['paired_market'],
                    sources=list(r['sources'])+candidate['sources'],bookmaker=candidate['bookmaker'],
                    market_time_basis=candidate['market_time_basis'])
    if r.get('h2h') is None and candidate.get('h2h'):
        return dict(r,h2h=candidate['h2h'],total=r.get('total') or candidate.get('total'),
                    sources=list(r['sources'])+candidate['sources'],paired_market=False,
                    market_time_basis=candidate['market_time_basis'],bookmaker=candidate['bookmaker'])
    return r


def make(root,code):
    base=next(k for k,g in GROUPS.items() if code in g)
    quotes=root/'quote-recovery/labeled-markets.jsonl'
    quote_index={(v['competition'],v['event']):v for l in quotes.open()
                 if (v:=json.loads(l))['competition']==code} if quotes.exists() else {}
    nationals=root/'quote-recovery/nations-matched.json'
    live=json.loads(nationals.read_bytes()) if code=='uefa.nations' and nationals.exists() else {}
    recoveries=root/'quote-recovery/regulation-recoveries.json'
    rescued=json.loads(recoveries.read_bytes()) if recoveries.exists() else {}
    paths=[root/base/'panel.jsonl']
    if code=='ned.1' and (root/'euro-cups/dutch-extra.jsonl').exists():paths.append(root/'euro-cups/dutch-extra.jsonl')
    rows={}
    natural={}
    exclusions=Counter()
    duplicates=Counter()
    for p in paths:
        for row in p.open():
            r=json.loads(row)
            if r.get('competition')!=code:continue
            recovery=rescued.get(r['id'])
            if recovery and recovery['competition']==code:
                r=dict(r,home_goals=recovery['home_goals'],away_goals=recovery['away_goals'],
                       score_basis=recovery['score_basis'],sources=list(r['sources'])+[recovery['source']])
            skip=excluded(r)
            if skip:
                exclusions[skip]+=1
                continue
            from research_program.all_scope_ingest import paired_market
            r=dict(r,paired_market=paired_market(r))
            r=attach_quote(r,quote_index)
            q=live.get(str(r['id']).split(':')[-1])
            if q and q['date']==r['date'][:10] and r.get('total') is None:
                r=dict(r,**{k:q[k] for k in ('h2h','total','bookmaker','paired_market','market_time_basis')},
                       sources=list(r['sources'])+q['sources'])
            if code=='usa.1' and r.get('stage')=='regular':
                slug=r.get('provider_stage_slug','')
                if slug=='mls-cup' or slug.startswith('mls-is-back---'):
                    r=dict(r,stage='playoffs:'+slug)
            sources=r['sources']
            hda=r.get('h2h')
            total=r.get('total')
            if total and not isinstance(total,dict):raise ValueError('invalid total '+str(total))
            season=r['season']
            if isinstance(season,dict):season=season.get('year') or season.get('slug')
            normalized=dict(id=str(r['id']),competition=code,stage=stage_key(code,r['stage'],r.get('leg')),
                source_stage=r['stage'],leg=r.get('leg'),season=str(season),date=r['date'][:10],
                home=r['home'],away=r['away'],home_goals=r['home_goals'],away_goals=r['away_goals'],
                neutral=r.get('neutral'),sources=sources,source_sha256=reference(sources),h2h=hda,total=total,
                paired_market=r.get('paired_market') is True,bookmaker=r.get('bookmaker'),
                market_time_basis=r.get('market_time_basis'),score_basis=r.get('score_basis','verified_regulation_from_collection'))
            key=(normalized['date'],name(r['home']),name(r['away']))
            if key in natural or normalized['id'] in rows:
                old=rows[natural[key]] if key in natural else rows[normalized['id']]
                if (old['date'],old['home_goals'],old['away_goals']) != (normalized['date'],r['home_goals'],r['away_goals']):
                    raise ValueError('conflicting identity/score: '+str([old['id'],r['id'],key]))
                duplicates['same_fixture']+=1
                continue
            rows[normalized['id']]=normalized
            natural[key]=normalized['id']
    folder=root/'panels';folder.mkdir(exist_ok=True)
    target=folder/(code+'.jsonl')
    with target.open('w') as out:
        for r in sorted(rows.values(),key=lambda v:(v['date'],v['id'])):out.write(encode(r)+'\n')
    summary=dict(competition=code,n=len(rows),inputs={str(p.relative_to(root)):sha(p) for p in paths},
        additional_quote_index_sha256=sha(quotes) if quotes.exists() else None,panel_sha256=sha(target),excluded=dict(exclusions),duplicates=dict(duplicates),
        stages=dict(Counter(r['stage'] for r in rows.values())),source_market_labels=dict(Counter(str(r['market_time_basis']) for r in rows.values())))
    (folder/(code+'-source.json')).write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    return len(rows)
if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('competitions',nargs='+');a=p.parse_args()
    root=Path(__file__).resolve().parent
    for c in a.competitions:print(c,make(root,c))
