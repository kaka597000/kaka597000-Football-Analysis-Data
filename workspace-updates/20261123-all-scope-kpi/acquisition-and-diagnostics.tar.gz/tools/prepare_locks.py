"""Build all requested development locks independently; retain earlier input revisions for lineage."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import json,os
from pathlib import Path
import shutil,subprocess,sys
from assemble import make
r=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('codes',nargs='+');args=p.parse_args()
sys.path.insert(0,str(args.source/'runtime'))
from research_program.all_scope_study import boundaries,check_panel
from research.analysis_freeze import digest
def execute(c):
    make(r,c); panel=r/'panels'/(c+'.jsonl');out=r/'study'/c
    rows=check_panel(panel,c);cut=boundaries(c)[1]
    dev=digest([x for x in rows if x['date']<cut])
    if (out/'lock.json').exists() and json.loads((out/'lock.json').read_bytes())['fit_selection_sha256']!=dev:
        if (out/'report.json').exists():raise ValueError('evaluation already opened')
        old=r/'provisional'/c/datetime.now(timezone.utc).strftime('%H%M%S%f')
        old.parent.mkdir(parents=True,exist_ok=True);shutil.move(out,old)
    out.mkdir(parents=True,exist_ok=True)
    for entry,flag in [('all_scope_study','lock.json'),('all_scope_neighbors','neighbor-lock.json')]:
        if not (out/flag).exists():
            with (out/(entry+'-fit.log')).open('w') as f:
                result=subprocess.run([sys.executable,'-m','research_program.'+entry,'fit','--competition',c,'--panel',str(panel),'--out',str(out)],cwd=args.source,env=dict(os.environ,PYTHONPATH=str(args.source/'runtime'),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'),stdout=f,stderr=f)
            if result.returncode:raise RuntimeError(c+' '+(out/(entry+'-fit.log')).read_text()[-1200:])
    print(c,'locked',len(rows),flush=True)
with ThreadPoolExecutor(4) as pool:list(pool.map(execute,args.codes))
