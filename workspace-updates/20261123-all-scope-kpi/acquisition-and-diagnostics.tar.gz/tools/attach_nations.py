"""Link the registered event ID and archived pre-kickoff bookmaker lines without using outcomes."""
from collections import defaultdict
from datetime import datetime
from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent
def stamp(v):return datetime.fromisoformat(v.replace('Z','+00:00'))
group=defaultdict(list)
for line in (r/'odds-supplement/recent-nations-market-supplement.jsonl').open():
    q=json.loads(line)
    if q['competition']!='uefa.nations' or not q.get('source_sha256') or not q.get('captured_at') or not q.get('quote_time'):continue
    if (stamp(q['quote_time'])<=stamp(q['captured_at'])<stamp(q['kickoff_at']) and q.get('line',0)>0
            and min(q.get('over_odds') or 0,q.get('under_odds') or 0)>1):
        group[q['match_id'].split(':')[-1]].append(q)
odds={}
for d in r.parent.glob('*nations*2026111*'):
    for p in d.rglob('odds.json'):
        try:raw=p.read_bytes();v=json.loads(raw)
        except (OSError,ValueError):continue
        digest=hashlib.sha256(raw).hexdigest()
        if not isinstance(v,list) or not v or not isinstance(v[0],dict) or 'bookmakers' not in v[0]:continue
        for event in v:odds[digest,event['id']]=event
result={}
for mid,quotes in group.items():
    q=min(quotes,key=lambda x:(x['bookmaker']!='pinnacle',-stamp(x['captured_at']).timestamp(),abs(1/x['over_odds']-1/x['under_odds']),x['bookmaker'],x['line']))
    evt=odds.get((q['source_sha256'],q['provider_match_id']),{})
    prices=None
    for bk in evt.get('bookmakers',[]):
        if bk['key']!=q['bookmaker']:continue
        for m in bk['markets']:
            if m['key']!='h2h':continue
            when=m.get('last_update') or bk.get('last_update')
            if not when or stamp(when)>stamp(q['captured_at']):continue
            value={o['name']:o['price'] for o in m['outcomes']}
            hda={k:value.get(name) for k,name in [('home',evt['home_team']),('draw','Draw'),('away',evt['away_team'])]}
            if all(isinstance(n,(int,float)) and n>1 for n in hda.values()):prices=hda
    ref=dict(provider=q['bookmaker'],url=q['source_url'],sha256=q['source_sha256'],match_id=q['match_id'],
             provider_match_id=q['provider_match_id'],capture=q['captured_at'],quoted_at=q['quote_time'],
             retained_archive=q['archive'].split('/workspace-updates/')[-1],archive_member=q['archive_member'])
    result[mid]=dict(date=q['date'],h2h=prices,total=dict(line=q['line'],over=q['over_odds'],under=q['under_odds']),
                     bookmaker=q['bookmaker'],paired_market=bool(prices),sources=[ref],market_time_basis='source-timestamped pre-kickoff capture')
(r/'quote-recovery/nations-matched.json').write_text(json.dumps(result,indent=2)+'\n')
print('pre-kickoff totals',len(result),'paired',sum(x['paired_market'] for x in result.values()))
