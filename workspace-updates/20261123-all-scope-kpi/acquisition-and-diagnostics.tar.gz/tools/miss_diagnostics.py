"""Describe score misses across all competitions on each locked historical window."""
from pathlib import Path
from collections import Counter
import csv,json,statistics
r=Path(__file__).resolve().parent
folder=Path('/workspace/Football-Data-kpi-20261123-r5/workspace-updates/20261123-all-scope-kpi/results');folder.mkdir(exist_ok=True)
scope=json.loads((r/'protocol.json').read_bytes())['competitions']
out=[]
for c in scope:
 for window in ('evaluation','recent'):
    g=[json.loads(s) for s in (r/'study'/c/('neighbor-'+window+'.jsonl')).open()]
    if not g:continue
    p=[x['forecast']['candidate']['primary'] for x in g];t=[x['forecast']['candidate']['top3'] for x in g]
    act=[x['actual'] for x in g];sc=['-'.join(map(str,v)) for v in act];mode=Counter(p).most_common(1)[0]
    predtot=[sum(map(int,v.split('-'))) for v in p];acttot=[sum(v) for v in act]
    out.append(dict(competition=c,window=window,population=len(g),most_picked_score=mode[0],picks_of_mode=mode[1],actual_matches_equal_mode=sc.count(mode[0]),
        primary_one_one=p.count('1-1'),actual_one_one=sc.count('1-1'),primary_accepted=sum(h==a for h,a in zip(p,sc)),
        actual_four_plus=sum(v>=4 for v in acttot),primary_four_plus=sum(v>=4 for v in predtot),three_contain_four_plus=sum(any(sum(map(int,i.split('-')))>=4 for i in v) for v in t),
        actual_four_plus_exact_hits=sum(v>=4 and f==a for v,f,a in zip(acttot,p,sc)),actual_four_plus_top3_hits=sum(v>=4 and a in choices for v,a,choices in zip(acttot,sc,t)),
        mean_actual_goals=sum(acttot)/len(g),mean_primary_goals=sum(predtot)/len(g)))
with (folder/'miss-diagnostics.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(out[0]));w.writeheader();w.writerows(out)
