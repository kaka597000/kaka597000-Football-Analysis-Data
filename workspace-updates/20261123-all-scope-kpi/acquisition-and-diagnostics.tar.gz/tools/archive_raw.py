"""Index the exact source bytes for panel/forward records, reusing earlier immutable repository files."""
from collections import defaultdict
import gzip,hashlib,io,json,os,subprocess,tarfile
from pathlib import Path
R=Path(__file__).resolve().parent;repo=Path('/workspace/Football-Data-kpi-20261123-r5');out=repo/'workspace-updates/20261123-all-scope-kpi/evidence'
out.mkdir(parents=True,exist_ok=True)
sources=defaultdict(set)
for p in (R/'panels').glob('*.jsonl'):
    for l in p.open():
        v=json.loads(l)
        for s in v['sources']:
            if s.get('sha256'):sources[s['sha256']].add(s.get('url') or s.get('file') or p.name)
for l in (R/'forward/fixtures.jsonl').open():
    v=json.loads(l)
    for s in v['sources']:sources[s['sha256']].add(s.get('url') or '')
for l in (R/'forward/market-latest-status.jsonl').open():
    v=json.loads(l)
    for field in ('h2h','total'):
        q=((v.get(field) or {}).get('close') or {}).get('source') or {}
        if q.get('sha256'):sources[q['sha256']].add(q.get('url') or '')
base=subprocess.check_output(['git','-C',str(repo),'rev-parse','research/kpi-score-process-20261123'],text=True).strip()
available={};pending=set(sources)
known=[repo/'workspace-updates/20261104-data-supplement']
for folder in known:
    for p in folder.rglob('*'):
        if not p.is_file():continue
        h=hashlib.sha256(p.read_bytes()).hexdigest()
        if h in pending:
            available[h]={'repository_path':str(p.relative_to(repo)),'commit':base};pending.remove(h)
locations=[R/d/'raw' for d in ('forward','euro-cups','special-cups','asia-america','nordic-brazil','odds-supplement')]
locations.extend([R.parent/'kpi-optimization-20261123-round2/data/raw',R.parent/'kpi-optimization-20261123-r4/new-panels/raw',R.parent/'kpi-optimization-20261123-r4/forward',R.parent.parent/'data/unified/raw',R/'forward',R/'odds-supplement'])
sensitive=[os.environ[n].encode() for n in os.environ if (n=='GH_TOKEN' or n.startswith('WCPP_') and ('KEY' in n or 'TOKEN' in n)) and len(os.environ[n])>12]
f=None;part=0;size=0
for folder in locations:
    if not folder.exists():continue
    for p in sorted(folder.rglob('*')):
        if not p.is_file() or p.stat().st_size<8 or p.stat().st_size>150_000_000:continue
        raw=p.read_bytes();h=hashlib.sha256(raw).hexdigest()
        if h not in pending:continue
        if any(k in raw for k in sensitive):raise ValueError('credential in raw source; exclude and retain safe evidence')
        data=gzip.compress(raw,compresslevel=5,mtime=0)
        if f is None or size+len(data)>9_000_000:
            if f is not None:f.close()
            part+=1;key=f'source-bytes-{part:02d}.tar';f=tarfile.open(out/key,'w');size=0
        ent=tarfile.TarInfo(h+'.gz');ent.size=len(data);ent.mode=0o644;f.addfile(ent,io.BytesIO(data));size+=len(data)+512
        available[h]={'archive':key,'member':h+'.gz','bytes':len(raw)};pending.remove(h)
if f is not None:f.close()
ledger={h:{'sources':sorted(sources[h]),**available.get(h,{'capture_status':'source hash only; use retained normalized inputs for replay'})} for h in sorted(sources)}
(out/'source-index.json').write_text(json.dumps(ledger,ensure_ascii=False,separators=(',',':'))+'\n')
print('unique',len(sources),'available',len(available),'referenced only',len(pending),'new archives',part,flush=True)
