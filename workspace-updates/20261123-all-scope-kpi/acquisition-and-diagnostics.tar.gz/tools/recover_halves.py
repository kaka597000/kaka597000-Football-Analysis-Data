"""Recover extra-time fixtures from archived regulation and extra-time goal clocks, validating the full score."""
import json,hashlib
from collections import Counter
from pathlib import Path
r=Path(__file__).resolve().parent
wanted={v['id']:v for l in (r/'asia-america/panel.jsonl').open() if 'unresolved' in str((v:=json.loads(l)).get('score_basis'))}
out={}
for p in sorted((r/'asia-america/raw').glob('espn_*.json')):
    if 'summary' in p.name or not p.stem.split('_')[-1].isdigit():continue
    raw=p.read_bytes()
    try:body=json.loads(raw)
    except ValueError:continue
    for e in body.get('events',[]):
        mid='espn:'+str(e['id'])
        if mid not in wanted:continue
        g=e['competitions'][0];teams={str(t['team']['id']):t['homeAway'] for t in g['competitors']};full={t['homeAway']:int(t['score']) for t in g['competitors']}
        if g['status']['type']['completed'] is not True or len(teams)!=2 or g.get('format',{}).get('regulation',{}).get('periods')!=2:continue
        entries=[v for v in g.get('details',[]) if v.get('scoringPlay') and not v.get('shootout')]
        observed=Counter();reg=Counter()
        bad=False
        for v in entries:
            side=teams.get(str((v.get('team') or {}).get('id')));clock=(v.get('clock') or {}).get('value')
            if side is None or not isinstance(clock,(int,float)):bad=True;break
            observed[side]+=1
            if clock<=5400:reg[side]+=1
        if bad or not g.get('details') or any(observed[t]!=score for t,score in full.items()):continue
        out[mid]=dict(id=mid,competition=wanted[mid]['competition'],home_goals=reg['home'],away_goals=reg['away'],
            score_basis='regulation_90 from timed scoring plays; non-shootout regulation plus extra-time goals cross-checked against both displayed team scores',
            source=dict(url=wanted[mid]['sources'][0]['url'],sha256=hashlib.sha256(raw).hexdigest(),file=p.name))
folder=r/'quote-recovery';folder.mkdir(exist_ok=True)
(folder/'regulation-recoveries.json').write_text(json.dumps(out,indent=2)+'\n')
print(len(out),'recovered from',len(wanted))
