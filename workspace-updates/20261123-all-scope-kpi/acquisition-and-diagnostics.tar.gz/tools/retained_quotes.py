"""Recover explicitly labeled prematch same-book markets from durable ESPN summary captures."""
from pathlib import Path
from collections import Counter
import hashlib,json,re
R=Path(__file__).resolve().parent
DATA=Path('/workspace/Football-Data-kpi-20261123-r5/workspace-updates/20261104-data-supplement')
SCOPE=set(json.loads((R/'protocol.json').read_bytes())['competitions'])
def number(v):
    try:n=float(str(v).strip().replace('−','-'));return 1+n/100 if n>=100 else 1-100/n if n<=-100 else None
    except (TypeError,ValueError):return None
def side_line(node,letter):
    line=str(node.get('line','')).strip().lower()
    m=re.fullmatch(letter+r'?\s*(\d+(?:\.\d+)?)',line)
    if not m:return None
    v=float(m.group(1));return v if v>0 and (4*v).is_integer() else None
def parse(o):
    for when in ['close','open']:
        mm=o.get('moneyline') or {}
        hda={k:number(((mm.get(k) or {}).get(when) or {}).get('odds')) for k in ('home','draw','away')}
        if not all(hda.values()):hda=None
        ou=o.get('total') or {}
        over=(ou.get('over') or {}).get(when) or {};under=(ou.get('under') or {}).get(when) or {}
        lo=side_line(over,'o');lu=side_line(under,'u')
        t=dict(line=lo,over=number(over.get('odds')),under=number(under.get('odds'))) if lo==lu and lo else None
        if t and not t['over'] and not t['under']:t=dict(line=lo)
        good=bool(t and t.get('over') and t.get('under'))
        if hda or t:yield (4 if hda and good else 3 if good else 2 if hda and t else 1 if t else 0),hda,t,when
def files():
    for p in DATA.glob('*summary-raw/*.json'):yield p
    for d in ('euro-cups','asia-america','nordic-brazil','special-cups'):
        for p in (R/d/'raw').rglob('*.json'):
            if 'summary' in str(p.relative_to(R/d)) and not p.name.endswith('.meta.json'):yield p
    other=R.parent.parent/'data/unified/raw'
    for p in other.rglob('*.json'):yield p
out={}
for p in files():
    if p.stat().st_size<1000:continue
    raw=p.read_bytes()
    try:v=json.loads(raw)
    except (ValueError,UnicodeError):continue
    if not isinstance(v,dict):continue
    hd=v.get('header') or {};code=(hd.get('league') or {}).get('slug')
    if code not in SCOPE or not hd.get('id') or len(hd.get('competitions',[]))!=1:continue
    game=hd['competitions'][0];ident=str(hd['id']);ts=game.get('date') or hd.get('date')
    if not ts or ts[:10]>'2026-11-22':continue
    teams={s['homeAway']:(s.get('team') or {}).get('displayName') for s in game['competitors']}
    if set(teams)!=set(('home','away')):continue
    for o in (v.get('pickcenter') or [])+(v.get('odds') or []):
        book=(o.get('provider') or {}).get('name')
        if not book:continue
        for quality,hda,t,when in parse(o):
            rank=(quality,int(when=='close'),int(book=='DraftKings'))
            if (code,ident) in out and out[code,ident][0]>=rank:continue
            src=dict(provider=book,url='https://site.api.espn.com/apis/site/v2/sports/soccer/'+code+'/summary?event='+ident,sha256=hashlib.sha256(raw).hexdigest())
            entry=dict(competition=code,event=ident,date=ts[:10],home=teams['home'],away=teams['away'],h2h=hda,total=t,bookmaker=book,
                paired_market=quality==4,market_time_basis='historical ESPN explicitly labelled '+when+' quote; provider time unreported',sources=[src],
                raw_quote={k:o.get(k) for k in ('provider','moneyline','total')})
            out[code,ident]=rank,entry
folder=R/'quote-recovery';folder.mkdir(exist_ok=True)
with (folder/'labeled-markets.jsonl').open('w') as s:
    for _,v in sorted(out.values(),key=lambda e:(e[1]['competition'],e[1]['date'],e[1]['event'])):
        s.write(json.dumps(v,ensure_ascii=False,separators=(',',':'))+'\n')
print('recoveries',dict(Counter(c for c,_ in out)))
