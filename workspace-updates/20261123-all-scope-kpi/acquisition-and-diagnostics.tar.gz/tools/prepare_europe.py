"""Re-use the archived regular-season Bet365 tables for the five major leagues and Eredivisie."""
from pathlib import Path
import json

r=Path(__file__).resolve().parent
old=r.parent/'kpi-optimization-20261123-round2/data/modern-market-paths.jsonl'
dutch=r.parent/'kpi-optimization-20261123-r4/new-panels/normalized.jsonl'
out=r/'west-regular'
out.mkdir(exist_ok=True)
with (out/'panel.jsonl').open('w',encoding='utf8') as stream:
    for path in (old,dutch):
        for line in path.open():
            v=json.loads(line)
            if path==dutch and v['cohort']!='ned.1':
                continue
            if path==old:
                q=v['market_paths'].get('Bet365',{}).get('close') or {}
                hda,total=q.get('h2h'),q.get('total')
                source=dict(url=v['source_url'],sha256=v['source_sha256'],row=v['source_line'])
            else:
                q=v['market']['bet365']['close']
                hda,total=q.get('h2h'),q.get('total_2_5')
                source=dict(url=v['source']['url'],sha256=v['source']['source_sha256'],row=v['source']['source_line'])
            rec=dict(id=v['match_id'],competition=v['cohort'],stage='regular',season=v['season'],date=v['game_date'],
                     home=v['home'],away=v['away'],home_goals=v['home_goals'],away_goals=v['away_goals'],neutral=False,
                     sources=[source],h2h=hda,total=total,bookmaker='Bet365' if hda or total else None,
                     paired_market=bool(hda and total),market_time_basis='archived_closing_category_no_quote_clock',
                     score_basis='regulation_90')
            stream.write(json.dumps(rec,ensure_ascii=False,separators=(',',':'))+'\n')
