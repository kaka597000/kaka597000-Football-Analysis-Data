"""Reconcile ESPN team IDs to historical names using the retained pre-window unified table and explicit same-league aliases."""
import json
from collections import defaultdict
from pathlib import Path
from hashlib import sha256
r=Path(__file__).resolve().parent
root=r.parent.parent
historical=root/'data/unified/training-90.json'
prev=r.parent/'kpi-optimization-20261123-r3/next/team-map.json'
kor=r/'forward/team-aliases.json'
forward=[json.loads(s) for s in (r/'forward/fixtures.jsonl').open()]
official=json.loads(kor.read_bytes())['alias_rows']
sources=[historical,prev,kor]
unified=json.loads(historical.read_bytes())
names=defaultdict(lambda:defaultdict(set))
for v in unified:
    if v.get('date','')>'2026-11-22':continue
    for side in ('home','away'):
        id_=v[side]
        if id_.startswith('espn:'):names[v['competition']][id_[5:]].add(v[side+'_name'])
big=json.loads(prev.read_bytes())['cohorts']
verified={c:{k.removeprefix('espn:'):v['football_data_name'] for k,v in g.items()} for c,g in big.items()}
verified['kor.1']={v['kleague_team_id']:v['historical_panel_name_en'] for v in official}
explicit={'eng.1':{'Manchester City':'Man City'},'esp.1':{'Celta Vigo':'Celta','Real Sociedad':'Sociedad'},
   'ger.1':{'TSG Hoffenheim':'Hoffenheim','FC Augsburg':'Augsburg','Borussia Dortmund':'Dortmund','Bayer Leverkusen':'Leverkusen'},
   'ita.1':{'AS Roma':'Roma'},'fra.1':{'Stade Rennais':'Rennes','AS Monaco':'Monaco'},
   'ned.1':{'FC Groningen':'Groningen','SC Cambuur':'Cambuur','ADO Den Haag':'Den Haag','FC Utrecht':'Utrecht',
            'Feyenoord Rotterdam':'Feyenoord','Ajax Amsterdam':'Ajax','Fortuna Sittard':'For Sittard','PEC Zwolle':'Zwolle','NEC Nijmegen':'Nijmegen','FC Twente':'Twente'}}
west={c:set() for c in ['eng.1','esp.1','ger.1','ita.1','fra.1','ned.1']}
for s in (r/'west-regular/panel.jsonl').open():
    v=json.loads(s);west[v['competition']].update((v['home'],v['away']))
for f in forward:
    c=f['competition']
    if c not in west:continue
    for side in ('home','away'):
        raw,id_=f[side],f[side+'_id']
        v=explicit.get(c,{}).get(raw) or verified.get(c,{}).get(id_)
        if v is None and raw in west[c]:v=raw
        options=names[c][id_]&west[c]
        if v is None and len(options)==1:v=next(iter(options))
        if v is not None and v in west[c]:verified.setdefault(c,{})[id_]=v
import importlib.util
norm_module=r/'nordic-brazil/build_final_panel.py'
spec=importlib.util.spec_from_file_location('nordic_team_names',norm_module)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
nordic_names=defaultdict(set)
for s in (r/'nordic-brazil/panel.jsonl').open():
    row=json.loads(s);nordic_names[row['competition']].update((row['home'],row['away']))
for f in forward:
    c=f['competition']
    if c not in nordic_names:continue
    for side in ('home','away'):
        candidates={t for t in nordic_names[c] if module.norm(t)==module.norm(f[side])}
        if c=='swe.1' and f[side]=='Örgryte IS' and 'Orgryte' in nordic_names[c]:
            candidates={'Orgryte'};explicit.setdefault(c,{})[f[side]]='Orgryte'
        if len(candidates)==1:verified.setdefault(c,{})[f[side+'_id']]=next(iter(candidates))
sources.append(norm_module)
(r/'forward/model-aliases.json').write_text(json.dumps(verified,ensure_ascii=False,indent=2)+'\n')
(r/'forward/model-alias-provenance.json').write_text(json.dumps(dict(inputs={str(p.relative_to(root)):sha256(p.read_bytes()).hexdigest() for p in sources},reviewed=explicit),ensure_ascii=False,indent=2)+'\n')
