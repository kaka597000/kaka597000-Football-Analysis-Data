"""Resolve remaining source hashes with archived national-team responses, gzip bodies and previous evidence archives."""
from pathlib import Path
import collections,gzip,hashlib,io,json,os,sqlite3,subprocess,tarfile
v=Path(__file__).resolve().parent;r=Path(str(v).removesuffix('-corrected'));repo=Path('/workspace/Football-Data-kpi-20261123-r5');out=repo/'workspace-updates/20261123-all-scope-kpi/evidence';p=out/'source-index.json';ledger=json.loads(p.read_bytes())
for panel in (v/'panels').glob('*.jsonl'):
 for l in panel.open():
  for s in json.loads(l)['sources']:
   h=s.get('sha256')
   if h and h not in ledger:ledger[h]={'sources':[s.get('url') or s.get('file') or panel.name],'capture_status':'source hash only'}
missing={k for k,v in ledger.items() if 'capture_status' in v}
index=16;t=None;size=0;base=subprocess.check_output(['git','-C',str(repo),'rev-parse','research/kpi-score-process-20261123'],text=True).strip()
def retain(h,raw):
 global t,index,size,name
 if h not in missing:return
 b=gzip.compress(raw,compresslevel=5,mtime=0)
 if t is None or size+len(b)>9000000:
  if t:t.close()
  name=f'source-bytes-extra-{index:02d}.tar';index+=1;size=0;t=tarfile.open(out/name,'w')
 a=tarfile.TarInfo(h+'.gz');a.size=len(b);a.mode=0o644;t.addfile(a,io.BytesIO(b));size+=len(b)+512
 ledger[h].pop('capture_status');ledger[h].update(archive=name,member=a.name,bytes=len(raw));missing.remove(h)
# Prefer existing immutable repository bytes when the member matches the price response byte for byte.
for n in ['20261110-nations-model','20261116-nations-repair','20261113-nations-evening','20261114-nations-prematch','20261123-goal-state']:
 for arc in (repo/'workspace-updates'/n).glob('*.tar.gz'):
  with tarfile.open(arc,'r|gz') as tf:
   for inf in tf:
    if not inf.isfile() or inf.size<8 or inf.size>20_000_000:continue
    z=tf.extractfile(inf).read();pool=[(False,z)]
    if z[:2]==b'\x1f\x8b':
     try:pool.append((True,gzip.decompress(z)))
     except OSError:pass
    for unpack,b in pool:
     h=hashlib.sha256(b).hexdigest()
     if h in missing:
      ledger[h].pop('capture_status');ledger[h].update(repository_path=str(arc.relative_to(repo)),member=inf.name,gunzip_member=unpack,commit=base);missing.remove(h)
db=sqlite3.connect('file:'+str(r/'special-cups/raw/nations.sqlite')+'?mode=ro',uri=True)
files=[Path(x) for h,x in db.execute('select raw_sha256,raw_path from source_records where raw_verified=1') if h in missing and x]
files+=list((r/'asia-america/raw/asianodds').glob('*.gz'))+list((r/'euro-cups/raw').glob('*.json'))
for d in [r.parent/'kpi-optimization-20261123',r.parent/'kpi-optimization-20261123-r4',r.parent/'kpi-optimization-20261123-round2']:
 files+=list(d.rglob('*.csv'))
for f in files:
 if not f.is_file() or not missing:continue
 x=f.read_bytes();retain(hashlib.sha256(x).hexdigest(),x)
 if x[:2]==b'\x1f\x8b':
  y=gzip.decompress(x);retain(hashlib.sha256(y).hexdigest(),y)
if t:t.close()
p.write_text(json.dumps(ledger,ensure_ascii=False,separators=(',',':'))+'\n')
print('Source-bytes references',len(ledger),'remaining',len(missing),[ledger[h]['sources'][0][:95] for h in sorted(missing)][:10],flush=True)
