"""Run the frozen research design for the complete verified set of competitions."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,sys,subprocess,os
r=Path(__file__).resolve().parent
source=Path(sys.argv[1]);locks=json.loads(Path(sys.argv[2]).read_bytes())['competitions']
def compute(code):
    folder=r/'study'/code;panel=r/'panels'/(code+'.jsonl')
    for p,h in [(panel,locks[code]['panel_sha256']),(folder/'artifact.json',locks[code]['primary']['artifact_sha256']),(folder/'neighbor-artifact.json',locks[code]['local_challenger']['artifact_sha256'])]:
        if hashlib.sha256(p.read_bytes()).hexdigest()!=h:raise ValueError('unregistered input: '+str(p))
    for mod,action,final in [('all_scope_study','evaluate','report.json'),('all_scope_neighbors','evaluate','neighbor-report.json'),('all_scope_study','refresh','refresh.json')]:
        if (folder/final).exists():continue
        with (folder/(mod+'-'+action+'.log')).open('w') as f:
            res=subprocess.run([sys.executable,'-m','research_program.'+mod,action,'--competition',code,'--out',str(folder),'--panel',str(panel)],cwd=source,env=dict(os.environ,PYTHONPATH=str(source/'runtime'),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'),stdout=f,stderr=f)
        if res.returncode:raise RuntimeError(code+' '+(folder/(mod+'-'+action+'.log')).read_text()[-1800:])
    print('evaluated',code,flush=True)
with ThreadPoolExecutor(5) as pool:list(pool.map(compute,locks))
