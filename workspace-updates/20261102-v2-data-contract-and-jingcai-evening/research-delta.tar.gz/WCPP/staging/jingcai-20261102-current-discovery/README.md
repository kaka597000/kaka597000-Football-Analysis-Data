# 2026-11-02竞彩身份与开球发现

查询时间均为北京时间（UTC+8）。这是周一竞彩销售日快照；编号按销售日，实际开球跨到11月3日。竞彩官方信息渠道未访问，澳客静态页面仅作允许的公开清单来源，销售状态不据此判定。

## 来源和权限

- 5Dollar `/status`：2026-11-02 17:59:32，HTTP 200，Community；status显示每小时300次、burst 20/min，响应头剩余299。
- 5Dollar固定 `types=jingcailottery` 的 `/chinasportslottery`：2026-11-02 18:00:11，HTTP 403，错误 `insufficient_plan`（China Sports Lottery starts with Ultra）。按服务停止后续调用。
- 澳客 `https://www.okooo.com/jingcai/`：2026-11-02 18:00:38，HTTP 200，430,311 bytes；响应SHA-256 `0f93a1576dc51180cda69d5a5921e9214b9dc050c4da231a07e34f97f9e13655`。按GB18030解码。页面显示周一001–009，字段`data-end=0`不作为实际销售状态证据。
- ESPN公开scoreboard：北京时间18:01:30–18:01:32按联赛分别调用，查询UTC日期`20261102`。八场身份精确匹配且状态均`STATUS_SCHEDULED/state=pre`。原始响应及哈希在`espn/`。
- ESPN芬超`fin.1`同日期HTTP 200、events 0。FotMob公开日历 `https://www.fotmob.com/api/data/matches?date=20261102` 于18:02:51 HTTP 200，未包含国际图尔—赫尔火花。

## 澳客清单与身份交叉核验

| 竞彩号 | 赛事 | 对阵 | 北京时间开球 | ESPN事件ID / 状态 | FotMob事件ID / 状态 |
|---|---|---|---|---|---|
| 周一001 | 芬超 | 国际图尔—赫尔火花 | 11-03 00:00 | 未匹配；ID/状态未核实 | 未匹配 |
| 周一002 | 意甲 | 萨索洛—佛罗伦萨 | 11-03 01:30 | 401874963 / STATUS_SCHEDULED | 待其他联赛代理补充 |
| 周一003 | 瑞典超 | 盖斯—索尔纳 | 11-03 02:00 | 401842870 / STATUS_SCHEDULED | 待其他联赛代理补充 |
| 周一004 | 意甲 | 亚特兰大—帕尔马 | 11-03 03:45 | 401874971 / STATUS_SCHEDULED | 待其他联赛代理补充 |
| 周一005 | 法乙 | 圣旺红星—南锡 | 11-03 03:45 | 401876703 / STATUS_SCHEDULED | 5803305 / 未开赛，Ligue 2 |
| 周一006 | 英超 | 纽卡斯尔—埃弗顿 | 11-03 04:00 | 401878762 / STATUS_SCHEDULED | 待其他联赛代理补充 |
| 周一007 | 西甲 | 拉科（Deportivo A Coruña）—奥萨苏纳 | 11-03 04:00 | 401882824 / STATUS_SCHEDULED | 5868113 / 未开赛，LaLiga |
| 周一008 | 葡超 | 本菲卡—阿尔维卡 | 11-03 04:15 | 401885403 / STATUS_SCHEDULED | 待其他联赛代理补充 |
| 周一009 | 巴西甲 | 布拉干RB—桑托斯 | 11-03 07:00 | 401841299 / STATUS_SCHEDULED | 待其他联赛代理补充 |

ESPN UTC开球时间分别对应澳客北京时间开球时间。查询时（18:04）所有比赛未开场。ESPN/FotMob仅核对比赛日赛程；005由FotMob Ligue 2（5803305）交叉核验；007由FotMob LaLiga（5868113）交叉核验，ESPN主队简写Deportivo，FotMob规范名Deportivo A Coruña。阶段/赛制和销售可用性尚未逐场确认。

## 留档与缺口

- `okooo-jingcai.html`：原始澳客响应；`okooo-jingcai.meta.json`：采集时间、状态、哈希。
- `okooo-parsed-fixtures.json`：逐项解析后的竞彩编号、澳客赛事ID、队名、时间和页面状态字段。
- `5dollar-status.json`与`5dollar-jingcailottery.json`：状态/接口权限证据，凭据未写入。
- `espn/`：八个联赛的原始scoreboard及调用清单；`fotmob-matches-20261102.json`及manifest：FotMob当天日历证据。
- `identity-and-status.json`：统一身份/status映射。
- The Odds API当前批次已覆盖周一002部分总球报价，详见`the-odds-api/summary.md`；没有完整时序，所以不把单点快照称水位变化。004及其他比赛尚无The Odds API报价证据。
- 仍缺：001独立赛事ID/日历身份；俱乐部/官方伤停与近期xG；竞彩当前是否仍售/已停售均未知。
