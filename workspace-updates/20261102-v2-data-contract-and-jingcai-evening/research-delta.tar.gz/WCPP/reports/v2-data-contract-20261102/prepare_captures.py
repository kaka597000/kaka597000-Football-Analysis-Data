import json,hashlib
from pathlib import Path
root=Path('/workspace/WCPP/staging')
base=root/'jingcai-20261102-current-discovery'
out=Path(__file__).parent
cohorts={'Premier League':'eng.1','Serie A':'ita.1','LaLiga':'esp.1',
    'Conference League':'uefa.conference','EFL Cup':'eng.league_cup','Copa del Rey':'esp.copa_del_rey'}
captures=[]
def add(f,url,query,cohort=None):
    x=json.loads(f.read_text());g=x['general'];t=x['header']['teams']
    cohort=cohort or cohorts.get(g['leagueName'])
    if cohort is None:raise ValueError('Unreviewed competition')
    captures.append({'file':str(f.relative_to(root)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),
        'url':url,'query_time':query,'expected_match_id':g['matchId'],
        'expected_home_id':t[0]['id'],'expected_away_id':t[1]['id'],
        'expected_league_id':g['leagueId'],'cohort':cohort,'identity_verified':True})
for x in json.load(open(base/'big5/fotmob/details-manifest.json')):
    add(base/'big5/fotmob/details'/('match-'+str(x['matchId'])+'.json'),x['call']['url'],x['call']['query_time'])
for x in json.load(open(base/'other/recent-match-xg-manifest.json')):
    add(base/'other'/x['raw_file'],x['url'],x['query_time'],
        {'Allsvenskan':'swe.1','Liga Portugal':'por.1','Série A':'bra.1'}[x['league']])
for x in json.load(open(root/'mls-review-20261102-current/collection-manifest.json'))['requests']:
    if (x.get('file') or '').startswith('fotmob') and x['http_status']==200:
        add(root/'mls-review-20261102-current'/x['file'],x['url'],x['query_time_utc'],'usa.1')
with (out/'captures.json').open('x') as f:json.dump(captures,f,ensure_ascii=False,indent=2)
print('reviewed captures',len(captures))
