# 单场赛事完整模块分析

赛事ID：espn:401885403；截止时间：2026-11-02T10:15:39.208024+00:00

模块有输出不代表数据齐全、五名外部代理已执行、状态模拟已训练或准确率提高

## 历史进失球、球队攻防、主客场

补充证据状态：available
原工件训练截止及样本覆盖见真实双模型输出；本轮新资料不冒充已训练。

本场事实：
```json
{
  "registry": "WCPP-DUAL-4"
}
```

- 来源：https://site.api.espn.com/apis/site/v2/sports/soccer/por.1/scoreboard?dates=20261102；已知时间：2026-11-02T10:01:32+00:00；抓取：2026-11-02T10:01:32+00:00
- 来源：https://www.okooo.com/jingcai/；已知时间：2026-11-02T10:00:38.994664+00:00；抓取：2026-11-02T10:00:38.994664+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887660；已知时间：2026-11-02T10:09:44.345249+00:00；抓取：2026-11-02T10:09:44.345249+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887653；已知时间：2026-11-02T10:09:46.133722+00:00；抓取：2026-11-02T10:09:46.133722+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887641；已知时间：2026-11-02T10:09:47.992591+00:00；抓取：2026-11-02T10:09:47.992591+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887654；已知时间：2026-11-02T10:09:49.622689+00:00；抓取：2026-11-02T10:09:49.622689+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887649；已知时间：2026-11-02T10:09:51.173044+00:00；抓取：2026-11-02T10:09:51.173044+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887636；已知时间：2026-11-02T10:09:52.832810+00:00；抓取：2026-11-02T10:09:52.832810+00:00
- 来源：https://www.fotmob.com/api/data/teams?id=9772；已知时间：2026-11-02T10:05:24.228530+00:00；抓取：2026-11-02T10:05:24.228530+00:00
- 来源：https://www.fotmob.com/api/data/teams?id=9780；已知时间：2026-11-02T10:05:26.246728+00:00；抓取：2026-11-02T10:05:26.246728+00:00
missing：["field-level full coverage not certified; see source packets"]
- current：WCPP-MAIN-1.2；训练比赛截止 2026-10-09
  - home：均值 2.532284291929174；P0 0.0794772635005857；P≥2 0.7192637105713654；P≥3 0.464441175588083；区间 {'lower': 1, 'upper': 5, 'nominal_coverage': 0.8, 'width': 4, 'lower_quantile': 0.09999999999999998, 'upper_quantile': 0.9, 'matrix_coverage': 0.8763101920425698, 'method': 'EQUAL_TAIL_INTEGER_INVERSE_CDF_INCLUSIVE'}
  - away：均值 0.8469500282597019；P0 0.4287205254120475；P≥2 0.20817461347470476；P≥3 0.05440877728415457；区间 {'lower': 0, 'upper': 2, 'nominal_coverage': 0.8, 'width': 2, 'lower_quantile': 0.09999999999999998, 'upper_quantile': 0.9, 'matrix_coverage': 0.9455912227158456, 'method': 'EQUAL_TAIL_INTEGER_INVERSE_CDF_INCLUSIVE'}
- test：WCPP-ML-0.1；训练比赛截止 2026-10-09
  - home：均值 2.505846875922972；P0 0.08161456588791349；P≥2 0.7138880888474487；P≥3 0.4576807475714046；区间 {'lower': 1, 'upper': 5, 'nominal_coverage': 0.8, 'width': 4, 'lower_quantile': 0.09999999999999998, 'upper_quantile': 0.9, 'matrix_coverage': 0.8759660755676764, 'method': 'EQUAL_TAIL_INTEGER_INVERSE_CDF_INCLUSIVE'}
  - away：均值 0.8056866066367989；P0 0.44708249165812675；P≥2 0.193316327944383；P≥3 0.048387834803616615；区间 {'lower': 0, 'upper': 2, 'nominal_coverage': 0.8, 'width': 2, 'lower_quantile': 0.09999999999999998, 'upper_quantile': 0.9, 'matrix_coverage': 0.9516121651963836, 'method': 'EQUAL_TAIL_INTEGER_INVERSE_CDF_INCLUSIVE'}
数值权重：未在本报告另行指定；数据缺失不填零。

## 近期状态与比赛间隔

补充证据状态：partial
ESPN/FotMob身份与球队近期比赛清单已核（001身份待核）；联赛/杯赛分开，窗口见原始报告。

本场事实：
```json
{
  "evidence_root": "/workspace/WCPP/staging/jingcai-20261102-current-discovery"
}
```

- 来源：https://site.api.espn.com/apis/site/v2/sports/soccer/por.1/scoreboard?dates=20261102；已知时间：2026-11-02T10:01:32+00:00；抓取：2026-11-02T10:01:32+00:00
- 来源：https://www.okooo.com/jingcai/；已知时间：2026-11-02T10:00:38.994664+00:00；抓取：2026-11-02T10:00:38.994664+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887660；已知时间：2026-11-02T10:09:44.345249+00:00；抓取：2026-11-02T10:09:44.345249+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887653；已知时间：2026-11-02T10:09:46.133722+00:00；抓取：2026-11-02T10:09:46.133722+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887641；已知时间：2026-11-02T10:09:47.992591+00:00；抓取：2026-11-02T10:09:47.992591+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887654；已知时间：2026-11-02T10:09:49.622689+00:00；抓取：2026-11-02T10:09:49.622689+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887649；已知时间：2026-11-02T10:09:51.173044+00:00；抓取：2026-11-02T10:09:51.173044+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887636；已知时间：2026-11-02T10:09:52.832810+00:00；抓取：2026-11-02T10:09:52.832810+00:00
- 来源：https://www.fotmob.com/api/data/teams?id=9772；已知时间：2026-11-02T10:05:24.228530+00:00；抓取：2026-11-02T10:05:24.228530+00:00
- 来源：https://www.fotmob.com/api/data/teams?id=9780；已知时间：2026-11-02T10:05:26.246728+00:00；抓取：2026-11-02T10:05:26.246728+00:00
missing：["field-level full coverage not certified; see source packets"]
数值权重：未在本报告另行指定；数据缺失不填零。

## 射门、射正、控球

补充证据状态：partial
近期比赛过程见FotMob原响应；本场尚未开球，无本场射门事实。

本场事实：
```json
{
  "evidence_root": "/workspace/WCPP/staging/jingcai-20261102-current-discovery"
}
```

- 来源：https://site.api.espn.com/apis/site/v2/sports/soccer/por.1/scoreboard?dates=20261102；已知时间：2026-11-02T10:01:32+00:00；抓取：2026-11-02T10:01:32+00:00
- 来源：https://www.okooo.com/jingcai/；已知时间：2026-11-02T10:00:38.994664+00:00；抓取：2026-11-02T10:00:38.994664+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887660；已知时间：2026-11-02T10:09:44.345249+00:00；抓取：2026-11-02T10:09:44.345249+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887653；已知时间：2026-11-02T10:09:46.133722+00:00；抓取：2026-11-02T10:09:46.133722+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887641；已知时间：2026-11-02T10:09:47.992591+00:00；抓取：2026-11-02T10:09:47.992591+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887654；已知时间：2026-11-02T10:09:49.622689+00:00；抓取：2026-11-02T10:09:49.622689+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887649；已知时间：2026-11-02T10:09:51.173044+00:00；抓取：2026-11-02T10:09:51.173044+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887636；已知时间：2026-11-02T10:09:52.832810+00:00；抓取：2026-11-02T10:09:52.832810+00:00
- 来源：https://www.fotmob.com/api/data/teams?id=9772；已知时间：2026-11-02T10:05:24.228530+00:00；抓取：2026-11-02T10:05:24.228530+00:00
- 来源：https://www.fotmob.com/api/data/teams?id=9780；已知时间：2026-11-02T10:05:26.246728+00:00；抓取：2026-11-02T10:05:26.246728+00:00
missing：["field-level full coverage not certified; see source packets"]
工件记录的训练覆盖行数：{"current": null, "test": 0}；工件未登记的覆盖保持未知；0表示本工件无登记合格训练行，不表示未采集任何资料
数值权重：未在本报告另行指定；数据缺失不填零。

## xG / xGA

补充证据状态：partial
FotMob已核近期同源xG/xGA；big5窗口可能含杯赛并分开说明，other为近三场联赛；001/005未取得代表性xG。

本场事实：
```json
{
  "big5_evidence": "/workspace/WCPP/staging/jingcai-20261102-current-discovery/big5/evidence-summary.json",
  "other_evidence": "/workspace/WCPP/staging/jingcai-20261102-current-discovery/other/recent-league-xg-summary.json",
  "numeric_training_applied": false
}
```

- 来源：https://site.api.espn.com/apis/site/v2/sports/soccer/por.1/scoreboard?dates=20261102；已知时间：2026-11-02T10:01:32+00:00；抓取：2026-11-02T10:01:32+00:00
- 来源：https://www.okooo.com/jingcai/；已知时间：2026-11-02T10:00:38.994664+00:00；抓取：2026-11-02T10:00:38.994664+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887660；已知时间：2026-11-02T10:09:44.345249+00:00；抓取：2026-11-02T10:09:44.345249+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887653；已知时间：2026-11-02T10:09:46.133722+00:00；抓取：2026-11-02T10:09:46.133722+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887641；已知时间：2026-11-02T10:09:47.992591+00:00；抓取：2026-11-02T10:09:47.992591+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887654；已知时间：2026-11-02T10:09:49.622689+00:00；抓取：2026-11-02T10:09:49.622689+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887649；已知时间：2026-11-02T10:09:51.173044+00:00；抓取：2026-11-02T10:09:51.173044+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887636；已知时间：2026-11-02T10:09:52.832810+00:00；抓取：2026-11-02T10:09:52.832810+00:00
- 来源：https://www.fotmob.com/api/data/teams?id=9772；已知时间：2026-11-02T10:05:24.228530+00:00；抓取：2026-11-02T10:05:24.228530+00:00
- 来源：https://www.fotmob.com/api/data/teams?id=9780；已知时间：2026-11-02T10:05:26.246728+00:00；抓取：2026-11-02T10:05:26.246728+00:00
missing：["field-level full coverage not certified; see source packets"]
工件记录的训练覆盖行数：{"current": null, "test": 0}；工件未登记的覆盖保持未知；0表示本工件无登记合格训练行，不表示未采集任何资料
数值权重：未在本报告另行指定；数据缺失不填零。

## 阵容、伤停、停赛

补充证据状态：partial
未公布首发不默认阻断；平台不可用人员与预计回归不等于官方确认。004重大风险待定。

本场事实：
```json
{
  "official_starting_XI_verified": false,
  "numeric_personnel_model_trained": false
}
```

- 来源：https://site.api.espn.com/apis/site/v2/sports/soccer/por.1/scoreboard?dates=20261102；已知时间：2026-11-02T10:01:32+00:00；抓取：2026-11-02T10:01:32+00:00
- 来源：https://www.okooo.com/jingcai/；已知时间：2026-11-02T10:00:38.994664+00:00；抓取：2026-11-02T10:00:38.994664+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887660；已知时间：2026-11-02T10:09:44.345249+00:00；抓取：2026-11-02T10:09:44.345249+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887653；已知时间：2026-11-02T10:09:46.133722+00:00；抓取：2026-11-02T10:09:46.133722+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887641；已知时间：2026-11-02T10:09:47.992591+00:00；抓取：2026-11-02T10:09:47.992591+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887654；已知时间：2026-11-02T10:09:49.622689+00:00；抓取：2026-11-02T10:09:49.622689+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887649；已知时间：2026-11-02T10:09:51.173044+00:00；抓取：2026-11-02T10:09:51.173044+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887636；已知时间：2026-11-02T10:09:52.832810+00:00；抓取：2026-11-02T10:09:52.832810+00:00
- 来源：https://www.fotmob.com/api/data/teams?id=9772；已知时间：2026-11-02T10:05:24.228530+00:00；抓取：2026-11-02T10:05:24.228530+00:00
- 来源：https://www.fotmob.com/api/data/teams?id=9780；已知时间：2026-11-02T10:05:26.246728+00:00；抓取：2026-11-02T10:05:26.246728+00:00
missing：["field-level full coverage not certified; see source packets"]
数值权重：未在本报告另行指定；数据缺失不填零。

## 战意、旅行、完整赛程负荷

补充证据状态：partial
球队资料有前后赛程；未独立认证所有赛事覆盖、实际旅行/天气或数学战意。

本场事实：
```json
{
  "complete_all_competition_load_verified": false
}
```

- 来源：https://site.api.espn.com/apis/site/v2/sports/soccer/por.1/scoreboard?dates=20261102；已知时间：2026-11-02T10:01:32+00:00；抓取：2026-11-02T10:01:32+00:00
- 来源：https://www.okooo.com/jingcai/；已知时间：2026-11-02T10:00:38.994664+00:00；抓取：2026-11-02T10:00:38.994664+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887660；已知时间：2026-11-02T10:09:44.345249+00:00；抓取：2026-11-02T10:09:44.345249+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887653；已知时间：2026-11-02T10:09:46.133722+00:00；抓取：2026-11-02T10:09:46.133722+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887641；已知时间：2026-11-02T10:09:47.992591+00:00；抓取：2026-11-02T10:09:47.992591+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887654；已知时间：2026-11-02T10:09:49.622689+00:00；抓取：2026-11-02T10:09:49.622689+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887649；已知时间：2026-11-02T10:09:51.173044+00:00；抓取：2026-11-02T10:09:51.173044+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887636；已知时间：2026-11-02T10:09:52.832810+00:00；抓取：2026-11-02T10:09:52.832810+00:00
- 来源：https://www.fotmob.com/api/data/teams?id=9772；已知时间：2026-11-02T10:05:24.228530+00:00；抓取：2026-11-02T10:05:24.228530+00:00
- 来源：https://www.fotmob.com/api/data/teams?id=9780；已知时间：2026-11-02T10:05:26.246728+00:00；抓取：2026-11-02T10:05:26.246728+00:00
missing：["field-level full coverage not certified; see source packets"]
数值权重：未在本报告另行指定；数据缺失不填零。

## 盘口、赔率与水位变化

补充证据状态：partial
002仅Pinnacle 3.0球单点真实时间快照，其余未得本批合格实盘；无同机构历史，不做水位趋势。

本场事实：
```json
{
  "quoted_at": null,
  "line": null,
  "over": null,
  "under": null
}
```

- 来源：https://site.api.espn.com/apis/site/v2/sports/soccer/por.1/scoreboard?dates=20261102；已知时间：2026-11-02T10:01:32+00:00；抓取：2026-11-02T10:01:32+00:00
- 来源：https://www.okooo.com/jingcai/；已知时间：2026-11-02T10:00:38.994664+00:00；抓取：2026-11-02T10:00:38.994664+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887660；已知时间：2026-11-02T10:09:44.345249+00:00；抓取：2026-11-02T10:09:44.345249+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887653；已知时间：2026-11-02T10:09:46.133722+00:00；抓取：2026-11-02T10:09:46.133722+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887641；已知时间：2026-11-02T10:09:47.992591+00:00；抓取：2026-11-02T10:09:47.992591+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887654；已知时间：2026-11-02T10:09:49.622689+00:00；抓取：2026-11-02T10:09:49.622689+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887649；已知时间：2026-11-02T10:09:51.173044+00:00；抓取：2026-11-02T10:09:51.173044+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887636；已知时间：2026-11-02T10:09:52.832810+00:00；抓取：2026-11-02T10:09:52.832810+00:00
- 来源：https://www.fotmob.com/api/data/teams?id=9772；已知时间：2026-11-02T10:05:24.228530+00:00；抓取：2026-11-02T10:05:24.228530+00:00
- 来源：https://www.fotmob.com/api/data/teams?id=9780；已知时间：2026-11-02T10:05:26.246728+00:00；抓取：2026-11-02T10:05:26.246728+00:00
missing：["field-level full coverage not certified; see source packets"]
同机构同盘口价格比较：{"status": "NO_SNAPSHOTS", "comparisons": [], "rejected_snapshots": 0, "prediction_modified": false, "money_flow_inferred": false}
数值权重：未在本报告另行指定；数据缺失不填零。

## 五角色审查、分钟模拟、冷门旁路

补充证据状态：partial
沿用原独立旁路状态；动态融合/球员影响/新选择器未完成，未调用五个外部LLM。

本场事实：
```json
{
  "new_v2_models_enabled": false
}
```

- 来源：https://site.api.espn.com/apis/site/v2/sports/soccer/por.1/scoreboard?dates=20261102；已知时间：2026-11-02T10:01:32+00:00；抓取：2026-11-02T10:01:32+00:00
- 来源：https://www.okooo.com/jingcai/；已知时间：2026-11-02T10:00:38.994664+00:00；抓取：2026-11-02T10:00:38.994664+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887660；已知时间：2026-11-02T10:09:44.345249+00:00；抓取：2026-11-02T10:09:44.345249+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887653；已知时间：2026-11-02T10:09:46.133722+00:00；抓取：2026-11-02T10:09:46.133722+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887641；已知时间：2026-11-02T10:09:47.992591+00:00；抓取：2026-11-02T10:09:47.992591+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887654；已知时间：2026-11-02T10:09:49.622689+00:00；抓取：2026-11-02T10:09:49.622689+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887649；已知时间：2026-11-02T10:09:51.173044+00:00；抓取：2026-11-02T10:09:51.173044+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5887636；已知时间：2026-11-02T10:09:52.832810+00:00；抓取：2026-11-02T10:09:52.832810+00:00
- 来源：https://www.fotmob.com/api/data/teams?id=9772；已知时间：2026-11-02T10:05:24.228530+00:00；抓取：2026-11-02T10:05:24.228530+00:00
- 来源：https://www.fotmob.com/api/data/teams?id=9780；已知时间：2026-11-02T10:05:26.246728+00:00；抓取：2026-11-02T10:05:26.246728+00:00
missing：["field-level full coverage not certified; see source packets"]
- five_role_review：fail_closed_no_random_or_default_agent_probability
  外部调用次数：0；独立代理次数：0
- upset_classifier：ABSTAIN_MISSING_1X2_QUOTE
- upset_candidate：ABSTAIN_MISSING_1X2_QUOTE
- selection_experiment：EXPERIMENTAL
- minute_simulation：NOT_CONFIGURED
数值权重：未在本报告另行指定；数据缺失不填零。

## 综合选分检查

- 逐队比较0/1/2+进球路径
- 比较至少两个比分候选及反证
- 重点核查同机构同盘口水位变化与升降盘
- 胜平负、第一比分和实际大小球分别判断
- 引用双模型冻结，综合判断独立追加；缺数据如实标记

本报告是证据与执行状态报告，不自动将统计比分改名为综合第一推荐；综合结论须独立保存冻结。
