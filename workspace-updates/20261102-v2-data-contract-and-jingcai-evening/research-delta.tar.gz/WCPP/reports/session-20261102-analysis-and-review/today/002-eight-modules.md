# 单场赛事完整模块分析

赛事ID：espn:401874963；截止时间：2026-11-02T10:15:39.208024+00:00

模块有输出不代表数据齐全、五名外部代理已执行、状态模拟已训练或准确率提高

## 历史进失球、球队攻防、主客场

补充证据状态：available
原工件训练截止及样本覆盖见真实双模型输出；本轮新资料不冒充已训练。

本场事实：
```json
{
  "registry": "WCPP-DUAL-4"
}
```

- 来源：https://site.api.espn.com/apis/site/v2/sports/soccer/ita.1/scoreboard?dates=20261102；已知时间：2026-11-02T10:01:32+00:00；抓取：2026-11-02T10:01:32+00:00
- 来源：https://www.okooo.com/jingcai/；已知时间：2026-11-02T10:00:38.994664+00:00；抓取：2026-11-02T10:00:38.994664+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749727；已知时间：2026-11-02T10:07:44.841036+00:00；抓取：2026-11-02T10:07:44.841036+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749712；已知时间：2026-11-02T10:07:46.380068+00:00；抓取：2026-11-02T10:07:46.380068+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749704；已知时间：2026-11-02T10:07:47.828049+00:00；抓取：2026-11-02T10:07:47.828049+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749722；已知时间：2026-11-02T10:07:49.508895+00:00；抓取：2026-11-02T10:07:49.508895+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749714；已知时间：2026-11-02T10:07:51.138133+00:00；抓取：2026-11-02T10:07:51.138133+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749703；已知时间：2026-11-02T10:07:52.907193+00:00；抓取：2026-11-02T10:07:52.907193+00:00
- 来源：https://www.fotmob.com/api/data/teams?id=7943&ccode3=USA&season=2026%2F2027；已知时间：2026-11-02T10:06:15.441481+00:00；抓取：2026-11-02T10:06:15.441481+00:00
- 来源：https://www.fotmob.com/api/data/teams?id=8535&ccode3=USA&season=2026%2F2027；已知时间：2026-11-02T10:06:17.481121+00:00；抓取：2026-11-02T10:06:17.481121+00:00
missing：["field-level full coverage not certified; see source packets"]
- current：WCPP-MAIN-1.2；训练比赛截止 2026-09-20
  - home：均值 1.5524034942305904；P0 0.21173844961073704；P≥2 0.4595580413505871；P≥3 0.20441780335183854；区间 {'lower': 0, 'upper': 3, 'nominal_coverage': 0.8, 'width': 3, 'lower_quantile': 0.09999999999999998, 'upper_quantile': 0.9, 'matrix_coverage': 0.9276090623108554, 'method': 'EQUAL_TAIL_INTEGER_INVERSE_CDF_INCLUSIVE'}
  - away：均值 1.2476731623913233；P0 0.2871722231918053；P≥2 0.3545307009475282；P≥3 0.13101187809020728；区间 {'lower': 0, 'upper': 3, 'nominal_coverage': 0.8, 'width': 3, 'lower_quantile': 0.09999999999999998, 'upper_quantile': 0.9, 'matrix_coverage': 0.9619476007659193, 'method': 'EQUAL_TAIL_INTEGER_INVERSE_CDF_INCLUSIVE'}
- test：WCPP-ML-0.1；训练比赛截止 2026-09-20
  - home：均值 1.4942026522136334；P0 0.22442885664579662；P≥2 0.440231703489986；P≥3 0.18969984352822522；区间 {'lower': 0, 'upper': 3, 'nominal_coverage': 0.8, 'width': 3, 'lower_quantile': 0.09999999999999998, 'upper_quantile': 0.9, 'matrix_coverage': 0.9350822931104287, 'method': 'EQUAL_TAIL_INTEGER_INVERSE_CDF_INCLUSIVE'}
  - away：均值 1.1570016077635412；P0 0.31524666638166826；P≥2 0.32165138546846395；P≥3 0.11172385348954195；区间 {'lower': 0, 'upper': 3, 'nominal_coverage': 0.8, 'width': 3, 'lower_quantile': 0.09999999999999998, 'upper_quantile': 0.9, 'matrix_coverage': 0.969504410225241, 'method': 'EQUAL_TAIL_INTEGER_INVERSE_CDF_INCLUSIVE'}
数值权重：未在本报告另行指定；数据缺失不填零。

## 近期状态与比赛间隔

补充证据状态：partial
ESPN/FotMob身份与球队近期比赛清单已核（001身份待核）；联赛/杯赛分开，窗口见原始报告。

本场事实：
```json
{
  "evidence_root": "/workspace/WCPP/staging/jingcai-20261102-current-discovery"
}
```

- 来源：https://site.api.espn.com/apis/site/v2/sports/soccer/ita.1/scoreboard?dates=20261102；已知时间：2026-11-02T10:01:32+00:00；抓取：2026-11-02T10:01:32+00:00
- 来源：https://www.okooo.com/jingcai/；已知时间：2026-11-02T10:00:38.994664+00:00；抓取：2026-11-02T10:00:38.994664+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749727；已知时间：2026-11-02T10:07:44.841036+00:00；抓取：2026-11-02T10:07:44.841036+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749712；已知时间：2026-11-02T10:07:46.380068+00:00；抓取：2026-11-02T10:07:46.380068+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749704；已知时间：2026-11-02T10:07:47.828049+00:00；抓取：2026-11-02T10:07:47.828049+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749722；已知时间：2026-11-02T10:07:49.508895+00:00；抓取：2026-11-02T10:07:49.508895+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749714；已知时间：2026-11-02T10:07:51.138133+00:00；抓取：2026-11-02T10:07:51.138133+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749703；已知时间：2026-11-02T10:07:52.907193+00:00；抓取：2026-11-02T10:07:52.907193+00:00
- 来源：https://www.fotmob.com/api/data/teams?id=7943&ccode3=USA&season=2026%2F2027；已知时间：2026-11-02T10:06:15.441481+00:00；抓取：2026-11-02T10:06:15.441481+00:00
- 来源：https://www.fotmob.com/api/data/teams?id=8535&ccode3=USA&season=2026%2F2027；已知时间：2026-11-02T10:06:17.481121+00:00；抓取：2026-11-02T10:06:17.481121+00:00
missing：["field-level full coverage not certified; see source packets"]
数值权重：未在本报告另行指定；数据缺失不填零。

## 射门、射正、控球

补充证据状态：partial
近期比赛过程见FotMob原响应；本场尚未开球，无本场射门事实。

本场事实：
```json
{
  "evidence_root": "/workspace/WCPP/staging/jingcai-20261102-current-discovery"
}
```

- 来源：https://site.api.espn.com/apis/site/v2/sports/soccer/ita.1/scoreboard?dates=20261102；已知时间：2026-11-02T10:01:32+00:00；抓取：2026-11-02T10:01:32+00:00
- 来源：https://www.okooo.com/jingcai/；已知时间：2026-11-02T10:00:38.994664+00:00；抓取：2026-11-02T10:00:38.994664+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749727；已知时间：2026-11-02T10:07:44.841036+00:00；抓取：2026-11-02T10:07:44.841036+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749712；已知时间：2026-11-02T10:07:46.380068+00:00；抓取：2026-11-02T10:07:46.380068+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749704；已知时间：2026-11-02T10:07:47.828049+00:00；抓取：2026-11-02T10:07:47.828049+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749722；已知时间：2026-11-02T10:07:49.508895+00:00；抓取：2026-11-02T10:07:49.508895+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749714；已知时间：2026-11-02T10:07:51.138133+00:00；抓取：2026-11-02T10:07:51.138133+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749703；已知时间：2026-11-02T10:07:52.907193+00:00；抓取：2026-11-02T10:07:52.907193+00:00
- 来源：https://www.fotmob.com/api/data/teams?id=7943&ccode3=USA&season=2026%2F2027；已知时间：2026-11-02T10:06:15.441481+00:00；抓取：2026-11-02T10:06:15.441481+00:00
- 来源：https://www.fotmob.com/api/data/teams?id=8535&ccode3=USA&season=2026%2F2027；已知时间：2026-11-02T10:06:17.481121+00:00；抓取：2026-11-02T10:06:17.481121+00:00
missing：["field-level full coverage not certified; see source packets"]
工件记录的训练覆盖行数：{"current": null, "test": 0}；工件未登记的覆盖保持未知；0表示本工件无登记合格训练行，不表示未采集任何资料
数值权重：未在本报告另行指定；数据缺失不填零。

## xG / xGA

补充证据状态：partial
FotMob已核近期同源xG/xGA；big5窗口可能含杯赛并分开说明，other为近三场联赛；001/005未取得代表性xG。

本场事实：
```json
{
  "big5_evidence": "/workspace/WCPP/staging/jingcai-20261102-current-discovery/big5/evidence-summary.json",
  "other_evidence": "/workspace/WCPP/staging/jingcai-20261102-current-discovery/other/recent-league-xg-summary.json",
  "numeric_training_applied": false
}
```

- 来源：https://site.api.espn.com/apis/site/v2/sports/soccer/ita.1/scoreboard?dates=20261102；已知时间：2026-11-02T10:01:32+00:00；抓取：2026-11-02T10:01:32+00:00
- 来源：https://www.okooo.com/jingcai/；已知时间：2026-11-02T10:00:38.994664+00:00；抓取：2026-11-02T10:00:38.994664+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749727；已知时间：2026-11-02T10:07:44.841036+00:00；抓取：2026-11-02T10:07:44.841036+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749712；已知时间：2026-11-02T10:07:46.380068+00:00；抓取：2026-11-02T10:07:46.380068+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749704；已知时间：2026-11-02T10:07:47.828049+00:00；抓取：2026-11-02T10:07:47.828049+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749722；已知时间：2026-11-02T10:07:49.508895+00:00；抓取：2026-11-02T10:07:49.508895+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749714；已知时间：2026-11-02T10:07:51.138133+00:00；抓取：2026-11-02T10:07:51.138133+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749703；已知时间：2026-11-02T10:07:52.907193+00:00；抓取：2026-11-02T10:07:52.907193+00:00
- 来源：https://www.fotmob.com/api/data/teams?id=7943&ccode3=USA&season=2026%2F2027；已知时间：2026-11-02T10:06:15.441481+00:00；抓取：2026-11-02T10:06:15.441481+00:00
- 来源：https://www.fotmob.com/api/data/teams?id=8535&ccode3=USA&season=2026%2F2027；已知时间：2026-11-02T10:06:17.481121+00:00；抓取：2026-11-02T10:06:17.481121+00:00
missing：["field-level full coverage not certified; see source packets"]
工件记录的训练覆盖行数：{"current": null, "test": 0}；工件未登记的覆盖保持未知；0表示本工件无登记合格训练行，不表示未采集任何资料
数值权重：未在本报告另行指定；数据缺失不填零。

## 阵容、伤停、停赛

补充证据状态：partial
未公布首发不默认阻断；平台不可用人员与预计回归不等于官方确认。004重大风险待定。

本场事实：
```json
{
  "official_starting_XI_verified": false,
  "numeric_personnel_model_trained": false
}
```

- 来源：https://site.api.espn.com/apis/site/v2/sports/soccer/ita.1/scoreboard?dates=20261102；已知时间：2026-11-02T10:01:32+00:00；抓取：2026-11-02T10:01:32+00:00
- 来源：https://www.okooo.com/jingcai/；已知时间：2026-11-02T10:00:38.994664+00:00；抓取：2026-11-02T10:00:38.994664+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749727；已知时间：2026-11-02T10:07:44.841036+00:00；抓取：2026-11-02T10:07:44.841036+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749712；已知时间：2026-11-02T10:07:46.380068+00:00；抓取：2026-11-02T10:07:46.380068+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749704；已知时间：2026-11-02T10:07:47.828049+00:00；抓取：2026-11-02T10:07:47.828049+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749722；已知时间：2026-11-02T10:07:49.508895+00:00；抓取：2026-11-02T10:07:49.508895+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749714；已知时间：2026-11-02T10:07:51.138133+00:00；抓取：2026-11-02T10:07:51.138133+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749703；已知时间：2026-11-02T10:07:52.907193+00:00；抓取：2026-11-02T10:07:52.907193+00:00
- 来源：https://www.fotmob.com/api/data/teams?id=7943&ccode3=USA&season=2026%2F2027；已知时间：2026-11-02T10:06:15.441481+00:00；抓取：2026-11-02T10:06:15.441481+00:00
- 来源：https://www.fotmob.com/api/data/teams?id=8535&ccode3=USA&season=2026%2F2027；已知时间：2026-11-02T10:06:17.481121+00:00；抓取：2026-11-02T10:06:17.481121+00:00
missing：["field-level full coverage not certified; see source packets"]
数值权重：未在本报告另行指定；数据缺失不填零。

## 战意、旅行、完整赛程负荷

补充证据状态：partial
球队资料有前后赛程；未独立认证所有赛事覆盖、实际旅行/天气或数学战意。

本场事实：
```json
{
  "complete_all_competition_load_verified": false
}
```

- 来源：https://site.api.espn.com/apis/site/v2/sports/soccer/ita.1/scoreboard?dates=20261102；已知时间：2026-11-02T10:01:32+00:00；抓取：2026-11-02T10:01:32+00:00
- 来源：https://www.okooo.com/jingcai/；已知时间：2026-11-02T10:00:38.994664+00:00；抓取：2026-11-02T10:00:38.994664+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749727；已知时间：2026-11-02T10:07:44.841036+00:00；抓取：2026-11-02T10:07:44.841036+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749712；已知时间：2026-11-02T10:07:46.380068+00:00；抓取：2026-11-02T10:07:46.380068+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749704；已知时间：2026-11-02T10:07:47.828049+00:00；抓取：2026-11-02T10:07:47.828049+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749722；已知时间：2026-11-02T10:07:49.508895+00:00；抓取：2026-11-02T10:07:49.508895+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749714；已知时间：2026-11-02T10:07:51.138133+00:00；抓取：2026-11-02T10:07:51.138133+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749703；已知时间：2026-11-02T10:07:52.907193+00:00；抓取：2026-11-02T10:07:52.907193+00:00
- 来源：https://www.fotmob.com/api/data/teams?id=7943&ccode3=USA&season=2026%2F2027；已知时间：2026-11-02T10:06:15.441481+00:00；抓取：2026-11-02T10:06:15.441481+00:00
- 来源：https://www.fotmob.com/api/data/teams?id=8535&ccode3=USA&season=2026%2F2027；已知时间：2026-11-02T10:06:17.481121+00:00；抓取：2026-11-02T10:06:17.481121+00:00
missing：["field-level full coverage not certified; see source packets"]
数值权重：未在本报告另行指定；数据缺失不填零。

## 盘口、赔率与水位变化

补充证据状态：partial
002仅Pinnacle 3.0球单点真实时间快照，其余未得本批合格实盘；无同机构历史，不做水位趋势。

本场事实：
```json
{
  "quoted_at": "2026-11-02T18:07:38+08:00",
  "line": 3.0,
  "over": 1.93,
  "under": 1.98
}
```

- 来源：https://site.api.espn.com/apis/site/v2/sports/soccer/ita.1/scoreboard?dates=20261102；已知时间：2026-11-02T10:01:32+00:00；抓取：2026-11-02T10:01:32+00:00
- 来源：https://www.okooo.com/jingcai/；已知时间：2026-11-02T10:00:38.994664+00:00；抓取：2026-11-02T10:00:38.994664+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749727；已知时间：2026-11-02T10:07:44.841036+00:00；抓取：2026-11-02T10:07:44.841036+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749712；已知时间：2026-11-02T10:07:46.380068+00:00；抓取：2026-11-02T10:07:46.380068+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749704；已知时间：2026-11-02T10:07:47.828049+00:00；抓取：2026-11-02T10:07:47.828049+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749722；已知时间：2026-11-02T10:07:49.508895+00:00；抓取：2026-11-02T10:07:49.508895+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749714；已知时间：2026-11-02T10:07:51.138133+00:00；抓取：2026-11-02T10:07:51.138133+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749703；已知时间：2026-11-02T10:07:52.907193+00:00；抓取：2026-11-02T10:07:52.907193+00:00
- 来源：https://www.fotmob.com/api/data/teams?id=7943&ccode3=USA&season=2026%2F2027；已知时间：2026-11-02T10:06:15.441481+00:00；抓取：2026-11-02T10:06:15.441481+00:00
- 来源：https://www.fotmob.com/api/data/teams?id=8535&ccode3=USA&season=2026%2F2027；已知时间：2026-11-02T10:06:17.481121+00:00；抓取：2026-11-02T10:06:17.481121+00:00
missing：["field-level full coverage not certified; see source packets"]
同机构同盘口价格比较：{"status": "NO_SNAPSHOTS", "comparisons": [], "rejected_snapshots": 0, "prediction_modified": false, "money_flow_inferred": false}
数值权重：未在本报告另行指定；数据缺失不填零。

## 五角色审查、分钟模拟、冷门旁路

补充证据状态：partial
沿用原独立旁路状态；动态融合/球员影响/新选择器未完成，未调用五个外部LLM。

本场事实：
```json
{
  "new_v2_models_enabled": false
}
```

- 来源：https://site.api.espn.com/apis/site/v2/sports/soccer/ita.1/scoreboard?dates=20261102；已知时间：2026-11-02T10:01:32+00:00；抓取：2026-11-02T10:01:32+00:00
- 来源：https://www.okooo.com/jingcai/；已知时间：2026-11-02T10:00:38.994664+00:00；抓取：2026-11-02T10:00:38.994664+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749727；已知时间：2026-11-02T10:07:44.841036+00:00；抓取：2026-11-02T10:07:44.841036+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749712；已知时间：2026-11-02T10:07:46.380068+00:00；抓取：2026-11-02T10:07:46.380068+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749704；已知时间：2026-11-02T10:07:47.828049+00:00；抓取：2026-11-02T10:07:47.828049+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749722；已知时间：2026-11-02T10:07:49.508895+00:00；抓取：2026-11-02T10:07:49.508895+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749714；已知时间：2026-11-02T10:07:51.138133+00:00；抓取：2026-11-02T10:07:51.138133+00:00
- 来源：https://www.fotmob.com/api/data/matchDetails?matchId=5749703；已知时间：2026-11-02T10:07:52.907193+00:00；抓取：2026-11-02T10:07:52.907193+00:00
- 来源：https://www.fotmob.com/api/data/teams?id=7943&ccode3=USA&season=2026%2F2027；已知时间：2026-11-02T10:06:15.441481+00:00；抓取：2026-11-02T10:06:15.441481+00:00
- 来源：https://www.fotmob.com/api/data/teams?id=8535&ccode3=USA&season=2026%2F2027；已知时间：2026-11-02T10:06:17.481121+00:00；抓取：2026-11-02T10:06:17.481121+00:00
missing：["field-level full coverage not certified; see source packets"]
- five_role_review：fail_closed_no_random_or_default_agent_probability
  外部调用次数：0；独立代理次数：0
- upset_classifier：ABSTAIN_MISSING_1X2_QUOTE
- upset_candidate：ABSTAIN_MISSING_1X2_QUOTE
- selection_experiment：EXPERIMENTAL
- minute_simulation：NOT_CONFIGURED
数值权重：未在本报告另行指定；数据缺失不填零。

## 综合选分检查

- 逐队比较0/1/2+进球路径
- 比较至少两个比分候选及反证
- 重点核查同机构同盘口水位变化与升降盘
- 胜平负、第一比分和实际大小球分别判断
- 引用双模型冻结，综合判断独立追加；缺数据如实标记

本报告是证据与执行状态报告，不自动将统计比分改名为综合第一推荐；综合结论须独立保存冻结。
