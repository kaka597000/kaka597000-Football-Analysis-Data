import json,sys,datetime,hashlib
from pathlib import Path
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from predict_active import run
from research.analysis_freeze import save

root=Path(__file__).parent
out=root/'today'
src=Path('/workspace/WCPP/staging/jingcai-20261102-current-discovery')
rows=json.loads((src/'identity-and-status.json').read_text())['fixtures']
drafts={f['lottery_no'][-3:]:f for f in json.loads((out/'draft-fixtures.json').read_text())}
big=json.loads((src/'big5/evidence-summary.json').read_text())
other=json.loads((src/'other/recent-league-xg-summary.json').read_text())
team_ids={'001':[],'002':[7943,8535],'003':[8297,8349],'004':[8524,10167],'005':[6390,8481],'006':[10261,8668],'007':[9783,8371],'008':[9772,9780],'009':[109705,8514]}
big_manifest=json.loads((src/'big5/fotmob/details-manifest.json').read_text())
other_manifest=json.loads((src/'other/recent-match-xg-manifest.json').read_text())
big_teams=json.loads((src/'big5/fotmob/teams-manifest.json').read_text())
other_teams=json.loads((src/'other/team-api-manifest.json').read_text())
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
choices={
'001':(None,None,'澳客单源清单，ESPN/FotMob未确认该场身份；不把未匹配比赛硬套模型。','赛事身份与状态待核实。'),
'002':('1-1','平局','双方防守均弱，但萨索洛近三场联赛xG仅1.04、佛罗伦萨1.29；不因近期大比分就机械升球。两队联赛第15/17，近期均难形成稳定压制，平局和双向一球是本轮综合主路径。','萨索洛近三场xGA2.73、佛罗伦萨1.91，客队后防与主队中场人员平台列项尚未官方确认；2-1、1-2、2-2均为实质反证。'),
'003':('1-1','平局','GAIS近三场联赛xG/xGA1.19/1.81，AIK1.38/2.20；GAIS主场和原模型优势不足以稳推零封，AIK最近三场联赛均进2球但防守仍不稳，综合保留双向一球。','主队上场0.54xG仍赢球，近况受转化影响；AIK近客场对Sirius虽胜但被创造3.50xG。2-1及1-2均可能，伤停仅平台证据。'),
'004':(None,None,'数值基准虽偏亚特兰大，但平台列出Scamacca、Raspadori及多名后防人员不可用，尚缺可靠官方确认；属于足以改变比分选择的人员风险，先待定。','亚特兰大最近联赛2-2与4-4，不能仅因帕尔马进攻弱就沿用1-0或宣称必零封。'),
'005':(None,None,'两源身份已核，但法乙没有活动双模型，且本批未取得代表性近期xG和合格人员证据；只记录南锡近三场连胜、红星近两场失利的形势，不硬给比分。','空伤停列表不代表无人缺阵；不能借法甲模型或仅据排名补造概率。'),
'006':('2-1','主胜','近期杯赛埃弗顿3-1纽卡不能直接当联赛实力结论；该场FotMob机会为1.67-2.14，纽卡未因赛果失利就失去机会制造。回到主场结合现有两模型主胜为最高边际，保留有限主胜且客队一球。','纽卡最近两场联赛xG仅0.99/0.95，埃弗顿面对切尔西/阿森纳低xG也有对手强度影响；1-1为主要反证，3-1不是必须翻转的异常值。'),
'007':('1-1','平局','剔开杯赛对低级别对手的大胜，拉科最近两场联赛xG1.08/1.67，奥萨苏纳0.61/3.65且主客对手差异很大；积分同为11分，不把4.55/4.21杯赛xG直接搬入联赛。原模型零封须与客队一球路径比较，本次综合选双方一球。','拉科主场与原模型较强支持1-0/2-1；奥萨苏纳客场0.61xG支持客队零球，但两场窗口过小、人员待核，方向不稳。'),
'008':('2-1','主胜','本菲卡联赛9场7胜、26进8失，原两模型主胜约74%；主场长期优势支持主胜。近三场联赛xG/xGA1.61/1.17，Alverca2.19/0.89且比赛窗口跨度较大，客队不能简单按弱队清零；本次选2-1而非原模型2-0。','Alverca近期xG受对手与窗口影响，上场仅0.48；客队也可能零球，但本菲卡最近主场4-1对应xG1.42-1.57，零封证据不足。对方门将平台不可用条目和本菲卡轮换均未获官方确认，3-1、2-2为反证。'),
'009':('2-2','平局','Bragantino最近主场3-0有2.58xG支持；Santos近三场联赛xG1.81/2.56/2.07，进攻机会比仅看0-0和1-1赛果更强。结合两队近期均有较高被创造机会，本次保留双向两球路径，单列于原模型1-1基准。','主队近三场xG均值1.77、xGA2.02，客队2.15/1.81，均是小样本且不同主客对手；1-1、2-1概率不能忽略。Santos门将/防线平台列项有关键风险，低优先研究，不入本批优先名单。')}

receipts=[]
table=[]
for row in rows:
 n=row['lottery_no'][-3:]
 f=drafts.get(n)
 if f is None:
  f={'match_id':'okooo:'+row['okooo_match_id'],'cohort':'fin.1','competition':'fin.1','gender':'men','age':'senior','kickoff_at':row['kickoff_source_local'].replace(' ','T')+'+08:00','phase':'PreMatch','stage':'regular','neutral':None,'identity_verified':False,'display_home':row['full_names'][0],'display_away':row['full_names'][1],'sources':[{'source_url':'https://www.okooo.com/jingcai/','query_time':'2026-11-02T10:00:38.994664+00:00'}]}
 f=dict(f,cutoff_at=now)
 ids=team_ids[n]
 match_ids={r['match_id'] for r in big['recent_matches'] if r.get('team_id') in ids}
 supplemental=[]
 for item in big_manifest:
  if item.get('matchId') in match_ids:
   c=item['call'];supplemental.append({'source_url':c['url'],'query_time':c['query_time']})
 for item in other_manifest:
  if item.get('team_id') in ids:supplemental.append({'source_url':item['url'],'query_time':item['query_time']})
 for item in big_teams+other_teams:
  if item.get('fotmob_team_id') in ids:
   c=item.get('call',item);supplemental.append({'source_url':c['url'],'query_time':c['query_time']})
 f['sources']=f['sources']+supplemental
 f['source_fallback']={'reason':'5Dollar lottery endpoint HTTP403 insufficient_plan; Understat current refresh failed for big5; use observed ESPN/FotMob evidence with gaps disclosed.','source_urls':[s['source_url'] for s in f['sources']]}
 request=json.loads((src/'5dollar-jingcailottery.json').read_text())['request']
 f['source_calls']=[dict(provider='5DollarFootballAPI',url=request['url'],query_time=request['query_time'],match_id=f['match_id'],http_status=403,api_success=False,retrieved_fields=[],analysis_fields=[],model_input_fields=[],error_code='INSUFFICIENT_PLAN')]
 primary,wdl,reason,risk=choices[n]
 # These blocks describe observed evidence; no new xG/personnel weight is applied.
 kinds={
 'history':('available','原工件训练截止及样本覆盖见真实双模型输出；本轮新资料不冒充已训练。',{'registry':'WCPP-DUAL-4'}),
 'form':('partial','ESPN/FotMob身份与球队近期比赛清单已核（001身份待核）；联赛/杯赛分开，窗口见原始报告。',{'evidence_root':str(src)}),
 'shots':('partial','近期比赛过程见FotMob原响应；本场尚未开球，无本场射门事实。',{'evidence_root':str(src)}),
 'xg':('partial','FotMob已核近期同源xG/xGA；big5窗口可能含杯赛并分开说明，other为近三场联赛；001/005未取得代表性xG。',{'big5_evidence':str(src/'big5/evidence-summary.json'),'other_evidence':str(src/'other/recent-league-xg-summary.json'),'numeric_training_applied':False}),
 'lineup':('partial','未公布首发不默认阻断；平台不可用人员与预计回归不等于官方确认。004重大风险待定。',{'official_starting_XI_verified':False,'numeric_personnel_model_trained':False}),
 'context':('partial','球队资料有前后赛程；未独立认证所有赛事覆盖、实际旅行/天气或数学战意。',{'complete_all_competition_load_verified':False}),
 'market':('partial','002仅Pinnacle 3.0球单点真实时间快照，其余未得本批合格实盘；无同机构历史，不做水位趋势。',{'quoted_at':'2026-11-02T18:07:38+08:00' if n=='002' else None,'line':3.0 if n=='002' else None,'over':1.93 if n=='002' else None,'under':1.98 if n=='002' else None}),
 'research':('partial','沿用原独立旁路状态；动态融合/球员影响/新选择器未完成，未调用五个外部LLM。',{'new_v2_models_enabled':False})}
 f['analysis_modules']={k:{'match_id':f['match_id'],'status':st,'as_of':now,'summary':su,'facts':facts,'sources':[dict(source_url=s['source_url'],known_at=s['query_time'],query_time=s['query_time']) for s in f['sources']],'missing':['field-level full coverage not certified; see source packets']} for k,(st,su,facts) in kinds.items()}
 if n in ['001','005']:
  for k in ['history','shots','xg']:f['analysis_modules'][k]={'match_id':f['match_id'],'status':'unknown','as_of':now,'summary':'本批无合格模型或代表性字段，保持未知。','missing':['not available']}
 f['evidence_packet']={'root':str(src),'latest_xg_numeric_trained':False,'new_v2_models_enabled':False,'lineup_type':'UNCONFIRMED_SCENARIOS','market_history_available':False}
 (out/(n+'-fixture.json')).write_text(json.dumps(f,ensure_ascii=False,indent=2))
 pair=None
 try:
  if not f['identity_verified']:raise ValueError('fixture identity unverified; numerical prediction not attempted')
  # A prior unissued baseline freeze for 002 is retained; append a source-annotation
  # correction rather than editing its immutable record. Numerical values unchanged.
  if (out/(n+'-pair.json')).exists():
   f['evidence_packet']['prior_unissued_source_annotation_correction']='Added actual FotMob source URLs/times; original numeric baseline preserved in freeze chain.'
  pair=run(f)
  pr=save(pair,f,stage='prematch',track='current-test-pair')
  pair['freeze_receipt']=pr
  (out/(n+'-pair.json')).write_text(json.dumps(pair,ensure_ascii=False,indent=2))
  from research.match_analysis import render
  (out/(n+'-eight-modules.md')).write_text(render(pair['match_analysis']))
 except ValueError as ex:
  pr=save({'status':'ABSTAIN_BOTH','reason':str(ex),'actual_matrices_available':False},f,stage='prematch',track='current-test-pair')
  (out/(n+'-model-unavailable.json')).write_text(json.dumps({'reason':str(ex),'receipt':pr},ensure_ascii=False,indent=2))
 f=dict(f,cutoff_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
 payload={'method':'WCPP-COMPREHENSIVE-EVIDENCE-20261102-EVENING','status':'PRIMARY_SELECTED' if primary else 'ABSTAIN','primary':primary,'wdl':wdl,'total_line':3.0 if n=='002' else None,'total_direction':None,'total_reason':'002仅3.0快照：机会生成偏低与防守高失球相冲突，独立观望；其他无合格实盘，观望。不从点比分推出大小球。','reason':reason,'risk':risk,'manual_primary_is_calibrated':False,'primary_probability':None,'new_v2_models_enabled':False,'numerical_model_changed':False,'source_evidence_root':str(src),'current_test_reference':pr if pair else None,'selection_evidence':{'compared_scores':list(dict.fromkeys([primary,'1-1','2-1','1-2','2-2','3-1','2-0'])) if primary else ['1-1','2-1','1-2'],'zero_vs_one':{},'three_plus_path':'显式比较2-1、2-2及3-1；近期xG、主客及比赛状态可支持高球，但不机械统一加球。'+risk,'total_reason':'实际盘线证据不足或方向反证未解决；不虚构2.5盘口，大小球观望。'},'model_freshness':'LAGGING_BASELINE; latest observed rounds not trained','xg_usage':'QUALITATIVE_ONLY; same-provider observations retained; no new numerical training','lineup_policy':'UNANNOUNCED_NOT_AUTOMATIC_BLOCK; MATERIAL_RISK_004_ABSTAIN','market_history':'NOT_AVAILABLE; one timestamp is not a movement series'}
 cr=save(payload,f,stage='prematch',track='comprehensive')
 (out/(n+'-comprehensive.json')).write_text(json.dumps({'fixture':f,'payload':payload,'receipt':cr},ensure_ascii=False,indent=2))
 rec={'lottery_no':row['lottery_no'],'match_id':f['match_id'],'home':row['full_names'][0],'away':row['full_names'][1],'kickoff_beijing':row['kickoff_source_local'],'current_primary':pair['current_model']['primary'] if pair else None,'test_primary':pair['test_model']['primary'] if pair else None,'comprehensive_primary':primary,'wdl':wdl,'total_line':payload['total_line'],'total_direction':None,'reason':reason,'risk':risk,'paired_receipt':pr,'comprehensive_receipt':cr}
 table.append(rec);receipts.extend([pr,cr])

# Priority is relative within this batch; no need to fill three entries.
selected=next(z for z in table if z['lottery_no']=='周一008')
first=min(z['kickoff_beijing'] for z in table)
batch={'match_id':'jingcai:20261102:evening-top','cohort':'BATCH','kickoff_at':first.replace(' ','T')+'+08:00','cutoff_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
top={'scope':'本批9场；仅本菲卡一场列研究优先，其余因身份、代表性/人员/盘口及选择稳定性限制不强凑TOP3。','top3':[{'rank':1,'match_id':selected['match_id'],'primary':selected['comprehensive_primary'],'wdl':selected['wdl'],'total_line':None,'total_direction':None,'reason':selected['reason'],'risk':selected['risk'],'comprehensive_reference':selected['comprehensive_receipt']}]}
tr=save(top,batch,stage='prematch',track='top3-selection')
(out/'top-priority.json').write_text(json.dumps({'payload':top,'receipt':tr},ensure_ascii=False,indent=2))
(out/'final-summary.json').write_text(json.dumps(table,ensure_ascii=False,indent=2))
(out/'freeze-receipts.json').write_text(json.dumps(receipts+[tr],ensure_ascii=False,indent=2))
print(json.dumps({'matches':len(table),'paired_numeric':sum(z['current_primary'] is not None for z in table),'comprehensive_selected':sum(z['comprehensive_primary'] is not None for z in table),'top_priority':1,'frozen_at':tr['recorded_at'],'top_freeze_id':tr['freeze_id']},ensure_ascii=False))
