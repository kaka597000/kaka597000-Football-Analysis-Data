import sys,json,hashlib,copy
from pathlib import Path
from datetime import datetime,timezone
from zoneinfo import ZoneInfo
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from jleague_cup import quarterfinals as q
from prediction_service import run
from research.analysis_freeze import save,verify
B=Path('/workspace/jcup-display-20261111');old=Path('/workspace/jleague-cup-today-20261111');models={x['fixture']['match_id']:x for x in q.read(B/'model-display.json')};editorial=q.read(B/'editorial.json');recent=q.read(old/'verified-recent-j1.json')
# Root validation uses actual retained raw responses and event objects, not derived collector IDs.
sources=[];fresh=q.read(B/'staging/fresh-sources.json');fresh=fresh.get('sources',fresh.get('records')) if isinstance(fresh,dict) else fresh
for s in q.read(old/'staging/sources.json')['sources']+fresh:
 s=dict(s);p=s.get('raw_path')
 if p:
  p=Path(p)
  if not p.is_absolute():p=(B/'staging'/p) if (B/'staging'/p).exists() else old/'staging'/p
  expected=s.get('sha256') or s.get('raw_sha256');assert hashlib.sha256(p.read_bytes()).hexdigest()==expected;s['raw_path']=str(p)
 sources.append({'id':'S'+str(len(sources)+1).zfill(2),'provider':s.get('provider','public source'),'url':s.get('url',s.get('source_url')),'time_bjt':datetime.fromisoformat(s.get('requested_at_utc',s.get('query_time')).replace('Z','+00:00')).astimezone(ZoneInfo('Asia/Shanghai')).isoformat(),'status':str(s.get('http_status',s.get('status','unknown'))),'use':s.get('note',s.get('use','保留原文；用途依逐场分析及缺项说明')),'sha256':s.get('sha256',s.get('raw_sha256')),'raw_path':s.get('raw_path')})
source_by_url={s['url']:s for s in sources};cert=q.certificate('/workspace/jcup-qf-expansion-20261111/rules-certificate.json');out=[]
for mid in ['jleague:111101','jleague:111103','jleague:111104','jleague:111102']:
 m=models[mid];e=editorial[mid];f=copy.deepcopy(m['fixture']);s=source_by_url[f['phase_evidence']['source_url']];assert s['time_bjt']>'2026-11-11T10:29:00+08:00','fresh official request required'
 f['phase_evidence']={'raw_path':s['raw_path'],'raw_sha256':s['sha256'],'source_url':s['url'],'query_time':s['time_bjt']};f['cutoff_at']=datetime.now(timezone.utc).isoformat();q.target_identity(f,cert)
 oldf=q.read(old/(mid.replace(':','-')+'-model-status.json'))['fixture'];activef=copy.deepcopy(oldf);activef['cutoff_at']=f['cutoff_at'];activef['phase_evidence']=f['phase_evidence']
 try:active=run(activef)
 except ValueError as err:
  assert str(err)=='no validated identity/history model for this cohort'
  active={'match_id':mid,'status':'ABSTAIN_NO_ACTIVE_COHORT','actual_entrypoint_attempt':'prediction_service.run','reason':str(err),'registry_sha256':q.evidence.sha('/workspace/WCPP/runtime/active-model.json'),'current_model':{'status':'ABSTAIN_NO_ACTIVE_COHORT','matrix':None,'primary':None,'training_data_cutoff':None},'test_model':{'status':'ABSTAIN_NO_ACTIVE_COHORT','matrix':None,'primary':None,'training_data_cutoff':None},'model_promotion':False}
 active_receipt=save(active,activef,stage='prematch',track='current-test-pair')
 f['cutoff_at']=datetime.now(timezone.utc).isoformat()
 payload={'version':'JCUP-COMPREHENSIVE-DISPLAY-20261111-v2','primary':e['primary'],'wdl':e['wdl'],'total_line':None,'total_direction':None,'current_test_reference':active_receipt,'research_candidate_reference':m['research_freeze_reference'],'status':'RESEARCH_SELECTION' if e['primary'] else 'ABSTAIN_CRITICAL_UNCERTAINTY','selection_evidence':{'compared_scores':e['compared_scores'],'zero_vs_one':e['zero_vs_one'],'three_plus_path':e['three_plus_path'],'total_reason':'没有合格实盘及报价时点，全部观望；不自设盘口。','reason':e['selection']},'editorial':e,'research_model_display':m['roles'],'sources':sources,'xg_status':'NOT_AVAILABLE_CURRENT_WINDOW','injury_status':'PARTIAL_OFFICIAL_PREVIEW_NOT_COMPLETE','fresh_source_audit':q.read(B/'staging/evidence-summary.json'),'formal_kpi_eligible':False,'model_promotion':False,'top3_eligible':False,'revision_policy':'append only; original first prematch remains primary evaluation; no hindsight selection'}
 receipt=save(payload,f,stage='prematch',track='comprehensive')
 out.append({'fixture':f,'kickoff_bjt':datetime.fromisoformat(f['kickoff_at'].replace('Z','+00:00')).astimezone(ZoneInfo('Asia/Shanghai')).isoformat(),'editorial':e,'models':m['roles'],'research_freeze_reference':m['research_freeze_reference'],'active_receipt':active_receipt,'comprehensive_receipt':receipt})
bf={'match_id':'jleague-cup-20261111-batch','kickoff_at':min(x['fixture']['kickoff_at'] for x in out),'cutoff_at':datetime.now(timezone.utc).isoformat()}
br=save({'top3':[],'reason':'No applicable active paired model or verified current market lines; four matches retained','comprehensive_records':[x['comprehensive_receipt'] for x in out],'research_first_scores':{x['fixture']['match_id']:x['editorial']['primary'] for x in out}},bf,stage='prematch',track='top3-selection')
allrefs=[br]+[d[k] for d in out for k in ('research_freeze_reference','active_receipt','comprehensive_receipt')]
for r in allrefs:assert verify(q.read(r['path']))['record_sha256']==r['sha256']
data={'created_at_bjt':datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),'matches':out,'sources':sources,'recent':recent,'batch_receipt':br,'drive_status':'NOT_UPLOADED_NO_CALLABLE_TOOL','validation':{'recent_rows_verified':40,'research_pairs_reloaded_exact':4,'freeze_records_verified':len(allrefs),'official_same_event_identity_verified':4,'formal_acceptance_passed':False}}
(B/'delivery-data.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
lines=['# 2026年11月11日日联杯赛前分析','', '北京时间；八强首回合；只判断90分钟。研究候选未验收，活动模型无适用路由。','', '|开球|对阵|综合比分|胜平负|实际大小球|','|---|---|---|---|---|']
for d in out:
 e=d['editorial'];lines.append('|'+d['kickoff_bjt'][11:16]+'|'+e['match']+'|'+(e['primary'] or '待定')+'|'+({'负':'柏客胜','平':'平局'}.get(e['wdl'],'待定'))+'|观望：实盘未核实|')
for d in out:
 e=d['editorial'];lines+=['','## '+e['match'],'','|研究轨道/球队|进球均值|中央80%区间（实际概率质量）|0球|至少2球|至少3球|','|---|---|---|---|---|---|']
 for role in ['current','test']:
  for side,name in [('home','主队'),('away','客队')]:
   v=d['models'][role]['display_distribution'][side];lines.append(f"|{role}/{name}|{v['mean']:.2f}|{v['interval80'][0]}–{v['interval80'][1]}（{v['interval_mass']:.1%}）|{v['p0']:.1%}|{v['p2plus']:.1%}|{v['p3plus']:.1%}|")
 for k in ['recent','path','evidence','selection','three_plus_path','risk']:lines+=['',e[k]]
 lines+=['','[官方预览]('+d['fixture']['phase_evidence']['source_url']+')；ESPN近期联赛与过程原文见工作簿来源页。','综合修订冻结：'+d['comprehensive_receipt']['freeze_id']+'；'+d['comprehensive_receipt']['recorded_at']+'。']
lines+=['','## 模型与缺项','', '数值来自已冻结的八强研究候选，统计众数均1–1；首回合训练截止2025-09-03，仅12场，留出4场各命中1场。无近期xG/伤停/盘口数值训练，场地未知，大阪樱花使用总体先验。新鲜赛前事实仅影响定性综合判断，不能当作模型已学习。', '', '近期五轮仅指J1，非全赛事负荷。单场射门不是xG；完整伤停与实盘仍缺失。两条人工研究比分不冒充已验收推荐。','', '本批合格TOP3为0场，不强凑；保留四场完整分母。首版与修订分别结算，不择优。','', '批次冻结：'+br['freeze_id']+'；北京时间 '+br['recorded_at']+'。', '', 'Drive／Sheets在线副本尚未创建；XLSX为可导入展示副本。']
(B/'analysis.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({'matches':len(out),'batch':br,'verified_records':len(allrefs)},ensure_ascii=False))
