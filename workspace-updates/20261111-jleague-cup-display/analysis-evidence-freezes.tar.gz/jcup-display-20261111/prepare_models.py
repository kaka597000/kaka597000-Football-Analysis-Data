import sys,json,hashlib
from pathlib import Path
from datetime import datetime,timezone
import numpy as np
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from jleague_cup import quarterfinals as q
from research.analysis_freeze import verify
b=Path('/workspace/jcup-display-20261111');old=Path('/workspace/jcup-qf-expansion-20261111')
index=q.read(old/'final-models/candidates.json');rows=[]
for p in sorted((old/'forward-freezes').glob('*.json')):
 d=q.read(p)
 if 'fixture' not in d:continue
 ref=d['freeze_receipt'];record=verify(q.read(ref['path']));assert record['record_sha256']==ref['sha256'];assert record['payload']==d['payload']
 f=d['fixture'];r={'fixture':f,'research_freeze_reference':ref,'roles':{}}
 for role in ('current','test'):
  refa=index['routes']['1']['artifacts'][role];assert q.evidence.sha(refa['path'])==refa['sha256'];pred=q.predict(refa['path'],f);assert pred==d['payload'][role]
  m=np.asarray(pred['matrix']);assert abs(m.sum()-1)<1e-10
  dist={}
  for side,axis in [('home',1),('away',0)]:
   v=m.sum(axis=axis);cdf=v.cumsum();lo=int(np.searchsorted(cdf,.1));hi=int(np.searchsorted(cdf,.9));dist[side]={'mean':float(np.dot(np.arange(len(v)),v)),'interval80':[lo,hi],'interval_mass':float(v[lo:hi+1].sum()),'p0':float(v[0]),'p2plus':float(v[2:].sum()),'p3plus':float(v[3:].sum())}
  pred['display_distribution']=dist;pred['wdl_probabilities']={'home':float(np.tril(m,-1).sum()),'draw':float(np.trace(m)),'away':float(np.triu(m,1).sum())};pred['p_total3plus']=float(sum(m[h,a] for h in range(len(m)) for a in range(len(m)) if h+a>=3))
  r['roles'][role]=pred
 rows.append(r)
(b/'model-display.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
print(json.dumps({'verified_model_pairs':len(rows),'model_cutoff':rows[0]['roles']['current']['training_data_cutoff'],'expected_goals_first_pair':rows[0]['roles']['test']['expected_goals']}))
