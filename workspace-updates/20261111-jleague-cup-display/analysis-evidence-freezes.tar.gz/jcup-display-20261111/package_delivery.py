from pathlib import Path
import json,hashlib,tarfile,os,shutil,subprocess
from datetime import datetime
from zoneinfo import ZoneInfo
B=Path('/workspace/jcup-display-20261111');R=Path('/workspace/kaka597000-Football-Analysis-Data');D=R/'workspace-updates/20261111-jleague-cup-display';D.mkdir(exist_ok=True)
data=json.loads((B/'delivery-data.json').read_text());files=set()
for p in B.rglob('*'):
 if p.is_file() and '__pycache__' not in p.parts and p.name not in ['drive-folder-access.txt','drive-folder-access.png','drive-access-retest.png']:files.add(p)
for s in data['sources']:
 if s.get('raw_path'):files.add(Path(s['raw_path']))
refs=[data['batch_receipt']]+[d[k] for d in data['matches'] for k in ['active_receipt','comprehensive_receipt','research_freeze_reference']]
for r in refs:
 for p in Path(r['path']).parent.glob('[0-9]*.json'):files.add(p)
secrets=[v.encode() for k,v in os.environ.items() if any(x in k.upper() for x in ['API_KEY','TOKEN','SECRET','PASSWORD']) and len(v)>12]
for k in ['bsd','openfoot','_5DOLLARS','THE_ODDS','footballdata_org','infer_yapan_zhishu','apifootball','therundown']:
 if len(os.environ.get(k,''))>12:secrets.append(os.environ[k].encode())
entries=[]
for p in sorted(files):
 raw=p.read_bytes();assert not any(s in raw for s in secrets),'credential value detected'
 entries.append({'workspace_path':str(p),'archive_path':str(p.relative_to('/workspace')),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)})
a=D/'analysis-evidence-freezes.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for e in entries:t.add(e['workspace_path'],arcname=e['archive_path'],recursive=False)
with tarfile.open(a) as t:
 for e in entries:assert hashlib.sha256(t.extractfile(e['archive_path']).read()).hexdigest()==e['sha256']
for src in [B/'analysis.md',B/'display/日联杯赛前分析_20261111.xlsx',B/'display/workbook-preview.png',B/'drive-access-retest.json']:shutil.copy2(src,D/src.name)
manifest={'source_commit':subprocess.check_output(['git','-C','/workspace/Football-Analysis','rev-parse','HEAD'],text=True).strip(),'created_at_bjt':datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),'target_drive_folder':'https://drive.google.com/drive/folders/1vEY9SNgIr6kOL4W-EBdUDB4aFSYUEIKx','drive_folder_readable':True,'drive_uploaded':False,'sheets_created':False,'delivery_blocker':'NO_AUTHENTICATED_UPLOAD_INTERFACE_AND_NO_DRIVE_CONNECTOR_TOOL','batch_freeze':data['batch_receipt'],'validation':dict(data['validation'],workbook_sheets=8,workbook_readback_passed=True,archive_hashes_verified=len(entries)),'archive_sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'files':entries,'dependencies':['workspace-updates/20261111-jleague-cup-quarterfinals/manifest.json','workspace-updates/20261111-jleague-cup-prematch/manifest.json'],'model_promotion':False}
(D/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
(D/'README.md').write_text('# 日联杯赛前分析与Sheets展示副本\n\n2026-11-11北京时间10:38追加冻结修订，四场完整保留。8页XLSX已读回校验，可上传Google Drive后用Sheets打开；PNG是工作簿内容预览，不是Google Sheets在线截图。\n\n目标文件夹“足球数据看板展示”在10:39复测可浏览，但没有已登录上传入口且会话无Drive/Sheets写入工具，因此尚未上传、未生成在线表格。\n\n综合研究：横滨–鹿岛1–1、川崎–柏1–2，另两场待定，全部实盘大小球观望；活动模型仍拒绝，八强研究候选独立展示且未验收。历史首次预测不被替代；本次为单列修订。\n\n原始证据与冻结链在压缩包，逐文件SHA在manifest。归档为/workspace相对路径，恢复须在独立目录核查，不覆盖现有资产。源代码未修改，模型未重训。\n')
p=R/'latest-source.json';v=json.loads(p.read_text());folder=str(D.relative_to(R));v['additional_workspace_updates']=list(dict.fromkeys(v.get('additional_workspace_updates',[])+[folder]));v['latest_jleague_cup_display']=folder+'/manifest.json';v['synchronized_at']=datetime.now(ZoneInfo('Asia/Shanghai')).isoformat();p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
out=Path('/workspace/shared');out.mkdir(exist_ok=True)
for src,name in [(B/'display/日联杯赛前分析_20261111.xlsx','jleague-cup-20261111.xlsx'),(B/'display/workbook-preview.png','jleague-cup-preview.png'),(B/'analysis.md','jleague-cup-analysis-20261111.md')]:shutil.copy2(src,out/name)
print(json.dumps({'archive_files':len(entries),'archive_bytes':a.stat().st_size,'freeze':data['batch_receipt']['freeze_id'],'outputs':str(out)},ensure_ascii=False))
