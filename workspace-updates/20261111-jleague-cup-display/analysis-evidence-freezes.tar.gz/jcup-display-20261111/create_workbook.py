import json,pathlib,datetime,html,shutil
from openpyxl import Workbook,load_workbook
from openpyxl.styles import Font,PatternFill,Alignment,Border,Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table,TableStyleInfo
B=pathlib.Path('/workspace/jcup-display-20261111');data=json.loads((B/'delivery-data.json').read_text());out=B/'display';out.mkdir(exist_ok=True)
wb=Workbook();wb.remove(wb.active)
navy='142D4E';teal='007F80';muted='596B80';gold='FFF1CD';light='F2F6FA'
def sheet(name,title,sub,headers,rows,widths):
 s=wb.create_sheet(name);n=len(headers);s.sheet_view.showGridLines=False;s.sheet_properties.pageSetUpPr.fitToPage=True
 for r,text in [(1,title),(2,sub)]:
  s.merge_cells(start_row=r,start_column=1,end_row=r,end_column=n);c=s.cell(r,1,text);c.fill=PatternFill('solid',fgColor=navy if r==1 else light);c.font=Font(name='Arial',size=20 if r==1 else 11,bold=r==1,color='FFFFFF' if r==1 else muted);c.alignment=Alignment(vertical='center',wrap_text=True)
 s.row_dimensions[1].height=42;s.row_dimensions[2].height=44
 for c,h in enumerate(headers,1):s.cell(4,c,h)
 for row in rows:s.append(row)
 # append starts at row 5 because row 4 is populated
 for r in s.iter_rows(min_row=4):
  for c in r:
   c.font=Font(name='Arial',size=11,color='FFFFFF' if c.row==4 else navy,bold=c.row==4)
   c.fill=PatternFill('solid',fgColor=teal if c.row==4 else ('FFFFFF' if c.row%2 else light));c.alignment=Alignment(vertical='top',wrap_text=True)
   if c.row>4 and isinstance(c.value,str) and c.value in ['待定','观望','不可用','未上传'] :c.fill=PatternFill('solid',fgColor=gold)
 s.row_dimensions[4].height=28
 for r in range(5,s.max_row+1):s.row_dimensions[r].height=64 if name=='今日总览' else 48
 for i,w in enumerate(widths,1):s.column_dimensions[get_column_letter(i)].width=w
 s.freeze_panes='C5';s.auto_filter.ref=f'A4:{get_column_letter(n)}{s.max_row}';s.print_title_rows='1:4';s.page_setup.orientation='landscape';s.page_setup.paperSize=s.PAPERSIZE_A3;s.page_setup.fitToWidth=1;s.page_setup.fitToHeight=0
 return s
rows=[]
for d in data['matches']:
 e=d['editorial'];rows.append([d['kickoff_bjt'][11:16],e['match'],e['primary'] or '待定',{'平':'平局','负':'柏客胜'}.get(e['wdl'],'待定'),'观望',e['observation'],e['risk'],'研究参考／未验收'])
s=sheet('今日总览','日联杯｜今日赛前观察','2026年11月11日 · 北京时间 · 八强首回合 · 仅90分钟｜综合判断与统计研究独立展示',['开球','对阵','综合第一比分','胜平负','实盘大小球','判断','主要风险','状态'],rows,[10,30,15,14,15,38,62,24])
s.merge_cells('A11:H11');s['A11']='本批合格TOP3：0场。四场实盘均未核实；活动模型无适用路由。保留全批4场，不强凑排名。';s['A11'].font=Font(size=12,bold=True,color='9A5600');s['A11'].fill=PatternFill('solid',fgColor=gold);s['A11'].alignment=Alignment(wrap_text=True);s.row_dimensions[11].height=40
s.merge_cells('A13:H13');s['A13']='更新冻结：'+data['batch_receipt']['freeze_id']+'｜'+data['batch_receipt']['recorded_at'][:19].replace('T',' ')+' 北京时间';s['A13'].font=Font(size=11,color=muted)
s.merge_cells('A14:H14');s['A14']='展示副本：可导入Google Sheets。当前尚无Drive上传回执，未创建在线文件。';s['A14'].font=Font(size=11,color=muted)
r=[]
for d in data['matches']:
 e=d['editorial']
 for k,label in [('recent','近期J1事实'),('path','双方进球与互动路径'),('evidence','过程与人员证据'),('selection','比分比较与选择'),('three_plus_path','三球以上替代路径'),('risk','主要反证与缺项')]:r.append([e['match'],label,e[k],'https://www.jleague.jp/match/leaguecup/2026/'+d['fixture']['match_id'].split(':')[1]+'/'])
s=sheet('逐场分析','逐场分析｜事实、路径与反证','近期战绩仅为最近5轮J1，不是全赛事；射门不等于xG；所有研究模型未学习本轮人员信息。',['对阵','分析项','内容','官方预览'],r,[30,25,115,65]);
for i in range(5,s.max_row+1):s.row_dimensions[i].height=78
r=[]
for d in data['matches']:
 for role in ['current','test']:
  m=d['models'][role];p=m['wdl_probabilities'];r.append([d['editorial']['match'],'研究候选 '+role,'–'.join(map(str,m['statistical_top1'])),p['home'],p['draw'],p['away'],m['p_total3plus'],m['training_data_cutoff'],'未纳入2026最新轮次；非活动模型',d['research_freeze_reference']['freeze_id']])
s=sheet('研究模型对照','研究模型｜四场统计众数均1–1','首回合仅12场训练、4场留出：current/test各命中1场。数值是模型内概率，不是经过验证的真实胜率。',['对阵','轨道','统计Top1','主胜概率','平局概率','客胜概率','总球≥3','训练截止','适用限制','原研究冻结ID'],r,[30,23,16,15,15,15,15,17,47,34])
for row in s.iter_rows(min_row=5):
 for c in row[3:7]:c.number_format='0.0%'
r=[]
for d in data['matches']:
 for role in ['current','test']:
  m=d['models'][role]
  for side,name in [('home','主队'),('away','客队')]:
   v=m['display_distribution'][side];r.append([d['editorial']['match'],'研究 '+role,name,v['mean'],'–'.join(map(str,v['interval80'])),v['interval_mass'],v['p0'],v['p2plus'],v['p3plus'],'模型期望≠历史xG；离散区间非硬边界'])
s=sheet('单队进球分布','单队进球｜先看分布，再讨论比分','区间为10%–90%等尾分位数；实际概率质量可能高于80%，未验证为真实覆盖率。缺失场地未默认非中立。',['对阵','轨道','主客','进球均值','中央80%区间','区间实际质量','0球概率','至少2球','至少3球','说明'],r,[30,18,10,14,20,18,16,16,16,48])
for row in s.iter_rows(min_row=5):
 row[3].number_format='0.00'
 for c in row[5:9]:c.number_format='0.0%'
r=[]
for x in data['recent']:
 r.append([x['actual_name'],x['w'],x['d'],x['l'],x['gf'],x['ga'],x['matches'][0]['date_bjt'][:10],x['matches'][-1]['date_bjt'][:10],'近5轮J1，非全赛事',x['source']['url']])
sheet('近期事实','近期事实｜8队各5轮J1','40条比赛比分已逐条重新对照原始ESPN响应；不能用这张表认证完整负荷、xG或杯赛训练覆盖。',['球队','胜','平','负','进球','失球','窗口开始','窗口结束','口径','来源'],r,[28,10,10,10,12,12,17,17,29,90])
r=[]
for x in data['sources']:
 r.append([x['id'],x.get('provider',''),x['url'],x.get('time_bjt','未知'),x.get('status',''),x.get('use',''),x.get('sha256',''),x.get('raw_path','')])
s=sheet('来源与缺项','来源｜可追溯的证据与访问结果','旧缓存保留真实原抓取时点；缺字段≠数值为零。查询时间不等于盘口报价时间。',['来源ID','提供方','URL','真实抓取时间（北京时间）','状态','用途／限制','原文SHA256','原文路径'],r,[14,24,85,28,22,65,72,100])
for i in range(5,s.max_row+1):
 c=s.cell(i,3);c.hyperlink=c.value;c.font=Font(color='087AA0',underline='single',size=10)
r=[]
for d in data['matches']:
 for label,k in [('综合修订','comprehensive_receipt'),('活动双模型状态','active_receipt'),('原研究双模型','research_freeze_reference')]:
  v=d[k];r.append([d['editorial']['match'],label,v['freeze_id'],v['recorded_at'],v.get('evaluation_slot',''),v['sha256'],v['path']])
r.append(['全批4场','TOP3空名单',data['batch_receipt']['freeze_id'],data['batch_receipt']['recorded_at'],data['batch_receipt']['evaluation_slot'],data['batch_receipt']['sha256'],data['batch_receipt']['path']])
sheet('冻结记录','冻结｜首次与修订分别保留','本次为综合修订，不能取代早间首次赛前主评价版本；研究候选、活动拒绝、综合判断分别复盘。',['对阵','轨道','冻结ID','北京时间','评价槽位','内容SHA256','权威记录路径'],r,[30,24,37,38,37,72,110])
r=[['分析范围','2026/27 日联杯八强首回合，成年男子，90分钟，不预测两回合晋级。'],['当前活动模型','四场均无适用路由，实际重试后记录拒绝，不借用J1模型。'],['研究候选','首、次回合各current/test；本次仅展示首回合。不是活动模型，未通过验收。'],['模型鲜度','首回合训练截止2025-09-03；2026联赛近期状态、xG、人员和盘口均未进入数值模型。'],['大阪樱花','未在24场合格历史中出现，test采用拟合总体先验，限制单独展示。'],['大小球','未取得同机构、实盘线及可靠报价时点，全部观望；不自设2.5。'],['TOP3','本批0场符合门槛；两场研究比分与另外两场待定均保留完整分母。'],['指标','比分、胜平负与真实盘口大小球分别结算；待定、观望及候选不算命中。'],['Google Drive / Sheets','目标文件夹“足球数据看板展示”已可浏览；浏览器未登录且会话无Drive写入工具，在线副本尚未创建。可将此工作簿上传并用Google Sheets打开。'],['冻结批次',data['batch_receipt']['freeze_id']],['权威存储','GitHub源码与数据仓库为权威记录；展示表是快照副本，不改变模型或旧冻结。']]
s=sheet('说明','使用说明｜展示副本与权威记录','先看「今日总览」，再按需查看逐场分析、研究模型、单队分布、来源和冻结记录。',['项目','说明'],r,[31,135])
for i in range(5,s.max_row+1):s.row_dimensions[i].height=45
p=out/'日联杯赛前分析_20261111.xlsx';wb.save(p);loaded=load_workbook(p,data_only=True);assert len(loaded.sheetnames)==8;assert loaded['今日总览']['C5'].value=='待定';assert loaded['今日总览']['C6'].value=='1-1';assert loaded['研究模型对照'].max_row==12
# Review image is an explicitly labeled rendering of workbook cells, not a screenshot of Google Sheets.
headers=[c.value for c in loaded['今日总览'][4]];table_rows=[[loaded['今日总览'].cell(r,c).value for c in range(1,9)] for r in range(5,9)]
esc=lambda x:html.escape(str(x or ''))
table='<thead><tr>'+''.join('<th>'+esc(x)+'</th>' for x in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+esc(x)+'</td>' for x in row)+'</tr>' for row in table_rows)+'</tbody>'
preview='''<!doctype html><html lang="zh"><meta charset="utf-8"><style>body{margin:0;background:#edf2f7;font-family:"Noto Sans CJK SC",Arial,sans-serif;color:#142d4e}main{margin:40px;padding:36px;background:white;border-radius:18px}small{color:#596b80}h1{font-size:34px}table{border-collapse:collapse;width:100%;margin-top:30px;font-size:15px}th{background:#007f80;color:white;text-align:left;padding:16px}td{padding:20px 14px;vertical-align:top;line-height:1.65;border-bottom:1px solid #dfe7ef}tr:nth-child(even){background:#f2f6fa}td:nth-child(3){font-size:24px;font-weight:700;white-space:nowrap}.note{padding:20px;background:#fff1cd;margin:24px 0}.tabs{color:#007f80;line-height:2;border-top:1px solid #ddd;padding-top:18px}footer{color:#596b80;font-size:13px;line-height:1.8}</style><main><small>WCPP · 赛前研究 · 工作簿内容预览（非Google Sheets在线截图）</small><h1>日联杯｜今日赛前观察</h1><p>2026年11月11日 · 北京时间 · 八强首回合 · 仅90分钟</p><table>'''+table+'</table><div class="note">'+esc(loaded['今日总览']['A11'].value)+'</div><div class="tabs">'+'　｜　'.join(loaded.sheetnames)+'</div><footer>'+esc(loaded['今日总览']['A13'].value)+'<br>在线副本尚未创建；下载XLSX可导入Google Sheets。研究模型未验收，实盘与近期xG仍有缺项。</footer></main></html>'
(out/'workbook-preview.html').write_text(preview)
print(json.dumps({'workbook':str(p),'sheets':loaded.sheetnames,'rows':{s.title:s.max_row for s in loaded}},ensure_ascii=False))
