"""One-time source-bound analysis delivery; no model training or promotion."""
import hashlib
import json
from pathlib import Path
import sys
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

sys.path.insert(0, '/workspace/Football-Analysis/runtime')
from nations_league import model
from research.analysis_freeze import save, verify
from research.team_goal_analysis import summarize_prediction
from research.score_distribution_audit import audit_prediction, comprehensive_audit
from research.market_movement import analyze as movement
from prediction_engine import predict_models
from v2_test.data_contract import snapshot

ROOT=Path(__file__).resolve().parent
FREEZES=Path('/workspace/WCPP/forecasts/issued-analyses')
INDEX=Path('/workspace/nations-model-20261110/models/candidates.json')
BJT=ZoneInfo('Asia/Shanghai')
def read(p): return json.loads(Path(p).read_text())
def write(p,v):
    with Path(p).open('x') as h: json.dump(v,h,ensure_ascii=False,indent=2,allow_nan=False)
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def stamp(): return datetime.now(timezone.utc).isoformat()
def bjt(t): return datetime.fromisoformat(t.replace('Z','+00:00')).astimezone(BJT).strftime('%m-%d %H:%M:%S')

fixtures=read(ROOT/'data/fixtures.json'); choices=read(ROOT/'selections.json')
latest=ROOT/'data/live-market-fresh-2'
assert latest.is_dir(), 'wait for final retained market batch'
aliases={'Türkiye':'Turkey','Czechia':'Czech Republic'}

def quotes(folder,f):
    meta=read(folder/'source-metadata.json'); raw=read(folder/'odds.json')
    assert sha(folder/'odds.json')==meta['odds']['sha256']
    assert sha(folder/'identity.json')==meta['identity']['sha256']
    matches=[r for r in raw if r['sport_key']=='soccer_uefa_nations_league'
             and r['home_team']==aliases.get(f['home_name'],f['home_name'])
             and r['away_team']==aliases.get(f['away_name'],f['away_name'])
             and model.aware(r['commence_time'])==model.aware(f['kickoff_at'])]
    assert len(matches)==1, 'unambiguous explicitly reviewed match required'
    source=matches[0]; books=[b for b in source['bookmakers'] if b['key']=='pinnacle']
    assert len(books)==1
    cap=read(folder/'market-channel.json')['created_at']; rows=[]
    for q in books[0]['markets']:
        if q['key'] not in ('h2h','totals'):continue
        names={source['home_team']:'home',source['away_team']:'away','Draw':'draw'} if q['key']=='h2h' else {'Over':'over','Under':'under'}
        assert len(q['outcomes'])==len(names) and {x['name'] for x in q['outcomes']}==set(names)
        value={'bookmaker':'pinnacle','market':q['key'],'quoted_at':q['last_update'],
               'odds':{names[x['name']]:x['price'] for x in q['outcomes']}}
        if q['key']=='totals':
            lines={x['point'] for x in q['outcomes']};assert len(lines)==1;value['line']=lines.pop()
        rows.append({'provider':'the-odds-api','cohort':'uefa.nations','match_id':f['match_id'],
                     'entity_id':f['home'],'field':'market_quote','period':'regulation_90',
                     'event_kickoff_at':f['kickoff_at'],'observed_at':meta['odds']['captured_at'],
                     'provider_match_id':source['id'],'value':value,
                     'identity_review':{'provider_home':source['home_team'],'provider_away':source['away_team'],
                                        'espn_home':f['home'],'espn_away':f['away'],
                                        'explicit_alias_crosswalk':'data/odds-identity-crosswalk.json'},
                     'evidence':dict(meta['odds'],query_time=meta['odds']['captured_at'],identity_verified=True)})
    target={'cohort':'uefa.nations','match_id':f['match_id'],'home_id':f['home'],'away_id':f['away'],
            'kickoff_at':f['kickoff_at'],'cutoff_at':cap}
    result=snapshot(rows,target,folder,provider='the-odds-api',now=model.aware(cap),market_max_age_seconds=60)
    assert len(result['observations'])==2, 'both markets must pass source-time validation'
    return result,meta

market={}; prepared=[]; preflight=[]
for original in fixtures:
    f=dict(original,cutoff_at=stamp(),entity='national',identity_verified=True,score_basis='regulation_90')
    model.validate_future(f)
    s,meta=quotes(latest,f); market[f['match_id']]=s
    total=next(r for r in s['observations'] if r['value']['market']=='totals')['value']
    assert total['line']==choices[f['source_event_id']]['expected_line'], 'review changed line before freezing'
    f['total_quote']={'verified':True,'match_id':f['match_id'],'bookmaker':'pinnacle','market':'asian_total',
                      'line':total['line'],'over_odds':total['odds']['over'],'under_odds':total['odds']['under'],
                      'quoted_at':total['quoted_at'],'query_time':meta['odds']['captured_at'],
                      'source_url':meta['odds']['url'],'source_sha256':meta['odds']['sha256']}
    f['market_snapshots']=[]
    for folder in [Path('/workspace/post32-20261112/live-market-fresh'), ROOT/'data/live-market-fresh-1',latest]:
        old,_=quotes(folder,f)
        for r in old['observations']:
            q=r['value'];f['market_snapshots'].append({'match_id':f['match_id'],'bookmaker':q['bookmaker'],
                'market':'1x2' if q['market']=='h2h' else q['market'],'line':q.get('line'),
                'decimal_odds':q['odds'],'quoted_at':q['quoted_at'],'query_time':r['observed_at'],
                'source_url':r['evidence']['url'],'source_sha256':r['evidence']['sha256']})
    route=read(INDEX)['routes'][f['league_level']]
    for role,v in route.items():
        assert sha(v['path'])==v['sha256'];model.predict(v['path'],f)
    try:predict_models(f)
    except ValueError as exc:
        assert str(exc)=='no validated identity/history model for this cohort'
        preflight.append({'match_id':f['match_id'],'active_route_error':str(exc)})
    else:raise ValueError('active route status changed; review before delivery')
    prepared.append(f)
write(ROOT/'validated-market.json',market);write(ROOT/'prepared-fixtures.json',prepared)
write(ROOT/'active-route-check.json',preflight)
model.freeze_pairs(INDEX,prepared,ROOT/'candidate-update',FREEZES)
receipts=read(ROOT/'candidate-update/receipts.json'); all_records=[]; lines=[]
lines += ['# 今晚欧国联赛前分析（研究版）','',
          '北京时间11月12日晚至11月13日凌晨，共8场，90分钟口径。严格自然日11月12日无比赛。',
          '欧国联活动Current/Test仍无已验收路由；以下数值为独立A/C级候选。Current只拟合等级均值与主场，Test另拟合球队攻防。四级均未通过效果验收，未晋级。',
          '本轮是11月10日候选首版冻结的追加版本，不增加独立比赛分母；综合判断独立保存。候选训练截至10月6日，已核对本届前四轮均在训练中；未学习新伤停、近期xG、完整俱乐部负荷或盘口系数。',
          '当前没有可靠近期同源xG/xGA；首发尚未确认，缺项逐场保留。Pinnacle报价仅代表所列真实时点，不是成交量或资金流。', '',
          '|北京时间|对阵|Current候选|Test候选|综合研究比分|胜平负|实际大小球判断|',
          '|---|---|---|---|---|---|---|']
for f,receipt in zip(prepared,receipts):
    pair=read(ROOT/'candidate-update'/(f['match_id'].replace(':','-')+'.json'))
    choice=choices[f['source_event_id']];q=f['total_quote'];mid=f['match_id']
    current_failed={'status':'ABSTAIN_NO_ACTIVE_ROUTE','matrix':None,'primary':None,'input':f}
    active={'current_model':dict(current_failed,model_label='当前模型'),'test_model':dict(current_failed,model_label='test模型'),
            'active_registry_sha256':sha('/workspace/WCPP/runtime/active-model.json'),'candidate_substitution':False}
    active_receipt=save(active,dict(f,cutoff_at=stamp()),stage='prematch',track='current-test-pair',root=FREEZES)
    candidates={role:dict(pair[role],team_goal_analysis=summarize_prediction(pair[role]),
                          score_distribution_audit=audit_prediction(pair[role])) for role in ('current','test')}
    payload=dict(choice,status='EXPERIMENTAL_MANUAL_ANALYSIS' if choice['primary'] else 'ABSTAIN_MATERIAL_PERSONNEL_RISK',
                 method_version='WCPP-NATIONS-MANUAL-20261112-1',total_line=q['line'],actual_quote=q,
                 current_test_reference=active_receipt,candidate_reference=receipt,
                 candidate_status='UNACCEPTED_RESEARCH_ONLY',candidate_outputs=candidates,
                 selection_evidence={k:choice[k] for k in ('compared_scores','zero_vs_one','three_plus_path','total_reason')},
                 sources={'fixture':f['phase_evidence'],'match_evidence':str(ROOT/'data/evidence'/(f['source_event_id']+'.json')),
                          'availability':str(ROOT/'data/availability-evidence.json'),'market':str(latest/'source-metadata.json')},
                 market_movement=movement(f),xg_status='NO_CURRENT_VERIFIED_SAME_PROVIDER_XG',
                 full_club_workload='NOT_FULLY_VERIFIED',formal_kpi_eligible=False,numerical_weights_changed=False)
    payload['candidate_comparison_audit']=comprehensive_audit(payload,{'current_model':candidates['current'],'test_model':candidates['test']})
    comprehensive=save(payload,dict(f,cutoff_at=stamp()),stage='prematch',track='comprehensive',root=FREEZES)
    record=verify(read(comprehensive['path']));assert not record['selection_audit']['top3_ready']
    all_records.append({'fixture':f,'payload':payload,'candidate_receipt':receipt,'active_receipt':active_receipt,'comprehensive_receipt':comprehensive})
    total=(choice['total_direction']+' '+str(q['line'])) if choice['total_direction'] else str(q['line'])+' 观望'
    lines.append(f"|{bjt(f['kickoff_at'])[:11]}|{choice['name']}|{pair['current']['primary']}|{pair['test']['primary']}|{choice['primary'] or '待定'}|{choice['wdl']}|{total}|")
for item in all_records:
    f,p=item['fixture'],item['payload'];q=f['total_quote'];lines+=['', '## '+p['name'],'',p['reason'],'', '反证与风险：'+p['counter'],'','人员：'+p['availability'],'',
        '|候选|主队均值／80%区间|主队0球／≥2球／≥3球|客队均值／80%区间|客队0球／≥2球／≥3球|胜／平／负|',
        '|---|---|---|---|---|---|']
    for role in ('current','test'):
        prediction=p['candidate_outputs'][role];g=prediction['team_goal_analysis'];cells=[]
        for side in ('home','away'):
            a=g[side];ci=a['central_interval'];cells += [f"{a['mean']:.2f} / {ci['lower']}–{ci['upper']}球",' / '.join(f"{a[k]:.1%}" for k in ('p0','p_ge_2','p_ge_3'))]
        w=' / '.join(f"{prediction['wdl'][k]:.1%}" for k in ('主胜','平局','客胜'))
        lines.append('|'+role+'|'+'|'.join(cells)+'|'+w+'|')
    lines += ['', '上述均值、区间和概率来自未验收候选矩阵，不是提供方xG或已验证置信度。','',
              '比分比较：'+'、'.join(p['compared_scores'])+'。'+p['three_plus_path'],'',
              '大小球：'+p['total_reason'], '',
              f"Pinnacle：总球{q['line']}，大{q['over_odds']}／小{q['under_odds']}；报价北京时间{bjt(q['quoted_at'])}，抓取{bjt(q['query_time'])}。"]
    comparisons=[r for r in p['market_movement']['comparisons'] if r['market']=='1x2']
    for c in comparisons:
        lines += ['','同机构1X2两端快照：'+str(c['first_decimal_odds'])+' → '+str(c['last_decimal_odds'])+'；仅是报价变化，不能解释为资金流。']
    lines += ['',f"赛程与近况来源：[ESPN比赛摘要]({f['phase_evidence']['source_url']})。",'',
              f"综合冻结：`{item['comprehensive_receipt']['freeze_id']}`，北京时间{bjt(item['comprehensive_receipt']['recorded_at'])}。"]
cutoff=stamp();shell={'match_id':'nations-analysis-batch:20261112-evening','cohort':'uefa.nations',
                      'kickoff_at':min(f['kickoff_at'] for f in prepared),'cutoff_at':cutoff}
top=save({'top3':[],'population':[f['match_id'] for f in prepared],
          'reason':'No accepted active pair; existing comprehensive TOP3 gate does not accept candidate-track substitutions.'},
         shell,stage='prematch',track='top3-selection',root=FREEZES)
lines += ['', '## 正式TOP3与缺项','',
          '本批正式TOP3为空。现行审计要求可用Current/Test配对引用，欧国联只有未验收候选，不用换轨道名称绕过入选条件。上表7场精确比分属于独立人工研究，意法待定；全部8场保留覆盖分母。',
          '历史赛果更新不代表未来准确率提升。未确认首发不自动阻断，但意法的多线替代风险尚未解决，单列观望。盘口没有被训练进当前候选，不给市场和人员虚设百分比权重。','',
          '新闻原文：[姆巴佩缺席](https://www.espn.com/soccer/story/_/id/50452835/kylian-mbappe-hamstring-miss-france-clash-italy)、[法国其他伤停](https://www.espn.com/soccer/story/_/id/50446771/france-thuram-tchouameni-leave-squad-injuries)、[亚马尔未赴捷克](https://www.espn.com/soccer/story/_/id/50455459/spain-lamine-yamal-injury-luis-de-la-fuente-nations-league)。']
report='\n'.join(lines)+'\n'
report_receipt=save({'report_markdown':report,'comprehensive_receipts':[r['comprehensive_receipt'] for r in all_records],
                     'top3_receipt':top,'source_commit':'705d1fe2866cbdb55f6099351f9092db03f6a554'},
                    dict(shell,cutoff_at=stamp()),stage='prematch',track='analysis-report',root=FREEZES)
(ROOT/'欧国联赛前分析.md').write_text(report)
write(ROOT/'analysis-records.json',all_records)
write(ROOT/'delivery.json',{'report_receipt':report_receipt,'top3_receipt':top,'population':8,'comprehensive_scores':7,
                          'comprehensive_abstentions':1,'candidate_receipts':receipts,'active_registry_changed':False,
                          'all_receipts':[r[k] for r in all_records for k in ('candidate_receipt','active_receipt','comprehensive_receipt')]})
for r in read(ROOT/'delivery.json')['all_receipts']+[report_receipt,top]:
    assert verify(read(r['path']))['record_sha256']==r['sha256']
print(json.dumps({'report':str(ROOT/'欧国联赛前分析.md'),'report_receipt':report_receipt,'population':8},ensure_ascii=False))
