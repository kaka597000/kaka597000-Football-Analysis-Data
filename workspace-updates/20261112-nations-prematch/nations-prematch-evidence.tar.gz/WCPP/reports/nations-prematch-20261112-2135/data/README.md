# 欧国联赛前数据包：2026-11-12 晚间（北京时间）

- 采集截止：2026-11-12 21:42 BJT（13:42 UTC）。赛程、球队身份、阶段、分组、neutral、开球时间与未开赛状态均由 ESPN API 原响应核验。
- 严格北京时间 11 月 12 日（UTC 11/11 16:00 至 11/12 16:00）：0 场。北京时间今晚至 11/13 07:00：8 场，均在 11/13 01:00 或 03:45 开球。
- 8 场均为 2026-27 联赛阶段；summary 原文完整含 A1/A3/C1/C2 分组、球队 ESPN ID、积分记录和 `neutralSite=false`。全部通过 `runtime.nations_league.model.validate_future()`。
- `fixtures.json` 是可用于候选接口的 fixture 列表。`summaries/` 保存 8 个完整 ESPN summary 原响应；`evidence/` 每场保存 JSON 与 Markdown，包含最近5场（并明确拆出近期本届欧国联）、当前积分、新闻及来源哈希。
- 当前分组动力（已赛4场）：A1 法国10、意大利7、比利时6、土耳其0；A3 西班牙12、英格兰9、克罗地亚3、捷克0；C1 阿尔巴尼亚9、白俄罗斯7、芬兰7、圣马力诺0；C2 黑山10、塞浦路斯7、亚美尼亚4、拉脱维亚1。依据逐场summary积分榜/竞赛记录，不补推未明规则下的晋级情景。
- 新盘口批次 13:35:43 UTC 捕获；符合严格报价时间≤60秒的150条，8场中6场有报价。原始响应在 `live-market-fresh-1/`。Türkiye/Turkey 与 Czechia/Czech Republic 用同开球、同主客顺序、共同对手、比赛ID和ESPN球队ID建立显式 crosswalk（`odds-identity-crosswalk.json`），未更改原赔率。
- 伤停方面，ESPN/AP 全文确认：姆巴佩将缺席意大利赛；图拉姆（腿筋）、楚阿梅尼（右内收肌复发）离队；西班牙主帅称亚马尔右膝发炎、因避免旅途本场留队接受治疗，报道预期他周日可用；Oyarzabal正从流感恢复，预计较晚报到（本报道未确认最终出场状态）。法国同篇报道还称Kalulu（左腿筋伤）、Saliba、Koundé、Lacroix、Manu Koné、Dembélé、Lepaul也缺席（该段未逐人说明原因）。来源正文、发布日期、原链接及哈希在 `news/`、`availability-evidence.json`。这些属于报道确认；其余六队没有核实到可靠的最新逐人缺阵名单，不能视为无人缺阵。
- ESPN summary 未返回 xG/xGA 字段；StatsBomb Open Data competitions.json 查询到80项，未列2026-27欧国联，无法提供该赛季xG；射门统计未转称xG。阵容/停赛与轮换证据除上述报道外仍有缺项。模型训练历史由主代理复用 `/workspace/nations-model-20261110/models/{A,B,C,D}/dataset.json`，截至10月，勿误称覆盖了本批之前的全部比赛。
- 未做同机构、同市场、同盘线变价比较。`/workspace/post32-20261112/live-market-fresh` 的 12:27 UTC 数据仅作较早快照；第二批新盘口等待主代理临近冻结通知。

## 文件

- `fixtures.json`：8场真实身份及候选预测输入。
- `sources-index.json`：URL、时点、原文路径、哈希、覆盖范围和缺项索引。
- `evidence/401861*.json`、`.md`：逐场细节。
- `group-standings.json`：本轮前 A1/A3/C1/C2 积分记录。
- `availability-evidence.json`、`news-sources.json`、`news/*.json`：伤停/报道原文。
- `live-market-fresh-1/`：本轮唯一盘口批次及逐报价时效审计。
- `xg-source-check/`：StatsBomb公开赛事覆盖核查原响应及哈希。
- `odds-identity-crosswalk.json`：仅两个名称别名的透明身份映射。
