"""All-phase official dates plus an independent ESPN board covering a one-day guard on both ends."""
from concurrent.futures import ThreadPoolExecutor
import time
from capture import COMPS,ROOT,capture


def fetch(provider):
    folder=ROOT/'raw/interval'
    folder.mkdir(exist_ok=True)
    for tag,(code,uid,_) in COMPS.items():
        if provider=='uefa':
            url=f'https://match.uefa.com/v5/matches?competitionId={uid}&seasonYear=2027&phase=ALL&fromDate=2026-11-25&toDate=2026-12-11&limit=500&offset=0&order=ASC'
        else:
            url=f'https://site.api.espn.com/apis/site/v2/sports/soccer/{code}/scoreboard?dates=20261125-20261211&limit=1000'
        info=capture(folder/(provider+'-'+tag+'.json'),url,provider+' full interval',tag)
        print(provider,tag,info['http_status'],info['bytes'],flush=True)
        time.sleep(1)


if __name__=='__main__':
    with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(fetch,('uefa','espn')))
