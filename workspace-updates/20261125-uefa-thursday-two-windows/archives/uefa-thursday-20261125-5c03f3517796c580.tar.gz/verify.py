"""Offline ID-by-ID readback of saved calendars, source clocks and native DraftKings quotes."""
import argparse
from collections import Counter, defaultdict
import csv
from datetime import datetime
import gzip
from hashlib import sha256
import json
from pathlib import Path

from interval_check import compute as interval_and_fixed

BASE=Path(__file__).resolve().parent
D=BASE/'derived'
read=lambda p:json.loads(p.read_bytes())
dt=lambda value:datetime.fromisoformat(value.replace('Z','+00:00'))
def check(test,what):
    if not test:
        raise ValueError(what)


def captures():
    catalog=[]
    for side in sorted((BASE/'raw').rglob('*.meta.json')):
        meta=read(side);path=BASE/meta['path']
        data=path.read_bytes()
        check(side==path.with_suffix('.meta.json') and sha256(data).hexdigest()==meta['sha256'] and len(data)==meta['bytes'],str(side))
        check(dt(meta['request_started_utc'])<=dt(meta['response_received_utc']),meta['url'])
        name=meta['path']
        if name in ('raw/espn/uel-2026.json','raw/espn/uecl-2026.json','raw/uefa/uel.json',
                    'raw/uefa/uecl-2019.json','raw/fotmob/uel.json','raw/fotmob/uecl.json'):
            role='calendar'
        elif 'espn-summaries/' in name:
            role='first_round_summary'
        elif name.startswith('raw/interval/uefa-'):
            role='all_phase_guard_calendar'
        elif name.startswith('raw/alternative/evt_'):
            role='separate_bookmaker_quote_candidates'
        elif name=='raw/alternative/infer-events.json':
            role='separate_candidate_event_identity'
        elif name.startswith('raw/alternative/infer-public-'):
            role='quote_provider_public_documentation'
        elif name.startswith('raw/alternative/'):
            role='alternative_discovery_only'
        elif name.endswith('providers.json'):
            role='missing_bookmaker_crosscheck'
        elif name=='raw/uefa/uecl-fixtures.html':
            role='official_competition_id'
        elif 'espn-core-odds/' in name:
            role='supplemental_quote_clock_check'
        else:
            role='unused_discovery_response'
        catalog.append(dict(meta,role=role,sidecar=str(side.relative_to(BASE)),sidecar_sha256=sha256(side.read_bytes()).hexdigest()))
    actual={str(path.relative_to(BASE)) for path in (BASE/'raw').rglob('*') if path.is_file()}
    check(actual=={m[k] for m in catalog for k in ('path','sidecar')},'unpaired raw original or sidecar')
    return catalog


def body(name):
    data=(BASE/name).read_bytes()
    return json.loads(gzip.decompress(data) if data[:2]==b'\x1f\x8b' else data)


def lines(name):
    return [json.loads(l) for l in (D/name).read_text().splitlines()]


def index(rows,key):
    idx={str(r[key]):r for r in rows}
    check(len(rows)==len(idx),'duplicate '+key)
    return idx


def interval_readback():
    audit, fixed=interval_and_fixed()
    check(read(D/'fixed-calendar.json')==fixed and read(D/'interval-audit.json')==json.loads(json.dumps(audit)),
          'fixed calendar/interval audit readback')
    result={}
    for tag,r in audit['competitions'].items():
        daily={d:n for d,n in r['source_checks']['uefa']['daily_utc'].items() if n}
        check(daily=={'2026-11-26':18,'2026-12-10':18}, 'non-matchday fixtures in closed interval')
        check(all(s['daily_utc']==r['source_checks']['uefa']['daily_utc'] and not s['extra_ids'] and not s['missing_ids']
                  for s in r['source_checks'].values()),'independent calendar membership')
        result[tag]=dict(registered=36, non_round_fixtures=0, dates_utc=daily, next_slots_bjt=r['next_round_bjt_slots'])
    return result


def alternative_readback(first, catalog):
    """Independently enumerate source lines and reproduce CSV membership, clocks, sides and odds."""
    folder=BASE/'alternatives'
    receipts={m['path']:m for m in catalog}
    cov=read(folder/'coverage.json')
    cf=index(cov['fixtures'],'espn_event_id')
    target=index(first,'espn_event_id')
    check(cf.keys()==target.keys() and len(cf)==36, 'alternative fixture denominator')
    reference=cov['clock_reference']
    guide=(BASE/reference['path']).read_text()
    definition=guide.split('### OddsQuote — one bookmaker × one market line',1)[1].split('###',1)[0]
    check('last upstream update applied' in definition and '`as_of`' in definition and
          receipts[reference['path']]['sha256']==reference['sha256'],'provider quote clock semantics')
    source_events=index(body(cov['event_list_source'])['data'],'id')
    market_rows=[json.loads(v) for v in (folder/'infersports-markets.jsonl').read_text().splitlines()]
    with (folder/'infersports-same-book.csv').open() as fd:
        pairs=list(csv.DictReader(fd))
    books={'crown','hkjc','m8bet','macau','nova88','sbobet'}
    source_markets={}
    eligible_pairs={}
    for eid,case in cf.items():
        event=source_events[case['infer_event_id']]
        check(event['id']==case['infer_event_id'] and dt(event['scheduled_at'])==dt(target[eid]['kickoff_utc'])
              and event['league']['id']==case['infer_league_id'] and event['status']=='scheduled'
              and all(event[s+'_team']=={'id':case['infer_'+s+'_id'],'name':case['infer_'+s+'_name']}
                      for s in ('home','away')),'separate match identity')
        source=body(case['source_path'])
        side=receipts[case['source_path']]
        check(source['event_id']==event['id'] and source['stale'] is False and case['source_sha256']==side['sha256']
              and dt(side['response_received_utc'])<dt(event['scheduled_at']), 'valid quote response')
        money={}
        totals=defaultdict(list)
        for i,q in enumerate(source['odds']):
            if q['period']!='full_time' or q['market_type'] not in ('1x2','totals') or q['status']!='open':
                continue
            sides=('home','draw','away') if q['market_type']=='1x2' else ('over','under')
            check(q['bookmaker'] in books and q['format']=='decimal' and all(q['prices'][s]>1 for s in sides)
                  and dt(q['as_of'])<=dt(side['response_received_utc']), 'raw candidate line/clock')
            source_markets[eid,i]=q
            if q['market_type']=='1x2':
                check(q['bookmaker'] not in money and q['line'] is None,'unique native 1X2')
                money[q['bookmaker']]=i
            else:
                check(q['line']>0 and q['line']*4==round(q['line']*4) and
                      all(q.get(s+'_line',q['line'])==q['line'] for s in sides),'native two-sided totals line')
                totals[q['bookmaker']].append(i)
        for book,indices in totals.items():
            if book in money:
                for i in indices:
                    eligible_pairs[eid,book,money[book],i]=side
    def row_hash(q):
        return sha256(json.dumps(q,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
    check(len(market_rows)==len(source_markets)==cov['markets'] and
          {(r['espn_event_id'],r['source_row_index']) for r in market_rows}==source_markets.keys(), 'all native quote rows')
    for r in market_rows:
        q=source_markets[r['espn_event_id'],r['source_row_index']]
        check(q['bookmaker']==r['bookmaker'] and q['market_type']==r['market'] and q['prices']==r['prices']
              and q['as_of']==r['quote_time'] and q['line']==r['line'] and q['handicap_components']==r['handicap_components']
              and row_hash(q)==r['source_row_sha256'],'candidate source-row replay')
    represented=set()
    exact, within_hour, both=set(),set(),set()
    equal_n=recent_n=both_n=0
    for p in pairs:
        eid=p['espn_event_id']
        i,j=int(p['moneyline_raw_index']),int(p['totals_raw_index'])
        key=(eid,p['bookmaker'],i,j)
        check(key not in represented,'duplicate pair')
        represented.add(key)
        receipt=eligible_pairs[key]
        q,t=source_markets[eid,i],source_markets[eid,j]
        check(p['source_sha256']==receipt['sha256'] and p['source_response_utc']==receipt['response_received_utc']
              and p['source_request_utc']==receipt['request_started_utc'] and p['moneyline_raw_row_sha256']==row_hash(q)
              and p['totals_raw_row_sha256']==row_hash(t) and q['as_of']==p['moneyline_quote_time']
              and t['as_of']==p['totals_quote_time'] and t['line']==float(p['total_line'])
              and t['handicap_components']==json.loads(p['total_components']), 'native pair clocks, line and hashes')
        for k in ('home','draw','away','over','under'):
            check(float(p[k+'_decimal'])==(q if k in ('home','draw','away') else t)['prices'][k],'candidate price side')
        ages=[(dt(receipt['response_received_utc'])-dt(x['as_of'])).total_seconds() for x in (q,t)]
        same=dt(q['as_of'])==dt(t['as_of'])
        recent=max(ages)<=3600
        check(p['same_quote_time']==str(same) and p['both_within_1h_at_receipt']==str(recent) and
              ages==[float(p['moneyline_age_seconds']),float(p['totals_age_seconds'])], 'candidate clock labels')
        if same:
            exact.add(eid);equal_n+=1
        if recent:
            within_hour.add(eid);recent_n+=1
        if same and recent:
            both.add(eid);both_n+=1
    n=len({k[0] for k in represented})
    check(represented==eligible_pairs.keys() and (n,len(pairs),len(exact),equal_n,len(within_hour),recent_n,len(both),both_n)==
          tuple(cov[k] for k in ('fixtures_with_same_book_pair','pairs','fixtures_with_equal_clocks','equal_clock_pairs',
                                 'fixtures_with_both_clocks_within_1h','both_within_1h_pairs',
                                 'fixtures_with_equal_clocks_within_1h','equal_clock_pairs_within_1h')), 'same-book coverage')
    return dict(fixtures=n, books=len({k[1] for k in represented}), markets=len(source_markets), same_book_pairs=len(pairs),
                equal_clock_pairs=equal_n, equal_clock_fixtures=len(exact), both_within_hour_pairs=recent_n,
                both_within_hour_fixtures=len(within_hour), equal_and_within_hour_pairs=both_n, equal_and_within_hour_fixtures=len(both))


def verify(catalog):
    clock_index={m['path']:m for m in catalog}
    first=lines('first-round.jsonl')
    rows=first+lines('next-round.jsonl')
    check(len(first)==36 and len(rows)==72 and len(index(rows,'espn_event_id'))==len(index(rows,'uefa_event_id'))==len(index(rows,'fotmob_event_id')), '72 unique competition fixtures')
    with (D/'calendar.csv').open() as f:
        tab=index(list(csv.DictReader(f)),'stable_match_id')
    check(len(tab)==72, 'spreadsheet population')
    matches=index(first,'espn_event_id')
    count=Counter()
    allclubs={}
    for tag,ue_file,md in [('uel','uel',5),('uecl','uecl-2019',4)]:
        off=index(body('raw/uefa/'+ue_file+'.json'),'id')
        esp=index(body('raw/espn/'+tag+'-2026.json')['events'],'id')
        fm=index(body('raw/fotmob/'+tag+'.json')['fixtures']['allMatches'],'id')
        for r in [r for r in rows if r['tag']==tag]:
            u,e,m=off[r['uefa_event_id']],esp[r['espn_event_id']],fm[r['fotmob_event_id']]
            c,=e['competitions']; k=dt(r['kickoff_utc'])
            check(k==dt(r['kickoff_bjt'])==dt(u['kickOffTime']['dateTime'])==dt(c['date'])==dt(m['status']['utcTime']),r['stable_match_id']+' kickoff')
            check(r['round']==int(u['matchday']['sequenceNumber'])==int(m['round'])==md+(r['window']=='next'),'matchday')
            check(u['round']['metaData']['name']=='League Phase' and e['season']['slug']=='league-phase' and e['season']['year']==2026,'phase')
            check(r['uefa_status']==u['status']=='UPCOMING' and r['espn_status']==c['status']['type']['name']=='STATUS_SCHEDULED'
                  and not m['status']['started'] and not m['status']['finished'] and c['timeValid'] is True,'prematch')
            for side in ('home','away'):
                et=next(x for x in c['competitors'] if x['homeAway']==side)
                ids=[str(u[side+'Team']['id']),et['team']['id'],str(m[side]['id'])]
                check(ids==[r[p+'_'+side+'_id'] for p in ('uefa','espn','fotmob')],r['stable_match_id']+' club ID')
                check(allclubs.setdefault((tag,ids[0]),ids[1:])==ids[1:],'ambiguous club link')
            check(tab[r['stable_match_id']]['espn_event_id']==e['id'] and dt(tab[r['stable_match_id']]['kickoff_utc'])==k,'calendar CSV')
            for provider,s in r['sources'].items():
                meta=clock_index[s['path']]
                check(all(s[key]==meta[key] for key in s) and dt(meta['response_received_utc'])<k,'calendar source clock/hash')
            count[(tag,r['window'])]+=1
    check(len(allclubs)==72 and len(count)==4 and set(count.values())=={18},'four complete rounds')
    price_rows=index(lines('first-round-draftkings.jsonl'),'espn_event_id')
    with (D/'first-round-draftkings.csv').open() as f:
        quotes=index(list(csv.DictReader(f)),'espn_event_id')
    check(matches.keys()==price_rows.keys()==quotes.keys(),'market denominator')
    complete=0
    for eid,r in price_rows.items():
        game=matches[eid];raw=body(r['source_raw_path']);side=clock_index[r['source_raw_path']]
        event,=raw['header']['competitions']
        check(eid==event['id']==raw['header']['id'] and dt(game['kickoff_utc'])==dt(event['date']) and
              event['status']['type']['state']=='pre' and dt(side['response_received_utc'])<dt(event['date']),'summary clock/ID')
        check(side['sha256']==r['source_sha256'] and side['request_started_utc']==r['source_request_utc']
              and side['response_received_utc']==r['source_response_utc'],'source capture')
        dk=[o for o in (raw.get('odds') or []) if o and o.get('provider',{}).get('name')=='DraftKings']
        if not dk:
            cp=r['missing_provider_list_evidence']
            check(not r['bookmaker'] and r['market_status']=='NO_DRAFTKINGS_ROW' and body(cp['path'])['count']==0
                  and all(r[k] is None for k in ('home_american','draw_american','away_american','over_american','under_american','total_line')),
                  'explicit missing original price')
            continue
        o,=dk
        check(o['provider']['id']=='100' and r['espn_provider_id']=='100' and r['bookmaker']=='DraftKings','same book')
        for s in ('home','draw','away','over','under'):
            block=o['moneyline' if s in ('home','draw','away') else 'total'][s]['close']
            check(int(block['odds'])==r[s+'_american']==int(quotes[eid][s+'_american']),eid+' '+s)
            if s in ('over','under'):
                check(float(block['line'][1:])==r['total_line']==o['overUnder'],'two sided total')
        check(o.get('lastUpdated') is None and r['quote_time_utc'] is None and not r['candidate_clock_fields'], 'provider clock status')
        complete+=1
    check(complete==35 and sum(q['quote_time_utc'] is not None for q in price_rows.values())==0,'observed snapshot coverage')
    return dict(calendar_fixtures=len(rows),provider_event_records=len(rows)*3,club_crosswalk_rows=len(allclubs),
                first_round_summaries=len(price_rows),complete_DraftKings=complete,explicit_unquoted=len(price_rows)-complete,
                provider_quote_clocks=0,raw_bodies=len(catalog),source_roles=dict(Counter(m['role'] for m in catalog)),
                interval=interval_readback(), independent_bookmaker_candidates=alternative_readback(first,catalog))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--write-manifest',action='store_true')
    a=parser.parse_args()
    sources=captures()
    result=verify(sources)
    manifest=dict(sources=sources,readback=result)
    first=BASE/'source-manifest.json'
    check(sha256(first.read_bytes()).hexdigest()=='a0a8cd7b058ca2b781b70b6267d35128a5430bc714ca6b5bee61ef768dbea162'
          and read(first)['sources']==[s for s in sources if not s['path'].startswith(('raw/alternative/','raw/interval/'))],
          'first delivery source manifest')
    archive_manifest=BASE/'archive-source-manifest.json'
    if a.write_manifest:
        archive_manifest.write_text(json.dumps(manifest,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
    else:
        check(read(archive_manifest)==manifest,'archive source manifest readback')
    print(json.dumps(result,sort_keys=True))
