"""Reconcile the two original full rounds per competition from immutable collection files."""
from collections import Counter, defaultdict
import csv
from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path

from capture import COMPS, ROOT, put, raw_json

DERIVED=ROOT/'derived'
PROVIDERS=('uefa','espn','fotmob')
BJT=timezone(timedelta(hours=8))


def require(test, reason):
    if not test:
        raise ValueError(reason)


def instant(value):
    dt=datetime.fromisoformat(value.replace('Z','+00:00'))
    require(dt.utcoffset() is not None, 'timezone required')
    return dt.astimezone(timezone.utc)


def utc(value):
    return value.astimezone(timezone.utc).isoformat(timespec='seconds').replace('+00:00','Z')


def fingerprint(value):
    return hashlib.sha256(json.dumps(value, separators=(',',':'), ensure_ascii=False,sort_keys=True).encode()).hexdigest()


def original(path):
    meta=json.loads(path.with_suffix('.meta.json').read_bytes())
    require(meta['http_status']==200 and meta['bytes']==path.stat().st_size
            and meta['path']==str(path.relative_to(ROOT))
            and hashlib.sha256(path.read_bytes()).hexdigest()==meta['sha256']
            and instant(meta['request_started_utc'])<=instant(meta['response_received_utc']),str(path))
    return raw_json(path),meta


def store_csv(path,rows):
    with path.open('w',encoding='utf-8',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n')
        writer.writeheader()
        writer.writerows(rows)


def store_lines(path,rows):
    with path.open('w',encoding='utf-8') as file:
        for row in rows:
            file.write(json.dumps(row,ensure_ascii=False,sort_keys=True,allow_nan=False)+'\n')


def build_sources(tag):
    code,official_id,fm_id=COMPS[tag]
    files={'uefa':ROOT/'raw/uefa'/('uel.json' if tag=='uel' else 'uecl-2019.json'),
           'espn':ROOT/'raw/espn'/(tag+'-2026.json'),'fotmob':ROOT/'raw/fotmob'/(tag+'.json')}
    docs,proof={},{}
    for provider in PROVIDERS:
        docs[provider],proof[provider]=original(files[provider])
        require(proof[provider]['competition']==code, 'competition sidecar')
    result={p:[] for p in PROVIDERS}
    for m in docs['uefa']:
        if m['round']['metaData']['name']!='League Phase':
            continue
        md=m['matchday']
        require(m['competition']['id']==official_id and m['competition']['code']==tag.upper()
                and str(m['seasonYear'])=='2027' and m['competitionPhase']=='TOURNAMENT'
                and md['roundId']==m['round']['id'] and md['competitionId']==official_id, 'UEFA stage/round binding')
        entry=dict(id=str(m['id']), round=int(md['sequenceNumber']), stage=m['round']['metaData']['name'],
                   stage_id=m['round']['id'], matchday_id=md['id'], status=m['status'], pre=m['status']=='UPCOMING',
                   time=utc(instant(m['kickOffTime']['dateTime'])))
        for side in ('home','away'):
            t=m[side+'Team']
            require(t.get('isPlaceHolder') is False and t['id'], 'UEFA club not confirmed')
            entry[side]=(str(t['id']),t['internationalName'])
        result['uefa'].append(entry)

    doc=docs['espn']
    require([l['slug'] for l in doc['leagues']]==[code],'ESPN competition')
    for m in doc['events']:
        if m['season']['year']!=2026 or m['season']['slug']!='league-phase':
            continue
        c,=m['competitions']
        require(m['id']==c['id'] and instant(c['date'])==instant(m['date']), 'ESPN event and competition mismatch')
        row=dict(id=str(m['id']),round=None, stage=m['season']['slug'], status=c['status']['type']['name'],
                 pre=c['status']['type']['state']=='pre' and c['status']['type']['completed'] is False,
                 time=utc(instant(c['date'])),time_valid=c.get('timeValid'))
        require({x['homeAway'] for x in c['competitors']}=={'home','away'} and len(c['competitors'])==2, 'ESPN sides')
        for x in c['competitors']:
            require(x['id']==x['team']['id'],'ESPN competitor ID')
            row[x['homeAway']]=(str(x['team']['id']),x['team']['displayName'])
        result['espn'].append(row)
    doc=docs['fotmob']
    require(str(doc['details']['id'])==fm_id and doc['details']['selectedSeason']=='2026/2027','FotMob competition/season')
    for m in doc['fixtures']['allMatches']:
        st=m['status']
        require(str(m['round'])==str(m['roundName']), 'FotMob round')
        pre=st.get('started') is False and st.get('finished') is False and not any(st.get(k) for k in ('cancelled','awarded'))
        row=dict(id=str(m['id']),round=int(m['round']),time=utc(instant(st['utcTime'])),pre=pre,
                 status='scheduled' if pre else (st.get('reason') or {}).get('short','other'))
        for side in ('home','away'):
            row[side]=(str(m[side]['id']),m[side]['name'])
        result['fotmob'].append(row)
    for provider,events in result.items():
        require(len({m['id'] for m in events})==len(events),provider+' nonunique event')
    return result,proof


def team_signatures(events):
    # Six full in-year matchdays occur in both competitions in 2026. Exact home/away
    # and kickoff plus opponents' schedules avoid transliteration or fuzzy-name joins.
    basic=defaultdict(list)
    opponents=defaultdict(list)
    names={}
    for m in events:
        if not m['time'].startswith('2026-'):
            continue
        for side,op in [('home','away'),('away','home')]:
            tid,name=m[side]
            basic[tid].append((m['time'],side))
            opponents[tid].append((m['time'],side,m[op][0]))
            require(names.setdefault(tid,name)==name,'provider team name changed within source response')
    require(len(basic)==36 and all(len(a)==6 for a in basic.values()),'complete in-year six-match club schedules')
    keys={tid:fingerprint(sorted(v)) for tid,v in basic.items()}
    links={fingerprint(sorted((time,side,keys[opp]) for time,side,opp in v)):tid for tid,v in opponents.items()}
    require(len(links)==36,'ambiguous club schedule/opponent signature')
    return links,names


def by_fixture(events,translate):
    matches={}
    for m in events:
        key=(translate[m['home'][0]],translate[m['away'][0]],m['time'])
        require(key not in matches,'ambiguous fixture identity')
        matches[key]=m
    return matches


def reconcile(tag):
    code=COMPS[tag][0]
    events, sources=build_sources(tag)
    links,names={},{}
    for provider in PROVIDERS:
        links[provider],names[provider]=team_signatures(events[provider])
    cross=[]
    for sig,official in links['uefa'].items():
        row=dict(competition=code, schedule_opponents_sha256=sig)
        for provider in PROVIDERS:
            require(sig in links[provider],provider+' club signature mismatch: '+official)
            i=links[provider][sig]
            row[provider+'_team_id']=i
            row[provider+'_name']=names[provider][i]
        cross.append(row)
    translations={p:{r[p+'_team_id']:r['uefa_team_id'] for r in cross} for p in PROVIDERS}
    joins={p:by_fixture(events[p],translations[p]) for p in PROVIDERS}
    year_keys={k for k in joins['uefa'] if k[2].startswith('2026-')}
    for provider in PROVIDERS:
        require({k for k in joins[provider] if k[2].startswith('2026-')}==year_keys,'2026 cross-source fixture identity: '+provider)
    rounds=defaultdict(list)
    for m in events['uefa']:
        rounds[m['round']].append(m)
    count=8 if tag=='uel' else 6
    require(set(rounds)==set(range(1,count+1)), 'UEFA full season stage')
    for n,rr in rounds.items():
        require(len(rr)==18 and len({m[s][0] for m in rr for s in ('home','away')})==36,'incomplete matchday')
    asof=max(instant(m['response_received_utc']) for m in sources.values())
    next_round=min(n for n,rr in rounds.items() if all(m['pre'] and instant(m['time'])>asof for m in rr))
    result=[]
    for n in (next_round,next_round+1):
        for m in rounds[n]:
            key=(m['home'][0],m['away'][0],m['time'])
            esp,fm=joins['espn'][key],joins['fotmob'][key]
            require(fm['round']==n and esp['time_valid'] is True and esp['status']=='STATUS_SCHEDULED'
                    and esp['pre'] and fm['pre'] and m['pre'] and instant(m['time'])>asof,'status/round/time mismatch')
            row=dict(tag=tag,competition=code,season='2026/27',stage='League Phase',
                     window='first' if n==next_round else 'next',round=n,
                     uefa_matchday_id=m['matchday_id'],uefa_stage_id=m['stage_id'],fotmob_round=fm['round'],espn_round=None,
                     stable_match_id='uefa:'+m['id'],uefa_event_id=m['id'],espn_event_id=esp['id'],fotmob_event_id=fm['id'],
                     home=m['home'][1],away=m['away'][1],kickoff_utc=m['time'],kickoff_bjt=instant(m['time']).astimezone(BJT).isoformat(),
                     uefa_status=m['status'],espn_status=esp['status'],fotmob_status=fm['status'],
                     espn_time_valid=esp['time_valid'],identity_sources_agree=True)
            for provider,ev in [('uefa',m),('espn',esp),('fotmob',fm)]:
                for side in ('home','away'):
                    row[provider+'_'+side+'_id'],row[provider+'_'+side]=ev[side]
                row[provider+'_kickoff_utc']=ev['time']
            row['sources']={p:{k:sources[p][k] for k in ('path','url','request_started_utc','response_received_utc','http_date','sha256')} for p in PROVIDERS}
            result.append(row)
    return result,cross,sources,dict(competition=code,full_uefa_league_phase_matchdays=count,
        entire_2026_six_rounds_matched=len(year_keys),unique_clubs_per_source=len(cross),
        first_round=next_round,next_round=next_round+1,
        schedule_checked_through_utc=asof.isoformat(),rounds=[dict(round=n,matches=18,clubs=36,
            earliest_kickoff_utc=min(m['time'] for m in rounds[n]),latest_kickoff_utc=max(m['time'] for m in rounds[n]))
            for n in (next_round,next_round+1)])


def main():
    rows,clubs,metadata,coverage=[],[],[],{}
    for tag in COMPS:
        rr,cc,ss,checks=reconcile(tag)
        rows.extend(rr);clubs.extend(cc);metadata.extend(ss.values());coverage[tag]=checks
    rows.sort(key=lambda r:(r['window']!='first',r['kickoff_utc'],r['competition'],r['uefa_event_id']))
    require(len(rows)==len({r['stable_match_id'] for r in rows})==72,'72 unique UEFA fixtures')
    require(len({r['espn_event_id'] for r in rows})==len({r['fotmob_event_id'] for r in rows})==72,'72 original provider IDs')
    for window in ('first','next'):
        keep=[r for r in rows if r['window']==window]
        require(len(keep)==36,window+' round completeness')
        store_lines(DERIVED/(window+'-round.jsonl'),keep)
    flat=[]
    for r in rows:
        fr={k:v for k,v in r.items() if k!='sources'}
        for p,s in r['sources'].items():
            fr.update({p+'_'+k:v for k,v in s.items()})
        flat.append(fr)
    store_csv(DERIVED/'calendar.csv',flat)
    store_csv(DERIVED/'club-ids.csv',sorted(clubs,key=lambda x:(x['competition'],x['uefa_name'])))
    put(DERIVED/'calendar-check.json',dict(first=36,next=36,verified_fixtures=72,
        club_id_links=len(clubs),raw_calendar_sources=metadata,competitions=coverage))
    print(json.dumps({tag:[v['first_round'],v['next_round']] for tag,v in coverage.items()}),len(rows),'three-source fixtures')


if __name__=='__main__':
    main()
