"""Freeze fixture identity and verify the entire interval from the unfiltered provider calendars."""
from collections import Counter
from datetime import timedelta
from hashlib import sha256
import json
from urllib.parse import parse_qs, urlsplit

from calendar_build import BJT, DERIVED, PROVIDERS, fingerprint, instant, original, require, utc
from capture import COMPS, ROOT, put

GUARD_START = instant('2026-11-25T00:00:00Z')
GUARD_END = instant('2026-12-12T00:00:00Z')  # exclusive: includes Dec 11 UTC in full


def source_ref(meta):
    return {k: meta[k] for k in ('path', 'url', 'sha256', 'request_started_utc', 'response_received_utc', 'http_date')}


def fixture_index(entries, provider):
    by_id = {str(i): instant(t) for i, t in entries}
    require(len(by_id) == len(entries), provider + ' duplicate calendar ID')
    return by_id


def interval_for(tag, fixtures, common_start):
    code, comp_id, fm_id = COMPS[tag]
    official, u_meta = original(ROOT / 'raw/interval' / ('uefa-' + tag + '.json'))
    espn, e_meta = original(ROOT / 'raw/espn' / (tag + '-2026.json'))
    fotmob, f_meta = original(ROOT / 'raw/fotmob' / (tag + '.json'))
    require(all(meta['competition'] == code for meta in (u_meta, e_meta, f_meta)), 'calendar provenance')
    params = parse_qs(urlsplit(u_meta['url']).query)
    require(params == {'phase': ['ALL'], 'competitionId': [comp_id], 'seasonYear': ['2027'],
                       'fromDate': ['2026-11-25'], 'toDate': ['2026-12-11'], 'limit': ['500'],
                       'offset': ['0'], 'order': ['ASC']} and len(official) < 500, 'UEFA interval query/pagination')
    require(espn['leagues'][0]['slug'] == code and str(fotmob['details']['id']) == fm_id and
            fotmob['details']['selectedSeason'] == '2026/2027', 'full competitor calendar identity')
    require(parse_qs(urlsplit(e_meta['url']).query) == {'dates': ['2026'], 'limit': ['1000']}
            and len(espn['events']) < 1000, 'ESPN annual calendar window/limit')
    # No round, phase, match ID, status, or team filter at enumeration time.
    entries = {
        'uefa': [(m['id'], m['kickOffTime']['dateTime']) for m in official],
        'espn': [(e['id'], e['date']) for e in espn['events']],
        'fotmob': [(m['id'], m['status']['utcTime']) for m in fotmob['fixtures']['allMatches']],
    }
    sources = {p: fixture_index(v, p) for p, v in entries.items()}
    next_md, = {f['uefa_matchday_id'] for f in fixtures if f['window'] == 'next'}
    end, = {instant(m['matchday']['dateTo']) for m in official if m['matchday']['id'] == next_md}
    start = min(instant(f['kickoff_utc']) for f in fixtures)
    require(GUARD_START < common_start <= start < end < GUARD_END and
            all(instant(m['response_received_utc']) < common_start for m in (u_meta, e_meta, f_meta)), 'prematch capture/guard')
    refs = {r['uefa_event_id']: r for r in fixtures}
    round_counts = Counter()
    for m in official:
        require(m['competition']['id'] == comp_id and m['seasonYear'] == '2027', 'UEFA all-phase competition/season')
        r = refs[str(m['id'])]
        require(r['uefa_matchday_id'] == m['matchday']['id'] and r['round'] == int(m['matchday']['sequenceNumber'])
                and m['round']['metaData']['name'] == r['stage'] and r['uefa_status'] == m['status'] == 'UPCOMING'
                and not m.get('fullTimeAt') and str(m['homeTeam']['id']) == r['uefa_home_id']
                and str(m['awayTeam']['id']) == r['uefa_away_id'], 'UEFA all-phase fixture')
        round_counts[r['round']] += 1
    counts = {}
    for provider, events in sources.items():
        expected = {r[provider + '_event_id']: instant(r['kickoff_utc']) for r in fixtures}
        guard = {i: t for i, t in events.items() if GUARD_START <= t < GUARD_END}
        combined = {i: t for i, t in events.items() if common_start <= t <= end}
        own = {i: t for i, t in events.items() if start <= t <= end}
        require(len(expected) == 36 and guard == combined == own == expected, provider + ' extra, absent, or shifted match')
        days = Counter(t.date().isoformat() for t in guard.values())
        counts[provider] = dict(raw_events_scanned=len(events), guard_events=len(guard), interval_events=len(own),
                                extra_ids=sorted(own.keys() - expected.keys()), missing_ids=sorted(expected.keys() - own.keys()),
                                daily_utc={(GUARD_START + timedelta(days=d)).date().isoformat():
                                           days[(GUARD_START + timedelta(days=d)).date().isoformat()]
                                           for d in range((GUARD_END - GUARD_START).days)})
    require(len(round_counts) == 2 and set(round_counts.values()) == {18}, 'two full matchdays')
    return dict(competition=code, first_kickoff_utc=utc(start), first_kickoff_bjt=start.astimezone(BJT).isoformat(),
                end_matchday_id=next_md, scheduled_matchday_end_utc=utc(end),
                scheduled_matchday_end_bjt=end.astimezone(BJT).isoformat(),
                end_source_field='UEFA matchday.dateTo', observed_final_whistle=None,
                registered_matchday_counts=dict(sorted(round_counts.items())),
                next_round_bjt_slots=dict(sorted(Counter(r['kickoff_bjt'] for r in fixtures if r['window'] == 'next').items())),
                first_round_bjt_slots=dict(sorted(Counter(r['kickoff_bjt'] for r in fixtures if r['window'] == 'first').items())),
                source_checks=counts, sources={p: source_ref(m) for p, m in zip(PROVIDERS, (u_meta, e_meta, f_meta))})


def compute():
    files = ('first-round.jsonl', 'next-round.jsonl', 'calendar.csv')
    fixtures = [json.loads(line) for name in files[:2] for line in (DERIVED / name).read_text().splitlines()]
    start = min(instant(f['kickoff_utc']) for f in fixtures)
    audit = dict(common_first_kickoff_utc=utc(start), guard_start_utc=utc(GUARD_START),
                 guard_end_exclusive_utc=utc(GUARD_END),
                 competitions={tag: interval_for(tag, [r for r in fixtures if r['tag'] == tag], start) for tag in COMPS})
    pinned = []
    for r in fixtures:
        entry = {k: r[k] for k in ('stable_match_id', 'competition', 'stage', 'season', 'window', 'round',
                                    'uefa_stage_id', 'uefa_matchday_id', 'home', 'away', 'kickoff_utc', 'kickoff_bjt')}
        entry['provider_ids_and_status'] = {
            p: {k: r[p + '_' + k] for k in ('event_id', 'home_id', 'away_id', 'status')} for p in PROVIDERS}
        entry['calendar_row_sha256'] = fingerprint(r)
        pinned.append(entry)
    fixed = dict(schema_version=1, event_count=len(pinned),
                 files_sha256={name: sha256((DERIVED / name).read_bytes()).hexdigest() for name in files},
                 ordered_fixtures=pinned)
    return audit, fixed


if __name__ == '__main__':
    audit, fixed = compute()
    put(DERIVED / 'interval-audit.json', audit)
    put(DERIVED / 'fixed-calendar.json', fixed)
    for tag, record in audit['competitions'].items():
        print(tag, record['registered_matchday_counts'], record['next_round_bjt_slots'])
