"""Read the first-window ESPN summary bookmaker observations without mixing shops or captures."""
from collections import Counter
from decimal import Decimal
from pathlib import Path
import json
import re
from urllib.parse import urlsplit,parse_qs

from capture import COMPS, ROOT, put
from calendar_build import DERIVED, fingerprint, instant, original, require, store_csv, store_lines, utc

FIELDS=('home','draw','away','over','under')


def american(value):
    if value is None or value=='':
        return None
    if isinstance(value,str) and value.upper() in ('EVEN','EVS'):
        return 100
    n=Decimal(str(value))
    require(n.is_finite() and n==int(n) and abs(n)>=100,'invalid American price')
    return int(n)


def decimal_price(n):
    if n is None:
        return None
    return round(1+n/100 if n>0 else 1+100/abs(n),8)


def number_line(x,side=None):
    if x is None:
        return None
    s=str(x).strip()
    if side and s.lower().startswith(side[0]):
        s=s[1:]
    v=Decimal(s)
    require(v.is_finite() and v>=0,'invalid total line')
    return float(v)


def clock_fields(obj,path=''):
    times={}
    if isinstance(obj,dict):
        for k,v in obj.items():
            if k in ('link','links','team','provider','logos'):
                continue
            field=path+'.'+k if path else k
            if k.lower() in ('lastupdated','updatedat','asof','quotedat','quotetime','timestamp','date','time','lastmodified') and v is not None:
                times[field]=v
            if isinstance(v,(list,dict)):
                times.update(clock_fields(v,field))
    elif isinstance(obj,list):
        for i,v in enumerate(obj):
            times.update(clock_fields(v,path+f'[{i}]'))
    return times


def native_ids(row):
    links=[]
    def visit(obj):
        if isinstance(obj,dict):
            for k,v in obj.items():
                if k=='href' and isinstance(v,str):
                    links.append(v)
                elif isinstance(v,(dict,list)):
                    visit(v)
        elif isinstance(obj,list):
            for v in obj:visit(v)
    visit(row)
    ids=set()
    for link in links:
        addr=urlsplit(link)
        if not (addr.hostname or '').endswith('draftkings.com'):
            continue
        for candidate in (link,*parse_qs(addr.query).get('preurl',[])):
            path=urlsplit(candidate)
            if path.hostname=='sportsbook.draftkings.com':
                mid=re.search(r'/event/(\d+)(?:/|$)',path.path)
                if mid:ids.add(mid.group(1))
    require(len(ids)<=1,'conflicting bookmaker event IDs in one observation')
    return next(iter(ids),None)


def market_values(row):
    plains={k:american((row.get(k+'TeamOdds' if k!='draw' else 'drawOdds') or {}).get('moneyLine'))
            for k in ('home','draw','away')}
    plains.update({k:american(row.get(k+'Odds')) for k in ('over','under')})
    line=number_line(row.get('overUnder'))
    native_snapshot={}
    for k in FIELDS:
        market=row.get('moneyline' if k in ('home','draw','away') else 'total') or {}
        part=(market.get(k) or {}).get('close') or {}
        native_snapshot[k]=american(part.get('odds'))
        if k in ('over','under'):
            native_snapshot[k+'_line']=number_line(part.get('line'),k)
    # The primary fields are from one bookmaker object. A complete nested representation is
    # a consistency check or (if necessary) a whole alternative observation, never a splice.
    complete_flat=line is not None and all(v is not None for v in plains.values())
    complete_nested=all(native_snapshot[k] is not None for k in FIELDS) and native_snapshot['over_line'] is not None and native_snapshot['over_line']==native_snapshot['under_line']
    agree=all(plains[k] is None or native_snapshot[k] is None or plains[k]==native_snapshot[k] for k in FIELDS)
    agree=agree and all(line is None or native_snapshot[s+'_line'] is None or line==native_snapshot[s+'_line'] for s in ('over','under'))
    if not agree:
        return {k:None for k in FIELDS},None,'CONFLICTING_DISPLAYS',False
    if complete_flat or not complete_nested:
        return plains,line,'ESPN_SUMMARY_BOOKMAKER_FIELDS',complete_flat and complete_nested
    return {k:native_snapshot[k] for k in FIELDS},native_snapshot['over_line'],'ESPN_SUMMARY_NESTED_CLOSE',False


def row_for(calendar, board):
    eid,tag=calendar['espn_event_id'],calendar['tag']
    path=ROOT/'raw/espn-summaries'/(eid+'.json')
    doc,meta=original(path)
    head=doc['header']
    event,=head['competitions']
    identity={s:x['team']['id'] for x in event['competitors'] for s in [x['homeAway']]}
    require(meta['event_id']==head['id']==event['id']==eid and meta['competition']==calendar['competition']
            and head['league']['slug']==calendar['competition'] and head['season']['year']==2026
            and 'League Phase' in head['season']['name'] and head['timeValid'] is True
            and event['status']['type']['state']=='pre' and event['status']['type']['completed'] is False
            and event['status']['type']['name']=='STATUS_SCHEDULED'
            and instant(event['date'])==instant(calendar['kickoff_utc'])
            and instant(meta['response_received_utc'])<instant(calendar['kickoff_utc'])
            and len(event['competitors'])==2 and identity=={s:calendar['espn_'+s+'_id'] for s in ('home','away')},
            'summary does not match registered prematch ID/time/sides: '+eid)
    provider_rows=[r for r in (doc.get('odds') or []) if r]
    shop=lambda r:(str((r.get('provider') or {}).get('id','')), (r.get('provider') or {}).get('name',''))
    dk=[r for r in provider_rows if shop(r)==('100','DraftKings')]
    require(len(dk)<=1 and not any((shop(r)[0]=='100')!=(shop(r)[1]=='DraftKings') for r in provider_rows),
            'ambiguous ESPN sportsbook identity')
    b,=board['competitions']
    board_shops=[shop(r)[1] for r in (b.get('odds') or []) if r]
    query=meta['request_started_utc']
    end=meta['response_received_utc']
    prices,line,which,cross={k:None for k in FIELDS},None,'NO_DRAFTKINGS_ROW',False
    book_id=book_sha=quoted=None
    clocks={}
    extra=None
    if dk:
        raw=dk[0]
        prices,line,which,cross=market_values(raw)
        book_id,book_sha=native_ids(raw),fingerprint(raw)
        clocks=clock_fields(raw)
        # Only an explicitly bookmaker-row quote timestamp can represent the whole current snapshot.
        for k in ('quotedAt','quoteTime','lastUpdated','updatedAt','asOf'):
            if raw.get(k):
                quoted=utc(instant(raw[k]))
                require(instant(quoted)<=instant(end),'future bookmaker timestamp')
                break
    else:
        require('DraftKings' not in board_shops,'summary missing a DraftKings quote available on the board')
        cp=ROOT/'raw/espn-core-odds'/(eid+'-providers.json')
        if cp.exists():
            cd,cm=original(cp)
            require(cm['event_id']==eid and cm['competition']==calendar['competition']
                    and instant(cm['response_received_utc'])<instant(calendar['kickoff_utc'])
                    and cd['count']==0 and cd['items']==[],'core provider list differs')
            extra=cm
    missing=[k for k in FIELDS if prices[k] is None]
    if line is None:
        missing.append('total_line')
    complete=not missing
    fields={k+'_american':v for k,v in prices.items()}
    fields.update({k+'_decimal_from_american':decimal_price(v) for k,v in prices.items()})
    row={k:calendar[k] for k in ('tag','competition','round','stage','stable_match_id','uefa_event_id','espn_event_id',
                                 'fotmob_event_id','home','away','espn_home_id','espn_away_id','kickoff_utc','kickoff_bjt')}
    row.update(requested_bookmaker='DraftKings',bookmaker='DraftKings' if dk else None,
               espn_provider_id='100' if dk else None,draftkings_event_id=book_id,market_status='COMPLETE' if complete else which,
               snapshot_representation=which,**fields,total_line=line,
               three_way_complete=all(prices[s] is not None for s in ('home','draw','away')),
               both_totals_and_line=line is not None and all(prices[s] is not None for s in ('over','under')),
               both_native_representations_agree=cross,missing_market_fields=missing,summary_bookmakers=[shop(r)[1] for r in provider_rows],
               scoreboard_bookmakers=board_shops,quote_time_utc=quoted,
               quote_clock_status='EXPLICIT_QUOTE_TIME' if quoted else 'NOT_SUPPLIED' if dk else 'NO_BOOKMAKER_ROW',
               candidate_clock_fields=clocks,source_request_utc=query,source_response_utc=end,source_http_date=meta['http_date'],
               source_http_status=meta['http_status'],source_url=meta['url'],source_raw_path=meta['path'],source_sha256=meta['sha256'],
               source_quote_object_sha256=book_sha,missing_provider_list_evidence=extra)
    return row


def main():
    calendar=[json.loads(l) for l in (DERIVED/'first-round.jsonl').read_text().splitlines()]
    boards={}
    for tag in COMPS:
        raw,_=original(ROOT/'raw/espn'/(tag+'-2026.json'))
        boards[tag]={r['id']:r for r in raw['events']}
    rows=[row_for(r,boards[r['tag']][r['espn_event_id']]) for r in calendar]
    require(len(rows)==len({r['espn_event_id'] for r in rows})==36,'market denominator')
    store_lines(DERIVED/'first-round-draftkings.jsonl',rows)
    def compact(value):
        if isinstance(value,list):
            return '|'.join(value)
        if isinstance(value,dict):
            return json.dumps(value,ensure_ascii=False,sort_keys=True)
        return value
    store_csv(DERIVED/'first-round-draftkings.csv',[{k:compact(v) for k,v in r.items()} for r in rows])
    def count(rr):
        return dict(registered=len(rr),prematch_summaries=len(rr),dk_rows=sum(r['bookmaker'] is not None for r in rr),
                    complete_same_book=sum(r['market_status']=='COMPLETE' for r in rr),
                    three_way=sum(r['three_way_complete'] for r in rr),
                    two_sided_total_with_line=sum(r['both_totals_and_line'] for r in rr),
                    provider_quote_clocks=sum(r['quote_time_utc'] is not None for r in rr),
                    preserved_dk_event_ids=sum(r['draftkings_event_id'] is not None for r in rr),
                    raw_current_fields_cross_checked=sum(r['both_native_representations_agree'] for r in rr),
                    query_started_utc=min(r['source_request_utc'] for r in rr),
                    latest_response_utc=max(r['source_response_utc'] for r in rr),
                    missing=[{k:r[k] for k in ('competition','uefa_event_id','espn_event_id','fotmob_event_id','home','away','market_status')} for r in rr if r['market_status']!='COMPLETE'])
    stats=dict(total=count(rows),competition={tag:count([r for r in rows if r['tag']==tag]) for tag in COMPS})
    put(DERIVED/'market-check.json',stats)
    print(json.dumps(stats['total'],ensure_ascii=False))


if __name__=='__main__':
    main()
