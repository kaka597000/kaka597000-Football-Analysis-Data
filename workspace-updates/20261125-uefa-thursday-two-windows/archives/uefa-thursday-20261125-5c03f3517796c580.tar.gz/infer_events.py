"""Join the separate InferSports event list to the frozen first matchdays before fetching quotes."""
import json
import os
import time
import unicodedata

from alternative_capture import OUT, authenticated
from calendar_build import DERIVED, instant, original, require

LEAGUES = {'uel': 'lg_NW0GJ4SZ', 'uecl': 'lg_PVTBWSDE'}
# Source club ID, spelling in the source and the exact UEFA club name. Recheck
# both spellings when used so a recycled ID or an unexpected alias fails closed.
ALIASES = {
    'tm_QWV9CSBR': ('Beer Sheva', 'H. Beer-Sheva'),
    'tm_D7FY8PZV': ('St.Gilloise', 'Union SG'),
    'tm_CMJP3BPA': ('Lech', 'Lech Poznań'),
    'tm_NFSGJ4SZ': ('Red bull Salzburg', 'Salzburg'),
    'tm_HXDV26EK': ('Plzen', 'Viktoria Plzeň'),
    'tm_MJT97TV6': ('Crete', 'OFI Crete'),
    'tm_2DNFAYC5': ('Nijmegen', 'N.E.C.'),
    'tm_4NNQVPJX': ('Stade Rennes', 'Rennes'),
    'tm_NW9GJ4SZ': ('Ferencvarosi', 'Ferencváros'),
    'tm_9A6K4H2E': ('Egnatia Rrogozhine', 'Egnatia'),
    'tm_TF8M68DX': ('AGF Aarhus', 'Aarhus'),
    'tm_CRTKP3BP': ('Nordsjaelland', 'Nordsjælland'),
    'tm_21S6AYC5': ('Borac BL', 'Borac'),
    'tm_NB4TGJ4S': ('Hajduk', 'Hajduk Split'),
    'tm_WG3BR6XB': ('St.Truidense', 'Sint-Truidense'),
}


def normalized(value):
    return ''.join(c for c in unicodedata.normalize('NFKD', value).casefold() if c.isalnum())


def same_club(team, fixture, side):
    if team['id'] in ALIASES:
        return ALIASES[team['id']] == (team['name'], fixture['uefa_' + side])
    return any(normalized(team['name']) == normalized(fixture[p + '_' + side])
               for p in ('uefa', 'espn', 'fotmob'))


def join_events():
    data, meta = original(OUT / 'infer-events.json')
    fixtures = [json.loads(row) for row in (DERIVED / 'first-round.jsonl').read_text().splitlines()]
    require(data['page']['next_cursor'] is None and len(data['data']) <= data['page']['limit'], 'event list pagination')
    relevant = [e for e in data['data'] if e['league']['id'] in LEAGUES.values()]
    require(len(relevant) == len(fixtures) == 36, 'event list denominator')
    pairs = []
    for f in fixtures:
        candidates = [e for e in relevant if e['league']['id'] == LEAGUES[f['tag']]
                      and e['league']['name'] == f['tag'].upper() and e['sport'] == 'football'
                      and e['status'] == 'scheduled' and instant(e['scheduled_at']) == instant(f['kickoff_utc'])
                      and all(same_club(e[s + '_team'], f, s) for s in ('home', 'away'))]
        require(len(candidates) == 1, 'ambiguous or absent InferSports fixture: ' + f['home'] + ' / ' + f['away'])
        pairs.append((f, candidates[0]))
    require(len({e['id'] for _, e in pairs}) == len(pairs) and
            len({e[s + '_team']['id'] for _, e in pairs for s in ('home', 'away')}) == 72, 'source identity uniqueness')
    return pairs, meta


def collect():
    pairs, _ = join_events()
    key = os.environ.get('WCPP_INFERSPORTS_KEY') or os.environ.get('infer_yapan_zhishu')
    require(key, 'authorized InferSports credential required for live capture')
    for f, event in pairs:
        name = event['id'] + '-odds'
        if (OUT / (name + '.meta.json')).is_file():
            continue
        meta = authenticated(name, 'https://api.infersports.dev', '/v1/events/' + event['id'] + '/odds',
                             {'format': 'decimal'}, 'InferSports bookmaker offers', key, tag=f['tag'], bearer=True)
        if meta['http_status'] != 200:
            print('Stopped on provider status', meta['http_status'], flush=True)
            break
        if meta['rate_limit_remaining'] is not None and int(meta['rate_limit_remaining']) <= 1:
            print('Waiting for source rate window', flush=True)
            time.sleep(61)
        else:
            time.sleep(2.2)


if __name__ == '__main__':
    collect()
