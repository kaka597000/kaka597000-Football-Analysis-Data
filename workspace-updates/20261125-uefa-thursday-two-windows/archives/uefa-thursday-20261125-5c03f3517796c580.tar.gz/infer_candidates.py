"""Rebuild independent full-time candidate quotes from captured bytes. No network calls."""
from collections import Counter, defaultdict
import json
from math import isfinite

from calendar_build import fingerprint, instant, original, require, store_csv, store_lines
from capture import ROOT, put
from infer_events import OUT, join_events

BOOKS = {'crown', 'hkjc', 'm8bet', 'macau', 'nova88', 'sbobet'}
FIELDS = {'1x2': ('home', 'draw', 'away'), 'totals': ('over', 'under')}
OUTPUT = ROOT / 'alternatives'


def number(value):
    return type(value) in (int, float) and isfinite(value)


def exclusion(row, receipt, kickoff):
    kind = row.get('market_type')
    if kind not in FIELDS or row.get('period') != 'full_time':
        return 'other_market_or_period'
    if row.get('status') != 'open' or row.get('format') != 'decimal' or row.get('bookmaker') not in BOOKS:
        return 'ineligible_status_format_or_book'
    prices = row.get('prices')
    if not isinstance(prices, dict) or any(not number(prices.get(k)) or prices[k] <= 1 for k in FIELDS[kind]):
        return 'missing_or_invalid_prices'
    try:
        clock = instant(row['as_of'])
    except (AttributeError, KeyError, TypeError, ValueError):
        return 'no_usable_quote_clock'
    if not clock <= receipt < kickoff:
        return 'invalid_quote_time_order'
    line, components = row.get('line'), row.get('handicap_components')
    if kind == '1x2':
        if line is not None or components is not None:
            return 'unexpected_moneyline_line'
    else:
        if not number(line) or line <= 0 or line * 4 != round(line * 4):
            return 'invalid_total_line'
        if any(row.get(k, line) != line for k in ('over_line', 'under_line')):
            return 'different_total_side_lines'
        if components is not None and (line * 2 == round(line * 2) or components != [line - .25, line + .25]):
            return 'invalid_split_line'
    return None


def build():
    matches, event_meta = join_events()
    all_markets, all_pairs, coverage = [], [], []
    book_counts, exclusions = Counter(), Counter()
    for f, event in matches:
        fixture = {k: f[k] for k in ('stable_match_id', 'competition', 'round', 'home', 'away', 'kickoff_utc',
                                      'espn_event_id', 'fotmob_event_id', 'uefa_event_id')}
        fixture.update(infer_event_id=event['id'], infer_league_id=event['league']['id'],
                       infer_home_id=event['home_team']['id'], infer_home_name=event['home_team']['name'],
                       infer_away_id=event['away_team']['id'], infer_away_name=event['away_team']['name'])
        path = OUT / (event['id'] + '-odds.json')
        source, meta = original(path)
        require(source['event_id'] == event['id'] and meta['url'] ==
                'https://api.infersports.dev/v1/events/' + event['id'] + '/odds?format=decimal',
                'odds response/event binding')
        require(meta['competition'] in (None, f['competition']) and instant(event_meta['response_received_utc'])
                <= instant(meta['request_started_utc']) <= instant(meta['response_received_utc']) < instant(f['kickoff_utc']),
                'source response must predate kickoff')
        proof = dict(source_path=meta['path'], source_sha256=meta['sha256'], source_request_utc=meta['request_started_utc'],
                     source_response_utc=meta['response_received_utc'], response_as_of=source.get('as_of'),
                     http_date=meta.get('http_date'), event_list_sha256=event_meta['sha256'])
        groups = defaultdict(list)
        dropped = Counter()
        for i, row in enumerate(source['odds']):
            reason = ('provider_response_stale_or_unknown' if source.get('stale') is not False else
                      exclusion(row, instant(meta['response_received_utc']), instant(f['kickoff_utc'])))
            if reason:
                dropped[reason] += 1
            else:
                groups[(row['bookmaker'], row['market_type'], row.get('line'))].append((i, row))
        markets = []
        for (book, kind, line), group in sorted(groups.items()):
            signatures = {fingerprint(g) for _, g in group}
            if len(signatures) > 1:
                dropped['conflicting_book_market_line'] += len(group)
                continue
            i, q = group[0]
            if len(group) > 1:
                dropped['identical_duplicate'] += len(group) - 1
            age = (instant(meta['response_received_utc']) - instant(q['as_of'])).total_seconds()
            markets.append(dict(fixture, **proof, bookmaker=book, market=kind, period=q['period'], line=line,
                                format=q['format'], status=q['status'], handicap_components=q.get('handicap_components'),
                                prices={k: q['prices'][k] for k in FIELDS[kind]}, quote_time=q['as_of'],
                                quote_age_seconds_at_receipt=age, source_row_index=i, source_row_sha256=fingerprint(q)))
        pairs = []
        money = {m['bookmaker']: m for m in markets if m['market'] == '1x2'}
        for total in (m for m in markets if m['market'] == 'totals' and m['bookmaker'] in money):
            three = money[total['bookmaker']]
            same_time = instant(three['quote_time']) == instant(total['quote_time'])
            pairs.append(dict(fixture, **proof, bookmaker=total['bookmaker'], total_line=total['line'],
                              total_components=json.dumps(total['handicap_components'], separators=(',', ':')),
                              home_decimal=three['prices']['home'], draw_decimal=three['prices']['draw'],
                              away_decimal=three['prices']['away'], over_decimal=total['prices']['over'],
                              under_decimal=total['prices']['under'], moneyline_quote_time=three['quote_time'],
                              totals_quote_time=total['quote_time'], same_quote_time=same_time,
                              moneyline_age_seconds=three['quote_age_seconds_at_receipt'],
                              totals_age_seconds=total['quote_age_seconds_at_receipt'],
                              both_within_1h_at_receipt=max(three['quote_age_seconds_at_receipt'],
                                                             total['quote_age_seconds_at_receipt']) <= 3600,
                              moneyline_raw_index=three['source_row_index'], totals_raw_index=total['source_row_index'],
                              moneyline_raw_row_sha256=three['source_row_sha256'], totals_raw_row_sha256=total['source_row_sha256']))
        coverage.append(dict(fixture, **proof, source_stale=source.get('stale'), raw_odds_rows=len(source['odds']),
                             eligible_market_rows=len(markets), excluded_rows=dict(sorted(dropped.items())),
                             pair_count=len(pairs), same_time_pairs=sum(p['same_quote_time'] for p in pairs),
                             both_within_1h_pairs=sum(p['both_within_1h_at_receipt'] for p in pairs),
                             books_with_pairs=sorted({p['bookmaker'] for p in pairs})))
        require(len(markets) + sum(dropped.values()) == len(source['odds']), 'raw quote denominator')
        book_counts.update(p['bookmaker'] for p in pairs)
        all_markets.extend(markets)
        all_pairs.extend(pairs)
        exclusions.update(dropped)
    docs = json.loads((OUT / 'infer-public-guide.meta.json').read_bytes())
    result = dict(provider='InferSports', quote_time_source='odds[i].as_of',
                  quote_time_definition='Last upstream update applied to this bookmaker and market line, in UTC.',
                  clock_reference=dict(path=docs['path'], sha256=docs['sha256'], section='Field reference / OddsQuote'),
                  response_time_source='top-level as_of', event_list_source=event_meta['path'],
                  event_list_sha256=event_meta['sha256'], registered_fixtures=len(matches),
                  fixtures_with_same_book_pair=sum(c['pair_count'] > 0 for c in coverage),
                  fixtures_with_equal_clocks=sum(c['same_time_pairs'] > 0 for c in coverage),
                  fixtures_with_both_clocks_within_1h=sum(c['both_within_1h_pairs'] > 0 for c in coverage),
                  fixtures_with_equal_clocks_within_1h=len({p['stable_match_id'] for p in all_pairs
                                                           if p['same_quote_time'] and p['both_within_1h_at_receipt']}),
                  markets=len(all_markets), pairs=len(all_pairs), equal_clock_pairs=sum(p['same_quote_time'] for p in all_pairs),
                  both_within_1h_pairs=sum(p['both_within_1h_at_receipt'] for p in all_pairs),
                  equal_clock_pairs_within_1h=sum(p['same_quote_time'] and p['both_within_1h_at_receipt'] for p in all_pairs),
                  by_book=dict(sorted(book_counts.items())), excluded_raw_rows=dict(sorted(exclusions.items())),
                  fixtures=coverage)
    return all_markets, all_pairs, result


if __name__ == '__main__':
    OUTPUT.mkdir(exist_ok=True)
    markets, pairs, report = build()
    store_lines(OUTPUT / 'infersports-markets.jsonl', markets)
    store_csv(OUTPUT / 'infersports-same-book.csv', pairs)
    put(OUTPUT / 'coverage.json', report)
    print(json.dumps({k: v for k, v in report.items() if k != 'fixtures'}, sort_keys=True))
