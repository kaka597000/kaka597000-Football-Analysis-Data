"""Capture public calendar/summary bytes with separate request, response and HTTP clocks."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import gzip
import json
from pathlib import Path
import time
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parent
COMPS = {'uel': ('uefa.europa', '14', '73'), 'uecl': ('uefa.europa.conf', '2019', '10216')}


def raw_json(path):
    body = path.read_bytes()
    return json.loads(gzip.decompress(body) if body.startswith(b'\x1f\x8b') else body)


def now():
    return datetime.now(timezone.utc).isoformat(timespec='microseconds').replace('+00:00', 'Z')


def put(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n')


def capture(path, url, provider, tag, **scope):
    side = path.with_suffix('.meta.json')
    if path.exists() and side.exists():
        stored = json.loads(side.read_bytes())
        if stored['url'] != url or hashlib.sha256(path.read_bytes()).hexdigest() != stored['sha256']:
            raise ValueError('capture path collision: ' + str(path))
        return stored
    if path.exists() or side.exists():
        raise ValueError('incomplete existing capture: ' + str(path))
    request = urllib.request.Request(url, headers={'User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/131.0 Safari/537.36',
                                                   'Accept':'application/json, text/plain, */*','Accept-Language':'en-US,en;q=0.8',
                                                   'Accept-Encoding':'identity'})
    start = now()
    try:
        with urllib.request.urlopen(request, timeout=38) as res:
            body = res.read()
            status, headers, final_url = res.status, res.headers, res.geturl()
    except urllib.error.HTTPError as exc:
        body, status, headers, final_url = exc.read(), exc.code, exc.headers, exc.geturl()
    end = now()
    info = dict(provider=provider, competition=COMPS[tag][0] if tag else None, url=url, response_url=final_url, http_status=status,
                request_started_utc=start,response_received_utc=end, http_date=headers.get('Date'),
                last_modified=headers.get('Last-Modified'), cache_age_seconds=headers.get('Age'),
                content_type=headers.get('Content-Type'),content_encoding=headers.get('Content-Encoding'),
                bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),
                path=str(path.relative_to(ROOT)),**scope)
    path.write_bytes(body)
    put(side,info)
    return info


def calendars(provider):
    for tag,(espn,uefa,fm) in COMPS.items():
        if provider=='espn':
            url=f'https://site.api.espn.com/apis/site/v2/sports/soccer/{espn}/scoreboard?dates=2026&limit=1000'
        elif provider=='uefa':
            url=f'https://match.uefa.com/v5/matches?competitionId={uefa}&seasonYear=2027&phase=TOURNAMENT&limit=500&offset=0&order=ASC'
        else:
            url=f'https://www.fotmob.com/api/data/leagues?id={fm}&ccode3=USA&season=2026%2F2027'
        name = tag+'-2026.json' if provider=='espn' else tag+'-2019.json' if provider=='uefa' and tag=='uecl' else tag+'.json'
        info=capture(ROOT/'raw'/provider/name,url,provider,tag)
        print(provider,tag,info['http_status'],info['bytes'],flush=True)
        time.sleep(.8)


def summaries():
    from collections import defaultdict
    rows = []
    parse = datetime.fromisoformat
    for tag,(code,_,_) in COMPS.items():
        rounds=defaultdict(list)
        for m in raw_json(ROOT/'raw/fotmob'/(tag+'.json'))['fixtures']['allMatches']:
            rounds[int(m['round'])].append(m)
        cutoff = parse(json.loads((ROOT/'raw/fotmob'/(tag+'.meta.json')).read_bytes())['response_received_utc'])
        first=next(v for _,v in sorted(rounds.items()) if len(v)==18 and all(
            not m['status'].get('started') and parse(m['status']['utcTime'])>cutoff for m in v))
        times={parse(m['status']['utcTime']) for m in first}
        selected=[e for e in raw_json(ROOT/'raw/espn'/(tag+'-2026.json'))['events']
                  if e['season']['year']==2026 and e['season']['slug']=='league-phase' and parse(e['date']) in times]
        if len({e['id'] for e in selected})!=18 or any(e['status']['type']['state']!='pre' for e in selected):
            raise ValueError('incomplete ESPN first round for '+code)
        rows.extend(dict(tag=tag,competition=code,espn_event_id=e['id']) for e in selected)
    for row in rows:
        tag,code,eid=row['tag'],row['competition'],row['espn_event_id']
        if not eid:
            continue
        url=f'https://site.api.espn.com/apis/site/v2/sports/soccer/{code}/summary?event={eid}'
        info=capture(ROOT/'raw/espn-summaries'/(eid+'.json'),url,'ESPN summary',tag,event_id=eid)
        print('summary',tag,eid,info['http_status'],info['bytes'],flush=True)
        if info['http_status'] in (401,403,429):
            break
        time.sleep(.9)


def supplemental():
    capture(ROOT/'raw/uefa/uecl-fixtures.html','https://www.uefa.com/uefaconferenceleague/fixtures-results/',
            'UEFA official fixtures page','uecl')
    folder=ROOT/'raw/espn-core-odds'
    folder.mkdir(exist_ok=True)
    for tag,eid,suffix,name,query in (
        ('uecl','401915809','','providers','lang=en&region=us'),
        ('uel','401915506','/100','dk','lang=en&region=us'),
        ('uel','401915506','/100/history/0/movement','movement','limit=10&lang=en&region=us'),
    ):
        code=COMPS[tag][0]
        url=f'https://sports.core.api.espn.com/v2/sports/soccer/leagues/{code}/events/{eid}/competitions/{eid}/odds{suffix}?{query}'
        capture(folder/(eid+'-'+name+'.json'),url,'ESPN core odds movement' if name=='movement' else 'ESPN core odds',tag,event_id=eid)
        time.sleep(.8)


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode',choices=('calendars','summaries','supplemental'))
    args=parser.parse_args()
    if args.mode=='calendars':
        with ThreadPoolExecutor(max_workers=3) as pool:
            list(pool.map(calendars, ('espn','uefa','fotmob')))
    elif args.mode=='summaries':
        summaries()
    else:
        supplemental()
