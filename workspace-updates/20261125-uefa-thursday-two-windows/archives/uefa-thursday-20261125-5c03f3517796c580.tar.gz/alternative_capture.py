"""Collect separate public or authorized discovery snapshots; retain only public URLs and bytes."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
import time
from urllib.parse import urlencode
from urllib.request import Request, HTTPRedirectHandler, build_opener
from urllib.error import HTTPError

from capture import ROOT,COMPS,capture,now,put,raw_json

OUT=ROOT/'raw/alternative'


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self,*args):
        return None


def authenticated(name,host,path,params,provider,key, *, tag=None, bearer=False):
    if not key:
        return None
    OUT.mkdir(exist_ok=True)
    dest=OUT/(name+'.json')
    side=dest.with_suffix('.meta.json')
    public=host+path+('?' + urlencode(params) if params else '')
    if dest.exists() and side.exists():
        cached=json.loads(side.read_bytes())
        if cached['url']!=public or hashlib.sha256(dest.read_bytes()).hexdigest()!=cached['sha256']:
            raise ValueError('capture path collision: '+name)
        return cached
    if dest.exists() or side.exists():
        raise ValueError('incomplete existing capture: '+name)
    url=public if bearer else host+path+'?'+urlencode(dict(params,apiKey=key))
    headers={'Accept':'application/json','Accept-Encoding':'identity'}
    if bearer:headers['Authorization']='Bearer '+key
    start=now()
    try:
        with build_opener(NoRedirect()).open(Request(url,headers=headers),timeout=25) as response:
            body=response.read();stat=response.status;h=response.headers
    except HTTPError as e:
        body=e.read();stat=e.code;h=e.headers
    end=now()
    if key.encode() in body:
        raise ValueError('provider response contains a credential')
    info=dict(provider=provider,competition=COMPS[tag][0] if tag else None,url=public,response_url=public,
              http_status=stat,request_started_utc=start,response_received_utc=end,http_date=h.get('Date'),
              last_modified=h.get('Last-Modified'),cache_age_seconds=h.get('Age'),content_type=h.get('Content-Type'),
              content_encoding=h.get('Content-Encoding'),bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),
              path=str(dest.relative_to(ROOT)),quota_remaining=h.get('x-requests-remaining'),quota_last_cost=h.get('x-requests-last'),
              rate_limit_remaining=h.get('X-RateLimit-Remaining'),rate_limit=h.get('X-RateLimit-Limit'),
              rate_limit_reset=h.get('X-RateLimit-Reset'),
              retry_after=h.get('Retry-After'))
    dest.write_bytes(body);put(side,info)
    print(name,stat,info['quota_remaining'],info['quota_last_cost'],flush=True)
    return info


def odds_api():
    key=next((os.environ[k] for k in ('THE_ODDS','WCPP_ODDS_API_KEY','WCPP_THE_ODDS_API_KEY') if os.environ.get(k)),None)
    base='https://api.the-odds-api.com'
    m=authenticated('odds-api-sports',base,'/v4/sports',{'all':'true'},'The Odds API free sports list',key)
    if not m or m['http_status']!=200 or int(m['quota_remaining'] or 0)<4:
        return
    sports=raw_json(OUT/'odds-api-sports.json')
    for tag,match in [('uel','soccer_uefa_europa_league'),('uecl','soccer_uefa_europa_conference_league')]:
        if not any(s['key']==match and s['active'] for s in sports):
            continue
        args=dict(markets='h2h,totals',bookmakers='pinnacle',oddsFormat='decimal',
                  commenceTimeFrom='2026-11-26T00:00:00Z',commenceTimeTo='2026-11-27T23:59:59Z')
        m=authenticated('odds-api-'+tag,base,'/v4/sports/'+match+'/odds/',args,'The Odds API bookmaker markets',key,tag=tag)
        if m['http_status']!=200 or int(m['quota_remaining'] or 0)<2:break
        time.sleep(1)


def infer():
    key=os.environ.get('WCPP_INFERSPORTS_KEY') or os.environ.get('infer_yapan_zhishu')
    if key:
        args={'sport':'football','date':'2026-11-26','limit':100}
        authenticated('infer-events','https://api.infersports.dev','/v1/events',args,'InferSports events',key,bearer=True)


def public():
    OUT.mkdir(exist_ok=True)
    tests=[('oddschecker-uel.html','https://www.oddschecker.com/football/europa-league','Oddschecker','uel'),
           ('sportytrader-football.html','https://www.sportytrader.com/en/odds/football/','SportyTrader',None),
           ('asianodds-feed.json','https://www.asianodds.org/d/events?sport=fb','AsianOdds / BetInAsia',None)]
    def run(item):
        filename,url,provider,tag=item
        m=capture(OUT/filename,url,provider,tag)
        print(filename,m['http_status'],m['bytes'],flush=True)
    with ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(run,tests))


if __name__=='__main__':
    with ThreadPoolExecutor(max_workers=3) as pool:
        for task in [pool.submit(fn) for fn in (odds_api,infer,public)]:task.result()
