"""Build a deterministic snapshot or replay one from its original responses, entirely offline."""
import argparse
import gzip
from hashlib import sha256
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import tarfile
from tempfile import TemporaryDirectory

BASE = Path(__file__).resolve().parent
PREFIX = 'uefa-thursday-20261125-'


def require(ok, message):
    if not ok:
        raise ValueError(message)


def files(root):
    selected = [root / name for name in ('README.md', 'source-manifest.json', 'archive-source-manifest.json')]
    selected.extend(root.glob('*.py'))
    for name in ('raw', 'derived', 'alternatives'):
        selected.extend(p for p in (root / name).rglob('*') if p.is_file())
    require(all(p.is_file() and not p.is_symlink() for p in selected), 'missing file or unexpected symlink')
    return sorted(p.relative_to(root).as_posix() for p in selected)


def digest(path):
    h = sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def sums(root):
    return ''.join(digest(root / name) + '  ' + name + '\n' for name in files(root))


def build():
    checksum_text = sums(BASE)
    checksum_file = BASE / 'SHA256SUMS'
    if not checksum_file.is_file() or checksum_file.read_text() != checksum_text:
        checksum_file.write_text(checksum_text)
    names = sorted(files(BASE) + ['SHA256SUMS'])
    with TemporaryDirectory(dir=BASE, prefix='.build-') as temp:
        candidate = Path(temp) / 'snapshot.tar.gz'
        with candidate.open('wb') as handle:
            with gzip.GzipFile(fileobj=handle, filename='', mode='wb', compresslevel=6, mtime=0) as zipped:
                with tarfile.open(fileobj=zipped, mode='w|', format=tarfile.USTAR_FORMAT) as tar:
                    for name in names:
                        p = BASE / name
                        t = tarfile.TarInfo(name)
                        t.size, t.mode, t.mtime = p.stat().st_size, 0o644, 0
                        with p.open('rb') as src:
                            tar.addfile(t, src)
        h = digest(candidate)
        target = BASE / (PREFIX + h[:16] + '.tar.gz')
        if target.exists():
            require(digest(target) == h, 'archive filename collision')
        else:
            candidate.rename(target)
        target.with_name(target.name + '.sha256').write_text(h + '  ' + target.name + '\n')
        print(target.name, h, len(names), 'files', target.stat().st_size, 'bytes')


# Offline child processes use no credentials and fail at creation of any network socket.
CHILD = """
import pathlib, runpy, sys
def offline(event, args):
    if event.startswith('socket.'):
        raise RuntimeError('network disabled for archive readback')
sys.addaudithook(offline)
script = pathlib.Path(sys.argv[1]).resolve()
sys.path.insert(0, str(script.parent))
sys.argv = [str(script)]
runpy.run_path(str(script), run_name='__main__')
"""


def run(root, script):
    completed = subprocess.run([sys.executable, '-I', '-B', '-c', CHILD, script], cwd=root, check=True,
                               capture_output=True, env={'LC_ALL': 'C.UTF-8'}, text=True)
    return completed.stdout.strip()


def replay(path):
    h = digest(path)
    require(path.name == PREFIX + h[:16] + '.tar.gz', 'wrong archive identifier')
    sidecar = path.with_name(path.name + '.sha256')
    if sidecar.exists():
        require(sidecar.read_text() == h + '  ' + path.name + '\n', 'outer archive checksum')
    with TemporaryDirectory(dir=BASE, prefix='.readback-') as temp:
        copy = Path(temp) / 'delivered'
        rebuilt = Path(temp) / 'rebuild'
        copy.mkdir()
        rebuilt.mkdir()
        with tarfile.open(path, 'r:gz') as tar:
            seen = set()
            for entry in tar:
                name = PurePosixPath(entry.name)
                require(entry.isfile() and not name.is_absolute() and '..' not in name.parts and
                        name.as_posix() == entry.name and name not in seen, 'unsafe or duplicate archive member')
                seen.add(name)
                output = copy / name
                output.parent.mkdir(parents=True, exist_ok=True)
                with tar.extractfile(entry) as src, output.open('xb') as dst:
                    shutil.copyfileobj(src, dst)
        content = (copy / 'SHA256SUMS').read_text()
        require(sums(copy) == content and seen == {PurePosixPath(p) for p in files(copy) + ['SHA256SUMS']},
                'delivered hashes/member list')
        for name in files(copy):
            if name.startswith(('alternatives/', 'derived/')):
                continue
            output = rebuilt / name
            output.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(copy / name, output)
        (rebuilt / 'derived').mkdir()
        for script in ('calendar_build.py', 'market_build.py', 'interval_check.py', 'infer_candidates.py'):
            run(rebuilt, script)
        metrics = run(rebuilt, 'verify.py')
        require(sums(rebuilt) == content, 'independently rebuilt content differs from archived evidence')
        print(metrics)
        print('Offline raw replay OK.', len(seen), 'archive members.', h)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('build')
    commands.add_parser('replay').add_argument('archive', type=Path)
    args = parser.parse_args()
    if args.command == 'build':
        build()
    else:
        replay(args.archive.resolve())
