# UEFA Europa / Conference source and loading audit

Captured 2026-11-25 UTC by the current Codex driver (GPT-6). The requested Luna delegate was not callable in this session; no Luna execution is claimed. Scope is raw-source verification and runtime loading diagnosis only. No new forecast, selection, or recommendation was issued. Prior issued records are retained byte-for-byte.

## Current/Test loading finding

Active registry `WCPP-DUAL-4` is `ACTIVE_RESEARCH`. The retained registry and `configs/module-portfolio.json` have null/missing entries for `uefa.europa` and `uefa.europa.conf` in Current and Test. The active entrypoint is `runtime/prediction_service.py:run -> runtime/prediction_engine.py:predict_models`, but there is no competition route/weight bundle to invoke for either code. Phase classification and ingestion scope do exist; they are not a running Current/Test route.

Separate historical R8 candidate archives exist as `WCPP-ALL-SCOPE-SCORE-1` and are not registered for runtime use. Outer archive SHA256: Europa `369305e83a1988f467ddd727282c7583f84fa9b707956d657cfa5705f0636b63`; Conference `69849f3b00d92e4be99aaa218c3383165a942435b7bda1658a9e19d24cca269a`. Per-artifact hashes, fit/selection counts, and trained/selection/tree phase coverage are in `raw/historical-candidates/manifest.json` and `derived/current-test-phase-audit.json`. The classifier lists League Phase, group-stage, playoffs, R16, QF, SF and final for both UEFA codes; classification support alone does not register model weights.

## Fixtures and stages

ESPN and FotMob independently list complete 2026-11-26 UTC (Nov 27 Beijing) rounds, each 18 events. Europa League is League Phase round 5; Conference League is League Phase round 4. `derived/schedule-36.csv` carries event IDs, both provider team IDs, venue, kickoff, and matched FotMob event IDs. Full ESPN scoreboard and FotMob league-calendar bodies, URLs, query/retrieval clocks and SHA256 are retained under `raw/` with `.meta.json` sidecars. `exploratory-id-525.json` is explicitly an earlier wrong-ID probe for AFC Champions League Elite and is not used as Conference evidence.

## Latest domestic evidence before kickoff

The 72 UEFA participants all have FotMob team IDs. 70 teams have a prior finished primary-domestic-league fixture on their team pages (68 unique matches); two have no earlier finished primary-league match in that retained fixture view. Each team row in `derived/team-last-domestic-evidence-72.csv` includes the opponent, provider match ID, source match UTC clock, FT score, xG, shots on target, XI count/source, detail-page retrieval clock, source URL, and source SHA when present. Coverage from the retained detail pages: 70/72 FT score, 47/72 team xG, 62/72 team SOT and 62/72 starting XIs with 11 named starters. Missing values stay blank. xG/SOT use FotMob's `All` period stat arrays and the team side indexed by home/away; FT score comes from the finished, non-awarded match status.

ESPN event summaries were retrieved for all 36 upcoming fixtures. They expose team-level roster shells, no player-level squad list and no injury report in these captures; they do not establish player availability. `derived/upcoming-personnel-summary-coverage.csv` records this explicitly. No absence was inferred from missing data.

## Prior first-prematch registrations

`derived/prior-first-prematch-records.csv` indexes 180 preserved first-prematch issue records. R8, R9, R10 and R13 each cover all 36 events; their track, stage, freeze ID, timestamp, registration hash, record hash and retained file hash are copied from the archived index under `raw/issued-firsts/`. Those 144 records are first revision and marked `model_promotion=false`. The independent R7/original first-issue archive was recovered from `workspace-updates/20261123-prematch-literature/first-issues.tar.gz` (source SHA256 `52f1dd07d146a93ba9cec41ce9e1c9cdf75b3db43f8a65da7ffea222467f385d`). All 36 UEFA event IDs match `receipts.json`; receipt SHA equals each embedded `record_sha256`, and event ID, first-prematch slot, revision 1 and provider issue time were checked. The preserved original track string is `research-prematch-continuation-20261123`; its registration id/hash/time are recorded in `raw/r7-first-issues/source-verification.json`. The exact compressed source archive, receipt ledger, registration JSON and matched raw record members are retained. This augments the index only; earlier R8/R9/R10/R13 records remain unchanged.

## Reproducibility and retained files

- `derived/coverage.json`: aggregate coverage and executor/source scope.
- `derived/current-test-phase-audit.json`: active-vs-historical routing distinction.
- `raw/`: original response bodies and archived model/issue evidence. HTTP responses are retained as received; sidecars include query start, retrieval UTC and body SHA where captured.
- `SHA256SUMS`: hashes of all package files except the sums file itself and final tarball.
- `uefa-thursday-teams-20261125.tar.gz`: portable package.

Public ESPN and FotMob endpoints were called with ordinary unauthenticated GET requests and a normal User-Agent. No login, access challenge, or paid quota was used. No 403/429 response occurred on completed source paths.
