#!/usr/bin/env python3
"""Independent integrity and coverage check for this retained UEFA evidence pack."""
import csv,hashlib,json,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent
errors=[]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
# Validate all raw HTTP sidecars against retained bytes.
checked=0
for m in (p/'raw').rglob('*.meta.json'):
 try:d=json.loads(m.read_text())
 except Exception as e:errors.append(f'{m}: invalid metadata {e}');continue
 rel=d.get('retained_path')
 if rel:
  f=p/rel
  if not f.exists():errors.append(f'{m}: missing {rel}')
  elif d.get('body_sha256') and sha(f)!=d['body_sha256']:errors.append(f'{m}: SHA mismatch {rel}')
  else:checked+=1
sched=list(csv.DictReader((p/'derived/schedule-36.csv').open(encoding='utf-8')))
recent=list(csv.DictReader((p/'derived/team-last-domestic-evidence-72.csv').open(encoding='utf-8')))
issues=list(csv.DictReader((p/'derived/prior-first-prematch-records.csv').open(encoding='utf-8')))
tracks={}
for x in issues:tracks.setdefault(x['track'],set()).add(x['espn_event_id'])
summary={'raw_sidecars_checked':checked,'schedule_rows':len(sched),'schedule_crosschecks_matched':sum(x['schedule_crosscheck']=='matched' for x in sched),'team_rows':len(recent),'teams_with_domestic_match':sum(bool(x['fotmob_match_id']) for x in recent),'ft_scores':sum(bool(x['ft90_score']) for x in recent),'xg':sum(bool(x['xg']) for x in recent),'sot':sum(bool(x['sot']) for x in recent),'xi11':sum(x['xi_count']=='11' for x in recent),'prior_issue_records':len(issues),'prior_track_event_counts':{k:len(v) for k,v in tracks.items()}}
for comp in ('uefa.europa','uefa.europa.conf'):
 if sum(x['competition']==comp for x in sched)!=18:errors.append(f'{comp}: expected 18 schedule rows')
if len(recent)!=72:errors.append('expected 72 team rows')
# Verify the recovered original R7 archive against each target ESPN event and retained raw member.
r7archive=p/'raw/r7-first-issues/first-issues.tar.gz'
r7rows=[x for x in json.load((p/'raw/issued-firsts/index.json').open()) if x.get('track')=='research-prematch-continuation-20261123']
r7checked=0
try:
 with tarfile.open(r7archive,'r:gz') as tf:
  receipt=json.load(tf.extractfile('receipts.json'))
  if len(r7rows)!=36: errors.append(f'expected 36 R7 rows, found {len(r7rows)}')
  for x in r7rows:
   r=receipt['matches'][x['match_id']]; body=tf.extractfile(r['file']).read(); obj=json.loads(body)
   retained=p/x['retained_path']
   if obj.get('record_sha256')!=r.get('sha256') or obj.get('recorded_at')!=r.get('recorded_at') or obj.get('match_id')!=x.get('match_id') or obj.get('evaluation_slot')!='FIRST_PREMATCH' or obj.get('revision')!=1: errors.append(f"R7 receipt mismatch: {x.get('match_id')}")
   if not retained.exists() or sha(retained)!=hashlib.sha256(body).hexdigest(): errors.append(f"R7 raw member mismatch: {x.get('match_id')}")
   r7checked+=1
except Exception as e: errors.append(f'R7 archive check failed: {e}')
summary['r7_receipts_verified']=r7checked
if errors: print(json.dumps({'ok':False,'errors':errors,'recomputed':summary},indent=2));raise SystemExit(1)
print(json.dumps({'ok':True,'recomputed':summary},indent=2))
