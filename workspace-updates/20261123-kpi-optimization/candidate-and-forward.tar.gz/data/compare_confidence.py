from pathlib import Path
import importlib.util
from collections import defaultdict
import time
import json
import numpy as np

HERE=Path(__file__).parent
parent=HERE.parent.parent
source=parent/'market-baseline-audit-20261123/compare_market.py'
spec=importlib.util.spec_from_file_location('matched_market_baseline', source)
market=importlib.util.module_from_spec(spec)
spec.loader.exec_module(market)

TARGETS={'first':.20,'three':.40,'wdl':.65,'total':.70}
PARTITIONS={'tune_2425':'tune','holdout_2627_pre_nov21':'holdout'}
SIDE={'home':0,'draw':1,'away':2}

def predict(row):
    # Historical book prices have no intraday provenance.
    t=row['market']
    quote=market._quote_values(t,None,proxy=True)
    plain,pmf=market.base_matrix(quote)
    order=np.argsort(-pmf.ravel(),kind='stable')[:3]
    probs=pmf.ravel()[order]
    real_home,real_away=row['home_goals'],row['away_goals']
    actual_score=real_home*pmf.shape[1]+real_away
    true_wdl=0 if real_home>real_away else 2 if real_home<real_away else 1
    best_wdl=int(np.argmax(quote[0]))
    out=market.score_picks(pmf,line=2.5)['total']
    side=out['direction']
    actual_over=real_home+real_away>=3
    return {
        'first':(float(probs[0]),bool(actual_score==order[0])),
        'three':(float(sum(probs)),bool(actual_score in order)),
        'wdl':(float(quote[0][best_wdl]),true_wdl==best_wdl),
        'total':(float(out['settlements'][side]['win']),actual_over==(side=='over')),
    }

def perf(sample,metric):
    hits=sum(r[metric][1] for r in sample)
    return {'hits':hits,'count':len(sample),'rate':hits/len(sample) if sample else None}

def run():
    begin=time.monotonic()
    groups=defaultdict(list)
    for line in (HERE/'closing-proxy.jsonl').read_text().splitlines():
        r=json.loads(line)
        k=PARTITIONS.get(r['partition'])
        if k and r['market']:
            groups[k].append(predict(r))
    tune,hold=groups['tune'],groups['holdout']
    answers={}
    for metric,target in TARGETS.items():
        answer={}
        answer['full_tune']=perf(tune,metric)
        answer['full_holdout']=perf(hold,metric)
        for n in range(101):
            threshold=n/100
            chosen=[r for r in tune if r[metric][0]>=threshold]
            p=perf(chosen,metric)
            if p['count']>=50 and p['rate']>=target:
                hold_selected=[r for r in hold if r[metric][0]>=threshold]
                answer['threshold']=threshold
                answer['selected_tune']=p|{'coverage':p['count']/len(tune)}
                answer['selected_holdout']=perf(hold_selected,metric)|{'coverage':len(hold_selected)/len(hold)}
                break
        else:
            answer['threshold']=None
        answers[metric]=answer
    params={k:r['threshold'] for k,r in answers.items()}
    if all(v is not None for v in params.values()):
        subset=[r for r in hold if all(r[k][0]>=v for k,v in params.items())]
        intersection={k:perf(subset,k) for k in TARGETS}
    else:
        intersection=None
    answers['holdout_intersection']=intersection
    (HERE/'confidence-sensitivity-results.json').write_text(json.dumps(answers,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(answers,indent=2))
    print('seconds',time.monotonic()-begin)
if __name__=='__main__':
    run()
