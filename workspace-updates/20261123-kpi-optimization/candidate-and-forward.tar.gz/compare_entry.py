import json
import os
from pathlib import Path
import subprocess

B=Path(__file__).resolve().parent
PARENTS=['/workspace/Football-Analysis-score-form-20261122','/workspace/Football-Analysis-kpi-20261123']
PY='/workspace/football-venv/bin/python'
program="""
import json, sys
from prediction_service import run
fixtures=json.load(open(sys.argv[1]))
for f in fixtures:
    out=run(f,'/workspace/WCPP/runtime/active-model.json')
    print(json.dumps(dict(
        id=f['match_id'], current=out['current_model']['matrix_hash'], test=out['test_model']['matrix_hash'],
        choices=[out[k]['primary'] for k in ('current_model','test_model')],
        new_diagnostics=out.get('market_baseline'), strict_total=out.get('strict_total_reference'),
        actual_test_inputs=out.get('test_input_freshness')
    )))
"""
input_file=B/'forward/issued-inputs.json'
input_file.write_text(json.dumps([json.loads(p.read_bytes())['fixture'] for p in sorted((B/'forward/issued').glob('*-forecast.json'))],indent=2)+'\n')
variants=[]
for root in PARENTS:
    env=dict(os.environ,PYTHONPATH=f'{root}/runtime:{root}/runtime/v5:{root}',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
    args=[PY,'-c',program,str(input_file)]
    data=subprocess.run(args,cwd=root,env=env,capture_output=True,text=True)
    if data.returncode:
        raise RuntimeError(data.stderr)
    variants.append([json.loads(line) for line in data.stdout.splitlines() if line.startswith('{')])
for before,after in zip(*variants,strict=True):
    assert all(before[k]==after[k] for k in ['id','current','test','choices'])
    assert after['new_diagnostics']['status']=='ABSTAIN' and after['strict_total']['eligible'] is False
    assert after['actual_test_inputs'] is not None
(B/'entry-equivalence.json').write_text(json.dumps({'comparison':'same live fixtures, programmatic default run, no production freeze',
                                                   'matrix_identities_and_picks_identical':True,'fixtures':variants[1]},indent=2)+'\n')
print('Verified unchanged entire matrix hashes on',len(variants[1]),'real fixtures')
