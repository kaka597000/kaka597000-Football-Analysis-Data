import hashlib
import json
from datetime import datetime
from pathlib import Path

B=Path(__file__).resolve().parents[1]
S=B/'forward-data'
D=B/'forward'
def load(p):return json.loads(p.read_bytes())
def write(p,obj):p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def choose(x):return datetime.fromisoformat(x.replace('Z','+00:00'))
def main():
    c={x['file']:x for x in load(S/'checksums.json')['files']}
    games=[]
    for f in load(S/'register.json')['fixtures']:
        if f['competition_code'] not in ('eng.1','esp.1','ita.1','fra.1','ger.1'):continue
        i=f['espn_event_id']; fc=f['fotmob_match']; cohort=f['competition_code']
        match=load(S/'recent_league_form/normalized-form'/f'{i}.json')
        raw=f"raw/espn-{cohort}-20261123.json"
        source=c[raw]; assert sha(S/raw)==source['sha256']
        espn,=[r for r in load(S/raw)['events'] if r['id']==i]
        comp,=espn['competitions']
        assert espn['status']['type']['state']=='pre'
        assert choose(espn['date'])==choose(f['kickoff_utc'])==choose(fc['utc_match_time'])
        assert not fc['started'] and not fc['cancelled'] and not fc['finished'] and fc['gender']=='male'
        sdt={r['homeAway']:'espn:'+r['id'] for r in comp['competitors']}
        clean={'match_id':'espn:'+i,'cohort':cohort}
        for side in ('home','away'):
            team=match[side];assert team['team_id']==sdt[side] and len(team['matches'])==6
            hist=[]
            for row in team['matches']:
                p=S/'recent_league_form'/row['raw_file']
                assert sha(p)==row['source_sha256']
                obj=load(p)
                phot=team['fotmob_team_id'];i_side=['home','away'].index(row['team_side'])
                assert str(obj['header']['teams'][i_side]['id'])==phot and obj['header']['status']['finished']
                keys=('kickoff_at','observed_at','gf','ga','xgf','xga','score_basis','source_url','source_sha256')
                g={k:row[k] for k in keys}
                g.update(id='fotmob:'+str(row['fotmob_match_id']),cohort=cohort,
                         xg_observed_at=row['observed_at'],xg_source_url=row['source_url'],
                         xg_source_sha256=row['source_sha256'])
                hist.append(g)
            clean[side]={'team_id':sdt[side],'matches':hist}
        obs=[{'source_url':f['espn_url'],'query_time':source['observed_at_utc'],
              'response_sha256':source['sha256'],'file':raw,'purpose':'fixture_identity'}]
        games.append({'match_id':'espn:'+i,'cohort':cohort,'competition':cohort,'stage':'regular','age':'senior','gender':'men',
             'entity':'club','level':'tier1','identity_verified':True,'neutral':comp.get('neutralSite',False),
             'season':'2026/27','phase':'PreMatch','score_basis':'regulation_90','kickoff_at':f['kickoff_utc'],
             'home':sdt['home'],'away':sdt['away'],'home_name':f['home'],'away_name':f['away'],
             'venue':f['venue'],'sources':obs,'recent_league_form':clean,
             'market_availability':'NO_VERIFIABLE_SOURCE_QUOTE_TIME'})
    assert len(games)==3
    write(D/'fixtures.json',games)
if __name__=='__main__':main()
