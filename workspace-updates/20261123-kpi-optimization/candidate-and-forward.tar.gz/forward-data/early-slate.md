# Forward KPI slate — 2026-11-23 10:00 to 2026-11-24 12:00 BJT

Captured 2026-11-23T02:02:49.336424Z. Window is half-open: 2026-11-23 02:00Z through 2026-11-24 04:00Z. 15 events were scheduled and unstarted at capture: 3 Big Five, 12 other covered competitions.

## Big Five

- **Italian Serie A** — Nov 24 03:45 BJT, Monza vs Fiorentina (ESPN `401875009`, FotMob `5749756`), U-Power Stadium. Phase: 2026-27-italian-serie-a (round 12).
- **Spanish LALIGA** — Nov 24 04:00 BJT, Levante vs Elche (ESPN `401882802`, FotMob `5868135`), Estadi Ciutat de València. Phase: 2026-27-laliga (round 13).
- **English Premier League** — Nov 24 04:00 BJT, Brentford vs Everton (ESPN `401879237`, FotMob `5795517`), Gtech Community Stadium. Phase: 2026-27-english-premier-league (round 11).

## Other covered competitions

- Nov 23 21:45 BJT — AFC Champions League Elite: Neftchi Fergana vs Al Hilal (ESPN `401912612`, FotMob `not found`), Istiqlol Stadium. Phase: league-stage.
- Nov 24 00:00 BJT — AFC Champions League Elite: Al Ain vs Esteghlal FC (ESPN `401912602`, FotMob `not found`), Hazza Bin Zayed Stadium. Phase: league-stage.
- Nov 24 00:00 BJT — AFC Champions League Elite: Al-Shamal vs Al Ahli (ESPN `401912610`, FotMob `6050098`), Al Bayt Stadium. Phase: league-stage (round 5).
- Nov 24 00:00 BJT — AFC Champions League Elite: Tractor vs Al Wasl (ESPN `401912611`, FotMob `6050099`), Sultan Qaboos Sports Complex'. Phase: league-stage (round 5).
- Nov 24 02:00 BJT — Swedish Allsvenskan: Hammarby IF vs IFK Göteborg (ESPN `401842888`, FotMob `not found`), Tele2 Arena. Phase: 2026-allsvenskan.
- Nov 24 02:00 BJT — Swedish Allsvenskan: Örgryte IS vs Kalmar FF (ESPN `401842884`, FotMob `not found`), Gamla Ullevi. Phase: 2026-allsvenskan.
- Nov 24 02:15 BJT — AFC Champions League Elite: Al Ittihad vs Pakhtakor (ESPN `401912601`, FotMob `not found`), King Abdullah Sports City. Phase: league-stage.
- Nov 24 02:15 BJT — AFC Champions League Elite: Al-Quwa Al-Jawiya vs Al-Gharafa (ESPN `401912600`, FotMob `6050101`), Basra International Stadium. Phase: league-stage (round 5).
- Nov 24 06:30 BJT — Brazilian Serie A: Internacional vs Vitória (ESPN `401841323`, FotMob `5103720`), Estadio Beira-Rio. Phase: 2026-brasileiro-serie-a (round 36).
- Nov 24 07:00 BJT — Brazilian Serie A: Botafogo vs São Paulo (ESPN `401841326`, FotMob `5103715`), Joao Havelange Stadium. Phase: 2026-brasileiro-serie-a (round 36).
- Nov 24 08:00 BJT — Brazilian Serie A: Santos vs Grêmio (ESPN `401841320`, FotMob `5103716`), Estádio Cícero Pompeu de Toledo. Phase: 2026-brasileiro-serie-a (round 36).
- Nov 24 09:00 BJT — MLS: St. Louis CITY SC vs LAFC (ESPN `401933728`, FotMob `not found`), Energizer Park. Phase: western-conference-playoffs---round-one.

## Baseline and market capture

A prior market comparison is available at `../market-baseline-audit-20261123/market-comparison.json` (latest sample n=30; see source JSON for model/market breakdowns). This is historical diagnostic evidence, not an eligible baseline for prospective fixtures. ESPN scoreboard included DraftKings open/close values but no quote timestamps, so those were excluded. No genuinely timestamped market sides were captured for this forward slate. The Odds API credential was known exhausted (0 remaining/401); it was not queried again.

## Evidence

Machine-readable register: `register.json`; flat table: `register.csv`. ESPN scoreboards, FotMob daily schedules and successful FotMob match-detail responses are retained in `raw/`; hashes are in `checksums.json`. ESPN state and FotMob `started=false` were used to establish unstarted status. Round numbers come from FotMob match details when available; season slugs are retained from ESPN for all events. FotMob schedule did not return IDs for three AFC fixtures, two Swedish fixtures, and the MLS fixture; these remain in coverage and have null FotMob IDs.

Recent form for the three Big Five fixtures (six completed league matches per team, xG and scores) is in `recent_league_form/normalized-form/` with source evidence and actual observation times in `recent_league_form/recent_league_form.json` and hashes in `recent_league_form/checksums.json`.
