from pathlib import Path
from collections import defaultdict
from datetime import timedelta
from math import sqrt
import json
import sys

B=Path(__file__).resolve().parent
S=Path('/workspace/Football-Analysis-kpi-20261123')
sys.path[:0]=[str(S/'scripts'),str(S/'runtime'),str(S/'runtime/v5'),str(S)]
import numpy as np
from competition_scope import inventory, policy
from research.analysis_freeze import aware
from research_program.future_validation import sha
from research_program.kpi_score_candidate import quotes_matrix, recalibrate
from train_kpi_candidate import score_arrays, summary
from research_program.kpi_validation import review
from research.analysis_freeze import verify


def load(p):return json.loads(Path(p).read_bytes())
def save(p,d):Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def rows(path):return [json.loads(x) for x in path.open()]
def interval(k,n):
    z=1.959963984540054
    p=k/n
    center=(p+z*z/(2*n))/(1+z*z/n)
    half=z*sqrt((p*(1-p)+z*z/(4*n))/n)/(1+z*z/n)
    return [center-half,center+half]
def benchmark(records,beta,should_audit):
    assert records
    if should_audit:
        for r in records:
            cutoff,kickoff,actual=[aware(r[k]) for k in ('cutoff_at','kickoff_at','observed_at')]
            assert r['timestamp_certified'] is True and cutoff<kickoff and kickoff+timedelta(minutes=90)<=actual
            for k in ('h2h_quoted_at','total_quoted_at'):
                age=cutoff-aware(r['market'][k]); assert timedelta(0)<=age<=timedelta(hours=1)
    actual=np.array([[r['home_goals'],r['away_goals']] for r in records])
    lines=np.array([r['market']['total']['line'] for r in records])
    market=np.stack([quotes_matrix(r) for r in records])
    books={}
    for k,mat in [('market',market),('market_tilt',recalibrate(market,beta))]:
        x=score_arrays(mat,actual,lines);books[k]=summary(x)
    return books

def main():
    train=load(B/'training-xg/evaluation.json')
    beta=load(B/'training-xg/artifact.json')['tilt']
    data=rows(B/'data/timestamp-certified.jsonl')
    ext=rows(B/'data/extension-timestamp-certified.jsonl')
    assert len({x['match_id'] for x in data+ext})==len(data+ext)
    outside_proxy=[r for r in rows(B/'data/extension-closing-proxy.jsonl') if r['season']=='2627' and r['market']]
    signed={k:benchmark(r,beta,flag) for k,r,flag in [
        ('timestamp_certified',data,True),('earlier_extra_certified',ext,True),('other_european_2627_closing_proxy',outside_proxy,False)]}
    z=train['checks']['final']['selected']
    signed['selected_2627_nominal_95']={k:interval(z[k],z['n'] if k!='total_full_win' else z['total_non_push'])
                                          for k in ['primary','top3','wdl','total_full_win']}
    registry=load('/workspace/WCPP/runtime/active-model.json');scope=policy()
    reg=inventory(registry)
    def inspect(path,h):
        file=Path(path)
        return file.is_file() and sha(file)==h
    reg['routes_with_integrity']={}
    for cohort,r in registry['models'].items():
        reg['routes_with_integrity'][cohort]={k:inspect(r[k],r[k.replace('path','sha256')]) for k in ('artifact_path','test_artifact_path') if k in r}
    reg['configured_competitions']=[t['code'] for t in scope['competitions']]
    reg['registry_sha256']=sha('/workspace/WCPP/runtime/active-model.json')
    receipts=load(B/'forward/issued/receipts.json')
    first=verify(load(receipts['register']['path']))
    inputs=[verify(load(i['path'])) for i in receipts['matches'].values()]
    for x in inputs:
        mid=x['match_id'].replace(':','-')
        evidence=sha(B/'forward/issued'/f'{mid}-forecast.json')
        assert all(v['forecast_evidence_sha256']==evidence for k,v in x['payload'].items() if k in ('candidate','market_baseline'))
    future=review(first,inputs,[])
    save(B/'forward/gate-pending.json',future)
    signed['runtime_inventory']=reg
    signed['forward_frozen']={'population':future['population'],'pending':len(future['pending_matches']),'paired_eligible_total':0,
                               'targets_verified':future['targets_met_on_complete_population']}
    save(B/'robustness.json',signed)
    print(json.dumps({k:v for k,v in signed.items() if k!='runtime_inventory'},ensure_ascii=False))
if __name__=='__main__':main()
