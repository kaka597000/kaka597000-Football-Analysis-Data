from pathlib import Path
from collections import Counter, defaultdict
import json,sys
import numpy as np
ROOT=Path('/workspace/Football-Analysis-kpi-20261123')
D=Path('/workspace/WCPP/reports')
sys.path[:0]=[str(ROOT/'runtime'),str(ROOT/'runtime/v5'),str(ROOT)]
from research_program.market_baseline import quote_only_matrices, predict as market
from research_program.score_coverage_policy import select_scores
from research.analysis_freeze import verify
read=lambda p:json.loads(Path(p).read_bytes())
M=read(D/'market-baseline-audit-20261123/market-comparison.json')['fixtures']
q=defaultdict(Counter); diff=defaultdict(list)
def record(model_cls, buckets, a, b, v):
 for g in buckets:
  s=q[g,model_cls]; scores=lambda x: [x['primary'],*x['alternates']]
  a0=scores(a); b0=scores(b); x=v['actual']; s['n']+=1; s['first']+=a['primary']==x; s['three']+=x in a0;s['diverse']+=x in b0;s['change']+=a0!=b0
  s['add']+=x not in a0 and x in b0;s['lost']+=x in a0 and x not in b0
  s['base4']+=any(sum(map(int,z.split('-')))>=4 for z in a0)
  s['diverse4']+=any(sum(map(int,z.split('-')))>=4 for z in b0)
  if a0!=b0 and (x in a0 or x in b0):diff[g,model_cls].append((v['id'],a0,b0,x))
for folder,key in [('all-review-20261122-1255','first_comprehensive'),('review-20261123-nov22-nonmls','first')]:
 for i,s in read(D/folder/'population-lock.json')['population'].items():
  if i not in M:continue
  v=M[i]; pair=verify(read(s['first_pair']['path'])); comp=verify(read(s[key]['path']))
  fix=comp['fixture']; h,t=v['markets']['h2h'],v['markets']['total']
  _,m=quote_only_matrices(h['decimal_odds'],dict(t['decimal_odds'],line=t['line']))
  both=['combined78',v['batch']]
  record('market_exact',both,select_scores([m],fixture=fix),select_scores([m],fixture=fix,policy='diverse'),v)
  if s['cohort'] in ('jpn.1','kor.1','aus.1'):continue
  c=pair['payload']['current_model']['matrix']; t=pair['payload']['test_model']['matrix']
  for name,z,primary in [('ensemble', [m,c,t],None),('manual_first', [m,c,t],v['manual']['top3'][0])]:
   record(name,['main70',v['batch']],select_scores(z,primary=primary,fixture=fix),select_scores(z,primary=primary,fixture=fix,policy='diverse'),v)
for (g,k),s in sorted(q.items()):print(g,k,dict(s),diff[g,k])
