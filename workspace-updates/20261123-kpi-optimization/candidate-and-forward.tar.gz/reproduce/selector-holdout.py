from pathlib import Path
from collections import Counter
from datetime import date
import json,sys
import numpy as np

ROOT=Path('/workspace/Football-Analysis-kpi-20261123')
R=Path('/workspace/WCPP/reports/score-selection-optimization-20261122/training')
SOURCE=Path('/workspace/WCPP/data/staging/systematic-20261015/understat')
sys.path[:0]=[str(ROOT/'runtime'),str(ROOT/'scripts'),str(ROOT/'runtime/v5')]
from research_program.score_coverage_policy import select_scores
from research_program import score_form as sf
from train_score_form import load_seasons, examples, LEAGUES, SHAPE
from research.analysis_freeze import digest

publish=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/tmp/wcpp-score-coverage/holdout.json')
rows=[]
for cohort, league in LEAGUES.items():
    games,files=load_seasons(SOURCE,league)
    a=json.loads((R/f'{cohort}.json').read_bytes())
    assert a['source_files']==files[:5]
    assert a['artifact_sha256']==digest({k:v for k,v in a.items() if k!='artifact_sha256'})
    for game,features in examples(games):
        if game['season']!=2025:continue
        assert game['date']>a['selection_end']
        actual='-'.join(map(str,game['goals']))
        m=sf.calibrate(sf.poisson_matrix(sf.rates(a['xg'],features),SHAPE),a['cell_factors'],a['weight'])
        row={'date':game['date'],'id':game['id'],'cohort':cohort,'actual':actual}
        for i in ['probability','diverse']:
            s=select_scores([m],policy=i)
            row[i]=[s['primary'],*s['alternates']]
        rows.append(row)
assert len(rows)==1752 and len({(r['cohort'],r['id']) for r in rows})==len(rows)
# Preserve date-separated inputs and compare two preconfigured selectors.
def metrics(sample):
    output={}
    for m in ['probability','diverse']:
        path=[(r[m],r['actual']) for r in sample]
        high=lambda score:sum(map(int,score.split('-')))>=4
        output[m]=dict(first=sum(t==s[0] for s,t in path),top3=sum(t in s for s,t in path),
                       true_high_hits=sum(t in s and high(t) for s,t in path),
                       predicted_with_high=sum(any(high(k) for k in s) for s,t in path))
    output['changed_set']=sum(r['probability']!=r['diverse'] for r in sample)
    output['diverse_gain']=sum(r['actual'] in r['diverse'] and r['actual'] not in r['probability'] for r in sample)
    output['diverse_loss']=sum(r['actual'] not in r['diverse'] and r['actual'] in r['probability'] for r in sample)
    return output
r={'n':len(rows),'historical_availability':'match_date, no provider first-known timestamps','forecast_artifact_selection_end':'2025-05',
   'portfolio':metrics(rows),'by_league':{c:metrics([r for r in rows if r['cohort']==c]) for c in LEAGUES},'rows':rows}
print(json.dumps({k:v for k,v in r.items() if k!='rows'},ensure_ascii=False))
publish.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
