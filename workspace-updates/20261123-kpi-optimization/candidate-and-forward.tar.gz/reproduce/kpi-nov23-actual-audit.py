from pathlib import Path
from collections import Counter, defaultdict
from datetime import datetime
import json, sys
import numpy as np
ROOT=Path('/workspace/Football-Analysis-kpi-20261123/runtime')
sys.path[:0]=[str(ROOT),str(ROOT/'v5'),str(ROOT.parent)]
DIR=Path('/workspace/WCPP/reports')
from research.analysis_freeze import verify, aware, digest
from research_program.three_arm_model import apply, score_picks, top_three_scores
from weighted_model import legacy
from research_program.future_validation import quote_audit
sys.path.insert(0,str(DIR/'market-baseline-audit-20261123'))
import compare_market as MARKET
read=lambda path: json.loads(Path(path).read_bytes())
M=read(DIR/'market-baseline-audit-20261123/market-comparison.json')['fixtures']
A=read('/workspace/Football-Data-nov22-review-20261123/workspace-updates/20261118-three-arm/training/artifact.json')
R=read('/workspace/WCPP/runtime/active-model.json')['models']
acc=defaultdict(lambda:defaultdict(Counter))
arch=[]
training=Counter()
features=Counter()
for folder,ref in [('all-review-20261122-1255','first_comprehensive'),('review-20261123-nov22-nonmls','first')]:
  for i,s in read(DIR/folder/'population-lock.json')['population'].items():
    if i not in M:continue
    r=M[i]; pair=verify(read(s['first_pair']['path']))
    comp=verify(read(s[ref]['path']))
    assert pair['record_sha256']==s['first_pair']['sha256']
    assert pair['fixture']['match_id']==comp['fixture']['match_id']
    assert aware(pair['recorded_at'])<aware(comp['fixture']['kickoff_at'])
    f=comp['fixture']
    c=pair['payload']['current_model'];aut=pair['payload']['test_model']
    if not c.get('matrix') or not aut.get('matrix'): continue
    cm=np.array(c['matrix']); tm=np.array(aut['matrix'])
    assert digest(cm.tolist())==c['matrix_hash'] and digest(tm.tolist())==aut['matrix_hash']
    h,q=MARKET.get_quotes(comp)
    quote={'h2h':h['decimal_odds'],'h2h_quoted_at':h['quoted_at'],'total':dict(q['decimal_odds'],line=q['line']),'total_quoted_at':q['quoted_at']}
    line=q['line']
    try:
      pri,proj=MARKET.base_matrix(MARKET._quote_values(quote,aware(f['cutoff_at'])))
      assert all(x<=51 for x in (*cm.shape,*tm.shape))
      cm=np.pad(cm,((0,51-cm.shape[0]),(0,51-cm.shape[1])))
      tm=np.pad(tm,((0,51-tm.shape[0]),(0,51-tm.shape[1])))
      result=apply(A,cm,quote,cohort=s['cohort'],cutoff_at=f['cutoff_at'])
    except ValueError as e:
      print(i,s['cohort'],e)
      continue
    H,W=map(int,r['actual'].split('-')); ts=np.zeros_like(cm);ts[H,W]=1
    groups=['all78',r['batch']]
    if s['cohort'] not in ('jpn.1','kor.1','aus.1'): groups+=['main70','main70-'+r['batch']]
    else:groups+=['ood']
    models={'current':cm,'test':tm,'same-model-current-market':result['market'],'three-arm-cohort':result['market_cohort'],'market-only-prior':pri,'market-only-projected':proj,'fixed-50-50-current-market':(cm+proj)*.5, 'fixed-50-50-test-market':(tm+proj)*.5}
    for label,pmf in models.items():
      sc=score_picks(pmf,line=line)
      first=sc['primary']; top3=top_three_scores(pmf)
      wdl={'home':'主胜','away':'客胜','draw':'平局'}[sc['wdl']]
      strict=sc['total']['direction']
      ss=legacy.total_settlement(pmf,line,'over')
      balance='over' if (ss['win']+.5*ss['half_win']-.5*ss['half_loss']-ss['loss']) > 0 else 'under'
      for g in groups:
        v=acc[g][label]; v.update({'n':1,'first':first==r['actual'],'three':r['actual'] in top3,'wdl':wdl==r['actual_wdl']})
        for lab,side in [('strict',strict),('balance',balance)]:
          k=MARKET.settle(ts,line,side);v[lab+'-'+k]+=1
        v['ou-diff']+=strict!=balance
    if r['batch']=='latest':
      candidate=pair['payload'].get('score_form_candidate')
      if candidate and candidate.get('status')=='AVAILABLE':
        for label in ('refreshed_test','pooled','xg_expert'):
          sc=candidate[label]
          for g in groups:
            v=acc[g][label]
            v.update({'n':1,'first':sc['primary']==r['actual'],'three':r['actual'] in sc['top3'],'wdl':{'home':'主胜','away':'客胜','draw':'平局'}[sc['wdl']]==r['actual_wdl']})
            v['strict-'+MARKET.settle(ts,line,sc['total']['direction'])]+=1
      ml=aut['ml']
      for key in ('own_same_cohort_gap','opponent_same_cohort_gap','own_recent_xg','opponent_recent_xg'):
        path=R[s['cohort']]['test_artifact_path']
        artifact=read(path)
        pos=artifact['feature_names'].index(key)
        for row in ml['feature_values']:
          features[(key,str(row[pos]))]+=1
      lag=(datetime.fromisoformat(f['kickoff_at'][:10])-datetime.fromisoformat(artifact['train_end'])).days
      training[(lag,ml['selected_alpha'],ml['xg_training_match_count'],ml['process_training_match_count'])]+=1
for g,tracks in sorted(acc.items()):
 print(g)
 for name,x in tracks.items():
   n=x['n']
   print(name,n,*(x[k] for k in ('first','three','wdl')), 'ou strict',x['strict-win'],n-x['strict-push'], 'balance',x['balance-win'],n-x['balance-push'],'delta',x['ou-diff'])
print('training',training)
print('features',features)
