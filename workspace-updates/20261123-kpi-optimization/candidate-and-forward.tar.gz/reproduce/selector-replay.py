"""Descriptive replay of already seen WCPP 78 non-MLS first forecasts."""
from collections import Counter
from pathlib import Path
import json
import sys

import numpy as np

WORKSPACE = Path('/workspace')
REPORTS = WORKSPACE / 'WCPP/reports'
RUNTIME = WORKSPACE / 'Football-Analysis-kpi-20261123/runtime'
sys.path[:0] = [str(RUNTIME), str(RUNTIME / 'v5'), str(RUNTIME.parent)]
from research.analysis_freeze import aware, verify
from research_program.market_baseline import predict, quote_only_matrices
from research_program.score_coverage_policy import select_scores
from research_program.three_arm_model import top_three_scores

def read(path):
    return json.loads(Path(path).read_bytes())

def frozen(ref):
    record = verify(read(ref['path']))
    assert record['record_sha256'] == ref['sha256'] and record['freeze_id'] == ref['freeze_id']
    assert record['stage'] == 'prematch'
    assert aware(record['fixture']['cutoff_at']) <= aware(record['recorded_at']) < aware(record['fixture']['kickoff_at'])
    return record

def alignment(values):
    matrices=[np.asarray(matrix) for matrix in values if matrix is not None]
    assert matrices and all(m.ndim==2 for m in matrices)
    a,b=np.max([m.shape for m in matrices],axis=0)
    return [np.pad(m, [(0,a-m.shape[0]),(0,b-m.shape[1])]) for m in matrices]

def big(score):
    return sum(map(int,score.split('-'))) >= 4

def zero(score):
    return '0' in score.split('-')

def row(actual, conditions, outputs):
    return {'actual':actual, 'conditions': conditions, 'predictions':{
        name:{'scores':[r['primary'],*r['alternates']],
              **({'mass_lost':r['pooled_probability_loss']} if 'pooled_probability_loss' in r else {})}
        for name,r in outputs.items()
    }}

batches=[
    ('previous_48',REPORTS/'all-review-20261122-1255','first_comprehensive','first_referenced_pair'),
    ('latest_30',REPORTS/'review-20261123-nov22-nonmls','first','referenced_pair'),
]
def fixtures():
    fixtures={}
    independently_estimated={}
    verified_results={}
    for name,path,comp_key,pair_key in batches:
        for k,entry in read(path/'population-lock.json')['population'].items():
            if entry['cohort']=='usa.1':
                continue
            comp=frozen(entry[comp_key])
            pair=frozen(entry[pair_key])
            assert comp['evaluation_slot']=='FIRST_PREMATCH' and comp['match_id']==pair['match_id']
            f=comp['fixture']
            market=predict(f)
            score=comp['payload']['primary']
            assert market['status']=='AVAILABLE', (k,market)
            snap=market['quote_snapshot']
            _,projected=quote_only_matrices(snap['h2h']['prices'],dict(snap['total']['prices'],line=snap['total']['line']))
            matrices=[pair['payload'][n].get('matrix') for n in ('current_model','test_model')]
            native_count=sum(m is not None for m in matrices)
            if not native_count:
                matrices=[projected]
            outputs={'official': comp['payload'], 'market_only': {'primary':market['top3'][0], 'alternates':market['top3'][1:]}}
            for label,pool in [('current_test',alignment(matrices)),('market_current_test',alignment([projected,*matrices]))]:
                for policy in ('probability','diverse'):
                    outputs[label+'_'+policy]=select_scores(pool,primary=score,policy=policy,fixture=f)
                outputs[label+'_probability_free_first']=select_scores(pool,policy='probability',fixture=f)
                outputs[label+'_diverse_free_first']=select_scores(pool,policy='diverse',fixture=f)
            independently_estimated[k]=(outputs, f, name,native_count)
        verified_results.update(read(path/'verified-results.json'))
    for i,(outputs,f,name,native_count) in independently_estimated.items():
        result=verified_results[i]
        assert result['status'] in ('completed','FT') and result['score_basis']=='regulation_90'
        assert all(result[k]==f[k] for k in ('home','away','match_id','cohort'))
        actual=f"{result['home_goals']}-{result['away_goals']}"
        fixtures[i] = row(actual, {'batch':name,'line':f['total_quote']['line'],'native_model_count':native_count}, outputs)
    return fixtures

def scores(rows,name):
    sets=[(v['actual'],v['predictions'][name]['scores']) for v in rows]
    count=lambda test: sum(test(a,s) for a,s in sets)
    cases=[v for v in rows if v['predictions'][name].get('mass_lost',0)>0.]
    baseline=name.replace('diverse','probability')
    prior_slot=lambda v: v['actual'] in v['predictions'][baseline]['scores']
    new_slot=lambda v: v['actual'] in v['predictions'][name]['scores']
    return dict(
        first=count(lambda a,s:a==s[0]), top3=count(lambda a,s:a in s),
        top3_above=count(lambda a,s:big(a) and a in s), top3_zero=count(lambda a,s:zero(a) and a in s),
        top3_with_high=count(lambda a,s:any(big(q) for q in s)),
        top3_with_zero=count(lambda a,s:any(zero(q) for q in s)),
        edited=len(cases),
        alt_gains=sum(not prior_slot(v) and new_slot(v) for v in cases),
        alt_losses=sum(prior_slot(v) and not new_slot(v) for v in cases),
        pooled_probability_budget_loss=round(sum(v['predictions'][name]['mass_lost'] for v in cases),6),
    )

data=fixtures()
report={}
for name in ('previous_48','latest_30','combined'):
    rr=[x for x in data.values() if name in (x['conditions']['batch'],'combined')]
    group={n:scores(rr,n) for n in next(iter(rr))['predictions']}
    print(name,len(rr))
    for method,item in group.items():
        print(method,item)
    report[name]={'population':len(rr),'real_high_goals':sum(big(r['actual']) for r in rr),'real_one_side_zero':sum(zero(r['actual']) for r in rr),'groups':group}
assert len(data)==78
p=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/tmp/wcpp-score-coverage/coverage_replay.json')
p.write_text(json.dumps({'summary':report,'fixtures':data},ensure_ascii=False,indent=2)+'\n')
