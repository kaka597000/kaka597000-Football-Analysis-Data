"""Read-only WDL/O-U experiment. Fixed Nov23 protocol: fit <=2324, select 2425,
report 2526 and 2627 independently. No historical odds timestamps claimed."""
import json
import sys
from pathlib import Path
from collections import defaultdict, deque
from itertools import groupby
from datetime import date
import numpy as np
import lightgbm as lgb
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline

PATH=Path('/workspace/WCPP/reports/kpi-optimization-20261123/data/closing-proxy-with-xg.jsonl')
LEAGUES=('eng.1','esp.1','ger.1','ita.1','fra.1')
BOOKS=('Bet365','Pinnacle','Average','Max')
FIT={'1920','2021','2122','2223','2324'}
RECIPES=('market','logistic','lgb','logistic-25','lgb-25')
def norm(x):
 inv=1./np.array(x)
 return inv/sum(inv)
def marketvector(pack):
 return np.r_[norm([pack['h2h'][k] for k in ('home','draw','away')]),norm([pack['total'][k] for k in ('under','over')])]

def features(rows):
 hist=defaultdict(lambda:deque(maxlen=20))
 X,y,mkt,seasons=[],[],[],[]
 for day,iter_r in groupby(sorted(rows,key=lambda r:(r['game_date'],r['match_id'])),key=lambda r:r['game_date']):
  block=list(iter_r);d=date.fromisoformat(day)
  for r in block:
   if r['score_basis']!='regulation_90' or not r.get('market') or r['market']['total']['line']!=2.5:
    continue
   m=marketvector(r['market']); h=r['home_goals'];a=r['away_goals']
   hc=[float(r['cohort']==k) for k in LEAGUES]
   hc.extend(np.log(m));hc.extend([sum(1./prob for prob in r['market']['h2h'].values()),sum(1./prob for k,prob in r['market']['total'].items() if k!='line')])
   for bk in BOOKS:
    market=r.get('market_by_book',{}).get(bk)
    hc.extend(np.log(marketvector(market)) if market and market['total']['line']==2.5 else np.log(m))
   for side in ('home','away'):
    q=list(hist[r['cohort'],r[side]])
    for n in (6,18):
     pairs=q[-n:];hgr=sum(x[0] for x in pairs);agr=sum(x[1] for x in pairs)
     s=len(pairs); xp=[(x[2],x[3]) for x in pairs if x[2] is not None and x[3] is not None]
     ex,ey= ((sum(x[0] for x in xp)+4*1.35)/(len(xp)+4.),(sum(x[1] for x in xp)+4*1.35)/(len(xp)+4.))
     hc.extend([(hgr+4*1.35)/(s+4),(agr+4*1.35)/(s+4),ex,ey,s/n,len(xp)/n,
                 (sum(3*(x[0]>x[1])+(x[0]==x[1]) for x in pairs)+4.*1.35)/(s+4),
                 (sum(x[0]+x[1]>=3 for x in pairs)+2.)/(s+4)])
    hc.append(float(min(35,(d-q[-1][4]).days) if q else 35))
   X.append(hc);y.append([0 if h>a else 1 if h==a else 2,int(h+a>=3)]);mkt.append(m);seasons.append(r['season'])
  for r in block:
   h,a=r['home_goals'],r['away_goals']
   home,away=(r.get('xg_understat') or {}).get('home'),(r.get('xg_understat') or {}).get('away')
   hist[r['cohort'],r['home']].append((h,a,home,away,d))
   hist[r['cohort'],r['away']].append((a,h,away,home,d))
 return tuple(map(np.asarray,(X,y,mkt,seasons)))

def models(X,y,mkt,seasons):
 base= {'wdl':mkt[:,:3],'ou':mkt[:,3:]}
 train=np.isin(seasons,list(FIT))
 for j,k in enumerate(('wdl','ou')):
  p=base[k]
  model = make_pipeline(StandardScaler(), LogisticRegression(C=.08,max_iter=2000))
  model.fit(X[train],y[train,j])
  p1=model.predict_proba(X)
  model=lgb.LGBMClassifier(n_estimators=180,learning_rate=.025,max_depth=4,num_leaves=12,
      min_child_samples=80,reg_lambda=7,verbosity=-1,n_jobs=1,random_state=20261123)
  model.fit(X[train],y[train,j])
  p2=model.predict_proba(X)
  ye=y[:,j]; estimate={'market':p,'logistic':p1,'lgb':p2,'logistic-25':.75*p+.25*p1,'lgb-25':.75*p+.25*p2}
  def tally(label,season):
   m=seasons==season; z=estimate[label][m]; v=ye[m]; hits=int((z.argmax(axis=1)==v).sum())
   return hits,len(z),float(-np.log(z[np.arange(len(z)),v]).mean())
  chosen=max(RECIPES,key=lambda label:(tally(label,'2425')[0],-tally(label,'2425')[2]))
  print(k,chosen)
  for name in RECIPES:print(name,*(tally(name,s) for s in ('2425','2526','2627')))
  mask=seasons=='2627'; actual=ye[mask]; old=estimate['market'][mask].argmax(axis=1)==actual; new=estimate[chosen][mask].argmax(axis=1)==actual
  print('holdout paired gain/loss',sum(~old & new),sum(old & ~new))
if __name__=='__main__':
 rows=list(map(json.loads,PATH.open()))
 models(*features(rows))
