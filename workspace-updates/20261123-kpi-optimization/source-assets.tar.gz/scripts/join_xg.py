"""Join separately verified club identities to historical postmatch Understat data."""
from collections import Counter
from pathlib import Path
import json

from prepare import D, ROOT, save_lines, sha

SOURCE=ROOT/'data/staging/systematic-20261015/understat'
LEAGUES={'eng.1':'EPL','esp.1':'La_liga','fra.1':'Ligue_1','ita.1':'Serie_A','ger.1':'Bundesliga'}
ALIASES={
    'eng.1':{'Man City':'Manchester City','Man United':'Manchester United','Newcastle':'Newcastle United',
             "Nott'm Forest":'Nottingham Forest','West Brom':'West Bromwich Albion','Wolves':'Wolverhampton Wanderers'},
    'esp.1':{'Ath Bilbao':'Athletic Club','Ath Madrid':'Atletico Madrid','Betis':'Real Betis',
             'Celta':'Celta Vigo','Espanol':'Espanyol','Huesca':'SD Huesca','La Coruna':'Deportivo La Coruna',
             'Oviedo':'Real Oviedo','Santander':'Racing Santander','Sociedad':'Real Sociedad',
             'Valladolid':'Real Valladolid','Vallecano':'Rayo Vallecano'},
    'fra.1':{'Clermont':'Clermont Foot','Paris SG':'Paris Saint Germain','St Etienne':'Saint-Etienne'},
    'ita.1':{'Milan':'AC Milan','Parma':'Parma Calcio 1913'},
    'ger.1':{'Bielefeld':'Arminia Bielefeld','Dortmund':'Borussia Dortmund','Ein Frankfurt':'Eintracht Frankfurt',
             'FC Koln':'FC Cologne','Greuther Furth':'Greuther Fuerth','Hamburg':'Hamburger SV',
             'Heidenheim':'FC Heidenheim','Hertha':'Hertha Berlin','Leverkusen':'Bayer Leverkusen',
             "M'gladbach":'Borussia M.Gladbach','Mainz':'Mainz 05','RB Leipzig':'RasenBallsport Leipzig',
             'St Pauli':'St. Pauli','Stuttgart':'VfB Stuttgart'},
}

def load():
    paths=[];lookup={}
    for league,directory in LEAGUES.items():
        for path in sorted((SOURCE/directory).glob('*/rows.jsonl')):
            season=int(path.parent.name)
            season_name=f'{season%100:02d}{(season+1)%100:02d}'
            raw=path.read_bytes()
            paths.append({'cohort':league,'season':season_name,'path':str(path),'sha256':sha(raw)})
            for line in raw.splitlines():
                r=json.loads(line)
                if r['home_xg'] is None or r['away_xg'] is None or not r['date']:
                    continue
                key=(league,season_name,r['home_name'],r['away_name'])
                if key in lookup:
                    raise ValueError(f'Duplicate club match in one season {key}')
                lookup[key]=r
    return lookup,paths

def run():
    base=D/'closing-proxy.jsonl';out=D/'closing-proxy-with-xg.jsonl'
    understat,paths=load()
    stats=Counter(); unmatched=Counter(); rows=[]
    for line in base.read_text().splitlines():
        row=json.loads(line)
        aliases=ALIASES[row['cohort']]
        key=(row['cohort'],row['season'],*(aliases.get(row[t],row[t]) for t in ('home','away')))
        source=understat.get(key)
        row['xg_understat']=None
        if source:
            # Team pair + league/season identifies the match without looking at its label.
            certification='accepted' if row['game_date']==source['date'][:10] else 'date_disagreement'
            if certification=='accepted' and (source['home_goals'],source['away_goals'])!=(row['home_goals'],row['away_goals']):
                certification='final_score_disagreement'
            if certification=='accepted':
                row['xg_understat']={'provider':'Understat','provider_match_id':source['provider_match_id'],
                                    'home':source['home_xg'],'away':source['away_xg'],
                                    'source_fetched_at':source['source_fetched_at_beijing'],
                                    'source_payload_sha256':source['source_payload_sha256'],
                                    'available_as_of_target':False,
                                    'use_before_target_only':'Only use this historical postmatch label from earlier fixture dates'}
        else:
            certification='source_missing'
        if certification!='accepted':
            unmatched[(row['cohort'],row['season'],certification)]+=1
        stats[(row['season'],certification)]+=1
        if row['xg_understat'] is not None:
            stats[(row['season'],'has_any_xg')]+=1
        elif row['xg'] is not None:
            stats[(row['season'],'has_any_xg')]+=1
        rows.append(row)
    save_lines(out,rows)
    evidence={
        'source':str(base),'source_sha256':sha(base.read_bytes()),'output':str(out),'output_sha256':sha(out.read_bytes()),
        'reference':'Explicit provider display aliases; unique league/season/ordered clubs; exact published date and final result agreement.',
        'policy':'This join adds postmatch historical labels. No target xG may enter target features. Train features from strictly earlier fixture dates with a separate optional source mix. Understat first-known times were unavailable.',
        'coverage':{s:{key:value for (ss,key),value in stats.items() if s==ss} for s in sorted({ss for ss,_ in stats})},
        'unmatched':[dict(cohort=c,season=s,reason=r,count=v) for (c,s,r),v in sorted(unmatched.items())],
        'understat_sources':paths,
    }
    (D/'xg-source-manifest.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(evidence['coverage'],indent=2))
if __name__=='__main__':
    run()
