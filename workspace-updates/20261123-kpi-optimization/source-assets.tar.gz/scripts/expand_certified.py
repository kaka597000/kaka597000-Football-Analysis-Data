"""Search existing settled first freezes for additional verified real line evidence."""
from collections import Counter, defaultdict
from pathlib import Path
import json

from prepare import ROOT, REPORTS, D, utc, read, sha, digest, aligned_market, save_lines

def adapt_results():
    found=defaultdict(list)
    for folder in REPORTS.iterdir():
        if not folder.is_dir():continue
        for path in folder.glob('verified-results*.json'):
            payload=read(path)
            items=payload if isinstance(payload,list) else payload.values()
            for r in items:
                if (not isinstance(r,dict) or r.get('status') not in ('completed','FT')
                    or r.get('score_basis') != 'regulation_90'
                    or not all(k in r for k in ('match_id','observed_at','home','away','home_goals','away_goals','kickoff_at','cohort'))
                    or not r.get('source_url','').startswith('https://')):
                    continue
                if r['cohort']=='usa.1':continue
                found[r['match_id']].append((r,path))
    return found

def compile_additional():
    latest={json.loads(line)['match_id'] for line in (D/'timestamp-certified.jsonl').read_text().splitlines()}
    candidates=adapt_results()
    for mid in latest:candidates.pop(mid,None)
    out=[]; misses=Counter()
    for path in (ROOT/'forecasts/issued-analyses').glob('*/000001.json'):
        rec=read(path)
        if rec.get('track')!='comprehensive' or rec.get('evaluation_slot')!='FIRST_PREMATCH' or rec.get('stage')!='prematch':continue
        f=rec['fixture'];mid=f['match_id']
        if mid not in candidates:continue
        assert digest({k:v for k,v in rec.items() if k!='record_sha256'})==rec['record_sha256']
        if not all(k in f for k in ('home_name','away_name','score_basis','cutoff_at','market_snapshots','total_quote')) or f['score_basis']!='regulation_90':
            misses['no_frozen_quotes_contract']+=1
            continue
        try:
            prices=aligned_market(rec)
        except (KeyError,AssertionError,TypeError,ValueError):
            misses['no_complete_aligned_quotes']+=1
            continue
        p=rec['payload']
        if not all(k in p for k in ('primary','alternates','wdl','total_direction')):
            misses['no_complete_issued_forecast']+=1
            continue
        ok=[]
        for r,source in candidates[mid]:
            if any(r[k]!=f[k] for k in ('home','away','cohort')):continue
            if r.get('stage') and r['stage']!=f['stage']:continue
            if utc(r['kickoff_at'])!=utc(f['kickoff_at']):continue
            if not utc(f['cutoff_at'])<=utc(rec['recorded_at'])<utc(f['kickoff_at'])<utc(r['observed_at']):continue
            if any(type(r[k]) is not int or not 0<=r[k]<25 for k in ('home_goals','away_goals')):continue
            ok.append((r,source))
        if not ok:
            misses['result_identity_or_time_mismatch']+=1
            continue
        if len({(v['home_goals'],v['away_goals']) for v,_ in ok})!=1:
            misses['inconsistent_verified_results']+=1
            continue
        r,source=min(ok,key=lambda z:utc(z[0]['observed_at']))
        out.append({'match_id':mid,'cohort':f['cohort'],'stage':f['stage'],
                    'game_date':utc(f['kickoff_at']).date().isoformat(),
                    'home':f['home'],'away':f['away'],'home_name':f['home_name'],'away_name':f['away_name'],
                    'home_goals':r['home_goals'],'away_goals':r['away_goals'],'score_basis':'regulation_90',
                    'historical_proxy':False,'timestamp_certified':True,'partition':'additional_settled_frozen_first',
                    'kickoff_at':f['kickoff_at'],'cutoff_at':f['cutoff_at'],'observed_at':r['observed_at'],'market':prices,
                    'result_source_url':r['source_url'],'result_proof_file':str(source),'result_proof_sha256':sha(source.read_bytes()),
                    'freeze_reference':{'path':str(path),'freeze_id':rec['freeze_id'],'sha256':rec['record_sha256']},
                    'issued_primary':p['primary'],'issued_alternates':p['alternates'],'issued_wdl':p['wdl'],
                    'issued_total_direction':p['total_direction']})
    out.sort(key=lambda r:(utc(r['kickoff_at']),r['match_id']))
    assert len(out)==len({r['match_id'] for r in out})
    output=D/'extension-timestamp-certified.jsonl'
    save_lines(output,out)
    p={'output_sha256':sha(output.read_bytes()),'distinct_earlier_results_available':len(candidates),
       'total':len(out),'by_cohort':dict(Counter(r['cohort'] for r in out)),
       'miss_counts':dict(misses),
       'purpose':'Supplemental formerly settled first freezes, no duplicates with the 80 standard certified rows. Not a final or future holdout.'}
    (D/'extension-timestamp-certified-manifest.json').write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(p,indent=2))

if __name__=='__main__':
    compile_additional()
