"""Normalize retained Football-Data closing proxies and separate true pre-match quotes."""
from pathlib import Path
from collections import Counter
import csv
from datetime import date, datetime, timedelta, timezone
import gzip
import hashlib
import json
import math
import re
from zoneinfo import ZoneInfo

D = Path(__file__).parent
ROOT = Path('/workspace/WCPP')
REPORTS = ROOT/'reports'
OLD = ROOT/'research/remaining-nine-20261105'
ARCHIVE = Path('/workspace/Football-Data-nov22-review-20261123/workspace-updates/20261118-three-arm/training')
COHORTS = dict(E0='eng.1',D1='ger.1',F1='fra.1',I1='ita.1',SP1='esp.1',N1='ned.1',P1='por.1',E1='eng.2',
               AUS='aus.1',BRA='bra.1',JPN='jpn.1',NOR='nor.1',SWE='swe.1')
COUNTRIES = {'BRA':'Brazil','JPN':'Japan','NOR':'Norway','SWE':'Sweden','AUS':'Australia'}
WINDOW_START = date(2019,1,1)
WINDOW_END = datetime(2026,11,21,tzinfo=ZoneInfo('Asia/Shanghai'))
MARKETS = {
    'Bet365': (('B365CH','B365CD','B365CA'), ('B365C>2.5','B365C<2.5')),
    'Pinnacle': (('PSCH','PSCD','PSCA'), ('PC>2.5','PC<2.5')),
    'Betfair Exchange': (('BFECH','BFECD','BFECA'), ('BFEC>2.5','BFEC<2.5')),
}

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def read(path):
    return json.loads(path.read_bytes())

def encode(value):
    return json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()

def save_lines(path, rows):
    temp=path.with_suffix(path.suffix+'.tmp')
    temp.write_bytes(b''.join(encode(x)+b'\n' for x in rows))
    temp.replace(path)

def utc(value):
    when=datetime.fromisoformat(value)
    assert when.tzinfo is not None
    return when.astimezone(timezone.utc)

def valid_prices(row,columns):
    prices=[]
    for k in columns:
        try:
            p=float(row.get(k,''))
        except (ValueError,TypeError):
            return None
        if not math.isfinite(p) or p<=1:
            return None
        prices.append(p)
    return prices

def parse_xg(row):
    if not row.get('HxG') or not row.get('AxG'):
        return None
    h,a=float(row['HxG']),float(row['AxG'])
    if not all(0<=x<30 for x in (h,a)):
        return None
    return {'home':h,'away':a,'provider':'Football-Data source HxG/AxG',
            'availability':'postmatch fixture label only; strictly earlier date for lagged features'}

def season_label(season,league):
    # Country feeds lack round/phase evidence for historical USA and MEX fixtures;
    # they are purposely not part of any regular-season target.
    if league in COUNTRIES:
        year=int(season.split('/')[0])
        if year==2026:
            return 'holdout_2026_pre_nov21_country'
        if year==2025:
            return 'secondary_2025_country'
        if year==2024:
            return 'tune_2024_country'
        return 'train_2019_through_2023_country'
    if season=='2627':
        return 'holdout_2627_pre_nov21'
    if season=='2526':
        return 'secondary_2526_previously_examined'
    if season=='2425':
        return 'tune_2425'
    return 'train_1920_through_2324'

def archive_rows(source, limit_by_slot):
    source_path=Path(source['path'])
    raw=source_path.read_bytes()
    assert sha(raw)==source['sha256'], source_path
    base=source_path.stem.split('_')
    league=base[-1]
    if league not in COHORTS:
        return
    international=league in COUNTRIES
    parser=csv.DictReader(raw.decode('utf-8-sig',errors='strict').splitlines())
    for idx, row in enumerate(parser,2):
        if None in row and any(row[None]):
            raise ValueError(f'extra fields {source_path}:{idx}')
        if not row.get('Date') or international and row['Country']!=COUNTRIES[league]:
            continue
        game_date=datetime.strptime(row['Date'],'%d/%m/%Y').date()
        if game_date<WINDOW_START or game_date>WINDOW_END.date():
            continue
        source_time=row.get('Time','').strip()
        if game_date==WINDOW_END.date() and not source_time:
            continue
        if source_time:
            observed=datetime.strptime(f'{game_date.isoformat()} {source_time}','%Y-%m-%d %H:%M')
            if observed.replace(tzinfo=ZoneInfo('Europe/London'))>=WINDOW_END:
                continue
        home_col,away_col,hg_col,ag_col=('Home','Away','HG','AG') if international else ('HomeTeam','AwayTeam','FTHG','FTAG')
        if not row.get(hg_col) or not row.get(ag_col):
            continue
        home,away=row[home_col].strip(),row[away_col].strip()
        h,a=int(row[hg_col]),int(row[ag_col])
        assert home and away and home!=away and 0<=h<25 and 0<=a<25
        outcome='H' if h>a else 'A' if a>h else 'D'
        assert row['Res' if international else 'FTR']==outcome
        season=row['Season'] if international else base[0]
        quotes={}
        partial={}
        for book,(h2h_cols,total_cols) in MARKETS.items():
            h2h=valid_prices(row,h2h_cols)
            total=valid_prices(row,total_cols)
            if h2h is not None:
                z={'bookmaker':book,'h2h':dict(zip(['home','draw','away'],h2h))}
                partial[book]=z
                if total is not None:
                    quotes[book]=dict(z,total={'line':2.5,'over':total[0],'under':total[1]})
        main=next(iter(quotes.values()),None)
        one=next(iter(partial.values()),None)
        identity='|'.join((COHORTS[league],game_date.isoformat(),home,away))
        if identity in limit_by_slot:
            raise ValueError(f'duplicate record {identity}')
        limit_by_slot.add(identity)
        yield {'match_id':'football-data:'+sha(identity.encode())[:24],'cohort':COHORTS[league],
               'stage':'regular','game_date':game_date.isoformat(),'game_time_source':source_time or None,
               'season':season,'partition':season_label(season,league),'home':home,'away':away,
               'home_goals':h,'away_goals':a,'score_basis':'regulation_90','historical_proxy':True,
               'timestamp_certified':False,'source_file':source_path.name,'source_line':idx,
               'source_url':source['url'],'source_sha256':source['sha256'],
               'market':main,'wdl_market':one,'market_by_book':quotes,'wdl_by_book':partial,'xg':parse_xg(row)}

def sources():
    old=read(OLD/'market-ablation-input-manifest.json')['sources']
    for item in old:
        yield dict(item, path=str(OLD/'raw'/Path(item['path']).name))
    for item in read(D/'extra-raw/sources.json'):
        if 'error' not in item:
            yield item

def write_proxy():
    raw_sources=list(sources())
    seen=set()
    raw_rows=sorted((r for src in raw_sources for r in archive_rows(src,seen)),
                    key=lambda r:(r['game_date'],r['cohort'],r['home']))
    rows=[r for r in raw_rows if r['cohort'] in ('eng.1','esp.1','fra.1','ger.1','ita.1')]
    other=[r for r in raw_rows if r['cohort'] not in ('eng.1','esp.1','fra.1','ger.1','ita.1')]
    save_lines(D/'closing-proxy.jsonl',rows)
    save_lines(D/'extension-closing-proxy.jsonl',other)
    return raw_rows,raw_sources

def digest(obj):
    return sha(json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode())

def confirmed_fixture(ref):
    rec=read(Path(ref['path']))
    assert rec['record_sha256']==ref['sha256']
    assert digest({key:value for key,value in rec.items() if key!='record_sha256'})==ref['sha256']
    assert rec['evaluation_slot']=='FIRST_PREMATCH' and rec['stage']=='prematch'
    assert utc(rec['fixture']['cutoff_at'])<=utc(rec['recorded_at'])<utc(rec['fixture']['kickoff_at'])
    return rec

def actual(verified, i, stage):
    result=verified[i]
    assert result['score_basis']=='regulation_90', i
    assert result['status'] in ('completed','FT') or result['event_status']=='FT', i
    assert all(type(result[k]) is int and 0<=result[k]<25 for k in ('home_goals','away_goals')), i
    if 'stage' in result:
        assert result['stage']==stage, i
    return result

def aligned_market(rec):
    f=rec['fixture']
    q=f['total_quote']
    cutoff=utc(f['cutoff_at'])
    assert q['verified'] and q['match_id']==f['match_id'] and q['market']=='standard_total'
    assert utc(q['quoted_at'])<=utc(q['query_time'])<=cutoff
    assert cutoff-utc(q['quoted_at'])<=timedelta(hours=1)
    total=[p for p in f['market_snapshots'] if p['market']=='totals'
           and p['source_sha256']==q['source_sha256'] and p['quoted_at']==q['quoted_at']
           and p['query_time']==q['query_time'] and p['line']==q['line']
           and p['bookmaker'].casefold()==q['bookmaker'].casefold() and p['match_id']==f['match_id']
           and p['decimal_odds']=={'over':q['over_odds'],'under':q['under_odds']}]
    assert total and all(t['provider_match_id']==total[0]['provider_match_id'] for t in total)
    side=[p for p in f['market_snapshots'] if p['market']=='1x2'
           and p['source_sha256']==q['source_sha256'] and p['query_time']==q['query_time']
           and p['bookmaker'].casefold()==q['bookmaker'].casefold() and p['match_id']==f['match_id']
           and p['provider_match_id']==total[0]['provider_match_id'] and utc(p['quoted_at'])<=utc(p['query_time'])
           and cutoff-utc(p['quoted_at'])<=timedelta(hours=1)]
    assert side and len({digest(p['decimal_odds']) for p in side})==1
    h,t=side[0],total[0]
    assert set(h['decimal_odds'])=={'home','draw','away'}
    assert all(1<v and math.isfinite(v) for b in [h,t] for v in b['decimal_odds'].values())
    assert t['line']>=0 and (4*t['line']).is_integer() if isinstance(t['line'],float) else t['line']>=0
    assert all(p.get('period','regulation_90')=='regulation_90' for p in [h,t])
    return {'bookmaker':'Pinnacle','h2h':h['decimal_odds'],'total':dict(t['decimal_odds'],line=t['line']),
            'quoted_at':t['quoted_at'],'h2h_quoted_at':h['quoted_at'],'total_quoted_at':t['quoted_at'],
            'query_time':t['query_time'],'market_source_sha256':t['source_sha256'],'market_source_url':t['source_url'],
            'provider_match_id':t['provider_match_id']}

def recent_certified():
    batches=[(REPORTS/'all-review-20261122-1255','first_comprehensive','review_2026_11_22_prior'),
             (REPORTS/'review-20261123-nov22-nonmls','first','review_2026_11_23_latest')]
    for path,rkey,label in batches:
        results=read(path/'verified-results.json')
        for i,row in read(path/'population-lock.json')['population'].items():
            if row['cohort']=='usa.1':
                continue
            ref=row[rkey]
            c=confirmed_fixture(ref)
            f=c['fixture']
            y=actual(results,i,f['stage'])
            assert y['match_id']==f['match_id'] and y['home']==f['home'] and y['away']==f['away']
            current=y.get('observed_provider_kickoff_at',y['kickoff_at'])
            assert utc(f['cutoff_at'])<utc(current)<utc(y['observed_at'])
            p=c['payload']
            assert f['home_name']!=f['away_name']
            yield {'match_id':f['match_id'],'cohort':f['cohort'],'stage':f['stage'],'game_date':utc(f['kickoff_at']).date().isoformat(),
                   'home':f['home'],'away':f['away'],'home_name':f['home_name'],'away_name':f['away_name'],
                   'home_goals':y['home_goals'],'away_goals':y['away_goals'],'score_basis':'regulation_90',
                   'historical_proxy':False,'timestamp_certified':True,'partition':label,
                   'kickoff_at':f['kickoff_at'],'actual_kickoff_at':current,'cutoff_at':f['cutoff_at'],
                   'observed_at':y['observed_at'],'result_source_url':y['source_url'],'market':aligned_market(c),
                   'freeze_reference':ref,'result_sources':y.get('sources'),
                   'issued_primary':p['primary'],'issued_alternates':p['alternates'],
                   'issued_wdl':p['wdl'],'issued_total_direction':p['total_direction']}

def retained_certified():
    source=read(ARCHIVE/'actual_current_sources.json')
    refs={x['match_id']:x for x in source['rows']}
    with gzip.open(ARCHIVE/'actual_current.jsonl.gz','rt') as fh:
        for line in fh:
            v=json.loads(line)
            market=v.get('market')
            if not market:
                continue
            e=refs[v['match_id']]
            assert utc(market['h2h_quoted_at'])<=utc(v['cutoff_at'])<utc(v['kickoff_at'])
            assert utc(market['total_quoted_at'])<=utc(v['cutoff_at'])<utc(v['kickoff_at'])
            assert v['cutoff_at']==e['fixture_cutoff_at']
            yield {k:val for k,val in v.items() if k!='current_matrix'}|{
                'market':dict(market,bookmaker='Pinnacle'),'historical_proxy':False,'timestamp_certified':True,
                'partition':'retained_older_frozen_first','game_date':utc(v['kickoff_at']).date().isoformat(),
                'stage':e['stage'],'home':e['home'],'away':e['away'],'score_basis':'regulation_90',
                'freeze_id':e['freeze_id'],'freeze_record_sha256':e['freeze_record_sha256'],
                'result_source_url':e['result_url'],'result_source_sha256':e['raw_result_sha256']}

def combine_certified():
    sorted_rows=sorted([*recent_certified(),*retained_certified()],key=lambda r:(r['kickoff_at'],r['match_id']))
    assert len({r['match_id'] for r in sorted_rows})==len(sorted_rows)
    save_lines(D/'timestamp-certified.jsonl',sorted_rows)
    return sorted_rows

def count(groups):
    c=Counter()
    for r in groups:
        g=r['partition']
        c[g,'results']+=1
        c[g,'wdl_prices']+=r.get('wdl_market') is not None or r['market'] is not None
        c[g,'same_book_wdl_and_total_prices']+=r['market'] is not None
        c[g,'native_xg_as_postmatch_label']+=r.get('xg') is not None
    counts={}
    for (k,v),n in sorted(c.items()):
        counts.setdefault(k,{})[v]=n
    return counts

def main():
    proxy,raw_sources=write_proxy()
    certified=combine_certified()
    paths=[D/'closing-proxy.jsonl',D/'extension-closing-proxy.jsonl',D/'timestamp-certified.jsonl']
    result = {
        'schema':'WCPP-KPI-DATA-1','created_at':datetime.now(timezone.utc).isoformat(),
        'policy':{
            'closed_proxy':'Source closing prices have no quoted_at/first_known timestamps; use strictly earlier fixture dates for lagged features. Only five-league data in closing-proxy.jsonl.',
            'normalization':'Use only same-book Bet365, Pinnacle or Betfair Exchange full closing 1X2 plus same-book two-sided 2.5. Retain other book and 1X2-only quotes separately.',
            'xg':'Same-fixture xg is a postmatch outcome. It is never a pre-match covariate. Only strictly older match dates can supply lagged xg proxies.',
            'holdout':'Freeze recipe based on fits through 2023/24 and 2024/25 tune. 2025/26 and recent 2026 frozen batches were previously analyzed. 2026/27 through the cutoff is a newly assembled date-only independent holdout where the candidate fit excludes it.',
            'cutoff_2026':'2026-11-21 00:00 Asia/Shanghai exclusive; Football-Data Time is documented as UK time.',
            'certified':'Original frozen pre-match snapshots validate chronology and real line. Quote timestamps are never imputed. This is an archived evaluation set, not prospective performance.',
            'extensions':'Country archive series lack total odds. Missing total prices remain null, not substituted or imputed. USA and MEX are excluded due unavailable phase evidence.',
        },
        'counts_by_partition':count(proxy+certified),
        'counts_by_cohort':dict(Counter(x['cohort'] for x in proxy+certified)),
        'outputs':{p.name:{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in paths},
        'raw_proxy_sources':[src for src in raw_sources if Path(src['path']).stem.split('_')[-1] in COHORTS],
        'retained_certified_sources':str(ARCHIVE/'actual_current_sources.json'),
    }
    (D/'manifest.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result['counts_by_partition'],indent=2))

if __name__=='__main__':
    main()
