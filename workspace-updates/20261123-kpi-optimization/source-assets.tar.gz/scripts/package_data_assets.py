"""Package deduplicated, content-hashed match and odds data for offline research."""
import gzip
from pathlib import Path
import io
import json
import tarfile
from collections import Counter

from prepare import ROOT, D, OLD, ARCHIVE, REPORTS, sha, read, utc

BASES = (REPORTS/'scope-evening-20261121-1932/market',
         REPORTS/'asia-prematch-20261121-1325/market',
         REPORTS/'scope-prematch-20261122-1713/market',
         REPORTS/'scope-prematch-20261120-1538/market/refresh',
         REPORTS/'scope-remaining-20261120-2104/market')
CERTIFIED = ('timestamp-certified.jsonl','extension-timestamp-certified.jsonl')
FORM = ('closing-proxy.jsonl','closing-proxy-with-xg.jsonl','extension-closing-proxy.jsonl')

def rows(path):
    return map(json.loads,path.read_text().splitlines())

def generate():
    original=read(D/'manifest.json')
    xg=read(D/'xg-source-manifest.json')
    payload={}
    normalized={}
    book_refs={}
    matched_market={}
    related_results={}
    freezes={}
    excluded=[]

    for name in ('prepare.py','join_xg.py','expand_certified.py','confidence-sensitivity-protocol.json',
                 'confidence-sensitivity-results.json','package_data_assets.py'):
        p=D/name
        if p.is_file():payload['scripts/'+name]=p.read_bytes()

    for name in (*CERTIFIED,*FORM):
        p=D/name
        raw=p.read_bytes()
        gz=gzip.compress(raw,compresslevel=6,mtime=0)
        payload['normalized/'+name+'.gz']=gz
        normalized[name]={'gzip_sha256':sha(gz),'sha256':sha(raw),'line_count':raw.count(b'\n')}

    for r in original['raw_proxy_sources']:
        path=Path(r['path'])
        raw=path.read_bytes()
        assert sha(raw)==r['sha256']
        alias='raw/close/'+path.name
        payload[alias]=raw
        book_refs[path.name]=dict(r,path=alias)

    for r in xg['understat_sources']:
        p=Path(r['path'])
        alias='raw/understat/'+p.parent.parent.name+'/'+p.parent.name+'/'
        raw=p.read_bytes()
        raw_body=p.with_name('league-data.json').read_bytes()
        assert sha(raw)==r['sha256']
        underlying_hashes={v['source_payload_sha256'] for v in map(json.loads,raw.splitlines())}
        assert underlying_hashes=={sha(raw_body)}
        payload[alias+'rows.jsonl']=raw
        payload[alias+'league-data.json']=raw_body

    # The oldest two November captures and their existing explicit proof retain a
    # validated archive generated before this study.
    for fname in ('actual_current_sources.json','actual_current.jsonl.gz','brazil_retained_inputs.tar.gz'):
        payload['retained/'+fname]=(ARCHIVE/fname).read_bytes()
    for name in ('all-review-20261122-1255','review-20261123-nov22-nonmls'):
        path=REPORTS/name
        for kind in ('verified-results.json','population-lock.json'):
            p=path/kind
            payload['review/'+path.name+'/'+kind]=p.read_bytes()

    wanted={}
    for name in CERTIFIED:
        for r in rows(D/name):
            if 'freeze_reference' in r:
                path=Path(r['freeze_reference']['path'])
                raw=path.read_bytes()
                alias='issued/'+r['freeze_reference']['freeze_id']+'.json'
                assert json.loads(raw)['record_sha256']==r['freeze_reference']['sha256']
                payload[alias]=raw
                freezes[r['match_id']]=alias
            if 'market_source_sha256' in r['market']:
                wanted[r['market']['market_source_sha256']]=r['market']['market_source_url']
            proof=[]
            if r.get('result_proof_file'):
                p=Path(r['result_proof_file']); raw=p.read_bytes()
                assert sha(raw)==r['result_proof_sha256']
                alias='review/extra/'+p.parent.name+'/'+p.name
                payload[alias]=raw
                proof.append(alias)
            if r.get('result_sources'):
                refs=r['result_sources']
                result_base=REPORTS/'review-20261123-nov22-nonmls'
                for ref in (refs.values() if isinstance(refs,dict) else refs):
                    path=Path(ref.get('path') or result_base/ref['file'])
                    expected=ref.get('sha256')
                    if not path.is_file() or not expected:
                        excluded.append({'match_id':r['match_id'],'stage':'raw_result_file_missing','source':str(path)})
                        continue
                    raw=path.read_bytes()
                    assert sha(raw)==expected
                    alias='raw/result/'+expected+'.json'
                    payload[alias]=raw
                    proof.append(alias)
            related_results[r['match_id']]=proof

    visited=set()
    market_roots=(*BASES,REPORTS/'scope-remaining-20261122-2328/market',
                  *(p/'market' for p in REPORTS.iterdir() if p.is_dir()))
    for base in market_roots:
        if not (base/'raw').is_dir() or base.resolve() in visited:continue
        visited.add(base.resolve())
        for p in (base/'raw').iterdir():
            if not p.is_file():continue
            raw=p.read_bytes()
            h=sha(raw)
            if h not in wanted:continue
            alias='raw/open-pregame/'+h+'.json'
            payload[alias]=raw
            matched_market[h]={'archive_path':alias,'source_url':wanted[h]}
    for h in sorted(wanted.keys()-matched_market.keys()):
        excluded.append({'market_source_sha256':h,'stage':'matching_raw_market_body_absent_from_retained_folders','source_url':wanted[h]})

    idx={'schema':'WCPP-KPI-PORTABLE-1','files':{name:sha(b) for name,b in payload.items()},
         'normalized':normalized,'closing_book_raw_csv':book_refs,'wcpp_pregame_proofs':matched_market,
         'wcpp_result_proofs':related_results,'wcpp_frozen_records':freezes,
         'external_source_records_missing_from_bundle':excluded,
         'provenance':{'proxy_base_manifest_sha256':sha((D/'manifest.json').read_bytes()),
                       'xg_source_manifest_sha256':sha((D/'xg-source-manifest.json').read_bytes()),
                       'old_retained_actual_evidence':'Retained historic verified Brazil bundle, separate from later raw odds evidence',
                       'cohorts':'Normalised inputs publish distinct resolved certified and date-only proxy channels.'}}
    payload['ASSET-MANIFEST.json']=(json.dumps(idx,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()

    out=D/'source-assets.tar.gz'
    tmp=out.with_suffix('.tmp')
    with tmp.open('wb') as sink, gzip.GzipFile(filename='',mode='wb',fileobj=sink,mtime=0,compresslevel=6) as compressed:
        with tarfile.open(fileobj=compressed,mode='w|',format=tarfile.PAX_FORMAT) as bundle:
            for name,raw in sorted(payload.items()):
                info=tarfile.TarInfo(name)
                info.size=len(raw)
                bundle.addfile(info,io.BytesIO(raw))
    names=set()
    with tarfile.open(tmp,'r|gz') as bundle:
        for info in bundle:
            name=info.name
            assert name not in names and name in payload
            names.add(name)
            assert sha(bundle.extractfile(info).read())==sha(payload[name]),name
    assert names==set(payload)
    tmp.replace(out)

    proof={'archive_path':str(out),'archive_sha256':sha(out.read_bytes()),'bytes':out.stat().st_size,
           'member_count':len(payload),'close_csv_sources':len(book_refs),'normalized_sha256':normalized,
           'real_raw_market_matched':len(matched_market),'real_raw_market_required':len(wanted),
           'complete_first_freezes':len(freezes),'certified_results_by_raw':sum(bool(v) for v in related_results.values()),
           'notes':excluded}
    (D/'source-assets-readback.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(proof,ensure_ascii=False,indent=2))

if __name__=='__main__':
    generate()
