# 欧国联盘口采集摘要（2026-11-13 北京时间）

- The Odds API：请求 `2026-11-13T13:20:59.638650+00:00`，响应捕获 `2026-11-13T13:21:01.265301+00:00`；批次返回27项未来赛事，按本日赛程身份匹配10场。
- 本次market snapshot cutoff `2026-11-13T13:27:19.314108+00:00`；source quote age上限3600秒；实际本日合格报价的年龄范围382.314–984.314秒。Pinnacle报价last_update为13:20:52Z，在cutoff时年龄387.314秒。机构报价时间单独保留。全批last_update范围 `2026-11-13T13:10:55Z`–`2026-11-13T13:20:57Z` UTC。
- ESPN exact board：请求 `2026-11-13T13:23:17.705875+00:00`，捕获 `2026-11-13T13:23:18.746329+00:00`，SHA `84c8996bd3921162c689dd99b40ad06014ed69145e2b9098d4536988ba56954b`。
- Snapshot：10场身份合格，10场有盘口，共272条；未请求spreads。本次API额外返回的 `h2h_lay` 未并入h2h（12条）。
- 旧本地同场报价：比较出257条同source ID/双方/开球/机构/市场/盘线且报价时距各自capture≤1小时的可比项；旧batch捕获 `2026-11-12T16:22:21.630468+00:00`，没有跨赛事/跨盘线套用。

## 本批全部未来事件

各27场source ID、主客队、UTC开球、机构、完整h2h/OU盘口线/价格/报价时点列于 `batch-quote-catalog.json`；完整原文见 `odds.json`。

## 本日10场（Pinnacle优先）

| ESPN ID | source ID | 主队–客队 | 开球 UTC | Pinnacle 1X2赔率；去水概率 | Pinnacle OU线/Over/Under | 已接纳机构市场条数 |
|---|---|---|---|---|---|---:|
| espn:401861162 | cc1ca0aea8a9aa6ad2e1537834fe0d04 | Moldova–Kazakhstan | 2026-11-13T17:00:00+00:00 | home 2.6 / draw 3.02 / away 3.12; 37.1%/32.0%/30.9% | 2: O 1.86/U 2.01 | 26 |
| espn:401861155 | 6eecb0b534f8cda6254b8a0884289e16 | Andorra–Gibraltar | 2026-11-13T19:45:00+00:00 | home 1.67 / draw 3.26 / away 6.89; 57.0%/29.2%/13.8% | 1.75: O 1.98/U 1.85 | 27 |
| espn:401861157 | b53069411f63a0d3aed21fa84d225faf | Bulgaria–Iceland | 2026-11-13T19:45:00+00:00 | home 5.17 / draw 3.78 / away 1.72; 18.6%/25.5%/55.9% | 2.5: O 2.07/U 1.81 | 27 |
| espn:401861153 | 9529ee7ca79126460eb063f53187f321 | Liechtenstein–Azerbaijan | 2026-11-13T19:45:00+00:00 | home 18.99 / draw 6.14 / away 1.19; 5.0%/15.4%/79.6% | 2.25: O 1.89/U 1.93 | 27 |
| espn:401861154 | eef1c96c424e42b66f49b7ec3bef1a5c | Luxembourg–Estonia | 2026-11-13T19:45:00+00:00 | home 2.66 / draw 3.06 / away 3.01; 36.3%/31.6%/32.1% | 2: O 1.95/U 1.92 | 22 |
| espn:401861159 | 0010d3b2b15a2b8cb04053b0b1407cc5 | Netherlands–Greece | 2026-11-13T19:45:00+00:00 | home 1.6 / draw 4.62 / away 5.2; 60.5%/20.9%/18.6% | 3: O 1.88/U 2 | 31 |
| espn:401861161 | 199940cd0d3a9c7ad93be4063cb2df93 | Scotland–North Macedonia | 2026-11-13T19:45:00+00:00 | home 1.18 / draw 7.92 / away 17.13; 82.1%/12.2%/5.7% | 3: O 1.93/U 1.96 | 27 |
| espn:401861158 | d0ee3d2f44cf592797f6ecae8de62edd | Serbia–Germany | 2026-11-13T19:45:00+00:00 | home 10.32 / draw 6.8 / away 1.26; 9.3%/14.2%/76.5% | 3.25: O 1.89/U 1.98 | 31 |
| espn:401861160 | a2b1b42a452df659cc5d0d242d8f98be | Slovakia–Faroe Islands | 2026-11-13T19:45:00+00:00 | home 1.37 / draw 4.9 / away 9.42; 70.2%/19.6%/10.2% | 2.5: O 1.93/U 1.94 | 27 |
| espn:401861156 | af4d45ae5e37dc2a0e146d2a9e9a926d | Slovenia–Switzerland | 2026-11-13T19:45:00+00:00 | home 6.41 / draw 3.44 / away 1.7; 15.1%/28.1%/56.8% | 2: O 2/U 1.89 | 27 |

## 本日全部已接纳报价（逐机构/市场/线/时间）

### Moldova–Kazakhstan（espn:401861162; source cc1ca0aea8a9aa6ad2e1537834fe0d04; 2026-11-13T17:00:00+00:00 UTC）

- winamax_fr h2h [2026-11-13T13:20:53Z]: away 2.8/draw 2.9/home 2.35
- betfair_ex_eu h2h [2026-11-13T13:20:52Z]: away 3.25/draw 3.15/home 2.64
- onexbet h2h [2026-11-13T13:20:52Z]: away 3.07/draw 3.05/home 2.65
- onexbet totals 2.5 [2026-11-13T13:20:52Z]: over 2.55/under 1.56
- betsson h2h [2026-11-13T13:20:54Z]: away 2.95/draw 2.92/home 2.52
- betsson totals 2.5 [2026-11-13T13:20:54Z]: over 2.38/under 1.52
- nordicbet h2h [2026-11-13T13:20:52Z]: away 2.95/draw 2.92/home 2.52
- nordicbet totals 2.5 [2026-11-13T13:20:52Z]: over 2.38/under 1.52
- unibet_se h2h [2026-11-13T13:20:29Z]: away 2.88/draw 2.9/home 2.7
- unibet_se totals 1.5 [2026-11-13T13:20:29Z]: over 1.5/under 2.5
- leovegas_se h2h [2026-11-13T13:20:29Z]: away 2.88/draw 2.9/home 2.7
- leovegas_se totals 1.5 [2026-11-13T13:20:29Z]: over 1.5/under 2.5
- pmu_fr h2h [2026-11-13T13:20:51Z]: away 2.65/draw 2.7/home 2.55
- pmu_fr totals 1.5 [2026-11-13T13:20:51Z]: over 1.4/under 2.38
- betclic_fr h2h [2026-11-13T13:18:51Z]: away 2.95/draw 2.93/home 2.38
- sport888 h2h [2026-11-13T13:10:55Z]: away 2.9/draw 2.9/home 2.5
- williamhill h2h [2026-11-13T13:20:30Z]: away 2.9/draw 2.8/home 2.45
- williamhill totals 2.5 [2026-11-13T13:20:30Z]: over 2.38/under 1.55
- mybookieag h2h [2026-11-13T13:19:14Z]: away 2.97/draw 2.95/home 2.48
- mybookieag totals 2.5 [2026-11-13T13:19:14Z]: over 2.35/under 1.53
- marathonbet h2h [2026-11-13T13:20:57Z]: away 3.04/draw 3.02/home 2.62
- marathonbet totals 2.5 [2026-11-13T13:20:57Z]: over 2.51/under 1.54
- betanysports h2h [2026-11-13T13:20:51Z]: away 3.03/draw 2.93/home 2.44
- betanysports totals 2 [2026-11-13T13:20:51Z]: over 1.77/under 2.1
- pinnacle h2h [2026-11-13T13:20:52Z]: away 3.12/draw 3.02/home 2.6
- pinnacle totals 2 [2026-11-13T13:20:52Z]: over 1.86/under 2.01

### Andorra–Gibraltar（espn:401861155; source 6eecb0b534f8cda6254b8a0884289e16; 2026-11-13T19:45:00+00:00 UTC）

- onexbet h2h [2026-11-13T13:20:53Z]: away 6.82/draw 3.38/home 1.7
- onexbet totals 1.5 [2026-11-13T13:20:53Z]: over 1.75/under 2.17
- leovegas_se h2h [2026-11-13T13:20:29Z]: away 6.0/draw 3.1/home 1.72
- leovegas_se totals 1.5 [2026-11-13T13:20:29Z]: over 1.7/under 2.08
- pmu_fr h2h [2026-11-13T13:20:51Z]: away 5.5/draw 2.9/home 1.63
- pmu_fr totals 1.5 [2026-11-13T13:20:51Z]: over 1.6/under 1.95
- unibet_se h2h [2026-11-13T13:20:29Z]: away 6.0/draw 3.1/home 1.72
- unibet_se totals 1.5 [2026-11-13T13:20:29Z]: over 1.7/under 2.08
- betclic_fr h2h [2026-11-13T13:18:51Z]: away 5.9/draw 3.2/home 1.62
- betfair_ex_eu h2h [2026-11-13T13:20:52Z]: away 8.0/draw 3.4/home 1.71
- betsson h2h [2026-11-13T13:20:54Z]: away 6.3/draw 3.2/home 1.6
- betsson totals 2.5 [2026-11-13T13:20:54Z]: over 3.15/under 1.32
- nordicbet h2h [2026-11-13T13:20:52Z]: away 6.3/draw 3.2/home 1.6
- nordicbet totals 2.5 [2026-11-13T13:20:52Z]: over 3.15/under 1.32
- marathonbet h2h [2026-11-13T13:20:57Z]: away 6.75/draw 3.34/home 1.68
- marathonbet totals 1.5 [2026-11-13T13:20:57Z]: over 1.73/under 2.14
- mybookieag h2h [2026-11-13T13:19:14Z]: away 6.1/draw 3.16/home 1.67
- mybookieag totals 1.5 [2026-11-13T13:19:14Z]: over 1.71/under 2.02
- sport888 h2h [2026-11-13T13:10:55Z]: away 6.0/draw 3.1/home 1.67
- williamhill h2h [2026-11-13T13:20:30Z]: away 6.0/draw 3.0/home 1.62
- williamhill totals 2.5 [2026-11-13T13:20:30Z]: over 3.0/under 1.35
- winamax_de h2h [2026-11-13T13:20:55Z]: away 6.0/draw 3.35/home 1.62
- winamax_fr h2h [2026-11-13T13:20:53Z]: away 5.8/draw 3.2/home 1.58
- betanysports h2h [2026-11-13T13:20:52Z]: away 6.1/draw 3.27/home 1.64
- betanysports totals 1.75 [2026-11-13T13:20:52Z]: over 2.05/under 1.8
- pinnacle h2h [2026-11-13T13:20:52Z]: away 6.89/draw 3.26/home 1.67
- pinnacle totals 1.75 [2026-11-13T13:20:52Z]: over 1.98/under 1.85

### Bulgaria–Iceland（espn:401861157; source b53069411f63a0d3aed21fa84d225faf; 2026-11-13T19:45:00+00:00 UTC）

- winamax_fr h2h [2026-11-13T13:20:53Z]: away 1.64/draw 3.55/home 4.2
- betfair_ex_eu h2h [2026-11-13T13:20:52Z]: away 1.77/draw 3.85/home 5.5
- onexbet h2h [2026-11-13T13:20:53Z]: away 1.78/draw 3.74/home 4.96
- onexbet totals 2.5 [2026-11-13T13:20:53Z]: over 2.08/under 1.82
- betsson h2h [2026-11-13T13:20:54Z]: away 1.68/draw 3.6/home 4.9
- betsson totals 2.5 [2026-11-13T13:20:54Z]: over 1.98/under 1.75
- winamax_de h2h [2026-11-13T13:20:55Z]: away 1.7/draw 3.75/home 4.5
- nordicbet h2h [2026-11-13T13:20:52Z]: away 1.68/draw 3.6/home 4.9
- nordicbet totals 2.5 [2026-11-13T13:20:52Z]: over 1.98/under 1.75
- unibet_se h2h [2026-11-13T13:20:29Z]: away 1.78/draw 3.55/home 4.7
- unibet_se totals 2.5 [2026-11-13T13:20:29Z]: over 2.08/under 1.7
- leovegas_se h2h [2026-11-13T13:20:29Z]: away 1.78/draw 3.55/home 4.7
- leovegas_se totals 2.5 [2026-11-13T13:20:29Z]: over 2.08/under 1.7
- pmu_fr h2h [2026-11-13T13:20:51Z]: away 1.66/draw 3.25/home 4.3
- pmu_fr totals 2.5 [2026-11-13T13:20:51Z]: over 1.95/under 1.6
- betclic_fr h2h [2026-11-13T13:18:51Z]: away 1.69/draw 3.5/home 4.5
- marathonbet h2h [2026-11-13T13:20:57Z]: away 1.76/draw 3.7/home 4.9
- marathonbet totals 2.5 [2026-11-13T13:20:57Z]: over 2.05/under 1.79
- sport888 h2h [2026-11-13T13:10:55Z]: away 1.73/draw 3.5/home 4.6
- williamhill h2h [2026-11-13T13:20:30Z]: away 1.7/draw 3.4/home 4.5
- williamhill totals 2.5 [2026-11-13T13:20:30Z]: over 2.0/under 1.75
- mybookieag h2h [2026-11-13T13:19:14Z]: away 1.71/draw 3.55/home 4.6
- mybookieag totals 2.5 [2026-11-13T13:19:14Z]: over 1.98/under 1.74
- betanysports h2h [2026-11-13T13:20:52Z]: away 1.69/draw 3.58/home 4.79
- betanysports totals 2.25 [2026-11-13T13:20:52Z]: over 1.76/under 2.11
- pinnacle h2h [2026-11-13T13:20:52Z]: away 1.72/draw 3.78/home 5.17
- pinnacle totals 2.5 [2026-11-13T13:20:52Z]: over 2.07/under 1.81

### Liechtenstein–Azerbaijan（espn:401861153; source 9529ee7ca79126460eb063f53187f321; 2026-11-13T19:45:00+00:00 UTC）

- unibet_se h2h [2026-11-13T13:20:29Z]: away 1.23/draw 5.3/home 15.0
- unibet_se totals 2.5 [2026-11-13T13:20:29Z]: over 2.02/under 1.75
- onexbet h2h [2026-11-13T13:20:53Z]: away 1.23/draw 6.12/home 19.0
- onexbet totals 2.5 [2026-11-13T13:20:53Z]: over 2.15/under 1.77
- leovegas_se h2h [2026-11-13T13:20:29Z]: away 1.23/draw 5.3/home 15.0
- leovegas_se totals 2.5 [2026-11-13T13:20:29Z]: over 2.02/under 1.75
- pmu_fr h2h [2026-11-13T13:20:51Z]: away 1.17/draw 4.9/home 14.0
- pmu_fr totals 2.5 [2026-11-13T13:20:51Z]: over 1.89/under 1.64
- betclic_fr h2h [2026-11-13T13:18:51Z]: away 1.16/draw 5.4/home 18.0
- winamax_fr h2h [2026-11-13T13:20:53Z]: away 1.14/draw 5.6/home 15.0
- winamax_de h2h [2026-11-13T13:20:55Z]: away 1.16/draw 6.25/home 16.0
- betsson h2h [2026-11-13T13:20:54Z]: away 1.15/draw 5.7/home 22.0
- betsson totals 2.5 [2026-11-13T13:20:54Z]: over 2.18/under 1.62
- nordicbet h2h [2026-11-13T13:20:52Z]: away 1.15/draw 5.7/home 22.0
- nordicbet totals 2.5 [2026-11-13T13:20:52Z]: over 2.18/under 1.62
- betfair_ex_eu h2h [2026-11-13T13:20:52Z]: away 1.22/draw 6.4/home 29.0
- marathonbet h2h [2026-11-13T13:20:57Z]: away 1.21/draw 6.05/home 19.25
- marathonbet totals 2.5 [2026-11-13T13:20:57Z]: over 2.12/under 1.74
- mybookieag h2h [2026-11-13T13:19:14Z]: away 1.17/draw 5.6/home 20.25
- mybookieag totals 2.5 [2026-11-13T13:19:14Z]: over 2.14/under 1.63
- sport888 h2h [2026-11-13T13:10:55Z]: away 1.2/draw 5.75/home 17.0
- williamhill h2h [2026-11-13T13:20:30Z]: away 1.18/draw 5.5/home 17.0
- williamhill totals 2.5 [2026-11-13T13:20:30Z]: over 2.1/under 1.67
- betanysports h2h [2026-11-13T13:20:51Z]: away 1.19/draw 5.85/home 17.8
- betanysports totals 2.25 [2026-11-13T13:20:51Z]: over 1.84/under 1.99
- pinnacle h2h [2026-11-13T13:20:52Z]: away 1.19/draw 6.14/home 18.99
- pinnacle totals 2.25 [2026-11-13T13:20:52Z]: over 1.89/under 1.93

### Luxembourg–Estonia（espn:401861154; source eef1c96c424e42b66f49b7ec3bef1a5c; 2026-11-13T19:45:00+00:00 UTC）

- betfair_ex_eu h2h [2026-11-13T13:20:52Z]: away 3.15/draw 3.1/home 2.72
- betsson h2h [2026-11-13T13:20:54Z]: away 2.85/draw 2.92/home 2.55
- betsson totals 2.5 [2026-11-13T13:20:54Z]: over 2.52/under 1.49
- winamax_fr h2h [2026-11-13T13:20:53Z]: away 2.75/draw 2.85/home 2.5
- onexbet h2h [2026-11-13T13:20:53Z]: away 3.08/draw 3.08/home 2.62
- onexbet totals 1.5 [2026-11-13T13:20:53Z]: over 1.56/under 2.56
- betclic_fr h2h [2026-11-13T13:18:51Z]: away 2.95/draw 2.98/home 2.35
- nordicbet h2h [2026-11-13T13:20:52Z]: away 2.85/draw 2.92/home 2.55
- nordicbet totals 2.5 [2026-11-13T13:20:52Z]: over 2.52/under 1.49
- pmu_fr h2h [2026-11-13T13:20:51Z]: away 2.75/draw 2.8/home 2.33
- pmu_fr totals 2.5 [2026-11-13T13:20:51Z]: over 2.32/under 1.42
- marathonbet h2h [2026-11-13T13:20:57Z]: away 3.05/draw 3.04/home 2.59
- marathonbet totals 2.5 [2026-11-13T13:20:57Z]: over 2.6/under 1.51
- sport888 h2h [2026-11-13T13:10:55Z]: away 2.9/draw 2.88/home 2.5
- williamhill h2h [2026-11-13T13:20:30Z]: away 2.88/draw 2.8/home 2.5
- williamhill totals 2.5 [2026-11-13T13:20:30Z]: over 2.45/under 1.5
- mybookieag h2h [2026-11-13T13:19:14Z]: away 2.91/draw 3.0/home 2.48
- mybookieag totals 2.5 [2026-11-13T13:19:14Z]: over 2.46/under 1.49
- betanysports h2h [2026-11-13T13:20:52Z]: away 2.98/draw 3.03/home 2.41
- betanysports totals 2 [2026-11-13T13:20:52Z]: over 1.86/under 1.96
- pinnacle h2h [2026-11-13T13:20:52Z]: away 3.01/draw 3.06/home 2.66
- pinnacle totals 2 [2026-11-13T13:20:52Z]: over 1.95/under 1.92

### Netherlands–Greece（espn:401861159; source 0010d3b2b15a2b8cb04053b0b1407cc5; 2026-11-13T19:45:00+00:00 UTC）

- onexbet h2h [2026-11-13T13:20:52Z]: away 5.38/draw 4.58/home 1.61
- onexbet totals 2.5 [2026-11-13T13:20:52Z]: over 1.63/under 2.43
- betfair_ex_eu h2h [2026-11-13T13:20:52Z]: away 5.8/draw 4.7/home 1.61
- betclic_fr h2h [2026-11-13T13:18:51Z]: away 5.0/draw 4.25/home 1.51
- winamax_de h2h [2026-11-13T13:20:55Z]: away 4.7/draw 4.5/home 1.56
- winamax_fr h2h [2026-11-13T13:20:53Z]: away 4.75/draw 4.4/home 1.5
- williamhill h2h [2026-11-13T13:20:30Z]: away 4.8/draw 4.0/home 1.57
- williamhill totals 2.5 [2026-11-13T13:20:30Z]: over 1.5/under 2.5
- sport888 h2h [2026-11-13T13:10:55Z]: away 4.8/draw 4.0/home 1.57
- betsson h2h [2026-11-13T13:20:54Z]: away 4.9/draw 4.3/home 1.58
- betsson totals 2.5 [2026-11-13T13:20:54Z]: over 1.5/under 2.52
- nordicbet h2h [2026-11-13T13:20:52Z]: away 4.9/draw 4.3/home 1.58
- nordicbet totals 2.5 [2026-11-13T13:20:52Z]: over 1.5/under 2.52
- marathonbet h2h [2026-11-13T13:20:57Z]: away 5.35/draw 4.55/home 1.6
- marathonbet totals 3.5 [2026-11-13T13:20:57Z]: over 2.44/under 1.57
- pinnacle h2h [2026-11-13T13:20:52Z]: away 5.2/draw 4.62/home 1.6
- pinnacle totals 3 [2026-11-13T13:20:52Z]: over 1.88/under 2.0
- unibet_se h2h [2026-11-13T13:20:29Z]: away 5.75/draw 4.5/home 1.56
- unibet_se totals 2.5 [2026-11-13T13:20:29Z]: over 1.56/under 2.35
- pmu_fr h2h [2026-11-13T13:20:51Z]: away 4.9/draw 3.95/home 1.49
- pmu_fr totals 2.5 [2026-11-13T13:20:51Z]: over 1.47/under 2.2
- leovegas_se h2h [2026-11-13T13:20:29Z]: away 5.25/draw 4.2/home 1.53
- leovegas_se totals 2.5 [2026-11-13T13:20:29Z]: over 1.56/under 2.35
- mybookieag h2h [2026-11-13T13:19:14Z]: away 4.8/draw 4.2/home 1.57
- mybookieag totals 3.5 [2026-11-13T13:19:14Z]: over 2.27/under 1.56
- matchbook h2h [2026-11-13T13:20:52Z]: away 5.8/draw 4.7/home 1.61
- matchbook totals 3.5 [2026-11-13T13:20:52Z]: over 2.46/under 1.67
- betonlineag h2h [2026-11-13T13:20:53Z]: away 5.52/draw 4.4/home 1.6
- betonlineag totals 3 [2026-11-13T13:20:53Z]: over 1.85/under 1.98
- betanysports h2h [2026-11-13T13:20:52Z]: away 5.33/draw 4.45/home 1.59
- betanysports totals 3 [2026-11-13T13:20:52Z]: over 1.84/under 1.99

### Scotland–North Macedonia（espn:401861161; source 199940cd0d3a9c7ad93be4063cb2df93; 2026-11-13T19:45:00+00:00 UTC）

- marathonbet h2h [2026-11-13T13:20:57Z]: away 17.5/draw 7.1/home 1.18
- marathonbet totals 2.5 [2026-11-13T13:20:57Z]: over 1.62/under 2.34
- betfair_ex_eu h2h [2026-11-13T13:20:52Z]: away 20.0/draw 7.8/home 1.21
- unibet_se h2h [2026-11-13T13:20:29Z]: away 20.0/draw 7.5/home 1.18
- unibet_se totals 2.5 [2026-11-13T13:20:29Z]: over 1.63/under 2.23
- betsson h2h [2026-11-13T13:20:54Z]: away 18.0/draw 7.1/home 1.16
- betsson totals 2.5 [2026-11-13T13:20:54Z]: over 1.52/under 2.42
- onexbet h2h [2026-11-13T13:20:52Z]: away 17.5/draw 7.18/home 1.2
- onexbet totals 2.5 [2026-11-13T13:20:52Z]: over 1.64/under 2.38
- sport888 h2h [2026-11-13T13:10:55Z]: away 15.0/draw 6.5/home 1.17
- leovegas_se h2h [2026-11-13T13:20:29Z]: away 16.0/draw 6.75/home 1.16
- leovegas_se totals 2.5 [2026-11-13T13:20:29Z]: over 1.63/under 2.23
- winamax_fr h2h [2026-11-13T13:20:53Z]: away 13.0/draw 7.5/home 1.12
- winamax_de h2h [2026-11-13T13:20:55Z]: away 14.0/draw 7.25/home 1.15
- williamhill h2h [2026-11-13T13:20:30Z]: away 15.0/draw 6.5/home 1.17
- williamhill totals 2.5 [2026-11-13T13:20:30Z]: over 1.53/under 2.4
- betclic_fr h2h [2026-11-13T13:18:51Z]: away 14.0/draw 6.5/home 1.14
- pmu_fr h2h [2026-11-13T13:20:51Z]: away 15.0/draw 6.25/home 1.13
- pmu_fr totals 2.5 [2026-11-13T13:20:51Z]: over 1.51/under 2.08
- nordicbet h2h [2026-11-13T13:20:52Z]: away 18.0/draw 7.1/home 1.16
- nordicbet totals 2.5 [2026-11-13T13:20:52Z]: over 1.52/under 2.42
- mybookieag h2h [2026-11-13T13:19:14Z]: away 14.75/draw 6.6/home 1.16
- mybookieag totals 2.5 [2026-11-13T13:19:14Z]: over 1.57/under 2.24
- betanysports h2h [2026-11-13T13:20:52Z]: away 14.8/draw 7.05/home 1.18
- betanysports totals 3 [2026-11-13T13:20:52Z]: over 1.99/under 1.84
- pinnacle h2h [2026-11-13T13:20:52Z]: away 17.13/draw 7.92/home 1.18
- pinnacle totals 3 [2026-11-13T13:20:52Z]: over 1.93/under 1.96

### Serbia–Germany（espn:401861158; source d0ee3d2f44cf592797f6ecae8de62edd; 2026-11-13T19:45:00+00:00 UTC）

- onexbet h2h [2026-11-13T13:20:52Z]: away 1.29/draw 6.53/home 10.5
- onexbet totals 3.5 [2026-11-13T13:20:52Z]: over 2.17/under 1.77
- betfair_ex_eu h2h [2026-11-13T13:20:52Z]: away 1.29/draw 6.8/home 12.0
- betsson h2h [2026-11-13T13:20:54Z]: away 1.23/draw 6.1/home 11.5
- betsson totals 2.5 [2026-11-13T13:20:54Z]: over 1.41/under 2.85
- nordicbet h2h [2026-11-13T13:20:52Z]: away 1.23/draw 6.1/home 11.5
- nordicbet totals 2.5 [2026-11-13T13:20:52Z]: over 1.41/under 2.85
- betclic_fr h2h [2026-11-13T13:18:51Z]: away 1.21/draw 6.0/home 9.5
- winamax_de h2h [2026-11-13T13:20:55Z]: away 1.23/draw 6.75/home 9.0
- winamax_fr h2h [2026-11-13T13:20:53Z]: away 1.18/draw 6.75/home 8.5
- williamhill h2h [2026-11-13T13:20:30Z]: away 1.25/draw 6.0/home 9.5
- williamhill totals 2.5 [2026-11-13T13:20:30Z]: over 1.36/under 2.8
- sport888 h2h [2026-11-13T13:10:55Z]: away 1.25/draw 6.0/home 9.5
- marathonbet h2h [2026-11-13T13:20:57Z]: away 1.25/draw 6.9/home 11.5
- marathonbet totals 3.5 [2026-11-13T13:20:57Z]: over 2.08/under 1.77
- pinnacle h2h [2026-11-13T13:20:52Z]: away 1.26/draw 6.8/home 10.32
- pinnacle totals 3.25 [2026-11-13T13:20:52Z]: over 1.89/under 1.98
- unibet_se h2h [2026-11-13T13:20:29Z]: away 1.28/draw 6.25/home 10.5
- unibet_se totals 3.5 [2026-11-13T13:20:29Z]: over 2.0/under 1.78
- leovegas_se h2h [2026-11-13T13:20:29Z]: away 1.26/draw 5.75/home 9.0
- leovegas_se totals 3.5 [2026-11-13T13:20:29Z]: over 2.0/under 1.78
- pmu_fr h2h [2026-11-13T13:20:51Z]: away 1.23/draw 5.3/home 8.5
- pmu_fr totals 3.5 [2026-11-13T13:20:51Z]: over 1.87/under 1.66
- mybookieag h2h [2026-11-13T13:19:14Z]: away 1.26/draw 5.9/home 9.0
- mybookieag totals 3.5 [2026-11-13T13:19:14Z]: over 2.02/under 1.71
- matchbook h2h [2026-11-13T13:20:52Z]: away 1.29/draw 6.8/home 12.0
- matchbook totals 3.5 [2026-11-13T13:20:52Z]: over 2.14/under 1.86
- betonlineag h2h [2026-11-13T13:20:53Z]: away 1.27/draw 6.62/home 10.15
- betonlineag totals 3.5 [2026-11-13T13:20:53Z]: over 2.08/under 1.78
- betanysports h2h [2026-11-13T13:20:52Z]: away 1.22/draw 7.25/home 11.74
- betanysports totals 3.25 [2026-11-13T13:20:52Z]: over 1.91/under 1.91

### Slovakia–Faroe Islands（espn:401861160; source a2b1b42a452df659cc5d0d242d8f98be; 2026-11-13T19:45:00+00:00 UTC）

- unibet_se h2h [2026-11-13T13:20:29Z]: away 10.0/draw 4.9/home 1.33
- unibet_se totals 2.5 [2026-11-13T13:20:29Z]: over 1.83/under 1.92
- onexbet h2h [2026-11-13T13:20:53Z]: away 9.4/draw 4.91/home 1.39
- onexbet totals 2.5 [2026-11-13T13:20:53Z]: over 1.93/under 1.95
- winamax_de h2h [2026-11-13T13:20:55Z]: away 8.0/draw 5.0/home 1.33
- betclic_fr h2h [2026-11-13T13:18:51Z]: away 9.0/draw 4.7/home 1.29
- betfair_ex_eu h2h [2026-11-13T13:20:52Z]: away 11.0/draw 5.1/home 1.39
- leovegas_se h2h [2026-11-13T13:20:29Z]: away 10.0/draw 4.9/home 1.33
- leovegas_se totals 2.5 [2026-11-13T13:20:29Z]: over 1.83/under 1.92
- nordicbet h2h [2026-11-13T13:20:52Z]: away 9.3/draw 4.55/home 1.33
- nordicbet totals 2.5 [2026-11-13T13:20:52Z]: over 1.85/under 1.88
- pmu_fr h2h [2026-11-13T13:20:51Z]: away 8.5/draw 4.4/home 1.26
- pmu_fr totals 2.5 [2026-11-13T13:20:51Z]: over 1.72/under 1.81
- winamax_fr h2h [2026-11-13T13:20:53Z]: away 7.5/draw 4.75/home 1.3
- betsson h2h [2026-11-13T13:20:54Z]: away 9.3/draw 4.55/home 1.33
- betsson totals 2.5 [2026-11-13T13:20:54Z]: over 1.85/under 1.88
- sport888 h2h [2026-11-13T13:10:55Z]: away 8.5/draw 4.5/home 1.36
- williamhill h2h [2026-11-13T13:20:30Z]: away 8.0/draw 4.4/home 1.35
- williamhill totals 2.5 [2026-11-13T13:20:30Z]: over 1.83/under 1.91
- mybookieag h2h [2026-11-13T13:19:14Z]: away 8.7/draw 4.7/home 1.33
- mybookieag totals 2.5 [2026-11-13T13:19:14Z]: over 1.88/under 1.83
- marathonbet h2h [2026-11-13T13:20:57Z]: away 9.3/draw 4.85/home 1.37
- marathonbet totals 2.5 [2026-11-13T13:20:57Z]: over 1.9/under 1.92
- betanysports h2h [2026-11-13T13:20:51Z]: away 9.02/draw 4.62/home 1.33
- betanysports totals 2.5 [2026-11-13T13:20:51Z]: over 1.98/under 1.85
- pinnacle h2h [2026-11-13T13:20:52Z]: away 9.42/draw 4.9/home 1.37
- pinnacle totals 2.5 [2026-11-13T13:20:52Z]: over 1.93/under 1.94

### Slovenia–Switzerland（espn:401861156; source af4d45ae5e37dc2a0e146d2a9e9a926d; 2026-11-13T19:45:00+00:00 UTC）

- leovegas_se h2h [2026-11-13T13:20:29Z]: away 1.67/draw 3.3/home 5.5
- leovegas_se totals 1.5 [2026-11-13T13:20:29Z]: over 1.49/under 2.55
- betsson h2h [2026-11-13T13:20:54Z]: away 1.68/draw 3.4/home 5.9
- betsson totals 2.5 [2026-11-13T13:20:54Z]: over 2.62/under 1.47
- sport888 h2h [2026-11-13T13:10:55Z]: away 1.7/draw 3.2/home 5.5
- unibet_se h2h [2026-11-13T13:20:29Z]: away 1.73/draw 3.5/home 6.0
- unibet_se totals 1.5 [2026-11-13T13:20:29Z]: over 1.49/under 2.55
- betfair_ex_eu h2h [2026-11-13T13:20:52Z]: away 1.75/draw 3.55/home 6.6
- onexbet h2h [2026-11-13T13:20:52Z]: away 1.75/draw 3.44/home 5.96
- onexbet totals 2.5 [2026-11-13T13:20:52Z]: over 2.61/under 1.54
- williamhill h2h [2026-11-13T13:20:30Z]: away 1.67/draw 3.1/home 5.5
- williamhill totals 2.5 [2026-11-13T13:20:30Z]: over 2.5/under 1.44
- winamax_fr h2h [2026-11-13T13:20:53Z]: away 1.6/draw 3.4/home 5.5
- nordicbet h2h [2026-11-13T13:20:52Z]: away 1.68/draw 3.4/home 5.9
- nordicbet totals 2.5 [2026-11-13T13:20:52Z]: over 2.62/under 1.47
- winamax_de h2h [2026-11-13T13:20:55Z]: away 1.64/draw 3.4/home 5.6
- marathonbet h2h [2026-11-13T13:20:57Z]: away 1.73/draw 3.4/home 5.9
- marathonbet totals 2.5 [2026-11-13T13:20:57Z]: over 2.57/under 1.52
- pmu_fr h2h [2026-11-13T13:20:51Z]: away 1.64/draw 3.15/home 5.2
- pmu_fr totals 1.5 [2026-11-13T13:20:51Z]: over 1.4/under 2.38
- betclic_fr h2h [2026-11-13T13:18:51Z]: away 1.61/draw 3.28/home 5.75
- mybookieag h2h [2026-11-13T13:19:14Z]: away 1.68/draw 3.28/home 5.5
- mybookieag totals 1.5 [2026-11-13T13:19:14Z]: over 1.5/under 2.43
- betanysports h2h [2026-11-13T13:20:52Z]: away 1.67/draw 3.3/home 6.0
- betanysports totals 2 [2026-11-13T13:20:52Z]: over 1.86/under 1.96
- pinnacle h2h [2026-11-13T13:20:52Z]: away 1.7/draw 3.44/home 6.41
- pinnacle totals 2 [2026-11-13T13:20:52Z]: over 2.0/under 1.89

## 旧本地同场同机构同盘线变化

| source ID | 比赛 | 机构 | 市场/线 | 旧报价时点/价格 | 本次报价时点/价格 |
|---|---|---|---|---|---|
| cc1ca0aea8a9aa6ad2e1537834fe0d04 | Moldova–Kazakhstan | betanysports | h2h  | 2026-11-12T16:22:17Z Draw:2.92/Kazakhstan:2.81/Moldova:2.63 | 2026-11-13T13:20:51Z Draw:2.93/Kazakhstan:3.03/Moldova:2.44 |
| cc1ca0aea8a9aa6ad2e1537834fe0d04 | Moldova–Kazakhstan | betanysports | totals 2.0 | 2026-11-12T16:22:17Z Over:1.8/Under:2.05 | 2026-11-13T13:20:51Z Over:1.77/Under:2.1 |
| cc1ca0aea8a9aa6ad2e1537834fe0d04 | Moldova–Kazakhstan | betclic_fr | h2h  | 2026-11-12T16:20:36Z Draw:2.9/Kazakhstan:2.75/Moldova:2.48 | 2026-11-13T13:18:51Z Draw:2.93/Kazakhstan:2.95/Moldova:2.38 |
| cc1ca0aea8a9aa6ad2e1537834fe0d04 | Moldova–Kazakhstan | betfair_ex_eu | h2h  | 2026-11-12T16:22:18Z Draw:3.1/Kazakhstan:2.98/Moldova:2.78 | 2026-11-13T13:20:52Z Draw:3.15/Kazakhstan:3.25/Moldova:2.64 |
| cc1ca0aea8a9aa6ad2e1537834fe0d04 | Moldova–Kazakhstan | betsson | h2h  | 2026-11-12T16:22:04Z Draw:2.92/Kazakhstan:2.75/Moldova:2.65 | 2026-11-13T13:20:54Z Draw:2.92/Kazakhstan:2.95/Moldova:2.52 |
| cc1ca0aea8a9aa6ad2e1537834fe0d04 | Moldova–Kazakhstan | betsson | totals 2.5 | 2026-11-12T16:22:04Z Over:2.38/Under:1.52 | 2026-11-13T13:20:54Z Over:2.38/Under:1.52 |
| cc1ca0aea8a9aa6ad2e1537834fe0d04 | Moldova–Kazakhstan | leovegas_se | h2h  | 2026-11-12T16:22:19Z Draw:3.05/Kazakhstan:2.95/Moldova:2.55 | 2026-11-13T13:20:29Z Draw:2.9/Kazakhstan:2.88/Moldova:2.7 |
| cc1ca0aea8a9aa6ad2e1537834fe0d04 | Moldova–Kazakhstan | marathonbet | h2h  | 2026-11-12T16:22:03Z Draw:3.05/Kazakhstan:2.88/Moldova:2.72 | 2026-11-13T13:20:57Z Draw:3.02/Kazakhstan:3.04/Moldova:2.62 |
| cc1ca0aea8a9aa6ad2e1537834fe0d04 | Moldova–Kazakhstan | marathonbet | totals 2.5 | 2026-11-12T16:22:03Z Over:2.54/Under:1.53 | 2026-11-13T13:20:57Z Over:2.51/Under:1.54 |
| cc1ca0aea8a9aa6ad2e1537834fe0d04 | Moldova–Kazakhstan | mybookieag | h2h  | 2026-11-12T16:18:51Z Draw:2.92/Kazakhstan:2.77/Moldova:2.59 | 2026-11-13T13:19:14Z Draw:2.95/Kazakhstan:2.97/Moldova:2.48 |
| cc1ca0aea8a9aa6ad2e1537834fe0d04 | Moldova–Kazakhstan | mybookieag | totals 2.5 | 2026-11-12T16:18:51Z Over:2.38/Under:1.51 | 2026-11-13T13:19:14Z Over:2.35/Under:1.53 |
| cc1ca0aea8a9aa6ad2e1537834fe0d04 | Moldova–Kazakhstan | nordicbet | h2h  | 2026-11-12T16:21:42Z Draw:2.92/Kazakhstan:2.75/Moldova:2.65 | 2026-11-13T13:20:52Z Draw:2.92/Kazakhstan:2.95/Moldova:2.52 |
| cc1ca0aea8a9aa6ad2e1537834fe0d04 | Moldova–Kazakhstan | nordicbet | totals 2.5 | 2026-11-12T16:21:42Z Over:2.38/Under:1.52 | 2026-11-13T13:20:52Z Over:2.38/Under:1.52 |
| cc1ca0aea8a9aa6ad2e1537834fe0d04 | Moldova–Kazakhstan | onexbet | h2h  | 2026-11-12T16:21:20Z Draw:3.08/Kazakhstan:2.91/Moldova:2.75 | 2026-11-13T13:20:52Z Draw:3.05/Kazakhstan:3.07/Moldova:2.65 |
| cc1ca0aea8a9aa6ad2e1537834fe0d04 | Moldova–Kazakhstan | onexbet | totals 2.5 | 2026-11-12T16:21:20Z Over:2.58/Under:1.55 | 2026-11-13T13:20:52Z Over:2.55/Under:1.56 |
| cc1ca0aea8a9aa6ad2e1537834fe0d04 | Moldova–Kazakhstan | pinnacle | h2h  | 2026-11-12T16:22:20Z Draw:2.96/Kazakhstan:2.9/Moldova:2.71 | 2026-11-13T13:20:52Z Draw:3.02/Kazakhstan:3.12/Moldova:2.6 |
| cc1ca0aea8a9aa6ad2e1537834fe0d04 | Moldova–Kazakhstan | pinnacle | totals 2.0 | 2026-11-12T16:22:20Z Over:1.83/Under:2.01 | 2026-11-13T13:20:52Z Over:1.86/Under:2.01 |
| cc1ca0aea8a9aa6ad2e1537834fe0d04 | Moldova–Kazakhstan | pmu_fr | h2h  | 2026-11-12T16:21:40Z Draw:2.8/Kazakhstan:2.75/Moldova:2.38 | 2026-11-13T13:20:51Z Draw:2.7/Kazakhstan:2.65/Moldova:2.55 |
| cc1ca0aea8a9aa6ad2e1537834fe0d04 | Moldova–Kazakhstan | sport888 | h2h  | 2026-11-12T16:21:39Z Draw:2.9/Kazakhstan:2.8/Moldova:2.62 | 2026-11-13T13:10:55Z Draw:2.9/Kazakhstan:2.9/Moldova:2.5 |
| cc1ca0aea8a9aa6ad2e1537834fe0d04 | Moldova–Kazakhstan | unibet_se | h2h  | 2026-11-12T16:22:00Z Draw:3.05/Kazakhstan:2.95/Moldova:2.55 | 2026-11-13T13:20:29Z Draw:2.9/Kazakhstan:2.88/Moldova:2.7 |
| cc1ca0aea8a9aa6ad2e1537834fe0d04 | Moldova–Kazakhstan | williamhill | h2h  | 2026-11-12T16:22:19Z Draw:2.8/Kazakhstan:2.7/Moldova:2.6 | 2026-11-13T13:20:30Z Draw:2.8/Kazakhstan:2.9/Moldova:2.45 |
| cc1ca0aea8a9aa6ad2e1537834fe0d04 | Moldova–Kazakhstan | williamhill | totals 2.5 | 2026-11-12T16:22:19Z Over:2.3/Under:1.55 | 2026-11-13T13:20:30Z Over:2.38/Under:1.55 |
| cc1ca0aea8a9aa6ad2e1537834fe0d04 | Moldova–Kazakhstan | winamax_fr | h2h  | 2026-11-12T16:22:18Z Draw:2.9/Kazakhstan:2.65/Moldova:2.5 | 2026-11-13T13:20:53Z Draw:2.9/Kazakhstan:2.8/Moldova:2.35 |
| 6eecb0b534f8cda6254b8a0884289e16 | Andorra–Gibraltar | betanysports | h2h  | 2026-11-12T16:22:17Z Andorra:1.75/Draw:3.15/Gibraltar:5.28 | 2026-11-13T13:20:52Z Andorra:1.64/Draw:3.27/Gibraltar:6.1 |
| 6eecb0b534f8cda6254b8a0884289e16 | Andorra–Gibraltar | betanysports | totals 1.75 | 2026-11-12T16:22:17Z Over:2.05/Under:1.8 | 2026-11-13T13:20:52Z Over:2.05/Under:1.8 |
| 6eecb0b534f8cda6254b8a0884289e16 | Andorra–Gibraltar | betclic_fr | h2h  | 2026-11-12T16:20:36Z Andorra:1.7/Draw:3.1/Gibraltar:5.0 | 2026-11-13T13:18:51Z Andorra:1.62/Draw:3.2/Gibraltar:5.9 |
| 6eecb0b534f8cda6254b8a0884289e16 | Andorra–Gibraltar | betfair_ex_eu | h2h  | 2026-11-12T16:22:18Z Andorra:1.83/Draw:3.25/Gibraltar:6.2 | 2026-11-13T13:20:52Z Andorra:1.71/Draw:3.4/Gibraltar:8.0 |
| 6eecb0b534f8cda6254b8a0884289e16 | Andorra–Gibraltar | betsson | h2h  | 2026-11-12T16:22:04Z Andorra:1.72/Draw:3.1/Gibraltar:5.4 | 2026-11-13T13:20:54Z Andorra:1.6/Draw:3.2/Gibraltar:6.3 |
| 6eecb0b534f8cda6254b8a0884289e16 | Andorra–Gibraltar | betsson | totals 2.5 | 2026-11-12T16:22:04Z Over:3.05/Under:1.32 | 2026-11-13T13:20:54Z Over:3.15/Under:1.32 |
| 6eecb0b534f8cda6254b8a0884289e16 | Andorra–Gibraltar | leovegas_se | h2h  | 2026-11-12T16:22:19Z Andorra:1.8/Draw:3.0/Gibraltar:5.6 | 2026-11-13T13:20:29Z Andorra:1.72/Draw:3.1/Gibraltar:6.0 |
| 6eecb0b534f8cda6254b8a0884289e16 | Andorra–Gibraltar | leovegas_se | totals 1.5 | 2026-11-12T16:22:19Z Over:1.73/Under:2.04 | 2026-11-13T13:20:29Z Over:1.7/Under:2.08 |
| 6eecb0b534f8cda6254b8a0884289e16 | Andorra–Gibraltar | marathonbet | h2h  | 2026-11-12T16:22:03Z Andorra:1.8/Draw:3.22/Gibraltar:5.65 | 2026-11-13T13:20:57Z Andorra:1.68/Draw:3.34/Gibraltar:6.75 |
| 6eecb0b534f8cda6254b8a0884289e16 | Andorra–Gibraltar | marathonbet | totals 1.5 | 2026-11-12T16:22:03Z Over:1.71/Under:2.16 | 2026-11-13T13:20:57Z Over:1.73/Under:2.14 |
| 6eecb0b534f8cda6254b8a0884289e16 | Andorra–Gibraltar | mybookieag | h2h  | 2026-11-12T16:18:51Z Andorra:1.77/Draw:3.02/Gibraltar:5.2 | 2026-11-13T13:19:14Z Andorra:1.67/Draw:3.16/Gibraltar:6.1 |
| 6eecb0b534f8cda6254b8a0884289e16 | Andorra–Gibraltar | mybookieag | totals 1.5 | 2026-11-12T16:18:51Z Over:1.68/Under:2.07 | 2026-11-13T13:19:14Z Over:1.71/Under:2.02 |
| 6eecb0b534f8cda6254b8a0884289e16 | Andorra–Gibraltar | nordicbet | h2h  | 2026-11-12T16:21:42Z Andorra:1.72/Draw:3.1/Gibraltar:5.4 | 2026-11-13T13:20:52Z Andorra:1.6/Draw:3.2/Gibraltar:6.3 |
| 6eecb0b534f8cda6254b8a0884289e16 | Andorra–Gibraltar | nordicbet | totals 2.5 | 2026-11-12T16:21:42Z Over:3.05/Under:1.32 | 2026-11-13T13:20:52Z Over:3.15/Under:1.32 |
| 6eecb0b534f8cda6254b8a0884289e16 | Andorra–Gibraltar | onexbet | h2h  | 2026-11-12T16:21:20Z Andorra:1.82/Draw:3.25/Gibraltar:5.71 | 2026-11-13T13:20:53Z Andorra:1.7/Draw:3.38/Gibraltar:6.82 |
| 6eecb0b534f8cda6254b8a0884289e16 | Andorra–Gibraltar | onexbet | totals 1.5 | 2026-11-12T16:21:20Z Over:1.74/Under:2.19 | 2026-11-13T13:20:53Z Over:1.75/Under:2.17 |
| 6eecb0b534f8cda6254b8a0884289e16 | Andorra–Gibraltar | pinnacle | h2h  | 2026-11-12T16:22:20Z Andorra:1.74/Draw:3.17/Gibraltar:5.57 | 2026-11-13T13:20:52Z Andorra:1.67/Draw:3.26/Gibraltar:6.89 |
| 6eecb0b534f8cda6254b8a0884289e16 | Andorra–Gibraltar | pinnacle | totals 1.75 | 2026-11-12T16:22:20Z Over:1.96/Under:1.85 | 2026-11-13T13:20:52Z Over:1.98/Under:1.85 |
| 6eecb0b534f8cda6254b8a0884289e16 | Andorra–Gibraltar | pmu_fr | h2h  | 2026-11-12T16:21:40Z Andorra:1.7/Draw:2.8/Gibraltar:5.2 | 2026-11-13T13:20:51Z Andorra:1.63/Draw:2.9/Gibraltar:5.5 |
| 6eecb0b534f8cda6254b8a0884289e16 | Andorra–Gibraltar | pmu_fr | totals 1.5 | 2026-11-12T16:21:40Z Over:1.63/Under:1.92 | 2026-11-13T13:20:51Z Over:1.6/Under:1.95 |
| 6eecb0b534f8cda6254b8a0884289e16 | Andorra–Gibraltar | sport888 | h2h  | 2026-11-12T16:21:39Z Andorra:1.8/Draw:3.0/Gibraltar:5.0 | 2026-11-13T13:10:55Z Andorra:1.67/Draw:3.1/Gibraltar:6.0 |
| 6eecb0b534f8cda6254b8a0884289e16 | Andorra–Gibraltar | unibet_se | h2h  | 2026-11-12T16:22:00Z Andorra:1.8/Draw:3.0/Gibraltar:5.6 | 2026-11-13T13:20:29Z Andorra:1.72/Draw:3.1/Gibraltar:6.0 |
| 6eecb0b534f8cda6254b8a0884289e16 | Andorra–Gibraltar | unibet_se | totals 1.5 | 2026-11-12T16:22:00Z Over:1.73/Under:2.04 | 2026-11-13T13:20:29Z Over:1.7/Under:2.08 |
| 6eecb0b534f8cda6254b8a0884289e16 | Andorra–Gibraltar | williamhill | h2h  | 2026-11-12T16:22:19Z Andorra:1.75/Draw:2.9/Gibraltar:5.0 | 2026-11-13T13:20:30Z Andorra:1.62/Draw:3.0/Gibraltar:6.0 |
| 6eecb0b534f8cda6254b8a0884289e16 | Andorra–Gibraltar | williamhill | totals 2.5 | 2026-11-12T16:22:19Z Over:3.0/Under:1.35 | 2026-11-13T13:20:30Z Over:3.0/Under:1.35 |
| 6eecb0b534f8cda6254b8a0884289e16 | Andorra–Gibraltar | winamax_de | h2h  | 2026-11-12T16:22:20Z Andorra:1.74/Draw:3.25/Gibraltar:5.2 | 2026-11-13T13:20:55Z Andorra:1.62/Draw:3.35/Gibraltar:6.0 |
| 6eecb0b534f8cda6254b8a0884289e16 | Andorra–Gibraltar | winamax_fr | h2h  | 2026-11-12T16:22:18Z Andorra:1.68/Draw:3.1/Gibraltar:4.9 | 2026-11-13T13:20:53Z Andorra:1.58/Draw:3.2/Gibraltar:5.8 |
| b53069411f63a0d3aed21fa84d225faf | Bulgaria–Iceland | betanysports | h2h  | 2026-11-12T16:22:17Z Bulgaria:4.36/Draw:3.43/Iceland:1.79 | 2026-11-13T13:20:52Z Bulgaria:4.79/Draw:3.58/Iceland:1.69 |
| b53069411f63a0d3aed21fa84d225faf | Bulgaria–Iceland | betanysports | totals 2.25 | 2026-11-12T16:22:17Z Over:1.81/Under:2.03 | 2026-11-13T13:20:52Z Over:1.76/Under:2.11 |
| b53069411f63a0d3aed21fa84d225faf | Bulgaria–Iceland | betclic_fr | h2h  | 2026-11-12T16:20:36Z Bulgaria:4.0/Draw:3.4/Iceland:1.77 | 2026-11-13T13:18:51Z Bulgaria:4.5/Draw:3.5/Iceland:1.69 |
| b53069411f63a0d3aed21fa84d225faf | Bulgaria–Iceland | betfair_ex_eu | h2h  | 2026-11-12T16:22:18Z Bulgaria:4.5/Draw:3.65/Iceland:1.91 | 2026-11-13T13:20:52Z Bulgaria:5.5/Draw:3.85/Iceland:1.77 |
| b53069411f63a0d3aed21fa84d225faf | Bulgaria–Iceland | betsson | h2h  | 2026-11-12T16:22:04Z Bulgaria:4.25/Draw:3.45/Iceland:1.78 | 2026-11-13T13:20:54Z Bulgaria:4.9/Draw:3.6/Iceland:1.68 |
| b53069411f63a0d3aed21fa84d225faf | Bulgaria–Iceland | betsson | totals 2.5 | 2026-11-12T16:22:04Z Over:2.08/Under:1.7 | 2026-11-13T13:20:54Z Over:1.98/Under:1.75 |
| b53069411f63a0d3aed21fa84d225faf | Bulgaria–Iceland | leovegas_se | h2h  | 2026-11-12T16:22:19Z Bulgaria:4.3/Draw:3.5/Iceland:1.85 | 2026-11-13T13:20:29Z Bulgaria:4.7/Draw:3.55/Iceland:1.78 |
| b53069411f63a0d3aed21fa84d225faf | Bulgaria–Iceland | leovegas_se | totals 2.5 | 2026-11-12T16:22:19Z Over:2.05/Under:1.73 | 2026-11-13T13:20:29Z Over:2.08/Under:1.7 |
| b53069411f63a0d3aed21fa84d225faf | Bulgaria–Iceland | marathonbet | h2h  | 2026-11-12T16:22:03Z Bulgaria:4.33/Draw:3.56/Iceland:1.88 | 2026-11-13T13:20:57Z Bulgaria:4.9/Draw:3.7/Iceland:1.76 |
| b53069411f63a0d3aed21fa84d225faf | Bulgaria–Iceland | marathonbet | totals 2.5 | 2026-11-12T16:22:03Z Over:2.1/Under:1.75 | 2026-11-13T13:20:57Z Over:2.05/Under:1.79 |
| b53069411f63a0d3aed21fa84d225faf | Bulgaria–Iceland | mybookieag | h2h  | 2026-11-12T16:18:51Z Bulgaria:4.1/Draw:3.4/Iceland:1.81 | 2026-11-13T13:19:14Z Bulgaria:4.6/Draw:3.55/Iceland:1.71 |
| b53069411f63a0d3aed21fa84d225faf | Bulgaria–Iceland | mybookieag | totals 2.5 | 2026-11-12T16:18:51Z Over:2.04/Under:1.69 | 2026-11-13T13:19:14Z Over:1.98/Under:1.74 |
| b53069411f63a0d3aed21fa84d225faf | Bulgaria–Iceland | nordicbet | h2h  | 2026-11-12T16:21:42Z Bulgaria:4.25/Draw:3.45/Iceland:1.78 | 2026-11-13T13:20:52Z Bulgaria:4.9/Draw:3.6/Iceland:1.68 |
| b53069411f63a0d3aed21fa84d225faf | Bulgaria–Iceland | nordicbet | totals 2.5 | 2026-11-12T16:21:42Z Over:2.08/Under:1.7 | 2026-11-13T13:20:52Z Over:1.98/Under:1.75 |
| b53069411f63a0d3aed21fa84d225faf | Bulgaria–Iceland | onexbet | h2h  | 2026-11-12T16:21:20Z Bulgaria:4.38/Draw:3.6/Iceland:1.9 | 2026-11-13T13:20:53Z Bulgaria:4.96/Draw:3.74/Iceland:1.78 |
| b53069411f63a0d3aed21fa84d225faf | Bulgaria–Iceland | onexbet | totals 2.5 | 2026-11-12T16:21:20Z Over:2.13/Under:1.78 | 2026-11-13T13:20:53Z Over:2.08/Under:1.82 |
| b53069411f63a0d3aed21fa84d225faf | Bulgaria–Iceland | pinnacle | h2h  | 2026-11-12T16:22:20Z Bulgaria:4.48/Draw:3.51/Iceland:1.83 | 2026-11-13T13:20:52Z Bulgaria:5.17/Draw:3.78/Iceland:1.72 |
| b53069411f63a0d3aed21fa84d225faf | Bulgaria–Iceland | pmu_fr | h2h  | 2026-11-12T16:21:40Z Bulgaria:3.95/Draw:3.2/Iceland:1.74 | 2026-11-13T13:20:51Z Bulgaria:4.3/Draw:3.25/Iceland:1.66 |
| b53069411f63a0d3aed21fa84d225faf | Bulgaria–Iceland | pmu_fr | totals 2.5 | 2026-11-12T16:21:40Z Over:1.93/Under:1.62 | 2026-11-13T13:20:51Z Over:1.95/Under:1.6 |
| b53069411f63a0d3aed21fa84d225faf | Bulgaria–Iceland | sport888 | h2h  | 2026-11-12T16:21:39Z Bulgaria:4.2/Draw:3.3/Iceland:1.85 | 2026-11-13T13:10:55Z Bulgaria:4.6/Draw:3.5/Iceland:1.73 |
| b53069411f63a0d3aed21fa84d225faf | Bulgaria–Iceland | unibet_se | h2h  | 2026-11-12T16:22:00Z Bulgaria:4.3/Draw:3.5/Iceland:1.85 | 2026-11-13T13:20:29Z Bulgaria:4.7/Draw:3.55/Iceland:1.78 |
| b53069411f63a0d3aed21fa84d225faf | Bulgaria–Iceland | unibet_se | totals 2.5 | 2026-11-12T16:22:00Z Over:2.05/Under:1.73 | 2026-11-13T13:20:29Z Over:2.08/Under:1.7 |
| b53069411f63a0d3aed21fa84d225faf | Bulgaria–Iceland | williamhill | h2h  | 2026-11-12T16:22:19Z Bulgaria:4.0/Draw:3.25/Iceland:1.8 | 2026-11-13T13:20:30Z Bulgaria:4.5/Draw:3.4/Iceland:1.7 |
| b53069411f63a0d3aed21fa84d225faf | Bulgaria–Iceland | williamhill | totals 2.5 | 2026-11-12T16:22:19Z Over:2.0/Under:1.75 | 2026-11-13T13:20:30Z Over:2.0/Under:1.75 |
| b53069411f63a0d3aed21fa84d225faf | Bulgaria–Iceland | winamax_de | h2h  | 2026-11-12T16:22:20Z Bulgaria:4.3/Draw:3.6/Iceland:1.78 | 2026-11-13T13:20:55Z Bulgaria:4.5/Draw:3.75/Iceland:1.7 |
| b53069411f63a0d3aed21fa84d225faf | Bulgaria–Iceland | winamax_fr | h2h  | 2026-11-12T16:22:18Z Bulgaria:4.0/Draw:3.4/Iceland:1.72 | 2026-11-13T13:20:53Z Bulgaria:4.2/Draw:3.55/Iceland:1.64 |
| 9529ee7ca79126460eb063f53187f321 | Liechtenstein–Azerbaijan | betanysports | h2h  | 2026-11-12T16:22:17Z Azerbaijan:1.26/Draw:5.1/Liechtenstein:11.85 | 2026-11-13T13:20:51Z Azerbaijan:1.19/Draw:5.85/Liechtenstein:17.8 |
| 9529ee7ca79126460eb063f53187f321 | Liechtenstein–Azerbaijan | betanysports | totals 2.25 | 2026-11-12T16:22:17Z Over:1.85/Under:1.98 | 2026-11-13T13:20:51Z Over:1.84/Under:1.99 |
| 9529ee7ca79126460eb063f53187f321 | Liechtenstein–Azerbaijan | betclic_fr | h2h  | 2026-11-12T16:20:36Z Azerbaijan:1.21/Draw:5.0/Liechtenstein:12.0 | 2026-11-13T13:18:51Z Azerbaijan:1.16/Draw:5.4/Liechtenstein:18.0 |
| 9529ee7ca79126460eb063f53187f321 | Liechtenstein–Azerbaijan | betfair_ex_eu | h2h  | 2026-11-12T16:22:18Z Azerbaijan:1.3/Draw:5.7/Liechtenstein:15.0 | 2026-11-13T13:20:52Z Azerbaijan:1.22/Draw:6.4/Liechtenstein:29.0 |
| 9529ee7ca79126460eb063f53187f321 | Liechtenstein–Azerbaijan | betsson | h2h  | 2026-11-12T16:22:04Z Azerbaijan:1.23/Draw:4.8/Liechtenstein:14.5 | 2026-11-13T13:20:54Z Azerbaijan:1.15/Draw:5.7/Liechtenstein:22.0 |
| 9529ee7ca79126460eb063f53187f321 | Liechtenstein–Azerbaijan | betsson | totals 2.5 | 2026-11-12T16:22:04Z Over:2.12/Under:1.62 | 2026-11-13T13:20:54Z Over:2.18/Under:1.62 |
| 9529ee7ca79126460eb063f53187f321 | Liechtenstein–Azerbaijan | leovegas_se | h2h  | 2026-11-12T16:22:19Z Azerbaijan:1.26/Draw:5.0/Liechtenstein:13.0 | 2026-11-13T13:20:29Z Azerbaijan:1.23/Draw:5.3/Liechtenstein:15.0 |
| 9529ee7ca79126460eb063f53187f321 | Liechtenstein–Azerbaijan | leovegas_se | totals 2.5 | 2026-11-12T16:22:19Z Over:2.02/Under:1.75 | 2026-11-13T13:20:29Z Over:2.02/Under:1.75 |
| 9529ee7ca79126460eb063f53187f321 | Liechtenstein–Azerbaijan | marathonbet | h2h  | 2026-11-12T16:22:03Z Azerbaijan:1.29/Draw:5.15/Liechtenstein:14.0 | 2026-11-13T13:20:57Z Azerbaijan:1.21/Draw:6.05/Liechtenstein:19.25 |
| 9529ee7ca79126460eb063f53187f321 | Liechtenstein–Azerbaijan | marathonbet | totals 2.5 | 2026-11-12T16:22:03Z Over:2.15/Under:1.72 | 2026-11-13T13:20:57Z Over:2.12/Under:1.74 |
| 9529ee7ca79126460eb063f53187f321 | Liechtenstein–Azerbaijan | mybookieag | h2h  | 2026-11-12T16:18:51Z Azerbaijan:1.26/Draw:4.9/Liechtenstein:11.25 | 2026-11-13T13:19:14Z Azerbaijan:1.17/Draw:5.6/Liechtenstein:20.25 |
| 9529ee7ca79126460eb063f53187f321 | Liechtenstein–Azerbaijan | mybookieag | totals 2.5 | 2026-11-12T16:18:51Z Over:2.08/Under:1.67 | 2026-11-13T13:19:14Z Over:2.14/Under:1.63 |
| 9529ee7ca79126460eb063f53187f321 | Liechtenstein–Azerbaijan | nordicbet | h2h  | 2026-11-12T16:21:42Z Azerbaijan:1.23/Draw:4.8/Liechtenstein:14.5 | 2026-11-13T13:20:52Z Azerbaijan:1.15/Draw:5.7/Liechtenstein:22.0 |
| 9529ee7ca79126460eb063f53187f321 | Liechtenstein–Azerbaijan | nordicbet | totals 2.5 | 2026-11-12T16:21:42Z Over:2.12/Under:1.62 | 2026-11-13T13:20:52Z Over:2.18/Under:1.62 |
| 9529ee7ca79126460eb063f53187f321 | Liechtenstein–Azerbaijan | onexbet | h2h  | 2026-11-12T16:21:20Z Azerbaijan:1.3/Draw:5.21/Liechtenstein:14.1 | 2026-11-13T13:20:53Z Azerbaijan:1.23/Draw:6.12/Liechtenstein:19.0 |
| 9529ee7ca79126460eb063f53187f321 | Liechtenstein–Azerbaijan | onexbet | totals 2.5 | 2026-11-12T16:21:20Z Over:2.18/Under:1.75 | 2026-11-13T13:20:53Z Over:2.15/Under:1.77 |
| 9529ee7ca79126460eb063f53187f321 | Liechtenstein–Azerbaijan | pinnacle | h2h  | 2026-11-12T16:22:20Z Azerbaijan:1.26/Draw:5.07/Liechtenstein:12.11 | 2026-11-13T13:20:52Z Azerbaijan:1.19/Draw:6.14/Liechtenstein:18.99 |
| 9529ee7ca79126460eb063f53187f321 | Liechtenstein–Azerbaijan | pinnacle | totals 2.25 | 2026-11-12T16:22:20Z Over:1.92/Under:1.88 | 2026-11-13T13:20:52Z Over:1.89/Under:1.93 |
| 9529ee7ca79126460eb063f53187f321 | Liechtenstein–Azerbaijan | pmu_fr | h2h  | 2026-11-12T16:21:41Z Azerbaijan:1.2/Draw:4.7/Liechtenstein:12.0 | 2026-11-13T13:20:51Z Azerbaijan:1.17/Draw:4.9/Liechtenstein:14.0 |
| 9529ee7ca79126460eb063f53187f321 | Liechtenstein–Azerbaijan | pmu_fr | totals 2.5 | 2026-11-12T16:21:41Z Over:1.89/Under:1.64 | 2026-11-13T13:20:51Z Over:1.89/Under:1.64 |
| 9529ee7ca79126460eb063f53187f321 | Liechtenstein–Azerbaijan | sport888 | h2h  | 2026-11-12T16:21:39Z Azerbaijan:1.29/Draw:4.8/Liechtenstein:12.0 | 2026-11-13T13:10:55Z Azerbaijan:1.2/Draw:5.75/Liechtenstein:17.0 |
| 9529ee7ca79126460eb063f53187f321 | Liechtenstein–Azerbaijan | unibet_se | h2h  | 2026-11-12T16:22:00Z Azerbaijan:1.26/Draw:5.0/Liechtenstein:13.0 | 2026-11-13T13:20:29Z Azerbaijan:1.23/Draw:5.3/Liechtenstein:15.0 |
| 9529ee7ca79126460eb063f53187f321 | Liechtenstein–Azerbaijan | unibet_se | totals 2.5 | 2026-11-12T16:22:00Z Over:2.02/Under:1.75 | 2026-11-13T13:20:29Z Over:2.02/Under:1.75 |
| 9529ee7ca79126460eb063f53187f321 | Liechtenstein–Azerbaijan | williamhill | h2h  | 2026-11-12T16:22:19Z Azerbaijan:1.25/Draw:4.6/Liechtenstein:12.0 | 2026-11-13T13:20:30Z Azerbaijan:1.18/Draw:5.5/Liechtenstein:17.0 |
| 9529ee7ca79126460eb063f53187f321 | Liechtenstein–Azerbaijan | williamhill | totals 2.5 | 2026-11-12T16:22:19Z Over:2.05/Under:1.7 | 2026-11-13T13:20:30Z Over:2.1/Under:1.67 |
| 9529ee7ca79126460eb063f53187f321 | Liechtenstein–Azerbaijan | winamax_de | h2h  | 2026-11-12T16:22:20Z Azerbaijan:1.24/Draw:5.5/Liechtenstein:11.5 | 2026-11-13T13:20:55Z Azerbaijan:1.16/Draw:6.25/Liechtenstein:16.0 |
| 9529ee7ca79126460eb063f53187f321 | Liechtenstein–Azerbaijan | winamax_fr | h2h  | 2026-11-12T16:22:18Z Azerbaijan:1.21/Draw:4.9/Liechtenstein:10.0 | 2026-11-13T13:20:53Z Azerbaijan:1.14/Draw:5.6/Liechtenstein:15.0 |
| eef1c96c424e42b66f49b7ec3bef1a5c | Luxembourg–Estonia | betanysports | h2h  | 2026-11-12T16:22:17Z Draw:3.09/Estonia:3.54/Luxembourg:2.11 | 2026-11-13T13:20:52Z Draw:3.03/Estonia:2.98/Luxembourg:2.41 |
| eef1c96c424e42b66f49b7ec3bef1a5c | Luxembourg–Estonia | betanysports | totals 2.0 | 2026-11-12T16:22:17Z Over:1.83/Under:2.01 | 2026-11-13T13:20:52Z Over:1.86/Under:1.96 |
| eef1c96c424e42b66f49b7ec3bef1a5c | Luxembourg–Estonia | betclic_fr | h2h  | 2026-11-12T16:20:36Z Draw:3.0/Estonia:3.42/Luxembourg:2.05 | 2026-11-13T13:18:51Z Draw:2.98/Estonia:2.95/Luxembourg:2.35 |
| eef1c96c424e42b66f49b7ec3bef1a5c | Luxembourg–Estonia | betfair_ex_eu | h2h  | 2026-11-12T16:22:18Z Draw:3.2/Estonia:3.65/Luxembourg:2.34 | 2026-11-13T13:20:52Z Draw:3.1/Estonia:3.15/Luxembourg:2.72 |
| eef1c96c424e42b66f49b7ec3bef1a5c | Luxembourg–Estonia | betsson | h2h  | 2026-11-12T16:22:04Z Draw:3.0/Estonia:3.45/Luxembourg:2.15 | 2026-11-13T13:20:54Z Draw:2.92/Estonia:2.85/Luxembourg:2.55 |
| eef1c96c424e42b66f49b7ec3bef1a5c | Luxembourg–Estonia | betsson | totals 2.5 | 2026-11-12T16:22:04Z Over:2.48/Under:1.52 | 2026-11-13T13:20:54Z Over:2.52/Under:1.49 |
| eef1c96c424e42b66f49b7ec3bef1a5c | Luxembourg–Estonia | marathonbet | h2h  | 2026-11-12T16:22:03Z Draw:3.25/Estonia:3.68/Luxembourg:2.16 | 2026-11-13T13:20:57Z Draw:3.04/Estonia:3.05/Luxembourg:2.59 |
| eef1c96c424e42b66f49b7ec3bef1a5c | Luxembourg–Estonia | marathonbet | totals 2.5 | 2026-11-12T16:22:03Z Over:2.41/Under:1.58 | 2026-11-13T13:20:57Z Over:2.6/Under:1.51 |
| eef1c96c424e42b66f49b7ec3bef1a5c | Luxembourg–Estonia | mybookieag | h2h  | 2026-11-12T16:18:51Z Draw:3.02/Estonia:3.44/Luxembourg:2.14 | 2026-11-13T13:19:14Z Draw:3.0/Estonia:2.91/Luxembourg:2.48 |
| eef1c96c424e42b66f49b7ec3bef1a5c | Luxembourg–Estonia | mybookieag | totals 2.5 | 2026-11-12T16:18:51Z Over:2.41/Under:1.5 | 2026-11-13T13:19:14Z Over:2.46/Under:1.49 |
| eef1c96c424e42b66f49b7ec3bef1a5c | Luxembourg–Estonia | nordicbet | h2h  | 2026-11-12T16:21:42Z Draw:3.0/Estonia:3.45/Luxembourg:2.15 | 2026-11-13T13:20:52Z Draw:2.92/Estonia:2.85/Luxembourg:2.55 |
| eef1c96c424e42b66f49b7ec3bef1a5c | Luxembourg–Estonia | nordicbet | totals 2.5 | 2026-11-12T16:21:42Z Over:2.48/Under:1.52 | 2026-11-13T13:20:52Z Over:2.52/Under:1.49 |
| eef1c96c424e42b66f49b7ec3bef1a5c | Luxembourg–Estonia | onexbet | h2h  | 2026-11-12T16:21:20Z Draw:3.29/Estonia:3.72/Luxembourg:2.18 | 2026-11-13T13:20:53Z Draw:3.08/Estonia:3.08/Luxembourg:2.62 |
| eef1c96c424e42b66f49b7ec3bef1a5c | Luxembourg–Estonia | pinnacle | h2h  | 2026-11-12T16:22:19Z Draw:3.15/Estonia:3.58/Luxembourg:2.19 | 2026-11-13T13:20:52Z Draw:3.06/Estonia:3.01/Luxembourg:2.66 |
| eef1c96c424e42b66f49b7ec3bef1a5c | Luxembourg–Estonia | pinnacle | totals 2.0 | 2026-11-12T16:22:19Z Over:1.85/Under:2.0 | 2026-11-13T13:20:52Z Over:1.95/Under:1.92 |
| eef1c96c424e42b66f49b7ec3bef1a5c | Luxembourg–Estonia | pmu_fr | h2h  | 2026-11-12T16:21:40Z Draw:2.9/Estonia:3.45/Luxembourg:1.95 | 2026-11-13T13:20:51Z Draw:2.8/Estonia:2.75/Luxembourg:2.33 |
| eef1c96c424e42b66f49b7ec3bef1a5c | Luxembourg–Estonia | pmu_fr | totals 2.5 | 2026-11-12T16:21:40Z Over:2.28/Under:1.43 | 2026-11-13T13:20:51Z Over:2.32/Under:1.42 |
| eef1c96c424e42b66f49b7ec3bef1a5c | Luxembourg–Estonia | sport888 | h2h  | 2026-11-12T16:21:39Z Draw:3.1/Estonia:3.5/Luxembourg:2.1 | 2026-11-13T13:10:55Z Draw:2.88/Estonia:2.9/Luxembourg:2.5 |
| eef1c96c424e42b66f49b7ec3bef1a5c | Luxembourg–Estonia | williamhill | h2h  | 2026-11-12T16:22:19Z Draw:3.0/Estonia:3.4/Luxembourg:2.05 | 2026-11-13T13:20:30Z Draw:2.8/Estonia:2.88/Luxembourg:2.5 |
| eef1c96c424e42b66f49b7ec3bef1a5c | Luxembourg–Estonia | williamhill | totals 2.5 | 2026-11-12T16:22:19Z Over:2.3/Under:1.55 | 2026-11-13T13:20:30Z Over:2.45/Under:1.5 |
| eef1c96c424e42b66f49b7ec3bef1a5c | Luxembourg–Estonia | winamax_fr | h2h  | 2026-11-12T16:22:18Z Draw:3.0/Estonia:3.4/Luxembourg:2.05 | 2026-11-13T13:20:53Z Draw:2.85/Estonia:2.75/Luxembourg:2.5 |
| 0010d3b2b15a2b8cb04053b0b1407cc5 | Netherlands–Greece | betanysports | h2h  | 2026-11-12T16:22:17Z Draw:4.47/Greece:5.86/Netherlands:1.55 | 2026-11-13T13:20:52Z Draw:4.45/Greece:5.33/Netherlands:1.59 |
| 0010d3b2b15a2b8cb04053b0b1407cc5 | Netherlands–Greece | betanysports | totals 3.0 | 2026-11-12T16:22:17Z Over:2.0/Under:1.83 | 2026-11-13T13:20:52Z Over:1.84/Under:1.99 |
| 0010d3b2b15a2b8cb04053b0b1407cc5 | Netherlands–Greece | betclic_fr | h2h  | 2026-11-12T16:20:36Z Draw:4.4/Greece:5.25/Netherlands:1.45 | 2026-11-13T13:18:51Z Draw:4.25/Greece:5.0/Netherlands:1.51 |
| 0010d3b2b15a2b8cb04053b0b1407cc5 | Netherlands–Greece | betfair_ex_eu | h2h  | 2026-11-12T16:22:18Z Draw:4.5/Greece:6.0/Netherlands:1.62 | 2026-11-13T13:20:52Z Draw:4.7/Greece:5.8/Netherlands:1.61 |
| 0010d3b2b15a2b8cb04053b0b1407cc5 | Netherlands–Greece | betonlineag | h2h  | 2026-11-12T16:21:40Z Draw:4.3/Greece:5.52/Netherlands:1.57 | 2026-11-13T13:20:53Z Draw:4.4/Greece:5.52/Netherlands:1.6 |
| 0010d3b2b15a2b8cb04053b0b1407cc5 | Netherlands–Greece | betonlineag | totals 3.0 | 2026-11-12T16:21:40Z Over:2.1/Under:1.77 | 2026-11-13T13:20:53Z Over:1.85/Under:1.98 |
| 0010d3b2b15a2b8cb04053b0b1407cc5 | Netherlands–Greece | betsson | h2h  | 2026-11-12T16:22:04Z Draw:4.3/Greece:5.9/Netherlands:1.52 | 2026-11-13T13:20:54Z Draw:4.3/Greece:4.9/Netherlands:1.58 |
| 0010d3b2b15a2b8cb04053b0b1407cc5 | Netherlands–Greece | betsson | totals 2.5 | 2026-11-12T16:22:04Z Over:1.62/Under:2.22 | 2026-11-13T13:20:54Z Over:1.5/Under:2.52 |
| 0010d3b2b15a2b8cb04053b0b1407cc5 | Netherlands–Greece | leovegas_se | h2h  | 2026-11-12T16:22:19Z Draw:4.1/Greece:5.5/Netherlands:1.51 | 2026-11-13T13:20:29Z Draw:4.2/Greece:5.25/Netherlands:1.53 |
| 0010d3b2b15a2b8cb04053b0b1407cc5 | Netherlands–Greece | leovegas_se | totals 2.5 | 2026-11-12T16:22:19Z Over:1.62/Under:2.23 | 2026-11-13T13:20:29Z Over:1.56/Under:2.35 |
| 0010d3b2b15a2b8cb04053b0b1407cc5 | Netherlands–Greece | marathonbet | h2h  | 2026-11-12T16:22:03Z Draw:4.5/Greece:5.95/Netherlands:1.56 | 2026-11-13T13:20:57Z Draw:4.55/Greece:5.35/Netherlands:1.6 |
| 0010d3b2b15a2b8cb04053b0b1407cc5 | Netherlands–Greece | marathonbet | totals 3.5 | 2026-11-12T16:22:03Z Over:2.57/Under:1.52 | 2026-11-13T13:20:57Z Over:2.44/Under:1.57 |
| 0010d3b2b15a2b8cb04053b0b1407cc5 | Netherlands–Greece | matchbook | h2h  | 2026-11-12T16:22:16Z Draw:4.5/Greece:6.0/Netherlands:1.62 | 2026-11-13T13:20:52Z Draw:4.7/Greece:5.8/Netherlands:1.61 |
| 0010d3b2b15a2b8cb04053b0b1407cc5 | Netherlands–Greece | mybookieag | h2h  | 2026-11-12T16:18:51Z Draw:4.2/Greece:5.2/Netherlands:1.52 | 2026-11-13T13:19:14Z Draw:4.2/Greece:4.8/Netherlands:1.57 |
| 0010d3b2b15a2b8cb04053b0b1407cc5 | Netherlands–Greece | nordicbet | h2h  | 2026-11-12T16:21:42Z Draw:4.3/Greece:5.9/Netherlands:1.52 | 2026-11-13T13:20:52Z Draw:4.3/Greece:4.9/Netherlands:1.58 |
| 0010d3b2b15a2b8cb04053b0b1407cc5 | Netherlands–Greece | nordicbet | totals 2.5 | 2026-11-12T16:21:42Z Over:1.62/Under:2.22 | 2026-11-13T13:20:52Z Over:1.5/Under:2.52 |
| 0010d3b2b15a2b8cb04053b0b1407cc5 | Netherlands–Greece | onexbet | h2h  | 2026-11-12T16:21:20Z Draw:4.5/Greece:5.95/Netherlands:1.56 | 2026-11-13T13:20:52Z Draw:4.58/Greece:5.38/Netherlands:1.61 |
| 0010d3b2b15a2b8cb04053b0b1407cc5 | Netherlands–Greece | onexbet | totals 2.5 | 2026-11-12T16:21:20Z Over:1.67/Under:2.32 | 2026-11-13T13:20:52Z Over:1.63/Under:2.43 |
| 0010d3b2b15a2b8cb04053b0b1407cc5 | Netherlands–Greece | pinnacle | h2h  | 2026-11-12T16:22:20Z Draw:4.51/Greece:5.66/Netherlands:1.57 | 2026-11-13T13:20:52Z Draw:4.62/Greece:5.2/Netherlands:1.6 |
| 0010d3b2b15a2b8cb04053b0b1407cc5 | Netherlands–Greece | pinnacle | totals 3.0 | 2026-11-12T16:22:20Z Over:2.1/Under:1.81 | 2026-11-13T13:20:52Z Over:1.88/Under:2.0 |
| 0010d3b2b15a2b8cb04053b0b1407cc5 | Netherlands–Greece | pmu_fr | h2h  | 2026-11-12T16:21:40Z Draw:3.9/Greece:5.2/Netherlands:1.48 | 2026-11-13T13:20:51Z Draw:3.95/Greece:4.9/Netherlands:1.49 |
| 0010d3b2b15a2b8cb04053b0b1407cc5 | Netherlands–Greece | pmu_fr | totals 2.5 | 2026-11-12T16:21:40Z Over:1.51/Under:2.1 | 2026-11-13T13:20:51Z Over:1.47/Under:2.2 |
| 0010d3b2b15a2b8cb04053b0b1407cc5 | Netherlands–Greece | sport888 | h2h  | 2026-11-12T16:21:39Z Draw:4.0/Greece:5.5/Netherlands:1.53 | 2026-11-13T13:10:55Z Draw:4.0/Greece:4.8/Netherlands:1.57 |
| 0010d3b2b15a2b8cb04053b0b1407cc5 | Netherlands–Greece | unibet_se | h2h  | 2026-11-12T16:22:00Z Draw:4.4/Greece:6.0/Netherlands:1.56 | 2026-11-13T13:20:29Z Draw:4.5/Greece:5.75/Netherlands:1.56 |
| 0010d3b2b15a2b8cb04053b0b1407cc5 | Netherlands–Greece | unibet_se | totals 2.5 | 2026-11-12T16:22:00Z Over:1.62/Under:2.23 | 2026-11-13T13:20:29Z Over:1.56/Under:2.35 |
| 0010d3b2b15a2b8cb04053b0b1407cc5 | Netherlands–Greece | williamhill | h2h  | 2026-11-12T16:22:19Z Draw:4.0/Greece:5.5/Netherlands:1.53 | 2026-11-13T13:20:30Z Draw:4.0/Greece:4.8/Netherlands:1.57 |
| 0010d3b2b15a2b8cb04053b0b1407cc5 | Netherlands–Greece | williamhill | totals 2.5 | 2026-11-12T16:22:19Z Over:1.6/Under:2.25 | 2026-11-13T13:20:30Z Over:1.5/Under:2.5 |
| 0010d3b2b15a2b8cb04053b0b1407cc5 | Netherlands–Greece | winamax_de | h2h  | 2026-11-12T16:22:20Z Draw:4.4/Greece:5.1/Netherlands:1.52 | 2026-11-13T13:20:55Z Draw:4.5/Greece:4.7/Netherlands:1.56 |
| 0010d3b2b15a2b8cb04053b0b1407cc5 | Netherlands–Greece | winamax_fr | h2h  | 2026-11-12T16:22:18Z Draw:4.4/Greece:5.1/Netherlands:1.45 | 2026-11-13T13:20:53Z Draw:4.4/Greece:4.75/Netherlands:1.5 |
| 199940cd0d3a9c7ad93be4063cb2df93 | Scotland–North Macedonia | betanysports | h2h  | 2026-11-12T16:22:17Z Draw:6.65/North Macedonia:15.0/Scotland:1.19 | 2026-11-13T13:20:52Z Draw:7.05/North Macedonia:14.8/Scotland:1.18 |
| 199940cd0d3a9c7ad93be4063cb2df93 | Scotland–North Macedonia | betclic_fr | h2h  | 2026-11-12T16:20:36Z Draw:6.1/North Macedonia:13.25/Scotland:1.15 | 2026-11-13T13:18:51Z Draw:6.5/North Macedonia:14.0/Scotland:1.14 |
| 199940cd0d3a9c7ad93be4063cb2df93 | Scotland–North Macedonia | betfair_ex_eu | h2h  | 2026-11-12T16:22:18Z Draw:7.4/North Macedonia:18.5/Scotland:1.21 | 2026-11-13T13:20:52Z Draw:7.8/North Macedonia:20.0/Scotland:1.21 |
| 199940cd0d3a9c7ad93be4063cb2df93 | Scotland–North Macedonia | betsson | h2h  | 2026-11-12T16:22:04Z Draw:6.6/North Macedonia:18.0/Scotland:1.18 | 2026-11-13T13:20:54Z Draw:7.1/North Macedonia:18.0/Scotland:1.16 |
| 199940cd0d3a9c7ad93be4063cb2df93 | Scotland–North Macedonia | betsson | totals 2.5 | 2026-11-12T16:22:04Z Over:1.65/Under:2.18 | 2026-11-13T13:20:54Z Over:1.52/Under:2.42 |
| 199940cd0d3a9c7ad93be4063cb2df93 | Scotland–North Macedonia | leovegas_se | h2h  | 2026-11-12T16:22:19Z Draw:6.25/North Macedonia:15.0/Scotland:1.18 | 2026-11-13T13:20:29Z Draw:6.75/North Macedonia:16.0/Scotland:1.16 |
| 199940cd0d3a9c7ad93be4063cb2df93 | Scotland–North Macedonia | leovegas_se | totals 2.5 | 2026-11-12T16:22:19Z Over:1.7/Under:2.1 | 2026-11-13T13:20:29Z Over:1.63/Under:2.23 |
| 199940cd0d3a9c7ad93be4063cb2df93 | Scotland–North Macedonia | marathonbet | h2h  | 2026-11-12T16:22:03Z Draw:6.4/North Macedonia:16.5/Scotland:1.21 | 2026-11-13T13:20:57Z Draw:7.1/North Macedonia:17.5/Scotland:1.18 |
| 199940cd0d3a9c7ad93be4063cb2df93 | Scotland–North Macedonia | marathonbet | totals 2.5 | 2026-11-12T16:22:03Z Over:1.75/Under:2.1 | 2026-11-13T13:20:57Z Over:1.62/Under:2.34 |
| 199940cd0d3a9c7ad93be4063cb2df93 | Scotland–North Macedonia | mybookieag | h2h  | 2026-11-12T16:18:51Z Draw:6.1/North Macedonia:13.5/Scotland:1.17 | 2026-11-13T13:19:14Z Draw:6.6/North Macedonia:14.75/Scotland:1.16 |
| 199940cd0d3a9c7ad93be4063cb2df93 | Scotland–North Macedonia | mybookieag | totals 2.5 | 2026-11-12T16:18:51Z Over:1.65/Under:2.12 | 2026-11-13T13:19:14Z Over:1.57/Under:2.24 |
| 199940cd0d3a9c7ad93be4063cb2df93 | Scotland–North Macedonia | nordicbet | h2h  | 2026-11-12T16:21:42Z Draw:6.6/North Macedonia:18.0/Scotland:1.18 | 2026-11-13T13:20:52Z Draw:7.1/North Macedonia:18.0/Scotland:1.16 |
| 199940cd0d3a9c7ad93be4063cb2df93 | Scotland–North Macedonia | nordicbet | totals 2.5 | 2026-11-12T16:21:42Z Over:1.65/Under:2.18 | 2026-11-13T13:20:52Z Over:1.52/Under:2.42 |
| 199940cd0d3a9c7ad93be4063cb2df93 | Scotland–North Macedonia | onexbet | h2h  | 2026-11-12T16:21:20Z Draw:6.47/North Macedonia:16.5/Scotland:1.22 | 2026-11-13T13:20:52Z Draw:7.18/North Macedonia:17.5/Scotland:1.2 |
| 199940cd0d3a9c7ad93be4063cb2df93 | Scotland–North Macedonia | onexbet | totals 2.5 | 2026-11-12T16:21:20Z Over:1.78/Under:2.13 | 2026-11-13T13:20:52Z Over:1.64/Under:2.38 |
| 199940cd0d3a9c7ad93be4063cb2df93 | Scotland–North Macedonia | pinnacle | h2h  | 2026-11-12T16:22:20Z Draw:6.8/North Macedonia:15.73/Scotland:1.19 | 2026-11-13T13:20:52Z Draw:7.92/North Macedonia:17.13/Scotland:1.18 |
| 199940cd0d3a9c7ad93be4063cb2df93 | Scotland–North Macedonia | pmu_fr | h2h  | 2026-11-12T16:21:41Z Draw:5.8/North Macedonia:14.0/Scotland:1.15 | 2026-11-13T13:20:51Z Draw:6.25/North Macedonia:15.0/Scotland:1.13 |
| 199940cd0d3a9c7ad93be4063cb2df93 | Scotland–North Macedonia | pmu_fr | totals 2.5 | 2026-11-12T16:21:41Z Over:1.6/Under:1.96 | 2026-11-13T13:20:51Z Over:1.51/Under:2.08 |
| 199940cd0d3a9c7ad93be4063cb2df93 | Scotland–North Macedonia | sport888 | h2h  | 2026-11-12T16:21:39Z Draw:6.0/North Macedonia:13.0/Scotland:1.2 | 2026-11-13T13:10:55Z Draw:6.5/North Macedonia:15.0/Scotland:1.17 |
| 199940cd0d3a9c7ad93be4063cb2df93 | Scotland–North Macedonia | unibet_se | h2h  | 2026-11-12T16:22:00Z Draw:6.75/North Macedonia:18.0/Scotland:1.21 | 2026-11-13T13:20:29Z Draw:7.5/North Macedonia:20.0/Scotland:1.18 |
| 199940cd0d3a9c7ad93be4063cb2df93 | Scotland–North Macedonia | unibet_se | totals 2.5 | 2026-11-12T16:22:00Z Over:1.7/Under:2.1 | 2026-11-13T13:20:29Z Over:1.63/Under:2.23 |
| 199940cd0d3a9c7ad93be4063cb2df93 | Scotland–North Macedonia | williamhill | h2h  | 2026-11-12T16:22:19Z Draw:6.0/North Macedonia:13.0/Scotland:1.2 | 2026-11-13T13:20:30Z Draw:6.5/North Macedonia:15.0/Scotland:1.17 |
| 199940cd0d3a9c7ad93be4063cb2df93 | Scotland–North Macedonia | williamhill | totals 2.5 | 2026-11-12T16:22:19Z Over:1.7/Under:2.05 | 2026-11-13T13:20:30Z Over:1.53/Under:2.4 |
| 199940cd0d3a9c7ad93be4063cb2df93 | Scotland–North Macedonia | winamax_de | h2h  | 2026-11-12T16:22:20Z Draw:7.0/North Macedonia:13.5/Scotland:1.16 | 2026-11-13T13:20:55Z Draw:7.25/North Macedonia:14.0/Scotland:1.15 |
| 199940cd0d3a9c7ad93be4063cb2df93 | Scotland–North Macedonia | winamax_fr | h2h  | 2026-11-12T16:22:18Z Draw:6.0/North Macedonia:12.0/Scotland:1.14 | 2026-11-13T13:20:53Z Draw:7.5/North Macedonia:13.0/Scotland:1.12 |
| d0ee3d2f44cf592797f6ecae8de62edd | Serbia–Germany | betanysports | h2h  | 2026-11-12T16:22:17Z Draw:6.62/Germany:1.27/Serbia:9.85 | 2026-11-13T13:20:52Z Draw:7.25/Germany:1.22/Serbia:11.74 |
| d0ee3d2f44cf592797f6ecae8de62edd | Serbia–Germany | betanysports | totals 3.25 | 2026-11-12T16:22:17Z Over:1.85/Under:1.98 | 2026-11-13T13:20:52Z Over:1.91/Under:1.91 |
| d0ee3d2f44cf592797f6ecae8de62edd | Serbia–Germany | betclic_fr | h2h  | 2026-11-12T16:20:36Z Draw:6.5/Germany:1.19/Serbia:8.5 | 2026-11-13T13:18:51Z Draw:6.0/Germany:1.21/Serbia:9.5 |
| d0ee3d2f44cf592797f6ecae8de62edd | Serbia–Germany | betfair_ex_eu | h2h  | 2026-11-12T16:22:18Z Draw:7.0/Germany:1.29/Serbia:10.5 | 2026-11-13T13:20:52Z Draw:6.8/Germany:1.29/Serbia:12.0 |
| d0ee3d2f44cf592797f6ecae8de62edd | Serbia–Germany | betonlineag | h2h  | 2026-11-12T16:21:40Z Draw:6.38/Germany:1.27/Serbia:9.25 | 2026-11-13T13:20:53Z Draw:6.62/Germany:1.27/Serbia:10.15 |
| d0ee3d2f44cf592797f6ecae8de62edd | Serbia–Germany | betonlineag | totals 3.5 | 2026-11-12T16:21:40Z Over:2.08/Under:1.78 | 2026-11-13T13:20:53Z Over:2.08/Under:1.78 |
| d0ee3d2f44cf592797f6ecae8de62edd | Serbia–Germany | betsson | h2h  | 2026-11-12T16:22:04Z Draw:6.1/Germany:1.27/Serbia:9.7 | 2026-11-13T13:20:54Z Draw:6.1/Germany:1.23/Serbia:11.5 |
| d0ee3d2f44cf592797f6ecae8de62edd | Serbia–Germany | betsson | totals 2.5 | 2026-11-12T16:22:04Z Over:1.39/Under:2.95 | 2026-11-13T13:20:54Z Over:1.41/Under:2.85 |
| d0ee3d2f44cf592797f6ecae8de62edd | Serbia–Germany | leovegas_se | h2h  | 2026-11-12T16:22:19Z Draw:5.6/Germany:1.27/Serbia:9.0 | 2026-11-13T13:20:29Z Draw:5.75/Germany:1.26/Serbia:9.0 |
| d0ee3d2f44cf592797f6ecae8de62edd | Serbia–Germany | leovegas_se | totals 3.5 | 2026-11-12T16:22:19Z Over:1.93/Under:1.82 | 2026-11-13T13:20:29Z Over:2.0/Under:1.78 |
| d0ee3d2f44cf592797f6ecae8de62edd | Serbia–Germany | marathonbet | h2h  | 2026-11-12T16:22:03Z Draw:6.2/Germany:1.3/Serbia:9.9 | 2026-11-13T13:20:57Z Draw:6.9/Germany:1.25/Serbia:11.5 |
| d0ee3d2f44cf592797f6ecae8de62edd | Serbia–Germany | marathonbet | totals 3.5 | 2026-11-12T16:22:03Z Over:2.03/Under:1.81 | 2026-11-13T13:20:57Z Over:2.08/Under:1.77 |
| d0ee3d2f44cf592797f6ecae8de62edd | Serbia–Germany | matchbook | h2h  | 2026-11-12T16:22:16Z Draw:7.0/Germany:1.29/Serbia:10.5 | 2026-11-13T13:20:52Z Draw:6.8/Germany:1.29/Serbia:12.0 |
| d0ee3d2f44cf592797f6ecae8de62edd | Serbia–Germany | matchbook | totals 3.5 | 2026-11-12T16:22:16Z Over:2.12/Under:1.84 | 2026-11-13T13:20:52Z Over:2.14/Under:1.86 |
| d0ee3d2f44cf592797f6ecae8de62edd | Serbia–Germany | mybookieag | h2h  | 2026-11-12T16:18:51Z Draw:5.7/Germany:1.26/Serbia:8.3 | 2026-11-13T13:19:14Z Draw:5.9/Germany:1.26/Serbia:9.0 |
| d0ee3d2f44cf592797f6ecae8de62edd | Serbia–Germany | mybookieag | totals 3.5 | 2026-11-12T16:18:51Z Over:2.0/Under:1.72 | 2026-11-13T13:19:14Z Over:2.02/Under:1.71 |
| d0ee3d2f44cf592797f6ecae8de62edd | Serbia–Germany | nordicbet | h2h  | 2026-11-12T16:21:42Z Draw:6.1/Germany:1.27/Serbia:9.7 | 2026-11-13T13:20:52Z Draw:6.1/Germany:1.23/Serbia:11.5 |
| d0ee3d2f44cf592797f6ecae8de62edd | Serbia–Germany | nordicbet | totals 2.5 | 2026-11-12T16:21:42Z Over:1.39/Under:2.95 | 2026-11-13T13:20:52Z Over:1.41/Under:2.85 |
| d0ee3d2f44cf592797f6ecae8de62edd | Serbia–Germany | onexbet | h2h  | 2026-11-12T16:21:20Z Draw:6.2/Germany:1.3/Serbia:9.9 | 2026-11-13T13:20:52Z Draw:6.53/Germany:1.29/Serbia:10.5 |
| d0ee3d2f44cf592797f6ecae8de62edd | Serbia–Germany | onexbet | totals 3.5 | 2026-11-12T16:21:20Z Over:2.06/Under:1.83 | 2026-11-13T13:20:52Z Over:2.17/Under:1.77 |
| d0ee3d2f44cf592797f6ecae8de62edd | Serbia–Germany | pinnacle | h2h  | 2026-11-12T16:22:20Z Draw:6.59/Germany:1.28/Serbia:9.81 | 2026-11-13T13:20:52Z Draw:6.8/Germany:1.26/Serbia:10.32 |
| d0ee3d2f44cf592797f6ecae8de62edd | Serbia–Germany | pinnacle | totals 3.25 | 2026-11-12T16:22:20Z Over:1.88/Under:2.01 | 2026-11-13T13:20:52Z Over:1.89/Under:1.98 |
| d0ee3d2f44cf592797f6ecae8de62edd | Serbia–Germany | pmu_fr | h2h  | 2026-11-12T16:21:40Z Draw:5.3/Germany:1.24/Serbia:8.5 | 2026-11-13T13:20:51Z Draw:5.3/Germany:1.23/Serbia:8.5 |
| d0ee3d2f44cf592797f6ecae8de62edd | Serbia–Germany | pmu_fr | totals 3.5 | 2026-11-12T16:21:40Z Over:1.81/Under:1.71 | 2026-11-13T13:20:51Z Over:1.87/Under:1.66 |
| d0ee3d2f44cf592797f6ecae8de62edd | Serbia–Germany | sport888 | h2h  | 2026-11-12T16:21:39Z Draw:5.75/Germany:1.25/Serbia:8.5 | 2026-11-13T13:10:55Z Draw:6.0/Germany:1.25/Serbia:9.5 |
| d0ee3d2f44cf592797f6ecae8de62edd | Serbia–Germany | unibet_se | h2h  | 2026-11-12T16:22:00Z Draw:6.1/Germany:1.29/Serbia:10.0 | 2026-11-13T13:20:29Z Draw:6.25/Germany:1.28/Serbia:10.5 |
| d0ee3d2f44cf592797f6ecae8de62edd | Serbia–Germany | unibet_se | totals 3.5 | 2026-11-12T16:22:00Z Over:1.93/Under:1.82 | 2026-11-13T13:20:29Z Over:2.0/Under:1.78 |
| d0ee3d2f44cf592797f6ecae8de62edd | Serbia–Germany | williamhill | h2h  | 2026-11-12T16:22:19Z Draw:5.8/Germany:1.25/Serbia:8.5 | 2026-11-13T13:20:30Z Draw:6.0/Germany:1.25/Serbia:9.5 |
| d0ee3d2f44cf592797f6ecae8de62edd | Serbia–Germany | williamhill | totals 2.5 | 2026-11-12T16:22:19Z Over:1.4/Under:2.8 | 2026-11-13T13:20:30Z Over:1.36/Under:2.8 |
| d0ee3d2f44cf592797f6ecae8de62edd | Serbia–Germany | winamax_de | h2h  | 2026-11-12T16:22:20Z Draw:6.5/Germany:1.24/Serbia:8.5 | 2026-11-13T13:20:55Z Draw:6.75/Germany:1.23/Serbia:9.0 |
| d0ee3d2f44cf592797f6ecae8de62edd | Serbia–Germany | winamax_fr | h2h  | 2026-11-12T16:22:18Z Draw:6.5/Germany:1.2/Serbia:8.5 | 2026-11-13T13:20:53Z Draw:6.75/Germany:1.18/Serbia:8.5 |
| a2b1b42a452df659cc5d0d242d8f98be | Slovakia–Faroe Islands | betanysports | h2h  | 2026-11-12T16:22:17Z Draw:4.56/Faroe Islands:8.27/Slovakia:1.35 | 2026-11-13T13:20:51Z Draw:4.62/Faroe Islands:9.02/Slovakia:1.33 |
| a2b1b42a452df659cc5d0d242d8f98be | Slovakia–Faroe Islands | betanysports | totals 2.5 | 2026-11-12T16:22:17Z Over:1.81/Under:2.04 | 2026-11-13T13:20:51Z Over:1.98/Under:1.85 |
| a2b1b42a452df659cc5d0d242d8f98be | Slovakia–Faroe Islands | betclic_fr | h2h  | 2026-11-12T16:20:36Z Draw:4.65/Faroe Islands:8.0/Slovakia:1.3 | 2026-11-13T13:18:51Z Draw:4.7/Faroe Islands:9.0/Slovakia:1.29 |
| a2b1b42a452df659cc5d0d242d8f98be | Slovakia–Faroe Islands | betfair_ex_eu | h2h  | 2026-11-12T16:22:18Z Draw:5.1/Faroe Islands:10.0/Slovakia:1.38 | 2026-11-13T13:20:52Z Draw:5.1/Faroe Islands:11.0/Slovakia:1.39 |
| a2b1b42a452df659cc5d0d242d8f98be | Slovakia–Faroe Islands | betsson | h2h  | 2026-11-12T16:22:04Z Draw:4.55/Faroe Islands:8.8/Slovakia:1.34 | 2026-11-13T13:20:54Z Draw:4.55/Faroe Islands:9.3/Slovakia:1.33 |
| a2b1b42a452df659cc5d0d242d8f98be | Slovakia–Faroe Islands | betsson | totals 2.5 | 2026-11-12T16:22:04Z Over:1.82/Under:1.92 | 2026-11-13T13:20:54Z Over:1.85/Under:1.88 |
| a2b1b42a452df659cc5d0d242d8f98be | Slovakia–Faroe Islands | leovegas_se | h2h  | 2026-11-12T16:22:19Z Draw:5.0/Faroe Islands:10.0/Slovakia:1.32 | 2026-11-13T13:20:29Z Draw:4.9/Faroe Islands:10.0/Slovakia:1.33 |
| a2b1b42a452df659cc5d0d242d8f98be | Slovakia–Faroe Islands | leovegas_se | totals 2.5 | 2026-11-12T16:22:19Z Over:1.77/Under:2.0 | 2026-11-13T13:20:29Z Over:1.83/Under:1.92 |
| a2b1b42a452df659cc5d0d242d8f98be | Slovakia–Faroe Islands | marathonbet | h2h  | 2026-11-12T16:22:03Z Draw:5.05/Faroe Islands:9.6/Slovakia:1.35 | 2026-11-13T13:20:57Z Draw:4.85/Faroe Islands:9.3/Slovakia:1.37 |
| a2b1b42a452df659cc5d0d242d8f98be | Slovakia–Faroe Islands | marathonbet | totals 2.5 | 2026-11-12T16:22:03Z Over:1.82/Under:2.01 | 2026-11-13T13:20:57Z Over:1.9/Under:1.92 |
| a2b1b42a452df659cc5d0d242d8f98be | Slovakia–Faroe Islands | mybookieag | h2h  | 2026-11-12T16:18:51Z Draw:4.6/Faroe Islands:7.9/Slovakia:1.34 | 2026-11-13T13:19:14Z Draw:4.7/Faroe Islands:8.7/Slovakia:1.33 |
| a2b1b42a452df659cc5d0d242d8f98be | Slovakia–Faroe Islands | mybookieag | totals 2.5 | 2026-11-12T16:18:51Z Over:1.79/Under:1.92 | 2026-11-13T13:19:14Z Over:1.88/Under:1.83 |
| a2b1b42a452df659cc5d0d242d8f98be | Slovakia–Faroe Islands | nordicbet | h2h  | 2026-11-12T16:21:42Z Draw:4.55/Faroe Islands:8.8/Slovakia:1.34 | 2026-11-13T13:20:52Z Draw:4.55/Faroe Islands:9.3/Slovakia:1.33 |
| a2b1b42a452df659cc5d0d242d8f98be | Slovakia–Faroe Islands | nordicbet | totals 2.5 | 2026-11-12T16:21:42Z Over:1.82/Under:1.92 | 2026-11-13T13:20:52Z Over:1.85/Under:1.88 |
| a2b1b42a452df659cc5d0d242d8f98be | Slovakia–Faroe Islands | onexbet | h2h  | 2026-11-12T16:21:20Z Draw:5.1/Faroe Islands:9.7/Slovakia:1.37 | 2026-11-13T13:20:53Z Draw:4.91/Faroe Islands:9.4/Slovakia:1.39 |
| a2b1b42a452df659cc5d0d242d8f98be | Slovakia–Faroe Islands | onexbet | totals 2.5 | 2026-11-12T16:21:20Z Over:1.85/Under:2.04 | 2026-11-13T13:20:53Z Over:1.93/Under:1.95 |
| a2b1b42a452df659cc5d0d242d8f98be | Slovakia–Faroe Islands | pinnacle | h2h  | 2026-11-12T16:22:20Z Draw:4.69/Faroe Islands:8.97/Slovakia:1.36 | 2026-11-13T13:20:52Z Draw:4.9/Faroe Islands:9.42/Slovakia:1.37 |
| a2b1b42a452df659cc5d0d242d8f98be | Slovakia–Faroe Islands | pinnacle | totals 2.5 | 2026-11-12T16:22:20Z Over:1.85/Under:1.98 | 2026-11-13T13:20:52Z Over:1.93/Under:1.94 |
| a2b1b42a452df659cc5d0d242d8f98be | Slovakia–Faroe Islands | pmu_fr | h2h  | 2026-11-12T16:21:41Z Draw:4.6/Faroe Islands:8.5/Slovakia:1.24 | 2026-11-13T13:20:51Z Draw:4.4/Faroe Islands:8.5/Slovakia:1.26 |
| a2b1b42a452df659cc5d0d242d8f98be | Slovakia–Faroe Islands | pmu_fr | totals 2.5 | 2026-11-12T16:21:41Z Over:1.66/Under:1.88 | 2026-11-13T13:20:51Z Over:1.72/Under:1.81 |
| a2b1b42a452df659cc5d0d242d8f98be | Slovakia–Faroe Islands | sport888 | h2h  | 2026-11-12T16:21:39Z Draw:4.6/Faroe Islands:8.5/Slovakia:1.33 | 2026-11-13T13:10:55Z Draw:4.5/Faroe Islands:8.5/Slovakia:1.36 |
| a2b1b42a452df659cc5d0d242d8f98be | Slovakia–Faroe Islands | unibet_se | h2h  | 2026-11-12T16:22:00Z Draw:5.0/Faroe Islands:10.0/Slovakia:1.32 | 2026-11-13T13:20:29Z Draw:4.9/Faroe Islands:10.0/Slovakia:1.33 |
| a2b1b42a452df659cc5d0d242d8f98be | Slovakia–Faroe Islands | unibet_se | totals 2.5 | 2026-11-12T16:22:00Z Over:1.77/Under:2.0 | 2026-11-13T13:20:29Z Over:1.83/Under:1.92 |
| a2b1b42a452df659cc5d0d242d8f98be | Slovakia–Faroe Islands | williamhill | h2h  | 2026-11-12T16:22:19Z Draw:4.5/Faroe Islands:8.5/Slovakia:1.33 | 2026-11-13T13:20:30Z Draw:4.4/Faroe Islands:8.0/Slovakia:1.35 |
| a2b1b42a452df659cc5d0d242d8f98be | Slovakia–Faroe Islands | williamhill | totals 2.5 | 2026-11-12T16:22:19Z Over:1.73/Under:2.0 | 2026-11-13T13:20:30Z Over:1.83/Under:1.91 |
| a2b1b42a452df659cc5d0d242d8f98be | Slovakia–Faroe Islands | winamax_de | h2h  | 2026-11-12T16:22:20Z Draw:5.0/Faroe Islands:8.0/Slovakia:1.33 | 2026-11-13T13:20:55Z Draw:5.0/Faroe Islands:8.0/Slovakia:1.33 |
| a2b1b42a452df659cc5d0d242d8f98be | Slovakia–Faroe Islands | winamax_fr | h2h  | 2026-11-12T16:22:18Z Draw:4.6/Faroe Islands:7.5/Slovakia:1.29 | 2026-11-13T13:20:53Z Draw:4.75/Faroe Islands:7.5/Slovakia:1.3 |
| af4d45ae5e37dc2a0e146d2a9e9a926d | Slovenia–Switzerland | betanysports | h2h  | 2026-11-12T16:22:17Z Draw:3.4/Slovenia:5.45/Switzerland:1.7 | 2026-11-13T13:20:52Z Draw:3.3/Slovenia:6.0/Switzerland:1.67 |
| af4d45ae5e37dc2a0e146d2a9e9a926d | Slovenia–Switzerland | betclic_fr | h2h  | 2026-11-12T16:20:36Z Draw:3.42/Slovenia:5.25/Switzerland:1.6 | 2026-11-13T13:18:51Z Draw:3.28/Slovenia:5.75/Switzerland:1.61 |
| af4d45ae5e37dc2a0e146d2a9e9a926d | Slovenia–Switzerland | betfair_ex_eu | h2h  | 2026-11-12T16:22:18Z Draw:3.85/Slovenia:6.0/Switzerland:1.73 | 2026-11-13T13:20:52Z Draw:3.55/Slovenia:6.6/Switzerland:1.75 |
| af4d45ae5e37dc2a0e146d2a9e9a926d | Slovenia–Switzerland | betsson | h2h  | 2026-11-12T16:22:04Z Draw:3.45/Slovenia:5.4/Switzerland:1.7 | 2026-11-13T13:20:54Z Draw:3.4/Slovenia:5.9/Switzerland:1.68 |
| af4d45ae5e37dc2a0e146d2a9e9a926d | Slovenia–Switzerland | betsson | totals 2.5 | 2026-11-12T16:22:04Z Over:2.22/Under:1.65 | 2026-11-13T13:20:54Z Over:2.62/Under:1.47 |
| af4d45ae5e37dc2a0e146d2a9e9a926d | Slovenia–Switzerland | leovegas_se | h2h  | 2026-11-12T16:22:19Z Draw:3.55/Slovenia:5.5/Switzerland:1.62 | 2026-11-13T13:20:29Z Draw:3.3/Slovenia:5.5/Switzerland:1.67 |
| af4d45ae5e37dc2a0e146d2a9e9a926d | Slovenia–Switzerland | marathonbet | h2h  | 2026-11-12T16:22:03Z Draw:3.64/Slovenia:5.65/Switzerland:1.69 | 2026-11-13T13:20:57Z Draw:3.4/Slovenia:5.9/Switzerland:1.73 |
| af4d45ae5e37dc2a0e146d2a9e9a926d | Slovenia–Switzerland | marathonbet | totals 2.5 | 2026-11-12T16:22:03Z Over:2.18/Under:1.7 | 2026-11-13T13:20:57Z Over:2.57/Under:1.52 |
| af4d45ae5e37dc2a0e146d2a9e9a926d | Slovenia–Switzerland | mybookieag | h2h  | 2026-11-12T16:18:51Z Draw:3.46/Slovenia:5.2/Switzerland:1.65 | 2026-11-13T13:19:14Z Draw:3.28/Slovenia:5.5/Switzerland:1.68 |
| af4d45ae5e37dc2a0e146d2a9e9a926d | Slovenia–Switzerland | nordicbet | h2h  | 2026-11-12T16:21:42Z Draw:3.45/Slovenia:5.4/Switzerland:1.7 | 2026-11-13T13:20:52Z Draw:3.4/Slovenia:5.9/Switzerland:1.68 |
| af4d45ae5e37dc2a0e146d2a9e9a926d | Slovenia–Switzerland | nordicbet | totals 2.5 | 2026-11-12T16:21:42Z Over:2.22/Under:1.65 | 2026-11-13T13:20:52Z Over:2.62/Under:1.47 |
| af4d45ae5e37dc2a0e146d2a9e9a926d | Slovenia–Switzerland | onexbet | h2h  | 2026-11-12T16:21:20Z Draw:3.68/Slovenia:5.71/Switzerland:1.71 | 2026-11-13T13:20:52Z Draw:3.44/Slovenia:5.96/Switzerland:1.75 |
| af4d45ae5e37dc2a0e146d2a9e9a926d | Slovenia–Switzerland | onexbet | totals 2.5 | 2026-11-12T16:21:20Z Over:2.21/Under:1.73 | 2026-11-13T13:20:52Z Over:2.61/Under:1.54 |
| af4d45ae5e37dc2a0e146d2a9e9a926d | Slovenia–Switzerland | pinnacle | h2h  | 2026-11-12T16:22:20Z Draw:3.48/Slovenia:5.54/Switzerland:1.71 | 2026-11-13T13:20:52Z Draw:3.44/Slovenia:6.41/Switzerland:1.7 |
| af4d45ae5e37dc2a0e146d2a9e9a926d | Slovenia–Switzerland | pmu_fr | h2h  | 2026-11-12T16:21:41Z Draw:3.35/Slovenia:5.1/Switzerland:1.57 | 2026-11-13T13:20:51Z Draw:3.15/Slovenia:5.2/Switzerland:1.64 |
| af4d45ae5e37dc2a0e146d2a9e9a926d | Slovenia–Switzerland | sport888 | h2h  | 2026-11-12T16:21:39Z Draw:3.4/Slovenia:5.0/Switzerland:1.67 | 2026-11-13T13:10:55Z Draw:3.2/Slovenia:5.5/Switzerland:1.7 |
| af4d45ae5e37dc2a0e146d2a9e9a926d | Slovenia–Switzerland | unibet_se | h2h  | 2026-11-12T16:22:00Z Draw:3.75/Slovenia:6.0/Switzerland:1.68 | 2026-11-13T13:20:29Z Draw:3.5/Slovenia:6.0/Switzerland:1.73 |
| af4d45ae5e37dc2a0e146d2a9e9a926d | Slovenia–Switzerland | williamhill | h2h  | 2026-11-12T16:22:19Z Draw:3.4/Slovenia:5.0/Switzerland:1.67 | 2026-11-13T13:20:30Z Draw:3.1/Slovenia:5.5/Switzerland:1.67 |
| af4d45ae5e37dc2a0e146d2a9e9a926d | Slovenia–Switzerland | williamhill | totals 2.5 | 2026-11-12T16:22:19Z Over:2.15/Under:1.65 | 2026-11-13T13:20:30Z Over:2.5/Under:1.44 |
| af4d45ae5e37dc2a0e146d2a9e9a926d | Slovenia–Switzerland | winamax_de | h2h  | 2026-11-12T16:22:20Z Draw:3.6/Slovenia:5.1/Switzerland:1.66 | 2026-11-13T13:20:55Z Draw:3.4/Slovenia:5.6/Switzerland:1.64 |
| af4d45ae5e37dc2a0e146d2a9e9a926d | Slovenia–Switzerland | winamax_fr | h2h  | 2026-11-12T16:22:18Z Draw:3.4/Slovenia:4.8/Switzerland:1.6 | 2026-11-13T13:20:53Z Draw:3.4/Slovenia:5.5/Switzerland:1.6 |

没有采集到的盘口保持缺项；不同机构、不同线不合并。赔率市场自身去水后是市场隐含概率，不是模型概率。
