# Nations League context A — five fixtures

近期比赛/API过程证据截止：2026-11-13 13:24 UTC（北京时间21:24）；人员网页检索补充至13:30 UTC（北京时间21:30）。比赛均未开赛。来源赛事 identity / lastFiveGames：ESPN public API summary，由 schedule agent 于13:20 UTC保存，文件与SHA在 `../schedule/summary_index.json`。近期比赛过程补抓6场 ESPN event summaries，原文及请求/抓取时点、SHA见 `raw/`。仅按成年国家队赛事统计。主窗口采用本届2026-27欧国联League Phase近4场；ESPN lastFiveGames另外列出的世界杯/友谊赛作为补充，不合并进主窗口。欧国联组赛比分按90分钟赛事比分使用；ESPN lastFiveGames本身不提供period字段。世界杯淘汰赛比分时段未独立核实，绝不当作90分钟数据。ESPN event-summary接口实际返回总射门、射正等字段，但六场中均无 expected goals/xG 或 xGA 统计项；本报告不把射门数代称xG。该接口的rosters没有球员名单，联赛news亦不具本场针对性。

## 各场近期窗口及最近一战过程

### Netherlands–Greece（event 401861159；kickoff 2026-11-13T19:45Z UTC；场地 Johan Cruijff Arena）

**Netherlands** ESPN ID `449`；ESPN所列近5场跨赛事补充W-D-L=2-3-0。窗口（新→旧）：
本届欧国联League Phase主窗口（4场）：W-D-L=2-2-0，进失球7:5；进球为0 0/4，零封 0/4，双方进球 4/4，合计≥3球 3/4。
ESPN所列近5场补充进失球 8:6；进球为0 0/5，零封 0/5，双方进球 5/5，合计≥3球 3/5。主客拆分（只按近5场场地）：主场 3场，比分GF-GA=['1-1', '1-1', '2-1']；客场 2场，比分GF-GA=['2-1', '2-2']。
- 2026-10-04T18:45Z 2026-27 UEFA Nations League /League Phase：Netherlands 2-1 Serbia（W）
- 2026-10-01T18:45Z 2026-27 UEFA Nations League /League Phase：Netherlands 2-2 Greece（D）
- 2026-09-27T16:00Z 2026-27 UEFA Nations League /League Phase：Netherlands 2-1 Serbia（W）
- 2026-09-24T18:45Z 2026-27 UEFA Nations League /League Phase：Netherlands 1-1 Germany（D）
- 2026-06-30T01:00Z 2026 FIFA World Cup /Round of 32：Netherlands 1-1 Morocco（D）
- 最近一战过程：shots 22，shots on target 7，corners 6，possession 64.4%，saves 3。这是单场过程，不是xG。

**Greece** ESPN ID `455`；ESPN所列近5场跨赛事补充W-D-L=2-2-1。窗口（新→旧）：
本届欧国联League Phase主窗口（4场）：W-D-L=2-2-0，进失球5:3；进球为0 1/4，零封 2/4，双方进球 2/4，合计≥3球 2/4。
ESPN所列近5场补充进失球 5:4；进球为0 2/5，零封 2/5，双方进球 2/5，合计≥3球 2/5。主客拆分（只按近5场场地）：主场 3场，比分GF-GA=['0-1', '2-2', '0-0']；客场 2场，比分GF-GA=['2-1', '1-0']。
- 2026-10-04T18:45Z 2026-27 UEFA Nations League /League Phase：Greece 0-0 Germany（D）
- 2026-10-01T18:45Z 2026-27 UEFA Nations League /League Phase：Greece 2-2 Netherlands（D）
- 2026-09-27T18:45Z 2026-27 UEFA Nations League /League Phase：Greece 1-0 Germany（W）
- 2026-09-24T18:45Z 2026-27 UEFA Nations League /League Phase：Greece 2-1 Serbia（W）
- 2026-06-07T19:00Z 2026 International Friendly ：Greece 0-1 Italy（L）
- 最近一战过程：shots 5，shots on target 2，corners 2，possession 29.9%，saves 4。这是单场过程，不是xG。

双方进球、零球与高比分路径依据：以上已逐队列出近5场GF/GA、零进球、零封、BTTS、≥3球以及主客比分；结合最近一战shots/SOT只能说明一次机会产量/射正表现。小样本比分与射门不能替代xG，也不能推断稳定机会质量。
人员风险：ESPN本场summary的`rosters`只有队徽/队名骨架，无球员名单；`news`是联赛通用文章列表，不含该场伤停、停赛、教练轮换表态。当前没有可核实的人选级证据，因此人员风险未知，不能由空名单推断无人伤停。
主客拆分仅是ESPN所列5场补充窗口内实际主/客场比分，不是各自扩展到最近5个主场和5个客场。世界杯/友谊赛作为补充，赛事period未逐场独立核实。全赛事（含俱乐部）负荷与实际休息天数未采集。关键缺项：ESPN lastFiveGames只给5场；xG/xGA缺；网页定向搜索结果受Google JS interstitial限制（细节见`availability-web.md`），本轮未取得可信的本场伤停、停赛或教练轮换公告。

### Serbia–Germany（event 401861158；kickoff 2026-11-13T19:45Z UTC；场地 Rajko Mitic Stadium）

**Serbia** ESPN ID `6757`；ESPN所列近5场跨赛事补充W-D-L=0-0-5。窗口（新→旧）：
本届欧国联League Phase主窗口（4场）：W-D-L=0-0-4，进失球3:8；进球为0 1/4，零封 0/4，双方进球 3/4，合计≥3球 3/4。
ESPN所列近5场补充进失球 4:13；进球为0 1/5，零封 0/5，双方进球 4/5，合计≥3球 4/5。主客拆分（只按近5场场地）：主场 2场，比分GF-GA=['1-2', '1-2']；客场 3场，比分GF-GA=['1-5', '0-2', '1-2']。
- 2026-10-04T18:45Z 2026-27 UEFA Nations League /League Phase：Serbia 1-2 Netherlands（L）
- 2026-10-01T18:45Z 2026-27 UEFA Nations League /League Phase：Serbia 0-2 Germany（L）
- 2026-09-27T16:00Z 2026-27 UEFA Nations League /League Phase：Serbia 1-2 Netherlands（L）
- 2026-09-24T18:45Z 2026-27 UEFA Nations League /League Phase：Serbia 1-2 Greece（L）
- 2026-06-05T02:00Z 2026 International Friendly ：Serbia 1-5 Mexico（L）
- 最近一战过程：shots 14，shots on target 4，corners 4，possession 35.6%，saves 4。这是单场过程，不是xG。

**Germany** ESPN ID `481`；ESPN所列近5场跨赛事补充W-D-L=1-3-1。窗口（新→旧）：
本届欧国联League Phase主窗口（4场）：W-D-L=1-2-1，进失球3:2；进球为0 2/4，零封 2/4，双方进球 1/4，合计≥3球 0/4。
ESPN所列近5场补充进失球 4:3；进球为0 2/5，零封 2/5，双方进球 2/5，合计≥3球 0/5。主客拆分（只按近5场场地）：主场 3场，比分GF-GA=['1-1', '0-1', '2-0']；客场 2场，比分GF-GA=['1-1', '0-0']。
- 2026-10-04T18:45Z 2026-27 UEFA Nations League /League Phase：Germany 0-0 Greece（D）
- 2026-10-01T18:45Z 2026-27 UEFA Nations League /League Phase：Germany 2-0 Serbia（W）
- 2026-09-27T18:45Z 2026-27 UEFA Nations League /League Phase：Germany 0-1 Greece（L）
- 2026-09-24T18:45Z 2026-27 UEFA Nations League /League Phase：Germany 1-1 Netherlands（D）
- 2026-06-29T20:30Z 2026 FIFA World Cup /Round of 32：Germany 1-1 Paraguay（D）
- 最近一战过程：shots 21，shots on target 4，corners 3，possession 70.1%，saves 2。这是单场过程，不是xG。

双方进球、零球与高比分路径依据：以上已逐队列出近5场GF/GA、零进球、零封、BTTS、≥3球以及主客比分；结合最近一战shots/SOT只能说明一次机会产量/射正表现。小样本比分与射门不能替代xG，也不能推断稳定机会质量。
人员风险：ESPN本场summary的`rosters`只有队徽/队名骨架，无球员名单；`news`是联赛通用文章列表，不含该场伤停、停赛、教练轮换表态。当前没有可核实的人选级证据，因此人员风险未知，不能由空名单推断无人伤停。
主客拆分仅是ESPN所列5场补充窗口内实际主/客场比分，不是各自扩展到最近5个主场和5个客场。世界杯/友谊赛作为补充，赛事period未逐场独立核实。全赛事（含俱乐部）负荷与实际休息天数未采集。关键缺项：ESPN lastFiveGames只给5场；xG/xGA缺；网页定向搜索结果受Google JS interstitial限制（细节见`availability-web.md`），本轮未取得可信的本场伤停、停赛或教练轮换公告。

### Slovenia–Switzerland（event 401861156；kickoff 2026-11-13T19:45Z UTC；场地 Ljudski vrt）

**Slovenia** ESPN ID `472`；ESPN所列近5场跨赛事补充W-D-L=2-1-2。窗口（新→旧）：
本届欧国联League Phase主窗口（4场）：W-D-L=2-1-1，进失球5:3；进球为0 1/4，零封 2/4，双方进球 2/4，合计≥3球 2/4。
ESPN所列近5场补充进失球 6:5；进球为0 1/5，零封 2/5，双方进球 3/5，合计≥3球 3/5。主客拆分（只按近5场场地）：主场 2场，比分GF-GA=['0-0', '2-0']；客场 3场，比分GF-GA=['1-2', '1-2', '2-1']。
- 2026-10-06T18:45Z 2026-27 UEFA Nations League /League Phase：Slovenia 2-1 Scotland（W）
- 2026-10-03T18:45Z 2026-27 UEFA Nations League /League Phase：Slovenia 1-2 Switzerland（L）
- 2026-09-29T18:45Z 2026-27 UEFA Nations League /League Phase：Slovenia 2-0 North Macedonia（W）
- 2026-09-26T13:00Z 2026-27 UEFA Nations League /League Phase：Slovenia 0-0 Scotland（D）
- 2026-06-07T18:45Z 2026 International Friendly ：Slovenia 1-2 Croatia（L）
- 最近一战过程：shots 10，shots on target 3，corners 4，possession 45.8%，saves 5。这是单场过程，不是xG。

**Switzerland** ESPN ID `475`；ESPN所列近5场跨赛事补充W-D-L=4-0-1。窗口（新→旧）：
本届欧国联League Phase主窗口（4场）：W-D-L=4-0-0，进失球11:1；进球为0 0/4，零封 3/4，双方进球 1/4，合计≥3球 4/4。
ESPN所列近5场补充进失球 12:4；进球为0 0/5，零封 3/5，双方进球 2/5，合计≥3球 5/5。主客拆分（只按近5场场地）：主场 2场，比分GF-GA=['2-1', '3-0']；客场 3场，比分GF-GA=['1-3', '3-0', '3-0']。
- 2026-10-06T18:45Z 2026-27 UEFA Nations League /League Phase：Switzerland 3-0 North Macedonia（W）
- 2026-10-03T18:45Z 2026-27 UEFA Nations League /League Phase：Switzerland 2-1 Slovenia（W）
- 2026-09-29T18:45Z 2026-27 UEFA Nations League /League Phase：Switzerland 3-0 Scotland（W）
- 2026-09-26T18:45Z 2026-27 UEFA Nations League /League Phase：Switzerland 3-0 North Macedonia（W）
- 2026-07-12T01:00Z 2026 FIFA World Cup /Quarterfinals：Switzerland 1-3 Argentina（L）
- 最近一战过程：shots 20，shots on target 7，corners 8，possession 57%，saves 0。这是单场过程，不是xG。

双方进球、零球与高比分路径依据：以上已逐队列出近5场GF/GA、零进球、零封、BTTS、≥3球以及主客比分；结合最近一战shots/SOT只能说明一次机会产量/射正表现。小样本比分与射门不能替代xG，也不能推断稳定机会质量。
人员风险：ESPN本场summary的`rosters`只有队徽/队名骨架，无球员名单；`news`是联赛通用文章列表，不含该场伤停、停赛、教练轮换表态。当前没有可核实的人选级证据，因此人员风险未知，不能由空名单推断无人伤停。
主客拆分仅是ESPN所列5场补充窗口内实际主/客场比分，不是各自扩展到最近5个主场和5个客场。世界杯/友谊赛作为补充，赛事period未逐场独立核实。全赛事（含俱乐部）负荷与实际休息天数未采集。关键缺项：ESPN lastFiveGames只给5场；xG/xGA缺；网页定向搜索结果受Google JS interstitial限制（细节见`availability-web.md`），本轮未取得可信的本场伤停、停赛或教练轮换公告。

### Scotland–North Macedonia（event 401861161；kickoff 2026-11-13T19:45Z UTC；场地 Hampden Park）

**Scotland** ESPN ID `580`；ESPN所列近5场跨赛事补充W-D-L=1-1-3。窗口（新→旧）：
本届欧国联League Phase主窗口（4场）：W-D-L=1-1-2，进失球3:5；进球为0 2/4，零封 2/4，双方进球 1/4，合计≥3球 2/4。
ESPN所列近5场补充进失球 3:8；进球为0 3/5，零封 2/5，双方进球 1/5，合计≥3球 3/5。主客拆分（只按近5场场地）：主场 3场，比分GF-GA=['0-3', '0-3', '1-2']；客场 2场，比分GF-GA=['0-0', '2-0']。
- 2026-10-06T18:45Z 2026-27 UEFA Nations League /League Phase：Scotland 1-2 Slovenia（L）
- 2026-10-03T18:45Z 2026-27 UEFA Nations League /League Phase：Scotland 2-0 North Macedonia（W）
- 2026-09-29T18:45Z 2026-27 UEFA Nations League /League Phase：Scotland 0-3 Switzerland（L）
- 2026-09-26T13:00Z 2026-27 UEFA Nations League /League Phase：Scotland 0-0 Slovenia（D）
- 2026-06-24T22:00Z 2026 FIFA World Cup /Group Stage：Scotland 0-3 Brazil（L）
- 最近一战过程：shots 12，shots on target 6，corners 1，possession 54.2%，saves 0。这是单场过程，不是xG。

**North Macedonia** ESPN ID `463`；ESPN所列近5场跨赛事补充W-D-L=0-0-5。窗口（新→旧）：
本届欧国联League Phase主窗口（4场）：W-D-L=0-0-4，进失球0:10；进球为0 4/4，零封 0/4，双方进球 0/4，合计≥3球 2/4。
ESPN所列近5场补充进失球 0:14；进球为0 5/5，零封 0/5，双方进球 0/5，合计≥3球 3/5。主客拆分（只按近5场场地）：主场 2场，比分GF-GA=['0-3', '0-2']；客场 3场，比分GF-GA=['0-4', '0-2', '0-3']。
- 2026-10-06T18:45Z 2026-27 UEFA Nations League /League Phase：North Macedonia 0-3 Switzerland（L）
- 2026-10-03T18:45Z 2026-27 UEFA Nations League /League Phase：North Macedonia 0-2 Scotland（L）
- 2026-09-29T18:45Z 2026-27 UEFA Nations League /League Phase：North Macedonia 0-2 Slovenia（L）
- 2026-09-26T18:45Z 2026-27 UEFA Nations League /League Phase：North Macedonia 0-3 Switzerland（L）
- 2026-06-01T17:30Z 2026 International Friendly ：North Macedonia 0-4 Türkiye（L）
- 最近一战过程：shots 3，shots on target 0，corners 3，possession 43%，saves 4。这是单场过程，不是xG。

双方进球、零球与高比分路径依据：以上已逐队列出近5场GF/GA、零进球、零封、BTTS、≥3球以及主客比分；结合最近一战shots/SOT只能说明一次机会产量/射正表现。小样本比分与射门不能替代xG，也不能推断稳定机会质量。
人员风险：ESPN本场summary的`rosters`只有队徽/队名骨架，无球员名单；`news`是联赛通用文章列表，不含该场伤停、停赛、教练轮换表态。当前没有可核实的人选级证据，因此人员风险未知，不能由空名单推断无人伤停。
主客拆分仅是ESPN所列5场补充窗口内实际主/客场比分，不是各自扩展到最近5个主场和5个客场。世界杯/友谊赛作为补充，赛事period未逐场独立核实。全赛事（含俱乐部）负荷与实际休息天数未采集。关键缺项：ESPN lastFiveGames只给5场；xG/xGA缺；网页定向搜索结果受Google JS interstitial限制（细节见`availability-web.md`），本轮未取得可信的本场伤停、停赛或教练轮换公告。

### Bulgaria–Iceland（event 401861157；kickoff 2026-11-13T19:45Z UTC；场地 Hristo Botev Stadium, Plovdiv）

**Bulgaria** ESPN ID `462`；ESPN所列近5场跨赛事补充W-D-L=1-2-2。窗口（新→旧）：
本届欧国联League Phase主窗口（4场）：W-D-L=1-1-2，进失球3:5；进球为0 2/4，零封 2/4，双方进球 1/4，合计≥3球 2/4。
ESPN所列近5场补充进失球 5:7；进球为0 2/5，零封 2/5，双方进球 2/5，合计≥3球 3/5。主客拆分（只按近5场场地）：主场 2场，比分GF-GA=['1-2', '0-0']；客场 3场，比分GF-GA=['2-2', '0-3', '2-0']。
- 2026-10-06T18:45Z 2026-27 UEFA Nations League /League Phase：Bulgaria 2-0 Luxembourg（W）
- 2026-10-03T16:00Z 2026-27 UEFA Nations League /League Phase：Bulgaria 0-3 Iceland（L）
- 2026-09-29T18:45Z 2026-27 UEFA Nations League /League Phase：Bulgaria 0-0 Estonia（D）
- 2026-09-26T16:00Z 2026-27 UEFA Nations League /League Phase：Bulgaria 1-2 Luxembourg（L）
- 2026-06-05T17:00Z 2026 International Friendly ：Bulgaria 2-2 Moldova（D）
- 最近一战过程：shots 13，shots on target 5，corners 4，possession 37.5%，saves 7。这是单场过程，不是xG。

**Iceland** ESPN ID `470`；ESPN所列近5场跨赛事补充W-D-L=2-2-1。窗口（新→旧）：
本届欧国联League Phase主窗口（4场）：W-D-L=2-2-0，进失球7:1；进球为0 1/4，零封 3/4，双方进球 1/4，合计≥3球 2/4。
ESPN所列近5场补充进失球 7:4；进球为0 2/5，零封 3/5，双方进球 1/5，合计≥3球 3/5。主客拆分（只按近5场场地）：主场 2场，比分GF-GA=['1-1', '3-0']；客场 3场，比分GF-GA=['0-3', '3-0', '0-0']。
- 2026-10-06T18:45Z 2026-27 UEFA Nations League /League Phase：Iceland 0-0 Estonia（D）
- 2026-10-03T16:00Z 2026-27 UEFA Nations League /League Phase：Iceland 3-0 Bulgaria（W）
- 2026-09-29T18:45Z 2026-27 UEFA Nations League /League Phase：Iceland 3-0 Luxembourg（W）
- 2026-09-26T16:00Z 2026-27 UEFA Nations League /League Phase：Iceland 1-1 Estonia（D）
- 2026-06-10T01:00Z 2026 International Friendly ：Iceland 0-3 Argentina（L）
- 最近一战过程：shots 12，shots on target 1，corners 7，possession 62%，saves 3。这是单场过程，不是xG。

双方进球、零球与高比分路径依据：以上已逐队列出近5场GF/GA、零进球、零封、BTTS、≥3球以及主客比分；结合最近一战shots/SOT只能说明一次机会产量/射正表现。小样本比分与射门不能替代xG，也不能推断稳定机会质量。
人员风险：ESPN本场summary的`rosters`只有队徽/队名骨架，无球员名单；`news`是联赛通用文章列表，不含该场伤停、停赛、教练轮换表态。当前没有可核实的人选级证据，因此人员风险未知，不能由空名单推断无人伤停。
主客拆分仅是ESPN所列5场补充窗口内实际主/客场比分，不是各自扩展到最近5个主场和5个客场。世界杯/友谊赛作为补充，赛事period未逐场独立核实。全赛事（含俱乐部）负荷与实际休息天数未采集。关键缺项：ESPN lastFiveGames只给5场；xG/xGA缺；网页定向搜索结果受Google JS interstitial限制（细节见`availability-web.md`），本轮未取得可信的本场伤停、停赛或教练轮换公告。
