# Availability web check

Checked 2026-11-13 13:30 UTC (21:30 Beijing). Five targeted Google searches were made, one per fixture. Each response was HTTP 200 but rendered only the Google JavaScript/interstitial shell; no readable result title, snippet or destination URL was returned. No article was opened. Therefore there is no new sourced availability fact; this is a search-access gap and does not imply a clean squad.

The five query strings, source URLs, request/capture times, HTTP status and SHA-256 are in `availability-web.json`; original search HTML and metadata are retained under `raw/web/`. ESPN fixture-summary news lists were also reviewed; six listed articles were about England/Spain/Wales/Italy and unrelated to these fixtures. No summary news link was followed.

## Fixture status

- **bulgaria_iceland** — no usable results; query `Bulgaria Iceland Nations League November 13 2026 squad injury absence`. Original: `/workspace/WCPP/reports/nations-prematch-20261113-2118/context-a/raw/web/bulgaria_iceland-search.html` (SHA-256 `6eea4436cd4d1354210acfb3c79508d10fdf8f380aea291cda8aa93c2ff90d11`).
- **netherlands_greece** — no usable results; query `Netherlands Greece Nations League November 13 2026 injury squad absence goalkeeper striker`. Original: `/workspace/WCPP/reports/nations-prematch-20261113-2118/context-a/raw/web/netherlands_greece-search.html` (SHA-256 `50f9219c8caf55a1c0ee3f922f9d331f115b92c4fa291ad2346e2188bb85db6b`).
- **scotland_north_macedonia** — no usable results; query `Scotland North Macedonia Nations League November 13 2026 Scotland squad injury absence goalkeeper striker`. Original: `/workspace/WCPP/reports/nations-prematch-20261113-2118/context-a/raw/web/scotland_north_macedonia-search.html` (SHA-256 `7b1453e598a9b6244119b950f9bae74b770ceff30dab917570fcdc80bc4a693a`).
- **serbia_germany** — no usable results; query `Serbia Germany Nations League November 13 2026 Germany squad injury absence striker goalkeeper`. Original: `/workspace/WCPP/reports/nations-prematch-20261113-2118/context-a/raw/web/serbia_germany-search.html` (SHA-256 `6e1f4414d7f1bd70a70cfb0857b80131ca518ebc1c771a86d24343e34f31f36c`).
- **slovenia_switzerland** — no usable results; query `Slovenia Switzerland Nations League November 13 2026 squad injury absence`. Original: `/workspace/WCPP/reports/nations-prematch-20261113-2118/context-a/raw/web/slovenia_switzerland-search.html` (SHA-256 `f94b2c2a0ff7152cac75cae19df3b064b471eee5022641f5f3f17d4341a79ccf`).

No injury, suspension, current squad omission, goalkeeper/striker availability, or coach rotation statement can be confirmed from this web pass.