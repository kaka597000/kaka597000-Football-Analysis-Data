import json,hashlib,sys
from pathlib import Path
from datetime import datetime,timezone
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from automation.market_snapshot import build
from nations_league import safe_cli
from research.team_goal_analysis import summarize_prediction
from research.score_distribution_audit import audit_prediction
R=Path(__file__).resolve().parent
F=Path('/workspace/WCPP/forecasts/issued-analyses')
def read(p):return json.loads(Path(p).read_text())
def write(p,x):
 with Path(p).open('x') as h:json.dump(x,h,ensure_ascii=False,indent=2,allow_nan=False)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=datetime.now(timezone.utc);meta=read(R/'market/source-metadata.json')
channel=build(R/'market',meta['odds'],meta['identity'],cutoff=now.isoformat(),now=now,competition='uefa.nations',market_max_age_seconds=3600)
assert channel['verified_quote_count']==272 and channel['covered_fixture_count']==10
write(R/'validated-market.json',channel)
quotes={x['match_id']:x for x in read(R/'market/pinnacle-markets.json')['matches']}
raw=read(R/'market/odds.json'); cm=read(R/'market/same-event-line-comparison.json');old=read(cm['prior_source']);assert sha(cm['prior_source'])==cm['prior_sha256']
fixtures=[]
for f in read(R/'schedule/fixtures.json'):
 f=dict(f,cutoff_at=now.isoformat(),identity_verified=True,score_basis='regulation_90');q=quotes[f['match_id']];t=q['pinnacle_totals'];s=next(s for s in channel['snapshots'] if s['target']['match_id']==f['match_id'])
 for side in ['home','away']:assert s['target'][side+'_id']==f[side]
 f['total_quote']={'verified':True,'match_id':f['match_id'],'bookmaker':'pinnacle','market':'totals','line':t['line'],'over_odds':t['odds']['over'],'under_odds':t['odds']['under'],'quoted_at':t['quoted_at'],'query_time':meta['odds']['captured_at'],'source_url':meta['odds']['url'],'source_sha256':meta['odds']['sha256'],'period':'regulation_90'}
 f['market_snapshots']=[]
 for arr,m in [(old,{'sha256':cm['prior_sha256'],'captured_at':cm['prior_captured_at'],'url':meta['odds']['url']}),(raw,meta['odds'])]:
  matches=[e for e in arr if e['id']==q['source_event_id']];assert len(matches)==1;e=matches[0]
  assert e['home_team']==q['home'] and e['away_team']==q['away']
  for b in e['bookmakers']:
   if b['key']!='pinnacle':continue
   for k in b['markets']:
    if k['key'] not in ['h2h','totals']:continue
    names={e['home_team']:'home',e['away_team']:'away','Draw':'draw'} if k['key']=='h2h' else {'Over':'over','Under':'under'}
    f['market_snapshots'].append({'match_id':f['match_id'],'bookmaker':'pinnacle','market':'1x2' if k['key']=='h2h' else 'totals','line':k['outcomes'][0].get('point'),'decimal_odds':{names[o['name']]:o['price'] for o in k['outcomes']},'quoted_at':k['last_update'],'query_time':m['captured_at'],'source_url':m['url'],'source_sha256':m['sha256']})
 safe_cli.validate_future(f);fixtures.append(f)
write(R/'prepared-fixtures.json',fixtures)
safe_cli.freeze_pairs('/workspace/nations-model-20261110/models/candidates.json',fixtures,R/'candidate-update',F)
compact=[]
for f in fixtures:
 pair=read(R/'candidate-update'/(f['match_id'].replace(':','-')+'.json'))
 compact.append({'match_id':f['match_id'],'total_quote':f['total_quote'],**{role:{'primary':pair[role]['primary'],'wdl':pair[role]['wdl'],'team_goal_analysis':summarize_prediction(pair[role]),'distribution_audit':audit_prediction(pair[role])} for role in ['current','test']}})
write(R/'candidate-diagnostics.json',compact)
print(json.dumps({'verified_quotes':channel['verified_quote_count'],'candidate_pairs':len(compact),'cutoff':now.isoformat()}))
