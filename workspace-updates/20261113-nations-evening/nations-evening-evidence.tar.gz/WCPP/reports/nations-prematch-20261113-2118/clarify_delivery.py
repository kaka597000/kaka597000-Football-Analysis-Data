"""Append-only source/display corrections. No numerical prediction or selection changes."""
import json,hashlib,sys
from pathlib import Path
from datetime import datetime,timezone
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from research.analysis_freeze import save,verify
R=Path(__file__).resolve().parent;F=Path('/workspace/WCPP/forecasts/issued-analyses')
def read(p):return json.loads(Path(p).read_text())
def write(p,x):
 with Path(p).open('x') as h:json.dump(x,h,ensure_ascii=False,indent=2,allow_nan=False)
def now():return datetime.now(timezone.utc).isoformat()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
d=read(R/'delivery.json');records=read(R/'analysis-records.json');fixes=[]
for item in records:
 f=item['fixture']; old=item['payload']['sources']['context_b']
 if not (R/old).exists():
  assert f['source_event_id'] in ['401861156','401861157','401861158','401861159','401861161']
  replacements=['context-a/recent-form-process.json','context-a/source-ledger.json','context-a/raw/web/availability-web.json','audit/recent-form-audit.json']
  fixes.append({'match_id':f['match_id'],'original_comprehensive_reference':item['comprehensive_receipt'],'invalid_optional_path':old,'reason':'Template populated context_b for A-assigned fixtures; raw fixture and shared context_a source were already retained. No evidence or prediction was replaced.','authoritative_paths':[{'relative_path':p,'sha256':sha(R/p)} for p in replacements]})
assert len(fixes)==5
shell=dict(read(d['report_receipt']['path'])['fixture'],cutoff_at=now())
correction=save({'corrections':fixes,'display_clarification':{'match_id':'espn:401861155','primary':None,'wdl':'观望','compared_scores':['0-0','1-0','1-1'],'meaning':'All are alternative paths only; none is an issued comprehensive score recommendation.'},'unchanged':['all candidate matrices','all 9 comprehensive scores and abstention','all WDL/total selections','TOP3 membership/order','original first-prematch evaluation slots'],'original_report_reference':d['report_receipt']},shell,stage='prematch',track='source-provenance-correction',root=F)
report=(R/'欧国联赛前分析.md').read_text()
old='比分比较（仅首个综合唯一比分用于该轨命中评估，备选不叠加命中）：0-0、1-0、1-1。'
assert report.count(old)==1
report=report.replace(old,'比分路径比较（本场综合比分与胜平负均弃权；以下全部为备选路径，不是已推荐比分，不计为比分命中覆盖）：0-0、1-0、1-1。')
report+='\n## 来源与展示更正（追加，不改变预测）\n\n本展示版仅澄清安道尔的备选比分均不构成推荐，并更正A组采集负责的5场引用路径。其实际证据为 `context-a/recent-form-process.json`、`context-a/source-ledger.json`、`context-a/raw/web/availability-web.json` 与独立原始赛果审计；旧综合payload里多余的不存在 `context-b/{ID}.json` 路径不作为来源。涉及斯洛文尼亚—瑞士、保加利亚—冰岛、塞尔维亚—德国、荷兰—希腊、苏格兰—北马其顿。逐文件哈希与原综合冻结引用已追加冻结为 `'+correction['freeze_id']+'`。原报告及全部综合/候选/TOP3冻结保持；比分、方向、盘口、TOP3次序和首次评价版本完全不变。\n'
rr=save({'report_markdown':report,'comprehensive_receipts':[x['comprehensive_receipt'] for x in records],'top3_receipt':d['top3_receipt'],'original_report_receipt':d['report_receipt'],'correction_receipt':correction,'source_commit':d['source_commit'],'formal_kpi_eligible':False,'predictions_changed':False},dict(shell,cutoff_at=now()),stage='prematch',track='analysis-report',root=F)
(R/'欧国联赛前分析-展示修正版.md').write_text(report)
write(R/'source-correction.json',{'correction_receipt':correction,'corrections':fixes})
final=dict(d,original_report_receipt=d['report_receipt'],report_receipt=rr,correction_receipt=correction,all_receipts=d['all_receipts']+[correction,rr],predictions_changed_by_display_correction=False,preferred_report='欧国联赛前分析-展示修正版.md')
for ref in final['all_receipts']:assert verify(read(ref['path']))['record_sha256']==ref['sha256']
write(R/'delivery-final.json',final)
print(json.dumps({'verified_receipts':len(final['all_receipts']),'report_receipt':rr,'correction_receipt':correction},ensure_ascii=False))
