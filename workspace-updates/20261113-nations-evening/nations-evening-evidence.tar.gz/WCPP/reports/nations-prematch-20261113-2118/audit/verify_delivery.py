"""Independent final audit; reads published files, writes only audit results."""
from pathlib import Path
import json, hashlib, math
from collections import Counter
from datetime import datetime, timezone

R=Path(__file__).resolve().parents[1]
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def digest(value):return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def dt(value):return datetime.fromisoformat(value.replace('Z','+00:00'))
checks=[]
def ck(ok,label,detail=None):checks.append({'label':label,'passed':bool(ok),'detail':detail})
def verified(ref):
    p=Path(ref['path']);record=read(p)
    ck(digest({k:v for k,v in record.items() if k!='record_sha256'})==record['record_sha256']==ref['sha256'],record['freeze_id']+': canonical record hash')
    ck(record['freeze_id']==ref['freeze_id'] and record['recorded_at']==ref['recorded_at'],record['freeze_id']+': receipt identity/time')
    ck(dt(record['fixture']['cutoff_at'])<=dt(record['recorded_at'])<dt(record['fixture']['kickoff_at']),record['freeze_id']+': cutoff <= freeze < kickoff')
    if record['revision']>1:
        prior=read(p.with_name(f'{record["revision"]-1:06}.json'))
        ck(digest({k:v for k,v in prior.items() if k!='record_sha256'})==prior['record_sha256']==record['previous_sha256'],record['freeze_id']+': previous revision hash chain')
    ck(record['model_promotion'] is False,record['freeze_id']+': no promotion')
    return record

delivery=read(R/'delivery.json')
refs=delivery['all_receipts']
ck(len(refs)==33 and len({r['path'] for r in refs})==33,'33 unique original receipts')
frozen={r['path']:verified(r) for r in refs}
tracks=Counter(r['track'] for r in frozen.values())
ck(tracks==Counter({'nations-paired-candidates':10,'current-test-pair':10,'comprehensive':10,'top3-selection':1,'analysis-report':1,'research-preregistration':1}),'original frozen track counts',dict(tracks))
selections=read(R/'selections.json')
records=read(R/'analysis-records.json')
diag={r['match_id']:r for r in read(R/'candidate-diagnostics.json')}
report=(R/'欧国联赛前分析.md').read_text()
report_freeze=frozen[delivery['report_receipt']['path']]
ck(report_freeze['payload']['report_markdown']==report,'report bytes/text equal original frozen report content')
form=read(R/'audit/recent-form-audit.json')['teams']
missing_sources=[]
def settlement(totals,line,side):
    quarter=round(line*4)
    components=[line] if quarter%2==0 else [line-.25,line+.25]
    result={key:0.0 for key in ['win','half_win','push','half_loss','loss']}
    names={1:'win',.5:'half_win',0:'push',-.5:'half_loss',-1:'loss'}
    for n,mass in enumerate(totals):
        results=[(1 if n>x else -1 if n<x else 0)*(1 if side=='over' else -1) for x in components]
        result[names[sum(results)/len(results)]]+=mass
    return result

for row in records:
    f,p=row['fixture'],row['payload'];mid=f['match_id'];eid=mid.split(':')[-1];choice=selections[eid]
    cf=frozen[row['comprehensive_receipt']['path']];cand=frozen[row['candidate_receipt']['path']];active=frozen[row['active_receipt']['path']]
    ck(cf['payload']==p,mid+': analysis record exactly equals comprehensive frozen payload')
    ck(all(p[k]==v for k,v in choice.items()),mid+': frozen payload equals final selections')
    ck(cf['match_id']==cand['match_id']==active['match_id']==mid,mid+': all tracks same fixture')
    ck(p['candidate_reference']==row['candidate_receipt'] and p['current_test_reference']==row['active_receipt'],mid+': exact frozen references')
    ck(dt(cand['recorded_at'])<=dt(cf['recorded_at']) and dt(active['recorded_at'])<=dt(cf['recorded_at']),mid+': references frozen first')
    ck(cand['revision']==2 and cf['revision']==1,mid+': candidate revision2 and comprehensive first version')
    ck(p['selection_scope']=='candidate_research' and p['formal_kpi_eligible'] is False and p['active_model_promotion'] is False and p['numerical_weights_changed'] is False,mid+': research scope and no parameter changes claimed')
    ck(active['payload']['candidate_substitution'] is False and all(active['payload'][role]['status']=='ABSTAIN_NO_ACTIVE_ROUTE' and active['payload'][role]['matrix'] is None and active['payload'][role]['primary'] is None for role in ['current_model','test_model']),mid+': active tracks retain refusal')
    ck(cand['payload']['current']['input']==cand['payload']['test']['input'],mid+': candidate tracks share exact input')
    for role in ['current','test']:
        original=cand['payload'][role];out=p['candidate_outputs'][role]
        ck(all(out[k]==v for k,v in original.items()),mid+'/'+role+': entire original candidate output preserved')
        for side in ['over','under']:
            expected=settlement(diag[mid][role]['distribution_audit']['total_probabilities'],p['total_line'],side)
            ck(all(abs(expected[k]-out['actual_total_settlement'][side][k])<1e-12 for k in expected),mid+'/'+role+'/'+side+': independently recomputed settlement')
        if p['total_direction'] in ['大','小']:
            side='over' if p['total_direction']=='大' else 'under'
            table='|'+role+'|'+'|'.join(f'{out["actual_total_settlement"][side][k]:.1%}' for k in ['win','half_win','push','half_loss','loss'])+'|'
            section=report.split('## '+p['name']+'\n',1)[1].split('\n## ',1)[0]
            ck(table in section,mid+'/'+role+': settlement displayed in matching report section')
    ck(p['current_edition_form']==[x for x in form if x['fixture_id']==eid],mid+': current edition form matches audited source')
    for k in ['reason','counter','total_reason','three_plus_path','availability']:
        ck(p[k] in report,mid+': final '+k+' text present in report')
    for name,path in p['sources'].items():
        if isinstance(path,str) and not (R/path).exists():missing_sources.append({'match_id':mid,'field':name,'path':path})

top=frozen[delivery['top3_receipt']['path']]
ck(top['payload']['selection_scope']=='candidate_research' and top['payload']['formal_kpi_eligible'] is False,'TOP3 remains research scope')
ck([x['match_id'] for x in top['payload']['top3']]==['espn:401861153','espn:401861161','espn:401861160'],'TOP3 exact rank order')
for i,item in enumerate(top['payload']['top3'],1):
    cf=frozen[item['comprehensive_reference']['path']]
    ck(item['rank']==i and all(item[k]==cf['payload'][k] for k in ['primary','wdl','total_line','total_direction']),item['match_id']+': TOP3 values match comprehensive')
    ck(cf['selection_audit']['top3_ready'] is True and dt(cf['recorded_at'])<=dt(top['recorded_at']),item['match_id']+': TOP3 comparison gate and chronology')
ck(report_freeze['payload']['top3_receipt']==delivery['top3_receipt'],'report cites exact TOP3 receipt')
ck(report_freeze['payload']['comprehensive_receipts']==[x['comprehensive_receipt'] for x in records],'report cites all ten exact comprehensive receipts')
ck(sum(s['primary'] is not None for s in selections.values())==9 and selections['401861155']['primary'] is None,'nine scores, Andorra abstention preserved')
ck(sum(s['total_direction'] in ['大','小'] for s in selections.values())==8,'eight total directions, two observations preserved')

preflight=read(R/'model-preflight/artifacts-readonly-check.json')
ck(sha(preflight['index_path'])==preflight['index_sha256'],'candidate index unchanged from preflight')
for item in preflight['checks']:
    ck(sha(item['path'])==item['actual_sha256']==item['expected_sha256'],'artifact unchanged: '+item['level']+'/'+item['role'])
    for name,d in item['dependencies'].items():ck(sha(d['path'])==d['actual_sha256']==d['expected_sha256'],'dependency unchanged: '+item['level']+'/'+item['role']+'/'+name)
preactive=read(R/'model-preflight/active-route-refusal.json')
ck(sha(preactive['registry_path'])==preactive['registry_sha256']=='923e34fc44cda33fe965498a24a2435abb37a01a80c539108d8ec20d490bf013','active registry unchanged from preflight')
guard=next(v for v in frozen.values() if v['track']=='nations-paired-candidates')['payload']['execution_guard']
for name,d in {**guard['sources'],'validator':guard['validator']}.items():ck(sha(d['path'])==d['sha256'],'execution guard source unchanged: '+name)

result={'audited_at':datetime.now(timezone.utc).isoformat(),'status':'PASS_WITH_DOCUMENTED_DISPLAY_AND_PROVENANCE_NOTES' if all(x['passed'] for x in checks) else 'FAIL','receipt_count':len(refs),'tracks':dict(tracks),'check_count':len(checks),'failed_checks':[x for x in checks if not x['passed']],'checks':checks,'original_report_sha256':sha(R/'欧国联赛前分析.md'),'final_selections_sha256':sha(R/'selections.json'),'original_report_recorded_at':report_freeze['recorded_at'],'missing_optional_source_references':missing_sources,'notes':['Five comprehensive v1 payload context_b references point to nonexistent files for context-a fixtures. Actual canonical source data and context-a file exist; root is appending a correction instead of overwriting frozen payloads.','Andorra original report score-comparison template can be misread as treating first candidate as selected. Frozen primary=null, full table and explicit statement retain abstention. Root is appending report clarification.','Official-lineup wording changed only from unannounced assertion to not obtained. All chosen scores and directions are unchanged.','No model/code/forecast files were modified by this audit; only audit output is written. Candidate index, eight artifacts/dependencies, active registry and execution-guard sources match existing hashes.','No independent Git commands were run; source commit identifier is only cross-referenced within delivered materials.']}
(R/'audit/delivery-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['status','receipt_count','tracks','check_count','failed_checks','missing_optional_source_references']},ensure_ascii=False,indent=2))
