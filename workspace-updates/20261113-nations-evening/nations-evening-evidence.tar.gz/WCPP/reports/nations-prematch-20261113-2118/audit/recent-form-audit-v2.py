import json, hashlib, datetime
from pathlib import Path
B=Path('/workspace/WCPP/reports/nations-prematch-20261113-2118')
A=B/'audit'
def read(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def stats(rows):
 return {'n':len(rows),'W':sum(r['goals_for']>r['goals_against'] for r in rows),'D':sum(r['goals_for']==r['goals_against'] for r in rows),'L':sum(r['goals_for']<r['goals_against'] for r in rows),'GF':sum(r['goals_for'] for r in rows),'GA':sum(r['goals_against'] for r in rows),'scored':sum(r['goals_for']>0 for r in rows),'scoreless':sum(r['goals_for']==0 for r in rows),'clean_sheets':sum(r['goals_against']==0 for r in rows),'btts':sum(r['goals_for']>0 and r['goals_against']>0 for r in rows),'total_3plus':sum(r['goals_for']+r['goals_against']>=3 for r in rows)}
source_teams={}; issues=[]; source_hashes={}
for p in sorted((B/'schedule/summaries').glob('*.json')):
 source_hashes[str(p.relative_to(B))]=sha(p)
 for t in read(p)['lastFiveGames']:
  tid=str(t['team']['id']);rows=[]
  for e in t['events']:
   home=str(e['homeTeamId'])==tid
   assert tid in [str(e['homeTeamId']),str(e['awayTeamId'])]
   gf=int(e['homeTeamScore'] if home else e['awayTeamScore']);ga=int(e['awayTeamScore'] if home else e['homeTeamScore'])
   rows.append({'event_id':e['id'],'date':e['gameDate'],'home_away':'H' if home else 'A','opponent_id':e['opponent']['id'],'opponent':e['opponent']['displayName'],'goals_for':gf,'goals_against':ga,'score_for_team':f'{gf}-{ga}','score_derived_result':'W' if gf>ga else 'L' if gf<ga else 'D','raw_game_result':e['gameResult'],'competition':e['competitionName'],'phase':e.get('roundName'),'raw_shootout':{'home':e.get('homeShootoutScore'),'away':e.get('awayShootoutScore')}})
  primary=[r for r in rows if r['competition']=='2026-27 UEFA Nations League' and r['phase']=='League Phase']
  source_teams[(p.stem,tid)]={'fixture_id':p.stem,'team_id':tid,'team':t['team']['displayName'],'source_file':str(p.relative_to(B)),'recent':rows,'primary':stats(primary),'primary_home_away':{side:stats([r for r in primary if r['home_away']==side]) for side in ['H','A']},'supplemental_excluded':[r for r in rows if r not in primary]}
def issue(kind,fixture,team,event,field,actual,expected,path):issues.append({'kind':kind,'fixture':fixture,'team':team,'event_id':event,'field':field,'actual':actual,'expected':expected,'file':str(path.relative_to(B))})
p=B/'context-a/recent-form-process.json';source_hashes[str(p.relative_to(B))]=sha(p)
for fixture in read(p)['fixtures']:
 for t in fixture['teams']:
  raw=source_teams[(str(fixture['event_id']),str(t['team_id']))];byid={r['event_id']:r for r in raw['recent']}
  for r in t['recent5']:
   rr=byid[r['event_id']]
   for k,expected in [('score_for_against',rr['score_for_team']),('opponent',rr['opponent']),('outcome',rr['score_derived_result']),('competition',rr['competition']),('phase',rr['phase'])]:
    if r.get(k)!=expected: issue('derived_row_mismatch',fixture['event_id'],t['team'],r['event_id'],k,r.get(k),expected,p)
  ps=raw['primary'];expected={'matches':ps['n'],'w_d_l':f"{ps['W']}-{ps['D']}-{ps['L']}",'goals_for':ps['GF'],'goals_against':ps['GA'],'zero_goals':ps['scoreless'],'clean_sheets':ps['clean_sheets'],'both_teams_scored':ps['btts'],'total_goals_3plus':ps['total_3plus']}
  for k,v in expected.items():
   if t['primary_competition_window'].get(k)!=v:issue('primary_summary_mismatch',fixture['event_id'],t['team'],None,k,t['primary_competition_window'].get(k),v,p)
for p in sorted((B/'context-b').glob('401*.json')):
 source_hashes[str(p.relative_to(B))]=sha(p);fixture=read(p)
 for t in fixture['teams']:
  raw=source_teams[(str(fixture['match_id']),str(t['team_id']))];byid={r['event_id']:r for r in raw['recent']}
  for r in t['recent_five_oldest_to_newest']:
   rr=byid[r['event_id']]
   for k,expected in [('goals_for',rr['goals_for']),('goals_against',rr['goals_against']),('home_away',rr['home_away']),('opponent',rr['opponent']),('opponent_id',rr['opponent_id']),('result',rr['score_derived_result']),('competition',rr['competition'])]:
    if r.get(k)!=expected:issue('derived_row_mismatch',fixture['match_id'],t['team'],r['event_id'],k,r.get(k),expected,p)
  for area,rs in [('window_overall',raw['recent']),('H',[r for r in raw['recent'] if r['home_away']=='H']),('A',[r for r in raw['recent'] if r['home_away']=='A'])]:
   expected=stats(rs);actual=t['window_overall'] if area=='window_overall' else t['home_away_windows'][area]
   for k,v in actual.items():
    if k in expected and v!=expected[k]:issue('summary_mismatch',fixture['match_id'],t['team'],None,area+'.'+k,v,expected[k],p)
report={'audit_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Local read-only review. Source identities are ESPN team IDs; goals_for/goals_against are reconstructed from homeTeamId/awayTeamId rather than score string. Primary window is exactly current 2026-27 UEFA Nations League League Phase; all other competition rows excluded.','source_hashes':source_hashes,'automated_issues':issues,'teams':list(source_teams.values()),'limitations':['Source schedule lastFiveGames does not independently certify 90-minute period for non-league-phase games. Knockout World Cup matches are excluded from primary window.','Latest event-process samples may be from friendlies for League D teams; do not promote them to current Nations League process.','Narrative support and counterpath errors are listed separately in the Markdown audit.']}

# V2 preserves the first audit and its exact input fingerprints.
first_path=A/'recent-form-audit.json'
first=read(first_path)
report['version']='v2'
report['first_audit']={'path':str(first_path),'sha256':sha(first_path),'source_hashes':first['source_hashes'],'automated_issue_count':len(first['automated_issues']),'automated_issues':first['automated_issues']}
# Validate the newly added primary window and both primary venue windows.
primary_checks=0
for p in sorted((B/'context-b').glob('401*.json')):
 fixture=read(p)
 for t in fixture['teams']:
  raw=source_teams[(str(fixture['match_id']),str(t['team_id']))]
  expected_primary=[r for r in raw['recent'] if r['competition']=='2026-27 UEFA Nations League' and r['phase']=='League Phase']
  for field,expected in [('current_nations_league_phase_window',stats(expected_primary)),('current_nations_league_home_away_windows',{side:stats([r for r in expected_primary if r['home_away']==side]) for side in ['H','A']})]:
   primary_checks+=1
   if t.get(field)!=expected:issue('primary_summary_mismatch',fixture['match_id'],t['team'],None,field,t.get(field),expected,p)
  actual_primary_ids=[r['event_id'] for r in t.get('current_nations_league_phase_recent',[])]
  expected_primary_ids=[r['event_id'] for r in expected_primary]
  primary_checks+=1
  if actual_primary_ids!=expected_primary_ids:issue('primary_membership_mismatch',fixture['match_id'],t['team'],None,'event_ids',actual_primary_ids,expected_primary_ids,p)
report['new_primary_window_checks']=primary_checks
# Reproduce all 98 original team-stat checks; preserve comparison details.
process_checks=[]
for cp in [B/'context-a/recent-form-process.json']+sorted((B/'context-b').glob('401*.json')):
 x=read(cp); teams=[t for f in x['fixtures'] for t in f['teams']] if 'fixtures' in x else x['teams']
 for t in teams:
  if 'last_match_stats' in t:
   eid=t['latest_match_process_event_id']; actual=t['last_match_stats']; rp=B/'context-a/raw'/f'espn-summary-{eid}.json'
  else:
   eid=t['latest_event_process']['event_id'];actual=t['latest_event_process']['team_stats'];rp=B/'context-b/raw'/f'espn-summary-{eid}.json'
  report['source_hashes'][str(rp.relative_to(B))]=sha(rp)
  box=read(rp).get('boxscore',{}).get('teams',[])
  team=next((r for r in box if str(r['team']['id'])==str(t['team_id'])),None)
  expected={} if team is None else {r['name']:r.get('displayValue') for r in team['statistics']}
  for k,v in actual.items():
   process_checks.append({'team_id':t['team_id'],'team':t['team'],'event_id':eid,'field':k,'actual':v,'expected':expected.get(k),'pass':v==expected.get(k),'source_path':str(rp.relative_to(B))})
report['process_stat_checks']={'field_count':len(process_checks),'mismatches':[r for r in process_checks if not r['pass']],'comparisons':process_checks,'notes':'Compared by team ID, never boxscore ordering. Liechtenstein/Gibraltar latest friendly summary supplies no usable statistics and both derived dictionaries are empty.'}
# Every regenerated Markdown record and each narrative bullet must agree with JSON.
markdown_checks=[]
for p in sorted((B/'context-b').glob('401*.json')):
 x=read(p);mp=p.with_suffix('.md');md=mp.read_text();report['source_hashes'][str(mp.relative_to(B))]=sha(mp)
 for t in x['teams']:
  for r in t['recent_five_oldest_to_newest']:
   token=f"{r['date']} {r['competition']} / {r['home_away']} vs {r['opponent']}：{r['result']} {r['score_for_team']}"
   markdown_checks.append({'file':str(mp.relative_to(B)),'team':t['team'],'event_id':r['event_id'],'field':'recent_row','pass':token in md,'expected_token':token})
 for kind,bullets in x['analysis_support_and_counterpaths'].items():
  for bullet in bullets:
   markdown_checks.append({'file':str(mp.relative_to(B)),'field':kind,'pass':bullet in md,'expected_token':bullet})
report['markdown_checks']={'count':len(markdown_checks),'mismatches':[r for r in markdown_checks if not r['pass']],'comparisons':markdown_checks}
# Manual semantic review of the seven original narrative errors: no new projection or score choice.
narrative_checks=[
 {'fixture':'401861153','first_error':'Azerbaijan scored in all five','source_fact':'4/5 all competitions; 2/3 current Nations League','replacement_must_include':['Azerbaijan本届3场有2场进球','Azerbaijan最近五场有一场未进球']},
 {'fixture':'401861154','first_error':'Luxembourg beat Faroe Islands 3-0 on 2026-09-29','source_fact':'Luxembourg 0-3 Iceland on September 29; legitimate winning counterpath is away 2-1 Bulgaria September 26','replacement_must_include':['Luxembourg本届赛中曾客场2-1胜Bulgaria']},
 {'fixture':'401861154','first_error':'Luxembourg scored in 3 of five','source_fact':'2/5 all competitions; 1/4 current Nations League','replacement_must_include':['Luxembourg仅1/4场进球']},
 {'fixture':'401861155','first_error':'Andorra three scoreless matches','source_fact':'4/5 all competitions; 2/3 current Nations League','replacement_must_include':['近5场总窗口Andorra有4场未进球']},
 {'fixture':'401861160','first_error':'Slovakia other four matches were 1-2 total goals','source_fact':'Other four scores are 2-2,2-0,2-1,1-1','replacement_must_include':['Slovakia最近五场另有2-2友谊赛和2-1联赛赛果']},
 {'fixture':'401861162','first_error':'Kazakhstan 2-1 Moldova on 2026-10-02','source_fact':'Kazakhstan home 1-2 Moldova','replacement_must_include':['10月2日客场2-1胜Kazakhstan']},
 {'fixture':'401861162','first_error':'Kazakhstan exactly 1 in three of five','source_fact':'Exactly 1 in four of five; corrected prose instead states current Nations League 5 goals and scoring in all four','replacement_must_include':['Kazakhstan本届4场进5球、每场均有进球']},
]
for c in narrative_checks:
 p=B/'context-b'/f"{c['fixture']}.json"; x=read(p);text=' '.join(b for vals in x['analysis_support_and_counterpaths'].values() for b in vals)
 c['pass']=all(token in text for token in c['replacement_must_include']) and c['first_error'] not in text
 c['review_method']='Rechecked whole revised narrative against raw lastFiveGames by team ID and the source-derived current primary window; exact tokens are reproducibility guards, not semantic proof by themselves.'
report['narrative_repair_checks']=narrative_checks
report['original_opponent_errors_recheck']=[dict(old,currently_correct=not any(new['fixture']==old['fixture'] and new['team']==old['team'] and new['event_id']==old['event_id'] and new['field']==old['field'] for new in issues)) for old in first['automated_issues']]
report['changed_inputs']=[{'file':p,'first_sha256':old,'current_sha256':report['source_hashes'].get(p),'changed':old!=report['source_hashes'].get(p)} for p,old in first['source_hashes'].items()]
report['final_status']='PASS' if not issues and not report['process_stat_checks']['mismatches'] and not report['markdown_checks']['mismatches'] and all(c['pass'] for c in narrative_checks) else 'FAIL'
out=A/'recent-form-audit-v2.json'
out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':report['final_status'],'automated_issues':issues,'primary_window_checks':primary_checks,'process_fields':len(process_checks),'process_mismatches':report['process_stat_checks']['mismatches'],'markdown_check_count':len(markdown_checks),'markdown_mismatches':report['markdown_checks']['mismatches'],'narrative_repairs_passed':sum(c['pass'] for c in narrative_checks),'original_opponent_errors_passed':sum(c['currently_correct'] for c in report['original_opponent_errors_recheck']),'output':str(out)},ensure_ascii=False,indent=2))
