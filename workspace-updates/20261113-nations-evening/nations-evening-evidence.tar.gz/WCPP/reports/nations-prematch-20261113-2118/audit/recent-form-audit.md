# 近期赛果与口径独立审计

审计快照：2026-11-13T13:31:09.965788+00:00；仅本地源文件，不联网、不改源码或冻结。

## 结论

按原始 homeTeamId / awayTeamId 重建 20 队共 100 条进失球，结构化 GF/GA、主客、胜平负及汇总数值均匹配；context-a 的本届欧国联主窗口数字全通过。98 项近期过程统计按球队 ID 逐字段比对通过。

context-b 存在 16 处对手名映射错误，另有多处手写支持/反证文案与原始赛果相反或计数不符。已逐项通知原代理修订；本文件记录的是首次审计快照，修订后需重核。全部结构化错误及源 SHA 在 recent-form-audit.json 中。

## 本届欧国联可复用窗口

以下仅含 competitionName=2026-27 UEFA Nations League 且 roundName=League Phase。74 条队次来自本届欧国联；其余 26 条队次（友谊赛22、世界杯4）全部排除。D 组三队制各队已赛场次不齐，禁止统一称近4场。

|球队|场次|胜-平-负|进-失球|零进球|零封|双方进球|总球≥3|
|---|---:|---|---|---:|---:|---:|---:|
|Liechtenstein|2|0-1-1|0-2|2|1|0|0|
|Azerbaijan|3|1-2-0|2-1|1|2|1|0|
|Luxembourg|4|1-0-3|2-7|3|0|1|2|
|Estonia|4|1-3-0|2-1|2|3|1|0|
|Andorra|3|0-1-2|1-3|2|1|1|1|
|Gibraltar|2|0-2-0|1-1|1|1|1|0|
|Slovenia|4|2-1-1|5-3|1|2|2|2|
|Switzerland|4|4-0-0|11-1|0|3|1|4|
|Bulgaria|4|1-1-2|3-5|2|2|1|2|
|Iceland|4|2-2-0|7-1|1|3|1|2|
|Serbia|4|0-0-4|3-8|1|0|3|3|
|Germany|4|1-2-1|3-2|2|2|1|0|
|Netherlands|4|2-2-0|7-5|0|0|4|3|
|Greece|4|2-2-0|5-3|1|2|2|2|
|Slovakia|4|3-1-0|9-2|0|2|2|2|
|Faroe Islands|4|0-4-0|5-5|0|0|4|1|
|Scotland|4|1-1-2|3-5|2|2|1|2|
|North Macedonia|4|0-0-4|0-10|4|0|0|2|
|Moldova|4|1-1-2|3-8|2|0|2|2|
|Kazakhstan|4|0-2-2|5-7|0|0|4|3|

## 必须修正的手写文案

|文件|原说法|原文支持的事实|
|---|---|---|
|context-b/401861153.json|Azerbaijan scored in all five|近5场仅4场进球，含0-0 Liechtenstein；本届欧国联3场中2场进球|
|context-b/401861154.json|Luxembourg beat Faroe Islands 3-0 on 2026-09-29|事件401861086：Luxembourg主场0-3 Iceland|
|context-b/401861154.json|Luxembourg in 3 of five scored|近5场仅2场进球；本届欧国联4场仅1场进球|
|context-b/401861155.json|Andorra three scoreless matches|近5场4场零进球；本届欧国联3场中2场零进球|
|context-b/401861160.json|Slovakia other four matches were 1-2 total goals|除4-0外四场依次2-2、2-0、2-1、1-1，总球4、2、3、2|
|context-b/401861162.json|Kazakhstan 2-1 Moldova on 2026-10-02|事件401861101：Kazakhstan主场1-2 Moldova，胜负方向被倒转|
|context-b/401861162.json|Kazakhstan exactly 1 in three of five|近5场四场恰好1球，一场2球|

## 赛事混入及解释边界

- context-a 主窗口已明确排除世界杯与友谊赛，可以复用其主窗口；跨赛事近5场与其主客拆分仍含补充赛事，不可替代本届窗口。
- Netherlands、Germany 的世界杯1-1原始 gameResult=L（含点球淘汰），context-a按比分记D。主窗口已排除，不影响本届欧国联统计；未独立核实90分钟前，不应把补充D当90分钟战绩。Switzerland世界杯淘汰赛1-3同样排除。
- Scotland的世界杯场次是Group Stage；context-a统一的“World Cup knockout”period_note措辞不准确，但同样排除，因此不影响主窗口数字。
- context-b 结构化window_overall与home_away_windows采用全部近5场，包含友谊赛；仅靠行标签不能声称总体窗口未混合。最终报告应改用本审计提供的primary及primary_home_away。
- Liechtenstein和Gibraltar最近一战401896386是友谊赛，且本地summary过程统计为空，不可补称当前欧国联过程。
- 最近国家队比赛相隔天数不能当休息天数；俱乐部负荷未覆盖。没有xG字段的射门统计不能替代xG。
- 本审计不选择比分，不把短窗口记录转换成额外概率。
