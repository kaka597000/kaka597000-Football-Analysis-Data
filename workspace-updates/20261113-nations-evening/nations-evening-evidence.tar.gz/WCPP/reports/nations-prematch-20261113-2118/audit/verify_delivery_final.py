"""Recheck original delivery plus append-only corrections; only audit output written."""
import runpy
from pathlib import Path
import json,hashlib
from datetime import datetime,timezone
R=Path(__file__).resolve().parents[1]
base=runpy.run_path(str(R/'audit/verify_delivery.py'))
read,sha,ck,verified,dt=(*(base[k] for k in ['read','sha','ck','verified','dt']),)
checks=base['checks'];original=base['delivery'];frozen=base['frozen']
first=read(R/'audit/delivery-audit.json')
history=R/'audit/delivery-audit-original33.json'
if not history.exists():history.write_text(json.dumps(first,ensure_ascii=False,indent=2)+'\n')
final=read(R/'delivery-final.json')
ck(len(final['all_receipts'])==35 and len({x['path'] for x in final['all_receipts']})==35,'35 unique final receipts')
ck(final['all_receipts'][:33]==original['all_receipts'],'all 33 original receipts retained unchanged')
ck(final['original_report_receipt']==original['report_receipt'] and final['top3_receipt']==original['top3_receipt'],'original report and TOP3 references retained')
correction=verified(final['correction_receipt']);newreport=verified(final['report_receipt'])
ck(correction['track']=='source-provenance-correction' and newreport['track']=='analysis-report' and newreport['revision']==2,'two added receipts have correction/report2 tracks')
ck(final['all_receipts'][33:]==[final['correction_receipt'],final['report_receipt']],'only source correction and report2 appended')
ck(newreport['previous_sha256']==original['report_receipt']['sha256'],'report2 chain points to unchanged report1')
ck(newreport['payload']['original_report_receipt']==original['report_receipt'] and newreport['payload']['correction_receipt']==final['correction_receipt'],'report2 references exact original and correction')
ck(newreport['payload']['top3_receipt']==original['top3_receipt'] and newreport['payload']['comprehensive_receipts']==base['report_freeze']['payload']['comprehensive_receipts'],'report2 reuses same ten comprehensive records and TOP3')
ck(newreport['payload']['predictions_changed'] is False and final['predictions_changed_by_display_correction'] is False,'correction explicitly leaves predictions unchanged')
newpath=R/final['preferred_report'];newtext=newpath.read_text();oldtext=(R/'欧国联赛前分析.md').read_text()
ck(newreport['payload']['report_markdown']==newtext,'preferred report exactly equals report2 frozen text')
old='比分比较（仅首个综合唯一比分用于该轨命中评估，备选不叠加命中）：0-0、1-0、1-1。'
new='比分路径比较（本场综合比分与胜平负均弃权；以下全部为备选路径，不是已推荐比分，不计为比分命中覆盖）：0-0、1-0、1-1。'
body=newtext.split('\n## 来源与展示更正（追加，不改变预测）\n',1)[0]
ck(body==oldtext.replace(old,new),'report2 body differs only by exact Andorra abstention clarification')
sidecar=read(R/'source-correction.json')
ck(sidecar['correction_receipt']==final['correction_receipt'] and sidecar['corrections']==correction['payload']['corrections'],'source sidecar exactly matches correction freeze')
fixes=correction['payload']['corrections'];missing=base['missing_sources']
ck({(x['match_id'],x['invalid_optional_path']) for x in fixes}=={(x['match_id'],x['path']) for x in missing},'correction covers exactly all five missing optional source paths')
for fix in fixes:
    ref=fix['original_comprehensive_reference'];record=frozen[ref['path']]
    ck(record['record_sha256']==ref['sha256'] and record['match_id']==fix['match_id'],'correction cites correct original: '+fix['match_id'])
    for p in fix['authoritative_paths']:ck((R/p['relative_path']).is_file() and sha(R/p['relative_path'])==p['sha256'],'corrected source exists and SHA matches: '+fix['match_id']+'/'+p['relative_path'])
clar=correction['payload']['display_clarification']
ck(clar['match_id']=='espn:401861155' and clar['primary'] is None and clar['wdl']=='观望' and clar['compared_scores']==['0-0','1-0','1-1'],'Andorra correction preserves abstention/candidate distinction')
ck(dt(original['report_receipt']['recorded_at'])<=dt(correction['recorded_at'])<=dt(newreport['recorded_at']),'append-only correction chronology')
result={**first,'audited_at':datetime.now(timezone.utc).isoformat(),'status':'PASS' if all(x['passed'] for x in checks) else 'FAIL','receipt_count':35,'tracks':{**first['tracks'],'analysis-report':2,'source-provenance-correction':1},'check_count':len(checks),'failed_checks':[x for x in checks if not x['passed']],'checks':checks,'preferred_report':str(newpath),'preferred_report_sha256':sha(newpath),'preferred_report_recorded_at':newreport['recorded_at'],'source_correction_receipt':final['correction_receipt'],'original_findings_status':'Both original provenance/display issues resolved by append-only frozen correction and report2; originals retained.','archive_ready':all(x['passed'] for x in checks),'notes':['All 35 actual frozen receipt hashes, previous-revision chains and chronological cutoffs passed. All freeze timestamps precede each relevant kickoff.','All 9 selected scores, 1 score/WDL abstention, 8 total directions, 2 total observations and exact TOP3 order are unchanged across selections/comprehensive/report1/report2.','Candidate matrices and original candidate numerical outputs are unchanged; independently recomputed Asian total settlement agrees with published figures.','Five optional context-b source path errors are preserved in original records and corrected by explicit immutable source-provenance-correction receipt, with existing source hashes verified.','Andorra remains primary=null. Report2 only clarifies all compared scores are alternatives, not recommendations.','Candidate index, eight artifacts and dependencies, active registry and execution-guard source hashes remain unchanged from preflight/candidate records. No independent Git commands used.','Audit PASS verifies integrity, facts and declared boundaries, not predictive accuracy, betting value or candidate promotion.']}
(R/'audit/delivery-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['status','receipt_count','check_count','failed_checks','archive_ready','preferred_report_recorded_at']},ensure_ascii=False,indent=2))
