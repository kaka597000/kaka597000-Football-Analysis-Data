import json, hashlib, datetime
from pathlib import Path
B=Path('/workspace/WCPP/reports/nations-prematch-20261113-2118')
A=B/'audit'
def read(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def stats(rows):
 return {'n':len(rows),'W':sum(r['goals_for']>r['goals_against'] for r in rows),'D':sum(r['goals_for']==r['goals_against'] for r in rows),'L':sum(r['goals_for']<r['goals_against'] for r in rows),'GF':sum(r['goals_for'] for r in rows),'GA':sum(r['goals_against'] for r in rows),'scored':sum(r['goals_for']>0 for r in rows),'scoreless':sum(r['goals_for']==0 for r in rows),'clean_sheets':sum(r['goals_against']==0 for r in rows),'btts':sum(r['goals_for']>0 and r['goals_against']>0 for r in rows),'total_3plus':sum(r['goals_for']+r['goals_against']>=3 for r in rows)}
source_teams={}; issues=[]; source_hashes={}
for p in sorted((B/'schedule/summaries').glob('*.json')):
 source_hashes[str(p.relative_to(B))]=sha(p)
 for t in read(p)['lastFiveGames']:
  tid=str(t['team']['id']);rows=[]
  for e in t['events']:
   home=str(e['homeTeamId'])==tid
   assert tid in [str(e['homeTeamId']),str(e['awayTeamId'])]
   gf=int(e['homeTeamScore'] if home else e['awayTeamScore']);ga=int(e['awayTeamScore'] if home else e['homeTeamScore'])
   rows.append({'event_id':e['id'],'date':e['gameDate'],'home_away':'H' if home else 'A','opponent_id':e['opponent']['id'],'opponent':e['opponent']['displayName'],'goals_for':gf,'goals_against':ga,'score_for_team':f'{gf}-{ga}','score_derived_result':'W' if gf>ga else 'L' if gf<ga else 'D','raw_game_result':e['gameResult'],'competition':e['competitionName'],'phase':e.get('roundName'),'raw_shootout':{'home':e.get('homeShootoutScore'),'away':e.get('awayShootoutScore')}})
  primary=[r for r in rows if r['competition']=='2026-27 UEFA Nations League' and r['phase']=='League Phase']
  source_teams[(p.stem,tid)]={'fixture_id':p.stem,'team_id':tid,'team':t['team']['displayName'],'source_file':str(p.relative_to(B)),'recent':rows,'primary':stats(primary),'primary_home_away':{side:stats([r for r in primary if r['home_away']==side]) for side in ['H','A']},'supplemental_excluded':[r for r in rows if r not in primary]}
def issue(kind,fixture,team,event,field,actual,expected,path):issues.append({'kind':kind,'fixture':fixture,'team':team,'event_id':event,'field':field,'actual':actual,'expected':expected,'file':str(path.relative_to(B))})
p=B/'context-a/recent-form-process.json';source_hashes[str(p.relative_to(B))]=sha(p)
for fixture in read(p)['fixtures']:
 for t in fixture['teams']:
  raw=source_teams[(str(fixture['event_id']),str(t['team_id']))];byid={r['event_id']:r for r in raw['recent']}
  for r in t['recent5']:
   rr=byid[r['event_id']]
   for k,expected in [('score_for_against',rr['score_for_team']),('opponent',rr['opponent']),('outcome',rr['score_derived_result']),('competition',rr['competition']),('phase',rr['phase'])]:
    if r.get(k)!=expected: issue('derived_row_mismatch',fixture['event_id'],t['team'],r['event_id'],k,r.get(k),expected,p)
  ps=raw['primary'];expected={'matches':ps['n'],'w_d_l':f"{ps['W']}-{ps['D']}-{ps['L']}",'goals_for':ps['GF'],'goals_against':ps['GA'],'zero_goals':ps['scoreless'],'clean_sheets':ps['clean_sheets'],'both_teams_scored':ps['btts'],'total_goals_3plus':ps['total_3plus']}
  for k,v in expected.items():
   if t['primary_competition_window'].get(k)!=v:issue('primary_summary_mismatch',fixture['event_id'],t['team'],None,k,t['primary_competition_window'].get(k),v,p)
for p in sorted((B/'context-b').glob('401*.json')):
 source_hashes[str(p.relative_to(B))]=sha(p);fixture=read(p)
 for t in fixture['teams']:
  raw=source_teams[(str(fixture['match_id']),str(t['team_id']))];byid={r['event_id']:r for r in raw['recent']}
  for r in t['recent_five_oldest_to_newest']:
   rr=byid[r['event_id']]
   for k,expected in [('goals_for',rr['goals_for']),('goals_against',rr['goals_against']),('home_away',rr['home_away']),('opponent',rr['opponent']),('opponent_id',rr['opponent_id']),('result',rr['score_derived_result']),('competition',rr['competition'])]:
    if r.get(k)!=expected:issue('derived_row_mismatch',fixture['match_id'],t['team'],r['event_id'],k,r.get(k),expected,p)
  for area,rs in [('window_overall',raw['recent']),('H',[r for r in raw['recent'] if r['home_away']=='H']),('A',[r for r in raw['recent'] if r['home_away']=='A'])]:
   expected=stats(rs);actual=t['window_overall'] if area=='window_overall' else t['home_away_windows'][area]
   for k,v in actual.items():
    if k in expected and v!=expected[k]:issue('summary_mismatch',fixture['match_id'],t['team'],None,area+'.'+k,v,expected[k],p)
report={'audit_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Local read-only review. Source identities are ESPN team IDs; goals_for/goals_against are reconstructed from homeTeamId/awayTeamId rather than score string. Primary window is exactly current 2026-27 UEFA Nations League League Phase; all other competition rows excluded.','source_hashes':source_hashes,'automated_issues':issues,'teams':list(source_teams.values()),'limitations':['Source schedule lastFiveGames does not independently certify 90-minute period for non-league-phase games. Knockout World Cup matches are excluded from primary window.','Latest event-process samples may be from friendlies for League D teams; do not promote them to current Nations League process.','Narrative support and counterpath errors are listed separately in the Markdown audit.']}
(A/'recent-form-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('automated issues',len(issues))
for i in issues:print(json.dumps(i,ensure_ascii=False))
for t in report['teams']:print(t['team'],t['primary'])
