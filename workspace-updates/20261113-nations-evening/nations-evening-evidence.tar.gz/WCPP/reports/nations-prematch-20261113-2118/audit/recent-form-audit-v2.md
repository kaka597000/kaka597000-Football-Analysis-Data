# 近期赛果修订后独立复核 V2

复核UTC：2026-11-13T13:35:34.882731+00:00。结论：**PASS**。

初版 recent-form-audit.json / .md / .py 均保留；V2 是追加复核，未覆盖最初16处错名和7条文案发现。

- 最初16处对手名错误全部按原始ESPN球队ID更正。
- 最初7条错误文案全部修订；对手、胜负方向及数量已重新逐句对照源赛果。
- context-b新增本届欧国联主窗口、主客拆分及赛事集合共30项通过。
- 20队100条结构化近期赛果继续通过；98项过程字段按球队ID比对通过。
- 50条Markdown近期赛果与25条支持/反证文案共75项与修订JSON一致。
- 世界杯、友谊赛仍隔离；D组三队制的实际2/3场窗口保留。

本次复核可复现脚本：recent-form-audit-v2.py。运行该脚本仅写 recent-form-audit-v2.json，不覆盖首次审计。JSON保留全部98条过程字段比较、初版各源SHA、修订后各源SHA、16条原始发现及各自复核状态。

首次审计JSON SHA-256：`b39fc042be57074ccc2aa4da55ca67ec7a6e21624c85818fc10d50f3b99603b1`

|修订文件|初版SHA-256|修订后SHA-256|
|---|---|---|
|context-b/401861153.json|22602f6deb82350060cfab285bba258e522d08df7040aafef499d4ec0406099b|52e9967100e8a1ca5fc82923b51f9c4ac1be7cd8803b4353b3fa5eb8581855ce|
|context-b/401861154.json|da34c0766292e95d7535a4ca5947b7614ddadab77f298535215eb4383658d314|f77eaa1d4b0806c8d7efa0c7dbfbed6103b076d31c9e2c97ae3fdf882ac72a0f|
|context-b/401861155.json|abcd7cd6712d088ae0900d15b5e4a45a8459e9726cc8068bf4d43c78ee570f3b|f3187f0037552b779dd217515d7097248ee73404d5531097e6c344a57d54e46b|
|context-b/401861160.json|5cea6e8b00be1440c2480f9c2e139ae753e9df602619b2529bbfd583a364be31|669e1854b230e639e94f53f228f537fe9a1a70b0f0c6a9d8bab47c1da6faa62b|
|context-b/401861162.json|0b70976ec353ebdc9343eafc7d19f62e02d0e795212f2f1566d69e21d3ab2a3e|30dd1a132eb0a808929c63a22c62ea55e519ff8601d444a4b7fea4cf3eb8e167|

注意：PASS针对本地事实、口径与修复一致性，不证明预测有效性，不作比分选择。
