"""Audit supplied selections, without choosing scores or changing the inputs."""
import json
import hashlib
from datetime import datetime, timezone
from pathlib import Path
R=Path(__file__).resolve().parents[1]
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
selection_path=R/'selections.json'
selections=read(selection_path)
diagnostics={r['match_id'].split(':')[-1]:r for r in read(R/'candidate-diagnostics.json')}
markets={r['match_id'].split(':')[-1]:r for r in read(R/'market/pinnacle-markets.json')['matches']}
checks=[]
def ck(ok,label):checks.append({'label':label,'passed':bool(ok)})
ck(set(selections)==set(diagnostics)==set(markets),'same ten fixtures in selection/candidate/market')
for eid,s in selections.items():
    d=diagnostics[eid]
    ck(s['expected_line']==markets[eid]['pinnacle_totals']['line'],eid+': real Pinnacle line')
    ck(bool(s['total_reason']) and bool(s['three_plus_path']) and bool(s['counter']),eid+': independent total path and counterevidence provided')
    if s['primary'] is None:
        ck(s['wdl']=='观望',eid+': abstention is not a score choice')
        continue
    ck(s['primary'] in s['compared_scores'] and len(set(s['compared_scores']))>=2,eid+': selected score in candidate comparison')
    home,away=map(int,s['primary'].split('-'))
    for side,goals in [('home',home),('away',away)]:
        if goals==0:
            evidence=s['zero_vs_one'].get(side,{})
            ck(bool(evidence.get('reason')) and bool(evidence.get('counterevidence')),eid+': '+side+' zero-vs-one support and counterevidence')
    if d['current']['primary']==d['test']['primary']!=s['primary']:
        ck(len(set(s['non_market_evidence_types']))>=2,eid+': common candidate override cites two nonmarket classes')
    if any(r['distribution_audit']['joint_mode_total']<=2 and r['distribution_audit']['p_total_ge_3']>0.5 for r in [d['current'],d['test']]):
        ck(any(sum(map(int,score.split('-')))>=3 for score in s['compared_scores']),eid+': mandatory three-plus candidate compared')
    if s['total_direction']=='大' and s['expected_line']>2.75:
        ck(False,eid+': manual both-team-two-goal path audit required')
ck('合计2个队伍进球' in selections['401861155']['total_reason'],'repair: Andorra + Gibraltar current competition GF is 2')
ck('两次对塞尔维亚均进2球' in selections['401861159']['reason'],'repair: Netherlands head-to-head wording is chronologically accurate')
ck('本场主场' in selections['401861161']['reason'] and '回主场' not in selections['401861161']['reason'],'repair: Scotland last game was already home')
ck('小3.25在3球时半赢' in selections['401861158']['three_plus_path'],'repair: under 3.25 at three goals is half win')
report={
 'audited_at':datetime.now(timezone.utc).isoformat(),
 'selection_sha256':sha(selection_path),
 'status':'PASS_WITH_EXPLICIT_LIMITATIONS' if all(c['passed'] for c in checks) else 'FAIL',
 'check_count':len(checks),'checks':checks,
 'manual_fact_review':{
  'recent_form_and_home_away':'All current Nations League WDL/GF/GA/venue/clean-sheet claims checked against summary explicit homeTeamId/awayTeamId and scores. Three narrative errors detected and corrected before this SHA.',
  'process':'All cited shots/shots on target and Switzerland eight corners checked against raw boxscore team IDs. These are observed process statistics, not xG.',
  'candidate_numbers':'Quoted total means and home/away means and zero probabilities agree with candidate-diagnostics rounding. North Macedonia test P0=.4237706 exceeds P1=.3638338.',
  'double_candidate_overrides':'Netherlands, Germany and Switzerland each identify results/home-away paths and recent shot process as distinct nonmarket evidence classes; material counterevidence remains stated. This is not a proof of prediction improvement.',
  'asian_settlement':'Over2 pushes at 2; under1.75 half loses at 2; under2.25 half wins at 2; under3 pushes at 3; under3.25 half wins at 3. The final wording is consistent.',
  'top3_scope':'Proposed Liechtenstein-Azerbaijan 0-1/under2.25, Scotland-North Macedonia 2-0/under3, Slovakia-Faroe Islands 2-1/over2.5 are research choices. Slovakia totals confidence is explicitly lower than WDL; no claim of uniform reliability or model promotion is supported.'
 },
 'first_pass_findings_preserved':[
  {'match_id':'401861155','field':'total_reason','original_issue':'Andorra plus Gibraltar claimed 3 team goals; true total is 2','status':'CORRECTED'},
  {'match_id':'401861159','field':'reason','original_issue':'Netherlands last two games claimed both vs Serbia; actual last two were Greece then Serbia','status':'CORRECTED'},
  {'match_id':'401861161','field':'reason','original_issue':'Scotland return-home wording; latest fixture was already home','status':'CORRECTED'},
  {'match_id':'401861158','field':'three_plus_path','original_issue':'Three-goal under3.25 settlement was loosely described as half push; now explicitly half win','status':'CLARIFIED'}
 ],
 'limitations':[
  'This audit verifies facts and reasoning completeness, not score choice quality, calibrated accuracy, or expected betting value.',
  'No verified current xG series, confirmed lineup/injury list or full club workload has been obtained; selections retain these unknowns.',
  'Evidence comes from small current-competition windows and mostly one latest process sample. Two evidence classes do not create two independent calibrated predictors.',
  'Selections are candidate_research only. Final freeze reference integrity, ranking payload and timestamps must be checked separately after root writes them.'
 ]}
(R/'audit/selection-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['status','selection_sha256','check_count']},ensure_ascii=False))
