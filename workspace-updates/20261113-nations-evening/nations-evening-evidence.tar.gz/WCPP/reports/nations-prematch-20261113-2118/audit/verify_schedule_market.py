"""Read-only source audit. Writes only into this report's audit directory."""
import hashlib
import json
import re
from datetime import datetime, timezone, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'audit'
def read(path):
    return json.loads(Path(path).read_text())
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def dt(value):
    return datetime.fromisoformat(value.replace('Z', '+00:00'))
issues = []
checks = []
def check(ok, label, detail=None):
    checks.append({'label': label, 'passed': bool(ok), 'detail': detail})
    if not ok:
        issues.append({'label': label, 'detail': detail})

fixtures = read(ROOT / 'schedule/fixtures.json')
manifest = {x['event_id']: x for x in read(ROOT / 'schedule/summary_manifest.json')}
scoreboard = {x['id']: x for x in read(ROOT / 'schedule/raw/scoreboard_20261113_timed.json')['events']}
schedule_rows = []
groups = {}
for fixture in fixtures:
    eid = fixture['source_event_id']
    source = ROOT / f'schedule/summaries/{eid}.json'
    summary = read(source)
    header = summary['header']
    comp = header['competitions'][0]
    teams = {x['homeAway']: x['team'] for x in comp['competitors']}
    level, group_number = re.search(r'Group ([ABCD])(\d+)', comp['altGameNote']).groups()
    group = level + group_number
    check(sha(source) == manifest[eid]['sha256'] == fixture['phase_evidence']['source_sha256'], f'{eid}: summary raw SHA')
    check(header['id'] == eid == comp['id'], f'{eid}: event IDs')
    check(fixture['home'] == 'espn:' + teams['home']['id'] and fixture['away'] == 'espn:' + teams['away']['id'], f'{eid}: home/away IDs')
    check(dt(fixture['kickoff_at']) == dt(comp['date']) == dt(scoreboard[eid]['date']), f'{eid}: kickoff')
    check(header['league']['slug'] == 'uefa.nations' and header['season']['year'] == 2026 and 'League Phase' in header['season']['name'], f'{eid}: season and phase')
    check(comp['status']['type']['state'] == 'pre' and not comp['status']['type']['completed'] and fixture['phase'] == 'PreMatch', f'{eid}: prematch')
    check(fixture['cohort'] == f'uefa.nations:{level}:league-phase' and fixture['league_level'] == level, f'{eid}: level')
    check(fixture['neutral'] == comp['neutralSite'], f'{eid}: venue neutrality')
    check(dt(manifest[eid]['requested_at']) <= dt(manifest[eid]['captured_at']) <= dt(fixture['cutoff_at']) < dt(fixture['kickoff_at']), f'{eid}: summary temporal order')
    rows = []
    for entry in summary['standings']['groups'][0]['standings']['entries']:
        stats = {x['name']: x.get('value', x.get('summary')) for x in entry['stats']}
        row = {'id': entry['id'], 'name': entry['team'], **{key: int(stats[key]) for key in ['gamesPlayed', 'points', 'wins', 'ties', 'losses', 'rank', 'pointDifferential']}}
        row['remaining_if_double_round_robin'] = 2 * (len(summary['standings']['groups'][0]['standings']['entries']) - 1) - row['gamesPlayed']
        row['max_points_if_double_round_robin'] = row['points'] + 3 * row['remaining_if_double_round_robin']
        check(row['points'] == 3 * row['wins'] + row['ties'] and row['gamesPlayed'] == row['wins'] + row['ties'] + row['losses'], f'{eid}/{entry["id"]}: table arithmetic')
        rows.append(row)
    check(sum(row['pointDifferential'] for row in rows) == 0 and sum(row['wins'] for row in rows) == sum(row['losses'] for row in rows), f'{eid}: table balance')
    check({teams['home']['id'], teams['away']['id']} <= {row['id'] for row in rows}, f'{eid}: teams in table')
    if group in groups:
        check(groups[group]['teams'] == rows, f'{eid}: same-group table consistency')
        groups[group]['source_event_ids'].append(eid)
    else:
        groups[group] = {'source_event_ids': [eid], 'teams': rows}
    schedule_rows.append({'event_id': eid, 'home': teams['home']['displayName'], 'home_id': teams['home']['id'], 'away': teams['away']['displayName'], 'away_id': teams['away']['id'], 'group': group, 'kickoff_beijing': dt(comp['date']).astimezone(timezone(timedelta(hours=8))).isoformat(), 'phase': 'pre', 'source_sha256': sha(source)})

meta = read(ROOT / 'market/source-metadata.json')
channel = read(ROOT / 'market/market-channel.json')
cutoff = dt(channel['actual_cutoff_at'])
for kind, record in meta.items():
    check(sha(ROOT / 'market' / record['file']) == record['sha256'], f'market: {kind} raw SHA')
    check(dt(record['requested_at']) <= dt(record['captured_at']) <= cutoff, f'market: {kind} captured <= cutoff')
check(sha(ROOT / 'market/identity.json') == sha(ROOT / 'schedule/raw/scoreboard_20261113_timed.json'), 'market identity equals timed scoreboard bytes')
odds = {x['id']: x for x in read(ROOT / 'market/odds.json')}
def market(event, book, key):
    return next(m for b in event['bookmakers'] if b['key'] == book for m in b['markets'] if m['key'] == key)
def norm(event, m):
    names = {event['home_team']: 'home', event['away_team']: 'away', 'Draw': 'draw', 'Over': 'over', 'Under': 'under'}
    return {names[x['name']]: x['price'] for x in m['outcomes']}
ages=[]
seen=set()
for snap in channel['snapshots']:
    target = snap['target']
    fixture = next(x for x in fixtures if x['match_id'] == target['match_id'])
    check(target['home_id'] == fixture['home'] and target['away_id'] == fixture['away'] and target['cohort'] == fixture['cohort'], target['match_id'] + ': snapshot identity')
    check(dt(target['cutoff_at']) == cutoff < dt(target['kickoff_at']), target['match_id'] + ': snapshot cutoff')
    for obs in snap['observations']:
        value = obs['value']
        event = odds[obs['provider_match_id']]
        m = market(event, value['bookmaker'], value['market'])
        key = (target['match_id'], value['bookmaker'], value['market'], value.get('line'))
        source_teams = {x['homeAway']: x['team']['displayName'] for x in scoreboard[fixture['source_event_id']]['competitions'][0]['competitors']}
        check(event['home_team'] == source_teams['home'] and event['away_team'] == source_teams['away'], str(key) + ': market names match ESPN home/away')
        check(key not in seen, str(key) + ': no duplicate observation')
        seen.add(key)
        check(value['odds'] == norm(event, m) and value['quoted_at'] == m['last_update'], str(key) + ': odds/quote time exact raw match')
        check(dt(event['commence_time']) == dt(target['kickoff_at']), str(key) + ': market kickoff')
        if value['market'] == 'h2h':
            check(set(value['odds']) == {'home', 'away', 'draw'}, str(key) + ': complete 1X2')
        else:
            check(set(value['odds']) == {'over', 'under'} and {x['point'] for x in m['outcomes']} == {value['line']}, str(key) + ': complete same-line totals')
        age = (cutoff - dt(value['quoted_at'])).total_seconds()
        ages.append(age)
        check(0 <= age <= 3600 and dt(value['quoted_at']) <= dt(meta['odds']['captured_at']), str(key) + ': quote temporal bounds')
        check(obs['evidence']['sha256'] == meta['odds']['sha256'] and obs['identity_evidence']['sha256'] == meta['identity']['sha256'], str(key) + ': evidence SHA references')
check(len(seen) == channel['verified_quote_count'] == 272, 'market: verified count')
pinnacle = read(ROOT / 'market/pinnacle-markets.json')
pinnacle_rows=[]
for row in pinnacle['matches']:
    event=odds[row['source_event_id']]
    check(row['home'] == event['home_team'] and row['away'] == event['away_team'], row['match_id'] + ': Pinnacle names')
    for name,key in [('pinnacle_h2h','h2h'),('pinnacle_totals','totals')]:
        m=market(event,'pinnacle',key)
        check(row[name]['odds'] == norm(event,m) and row[name]['quoted_at'] == m['last_update'], row['match_id'] + ': ' + name + ' raw match')
        if key=='totals':
            check({x['point'] for x in m['outcomes']} == {row[name]['line']}, row['match_id'] + ': Pinnacle same two-side line')
        else:
            denom=sum(1 / value for value in row[name]['odds'].values())
            check(all(abs(row[name]['no_vig_probabilities'][side] - 1/value/denom) <= 0.00000051 for side,value in row[name]['odds'].items()),row['match_id'] + ': Pinnacle no-vig arithmetic')
    pinnacle_rows.append({'match_id':row['match_id'],'home':row['home'],'away':row['away'],'line':row['pinnacle_totals']['line'],'over':row['pinnacle_totals']['odds']['over'],'under':row['pinnacle_totals']['odds']['under'],'quoted_at':row['pinnacle_totals']['quoted_at']})

comparison=read(ROOT / 'market/same-event-line-comparison.json')
prior_meta=read(Path(comparison['prior_source']).parent/'source-metadata.json')['odds']
check(prior_meta['sha256'] == comparison['prior_sha256'] and prior_meta['requested_at'] == comparison['prior_requested_at'] and prior_meta['captured_at'] == comparison['prior_captured_at'], 'history: timestamps/hash match original metadata')
prior=read(comparison['prior_source'])
prior={x['id']:x for x in prior}
check(sha(comparison['prior_source']) == comparison['prior_sha256'], 'history: prior raw SHA')
check(comparison['current_source_sha256'] == meta['odds']['sha256'], 'history: current raw SHA')
pin_comparisons=[]
for row in comparison['comparisons']:
    eid=row['source_event_id']
    old,new=prior[eid],odds[eid]
    ident=['home_team','away_team','commence_time']
    check(all(old[k] == new[k] == row[k] for k in ident),f'history {eid}: same event sides/kickoff')
    for label,event,cap_key in [('old',old,'prior_captured_at'),('current',new,'current_captured_at')]:
        m=market(event,row['bookmaker'],row['market'])
        check(row[label]['odds'] == {x['name']:x['price'] for x in m['outcomes']} and row[label]['quoted_at'] == m['last_update'], f'history {eid}/{row["bookmaker"]}/{row["market"]}/{label}: raw values')
        if row['market']=='totals':
            check({x['point'] for x in m['outcomes']} == {row['line']} == {row[label]['line']}, f'history {eid}/{row["bookmaker"]}: same line')
        age=(dt(comparison[cap_key])-dt(row[label]['quoted_at'])).total_seconds()
        check(0 <= age <=3600, f'history {eid}/{row["bookmaker"]}/{label}: quote age at capture')
    check(dt(row['old']['quoted_at']) < dt(row['current']['quoted_at']) <= cutoff, f'history {eid}/{row["bookmaker"]}: chronological quotes')
    if row['bookmaker']=='pinnacle':
        pin_comparisons.append(row)
check(len(comparison['comparisons']) == comparison['comparison_count'] == 257, 'history: comparison count')
report={'audited_at':datetime.now(timezone.utc).isoformat(),'status':'PASS' if not issues else 'FAIL','check_count':len(checks),'issues':issues,'schedule':schedule_rows,'groups':groups,'market_cutoff':cutoff.isoformat(),'market_raw_sha256':meta['odds']['sha256'],'market_quote_count':len(seen),'market_quote_age_range_seconds':[min(ages),max(ages)],'pinnacle':pinnacle_rows,'pinnacle_same_line_comparisons':pin_comparisons,'warnings':['Original schedule fixture cutoff precedes final market identity capture; root must use final cutoff or later for new model inputs.','Remaining games and maximum points are explicitly conditional on double round robin. This audit has not independently loaded official 2026-27 competition rules/tiebreaks. Do not infer clinched promotion/relegation or must-win from points alone.','Historical quotes are valid at their historical capture time; they are not fresh current quotes.','Raw lastFiveGames.score and matchNote are not safe canonical home-away or promotion fields. Use homeTeamScore/awayTeamScore and IDs.'],'checks':checks}
(OUT/'schedule-market-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({key:report[key] for key in ['status','check_count','issues','market_cutoff','market_quote_count','market_quote_age_range_seconds','pinnacle']},ensure_ascii=False,indent=2))
