"""One-time source-bound forecast publication; no fitting, model promotion or parameter edits."""
import csv,hashlib,json,sys
from pathlib import Path
from datetime import datetime,timezone
from zoneinfo import ZoneInfo
import numpy as np
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from prediction_engine import predict_models
from research.analysis_freeze import save,verify
from research.team_goal_analysis import summarize_prediction
from research.score_distribution_audit import audit_prediction
from research.market_movement import analyze
from v2.model import total_settlement
R=Path(__file__).resolve().parent; FREEZES=Path('/workspace/WCPP/forecasts/issued-analyses');BJT=ZoneInfo('Asia/Shanghai')
SOURCE='1257fdde7b6746b7ba6d2aa919382214a2cfb589'
def read(p):return json.loads(Path(p).read_text())
def write(p,x):
 with Path(p).open('x') as h:json.dump(x,h,ensure_ascii=False,indent=2,allow_nan=False)
def now():return datetime.now(timezone.utc).isoformat()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def bt(t):return datetime.fromisoformat(t.replace('Z','+00:00')).astimezone(BJT).strftime('%m-%d %H:%M:%S')
choices=read(R/'selections.json');fs=read(R/'prepared-fixtures.json');recs=read(R/'candidate-update/receipts.json');quotes={v['match_id']:v for v in read(R/'market/pinnacle-markets.json')['matches']};form=read(R/'audit/recent-form-audit-v2.json')
# The original independently reconstructed source window remains the authority for numerical form.
forms=read(R/'audit/recent-form-audit.json')['teams']
registry_sha=sha('/workspace/WCPP/runtime/active-model.json')
assert registry_sha=='923e34fc44cda33fe965498a24a2435abb37a01a80c539108d8ec20d490bf013'
all_records=[]
# Verify every active refusal before issuing any of the comprehensive records.
for f in fs:
 try:predict_models(dict(f,cutoff_at=now()))
 except ValueError as e:assert str(e)=='no validated identity/history model for this cohort'
 else:raise ValueError('active route changed; must review before publication')
for f,receipt in zip(fs,recs):
 mid=f['match_id'];choice=choices[f['source_event_id']];q=f['total_quote'];assert choice['expected_line']==q['line']
 pair=read(R/'candidate-update'/(mid.replace(':','-')+'.json'))
 failed={'status':'ABSTAIN_NO_ACTIVE_ROUTE','matrix':None,'primary':None,'input':f}
 active=save({'current_model':dict(failed,model_label='当前模型'),'test_model':dict(failed,model_label='test模型'),'active_registry_sha256':registry_sha,'candidate_substitution':False},dict(f,cutoff_at=now()),stage='prematch',track='current-test-pair',root=FREEZES)
 cand={}
 for role in ['current','test']:
  p=pair[role];cand[role]=dict(p,team_goal_analysis=summarize_prediction(p),score_distribution_audit=audit_prediction(p,choice['primary']) if choice['primary'] else audit_prediction(p))
  cand[role]['actual_total_settlement']={side:total_settlement(np.asarray(p['matrix']),q['line'],side) for side in ['over','under']}
 payload=dict(choice,selection_scope='candidate_research',method_version='WCPP-NATIONS-MANUAL-20261113-1',status='RESEARCH_COMPREHENSIVE' if choice['primary'] else 'ABSTAIN_SCORE_AND_WDL_UNEXPLAINED_DISAGREEMENT',total_line=q['line'],actual_quote=q,current_test_reference=active,candidate_reference=receipt,candidate_status='UNACCEPTED_RESEARCH_ONLY',candidate_outputs=cand,selection_evidence={k:choice[k] for k in ['compared_scores','zero_vs_one','three_plus_path','total_reason']},sources={'fixture':f['phase_evidence'],'form':'audit/recent-form-audit.json','correction_audit':'audit/recent-form-audit-v2.json','context_a':'context-a/recent-form-process.json','context_b':'context-b/'+f['source_event_id']+'.json','availability_a':'context-a/raw/web/availability-web.json','market':'market/source-metadata.json'},current_edition_form=[x for x in forms if x['fixture_id']==f['source_event_id']],market_movement=analyze(dict(f,cutoff_at=now())),xg_status='NO_VERIFIED_CURRENT_SAME_PROVIDER_XG',full_club_workload='NOT_VERIFIED',formal_kpi_eligible=False,active_model_promotion=False,numerical_weights_changed=False,exact_score_basis='regulation_90')
 receipt_c=save(payload,dict(f,cutoff_at=now()),stage='prematch',track='comprehensive',root=FREEZES)
 record=verify(read(receipt_c['path']));assert record['selection_audit']['top3_ready']==bool(choice['primary']),record['selection_audit']
 all_records.append({'fixture':f,'payload':payload,'candidate_receipt':receipt,'active_receipt':active,'comprehensive_receipt':receipt_c})
byid={x['fixture']['source_event_id']:x for x in all_records}
top_ids=['401861153','401861161','401861160'];top_items=[]
for rank,id in enumerate(top_ids,1):
 x=byid[id];p=x['payload'];top_items.append(dict(rank=rank,match_id=x['fixture']['match_id'],**{k:p[k] for k in ['primary','wdl','total_line','total_direction']},comprehensive_reference=x['comprehensive_receipt'],reason=p['reason'],risk=p['counter']))
shell={'match_id':'nations-analysis-batch:20261113-evening','cohort':'uefa.nations','kickoff_at':min(f['kickoff_at'] for f in fs),'cutoff_at':now()}
top=save({'selection_scope':'candidate_research','population':[f['match_id'] for f in fs],'top3':top_items,'ranking_basis':'人工研究优先级：球队进球路径、事实一致性与反证；不声称已校准精确比分命中率排名','formal_kpi_eligible':False,'active_model_promotion':False},shell,stage='prematch',track='top3-selection',root=FREEZES)
lines=['# 欧国联今晚赛前分析｜2026年11月13日晚','',
'范围：欧洲11月13日比赛日10场；北京时间11月14日01:00和03:45开球。北京时间11月13日早间已完赛的8场不在本次赛前样本。全部按90分钟含补时、无加时点球口径。',
'本版数据查询始于北京时间21:18左右，Pinnacle全部报价时间为11月13日21:20:52，实际抓取21:21:01；独立赛程身份补抓21:23:18。今晚10场全部匹配，共272条机构市场观测通过身份/来源/时间/同线校验。它不是272场或272个独立样本。只验证今晚10场，不将原始API里的27场一概称为验证通过。',
'模型状态：欧国联活动Current/Test无已验收路由，10场均实际调用并冻结拒绝输出。以下Current候选只拟合等级均值与主场项；Test候选另拟合球队攻防（半衰期730日、正则8）。均是未验收研究候选，未晋级。A/B/C训练截至10月6日，D截至10月4日；没有本轮人员、真实xG、盘口或完整俱乐部负荷训练特征。',
'两候选数值独立保存；本轮候选追加为11月10日首版后的v2，不覆盖首版，也不增加比赛分母。综合人工判断另轨、逐场首版冻结；不手改模型概率、进球均值或融合权重。TOP3为研究优先级，非经历史命中率验证的排名。',
'主窗口只用2026-27欧国联League Phase：A/B/C每队4场，D各2—3场。已逐场按球队ID核对主客/比分方向，排除世界杯及友谊赛。没有可靠同源近期xG/xGA；射门不等于xG。没有本轮可靠首发与伤停正文，不能称全员健康。国家队赛程间隔不代表球员实际休息。','',
'## 全部比赛','',
'大小球按实际盘口分别判断，允许与唯一点比分的进球和不同；整数线有走盘，四分之一线有半赢半输。以下不是已校准收益或命中率承诺。','',
'|北京时间11月14日|对阵|Current候选众数|Test候选众数|综合唯一比分|胜平负|实际大小球倾向|',
'|---|---|---|---|---|---|---|']
for x in all_records:
 f,p=x['fixture'],x['payload'];lines.append(f"|{bt(f['kickoff_at'])[6:11]}|{p['name']}|{p['candidate_outputs']['current']['primary']}|{p['candidate_outputs']['test']['primary']}|{p['primary'] or '观望'}|{p['wdl']}|{p['total_direction']} {p['total_line']:g}|")
lines+=['','## 研究TOP3','', '|顺序|比赛|唯一比分|胜平负|大小球|主要风险|','|---|---|---|---|---|---|']
risks=['此前交锋0-0；客胜低赔不等于比分可靠','苏格兰本届仅进3球，1-0是关键反证','法罗四连平；大2.5信心低于主胜，1-1/2-0均使大球失败']
for rank,id in enumerate(top_ids,1):
 p=byid[id]['payload'];lines.append(f"|{rank}|{p['name']}|{p['primary']}|{p['wdl']}|{p['total_direction']} {p['total_line']:g}|{risks[rank-1]}|")
lines+=['','TOP3选三场比赛，每场一个比分；不将每场备选比分包装成三次推荐。安道尔保留在完整10场分母，但比分/胜平负弃权，大小球独立研究。', '']
for x in all_records:
 f,p=x['fixture'],x['payload'];q=p['actual_quote'];books=quotes[f['match_id']];hq=books['pinnacle_h2h'];formrows=p['current_edition_form']
 lines+=['## '+p['name'],'',p['reason'],'','反证与风险：'+p['counter'],'','本届窗口：'+'；'.join(f"{z['team']} {z['primary']['n']}场{z['primary']['W']}胜{z['primary']['D']}平{z['primary']['L']}负、进{z['primary']['GF']}失{z['primary']['GA']}" for z in formrows)+'。','',
 '|候选|主队均值／中央80%区间|主队0球／≥2球／≥3球|客队均值／中央80%区间|客队0球／≥2球／≥3球|主胜／平局／客胜|','|---|---|---|---|---|---|']
 for role in ['current','test']:
  pred=p['candidate_outputs'][role];g=pred['team_goal_analysis'];cells=[]
  for side in ['home','away']:
   z=g[side];ci=z['central_interval'];cells+=[f"{z['mean']:.2f} / {ci['lower']}–{ci['upper']}球",' / '.join(f"{z[k]:.1%}" for k in ['p0','p_ge_2','p_ge_3'])]
  cells+=[' / '.join(f"{pred['wdl'][k]:.1%}" for k in ['主胜','平局','客胜'])];lines.append('|'+role+'|'+'|'.join(cells)+'|')
 lines+=['','均值和离散中央区间来自候选矩阵，不是提供方xG、校准置信区间或实际覆盖率。',
 '双方总球≥3概率：'+' / '.join(f"{role} {p['candidate_outputs'][role]['score_distribution_audit']['p_total_ge_3']:.1%}" for role in ['current','test'])+'。',
 '比分比较（仅首个综合唯一比分用于该轨命中评估，备选不叠加命中）：'+('、'.join(p['compared_scores']))+'。'+p['three_plus_path']]
 for side,entry in p['zero_vs_one'].items():lines+=['','零球对比一球（'+('主队' if side=='home' else '客队')+'）：'+entry['reason']+' 反证：'+entry['counterevidence']]
 lines+=['','大小球独立理由：'+p['total_reason'],'',f"Pinnacle 1X2：主{hq['odds']['home']} / 平{hq['odds']['draw']} / 客{hq['odds']['away']}；实际总球{q['line']:g}，大{q['over_odds']} / 小{q['under_odds']}。报价北京时间{bt(q['quoted_at'])}；抓取{bt(q['query_time'])}。"]
 if p['total_direction'] in ['大','小']:
  side='over' if p['total_direction']=='大' else 'under';lines+=['','候选矩阵在所选实际线的结算概率（研究值，非综合人工概率）：','', '|候选|全赢|半赢|走盘|半输|全输|','|---|---|---|---|---|---|']
  for role in ['current','test']:
   z=p['candidate_outputs'][role]['actual_total_settlement'][side];lines.append('|'+role+'|'+'|'.join(f'{z[k]:.1%}' for k in ['win','half_win','push','half_loss','loss'])+'|')
 for c in p['market_movement']['comparisons']:
  if c['market']!='1x2':continue
  odds=lambda d:' / '.join(str(d[k]) for k in ['home','draw','away'])
  lines+=['',f"同机构1X2历史对照（主/平/客）：{bt(c['first_quoted_at'])} 的 {odds(c['first_decimal_odds'])} → {bt(c['last_quoted_at'])} 的 {odds(c['last_decimal_odds'])}。只是报价变化，不推断资金流或内幕，也不作为独立因果证据。"]
 oldtotal=[t for t in f['market_snapshots'][:2] if t['market']=='totals']
 if oldtotal and oldtotal[0]['line']!=q['line']:lines+=['',f"总球历史线{oldtotal[0]['line']:g} → 当前{q['line']:g}；属于换线，未将两端不同盘线价格当同盘水位变化。"]
 lines+=['','人员与负荷：'+p['availability']+' 俱乐部比赛负荷、旅行与全量休息时间未核实。',f"赛程、主窗口及积分来源：[ESPN]({f['phase_evidence']['source_url']})。",f"综合冻结 `{x['comprehensive_receipt']['freeze_id']}`，北京时间{bt(x['comprehensive_receipt']['recorded_at'])}；候选 `{x['candidate_receipt']['freeze_id']}`（追加版）。",'']
lines+=['## 证据与复盘边界','',
'- 全10场赛程/市场原文与来源时间、SHA均留存；3599项赛程市场断言、100条近期结果方向及98个过程字段经独立复核。审计不是模型命中率验收。',
'- 初次资料整理出现对手姓名和文字赛果错误，已按原始ID与赛果修正；初版错误清单与修订后审计同时保留。正式结论只使用修正后事实。',
'- 采集人员B共27次HTTP请求，超原定25次2次，并与A重复采集2个summary；已停止重复请求，流程偏差保留记录。',
'- 研究TOP3、综合Primary、Current候选、Test候选与活动路由拒绝分别冻结。比赛尚未开赛，比分、胜平负、大小球均待结算，不填命中率。实际盘口结算必须报告全赢/半赢/走盘/半输/全输；弃权不删除整体覆盖分母。',
'- 候选本轮是修订v2，原11月10日首版仍作该候选轨默认评价版本。本轮综合与TOP3为各自首版，不能赛后从不同版本或备选比分中择优。',
'- 所有判断为当前证据下的研究输出；官方首发和最新伤停缺失，阵容后若更新则新增版本。没有修改活动注册表、历史冻结、模型参数，也未发布环境。',
'','源码版本：`'+SOURCE+'`；活动注册表SHA：`'+registry_sha+'`。','']
report='\n'.join(lines)
report_receipt=save({'report_markdown':report,'comprehensive_receipts':[x['comprehensive_receipt'] for x in all_records],'top3_receipt':top,'source_commit':SOURCE,'formal_kpi_eligible':False},dict(shell,cutoff_at=now()),stage='prematch',track='analysis-report',root=FREEZES)
(R/'欧国联赛前分析.md').write_text(report)
write(R/'analysis-records.json',all_records)
receipts=[x[k] for x in all_records for k in ['candidate_receipt','active_receipt','comprehensive_receipt']]+[top,report_receipt,read(R/'candidate-update/plan-receipt.json')]
for rr in receipts:assert verify(read(rr['path']))['record_sha256']==rr['sha256']
assert sha('/workspace/WCPP/runtime/active-model.json')==registry_sha
write(R/'delivery.json',{'report_receipt':report_receipt,'top3_receipt':top,'all_receipts':receipts,'population':10,'comprehensive_scores':9,'comprehensive_score_abstentions':1,'wdl_selections':9,'total_selections':8,'top3_count':3,'source_commit':SOURCE,'active_registry_changed':False,'verified_all_receipts':True,'all_before_kickoff':True})
with (R/'比赛分析展示.csv').open('x',encoding='utf-8-sig',newline='') as h:
 w=csv.writer(h);w.writerow(['北京时间','比赛','Current候选','Test候选','综合比分','胜平负','大小球方向','实际线','大赔率','小赔率','报价北京时间','综合冻结ID'])
 for x in all_records:
  f,p=x['fixture'],x['payload'];q=p['actual_quote'];w.writerow([bt(f['kickoff_at']),p['name'],p['candidate_outputs']['current']['primary'],p['candidate_outputs']['test']['primary'],p['primary'] or '观望',p['wdl'],p['total_direction'],q['line'],q['over_odds'],q['under_odds'],bt(q['quoted_at']),x['comprehensive_receipt']['freeze_id']])
print(json.dumps({'report':str(R/'欧国联赛前分析.md'),'report_freeze':report_receipt,'top3_freeze':top,'verified_receipts':len(receipts)},ensure_ascii=False))
