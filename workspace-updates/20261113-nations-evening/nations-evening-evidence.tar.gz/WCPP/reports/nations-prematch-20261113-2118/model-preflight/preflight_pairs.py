"""Pure candidate-pair computation helper. Does not train, publish, or freeze.
Run only after all fixtures and their source bytes have been verified by the root.
Output is deliberately separate from authoritative candidate freezes.
"""
import argparse, json, sys
from pathlib import Path
from datetime import datetime, timezone
sys.dont_write_bytecode=True
sys.path.insert(0, '/workspace/Football-Analysis')
sys.path.insert(0, '/workspace/Football-Analysis/runtime')
from runtime.nations_league import safe_cli
from research.team_goal_analysis import summarize_prediction
from research.score_distribution_audit import audit_prediction

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--index',default='/workspace/nations-model-20261110/models/candidates.json')
    p.add_argument('--fixtures',required=True)
    p.add_argument('--out',required=True)
    a=p.parse_args()
    target=Path(a.out)
    if target.exists(): raise FileExistsError(target)
    index=safe_cli.model.read(a.index); fixtures=safe_cli.model.read(a.fixtures)
    if not isinstance(fixtures,list) or not fixtures: raise ValueError('nonempty fixture list required')
    if len({f['match_id'] for f in fixtures})!=len(fixtures): raise ValueError('duplicate fixtures')
    for f in fixtures: safe_cli.validate_future(f)
    pairs=[]
    for supplied in fixtures:
        f={**supplied,'cutoff_at':datetime.now(timezone.utc).isoformat()}
        pair={};derived={}
        for role in ('current','test'):
            ref=index['routes'][f['league_level']][role]
            if safe_cli.model.sha(ref['path'])!=ref['sha256']: raise ValueError('index artifact mismatch')
            prediction=safe_cli.predict(ref['path'],f,expected_role=role)
            pair[role]=prediction
            derived[role]={'team_goal_analysis':summarize_prediction(prediction),'score_distribution_audit':audit_prediction(prediction)}
        pairs.append({'fixture':f,'predictions':pair,'derived_readonly':derived})
    result={'status':'PURE_COMPUTATION_NOT_FROZEN','formal_kpi_eligible':False,'active_route':False,'artifact_index_sha256':safe_cli.model.sha(a.index),'execution_guard':safe_cli.execution_guard(),'pairs':pairs}
    target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('x') as handle: json.dump(result,handle,ensure_ascii=False,indent=2,allow_nan=False); handle.write('\n')
    print(json.dumps({'computed':len(pairs),'path':str(target),'frozen':False}))
if __name__=='__main__': main()
