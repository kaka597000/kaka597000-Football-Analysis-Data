"""Read-only asset checks and pure calculations; no freeze, training, git or network."""
import sys, json, hashlib
from pathlib import Path
from datetime import datetime, timezone
sys.path.insert(0, '/workspace/Football-Analysis')
sys.path.insert(0, '/workspace/Football-Analysis/runtime')
from runtime.nations_league import safe_cli
from prediction_engine import predict_models
from research.team_goal_analysis import summarize_prediction
from research.score_distribution_audit import audit_prediction
OUT=Path(__file__).parent
sha=lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p: json.loads(Path(p).read_text())
def write(name, data):
    with (OUT/name).open('x') as f: json.dump(data,f,ensure_ascii=False,indent=2,allow_nan=False); f.write('\n')
index_path=Path('/workspace/nations-model-20261110/models/candidates.json')
index=read(index_path)
protocol=read('/workspace/nations-model-20261110/forward-freezes/protocol.json')
now=datetime.now(timezone.utc)
fixtures=[x for x in protocol['fixture_population'] if datetime.fromisoformat(x['kickoff_at'])>now]
registry_path=Path('/workspace/WCPP/runtime/active-model.json')
registry=read(registry_path)
active={'registry_path':str(registry_path),'registry_sha256':sha(registry_path),'registry_version':registry['version'],'routes_matching_nations':[x for x in registry['models'] if 'nations' in x],'test_type':'pure predict_models using retained real future source fixture; no publication CLI'}
fixture=dict(fixtures[0], cutoff_at=now.isoformat())
try:
    predict_models(fixture, str(registry_path))
    active['unexpected_execution']='SUCCESS'
except Exception as exc:
    active['exception_type']=type(exc).__name__; active['reason']=str(exc)
write('active-route-refusal.json',active)
checks=[]
for level, route in index['routes'].items():
    fixture=dict(next(f for f in fixtures if f['league_level']==level),cutoff_at=datetime.now(timezone.utc).isoformat())
    for role, ref in route.items():
        artifact=read(ref['path'])
        row={'level':level,'role':role,'path':ref['path'],'expected_sha256':ref['sha256'],'actual_sha256':sha(ref['path']),'artifact_hash_ok':sha(ref['path'])==ref['sha256']}
        row.update({k:artifact[k] for k in ['version','created_at','train_end','training_n','cohort','competition','stage','validation_status','formal_acceptance_passed','activation_allowed','trained_features','untrained_features','historical_asof_certified']})
        row['dependencies']={stem:{'path':artifact[stem+'_path'],'expected_sha256':artifact[stem+'_sha256'],'actual_sha256':sha(artifact[stem+'_path']),'ok':sha(artifact[stem+'_path'])==artifact[stem+'_sha256']} for stem in ['dataset','protocol','engine']}
        row['parameters']=artifact['core']
        row['evaluation_summary']=next(s for s in index['summary'] if s['level']==level)['quality_reasons']
        try:
            prediction=safe_cli.predict(ref['path'],fixture,expected_role=role)
            summary=summarize_prediction(prediction)
            audit=audit_prediction(prediction)
            row['load_check']={'status':'PASSED','fixture':fixture,'note':'Retained 2026-11-10 source; model availability recheck only, not current source confirmation or publication','prediction_version':prediction['version'],'primary_statistical_reference':prediction['primary'],'matrix_hash':prediction['matrix_hash'],'matrix_shape':[len(prediction['matrix']),len(prediction['matrix'][0])],'team_goal_analysis':summary,'score_distribution_audit':audit,'execution_guard':prediction['execution_guard']}
        except Exception as exc:
            row['load_check']={'status':'FAILED','exception_type':type(exc).__name__,'reason':str(exc)}
        checks.append(row)
write('artifacts-readonly-check.json',{'checked_at_utc':datetime.now(timezone.utc).isoformat(),'index_path':str(index_path),'index_sha256':sha(index_path),'no_freeze':True,'no_training':True,'no_artifact_mutation':True,'checks':checks})
print(json.dumps({'active':active,'artifact_count':len(checks),'hashes_ok':all(r['artifact_hash_ok'] and all(d['ok'] for d in r['dependencies'].values()) for r in checks),'load_statuses':[(r['level'],r['role'],r['load_check']['status']) for r in checks]},ensure_ascii=False))
