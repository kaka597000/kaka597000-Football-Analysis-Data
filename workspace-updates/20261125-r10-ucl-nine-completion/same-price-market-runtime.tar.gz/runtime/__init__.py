"""Pinned runtime namespace for exact market replay."""
