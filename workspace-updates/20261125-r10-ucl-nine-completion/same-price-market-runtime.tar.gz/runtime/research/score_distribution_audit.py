"""Read-only score-path diagnostics, with no forced increase in forecast goals.

A joint mode below a mean is a distribution property, not evidence of bias.
A manual score's probability is its mass in the referenced model, never a
calibrated probability for the independent comprehensive judgement.
"""
import re
from datetime import datetime
import json
from pathlib import Path
import numpy as np
try:
    from .team_goal_analysis import summarize_prediction
except ImportError:
    from team_goal_analysis import summarize_prediction

VERSION = 'WCPP-SCORE-DISTRIBUTION-AUDIT-0.3'
DECISION_POLICY = 'WCPP-COMPREHENSIVE-REPAIR-1'
PAIR_DIAGNOSTIC_VERSION = 'WCPP-CURRENT-TEST-DISAGREEMENT-0.1'
RESEARCH_SCOPE = 'candidate_research'


def parse_score(value):
    if isinstance(value, str) and re.fullmatch(r'\d+-\d+', value):
        return tuple(map(int, value.split('-')))
    if (isinstance(value, (list, tuple)) and len(value) == 2
            and all(type(x) is int and x >= 0 for x in value)):
        return tuple(value)
    raise ValueError('nonnegative integer home-away score required')


def _score_view(matrix, score):
    h, a = parse_score(score)
    if h >= matrix.shape[0] or a >= matrix.shape[1]:
        return {'score': f'{h}-{a}', 'status': 'OUTSIDE_MATRIX_SUPPORT'}
    p = float(matrix[h, a]); peak = float(matrix.max())
    return {'score': f'{h}-{a}', 'status': 'IN_MATRIX', 'model_probability': p,
            'probability_rank': int(np.sum(matrix > p)) + 1,
            'ties_at_probability': int(np.sum(matrix == p)),
            'relative_probability_to_joint_mode': p / peak,
            'probability_scope': 'REFERENCED_MODEL_NOT_COMPREHENSIVE_CALIBRATION'}


def _best(matrix, totals, predicate):
    mask = predicate(totals)
    if not mask.any() or float(matrix[mask].max()) <= 0:
        return None
    flat = int(np.argmax(np.where(mask, matrix, -1)))
    return _score_view(matrix, (flat // matrix.shape[1], flat % matrix.shape[1]))


def audit_prediction(prediction, comprehensive_primary=None):
    summary = summarize_prediction(prediction)
    if summary['status'] != 'AVAILABLE':
        return {'version': VERSION, 'status': 'UNAVAILABLE',
                'reason': summary['reason'], 'numeric_output_modified': False}
    matrix = np.asarray(prediction['matrix'], dtype=float)
    totals = np.add.outer(np.arange(matrix.shape[0]), np.arange(matrix.shape[1]))
    probabilities = np.bincount(totals.ravel(), weights=matrix.ravel(),
                                minlength=sum(matrix.shape) - 1)
    flat = int(np.argmax(matrix)); joint = (flat // matrix.shape[1], flat % matrix.shape[1])
    mean = summary['home']['mean'] + summary['away']['mean']
    total_mode = int(np.argmax(probabilities))
    flags = []
    if sum(joint) < mean:
        flags.append('JOINT_MODE_BELOW_MEAN_IS_NOT_BY_ITSELF_A_CALIBRATION_ERROR')
    if sum(joint) <= 2 and float(probabilities[3:].sum()) > .5:
        flags.append('LOW_JOINT_MODE_WITH_MAJORITY_MASS_AT_THREE_PLUS')
    result = {'version': VERSION, 'status': 'AVAILABLE',
              'matrix_sha256': summary['source_matrix_sha256'],
              'numeric_output_modified': False, 'primary_reordered': False,
              'total_probabilities': probabilities.tolist(), 'total_mean': mean,
              'total_mode': total_mode, 'joint_mode': f'{joint[0]}-{joint[1]}',
              'joint_mode_total': sum(joint),
              'joint_mode_total_minus_mean': sum(joint) - mean,
              'p_total_le_2': float(probabilities[:3].sum()),
              'p_total_ge_3': float(probabilities[3:].sum()),
              'p_total_ge_4': float(probabilities[4:].sum()),
              'p_home_zero': summary['home']['p0'], 'p_away_zero': summary['away']['p0'],
              'comparison_candidates_not_recommendations': {
                  'joint_mode': _score_view(matrix, joint),
                  'best_at_total_mode': _best(matrix, totals, lambda x: x == total_mode),
                  'best_three_plus': _best(matrix, totals, lambda x: x >= 3),
                  'best_four_plus': _best(matrix, totals, lambda x: x >= 4)},
              'flags': flags, 'comprehensive_selection': {'status': 'NOT_PROVIDED'}}
    train_end = prediction.get('training_data_cutoff')
    fixture = prediction.get('input', {})
    result['history_freshness'] = {
        'training_match_cutoff': train_end,
        'days_from_training_to_fixture': (datetime.fromisoformat(fixture['kickoff_at'][:10])
             - datetime.fromisoformat(train_end[:10])).days if train_end and fixture.get('kickoff_at') else None,
        'latest_available_matches_included': 'NOT_VERIFIED_BY_THIS_DIAGNOSTIC',
        'notice': 'Age alone does not establish missing matches; check verified current schedules.'}
    if comprehensive_primary is not None:
        selected = parse_score(comprehensive_primary); view = _score_view(matrix, selected)
        view.update(total_minus_mean=sum(selected)-mean,
                    home_change_from_joint_mode=selected[0]-joint[0],
                    away_change_from_joint_mode=selected[1]-joint[1],
                    total_change_from_joint_mode=sum(selected)-sum(joint),
                    zero_sides=[side for side, value in zip(('home','away'),selected) if value == 0])
        for side, index in [('home',0),('away',1)]:
            if selected[index] == 0:
                marginal = summary[side]['marginal']
                view[side+'_zero_comparison'] = {
                    'p0': marginal[0], 'p1': marginal[1] if len(marginal)>1 else 0.,
                    'p_ge_2': summary[side]['p_ge_2']}
        result['comprehensive_selection'] = view
    return result


def pair_disagreement(bundle):
    """Compare genuine current/test matrices without changing either forecast.

    Jensen-Shannon divergence is a descriptive difference between the two saved
    distributions.  It is not evidence independence, causal confidence, model
    quality, or permission to choose whichever Primary later wins.
    """
    if not isinstance(bundle, dict):
        raise ValueError('current/test bundle required')
    matrices = {}
    summaries = {}
    primary = {}
    for key in ('current_model', 'test_model'):
        prediction = bundle.get(key)
        if not isinstance(prediction, dict):
            raise ValueError('both current and test predictions are required')
        summary = summarize_prediction(prediction)
        summaries[key] = summary
        if summary['status'] != 'AVAILABLE':
            return {
                'version': PAIR_DIAGNOSTIC_VERSION,
                'status': 'NOT_READY',
                'reason': f'{key}:{summary["reason"]}',
                'changes_primary': False,
                'formal_kpi_eligible': False,
            }
        matrices[key] = np.asarray(prediction['matrix'], dtype=float)
        primary[key] = '-'.join(map(str, parse_score(prediction['primary'])))
    shapes = {matrix.shape for matrix in matrices.values()}
    if len(shapes) != 1:
        raise ValueError('current/test matrices require identical score support')
    stack = np.stack([matrices['current_model'], matrices['test_model']])
    average = stack.mean(axis=0)
    divergence = 0.0
    for matrix in stack:
        mask = matrix > 0
        divergence += float(np.sum(matrix[mask] * np.log(matrix[mask] / average[mask]))) / len(stack)
    return {
        'version': PAIR_DIAGNOSTIC_VERSION,
        'status': 'READY',
        'matrix_shape': list(stack.shape[1:]),
        'matrix_sha256': {key: summaries[key]['source_matrix_sha256'] for key in summaries},
        'primary_scores': primary,
        'primary_disagreement': len(set(primary.values())) > 1,
        'jensen_shannon_nats': max(0.0, divergence),
        'changes_primary': False,
        'formal_kpi_eligible': False,
        'is_calibrated_confidence': False,
        'independent_evidence_count': None,
        'interpretation': 'Distribution disagreement diagnostic only; never best-of-two selection evidence.',
    }


def attach_pair(bundle):
    audits = {k: audit_prediction(bundle[k]) for k in ('current_model','test_model')}
    disagreement = pair_disagreement(bundle)
    for k, value in audits.items():
        bundle[k]['score_distribution_audit'] = value
    bundle['current_test_disagreement'] = disagreement
    return bundle


def comprehensive_audit(payload, pair):
    """Check documented comparisons; completeness is not validation of judgement."""
    primary = payload.get('primary')
    if primary is None:
        return {'version': VERSION, 'status': 'ABSTAIN', 'top3_ready': False,
                'missing_comparisons': [], 'reason': 'NO_COMPREHENSIVE_PRIMARY'}
    score = parse_score(primary)
    audits = {k: audit_prediction(pair[k], primary) for k in ('current_model','test_model')}
    available = [a for a in audits.values() if a['status']=='AVAILABLE']
    if not available:
        return {'version': VERSION, 'status':'UNAVAILABLE', 'top3_ready': False,
                'models':audits,'missing_comparisons':['NO_REFERENCED_SCORE_MATRIX']}
    details = payload.get('selection_evidence', {})
    if not isinstance(details, dict) or not isinstance(details.get('zero_vs_one', {}), dict):
        raise ValueError('selection_evidence and zero_vs_one must be objects')
    compared = {parse_score(x) for x in details.get('compared_scores', [])}
    missing = []
    if score not in compared or len(compared) < 2:
        missing.append('AT_LEAST_TWO_EXPLICIT_SCORE_CANDIDATES_INCLUDING_PRIMARY')
    for side,index in [('home',0),('away',1)]:
        if score[index] == 0:
            entry = details.get('zero_vs_one', {}).get(side, {})
            if not isinstance(entry,dict) or not str(entry.get('reason','')).strip() or not str(entry.get('counterevidence','')).strip():
                missing.append(side.upper()+'_ZERO_VS_ONE_SUPPORT_AND_COUNTEREVIDENCE')
    if any('LOW_JOINT_MODE_WITH_MAJORITY_MASS_AT_THREE_PLUS' in a['flags'] for a in available):
        if not any(sum(s)>=3 for s in compared) or not str(details.get('three_plus_path','')).strip():
            missing.append('THREE_PLUS_CANDIDATE_AND_PATH_WHEN_MAJORITY_MASS_IS_HIGHER')
    if payload.get('total_direction') in ['大','小'] and not str(details.get('total_reason','')).strip():
        missing.append('ACTUAL_LINE_DIRECTION_REASON_INDEPENDENT_OF_POINT_SCORE')
    if any(a['comprehensive_selection']['status']!='IN_MATRIX' for a in available):
        missing.append('PRIMARY_OUTSIDE_REFERENCED_MATRIX_SUPPORT')
    directions={}
    for name in audits:
        if audits[name]['status']!='AVAILABLE':continue
        m=np.asarray(pair[name]['matrix'],float);h,a=np.indices(m.shape)
        probabilities=dict(zip(('主胜','平局','客胜'),
            map(float,(m[h>a].sum(),m[h==a].sum(),m[h<a].sum()))))
        chosen=payload.get('wdl')
        directions[name]={'model_direction':max(probabilities,key=probabilities.get),
                          'model_probabilities':probabilities,
                          'comprehensive_direction':chosen,
                          'selected_direction_model_probability':probabilities.get(chosen)}
    unsupported_direction=(payload.get('wdl') in ('主胜','平局','客胜') and directions
        and payload['wdl'] not in {v['model_direction'] for v in directions.values()})
    policy=payload.get('decision_policy_version')
    policy_checks=[]
    if policy not in (None,DECISION_POLICY):raise ValueError('unknown comprehensive decision policy')
    if policy==DECISION_POLICY:
        for name,required in [('wdl_evidence',bool(unsupported_direction)),
                              ('total_evidence',payload.get('total_direction') in ('大','小'))]:
            entry=details.get(name,{})
            if required and (not isinstance(entry,dict) or any(
                    not isinstance(entry.get(k),str) or not entry[k].strip()
                    for k in ('reason','counterevidence'))):
                policy_checks.append(name.upper()+'_SUPPORT_AND_COUNTEREVIDENCE')
        # This records manual discretion, without inventing learned weights or
        # automatically substituting a model direction for the user's judgement.
        if payload.get('override_validation_status')!='UNVALIDATED_MANUAL_RESEARCH':
            policy_checks.append('EXPLICIT_UNVALIDATED_MANUAL_OVERRIDE_STATUS')
        missing.extend(policy_checks)
    return {'version': VERSION, 'status':'NEEDS_COMPARISON' if missing else 'COMPARISONS_DOCUMENTED',
            'top3_ready':not missing,'models':audits,'missing_comparisons':missing,
            'decision_policy_version':policy,'independent_wdl_comparison':directions,
            'direction_disagrees_with_all_referenced_models':bool(unsupported_direction),
            'point_score_does_not_determine_wdl':True,
            'completeness_is_not_accuracy_evidence':True,
            'numeric_output_modified':False,'primary_reordered':False}


def _aware(value):
    result = datetime.fromisoformat(value.replace('Z', '+00:00'))
    if result.tzinfo is None:
        raise ValueError('timezone required in referenced freeze')
    return result


def _reference(reference, *, expected_track, match_id, cutoff, verify_record):
    if not isinstance(reference, dict) or not reference.get('path') or not reference.get('sha256'):
        raise ValueError('complete issued freeze reference required')
    record = verify_record(json.loads(Path(reference['path']).read_text()))
    if (record['record_sha256'] != reference['sha256'] or record['track'] != expected_track
            or record['stage'] != 'prematch' or record['match_id'] != match_id):
        raise ValueError('issued reference identity, track or checksum mismatch')
    if _aware(record['recorded_at']) > cutoff or _aware(record['fixture']['cutoff_at']) > cutoff:
        raise ValueError('referenced analysis was unavailable at selection cutoff')
    return record


def _same_fixture(left, right, *, require_identity=False):
    if (not isinstance(left, dict) or not isinstance(right, dict)
            or not left.get('kickoff_at') or not right.get('kickoff_at')):
        raise ValueError('paired reference requires fixture and kickoff')
    if _aware(left['kickoff_at']) != _aware(right['kickoff_at']):
        raise ValueError('paired reference kickoff mismatch')
    for key in ('match_id', 'competition', 'cohort', 'home', 'away', 'phase'):
        if require_identity and (not left.get(key) or not right.get(key)):
            raise ValueError('candidate reference requires fixture identity: '+key)
        if key in left and key in right and left[key] != right[key]:
            raise ValueError('paired reference fixture identity mismatch: '+key)


def _research_pair(payload, fixture, cutoff, verify_record):
    """Read an explicit existing candidate schema without promoting its roles."""
    record = _reference(payload.get('candidate_reference'),
                        expected_track='nations-paired-candidates',
                        match_id=fixture['match_id'], cutoff=cutoff,
                        verify_record=verify_record)
    _same_fixture(record['fixture'], fixture, require_identity=True)
    if (record['payload'].get('active_route') is not False
            or record['payload'].get('formal_kpi_eligible') is not False):
        raise ValueError('explicit inactive research candidate pair required')
    pair = {}
    for role in ('current', 'test'):
        prediction = record['payload'].get(role)
        if not isinstance(prediction, dict) or prediction.get('role') != role:
            raise ValueError('candidate pair role mismatch')
        if (prediction.get('status') != 'TRAINED_CANDIDATE_RESEARCH_ONLY'
                or prediction.get('formal_kpi_eligible') is not False):
            raise ValueError('explicit research-only prediction required')
        if not prediction.get('version') or not re.fullmatch(
                r'[0-9a-f]{64}', str(prediction.get('artifact_sha256', ''))):
            raise ValueError('candidate model version and artifact identity required')
        _same_fixture(prediction.get('input', {}), record['fixture'], require_identity=True)
        if not (_aware(prediction['input']['cutoff_at'])
                <= _aware(prediction['generated_at']) <= _aware(record['recorded_at'])
                < _aware(fixture['kickoff_at'])):
            raise ValueError('candidate prediction chronology mismatch')
        if not prediction.get('matrix_hash'):
            raise ValueError('candidate source matrix hash required')
        # summarize_prediction checks probability validity and the original hash.
        if summarize_prediction(prediction)['status'] != 'AVAILABLE':
            raise ValueError('both candidate score matrices required')
        pair[role+'_model'] = prediction
    return pair


def audit_issued(payload, fixture, *, stage, track, verify_record):
    """Derive new-record audit metadata, preserving old payloads and their hashes.

    Only new TOP3 selections require documented comparisons. Whole-batch analyses,
    including missing evidence and abstentions, are still frozen honestly.
    """
    if stage != 'prematch' or track not in ('comprehensive', 'top3-selection'):
        return None
    cutoff = _aware(fixture['cutoff_at'])
    scope = payload.get('selection_scope', 'active_reference')
    if scope not in ('active_reference', RESEARCH_SCOPE):
        raise ValueError('unknown selection scope')
    if track == 'comprehensive':
        if scope == RESEARCH_SCOPE:
            pair = _research_pair(payload, fixture, cutoff, verify_record)
            result = comprehensive_audit(payload, pair)
            result.update(selection_scope=RESEARCH_SCOPE, formal_kpi_eligible=False,
                          active_model_promotion=False,
                          reference_track='nations-paired-candidates')
            return result
        reference = payload.get('current_test_reference')
        if reference is None:
            return {'version': VERSION, 'status': 'UNAVAILABLE', 'top3_ready': False,
                    'reason': 'NO_VERIFIED_CURRENT_TEST_FREEZE_REFERENCE'}
        record = _reference(reference, expected_track='current-test-pair',
                            match_id=fixture['match_id'], cutoff=cutoff, verify_record=verify_record)
        _same_fixture(record['fixture'], fixture)
        return comprehensive_audit(payload, record['payload'])
    items = payload.get('top3')
    if not isinstance(items, list) or len(items) > 3:
        raise ValueError('TOP3 requires a list of at most three issued selections')
    seen = set()
    for rank, item in enumerate(items, 1):
        match_id = item['match_id']
        if item.get('rank') != rank or match_id in seen:
            raise ValueError('TOP3 ranks must be consecutive with unique matches')
        seen.add(match_id)
        record = _reference(item.get('comprehensive_reference'), expected_track='comprehensive',
                            match_id=match_id, cutoff=cutoff, verify_record=verify_record)
        if not record.get('selection_audit', {}).get('top3_ready'):
            raise ValueError('TOP3 requires resolved score/zero-goal/total comparisons; freeze the full analysis first')
        if record['selection_audit'].get('selection_scope', 'active_reference') != scope:
            raise ValueError('TOP3 scope must match referenced comprehensive analysis')
        for key in ('primary', 'wdl', 'total_line', 'total_direction'):
            if item.get(key) != record['payload'].get(key):
                raise ValueError('TOP3 recommendation differs from referenced comprehensive freeze: '+key)
        if _aware(fixture['kickoff_at']) > _aware(record['fixture']['kickoff_at']):
            raise ValueError('batch kickoff must not follow selected match kickoff')
    result = {'version': VERSION, 'status': 'COMPARISONS_DOCUMENTED', 'n': len(items),
              'completeness_is_not_accuracy_evidence': True, 'numeric_output_modified': False}
    if scope == RESEARCH_SCOPE:
        result.update(selection_scope=RESEARCH_SCOPE, formal_kpi_eligible=False,
                      active_model_promotion=False)
    return result
