"""Pinned score model dependency."""
