#!/usr/bin/env python3
"""Polite, resumable public FotMob matchDetails capture for twelve target teams' latest five."""
import datetime as dt,hashlib,json,pathlib,time,urllib.error,urllib.request
ROOT=pathlib.Path(__file__).resolve().parent; TEAMDIR=ROOT/'raw/current/fotmob-teams'; RAW=ROOT/'raw/current/fotmob-recent-details';RAW.mkdir(parents=True,exist_ok=True)
teams=[]; events={}
for p in sorted(TEAMDIR.glob('[0-9]*.json')):
 if '.meta.' in p.name:continue
 d=json.loads(p.read_text()); name=d.get('details',{}).get('name'); tid=str(d.get('details',{}).get('id'))
 for x in d.get('overview',{}).get('teamForm',[]):
  mid=str(x['linkToMatch'].split('#')[-1]); t=x['tooltipText']; row={'fotmob_match_id':mid,'date_utc':x.get('date',{}).get('utcTime'),'home':t.get('homeTeam'),'home_id':t.get('homeTeamId'),'home_score':t.get('homeScore'),'away':t.get('awayTeam'),'away_id':t.get('awayTeamId'),'away_score':t.get('awayScore'),'competition':x.get('tournamentName'),'target_team':name,'target_team_id':tid}
  events.setdefault(mid,{'match_id':mid,'date_utc':row['date_utc'],'home':row['home'],'home_id':row['home_id'],'home_score':row['home_score'],'away':row['away'],'away_id':row['away_id'],'away_score':row['away_score'],'competition':row['competition'],'target_teams':[]})
  events[mid]['target_teams'].append({'name':name,'id':tid})
  teams.append(row)
(ROOT/'fotmob-recent-five-index.json').write_text(json.dumps({'schema':'ucl-six-fotmob-recent-five-index-v1','team_form_rows':teams,'unique_events':list(events.values())},indent=2,ensure_ascii=False)+'\n')
def utc():return dt.datetime.now(dt.timezone.utc).isoformat(timespec='microseconds').replace('+00:00','Z')
for i,(mid,row) in enumerate(sorted(events.items()),1):
 bp=RAW/f'{mid}.json';mp=RAW/f'{mid}.meta.json'
 if bp.exists() and mp.exists() and json.loads(mp.read_text()).get('readback_verified'):continue
 url=f'https://www.fotmob.com/api/data/matchDetails?matchId={mid}';start=utc();req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 (compatible; public football research intake)'})
 try:
  with urllib.request.urlopen(req,timeout=25) as r:body=r.read();status=r.status;ctype=r.headers.get('Content-Type');final=r.geturl()
 except urllib.error.HTTPError as e:body=e.read();status=e.code;ctype=e.headers.get('Content-Type');final=e.geturl()
 end=utc();bp.write_bytes(body);digest=hashlib.sha256(body).hexdigest();rb=bp.read_bytes()
 meta={'fotmob_match_id':mid,'url':url,'final_url':final,'observed_request_start_utc':start,'observed_response_end_utc':end,'http_status':status,'content_type':ctype,'bytes':len(body),'sha256':digest,'readback_bytes':len(rb),'readback_sha256':hashlib.sha256(rb).hexdigest(),'readback_verified':hashlib.sha256(rb).hexdigest()==digest}
 mp.write_text(json.dumps(meta,indent=2)+'\n');print(f'{i}/{len(events)} {mid} HTTP={status} bytes={len(body)} sha256={digest[:12]}',flush=True)
 if status in (401,403,429):print('Stopping on refusal/rate response; no retry or alternate route.',flush=True);break
 if i<len(events):time.sleep(1.3)
