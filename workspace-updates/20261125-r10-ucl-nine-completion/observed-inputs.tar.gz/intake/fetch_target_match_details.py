#!/usr/bin/env python3
"""Capture six public FotMob target-match details to audit lineup availability."""
import datetime as dt,hashlib,json,pathlib,time,urllib.request,urllib.error
ROOT=pathlib.Path(__file__).resolve().parent;RAW=ROOT/'raw/current/fotmob-target-details';RAW.mkdir(parents=True,exist_ok=True)
TARGETS={'401915378':'6106421','401915293':'6106391','401915292':'6106294','401915376':'6106253','401915377':'6106310','401915374':'6106235'}
def utc():return dt.datetime.now(dt.timezone.utc).isoformat(timespec='microseconds').replace('+00:00','Z')
for i,(espn,fm) in enumerate(TARGETS.items(),1):
 bp=RAW/f'{espn}.json';mp=RAW/f'{espn}.meta.json'
 if bp.exists() and mp.exists() and json.loads(mp.read_text()).get('readback_verified'):continue
 url=f'https://www.fotmob.com/api/data/matchDetails?matchId={fm}';start=utc();req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 (compatible; public football research intake)'})
 try:
  with urllib.request.urlopen(req,timeout=25) as r:body=r.read();status=r.status;ct=r.headers.get('Content-Type');final=r.geturl()
 except urllib.error.HTTPError as e:body=e.read();status=e.code;ct=e.headers.get('Content-Type');final=e.geturl()
 end=utc();bp.write_bytes(body);h=hashlib.sha256(body).hexdigest();rb=bp.read_bytes();mp.write_text(json.dumps({'espn_event_id':espn,'fotmob_match_id':fm,'url':url,'final_url':final,'observed_request_start_utc':start,'observed_response_end_utc':end,'http_status':status,'content_type':ct,'bytes':len(body),'sha256':h,'readback_bytes':len(rb),'readback_sha256':hashlib.sha256(rb).hexdigest(),'readback_verified':hashlib.sha256(rb).hexdigest()==h},indent=2)+'\n');print(i,espn,status,len(body),h[:12],flush=True)
 if status in (401,403,429): print('stop on refusal/rate response');break
 if i<len(TARGETS):time.sleep(1.3)
