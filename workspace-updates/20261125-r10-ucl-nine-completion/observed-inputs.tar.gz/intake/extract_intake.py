#!/usr/bin/env python3
"""Rebuild normalized UCL six-match intake tables from captured JSON bytes."""
from __future__ import annotations
import csv, datetime as dt, difflib, hashlib, json, pathlib, re, unicodedata
ROOT=pathlib.Path(__file__).resolve().parent; RAW=ROOT/'raw/current'; OUT=ROOT/'outputs'; OUT.mkdir(exist_ok=True)
TARGETS=['401915293','401915378','401915292','401915374','401915376','401915377']
FM_TARGET={'401915378':'6106421','401915293':'6106391','401915292':'6106294','401915376':'6106253','401915377':'6106310','401915374':'6106235'}
def read(p): return json.loads(pathlib.Path(p).read_text())
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def write_csv(name, rows, fields=None):
 if fields is None: fields=list(rows[0]) if rows else []
 with (OUT/name).open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rows)
def norm(s):
 s=unicodedata.normalize('NFKD',str(s or '')).encode('ascii','ignore').decode().lower()
 s=re.sub(r'[^a-z0-9]+',' ',s).strip()
 toks=[t for t in s.split() if t not in {'fc','cf','ac','as','afc','sc','vfb','club','the'}]
 out=' '.join(toks)
 aliases={'deportivo alaves':'alaves','sint truidense':'st truiden','st truiden':'st truiden','st truidense':'st truiden','le havre ac':'le havre','bayern munchen':'bayern munich','internazionale':'inter','as roma':'roma','1 fc cologne':'cologne','fc cologne':'cologne','man united':'manchester united','man utd':'manchester united','vfb stuttgart':'stuttgart','slavia prag':'slavia prague','bodo glimt':'bodo glimt','fenerbahce':'fenerbahce'}
 return aliases.get(out,out)
def num(v):
 try:return float(v) if v not in (None,'') else None
 except (ValueError,TypeError):return None
# Current target identities: ESPN scoreboard + direct ESPN summary + independent FotMob match list.
board=read(RAW/'espn-scoreboard.json'); fotoday=read(RAW/'fotmob-matches-20261125.json')
board_events={str(e['id']):e for e in board.get('events',[])}
fm_events=[]
for league in fotoday.get('leagues',[]):
 if league.get('name')=='Champions League':fm_events.extend(league.get('matches',[]))
fixtures=[]; market_rows=[]; lineup_rows=[]; injury_rows=[]; identity_ok=0
for eid in TARGETS:
 ep=RAW/f'espn-summary-{eid}.json';d=read(ep); ev=board_events[eid]; comp=ev['competitions'][0]; competitors=comp['competitors']
 home=next(c for c in competitors if c['homeAway']=='home'); away=next(c for c in competitors if c['homeAway']=='away')
 fm=next((m for m in fm_events if str(m['id'])==FM_TARGET[eid]),None)
 assert fm is not None, f'FotMob target missing {eid}'
 same=(norm(home['team']['displayName'])==norm(fm['home']['name']) and norm(away['team']['displayName'])==norm(fm['away']['name']))
 kickoff=ev['date']; stadium=(d.get('gameInfo') or {}).get('venue',{}).get('fullName')
 status=ev['status']['type']['name']; fmstatus=fm.get('status',{})
 if same and fmstatus.get('utcTime','').startswith(kickoff[:16]): identity_ok+=1
 fixture={'espn_event_id':eid,'fotmob_match_id':str(fm['id']),'competition':'UEFA Champions League','season':'2026-27','stage':'league phase','kickoff_utc':kickoff,'kickoff_beijing':(dt.datetime.fromisoformat(kickoff.replace('Z','+00:00')).astimezone(dt.timezone(dt.timedelta(hours=8))).isoformat(timespec='minutes')),'home':home['team']['displayName'],'home_espn_id':'espn:'+str(home['team']['id']),'home_fotmob_id':'fotmob:'+str(fm['home']['id']),'away':away['team']['displayName'],'away_espn_id':'espn:'+str(away['team']['id']),'away_fotmob_id':'fotmob:'+str(fm['away']['id']),'venue':stadium,'espn_status':status,'espn_time_valid':ev['status']['type'].get('completed') is False,'fotmob_started':fmstatus.get('started'),'fotmob_finished':fmstatus.get('finished'),'fotmob_cancelled':fmstatus.get('cancelled'),'identity_sides_and_kickoff_match':same and fmstatus.get('utcTime','').startswith(kickoff[:16]),'espn_summary_sha256':sha(ep),'espn_summary_url':f'https://site.api.espn.com/apis/site/v2/sports/soccer/uefa.champions/summary?event={eid}','fotmob_schedule_url':'https://www.fotmob.com/api/data/matches?date=20261125'}
 fixtures.append(fixture)
 dk_url=None; odds=d.get('odds') or []
 for o in odds:
  pname=(o.get('provider') or {}).get('name','')
  if pname=='DraftKings' and not dk_url:
   for link in o.get('links',[]):
    if 'game' in link.get('rel',[]): dk_url=link.get('href');break
  hobj=o.get('homeTeamOdds') or {}; aobj=o.get('awayTeamOdds') or {}; dobj=o.get('drawOdds') or {}
  home_ml=hobj.get('moneyLine') if hobj.get('moneyLine') is not None else (hobj.get('odds') or {}).get('value')
  away_ml=aobj.get('moneyLine') if aobj.get('moneyLine') is not None else (aobj.get('odds') or {}).get('value')
  draw=dobj.get('moneyLine') if dobj.get('moneyLine') is not None else dobj.get('value') if isinstance(dobj,dict) else dobj
  timekeys=[]
  def scan(x,path=''):
   if isinstance(x,dict):
    for k,v in x.items():
     if any(t in k.lower() for t in ('time','date','update','timestamp')):timekeys.append((path+'/'+k,v))
     scan(v,path+'/'+k)
   elif isinstance(x,list):
    for i,v in enumerate(x):scan(v,path+f'/{i}')
  scan(o)
  native=None
  for k,v in timekeys:
   if k.rsplit('/',1)[-1].lower() in {'timestamp','lastupdated','updatedat','asof','quotedat','quote_time','lastupdate'} and isinstance(v,str) and re.search(r'\d{4}-\d\d-\d\d|\d{10,}',v):native=v;break
  total=o.get('overUnder'); over=o.get('overOdds'); under=o.get('underOdds')
  market_rows.append({'espn_event_id':eid,'match':fixture['home']+' - '+fixture['away'],'provider':pname,'odds_format':'american' if pname=='DraftKings' else 'decimal','home_1x2':home_ml,'draw_1x2':draw,'away_1x2':away_ml,'total_goals_line':total,'over_price':over,'under_price':under,'source_quote_time':native,'source_quote_time_present':bool(native),'snapshot_capture_utc':read(ep.with_suffix('.json.meta.json'))['observed_request_start_utc'],'snapshot_source':'ESPN odds feed provider label '+(pname or '(missing)'),'source_url':f'https://site.api.espn.com/apis/site/v2/sports/soccer/uefa.champions/summary?event={eid}','raw_sha256':sha(ep),'complete_1x2':all(v is not None for v in (home_ml,draw,away_ml)),'complete_ou':all(v is not None for v in (total,over,under)),'note':'Provider snapshot has no native quote timestamp; request time is not quote time.'})
 # FutMob currently supplies predictions and unavailable list; never represent as confirmed lineup.
 target=read(RAW/f'fotmob-target-details/{eid}.json'); li=(target.get('content') or {}).get('lineup') or {}
 line_type=li.get('lineupType','not supplied'); source=li.get('source')
 for sidekey,side in [('home','homeTeam'),('away','awayTeam')]:
  tm=li.get(side) or {}
  for player in tm.get('starters',[]):
   lineup_rows.append({'espn_event_id':eid,'fotmob_match_id':str(fm['id']),'side':side,'team':tm.get('name'),'player_id':'fotmob:'+str(player.get('id')),'player_name':player.get('name'),'position_id':player.get('positionId'),'shirt_number':player.get('shirtNumber'),'lineup_type':line_type,'lineup_source':source,'status':'predicted, not confirmed starter','captured_utc':read(RAW/f'fotmob-target-details/{eid}.meta.json')['observed_request_start_utc']})
  for player in tm.get('unavailable',[]):
   ua=player.get('unavailability') or {}
   injury_rows.append({'espn_event_id':eid,'team':tm.get('name'),'player_id':'fotmob:'+str(player.get('id')),'player_name':player.get('name'),'reported_type':ua.get('type'),'reported_return':ua.get('expectedReturn'),'source':'FotMob predicted match lineup unavailable list','status':'provider-listed; not independently corroborated here','provider_update_time':None,'retrieved_utc':read(RAW/f'fotmob-target-details/{eid}.meta.json')['observed_request_start_utc'],'raw_sha256':sha(RAW/f'fotmob-target-details/{eid}.json')})
write_csv('fixtures.csv',fixtures)
write_csv('markets.csv',market_rows)
write_csv('predicted-lineups.csv',lineup_rows)
write_csv('fotmob-listed-unavailable.csv',injury_rows, ['espn_event_id','team','player_id','player_name','reported_type','reported_return','source','status','provider_update_time','retrieved_utc','raw_sha256'])
# Recent form: FotMob teamForm defines latest five; same-event detail response supplies metrics and finished status.
index=read(ROOT/'fotmob-recent-five-index.json'); details=RAW/'fotmob-recent-details'; all_details={}
for p in details.glob('[0-9]*.json'):
 if '.meta.' not in p.name:all_details[p.stem]=read(p)
# strict ESPN cross-check: same UTC date, both names/scores normalized; ambiguity is left unmatched.
espn_games=[]
for p in (RAW/'recent-summaries').glob('[0-9]*.json'):
 if '.meta.' in p.name:continue
 x=read(p); c=x['header']['competitions'][0]; comps=c['competitors']; h=next(a for a in comps if a['homeAway']=='home');a=next(a for a in comps if a['homeAway']=='away')
 espn_games.append({'id':str(c['id']),'date':c['date'][:10],'home':h['team']['displayName'],'away':a['team']['displayName'],'hg':num(h.get('score')),'ag':num(a.get('score')),'venue':(x.get('gameInfo') or {}).get('venue',{}).get('fullName'),'path':p})
def score_match(ev,g):
 if ev['date_utc'][:10]!=g['date']:return 0
 if num(ev['home_score'])!=g['hg'] or num(ev['away_score'])!=g['ag']:return 0
 return (difflib.SequenceMatcher(None,norm(ev['home']),norm(g['home'])).ratio()+difflib.SequenceMatcher(None,norm(ev['away']),norm(g['away'])).ratio())/2
recent_rows=[]; cross_ids=set()
for row in index['team_form_rows']:
 mid=str(row['fotmob_match_id']); d=all_details.get(mid); base={'target_team':row['target_team'],'target_team_fotmob_id':'fotmob:'+str(row['target_team_id']),'date_utc':row['date_utc'],'competition_from_team_form':row['competition'],'fotmob_match_id':mid,'home':row['home'],'home_id':'fotmob:'+str(row['home_id']),'away':row['away'],'away_id':'fotmob:'+str(row['away_id']),'home_goals':row['home_score'],'away_goals':row['away_score'],'detail_source_url':f'https://www.fotmob.com/api/data/matchDetails?matchId={mid}','detail_raw_sha256':None,'detail_retrieved_utc':None,'detail_finished':None,'detail_started':None,'finish_reason':None,'after_extra_time_or_shootout':None,'home_xg':None,'away_xg':None,'home_shots_on_target':None,'away_shots_on_target':None,'team_venue':'home' if str(row['home_id'])==str(row['target_team_id']) else 'away','venue':None,'espn_event_id':None,'xg_missing_reason':None,'shots_missing_reason':None}
 if d:
  base['detail_raw_sha256']=sha(details/f'{mid}.json');base['detail_retrieved_utc']=read(details/f'{mid}.meta.json')['observed_request_start_utc'];g=d.get('general') or {}; hs=d.get('header',{}).get('status') or {};base['detail_started']=g.get('started');base['detail_finished']=g.get('finished');base['finish_reason']=((hs.get('reason') or {}).get('short') or hs.get('desc'))
  reason=(base['finish_reason'] or '').lower();base['after_extra_time_or_shootout']=any(z in reason for z in ('aet','pen','extra'))
  # Confirm event identity against matchDetails before attaching stats.
  ft=(d.get('header') or {}).get('teams') or []
  match_sides={(str(t.get('id')),norm(t.get('name'))) for t in ft}
  if not all((str(z['home_id']).split(':')[-1],norm(z['home'])) in match_sides for z in [row]) or not all((str(z['away_id']).split(':')[-1],norm(z['away'])) in match_sides for z in [row]):base['identity_warning']='teamForm/detail team identity mismatch'
  stats=((d.get('content') or {}).get('stats') or {}).get('Periods',{}).get('All',{}).get('stats',[]) if isinstance((d.get('content') or {}).get('stats'),dict) else []
  values={}
  for group in stats:
   for s in group.get('stats',[]):
    key=s.get('key'); vals=s.get('rawStats') or []
    if key in ('expected_goals','ShotsOnTarget') and key not in values:
     values[key]=[num(v.get('value')) for v in vals[:2]] if vals else [num(v) for v in (s.get('stats') or [])[:2]]
  if 'expected_goals' in values and len(values['expected_goals'])==2:base['home_xg'],base['away_xg']=values['expected_goals']
  else:base['xg_missing_reason']='FotMob detail response has no expected_goals value; coverageLevel='+str(g.get('coverageLevel'))
  if 'ShotsOnTarget' in values and len(values['ShotsOnTarget'])==2:base['home_shots_on_target'],base['away_shots_on_target']=values['ShotsOnTarget']
  else:base['shots_missing_reason']='FotMob detail response has no ShotsOnTarget value'
  candidates=[e for e in espn_games if score_match(row,e)>=0.78]
  candidates.sort(key=lambda e:score_match(row,e),reverse=True)
  if candidates and (len(candidates)==1 or score_match(row,candidates[0])-score_match(row,candidates[1])>=0.08):
   e=candidates[0];base['espn_event_id']='espn:'+e['id'];base['venue']=e['venue'];cross_ids.add(e['id'])
  else:base['venue']='unknown from captured ESPN summaries; no unambiguous cross-source identity join'
 else:
  base['xg_missing_reason']='FotMob matchDetails capture missing';base['shots_missing_reason']='FotMob matchDetails capture missing'
 # Orient values to the target team, preserving event-level home/away values too.
 ishome=str(row['home_id'])==str(row['target_team_id']);base['team_xg']=base['home_xg'] if ishome else base['away_xg'];base['opponent_xg']=base['away_xg'] if ishome else base['home_xg'];base['team_shots_on_target']=base['home_shots_on_target'] if ishome else base['away_shots_on_target'];base['opponent_shots_on_target']=base['away_shots_on_target'] if ishome else base['home_shots_on_target']
 recent_rows.append(base)
write_csv('recent-five-process.csv',recent_rows)
# Source manifest includes every current raw response with preserved capture clock and raw/readback digest.
captures=[]
for p in (ROOT/'raw').rglob('*.meta.json'):
 try:m=read(p)
 except Exception:continue
 m['path']=str(p.relative_to(ROOT));captures.append(m)
captures.sort(key=lambda m:m.get('observed_request_start_utc',''))
manifest={'schema':'ucl-other-six-capture-manifest-v1','target_espn_ids':TARGETS,'captures':captures}
(ROOT/'capture-manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
# Coverage/audit aggregates.
teams={}
for r in recent_rows:
 t=teams.setdefault(r['target_team'],{'rows':0,'xg_team':0,'xg_opponent':0,'sot_team':0,'sot_opponent':0,'finished':0,'venues':0})
 t['rows']+=1;t['xg_team']+=r['team_xg'] is not None;t['xg_opponent']+=r['opponent_xg'] is not None;t['sot_team']+=r['team_shots_on_target'] is not None;t['sot_opponent']+=r['opponent_shots_on_target'] is not None;t['finished']+=r['detail_finished'] is True;t['venues']+=bool(r['venue'] and not r['venue'].startswith('unknown'))
market_cov={}
for r in market_rows:market_cov.setdefault(r['provider'],{'rows':0,'complete_1x2':0,'complete_ou':0,'native_quote_time':0})['rows']+=1
for r in market_rows:
 c=market_cov[r['provider']];c['complete_1x2']+=r['complete_1x2'];c['complete_ou']+=r['complete_ou'];c['native_quote_time']+=bool(r['source_quote_time_present'])
meta={'schema':'ucl-other-six-coverage-audit-v1','target_count':len(TARGETS),'official_ESPN_identity_rows':len(fixtures),'ESPN_FotMob_target_identity_and_time_agreements':identity_ok,'target_ids_unchanged':TARGETS,'targets_frozen_excluded_from_outputs':True,'target_market_rows':market_rows,'market_coverage_by_provider':market_cov,'native_bookmaker_quote_times_verified':0,'bookmaker_page_access':{'service':'DraftKings sportsbook public event page','tested_path':'/event/34966677','http_status':403,'response_body_and_exact_request_clock_retained':False,'no_retry_or_access_circumvention':True},'recent_fotmob_team_form_rows':len(index['team_form_rows']),'unique_recent_fotmob_event_ids':len(index['unique_events']),'recent_match_details_success':sum(bool(r.get('detail_raw_sha256')) for r in recent_rows),'recent_event_ESPN_cross_identity_joins':len(cross_ids),'recent_coverage_by_team':teams,'actual_target_lineups_confirmed':0,'target_lineup_status':'All six target match details report lineupType=predicted; no confirmed starters. Predicted lineups are separately labeled.','injury_status':'FotMob predicted lineup unavailable lists retained verbatim by player ID; their provider-native publication time is absent. Official sources are in outputs/official-injury-evidence-v1.csv. Any unlisted player remains unknown, not cleared.','official_injury_evidence_file':'outputs/official-injury-evidence-v1.csv','target_fixtures_complete_and_not_started':all(f['identity_sides_and_kickoff_match'] and f['espn_status']=='STATUS_SCHEDULED' and not f['fotmob_started'] and not f['fotmob_finished'] and not f['fotmob_cancelled'] for f in fixtures),'data_does_not_contain_model_outputs':True}
(ROOT/'coverage-audit.json').write_text(json.dumps(meta,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'fixtures':len(fixtures),'target_identity_agreements':identity_ok,'market_rows':len(market_rows),'recent_team_rows':len(recent_rows),'recent_unique_events':len(index['unique_events']),'recent_details':sum(bool(r.get('detail_raw_sha256')) for r in recent_rows),'recent_ESPN_crossjoins':len(cross_ids),'recent_coverage_by_team':teams,'target_lineup_types':sorted({r['lineup_type'] for r in lineup_rows})},ensure_ascii=False,indent=2))
