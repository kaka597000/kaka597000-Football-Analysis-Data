#!/usr/bin/env python3
"""Capture FotMob public team pages to identify recent fixture IDs; resumable."""
import datetime as dt,hashlib,json,pathlib,time,urllib.error,urllib.request
ROOT=pathlib.Path(__file__).resolve().parent; RAW=ROOT/'raw/current/fotmob-teams'; RAW.mkdir(parents=True,exist_ok=True)
TEAMS={'Sabah FK':951893,'Barcelona':8634,'Slavia Prague':7787,'Villarreal':10205,'Club Brugge':8342,'Liverpool':8650,'Inter':8636,'VfB Stuttgart':10269,'Lille':8639,'Bayern München':9823,'Paris Saint-Germain':9847,'Roma':8686}
def utc(): return dt.datetime.now(dt.timezone.utc).isoformat(timespec='microseconds').replace('+00:00','Z')
for i,(name,tid) in enumerate(TEAMS.items(),1):
 p=RAW/f'{tid}.json'; mpath=RAW/f'{tid}.meta.json'
 if p.exists() and mpath.exists() and json.loads(mpath.read_text()).get('readback_verified'): continue
 url=f'https://www.fotmob.com/api/data/teams?id={tid}&ccode3=ENG'; start=utc(); req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 (compatible; public football research intake)'})
 try:
  with urllib.request.urlopen(req,timeout=25) as r: body=r.read();status=r.status;ctype=r.headers.get('Content-Type');final=r.geturl()
 except urllib.error.HTTPError as e: body=e.read();status=e.code;ctype=e.headers.get('Content-Type');final=e.geturl()
 end=utc();p.write_bytes(body);d=hashlib.sha256(body).hexdigest(); rb=p.read_bytes()
 m={'team_id':tid,'team_name':name,'url':url,'final_url':final,'observed_request_start_utc':start,'observed_response_end_utc':end,'http_status':status,'content_type':ctype,'bytes':len(body),'sha256':d,'readback_bytes':len(rb),'readback_sha256':hashlib.sha256(rb).hexdigest(),'readback_verified':hashlib.sha256(rb).hexdigest()==d};mpath.write_text(json.dumps(m,indent=2)+'\n');print(i,name,status,len(body),d[:12],flush=True)
 if status in (401,403,429): print('stop after refusal/rate response');break
 if i<len(TEAMS):time.sleep(1.3)
