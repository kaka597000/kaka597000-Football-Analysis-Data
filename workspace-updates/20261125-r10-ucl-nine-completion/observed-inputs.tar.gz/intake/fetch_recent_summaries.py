#!/usr/bin/env python3
"""Polite, resumable public ESPN event-summary capture for target teams' prior five."""
import datetime as dt, hashlib, json, pathlib, time, urllib.error, urllib.request
ROOT=pathlib.Path(__file__).resolve().parent
RAW=ROOT/'raw/current/recent-summaries'; RAW.mkdir(parents=True,exist_ok=True)
TARGETS=['401915293','401915378','401915292','401915374','401915376','401915377']
BASE='https://site.api.espn.com/apis/site/v2/sports/soccer/uefa.champions/summary?event='
def utcnow(): return dt.datetime.now(dt.timezone.utc).isoformat(timespec='microseconds').replace('+00:00','Z')
def event_ids():
 ids=set()
 for target in TARGETS:
  d=json.loads((ROOT/f'raw/current/espn-summary-{target}.json').read_text())
  kickoff=d['header']['competitions'][0]['date']
  for team in d.get('lastFiveGames',[]):
   before=[e for e in team.get('events',[]) if e.get('gameDate') and e['gameDate']<kickoff and e.get('homeTeamScore') is not None and e.get('awayTeamScore') is not None]
   for e in sorted(before,key=lambda x:x['gameDate'])[-5:]: ids.add(e['id'])
 return sorted(ids)
ids=event_ids(); (RAW/'queue.json').write_text(json.dumps({'schema':'espn-recent-summary-queue-v1','target_ids':TARGETS,'event_ids':ids},indent=2)+'\n')
for i,eid in enumerate(ids,1):
 bp=RAW/f'{eid}.json'; mp=RAW/f'{eid}.meta.json'
 if bp.exists() and mp.exists():
  old=json.loads(mp.read_text())
  if old.get('readback_verified') and old.get('http_status')==200: continue
 url=BASE+eid; start=utcnow(); req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 (compatible; public football research intake)'})
 status=ctype=None; final=url; error=None
 try:
  with urllib.request.urlopen(req,timeout=25) as response:
   body=response.read(); status=response.status; ctype=response.headers.get('Content-Type'); final=response.geturl()
 except urllib.error.HTTPError as exc:
  status=exc.code; ctype=exc.headers.get('Content-Type'); final=exc.geturl(); body=exc.read(); error=f'HTTP {exc.code}'
 except Exception as exc: body=b''; error=f'{type(exc).__name__}: {exc}'
 end=utcnow()
 if body: bp.write_bytes(body)
 digest=hashlib.sha256(body).hexdigest(); rb=bp.read_bytes() if bp.exists() else b''
 meta={'event_id':eid,'url':url,'final_url':final,'observed_request_start_utc':start,'observed_response_end_utc':end,'http_status':status,'content_type':ctype,'bytes':len(body),'sha256':digest,'readback_bytes':len(rb),'readback_sha256':hashlib.sha256(rb).hexdigest(),'readback_verified':bool(body) and hashlib.sha256(body).hexdigest()==hashlib.sha256(rb).hexdigest(),'error':error}
 mp.write_text(json.dumps(meta,indent=2)+'\n'); print(f'{i}/{len(ids)} {eid} HTTP={status} bytes={len(body)} sha256={digest[:12]}',flush=True)
 if status in (401,403,429): print('Stopping on access/rate response; no retry or alternate route.',flush=True); break
 if i<len(ids): time.sleep(1.25)
