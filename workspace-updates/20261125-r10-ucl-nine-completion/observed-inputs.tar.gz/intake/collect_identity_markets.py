#!/usr/bin/env python3
"""Capture public ESPN/FotMob UCL fixtures and ESPN event summaries for six fixed IDs."""
from __future__ import annotations
import datetime as dt
import hashlib
import json
import pathlib
import time
import urllib.request
from zoneinfo import ZoneInfo

ROOT = pathlib.Path(__file__).resolve().parent
SIX = ["401915293", "401915378", "401915292", "401915374", "401915376", "401915377"]
ENDPOINTS = [
    ("espn_scoreboard", "https://site.api.espn.com/apis/site/v2/sports/soccer/uefa.champions/scoreboard?dates=20261125", "espn-scoreboard.json"),
    ("fotmob_matches", "https://www.fotmob.com/api/data/matches?date=20261126", "fotmob-matches.json"),
]
def now(): return dt.datetime.now(dt.timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")
def get(url):
    req=urllib.request.Request(url,headers={"User-Agent":"Mozilla/5.0 (compatible; UCLFixtureEvidence/1.0)","Accept":"application/json, text/plain, */*","Referer":"https://www.espn.com/"})
    started=now()
    with urllib.request.urlopen(req,timeout=45) as r:
        body=r.read();status=r.status;headers=dict(r.headers.items());final_url=r.geturl()
    ended=now()
    return body,status,headers,final_url,started,ended
def capture(url,path):
    meta_path=path.with_suffix(path.suffix+".meta.json")
    if path.exists() and meta_path.exists(): return json.loads(meta_path.read_text())
    body,status,headers,final_url,started,ended=get(url)
    path.write_bytes(body)
    reread=path.read_bytes()
    obj={"url":url,"final_url":final_url,"observed_request_start_utc":started,"observed_response_end_utc":ended,"http_status":status,"content_type":next((v for k,v in headers.items() if k.lower()=="content-type"),None),"bytes":len(body),"sha256":hashlib.sha256(body).hexdigest(),"readback_bytes":len(reread),"readback_sha256":hashlib.sha256(reread).hexdigest(),"readback_verified":reread==body}
    meta_path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+"\n")
    return obj
def main():
    records=[]
    for name,url,filename in ENDPOINTS:
        path=ROOT/"raw"/"current"/filename
        records.append({"name":name,**capture(url,path),"path":str(path.relative_to(ROOT))})
        time.sleep(1.2)
    for mid in SIX:
        url=f"https://site.api.espn.com/apis/site/v2/sports/soccer/uefa.champions/summary?event={mid}"
        path=ROOT/"raw"/"current"/f"espn-summary-{mid}.json"
        records.append({"name":"espn_summary","event_id":mid,**capture(url,path),"path":str(path.relative_to(ROOT))})
        time.sleep(1.2)
    (ROOT/"current-source-manifest.json").write_text(json.dumps({"schema":"ucl-other-six-capture-manifest-v1","captured_at_utc":now(),"targets":SIX,"captures":records},ensure_ascii=False,indent=2)+"\n")
if __name__=="__main__":main()
