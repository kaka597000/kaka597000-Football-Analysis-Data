# 盘口快照接入新赛前输入

代码范围仅四文件，见handoff.json。26项离线测试通过；没有外部请求、生产冻结、旧记录改写或模型参数修改。真实新盘口验收由root根据Luna取得的当前响应另行执行，不把单元测试称为盘口可用。

`runtime/automation/market_bridge.py:attach_total_quote(fixture, market_dir, provider_order=(), bookmaker_order=())`读取各run目录中的`market-channel.json`。每个候选必须是原`WCPP-V2-FEATURE-SNAPSHOT-1`，重新核验snapshot_sha256、odds原文hash及identity原文hash；原文必须位于run目录内部，来源URL不能带凭据。

snapshot.target必须匹配fixture的match_id、cohort、stage、home_id/home、away_id/away、kickoff；fixture有competition时也须匹配。旧缺stage的快照仍可保留研究，但本入口不将其补作生产身份。provider adapter负责正确解释源市场/报价时间/身份；本入口的hash验证不宣称独立证明提供商事实。

新的实际cutoff下再次执行已有snapshot规则并保留原market_max_age_seconds（最多3600秒），再通过已锁定future_validation.quote_audit。报价时间不使用采集时间代替。source_quote必须完整双边、机构、盘线、真实quoted_at/query_time，均早于当前冻结cutoff。

选择是事前配置的provider及book顺序；未列来源按名称稳定排序。每个provider/book取来源时间最新一组；若这组存在不同盘线或价格则排除歧义，不依据模型结果挑选更好盘线。坏来源不阻断其他完整来源。结果的market_attachment保留selected snapshot与observation SHA、来源文件、优先序及所有排除原因。

cycle新增显式参数：

```text
--market-dir /path/to/retained/market/runs
--market-provider provider-a --market-provider provider-b
--market-bookmaker preferred-book
```

只有尚未捕获且没有partial journal的真实赛前fixture会读盘口。captured/protected首冻、已保存package恢复和partial journal恢复均不读新盘口；原队列及注册身份不修改。没有合格盘口仍可冻结独立比分/WDL，盘口缺失元数据保留。后装密钥或新抓价格不能把旧80场第一版补成有效OU样本。

现有运行环境若采用单文件覆盖，启用`--market-dir`时必须把`runtime/automation/market_bridge.py`与新prospective_cycle.py一同部署。future_validation.py、challengers.py及其锁定协议/工件不变。
