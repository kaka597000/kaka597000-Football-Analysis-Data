# Provenance correction — ESPN capture timestamp

The earlier `identity-source-metadata.json` used the HTTP `Date` response header (`2026-11-12T15:51:44Z`) as `captured_at`. That is the provider server's clock, not the local response-receipt time, and must not be treated as an actual capture timestamp. The raw response wrapper's file mtime was also not used as a network receipt claim.

A fresh ESPN request was made at 2026-11-12 UTC and captured with `runtime/automation/market_snapshot.fetch`, which records local request start and response-receipt times while retaining exact response bytes. The corrected identity evidence and rebuilt market channel are in `/workspace/market-fallback-20261112/live-validated`. This directory reuses the existing Odds API raw bytes and original odds request/capture times and hash; it makes no new Odds API request. The prior directory remains intact for audit but is superseded for final identity provenance.
