# API odds fallback probes — 2026-11-12 UTC

All probes were read-only, TLS enabled, and used environment bindings only. Responses were scrubbed of credential strings and credential fields before storage. API-Sports and 5Dollar credentials were sent only to their documented vendor domains; BSD's Token header was sent only to `sports.bzzoiro.com`. No secret values or auth headers are retained.

## Findings

| Provider | Current access | Schedule/event coverage | Full-time total odds coverage |
|---|---|---|---|
| API-Football / API-SPORTS | The explicitly requested lowercase `apifootball` binding was present; uppercase `APIFOOTBALL` was absent. `/status` returned HTTP 403. Stopped immediately. | Not tested because status was blocked. | Not verified; no odds request made. |
| 5Dollar | `_5DOLLARS` `/status` returned 200, authenticated plan `community`, 300 requests/hour and 20/min burst. | `/fixtures` for default UTC date and documented 2026-11-13 window each returned 200 with zero rows. | Documented 2026-11-15 fixture window with `include=odds` returned 403. Stopped service after denial. No fixture quote, bookmaker or quote time verified. |
| BSD | `bsd` `/events/` returned 200 and 100 event records for the requested date range. | Upcoming events appeared, including event IDs and UTC kickoff/status. | Event-scoped consensus response for event 7343 returned null for all 1X2 and O/U 1.5/2.5/3.5 fields; `last_update_at` was null. Official bookmaker-specific `over_under_25` list filtered to event 215314 returned 200 but zero rows. Thus no usable quote, two-sided line, bookmaker, or source quote timestamp was obtained. |

No API's HTTP/query time is represented as a quote time. The BSD event odds response's `next_update_at` is a scheduled refresh, not a source quote timestamp.

## Official endpoint references

- API-SPORTS Football v3 OpenAPI: `https://api-sports.io/public/documentations/football-v3.yaml` (local historical official schema copy: `api-sports-official-openapi-cached.yaml`).
- 5Dollar API docs: `https://5dollarfootballapi.com/docs` (local cached official docs text: `5dollar-official-docs-cached.txt`). It documents the 24-hour fixtures window and `include=odds`.
- BSD official docs: `https://sports.bzzoiro.com/docs/football/`; live OpenAPI schema: `https://sports.bzzoiro.com/openapi.json`. It documents `/events/`, `/events/{id}/odds/` and bookmaker tuples at `/odds/`.

Each response record retains its safe request path/parameters, query time, HTTP status and SHA-256. `manifest.json` records file hashes and sanitized response hashes. No fixture mapping, source-time verification, or model ingestion was performed.

## BSD same-day supplement (bounded two-call check)

At the root agent's request, BSD was queried for `date_from=date_to=2026-11-12` (UTC), returning 46 events. It included England–Croatia, event ID `212691`, marked `notstarted`, kickoff `2026-11-12T19:45:00Z`, `league_id=64`, `stage=group-stage`. The official bookmaker-odds list endpoint was queried once with `event_id=212691`, `market=over_under_25`, `limit=100`. It returned two consensus rows at line 2.5:

- Over 1.458; Under 2.626.
- Both rows report `updated_at=2026-11-12T15:35:05Z`, `opening_at=2026-11-05T20:51:29Z`, and `bookmaker_count=5`.

The API labels these rows `bookmaker_slug/name=consensus`; they do not identify any individual bookmaker's prices. The event is a not-started national-team group-stage fixture, but this bounded check did not resolve the official name of league 64, so it is not certified here as Nations League or another requested competition. `updated_at` is the provider's returned quote-update time; the separate HTTP query time is in the response record. This is useful same-day two-sided total-market evidence, but not institution-attributed or independently competition-verified odds. See `bsd-today-events-supplement.json` and `bsd-today-national-team-total-odds-supplement.json`.
