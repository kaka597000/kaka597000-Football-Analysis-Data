# The Odds API and ESPN positive control — 2026-11-12 UTC

## Access distinction

- The current execution process has a `THE_ODDS` binding and no `WCPP_THE_ODDS_API_KEY` binding. The requested official API call succeeded using the `THE_ODDS` binding. The credential value is neither recorded nor printed.
- This proves only that the current process can call The Odds API. It does not prove a GitHub Actions secret with the same value or name exists.
- A read-only GitHub Actions secret-name listing was attempted against the private data repository and returned HTTP 403, `Resource not accessible by integration`. Therefore GitHub secret presence or absence cannot be determined here. The local key working and GitHub's inability to list secrets are separate facts; this is not evidence that GitHub's key is missing.

## The Odds API

One call to the official v4 endpoint with `regions=eu`, `markets=totals`, `oddsFormat=decimal` returned HTTP 200 with 35 events. Response headers reported one request unit used, 292 remaining. No 401/403/429 was received.

The ESPN same-day scoreboard response maps England–Croatia to ESPN event `401861150` (scheduled 19:45 UTC); The Odds API lists the same teams and kickoff in reverse display order as event `8a1174de9079b530bd6612e3fde6e2fa`. It returned 12 bookmaker totals for that event. For example, Betsson had Over 2.5 at 1.44 and Under 2.5 at 2.72, last updated at `2026-11-12T15:57:23Z`. The event's Pinnacle line was 3.25 (Over 1.99 / Under 1.88, updated `15:57:21Z`). Other same-day UEFA Nations League events also returned paired prices; see `quote-coverage.json`.

The request filter was `markets=totals`; provider `last_update` is retained as quote-update time and is distinct from query time. These are full-time totals from the standard soccer totals market; no Asian-handicap/spread interpretation is made.

## ESPN source

The scoreboard JSON was reused from the same-day probe at `2026-11-12T15:51:43.227295Z` (HTTP 200), about five minutes before the odds request. No second ESPN request was made. It identifies eight scheduled Nations League fixtures, including England–Croatia.

## Stored files and capture caveat

- `theodds-unl-totals.json`: response passed through the project's credential scrubber before saving. The helper also removes generic JSON properties named `key`; the exact response body was therefore not byte-for-byte preserved. The market identity is clear from the one requested `markets=totals` filter. No second call was made because authorization was one quota unit.
- `espn-unl-scoreboard.json`: same-day response JSON extracted from the recent ESPN probe.
- `source-metadata.json`: safe URL, requested/captured times, file hashes, and response hashes. API key is absent from URLs and files.
- `quote-coverage.json`: identity-matched fixture/price extraction from the saved responses.
- `request-record.json`: endpoint, sanitized URL, status and quota headers.
