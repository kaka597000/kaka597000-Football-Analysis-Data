from pathlib import Path
from nations_league import repair, xg_research as xg
from research.analysis_freeze import aware
p=Path(__file__).parent
original=repair.read(p/'future-identity.json')
odds=repair.read(p/'data/markets/raw/odds.json'); capture=repair.read(p/'data/markets/capture.json')
assert repair.sha(capture['raw_path'])==capture['raw_sha256']
captures={Path(r['raw_path']).name:r for r in repair.read(p/'data/future/captures.json')['requests']}
fixtures=[]
for old in original:
 f={k:v for k,v in old.items() if k not in ('total_quote','market_attachment','market_snapshots','phase_evidence')}
 source=captures['espn-summary-'+f['source_event_id']+'.json']
 assert repair.sha(source['raw_path'])==source['raw_sha256']
 d=repair.read(source['raw_path']); c=d['header']['competitions'][0]
 assert str(d['header']['id'])==f['source_event_id']
 assert c['status']['type']['state']=='pre' and c['status']['type']['completed'] is False
 assert aware(c['date'])==aware(f['kickoff_at'])
 assert c['neutralSite']==f['neutral']
 for side in ('home','away'):
  team=next(t for t in c['competitors'] if t['homeAway']==side)
  assert 'espn:'+team['id']==f[side] and team['team']['displayName']==f[side+'_name']
 group=c['groups']['name']
 assert ('LEAGUE '+f['league_level']) in group or ('GROUP '+f['league_level']) in group
 f['phase_evidence']={'source_path':source['raw_path'],'source_sha256':source['raw_sha256'],'source_url':source['url'],'query_time':source['ended_at']}
 odds_home={'Bosnia-Herzegovina':'Bosnia & Herzegovina'}.get(f['home_name'],f['home_name'])
 matches=[r for r in odds if r['home_team']==odds_home and r['away_team']==f['away_name'] and aware(r['commence_time'])==aware(f['kickoff_at'])]
 assert len(matches)==1
 event=matches[0];book=next(b for b in event['bookmakers'] if b['key']=='pinnacle')
 market=next(m for m in book['markets'] if m['key']=='totals')
 over=next(v for v in market['outcomes'] if v['name']=='Over'); under=next(v for v in market['outcomes'] if v['name']=='Under')
 assert over['point']==under['point']
 f['total_quote']={'verified':True,'match_id':f['match_id'],'bookmaker':book['key'],'market':'standard_total','line':over['point'],'over_odds':over['price'],'under_odds':under['price'],'quoted_at':market['last_update'],'query_time':capture['ended_at'],'source_url':capture['url'],'source_sha256':capture['raw_sha256'],'provider':'the-odds-api'}
 f['cutoff_at']=xg.now()
 fixtures.append(f)
repair.write(p/'future-prepared.json',fixtures)
index=repair.read(p/'experiment/index.json')
result=xg.freeze_forward(index,fixtures,p/'forward')
repair.write(p/'forward/creation-result.json',result)
review=xg.review_forward(p/'forward',[])
repair.write(p/'forward/pending-review.json',review)
print(result)
print('pending',review['comparison']['pending'])
