import json, hashlib
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
from nations_league import xg_research as xg, repair
from research.analysis_freeze import save, aware, verify
p=Path(__file__).parent
h=repair.read(p/'canonical-history.json'); allx=repair.read(p/'data/xg-records.json')['rows']
indexed=xg.index_xg(allx,h); byid={r['match_id']:r for r in h}; checked=[]
for r in allx:
 if r.get('quality',{}).get('status') not in ('STATS_CAPTURED','REUSED_VERIFIED_CACHE'):continue
 raw=repair.read(r['source_path']); assert repair.sha(r['source_path'])==r['source_sha256']
 assert str(raw['event_id'])==str(r['bsd_event_id'])
 directory=repair.read(r['directory_source_path']); assert repair.sha(r['directory_source_path'])==r['directory_sha256']
 event=next(e for e in directory['results'] if e['id']==r['bsd_event_id'])
 assert event['league_id']==64 and event['season_id']==1430
 assert event['group_name'].startswith('League '+r['league_level']+',')
 assert event['home_score']==r['home_goals'] and event['away_score']==r['away_goals']
 assert aware(event['event_date'])==aware(r['kickoff_at'])
 alias={'Republic of Ireland':'Ireland','Bosnia-Herzegovina':'Bosnia & Herzegovina'}
 for side in ('home','away'):
  assert alias.get(r[side+'_name'],r[side+'_name'])==event[side+'_team']
 vals={'expected':[raw['stats'][s]['expected_goals'] for s in ('home','away')],
       'actual':[raw['stats'][s]['xg']['actual'] for s in ('home','away')],
       'shotmap':[round(sum(float(shot['xg']) for shot in raw['shotmap'] if shot.get('home') is flag and shot.get('xg') is not None),4) for flag in (True,False)]}
 assert all(abs(a-b)<1e-10 for key in vals for a,b in zip(vals[key],r['values'][key])),(r['match_id'],vals,r['values'])
 checked.append(r['match_id'])
assert len(checked)==29
quotes=repair.read('/workspace/WCPP/reports/nations-prematch-20261116-2018/prepared-fixtures.json')
quotes=[r for r in quotes if r['match_id'] in byid]
repair.write(p/'archived-quotes.json',quotes)
repair.write(p/'root-input-verification.json',{'checked_at':xg.now(),'xg_identity_join':len(indexed),'stats_and_directory_reparsed':len(checked),'verified_stats_ids':checked,'target_matches_2026':sum(r['date'].startswith('2026') for r in h),'historical_quoted_targets':len(quotes)})
inputs={name:{'path':str(path),'sha256':repair.sha(path)} for name,path in [('history',p/'canonical-history.json'),('xg',p/'data/xg-records.json'),('quotes',p/'archived-quotes.json')]}
future=repair.read(p/'future-identity.json')
protocol={'schema':'WCPP-NATIONS-XG-PROTOCOL-1','created_at':xg.now(),'arms':xg.ARMS,'fit':{'half_life':730.,'ridge':8.},'selection_window':['2026-10-01','2026-11-01'],'diagnostic_window':['2026-11-12','2026-11-17'],'inputs':inputs,
 'selector':'joint_map','selection_ranking':['primary_hits desc','wdl_hits desc','score_log_loss asc','weight asc','id asc'],
 'historical_scope':'KNOWN_RESULTS_DATE_ROLLING_DEVELOPMENT; not historical as-of certified or untouched test',
 'missing_policy':'per-side actual-goal fallback; all actual labels unchanged',
 'quality_policy':'retain estimated flags and field conflicts, run three separate fields',
 'chronology':'fit per grade and target date using strictly earlier UTC dates; target-game xG never enters its prediction',
 'time_boundaries':'all October and November outcomes already known; October chooses arms, November diagnostic does not retune',
 'training_xg_coverage':{'all_history':len(h),'xg_rows':len(checked),'2026_population':148},
 'selection_ids':[r['match_id'] for r in h if '2026-10-01'<=r['date']<'2026-11-01'],
 'diagnostic_ids':[r['match_id'] for r in h if '2026-11-12'<=r['date']<'2026-11-17'],
 'future_ids':[f['match_id'] for f in future],
 'future_mode':'freeze all 13 arms; selected arm determined only by October; keep original 18-match plan',
 'ou_rule':'real archived/future quote only; choose unit-odds settlement balance; retain full/half wins, pushes, full/half losses',
 'activation':'independent research; no automatic promotion','report':'per-grade metrics plus descriptive pooled totals; date-cluster paired uncertainty'}
assert not (p/'protocol.json').exists()
repair.write(p/'protocol.json',protocol)
shell={'match_id':'nations-xg-protocol:20261117','cutoff_at':xg.now(),'kickoff_at':min((f['kickoff_at'] for f in future),key=aware)}
r=save(protocol,shell,stage='review',track='research-preregistration')
repair.write(p/'protocol-receipt.json',r);repair.write(p/'protocol-freeze.json',verify(repair.read(r['path'])))
print(json.dumps({'protocol':r,'selection_n':len(protocol['selection_ids']),'diagnostic_n':len(protocol['diagnostic_ids']),'xg':len(checked)},ensure_ascii=False))
