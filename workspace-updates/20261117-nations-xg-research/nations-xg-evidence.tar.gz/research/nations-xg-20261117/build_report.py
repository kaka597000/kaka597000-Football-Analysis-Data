import csv,json,re
from pathlib import Path
from collections import Counter
from nations_league import repair,xg_research as xg
from research.analysis_freeze import verify,digest
p=Path(__file__).parent;r=repair.read(p/'experiment/results.json');idx=repair.read(p/'experiment/index.json')
summary={'generated_at':xg.now(),'windows':{},'selected':idx['selected']}
for window,bounds in [('selection',('2026-10-01','2026-11-01')),('diagnostic',('2026-11-12','2026-11-17'))]:
 b=[];c=[]
 for level,v in r['levels'].items():
  b.extend(x for x in repair.read(p/'experiment'/level/'goals-predictions.json') if bounds[0]<=x['date']<bounds[1])
  c.extend(x for x in repair.read(p/'experiment'/level/(v['selected_on_october']+'-predictions.json')) if bounds[0]<=x['date']<bounds[1])
 b.sort(key=lambda x:x['match_id']);c.sort(key=lambda x:x['match_id'])
 summary['windows'][window]={'baseline':xg.summarize(b),'selected':xg.summarize(c),'paired':repair.paired(b,c)}
# Recompute all 1,248 targets from preserved rates, not a cached result table.
replayed=0
for level in r['levels']:
 for arm in xg.ARMS:
  records=repair.read(p/'experiment'/level/(arm['id']+'-predictions.json'))
  for rec in records:
   m=repair.probability_matrix(*rec['base_rates'])
   assert digest(m.tolist())==rec['matrix_hash']
   assert repair.select_score(m)==rec['primary']
   assert rec['training_cutoff']<rec['date']
   assert (rec['primary']==rec['actual'])==rec['primary_hit']
   replayed+=1
assets=repair.read('/workspace/WCPP/reports/nations-review-20261117-0818/review-scope-lock.json')['protected_assets']
assert all(repair.sha(a['path'])==a['sha256'] for a in assets)
forward=[];comparisons=0
for path in sorted((p/'forward/freezes').glob('*.json')):
 record=verify(repair.read(path));fixture=record['fixture'];selected=idx['selected'][fixture['league_level']]
 for arm,pred in record['payload']['predictions'].items():
  artifact=repair.read(idx['routes'][fixture['league_level']][arm]['path'])
  recomputed=xg.prediction(artifact['core'],fixture,pred['version'],pred['artifact_sha256'])
  assert recomputed['matrix_hash']==pred['matrix_hash']
  assert recomputed['primary']==pred['primary'] and recomputed['total']==pred['total']
  comparisons+=1
 pred=record['payload']['predictions'][selected]
 forward.append({'match_id':fixture['match_id'],'home':fixture['home_name'],'away':fixture['away_name'],'level':fixture['league_level'],'kickoff_at':fixture['kickoff_at'],'selected':selected,'score':pred['primary'],'wdl':pred['wdl_reference'],'line':pred['total']['quote']['line'],'total_direction':pred['total']['reference_direction'],'freeze_id':record['freeze_id'],'recorded_at':record['recorded_at']})
summary['execution']={'arms':13,'fitted_final_artifacts':52,'historical_predictions_replayed':replayed,'forward_fixtures':len(forward),'forward_predictions_replayed':comparisons,'protected_asset_hashes_unchanged':len(assets)}
summary['future']=forward
summary['evidence_scope']='Known-history statistical score experiment; selected on October only; future 8 matches pending, no comprehensive Primary performance claim'
repair.write(p/'summary.json',summary)
with (p/'metrics.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['grade','arm','window','n','score_top1_hits','wdl_hits','score_log_loss','quote_n','ou_settlements','selected_on_october'])
 for level,v in r['levels'].items():
  for arm,windows in v['metrics'].items():
   for window,m in windows.items():w.writerow([level,arm,window,m['n'],m['primary_hits'],m['wdl_hits'],m['score_log_loss'],m['actual_line_n'],json.dumps(m['actual_line_settlements']),arm==v['selected_on_october']])
with (p/'future-predictions.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(forward[0]));w.writeheader();w.writerows(forward)
lines=['# 欧国联xG真实实验与后续执行方式','', '2026年11月17日，北京时间。已经训练、比较并冻结下一批；活动模型与旧预测保持原身份。', '',
'用户目标：第一推荐精确比分优先，胜平负和实际盘口大小球独立核算。70%/80%仍是目标，本轮数据远未达到。', '',
'## 已执行', '',
'- 758场真实历史按A/B/C/D分级拟合；2026年148场全部保留。BSD目录身份148/148，xG统计29场：9月19场、11月16日10场。采集途中401后保留成功数据，未因单一来源失败停止训练。',
'- 比较进球基线及三种字段（expected_goals、xg.actual、逐射门合计）×25%、50%、75%、100%，共13个方案。每个比赛日只使用更早日期训练；同场实际进球仍为评价标签。',
'- 旧年份和本批缺失的xG按该场真实进球回退，因此权重100%也不是全历史纯xG。估算/字段冲突保留标记并实测，不自动否决整批。',
'- 10月52场选择方案；11月12–16日44场只作已知结果诊断，不按11月结果重选。所有历史结果在实验前已知，不称全新留出或历史时点认证。',
'- 52份最终工件、1,248条逐场滚动预测已保存。下一批8场×13方案于北京时间10:25实际冻结，8/8附Pinnacle真实总球线和赛前选向。开球为11月18日03:45，全部待结算。', '',
'## 实际结果', '',
'此处比分为统计joint-map Top1，不是人工综合Primary，也不是旧Current模型。基线为相同数据、相同时间更新、相同球队攻防算法的进球版本。', '',
'|窗口|进球基线比分Top1|选中xG方案比分Top1|进球基线胜平负|选中xG方案胜平负|',
'|---|---:|---:|---:|---:|']
for name,title in [('selection','10月开发选择'),('diagnostic','11月已知结果诊断')]:
 a=summary['windows'][name]['baseline'];b=summary['windows'][name]['selected'];n=a['n']
 lines.append(f"|{title}|{a['primary_hits']}/{n}|{b['primary_hits']}/{n}|{a['wdl_hits']}/{n}|{b['wdl_hits']}/{n}|")
lines+=['','11月有10场存档真实盘口，基线和选中方案均为2全赢、1走盘、1半输、6全输；大小球本轮没有改善。其余34场仍参与比分和胜平负比较。10月没有该实验可用的存档盘口，不自设2.5线。', '',
'|等级|10月选中字段/权重|11月比分 基线→候选|11月胜平负 基线→候选|', '|---|---|---:|---:|']
for level,v in r['levels'].items():
 a=v['metrics']['goals']['diagnostic'];b=v['metrics'][v['selected_on_october']]['diagnostic']
 lines.append(f"|{level}|{v['selected_on_october']}|{a['primary_hits']}→{b['primary_hits']} / {a['n']}|{a['wdl_hits']}→{b['wdl_hits']} / {a['n']}|")
lines+=['','11月比分净增1场、胜平负净增1场；按日期聚类的描述性区间包含0。B/C/D部分概率损失变差。结论是出现一个值得前向检验的弱信号，未证明可靠提升；大小球和高比分尾部仍需继续实证研究。', '',
'## 下一批真实冻结', '',
'全部13方案均留档，表中仅显示10月预先选中的方案；不作为用户综合推荐或TOP3榜。单一比分和胜平负边际最优方向可以不同。', '',
'|比赛|方案|统计比分|胜平负|真实总球线及选向|', '|---|---|---|---|---|']
for f in forward:lines.append(f"|{f['home']}—{f['away']}|{f['selected']}|{f['score']}|{f['wdl']}|{f['line']:g} {'大' if f['total_direction']=='over' else '小'}|")
lines+=['','冻结计划：`0d33811468c62416-v000001`。旧18场修复计划和原Current/Test未改。待比赛完赛，调用`xg_research.review_forward`按首次冻结结算，未完赛保持pending。', '',
'## 执行与恢复', '',
'项目规则和运行目录AGENTS已写入用户的“先实际实验”要求。赛事身份、训练时间先后、真实报价时间和原冻结完整性仍保留。', '',
'运行入口：`PYTHONPATH=runtime python -m nations_league.xg_research --protocol /workspace/WCPP/research/nations-xg-20261117/protocol.json --out /tmp/nations-xg-replay`。新输出目录须不存在。', '',
'归档包含协议首版、原文及采集回执、全部历史输入、52工件、1,248逐场结果、8场104份未来预测及校验清单；训练用原始赛果来源可追溯到既有长期修复/复盘归档。', '',
'`summary.json`为汇总，`metrics.csv`为全部13方案对照，`experiment/`为工件和逐场结果，`forward/`为真实冻结与待结算回执。']
(p/'xG研究执行报告.md').write_text('\n'.join(lines)+'\n')
print(json.dumps(summary['execution'],ensure_ascii=False));print(summary['windows']['diagnostic']['paired'])
