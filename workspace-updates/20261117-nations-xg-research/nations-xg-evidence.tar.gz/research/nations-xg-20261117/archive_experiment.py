import json,hashlib,tarfile,shutil,subprocess,sys,platform
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
from nations_league import repair,xg_research as xg
from research.analysis_freeze import save,verify
import numpy,scipy
p=Path(__file__).parent;source=Path('/workspace/Football-Analysis-xg-research-20261117');repo=Path('/workspace/kaka597000-Football-Analysis-Data');dest=repo/'workspace-updates/20261117-nations-xg-research';dest.mkdir(parents=True,exist_ok=False)
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
modules=['runtime/nations_league/xg_research.py','runtime/nations_league/repair.py','runtime/nations_league/repair_forward.py','runtime/v2/model.py','runtime/v2_test/evaluation.py','runtime/research/analysis_freeze.py','runtime/research_program/future_validation.py','runtime/v5/paired_review.py']
identity={'source_commit':commit,'base_main_commit':'3eca355a9e801c15d21c9b9b87e84592be15cee9','pull_request':'https://github.com/kaka597000/Football-Analysis/pull/40','actual_execution_state':'numerical runs used this exact module set before Git commit; file hashes match committed source','dependencies':{f:repair.sha(source/f) for f in modules},'python':sys.version,'numpy':numpy.__version__,'scipy':scipy.__version__,'platform':platform.platform(),'automatic_model_promotion':False}
repair.write(p/'execution-source.json',identity)
for name in modules:
 target=p/'executed-source'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source/name,target)
shutil.copy2('/workspace/WCPP/AGENTS.md',p/'runtime-AGENTS.md')
report={'report_markdown':(p/'xG研究执行报告.md').read_text(),'summary':repair.read(p/'summary.json'),'test_summary':repair.read(p/'test-summary.json'),'execution_source':identity}
f={'match_id':'nations-xg-report:20261117','cutoff_at':xg.now(),'kickoff_at':'2026-11-17T19:45:00Z'}
receipt=save(report,f,stage='review',track='research-xg-results')
repair.write(p/'report-receipt.json',receipt);repair.write(p/'report-freeze.json',verify(repair.read(receipt['path'])))
files=sorted(f for f in p.rglob('*') if f.is_file() and '__pycache__' not in f.parts)
freeze_files={}
for name in ['protocol-receipt.json','report-receipt.json','forward/plan-receipt.json']:
 row=repair.read(p/name);freeze_files[row['path']]=Path(row['path'])
for row in repair.read(p/'forward/receipts.json'):freeze_files[row['path']]=Path(row['path'])
archive=dest/'nations-xg-evidence.tar.gz';entries=[]
with tarfile.open(archive,'w:gz') as tf:
 for f in files:
  member='research/nations-xg-20261117/'+str(f.relative_to(p));tf.add(f,arcname=member,recursive=False)
  entries.append({'member':member,'original_path':str(f),'bytes':f.stat().st_size,'sha256':repair.sha(f)})
 for f in freeze_files.values():
  member=str(f.relative_to('/workspace/WCPP'));tf.add(f,arcname=member,recursive=False)
  entries.append({'member':member,'original_path':str(f),'bytes':f.stat().st_size,'sha256':repair.sha(f)})
manifest={'schema':'WCPP-NATIONS-XG-ARCHIVE-1','created_at':xg.now(),'archive':archive.name,'bytes':archive.stat().st_size,'sha256':repair.sha(archive),'source':identity,'files':entries,'prior_source_evidence_archives':[]}
for name in ['workspace-updates/20261116-nations-repair/nations-repair-evidence.tar.gz','workspace-updates/20261117-nations-review-0833/nations-review-evidence.tar.gz','workspace-updates/20261116-nations-prematch-2044/nations-prematch-evidence.tar.gz']:
 file=repo/name
 if file.exists():manifest['prior_source_evidence_archives'].append({'path':name,'sha256':repair.sha(file),'reuse':'original ESPN history and first frozen quote evidence; no duplicate whole backup'})
repair.write(dest/'manifest.json',manifest)
for name in ['xG研究执行报告.md','summary.json','metrics.csv','future-predictions.csv','test-summary.json','execution-source.json','report-receipt.json']:
 shutil.copy2(p/name,dest/name)
readme=f'''# 欧国联xG研究与未来真实冻结\n\n2026年11月17日，按用户要求直接执行独立实验。源码[PR #40](https://github.com/kaka597000/Football-Analysis/pull/40)，执行代码 `{commit}`。\n\n[研究报告](xG研究执行报告.md)与[全部13方案指标](metrics.csv)。758场真实历史、29场BSD xG，52工件、1,248条历史滚动预测；10月选方案，11月44场诊断比分5→6、胜平负30→31，10场真实盘口大小球无改善。结果属于已知历史统计研究，未证明未来准确率提升。\n\n下一批8场×13方案已于10:25实际赛前冻结，真实总球线覆盖8/8，全部待结算，开球为北京时间11月18日03:45。计划 `0d33811468c62416-v000001`。原18场计划单独保留。\n\n`nations-xg-evidence.tar.gz` SHA256 `{manifest['sha256']}`，{manifest['bytes']:,}字节，{len(entries)}个文件。包含原文、输入、协议、工件、预测、完整新冻结及执行源码。`manifest.json`逐文件哈希与原路径可核查。旧758场赛果的原始ESPN证据复用manifest列出的既有长期归档，不依赖Actions临时artifact。\n\n先在空目录验证和解包：\n\n```bash\npython workspace-updates/20261117-nations-xg-research/verify_archive.py --out /tmp/nations-xg-restore\n```\n\n数值离线重跑（检出源码 `{commit}` 并安装其Python依赖）：\n\n```bash\nPYTHONPATH=runtime python workspace-updates/20261117-nations-xg-research/verify_archive.py --out /tmp/nations-xg-replay --replay\n```\n\n恢复至WCPP时将 `research/nations-xg-20261117` 放到 `/workspace/WCPP/research/`，新增冻结按manifest恢复到 `/workspace/WCPP/forecasts/issued-analyses/`。已有相同哈希可复用；已有不同内容保留另查，不覆盖旧记录。`runtime-AGENTS.md`保存本次研究偏好，恢复时合并这条偏好，保留新环境已有更新。\n\n`xg_research.review_forward(恢复后的forward目录, 已核验赛果列表)`可按首版冻结结算，未完赛保持pending。已有旧18场定时流程不自动纳入本8场新实验；本轮已执行训练与冻结，未另建定时任务。\n'''
(dest/'README.md').write_text(readme)
print(json.dumps({'archive_bytes':manifest['bytes'],'sha256':manifest['sha256'],'files':len(entries),'report_freeze':receipt},ensure_ascii=False))
