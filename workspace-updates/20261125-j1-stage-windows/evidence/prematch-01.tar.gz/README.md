# J1 2026-11-25 pre-match evidence stage

截点为北京时间 2026-11-25 18:00 前。今日 ESPN `jpn.1` / R10 收据共有 7 场成年男子 J1 常规赛。赛事 ID、双方 ESPN ID/名称、FotMob 当日 match ID、开球时点、provider stage 与 R10 原冻结引用见 `fixtures/master-fixtures.json`；阶段定义见 `fixtures/phase-identity.json`。

## Contents

- `future-calendar.jsonl`: ESPN 年度 scoreboard 原始响应中，截至 2027-05-31（北京时间）全部 `regular-season` J1 赛事；每行附 mid、主客 ESPN ID/显示名、UTC 和北京时间开球、stage、status 及源响应 SHA。排除 `2026-j1-100-year-vision-league`。当前返回数据中未见时间未定事件；这只适用于 ESPN 已返回的事件母体。
- `raw/espn_calendar_2026.json`, `raw/espn_calendar_2027.json`: 年度完整原始 scoreboard 响应；精确抓取时间、请求 URL、响应 SHA 与记录数见 `raw/espn-annual-source-manifest.json`。
- `fixtures/team-last-five-xg.json`: 今日 14 队各自最近五场已完赛记录（同一比赛的主客队值来自同一原始响应），逐场列日期、赛事、xG/xGA、射正和字段覆盖。总共 70 个队级记录；xG 双侧覆盖 60/70，射正双侧覆盖 68/70，11 场联赛杯未提供 xG，缺值未填。逐场 raw URL/抓取时点/SHA 与球队赛程原件见 `raw/fotmob-recent-history-source-manifest.json` 和 `matches/`。
- `fixtures/prematch-status-odds-lastfive.json`: ESPN summary 状态、两队 schedule `lastFiveGames`、ESPN 展示赔率与实际抓取时点。ESPN 未给报价更新时间。
- `raw/afc-status-20261125.json`: R10 已首次展示的两场亚冠状态交叉核对。
- `odds/the-odds-api-metadata.json`: 一次联赛级 `soccer_japan_j_league` / `h2h,totals` / EU 请求记录；API key 只由环境读取，记录中不含 key 或 credential-bearing URL。
- `raw/` and `matches/`: 原始公开响应及 URL、UTC 抓取时间、SHA。The Odds API 拒绝响应不保存可能回显凭据的正文，只保存安全状态与额度响应头。

J.League 官方页面已归档，但该页响应未暴露今日逐场的官方赛事行/内部 ID；因此今日逐场赛事核验用 ESPN scoreboard/summary 与 FotMob public API 的一对一赛事、主客、时间和性别字段。FotMob `tournamentStage=16` 原样保留，不自行解释。

The Odds API 本次 HTTP 401，响应额度头 `remaining=0`, `used=500`; 无逐场重试。ESPN 可见 DraftKings 报价仅作为观测值，`quote_updated_at=null`，观测时刻另列。16:56 左右追加回读中，福冈 vs 横滨水手已有 FotMob Opta 来源正式首发（两队各 11 人）；其余 6 场仅 `lastStarting11`。目标响应未提供可用伤停列项，未知不等于无人伤停。最新复核见 `fixtures/lineup-and-injuries.json` 与 `fixtures/status-refresh-1655.json`。

R10 首冻及其完整模型数据未被修改。此目录未新增模型预测或综合结论，也未向外部发布。
