"""Retrospective evidence replay, not a new forecast or fitted market model."""
import sys,json,hashlib,shutil
from pathlib import Path
from datetime import datetime,timezone
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from competition_scope import permitted
from research_program.market_expert import baseline,paired_wdl
root=Path(__file__).parent;raw=root/'raw';raw.mkdir(exist_ok=True)
src=Path('/workspace/WCPP/staging/jingcai-20261102-refresh-1925');analysis=Path('/workspace/WCPP/reports/jingcai-refresh-20261102-1925')
verified={r['lottery_no']:r for r in json.loads((src/'verified-pinnacle-quotes-final.json').read_text())}
batches=[]
for name in ('odds-current-batch.json','odds-final-batch.json'):
 shutil.copyfile(src/name,raw/name)
 for batch in json.loads((raw/name).read_text()):batches.append((name,batch))
results={'espn:'+r['espn_event_id']:r for r in json.load(open('/workspace/WCPP/reports/review-jingcai-20261103/results/results.json')) if r['status']=='completed'}
reports=[];evaluation=[];observations=[]
for row in json.load(open(analysis/'summary.json')):
 n=row['lottery_no'][-3:];f=json.load(open(analysis/(n+'-fixture.json')))
 if not permitted(f) or n in ('001','005'):continue
 q=verified[row['lottery_no']];target=dict(f,home_id=f['home'],away_id=f['away']);obs=[]
 for filename,batch in batches:
  for event in batch.get('response',[]) if isinstance(batch.get('response'),list) else []:
   if event['id']!=q['odds_event_id']:continue
   if datetime.fromisoformat(event['commence_time'].replace('Z','+00:00'))!=datetime.fromisoformat(f['kickoff_at'].replace('Z','+00:00')):raise ValueError('kickoff mismatch')
   for book in event['bookmakers']:
    if book['key']!='pinnacle':continue
    for market in book['markets']:
     if market['key'] not in ('h2h','totals'):continue
     outcomes=market['outcomes'];line=None
     if market['key']=='h2h':
      values={r['name']:r['price'] for r in outcomes};odds={'home':values[event['home_team']],'draw':values['Draw'],'away':values[event['away_team']]}
     else:
      lines={r['point'] for r in outcomes}
      if len(lines)!=1:continue
      line=next(iter(lines));values={r['name']:r['price'] for r in outcomes};odds={'over':values['Over'],'under':values['Under']}
     captured=batch['retrieved_at_utc'];observed={'provider':'the-odds-api','cohort':f['cohort'],'stage':f['stage'],'match_id':f['match_id'],'entity_id':f['home'],'field':'market_quote','period':'regulation_90','event_kickoff_at':f['kickoff_at'],'observed_at':captured,'first_known_at':None,
     'evidence':{'url':batch['source_url'],'file':'raw/'+filename,'sha256':hashlib.sha256((raw/filename).read_bytes()).hexdigest(),'query_time':captured,'identity_verified':True},
     'value':{'bookmaker':'Pinnacle','market':market['key'],'line':line,'quoted_at':market.get('last_update') or book['last_update'],'odds':odds}}
     obs.append(observed)
 report=baseline(obs,target,root,bookmaker='Pinnacle');reports.append(report);observations.extend(obs)
 model=json.load(open(analysis/(n+'-unified.json')))['current_test_pair']['current_model']
 actual=results[f['match_id']];h,a=actual['home_goals'],actual['away_goals']
 evaluation.append({'match_id':f['match_id'],'market_wdl':report['wdl']['probabilities'] if report['wdl'] else None,'current_wdl':[model['wdl'][k] for k in ('主胜','平局','客胜')],'actual_wdl':0 if h>a else 1 if h==a else 2})
result={'created_at':datetime.now(timezone.utc).isoformat(),'scope':'retained Nov2 revised forecast, newly declared 18-competition subset; post-hoc development only','market_reports':reports,'paired_wdl':paired_wdl(evaluation),'new_forecast':False,'historical_first_known_certified':False,'score_model_trained':False,'incremental_value_proven':False}
(root/'observations.json').write_text(json.dumps(observations,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(root/'report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(result['paired_wdl'])
