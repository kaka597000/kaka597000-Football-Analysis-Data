"""Append an xG source audit; preserve the earlier review and all forecasts."""
import json,hashlib,sys,tarfile,os,shutil
from pathlib import Path
from datetime import datetime,timezone
sys.path.insert(0,'/workspace/Football-Analysis-nations-repair-20261116/runtime')
from research.analysis_freeze import save,verify
R=Path(__file__).resolve().parent;W=Path('/workspace/WCPP').resolve();OLD=Path('/workspace/WCPP/reports/nations-review-20261117-0818');D=Path('/workspace/kaka597000-Football-Analysis-Data/workspace-updates/20261117-xg-availability')
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
a=read(R/'root-audit.json');old=read(OLD/'delivery.json');lock=read(OLD/'review-scope-lock.json')
assert verify(read(old['report_receipt']['path']))['record_sha256']==old['report_receipt']['sha256']
for p in lock['protected_assets']:assert sha(p['path'])==p['sha256']
lines=['# 欧国联xG获取实测｜北京时间2026年11月17日','','**能获取。BSD已实际返回昨晚10场欧国联的数值xG字段，比赛身份和90分钟赛果10/10一致。** 此前复盘仅确认ESPN原文无xG，没有把BSD统计补上，采集覆盖不完整。本次补充来源证据，原预测、命中统计和08:32复盘冻结均保留。','',
'本次使用现有BSD授权，1次按日期获取赛事，随后10次统计接口均HTTP200。API-Football云环境绑定返回403后停止，FotMob所测赛程URL返回404；不需要等这两条恢复才能从BSD取得数据。合计13次HTTP请求，没有关闭TLS、购买订阅或新建定时任务。','',
'下表保留提供方的两种原始汇总字段，主队在前。未指定其中一列为已认证的唯一标准；数据是赛后补采，不是本场赛前已知特征。','',
'|比赛|90分钟赛果|expected_goals 主/客|xg.actual 主/客|汇总是否相同|','|---|---|---|---|---|']
for x in a['rows']:
 h,v=x['sides']['home'],x['sides']['away'];same=all(s['aggregate_field_delta']==0 for s in x['sides'].values())
 lines.append(f"|{x['name']}|{x['actual_score']}|{h['expected_goals']:.2f} / {v['expected_goals']:.2f}|{h['xg_actual']:.2f} / {v['xg_actual']:.2f}|{'相同' if same else '不同'}|")
lines+=['','## 数据已取得，口径仍需核验','',
'- 5场两种汇总字段不完全一致：哈萨克斯坦、冰岛、德国、瑞士、希腊。不能在看过赛果后选更符合叙事的数值，也不能先平均成一个自造xG。','- 法罗、哈萨克的赛事列表写has_xg=false，统计接口却有数值。目录标记不能作为唯一是否采集的依据；实际接口结果及冲突已保存。','- 瑞士整场xg_estimated=true，但双方汇总xg.estimated=false，射门记录里也混有估算标记。必须保留字段层级及原始标记，不能称全场原生数据已认证。','- 所有10场还返回了逐射门xG和分钟累计，可进一步核对。斯洛文尼亚汇总8次射门、shotmap只有7条，汇总xG为1.88、现有射门xG合计1.6389；其他比赛也有不同程度的累计差值。差值已记录，未擅自补射门或覆盖汇总。','- 原文未给出足以独立确认的上游模型/来源版本。xG本来就是机会质量模型的估计；这里的estimated标记指提供方所声明的计算或补值方式，不能据false就声称数据来自Opta。','',
'因此，**接口数值覆盖10/10，不等于10/10已通过训练数据验收。** 可先作明确标注来源与冲突的复盘补充。当前没有将任一冲突值自动写入活动训练表或静默替换模型输入；不同源的xG、派生估算、泊松进球均值分开保存。','',
'## 对当前项目的用途','',
'可以用统一来源的历史xG/xGA比较创造机会与实际进球，帮助区分机会生成、终结和门将表现；本批先提供可追溯数据及冲突清单。冰岛的两套汇总都显示明显机会优势，但德国实际5-0对应汇总约1.52–1.55对1.19，也提醒不能仅凭射正10-1就把五球差完全解释为机会质量差距。这里的区间只是两个字段的取值范围，不是置信区间；原因判断仍需口径核验。','',
'欧国联现有研究工件的untrained_features仍明确包含xg。拿到这10场数据不等于xG权重已训练。数值接入应先统一字段、估算标记及同源历史覆盖，在赛前可知时点构造特征，再独立时间验证。赛后数据可以服务后续赛事，但不能回填本批赛前预测。','',
'本次全部为赛后证据追加；既有18场前向计划与原10场复盘统计不变。下一步的数据工作是解释BSD汇总/逐射门差异、确认来源定义，再补同源历史窗口；本次没有声称这些后续工作已经完成。','',
'## 来源与复核','',
'[BSD德国比赛统计](https://sports.bzzoiro.com/api/v2/events/212726/stats/)（需要授权）；完整逐场URL、请求起止、HTTP状态和原文SHA在request-manifest.json及root-audit.json。采集时间为北京时间11月17日08:46–08:48附近，精确时间见清单；不拿抓取时间冒充来源更新时点。','',
'root-audit.json验证赛事名称、provider ID、成年男欧国联级别/组别、开球、90分钟赛果、数值范围、统计字段及射门累计，CSV展示原始字段。数据源自身字段冲突原样保留；没有其他xG来源对这些数值进行独立交叉认证。','',
'原复盘固定提交：0e06c14e8338c7bca9b9f07ee68345dfe6930e41，归档workspace-updates/20261117-nations-review-0833/。本次另存来源审计冻结，旧报告不覆盖。']
report='\n'.join(lines)+'\n';(R/'xG获取核查.md').write_text(report)
receipt=save(dict(report_markdown=report,audit=a,collection_summary=read(R/'summary.json'),request_manifest=read(R/'request-manifest.json'),previous_review=old['report_receipt'],active_registry_sha256=lock['active_registry_sha256'],forecasts_changed=False,model_ingested=False),dict(match_id='xg-source-audit:20261117-nations10',kickoff_at=min(x['kickoff_at'] for x in a['rows']),cutoff_at=datetime.now(timezone.utc).isoformat()),stage='review',track='xg-availability')
assert verify(read(receipt['path']))['record_sha256']==receipt['sha256']
delivery=dict(receipt=receipt,source_commit=lock['source_commit'],retrieved=10,aggregate_field_conflict_matches=5,previous_review_unchanged=True,active_registry_unchanged=True,training_runs=0,model_promoted=False)
(R/'delivery.json').write_text(json.dumps(delivery,ensure_ascii=False,indent=2)+'\n')
D.mkdir(parents=True,exist_ok=False);files={}
for p in list(R.rglob('*'))+[Path(receipt['path'])]:
 if p.is_file() and '__pycache__' not in p.parts:files['WCPP/'+str(p.resolve().relative_to(W))]=p
secrets=[v.encode() for k,v in os.environ.items() if len(v)>=12 and any(s in k.upper() for s in ['SECRET','TOKEN','API_KEY','APIKEY'])]
for p in files.values():
 if any(s in p.read_bytes() for s in secrets):raise ValueError('credential detected')
archive=D/'xg-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for name,p in sorted(files.items()):tar.add(p,arcname=name,recursive=False)
manifest=dict(archive=dict(file=archive.name,bytes=archive.stat().st_size,sha256=sha(archive)),files=[dict(path=n,bytes=p.stat().st_size,sha256=sha(p)) for n,p in sorted(files.items())],previous_review_data_commit='0e06c14e8338c7bca9b9f07ee68345dfe6930e41',receipt=receipt)
with tarfile.open(archive,'r:gz') as tar:
 for f in manifest['files']:
  body=tar.extractfile(f['path']).read();assert hashlib.sha256(body).hexdigest()==f['sha256'] and len(body)==f['bytes']
(D/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
for n in ['xG获取核查.md','xG字段对照.csv','root-audit.json','request-manifest.json','delivery.json']:shutil.copyfile(R/n,D/n)
(D/'README.md').write_text('''# 欧国联xG来源补采

[核查报告](xG获取核查.md) · [两种汇总及逐射门对照表](xG字段对照.csv) · [独立原文审计](root-audit.json) · [冻结回执](delivery.json)

BSD返回10/10赛事xG字段，5场两种汇总值不同，2场目录可用标记矛盾、1场估算标记跨层级矛盾。取得数值与通过训练验收分开。此前复盘未补查BSD；本增量补充证据，不修改旧预测、旧复盘或活动模型。

压缩包保存成功响应原文、请求元数据、逐场字段、独立审计脚本与来源审计冻结；manifest含包及逐文件SHA，均从压缩包读回核验。恢复采用WCPP/相对路径，原10场身份与冻结基准复用workspace-updates/20261117-nations-review-0833/长期归档，不重复上传全部运行资产。缺来源时间保持未知；旧冻结不得被覆盖。
''')
print(json.dumps(dict(delivery=delivery,archive=manifest['archive'],files=len(files)),ensure_ascii=False))
