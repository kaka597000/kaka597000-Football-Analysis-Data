# 2026-11-16 欧国联 xG 可获取性核查

## 结论

能取得数值字段，但这批响应不能证明它们是口径可靠、来源已验证的观测xG。BSD按日期接口准确找到冻结范围10场，10场`/stats/`均返回HTTP 200并出现`stats.{home,away}.xg.actual`数值；但赛事目录对法罗群岛—摩尔多瓦、哈萨克斯坦—斯洛伐克标记`has_xg=false`，而详情仍返回非零数值。瑞士—苏格兰详情顶层`xg_estimated=true`，分队字段却均写`estimated=false`。此外若干场`xg.actual`与并列`expected_goals`不一致。BSD响应未独立说明上游来源/计算模型，因此本报告不将它们认证为可入模观测xG。

API-Football在唯一一次请求返回403后停止；FotMob公开`/api/matches?date=20261116`返回404，未进行域名/客户端绕行。ESPN已有原文无xG记录复用。旧记录已有联赛级FotMob xG正样本，说明“能从部分联赛来源取得”，不证明欧国联覆盖或BSD质量。

## 逐场响应

| 比赛 | BSD赛事ID | `/stats/*/xg.actual` 主/客 | 状态 |
|---|---:|---:|---|
| Faroe Islands–Moldova | 212721 | 2.78 / 1.36 | NUMERIC_RESPONSE_WITH_PROVENANCE_CONFLICT (has_xg=False, xg_estimated=False) |
| Kazakhstan–Slovakia | 212722 | 0.78 / 1.93 | NUMERIC_RESPONSE_WITH_PROVENANCE_CONFLICT (has_xg=False, xg_estimated=False) |
| Iceland–Luxembourg | 212724 | 3.32 / 0.07 | NUMERIC_RESPONSE_WITH_PROVENANCE_CONFLICT (has_xg=True, xg_estimated=False) |
| Estonia–Bulgaria | 212723 | 0.86 / 0.46 | NUMERIC_RESPONSE_FLAGS_CONSISTENT (has_xg=True, xg_estimated=False) |
| Lithuania–Liechtenstein | 212725 | 3.17 / 0.37 | NUMERIC_RESPONSE_FLAGS_CONSISTENT (has_xg=True, xg_estimated=False) |
| Gibraltar–Malta | 212728 | 0.29 / 1.73 | NUMERIC_RESPONSE_FLAGS_CONSISTENT (has_xg=True, xg_estimated=False) |
| Germany–Netherlands | 212726 | 1.55 / 1.19 | NUMERIC_RESPONSE_WITH_PROVENANCE_CONFLICT (has_xg=True, xg_estimated=False) |
| Switzerland–Scotland | 212712 | 2.23 / 1.32 | NUMERIC_RESPONSE_WITH_PROVENANCE_CONFLICT (has_xg=True, xg_estimated=True) |
| North Macedonia–Slovenia | 212711 | 0.43 / 1.88 | NUMERIC_RESPONSE_FLAGS_CONSISTENT (has_xg=True, xg_estimated=False) |
| Greece–Serbia | 212727 | 1.55 / 0.14 | NUMERIC_RESPONSE_WITH_PROVENANCE_CONFLICT (has_xg=True, xg_estimated=False) |

`xg.actual=0`真零与占位判断未触发：10场两队值均非零。具体并列字段与差异见`coverage.json`。每个请求的清洗后原文、URL、时间、HTTP与SHA-256见`request-manifest.json`；原始成功响应位于`raw/`。无浏览器网页核验。
