"""Audit retrieved provider xG without altering old forecasts or training data."""
import json,hashlib,math,re,csv
from pathlib import Path
from datetime import datetime,timezone
R=Path(__file__).resolve().parent;OLD=Path('/workspace/WCPP/reports/nations-review-20261117-0818')
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
lock=read(OLD/'review-scope-lock.json');results={r['match_id']:r for r in read(OLD/'verified-results.json')}
directory=read(R/'raw/bsd-events-20261116.json');meta=read(R/'bsd-events-call.json')
assert meta['http_status']==200 and sha(R/'raw/bsd-events-20261116.json')==meta['response_sha256']
assert directory['next'] is None
rows=[]
for item in lock['fixtures']:
 f=item['fixture'];actual=results[f['match_id']]
 matches=[x for x in directory['results'] if x['home_team']==f['home_name'] and x['away_team']==f['away_name'] and datetime.fromisoformat(x['event_date'])==datetime.fromisoformat(f['kickoff_at'].replace('Z','+00:00'))]
 assert len(matches)==1;e=matches[0]
 assert e['league_id']==64 and e['season_id']==1430 and e['stage']=='group-stage'
 assert re.fullmatch(r'League '+f['league_level']+r', Group \d+',e['group_name'])
 assert e['status']=='finished' and e['period']=='FT' and e['penalty_shootout'] is None and e['extra_time_score'] is None
 assert (e['home_score'],e['away_score'])==(actual['home_goals'],actual['away_goals'])
 raw=R/'raw'/f"bsd-stats-{e['id']}.json";d=read(raw);call=read(R/f"bsd-stats-{e['id']}-call.json")
 assert call['http_status']==200 and sha(raw)==call['response_sha256'] and d['event_id']==e['id']
 assert datetime.fromisoformat(call['ended_at'])>=datetime.fromisoformat(call['started_at'])
 sides={};issues=[]
 for side,home in [('home',True),('away',False)]:
  s=d['stats'][side];x=s['xg'];a,b=s['expected_goals'],x['actual']
  assert all(type(v) in [int,float] and math.isfinite(v) and v>=0 for v in [a,b])
  shots=[q for q in d.get('shotmap',[]) if q.get('home') is home]
  assert all(type(q.get('xg')) in [float,int] and 0<=q['xg']<=1 for q in shots)
  shot_sum=math.fsum(q['xg'] for q in shots);times=d.get('xg_per_minute',[])
  sides[side]=dict(expected_goals=a,xg_actual=b,xg_estimated=x['estimated'],total_shots=s['total_shots'],shotmap_rows=len(shots),shotmap_xg_sum=shot_sum,shotmap_estimated_rows=sum(q.get('xg_estimated') is True for q in shots),shotmap_null_estimation_flag_rows=sum(q.get('xg_estimated') is None for q in shots),minute_final=times[-1].get('cum_'+side) if times else None,aggregate_field_delta=round(b-a,8),nested_vs_shots_delta=round(b-shot_sum,8))
  if a!=b:issues.append(side+':AGGREGATE_FIELDS_DIFFER')
  if len(shots)!=s['total_shots']:issues.append(side+':SHOT_COUNT_DIFFERS')
  if abs(b-shot_sum)>.005:issues.append(side+':SHOT_SUM_OUTSIDE_TWO_DECIMAL_ROUNDING_RANGE')
  if d.get('xg_estimated')!=x['estimated']:issues.append(side+':MATCH_AND_TEAM_ESTIMATION_FLAGS_DIFFER')
 if e['has_xg'] is False:issues.append('DIRECTORY_SAYS_NO_XG_BUT_STATS_HAS_VALUES')
 rows.append(dict(match_id=f['match_id'],name=item['name'],bsd_event_id=e['id'],bsd_team_ids=dict(home=e['home_team_id'],away=e['away_team_id']),league_level=f['league_level'],kickoff_at=f['kickoff_at'],actual_score=f"{actual['home_goals']}-{actual['away_goals']}",directory_has_xg=e['has_xg'],match_xg_estimated=d.get('xg_estimated'),sides=sides,quality_findings=issues,retrieved=True,source_url=call['url'],source_path=str(raw),source_sha256=call['response_sha256'],observed_at=call['ended_at'],source_quote_time=None,source_contract='Provider-reported values; upstream xG model and conflicting field contract not independently certified',model_ingested=False,prematch_backfilled=False))
out=dict(schema='WCPP-XG-AVAILABILITY-AUDIT-20261117-1',verified_at=datetime.now(timezone.utc).isoformat(),population=10,retrieved=10,score_and_identity_agree=10,both_aggregate_fields_equal=sum(all(s['aggregate_field_delta']==0 for s in x['sides'].values()) for x in rows),aggregate_field_conflict_matches=sum(any(s['aggregate_field_delta']!=0 for s in x['sides'].values()) for x in rows),directory_availability_conflicts=sum(not x['directory_has_xg'] for x in rows),match_estimated_true=sum(x['match_xg_estimated'] is True for x in rows),native_upstream_independently_certified=0,selected_authoritative_field=None,numeric_model_ingested=0,prematch_backfilled=False,interpretation='10/10 returned xG fields; this is acquisition coverage, not 10/10 clean native-xG certification. Both aggregate fields and shotmaps retained. Rounding-range findings are diagnostics, not provider-certified error thresholds.',previous_review=str(OLD/'delivery.json'),rows=rows)
with (R/'root-audit.json').open('x') as h:json.dump(out,h,ensure_ascii=False,indent=2,allow_nan=False)
with (R/'xG字段对照.csv').open('x',encoding='utf-8-sig',newline='') as h:
 w=csv.writer(h);w.writerow(['比赛','赛果','expected_goals主','expected_goals客','xg.actual主','xg.actual客','逐射门xG合计主','逐射门xG合计客','整场估算标记','目录has_xg','质量事项','BSD赛事ID','响应时间','原文SHA256'])
 for x in rows:
  a,b=x['sides']['home'],x['sides']['away'];w.writerow([x['name'],x['actual_score'],a['expected_goals'],b['expected_goals'],a['xg_actual'],b['xg_actual'],a['shotmap_xg_sum'],b['shotmap_xg_sum'],x['match_xg_estimated'],x['directory_has_xg'],';'.join(x['quality_findings']),x['bsd_event_id'],x['observed_at'],x['source_sha256']])
print(json.dumps({k:v for k,v in out.items() if k not in ['rows','interpretation']},ensure_ascii=False))
