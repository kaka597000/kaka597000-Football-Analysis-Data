from common import *
from collections import Counter
import os
import shutil
import tarfile
import openpyxl
import xlsxwriter

WORKTREE=Path('/workspace/Football-Data-nov22-review-20261123')
DEST=WORKTREE/'workspace-updates/20261123-nov22-review-nonmls'
DEST.mkdir(exist_ok=True)
l=lock(); matches=l['population']; groups=l['ranked']
A=read(D/'verified-results.json'); P=read(D/'verified-process.json')
E=read(D/'match-evaluations.json'); M=read(D/'metrics.json'); N=read(D/'model-evaluations.json')
S=read(D/'selection-review.json')
assert len(A)==len(P)==M['groups']['first']['finished']==30
asian={'win':'全赢','half_win':'半赢','push':'走盘','half_loss':'半输','loss':'全输','abstention':'观望'}
groups_labels=[('first','首版全量'),('first_on_update_games','首版 · 同16场'),('update','23:34修订版'),('first_top3','首版推荐三场'),('update_top3','本轮推荐三场')]
def percent(n,d):return f'{n}/{d}（{n/d:.1%}）' if d else '—'
def scores(s):return s.replace('-','–')
def wx(r):return '—' if not r.get('postmatch_xg') else '–'.join(f'{x:.2f}' for x in r['postmatch_xg'])
def hit_label(rank):return {1:'第1比分',2:'第2比分',3:'第3比分',None:'未命中'}[rank]
def total_line(r):
    if not r['total_direction']:return '观望'
    return f"{r['total_direction']}{r['total_line']:g}"
def total_str(z):
    obj=z['totals']; n=z['total_eligible']
    return f"{n}场，"+'、'.join(f'{obj[k]}{asian[k]}' for k in asian if obj[k])
def row_view(r):
    return [bjt(r['provider_kickoff_at']),r['league'],r['teams'],scores(r['result']),scores(r['primary']),
            '、'.join(map(scores,r['alternates'])),hit_label(r['hit_rank']),f"{r['wdl']} {'✓' if r['wdl']==r['actual_wdl'] else '×'}",
            total_line(r),asian[r['settlement']],wx(r),r['ref']['freeze_id']]
first=E['first']
diag=M['first_goal_diagnostics']; f=M['groups']['first']; v=M['groups']['update']; side=M['frozen_model_totals']
common13=[i for i,r in E['update'].items() if r['settlement']!='abstention']
common13first=sum(first[i]['settlement']=='win' for i in common13)
common13new=sum(E['update'][i]['settlement']=='win' for i in common13)
older=read('/workspace/WCPP/reports/all-review-20261122-1255/match-evaluations.json')['first']
previous=[r for i,r in older.items() if r['cohort']!='usa.1' and i not in matches]
count=len(previous)+f['finished']; cumulative_first=sum(r['first_hit'] for r in previous)+f['exact_first']; cumulative_three=sum(r['three_hit'] for r in previous)+f['exact_three']
cumulative_four=sum(r['actual_total']>=4 for r in previous)+len(diag['four_plus'])
cumulative_primary_four=sum(r['primary_total']>=4 for r in previous)+len(diag['primary_four_plus'])
cumulative_above=sum(r['actual_total']>max(r['candidate_totals']) for r in previous)+len(diag['above_all_three'])
def table_header(columns):
    return ['| '+' | '.join(columns)+' |','| '+' | '.join('---' for _ in columns)+' |']
def row_md(vals):
    return '| '+' | '.join(map(str,vals))+' |'
decision=[
    f"本轮30场首版共{f['exact_first']}个第一比分命中，三选命中{f['exact_three']}场。和上一批排除美职联、无重复的48场合计，第一比分{percent(cumulative_first,count)}，三选{percent(cumulative_three,count)}。两批实战至少4球共{cumulative_four}场，首选至少4球共{cumulative_primary_four}场，{cumulative_above}场的实际总球超过了三个比分的上限。",
    f"实际至少4球{len(diag['four_plus'])}/30，首版第一比分只有{len(diag['primary_four_plus'])}/30；当前模型与测试模型按各场完整比分分布累加的至少4球的期望场数分别为{side['current_model']['mass_4_or_more_sum']:.1f}、{side['test_model']['mass_4_or_more_sum']:.1f}。已有模型分布对高比分偏轻，综合三选也有{len(diag['above_all_three'])}场整体低于实战总球。",
    f"保留当前活动模型。追加检查高总球赛事的三选覆盖，优先比较热门队单边爆发与双方互攻两条路径。已经用于本次诊断的30场作为开发样本。下一次检查使用新一批真实赛前冻结的同场配对，比较第一比分、三选净增及实盘结算。"
]
markdown=['# 11月22日至23日赛后复盘（排除美职联）','',
    '范围按11月22日17:31首版的33场原单锁定，按要求排除3场美职联。30场的ESPN和FotMob常规时间全场赛果均一致，23:34版本在这30场中覆盖16场。比分均为主队在前。','',
    '## 命中结果','',*table_header(['范围','第一比分','三选比分','胜平负','实盘大小球','大小球全赢率（扣走盘）'])]
summary=[]
for label,name in groups_labels:
    z=M['groups'][label]; n=z['finished']; tu=z['total_full_win_nonpush_denominator']
    rr=[name,percent(z['exact_first'],n),percent(z['exact_three'],n),percent(z['wdl'],n),total_str(z),percent(z['totals']['win'],tu)]
    summary.append(rr);markdown.append(row_md(rr))
markdown+=['',f'首版三选的命中顺序为第一比分{f["rank_counts"][0]}场、第二比分{f["rank_counts"][1]}场、第三比分{f["rank_counts"][2]}场。修订版的同16场第一比分、三选和胜平负净变化均为0。在13场首版和修订版均可结算的盘口上，全赢从{common13first}场降到{common13new}场。巴甲3场修订版因盘口观望保留在场次分母内，大小球单独记账。','',
    '## 两版推荐三场','',*table_header(['版本','名次','对阵','首选','赛果','比分','胜平负','大小球结果'])]
toprows=[]
for key,title in [('first_top3','首版'),('update_top3','23:34版')]:
    for r in E['ranked'][key]:
        row=[title,r['rank'],r['teams'],scores(r['primary']),scores(r['result']),hit_label(r['hit_rank']),
             f"{r['wdl']} {'✓' if r['wdl']==r['actual_wdl'] else '×'}",f"{total_line(r)} {asian[r['settlement']]}"]
        toprows.append(row);markdown.append(row_md(row))
markdown+=['',f"首版推荐三场的冻结号为 `{groups['first_top3']['ref']['freeze_id']}`。23:34版的冻结号为 `{groups['update_top3']['ref']['freeze_id']}`。",'',
    '## 两套活动模型和近期研究','',*table_header(['预测轨道','第一比分','三选比分','胜平负','大小球 全赢/半赢/走盘/半输/全输（有效场次）'])]
model_rows=[]
for role in ('当前模型','test模型'):
    obj=N['native_first']['models'][role]
    for version,z in obj['by_version'].items():
        count3=obj['three_scores_by_version'][version]
        rr=[f'{role} {version}',percent(z['primary_hits'],z['primary_eligible']),percent(count3['hits'],count3['finished']),percent(z['wdl_hits'],z['wdl_eligible']),'/'.join(str(x) for x in z['total_settlements'].values())+f"（{z['total_eligible']}）"]
        markdown.append(row_md(rr));model_rows.append(rr)
for name,c in M['method_candidates'].items():
    n=c['finished']; rr=[name,percent(c['first_hits'],n),percent(c['three_hits'],n),'—','—']; markdown.append(row_md(rr));model_rows.append(rr)
cv=S['by_model_version']['current_model:WCPP-MAIN-1.2'];tv=S['by_model_version']['test_model:WCPP-ML-0.1']
markdown+=['',f"同场比较时，综合首选相对其引用的当前模型净命中{cv['net_hits']:+d}，相对引用的测试模型净命中{tv['net_hits']:+d}。英超两场的活动模型较早原单与本批综合引用的活动模型版次不同，盘口统计保留各自报价时间。",'',
    '## 比分为什么拉开','',
    f"- 30场实战共{diag['actual_goals']}球，首版第一比分合计{diag['primary_goals']}球。FotMob赛后xG合计{M['postmatch_xg_sum']:.2f}，当前和测试模型赛前均值累计{side['current_model']['mean_total_goals_sum']:.2f}、{side['test_model']['mean_total_goals_sum']:.2f}。实际机会量也明显超过模型均值。",
    f"- 实际有{len(diag['above_all_three'])}场总进球越过三个比分的上限，{len(diag['below_all_three'])}场低于三个比分的下限。首版把1–1排首{diag['one_one_predicted']}次，实际出现{diag['one_one_actual']}次，首选命中1场。",
    f"- 胜平负首版选主胜{diag['wdl_predicted'].get('主胜',0)}场、客胜{diag['wdl_predicted'].get('客胜',0)}场、平局{diag['wdl_predicted'].get('平局',0)}场。实际有{diag['wdl_actual'].get('平局',0)}场平局。全场比分的平局概率与单格1–1继续独立检查。",
    "- 利物浦4–0曼联。曼联第8分钟被罚下一人，利物浦第10和第13分钟已连进两球，全场xG 4.35比0.65，原先1–1的路径在开局就被打破。",
    "- 亚特兰大4–4国米。全场xG 3.10比3.38，两队都创造了大量机会。国米三次领先两球，亚特兰大仍追成平局。首版保留了1–1、0–1，没有覆盖双方连续进球的路径。",
    "- 不来梅4–0汉堡。半场0–0，全场xG仅1.52比1.54。不来梅下半场集中兑现机会，本场比分偏差主要体现在实际进球转化。尤文4–0威尼斯也在半场0–0后连进四球，主队xG为1.84。",
    "- 马赛2–3勒芒。勒芒的4.01 xG高于马赛1.42，马赛主胜信号与实际机会差异明显。特温特2–1威廉二世则相反，威廉二世少一人且仅0.08 xG仍率先进球，首版第三比分覆盖了这个分支。",
    "- 奥斯陆KFUM—布兰的赛前原定开球是00:00，赛后两源均给02:00，比赛ID及球队一致，3–4纳入同一场结算。奥格斯堡—美因茨的FotMob红牌事件属于教练曼努埃尔·鲍姆，球员红牌计数为0。",
    '', '## 调整决定','',*[f'- {x}' for x in decision],
    '', '## 逐场首版结算','',*table_header(['北京时间','赛事','对阵','90分钟','首选','两个备选','命中','胜平负','大小球','结算','xG'])]
for r in first.values():markdown.append(row_md(row_view(r)[:-1]))
markdown+=['','## 23:34修订版逐场结算','',*table_header(['北京时间','赛事','对阵','90分钟','首选','两个备选','命中','胜平负','大小球','结算','xG'])]
for r in E['update'].values():markdown.append(row_md(row_view(r)[:-1]))
markdown+=['','[Excel 明细](review.xlsx) · [复盘冻结回执](review-receipts.json) · [来源与核验](verification.json)','']

def equity(reviews):
    actual=read(D/'verified-results.json')
    out={}
    for i,s in matches.items():
        a=actual[i]; assert a['status']=='completed'
        r=first[i]; log={k:P[i][k] for k in ['xg','goals','red_events','halftime']}
        rr={'fixture_identity':{k:s[k] for k in ('id','cohort','home','away','fotmob')},
            'first_review':r,'revision_review':E['update'].get(i),'score_evidence':a,'process':log,
            'decision':decision,'version':'WCPP-NOV22-NONMLS-REVIEW-1'}
        ff=dict(load(s['first'])['fixture'],cutoff_at=a['observed_at'])
        receipt=save(rr,ff,stage='review',track='comprehensive',idempotency_key='20261123-postmatch-nov22-exclude-mls')
        assert load(receipt)['payload']['first_review']['ref']==s['first']
        out[i]=receipt
    stamp=max([a['observed_at'] for a in actual.values()],key=aware)
    p=read(D/'review-batch.json') if (D/'review-batch.json').exists() else {'fixture':{'match_id':'review:scope-nov22-nonmls',
         'cohort':'configured-scope','kickoff_at':min(v['kickoff_at'] for v in matches.values()),'cutoff_at':stamp},
         'payload':{'scope':list(matches),'excluded_user_mls':l['excluded_explicit_mls'],'match_reviews':out,
            'group_metrics':M['groups'],'first_prediction_top3':l['ranked']['first_top3']['ref'],'revision_prediction_top3':l['ranked']['update_top3']['ref'],
            'decision':decision,'review_text':reviews}}
    write(D/'review-batch.json',p)
    batch=save(p['payload'],p['fixture'],stage='review',track='batch-review',idempotency_key='20261123-postmatch-nov22-exclude-mls')
    assert load(batch)['payload']['group_metrics']==M['groups']
    return {'matches':out,'batch':batch}
success=equity('\n'.join(markdown))
write(D/'review-receipts.json',success)
markdown+=['',f"全批复盘冻结号 `{success['batch']['freeze_id']}`，北京时间 {bjt(success['batch']['recorded_at'])}。",'']
(DEST/'README.md').write_text('\n'.join(markdown))
shutil.copy2(DEST/'README.md',D/'11月22日非美职联30场复盘.md')
shutil.copy2(D/'review-receipts.json',DEST/'review-receipts.json')
shutil.copy2(D/'metrics.json',DEST/'metrics.json')
shutil.copy2(D/'match-evaluations.json',DEST/'match-evaluations.json')

file=DEST/'review.xlsx'
book=xlsxwriter.Workbook(file)
book.set_properties({'title':'11月22日至23日非美职联30场赛后复盘'})
title=book.add_format({'bold':True,'font_size':17,'font_color':'#FFFFFF','bg_color':'#17364A','valign':'vcenter','indent':1})
sub=book.add_format({'font_color':'#31576A','bg_color':'#E5F2EF','text_wrap':True,'valign':'vcenter','indent':1})
header=book.add_format({'bold':True,'font_color':'#FFFFFF','bg_color':'#2A6458','text_wrap':True,'valign':'vcenter'})
body=[book.add_format({'font_size':10,'font_color':'#183646','valign':'vcenter','text_wrap':True,'bg_color':c}) for c in ['#FFFFFF','#F0F6F5']]
strong=[book.add_format({'bold':True,'font_size':11,'font_color':'#11644F','valign':'vcenter','bg_color':c}) for c in ['#E3F4EB','#D4EEE3']]
def add_table(name,headline,caption,columns,rows,mark):
    sh=book.add_worksheet(name)
    sh.hide_gridlines(2); sh.set_row(0,32); sh.set_row(1,30); sh.set_row(3,31)
    sh.merge_range(0,0,0,len(columns)-1,headline,title)
    sh.merge_range(1,0,1,len(columns)-1,caption,sub)
    for j,(name,width) in enumerate(columns):
        sh.set_column(j,j,width); sh.write(3,j,name,header)
    for i,row in enumerate(rows,4):
        sh.set_row(i,28); sh.write_row(i,0,row,body[i%2])
        sh.write(i,mark,row[mark],strong[i%2])
    sh.freeze_panes(4,2);sh.autofilter(3,0,3+len(rows),len(columns)-1)

add_table('全批指标','非美职联30场　｜　复盘汇总','两版按各自赛前冻结独立结算。大小球全赢率扣除走盘，半赢另列。',[('范围',24),('第一比分',20),('三选比分',20),('胜平负',20),('实盘大小球',60),('大小球全赢率',22)],summary,1)
add_table('两版首选三场','两次赛前冻结的三场推荐','含两次都入选的赫塔费—马竞。该场在全量中只计一次。',[('版本',14),('名次',9),('比赛',34),('首选',13),('90分钟',13),('比分',14),('胜平负',14),('大小球结果',22)],toprows,4)
fields=[('北京时间',16),('赛事',16),('比赛',34),('90分钟',13),('首选',12),('备选',19),('命中顺序',16),('胜平负',14),('总球线',13),('大小球结算',15),('主客xG',16),('赛前冻结号',32)]
add_table('首版30场','11月22日17:31首版　｜　逐场结算','北京时间基于赛后两源核验；奥斯陆KFUM实际比原定晚两小时开球。',fields,[row_view(r) for r in first.values()],3)
add_table('修订版16场','23:34赛前修订　｜　逐场结算','巴甲3场修订版大小球观望，比分及胜平负仍结算。',fields,[row_view(r) for r in E['update'].values()],3)
add_table('模型与研究','当前模型、测试模型及研究轨道','活动模型按各自首版结算，近期xG与重排为独立研究轨道。',[('轨道',31),('第一比分',22),('三选比分',22),('胜平负',21),('大小球五类结算和有效场次',47)],model_rows,1)
book.close()
b=openpyxl.load_workbook(file,read_only=True)
for name,expected in [('首版30场',list(first.values())),('修订版16场',list(E['update'].values()))]:
    rows=list(b[name].values)[4:]; assert len(rows)==len(expected)
    assert all(list(row)==row_view(r) for row,r in zip(rows,expected))
assert [list(x) for x in list(b['两版首选三场'].values)[4:]]==toprows
b.close()
shutil.copy2(file,D/'11月22日非美职联30场复盘.xlsx')

EVID=DEST/'evidence.tar.gz'
secret_values={v.encode() for k,v in os.environ.items() if len(v)>9 and (k in {'BSD','FOOTBALLDATA','INFER','OPENFOOT','THEODDSAPI','GH_TOKEN','GITHUB_TOKEN','THERUNDOWN'} or k.endswith(('_API_KEY','_TOKEN')))}
wanted={}
def arc_add(tar,p,name):
    data=p.read_bytes()
    assert not any(k in data for k in secret_values),p
    wanted[name]=hashlib.sha256(data).hexdigest()
    tar.add(p,arcname=name,recursive=False)
with tarfile.open(EVID,'w:gz',compresslevel=5) as tar:
    for rel in ('population-lock.json','verified-results.json','verified-process.json','metrics.json','model-evaluations.json','selection-review.json','match-evaluations.json','review-batch.json','review-receipts.json','europe/scores.json','brazil/scores.json'):
        p=D/rel
        if p.exists():arc_add(tar,p,rel)
    for data in A.values():
        for x in data['sources']:
            rel=x['file']; p=D/rel; assert file_hash(p)==x['sha256']
            if rel not in wanted:arc_add(tar,p,rel)
    for r in [success['batch'],*success['matches'].values()]:
        record=load(r)
        arc_add(tar,Path(r['path']),'issued-review/'+record['freeze_id']+'.json')
    for local in ('common.py','results.py','score.py','report.py'):
        arc_add(tar,Path(__file__).parent/local,'reproduce/'+local)
with tarfile.open(EVID,'r|gz') as tar:
    seen={}
    for member in tar:
        seen[member.name]=hashlib.sha256(tar.extractfile(member).read()).hexdigest()
    assert seen==wanted

verification={'scope_matches':30,'excluded_mls':l['excluded_explicit_mls'],'completed_regulation_verified_both_providers':30,
              'eligible_updates':16,'metrics_written_from_record':True,'xlsx_first_update_and_ranked_rows_verified':True,
              'archive_entries_checked':len(wanted),'raw_provider_response_hashes_verified':60,
              'first_freeze_id':groups['first_top3']['ref']['freeze_id'],'revised_freeze_id':groups['update_top3']['ref']['freeze_id'],
              'review_batch_receipt':success['batch'],'fixture_identity_later_kickoff':['401843488'],'provider_red_card_is_coach':['401884733'],'archive_checksums':seen,
              'sha256':{n:file_hash(DEST/n) for n in ['README.md','review.xlsx','metrics.json','match-evaluations.json','review-receipts.json','evidence.tar.gz']}}
write(DEST/'verification.json',verification)
write(D/'verification.json',verification)
print('review-batch',success['batch'],'file checks',len(wanted))
