from common import *
from collections import Counter
import numpy as np
from research_program.selection_review import compare
from research_program.future_validation import quote_audit
from v5.paired_review import review as paired, legacy, SETTLEMENTS

def direction(h,a):
    return '主胜' if h>a else '客胜' if h<a else '平局'

def total_settlement(h,a,line,side):
    point=np.zeros((51,51))
    point[h,a]=1.
    tag,=[k for k,value in legacy.total_settlement(point,line,{'大':'over','小':'under'}[side]).items() if value==1]
    return tag

def row(s,ref,actual,process):
    rec=load(ref);f=rec['fixture'];p=rec['payload']
    t=p.get('total_direction')
    first=p['primary'];scores=[first,*p['alternates']]
    assert len(scores)==len(set(scores))==3
    if t is not None:
        assert quote_audit(f)['eligible'] and f['total_quote']['line']==p['total_line']
    outcome=hit_rank=total=wdl=None
    if actual['status']=='completed':
        h,a=actual['home_goals'],actual['away_goals'];outcome=f'{h}-{a}'
        hit_rank=scores.index(outcome)+1 if outcome in scores else None
        wdl=direction(h,a)
        total=total_settlement(h,a,p['total_line'],t) if t is not None else 'abstention'
    return {'id':s['id'],'cohort':s['cohort'],'teams':'—'.join(s['row']['teams']),'league':s['row']['league'],
            'kickoff_at':f['kickoff_at'],'provider_kickoff_at':actual['observed_provider_kickoff_at'],
            'ref':ref,'primary':first,'alternates':scores[1:],'wdl':p['wdl'],'total_direction':t,
            'total_line':p['total_line'],'status':actual['status'],'result':outcome,'actual_wdl':wdl,
            'hit_rank':hit_rank,'settlement':total,'postmatch_xg':process.get(s['id'],{}).get('xg')}

def aggregate(rows):
    complete=[r for r in rows if r['result'] is not None]
    kinds=Counter(r['settlement'] for r in complete)
    return {'population':len(rows),'finished':len(complete),'pending':len(rows)-len(complete),
            'exact_first':sum(r['hit_rank']==1 for r in complete),'exact_three':sum(r['hit_rank'] is not None for r in complete),
            'rank_counts':[sum(r['hit_rank']==k for r in complete) for k in [1,2,3]],
            'wdl':sum(r['actual_wdl']==r['wdl'] for r in complete),
            'totals':{k:kinds[k] for k in [*SETTLEMENTS,'abstention']},
            'total_eligible':sum(kinds[k] for k in SETTLEMENTS),
            'total_full_win_nonpush_denominator':sum(kinds[k] for k in SETTLEMENTS if k!='push')}

def paired_rows(refs, results):
    models=[]
    for ref in refs:
        m=load(ref)
        models.append(dict(m['payload'],fixture=m['fixture'],match_id=m['match_id']))
    evaluated=paired(models,results)
    # Add Top3 from each preserved numerical output. paired_review owns the other metrics.
    for role,key in [('当前模型','current_model'),('test模型','test_model')]:
        per_version=Counter()
        count=Counter()
        by_id={d['match_id']:d for d in models}
        for r in evaluated['paired_rows']:
            p=by_id[r['match_id']][key]; scores=[x['score'] for x in p['top3']]
            assert len(set(scores))==3 and scores[0]==p['primary']
            version=p['version'];count[version]+=1;per_version[version]+=r['result'] in scores
        evaluated['models'][role]['three_scores_by_version']={k:{'hits':n,'finished':count[k]} for k,n in per_version.items()}
    return evaluated

def compare_updates(previous,updates):
    out={}
    for label,verdict in {
        'primary':lambda r:r['hit_rank']==1,
        'three':lambda r:r['hit_rank'] is not None,
        'wdl':lambda r:r['wdl']==r['actual_wdl'],
        'totals_full_win':lambda r:r['settlement']=='win',
    }.items():
        valid=[(previous[i],r) for i,r in updates.items() if r['result'] is not None and
               (label!='totals_full_win' or r['settlement'] not in [None,'abstention'])]
        gains=[n['id'] for f,n in valid if verdict(n) and not verdict(f)]
        losses=[n['id'] for f,n in valid if verdict(f) and not verdict(n)]
        out[label]={'n':len(valid),'gains':gains,'losses':losses,'net':len(gains)-len(losses)}
    return out

def goal_diagnostics(rows):
    done=[r for r in rows if r['result']]
    def n(s):return sum(map(int,s.split('-')))
    above=[];below=[];same_envelope_misses=[];positive=[];negative=[]; tails=[]
    for r in done:
        candidates=[n(r['primary']),*(n(x) for x in r['alternates'])]
        actual=n(r['result'])
        if actual>max(candidates):above.append(r['id'])
        elif actual<min(candidates):below.append(r['id'])
        elif r['hit_rank'] is None:same_envelope_misses.append(r['id'])
        if actual>=4:tails.append(r['id'])
        if r['wdl']=='主胜' and r['actual_wdl']=='主胜':positive.append(r['id'])
        if actual>n(r['primary']):negative.append(r['id'])
    return {'actual_goals':sum(n(r['result']) for r in done),'primary_goals':sum(n(r['primary']) for r in done),
            'four_plus':tails,'primary_four_plus':[r['id'] for r in done if n(r['primary'])>=4],
            'above_all_three':above,'below_all_three':below,'inside_envelope_score_misses':same_envelope_misses,
            'one_one_predicted':sum(r['primary']=='1-1' for r in done),'one_one_actual':sum(r['result']=='1-1' for r in done),
            'one_one_hits':sum(r['primary']==r['result']=='1-1' for r in done),
            'wdl_actual':dict(Counter(r['actual_wdl'] for r in done)),'wdl_predicted':dict(Counter(r['wdl'] for r in done)),
            'wdl_by_choice':{k:{'picked':sum(r['wdl']==k for r in done),'hit':sum(r['wdl']==r['actual_wdl']==k for r in done)} for k in ('主胜','平局','客胜')},
            'actual_more_than_primary':negative}

def run():
    l=lock();pop=l['population'];act=read(D/'verified-results.json');process=read(D/'verified-process.json')
    first={i:row(s,s['first'],act[i],process) for i,s in pop.items()}
    updates={i:row(s,s['update'],act[i],process) for i,s in pop.items() if s['update']}
    rank_sets={}
    for name,entry in l['ranked'].items():
        rr=first if name=='first_top3' else updates
        rank_sets[name]=[dict(rr[item['match_id'].split(':')[-1]],rank=item['rank']) for item in entry['rows']]
    valid_results=[r for r in act.values() if r['status']=='completed']
    selection=compare([{'comprehensive':load(s['first']),'pair':load(s['referenced_pair'])} for s in pop.values()],valid_results)
    assert selection['comprehensive_hits']==sum(r['hit_rank']==1 for r in first.values())
    write(D/'selection-review.json',selection)
    model_eval={}
    for label,refs in [('native_first',[s['first_pair'] for s in pop.values()]),('same_time_as_comprehensive',[s['referenced_pair'] for s in pop.values()]),('updated',[s['update_pair'] for s in pop.values() if s['update_pair']])]:
        model_eval[label]=paired_rows(refs,valid_results)
    write(D/'model-evaluations.json',model_eval)
    chosen={}
    def add_candidate(name,i,scores):
        if i not in act or act[i]['status']!='completed':return
        assert len(scores)==3 and len(set(scores))==3
        res=first[i]['result']
        chosen.setdefault(name,{})[i]={'scores':scores,'first_hit':res==scores[0],'three_hit':res in scores}
    for i,s in pop.items():
        f=load(s['first'])
        m=load(s['referenced_pair'])['payload']['score_form_candidate']
        add_candidate('近期xG融合',i,m['pooled']['top3'])
        pick=m['selection']
        add_candidate('近期xG候选',i,[pick['primary'],*pick['alternates']])
        k=f['selection_audit']['score_form_comparison']['within_issued_three']
        add_candidate('综合三选内重排',i,k)
        if 'prior_research' in s:
            pre=load(s['prior_research'])['payload']['all_score_candidate']
            add_candidate('英超15:33独立研究',i,[pre['primary'],*pre['alternates']])
    pmf_totals={}
    for name in ('current_model','test_model'):
        p4=[]; mean=[]
        for i,s in pop.items():
            if act[i]['status']!='completed':continue
            m=np.asarray(load(s['referenced_pair'])['payload'][name]['matrix'])
            total=np.sum(np.indices(m.shape),axis=0)
            p4.append(float(m[total>=4].sum()))
            mean.append(float((m*total).sum()))
        pmf_totals[name]={'mass_4_or_more_sum':sum(p4),'mean_total_goals_sum':sum(mean)}
    metrics={
        'groups':{'first':aggregate(list(first.values())),'update':aggregate(list(updates.values())),
                  'first_on_update_games':aggregate([first[i] for i in updates]),
                  **{k:aggregate(r) for k,r in rank_sets.items()}},
        'leagues':{c:aggregate([r for r in first.values() if r['cohort']==c]) for c in sorted({s['cohort'] for s in pop.values()})},
        'revision_comparison':compare_updates(first,updates),'first_goal_diagnostics':goal_diagnostics(list(first.values())),
        'method_candidates':{k:{'finished':len(v),'first_hits':sum(r['first_hit'] for r in v.values()),'three_hits':sum(r['three_hit'] for r in v.values())} for k,v in chosen.items()},
        'postmatch_xg':sum(v['xg'] is not None for v in process.values()),'postmatch_xg_sum':sum(sum(v['xg']) for v in process.values() if v['xg'] is not None),'frozen_model_totals':pmf_totals,'candidate_detail':chosen}
    write(D/'metrics.json',metrics)
    write(D/'match-evaluations.json',{'first':first,'update':updates,'ranked':rank_sets})
    for name,md in metrics['groups'].items():print(name,md)
    print('selection',selection['score_form_review'])
    print('candidate',metrics['method_candidates'])

if __name__=='__main__':
    run()
