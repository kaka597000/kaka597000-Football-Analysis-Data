from common import *
from datetime import timedelta
import math
from research.review_events import normalize_fotmob_goal

def references(domain, i, row):
    if domain=='europe':
        return [{'file':s['raw_file'],'source':s['publisher'].lower(),'url':s['url'],'observed_at':s['accessed_at_utc'],'sha256':s['sha256']} for s in row['sources']]
    latest={}
    for r in read(D/'brazil/capture-manifest.json'):
        if r['id']==i and r['http_status']==200:
            item={'file':r['file'],'source':r['source'],'url':r['source_url'],'observed_at':r['query_time'],'sha256':r['response_sha256']}
            if r['source'] not in latest or aware(item['observed_at'])>aware(latest[r['source']]['observed_at']):
                latest[r['source']]=item
    return list(latest.values())

def read_raw(domain, i, row):
    raw={}; meta={}
    for ref in references(domain,i,row):
        p=D/domain/ref['file']; assert file_hash(p)==ref['sha256'],p
        src=ref['source']; raw[src]=read(p);meta[src]=dict(ref,file=str(p.relative_to(D)))
    return raw,meta

def goal_time(e):
    period=e.get('period') or {}
    return e.get('timeStr') or str(e.get('time') or period.get('number') or '')

def observations(foot, s, final):
    items=foot['content']; stats=((items.get('stats') or {}).get('Periods') or {}).get('All') or {}
    variants=set()
    for sect in stats.get('stats') or []:
        for col in sect.get('stats') or []:
            if col['key']!='expected_goals':continue
            vals=col.get('stats')
            if vals and len(vals)==2 and all(x is not None for x in vals):
                numbers=tuple(map(float,vals)); assert all(0<=x<=30 and math.isfinite(x) for x in numbers)
                variants.add(numbers)
    assert len(variants)<=1
    xx=next(iter(variants)) if variants else None
    goals=[]; reds=[]; goal_issues=[]
    events=(items['matchFacts'].get('events') or {}).get('events') or []
    for e in events:
        if e.get('type')=='Goal' and not e.get('isPenaltyShootoutEvent'):
            ee=dict(e)
            if '+' in str(ee.get('timeStr','')) and ee.get('overloadTime'):
                ee['timeStr']=ee['time']
            if ee.get('ownGoal') is None and (ee.get('shotmapEvent') or {}).get('isOwnGoal') is None:
                # The provider uses absence of a flag on ordinary goals.
                if ee.get('goalDescription') not in ('OwnGoal','Own goal'):
                    ee['ownGoal']=False
            try:
                g=normalize_fotmob_goal(ee,home_team_id=s['fot_home'],away_team_id=s['fot_away'])
                goals.append(g)
            except ValueError as exc:
                goal_issues.append({'time':goal_time(e),'name':e.get('fullName'),'issue':str(exc)})
        if e.get('type')=='Card' and e.get('card') in ('Red','YellowRed'):
            reds.append({'time':goal_time(e),'minute':e.get('time'),'side':'home' if e['isHome'] else 'away','name':e.get('fullName'),'card':e['card'],'recipient_role':'coach' if (e.get('cardDescription') or {}).get('localizedKey')=='coach' else 'player'})
    ht=None
    for e in events:
        if e.get('type')=='Half' and e.get('halfStrShort')=='HT':
            score=e.get('score') or [e.get('homeScore'),e.get('awayScore')]
            if len(score)==2 and all(type(z)==int for z in score):ht=score
    if not ht and not goal_issues and len(goals)==sum(final):
        a=[e['detail']['score_after'] for e,v in zip(goals,[q for q in events if q.get('type')=='Goal']) if v.get('time',99)<=45]
        ht=a[-1] if a else [0,0]
    status=foot['header']['status']
    return {'xg':list(xx) if xx else None,'goals':goals,'goal_verification_issues':goal_issues,'halftime':ht,
            'red_events':reds,'red_count':[status.get('numberOfHomeRedCards'),status.get('numberOfAwayRedCards')]}

def run():
    pop=lock()['population']
    records={};process={};sources=read(D/'europe/scores.json')
    eur={r['espn_id']:r for r in sources['events']}
    for i,s in pop.items():
        domain='brazil' if s['cohort']=='bra.1' else 'europe'
        bundles,ref=read_raw(domain,i,eur.get(i))
        status='pending'; actual=None
        fm,es=[bundles[k] for k in ('fotmob','espn')]
        esp_header=es['header'];summary,=esp_header['competitions']; events={r['homeAway']:r for r in summary['competitors']}
        assert esp_header['id']==i and esp_header['league']['slug']==s['cohort']
        assert [str(events[k]['id']) for k in ('home','away')]==[s[k].split(':')[1] for k in ('home','away')]
        ft=fm['header'];ff=ft['status']
        assert str(fm['general']['matchId'])==s['fotmob'] and [str(t['id']) for t in ft['teams']]==[s['fot_home'],s['fot_away']]
        assert aware(ff['utcTime'])==aware(summary['date'])
        kickoff_moved=aware(ff['utcTime'])!=aware(s['kickoff_at'])
        if kickoff_moved:assert aware(ff['utcTime'])>aware(s['kickoff_at']) and i=='401843488'
        status_esp=summary['status']['type']['name']
        status_fot=(ff.get('reason') or {}).get('short')
        completed_esp=status_esp=='STATUS_FULL_TIME' and summary['status']['type']['completed'] is True
        completed_fot=status_fot=='FT' and ff['finished'] and not ff.get('awarded') and not ff.get('whoLostOnPenalties')
        es_score=[int(events[k]['score']) for k in ('home','away')]
        ft_score=[int(t['score']) for t in ft['teams']]
        if completed_fot and completed_esp and es_score==ft_score:
            status='completed'; actual=es_score
        observed=max((v['observed_at'] for v in ref.values()),key=aware)
        rr={k:s[k] for k in ('match_id','cohort','stage','home','away','kickoff_at')}
        rr.update(observed_provider_kickoff_at=ff['utcTime'],kickoff_moved_later=kickoff_moved,status=status,competition=s['cohort'],source_url=ref['espn']['url'],score_basis='regulation_90',observed_at=observed, sources=list(ref.values()))
        if actual is not None:
            assert aware(observed)>=aware(ff['utcTime'])+timedelta(minutes=90)
            rr.update(event_status='FT',home_goals=actual[0],away_goals=actual[1])
            d=observations(fm,s,actual)
            ht=eur.get(i,{}).get('halftime')
            d['espn_halftime']=[ht['home'],ht['away']] if ht else None
            process[i]=d
        else:rr.update(provider_status=[status_esp,status_fot])
        records[i]=rr
    write(D/'verified-results.json',records)
    write(D/'verified-process.json',process)
    print('result checks',len(process),'of',len(pop),'xG',sum(d['xg'] is not None for d in process.values()),'goal flags',sum(len(d['goal_verification_issues']) for d in process.values()),'pending',[i for i,v in records.items() if v['status']=='pending'])

if __name__=='__main__':
    run()
