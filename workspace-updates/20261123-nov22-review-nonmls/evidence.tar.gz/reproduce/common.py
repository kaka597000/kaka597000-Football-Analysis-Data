from pathlib import Path
import json
import hashlib
import sys
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

SRC=Path('/workspace/Football-Analysis-score-form-20261122')
D=Path('/workspace/WCPP/reports/review-20261123-nov22-nonmls')
FIRST=Path('/workspace/WCPP/reports/scope-prematch-20261122-1713')
UP=Path('/workspace/WCPP/reports/scope-remaining-20261122-2328')
sys.path[:0]=[str(SRC/'runtime'),str(SRC/'runtime/v5'),str(SRC)]
from research.analysis_freeze import aware, verify, save, digest
BJ=ZoneInfo('Asia/Shanghai')

def now():
    return datetime.now(timezone.utc).isoformat()

def bjt(value):
    return aware(value).astimezone(BJ).strftime('%m-%d %H:%M')

def read(path):
    return json.loads(Path(path).read_bytes())

def write(path,value):
    path=Path(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    tmp.replace(path)

def file_hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def load(ref):
    r=verify(read(ref['path']))
    assert r['record_sha256']==ref['sha256'] and r['freeze_id']==ref['freeze_id']
    return r

def locate_first(ref):
    path=Path(ref['path'])
    parent=path.parent
    rec=verify(read(parent/'000001.json'))
    assert rec['revision']==1 and rec['evaluation_slot']=='FIRST_PREMATCH'
    previous=None
    for p in sorted(parent.glob('[0-9]*.json')):
        if p.name>path.name:break
        event=verify(read(p))
        assert event['previous_sha256']==previous
        previous=event['record_sha256']
    assert previous==ref['sha256']
    return {'path':str(parent/'000001.json'),'sha256':rec['record_sha256'],'freeze_id':rec['freeze_id'],'recorded_at':rec['recorded_at'],'evaluation_slot':rec['evaluation_slot']}

def lock():
    target=D/'population-lock.json'
    if target.exists():return read(target)
    a,b=read(FIRST/'receipts.json'),read(UP/'receipts.json')
    table={}
    excluded=[]
    for s in read(FIRST/'schedule/slate.json')['list']:
        i=s['id']
        if s['cohort']=='usa.1':
            excluded.append(s['mid'])
            continue
        r=a['matches'][i]['comprehensive'];p=a['matches'][i]['pair']
        c,paired=load(r),load(p)
        assert c['match_id']==paired['match_id']==s['mid']
        assert c['stage']==paired['stage']=='prematch' and c['track']=='comprehensive' and paired['track']=='current-test-pair'
        assert c['revision']==1 and c['payload']['current_test_reference']==p
        for record in (c,paired):
            fixture=record['fixture']
            assert [fixture[k] for k in ('cohort','home','away')]==[s[k] for k in ('cohort','home','away')]
            assert aware(record['recorded_at'])<aware(s['kickoff_at'])==aware(fixture['kickoff_at'])
        fp=locate_first(p)
        info={'match_id':s['mid'],'id':i,'cohort':s['cohort'],'stage':c['fixture']['stage'],'home':s['home'],'away':s['away'],
              'home_name':s['home_name'],'away_name':s['away_name'],'fotmob':s['fot_id'],'fot_home':s['fot_home'],'fot_away':s['fot_away'],
              'kickoff_at':s['kickoff_at'],'row':c['payload']['user_facing_row'],'first':r,'first_pair':fp,'referenced_pair':p,
              'update':None,'update_pair':None}
        if i in b['matches']:
            u=b['matches'][i]['comprehensive'];up=load(u);q=b['matches'][i]['pair'];px=load(q)
            assert up['revision']==2 and up['previous_sha256']==r['sha256'] and up['payload']['current_test_reference']==q
            assert load(q)['previous_sha256']==p['sha256'] and aware(up['recorded_at'])<aware(s['kickoff_at'])
            assert up['match_id']==px['match_id']==s['mid']
            info.update(update=u,update_pair=q)
        if a['matches'][i].get('earlier_candidate'):
            prior=a['matches'][i]['earlier_candidate']; x=load(prior)
            assert x['match_id']==s['mid'] and aware(x['recorded_at'])<aware(s['kickoff_at'])
            info['prior_research']=prior
        table[i]=info
    ranked={}
    for label,group in [('first_top3',a),('update_top3',b)]:
        ref=group['top3']; rec=load(ref); rows=rec['payload']['top3']
        assert rec['track']=='top3-selection' and len(rows)==3
        for pos,item in enumerate(rows,1):
            i=item['match_id'].split(':')[-1]
            assert item['rank']==pos and item['comprehensive_reference']==table[i]['first' if label=='first_top3' else 'update']
        ranked[label]={'ref':ref,'rows':rows}
    assert len(table)==30 and len(excluded)==3 and sum(v['update'] is not None for v in table.values())==16
    out={'locked_at':now(),'population':table,'ranked':ranked,'excluded_explicit_mls':excluded,
         'prediction_archives':[{'path':str(a),'source':b} for a,b in [(FIRST/'receipts.json','87e3ad5ba551714dbf840bae84335d3bf619a50a'),(UP/'receipts.json','f0b2f25c309f067ed56479854bd4d81d4a01e92d')]]}
    write(target,out)
    return out

if __name__=='__main__':
    data=lock()
    print('population',len(data['population']), 'locked_at', data['locked_at'])
