import json,pathlib,hashlib,datetime
base=pathlib.Path(__file__).parent;s=base/'staging';out=base/'inputs';out.mkdir(exist_ok=True)
fixtures=json.loads((s/'fixtures-ucl-20261103.json').read_text());odds=json.loads((s/'odds-ucl-20261103-refresh.json').read_text())
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
for f in fixtures['fixtures']:
 mid='espn:'+f['id'];home=next(x for x in f['competitors'] if x['home_away']=='home');away=next(x for x in f['competitors'] if x['home_away']=='away')
 event=next(x for x in odds['events'] if x['home_team']==('Barcelona' if home['team_id']=='83' else 'Atlético Madrid'))
 assert datetime.datetime.fromisoformat(f['date_utc'].replace('Z','+00:00'))==datetime.datetime.fromisoformat(event['commence_time'].replace('Z','+00:00'))
 b=next(x for x in event['bookmakers'] if x['key']=='pinnacle');m=next(x for x in b['markets'] if x['key']=='totals');quotes={x['name']:x for x in m['outcomes']};assert quotes['Over']['point']==quotes['Under']['point']
 item=dict(sources=[dict(source_url='https://site.api.espn.com/apis/site/v2/sports/soccer/uefa.champions/scoreboard?dates=20261103',query_time=fixtures['retrieved_at_utc'])],match_id=mid,cohort='uefa.champions:NEW_FORMAT:league_phase',competition='uefa.champions',stage='NEW_FORMAT:league_phase',phase='PreMatch',gender='men',age='senior',identity_verified=True,home='espn:'+home['team_id'],away='espn:'+away['team_id'],display_home=home['name'],display_away=away['name'],neutral=False,kickoff_at=f['date_utc'],cutoff_at=now,
  total_quote=dict(match_id=mid,verified=True,bookmaker='Pinnacle via The Odds API',line=quotes['Over']['point'],over_odds=quotes['Over']['price'],under_odds=quotes['Under']['price'],market='asian_total',asian_main_line_verified=False,quoted_at=m['last_update'],query_time=odds['retrieved_at_utc'],source_url='https://api.the-odds-api.com/v4/sports/soccer_uefa_champs_league/odds/'),
  evidence_packet=dict(confirmed_lineup=False,xg_xga_usage='RECENT_FOTMOB_QUALITATIVE_ONLY_NOT_NUMERICALLY_LEARNED',injury_usage='FOTMOB_PROVIDER_UNAVAILABLE_NOT_OFFICIAL_CONFIRMATION',staging=str(s),source_files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in s.glob('*.json')}))
 target=out/(f['id']+'.json');target.write_text(json.dumps(item,ensure_ascii=False,indent=2));print(target)
