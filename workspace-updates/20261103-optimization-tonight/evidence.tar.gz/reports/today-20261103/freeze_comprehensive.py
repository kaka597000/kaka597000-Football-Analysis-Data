import json,pathlib,datetime,sys,hashlib
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from research.analysis_freeze import save,verify
base=pathlib.Path(__file__).parent
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
records=[]
for event in ['401915386','401915387']:
 pair=json.loads((base/(event+'-pair-v1.json')).read_text());receipt=pair['freeze_receipt'];verify(json.loads(pathlib.Path(receipt['path']).read_text()))
 f=json.loads((base/'inputs'/(event+'.json')).read_text());f['cutoff_at']=now
 common=dict(method_version='WCPP-MANUAL-COMPARATIVE-20261103-1',current_test_reference=receipt,
  numeric_model_training_cutoff='2026-09-10',latest_verified_round_included=False,
  latest_verified_recent_match_date='2026-10-31',source_staging=str(base/'staging'),
  numeric_adjustment_applied=False,probability_claim='No calibrated comprehensive probability assigned',
  xg_status='FotMob recent three official matches verified and used qualitatively; Understat HTTP503',
  availability_status='FotMob predicted-lineup unavailable retained; Transfermarkt HTTP405; individual official confirmation incomplete',
  market_status='Pinnacle same-line quotes 21:45:20 and 21:49:53 Beijing unchanged; two short snapshots do not establish long movement or funds flow',
  limitations=['Current/Test are lagging statistical baselines; 2026-10-31 results and current xG not numerically incorporated',
    'Three-match mixed domestic/UCL/cup sample is not opponent-adjusted training or a full-form estimate',
    'Expected lineups and platform unavailable do not certify official starters or individual injuries'])
 if event=='401915387':
  common.update(primary='2-1',wdl='主胜',total_line=4.25,total_direction='小',status='COMPREHENSIVE_RESEARCH_SELECTION',
   primary_reason='巴萨近三场同源xG均2.23，维拉xGA均2.12，支持主队连续制造机会但不能按6-1阿拉维斯外推。维拉近三场xG均1.57，巴萨xGA2.13且防线平台伤缺，支持客队1球路径。比较2-1、3-1、2-2、2-0后，保留2-1：主场机会优势比维拉高效反击更有延续依据，仍不给未经校准概率。',
   selection_evidence=dict(compared_scores=['2-1','3-1','2-2','2-0'],
    candidate_comparison={'2-1':'主队2球与客队1球的组合得到双方当前机会生成/防守窗口支持；与统计众数相同但另作证据推断。','3-1':'巴萨压制及维拉客场失球路径支持，但近期6-1对手较弱，不能直接外推连续三球。','2-2':'巴萨对巴黎xGA3.70及后防平台缺员支持，反证是维拉对曼城xG仅0.61、客队进球效率未稳定。','2-0':'维拉有近期足够机会创造且巴萨防线风险，零封依据不足。'},
    zero_vs_one={'away':{'reason':'不选0球：维拉近三场FotMob xG1.57且巴萨xGA2.13，支持客队1球；此为定性判断，不是新均值模型。','counterevidence':'维拉对曼城仅0.61xG、联赛实际1-1且进攻波动；统计客队0球约22%–24%，零封不能排除。'}},
    three_plus_path='比较3-1与2-2四球路径及3-2以上：巴萨领先后仍可能持续进攻，维拉落后追分会增加转移空间；巴萨近期对巴黎/皇马失守是开放反证。未据此机械加球，2-1仍是唯一Primary。',
    total_reason='真实Pinnacle线为4.25，3球以下小全赢、4球小半赢、5球以上全输。两队近期机会分布与维拉进攻波动支持总球落在3–4球的路径；双方模型总球均值4.05–4.13，5+约38%–40%，并非极端低风险。小4.25的依据是高线下4球仍半赢的结算缓冲及客队未稳定高产，不由2-1之和倒推。反证为巴萨后防人员不确定及先失球后开放追分。'),
   ranking_reason='本批唯一三项方向均有独立比较依据的比赛。相对马竞场，主队机会优势和真实高总球线下的小球路径更清晰；主要风险为巴萨防线名单未获俱乐部逐人确认与维拉反击造成5+。')
 else:
  common.update(primary=None,wdl='客胜',total_line=3.25,total_direction='观望',status='ABSTAIN_PRIMARY_AND_TOTAL_UNRESOLVED_HIGH_IMPACT_AVAILABILITY',
   primary_reason='客胜仅作方向倾向：拜仁近三场xG3.79/xGA0.87，马竞1.00/1.55；但拜仁窗口含杯赛6-1马格德堡、球队强度与样本场景差异大，多名前场unavailable未获官方确认，尚不足确定客队2球或3球。唯一综合比分待定，1-2只是候选不是推荐。',
   selection_evidence=dict(compared_scores=['1-2','1-1','0-2','2-2'],
    candidate_comparison={'1-2':'拜仁机会优势和马竞主场进球路径支持，但前场可用性未确认可能改写客队产量。','1-1':'马竞节奏与拜仁前场减员情景支持；拜仁最近对多特4.48xG是反证。','0-2':'拜仁近三场xGA0.87提供零封路径；马竞主场与拜仁对多特丢2球是反证。','2-2':'若马竞被领先迫使追分可双向开放，但近期马竞过程不足支持高优先。'},
    zero_vs_one={'home':{'reason':'不正式选择零球：马竞近三场均有进球，但过程均1.00xG，0球与1球均需保留。','counterevidence':'拜仁同源xGA均0.87及模型主队0球约17%–18%支持零封，当前人员不确定未解决。'}},
    three_plus_path='显式比较1-2与2-2：拜仁若先领先且马竞追分可到3–4球，反证为拜仁前场平台缺员、马竞机会均值较低。当前模型1-1虽众数，总球3+约69%；test约72%，不能只凭1-1推小。',
    total_reason='实际Pinnacle3.25：双方滞后模型均参考大，但马竞近期较低机会生成与拜仁前场未确认同时可能压低节奏；盘口两次同线同价不能解决信息缺口。因此大小球观望，不从候选1-2硬推小，也不因模型大而强制推荐。'),
   ranking_reason='未入TOP3：高影响前场可用性与机会样本对手差异尚未解决。方向倾向客胜仍单独留档并未来结算，不把候选比分补成命中。')
 rec=save(common,f,stage='prematch',track='comprehensive');records.append(dict(event=event,fixture=f,payload=common,receipt=rec))
 print(event,json.dumps(rec,ensure_ascii=False))
(base/'comprehensive-receipts.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
selected=next(r for r in records if r['event']=='401915387')
batch=dict(match_id='batch:20261103-night-two-ucl',kickoff_at=selected['fixture']['kickoff_at'],cutoff_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
payload=dict(method_version='WCPP-MANUAL-COMPARATIVE-20261103-1',top3=[dict(rank=1,match_id=selected['fixture']['match_id'],primary='2-1',wdl='主胜',total_line=4.25,total_direction='小',comprehensive_reference=selected['receipt'],reason=selected['payload']['ranking_reason'])],population=['espn:401915386','espn:401915387'],notice='Only one qualified selection; full two-match population retained. No forced TOP3 fill.')
receipt=save(payload,batch,stage='prematch',track='top3-selection');(base/'top3-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2));print('TOP',receipt)
