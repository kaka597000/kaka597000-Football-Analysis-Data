import json,pathlib,sys,collections,hashlib
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from research_program.complementarity import compare
from research.analysis_freeze import verify
base=pathlib.Path('/workspace/WCPP');source=base/'reports/review-all-20261101-0100/v2/normalized-results.json';raw=json.loads(source.read_text());results=[]
for r in raw:
 if r.get('status')=='SETTLED' and r.get('provider_status')=='STATUS_FULL_TIME':
  results.append(dict(match_id=r['match_id'],status='completed',score_basis=r['score_basis'],home_goals=r['score'][0],away_goals=r['score'][1],source_url=r['source_url'],observed_at=r['observed_at'],kickoff_at=r['kickoff_at']))
ids={r['match_id'] for r in results};pairs=[];excluded=collections.Counter()
for p in (base/'forecasts/issued-analyses').rglob('*.json'):
 try:r=json.loads(p.read_text())
 except:continue
 if r.get('track')!='current-test-pair' or r.get('evaluation_slot')!='FIRST_PREMATCH' or r.get('fixture',{}).get('match_id') not in ids:continue
 verify(r);pairs.append(r)
report=compare(pairs,results);report['source_results']=str(source);report['source_results_sha256']=hashlib.sha256(source.read_bytes()).hexdigest();report['scope']='All matching FIRST_PREMATCH pairs for fixed prior 2026-11-01 completed review batch; not unseen validation or prospective promotion evidence.'
out=base/'reports/optimization-execution-20261103/complementarity.json';out.write_text(json.dumps(report,ensure_ascii=False,indent=2));print(out)
for g in report['groups']:print(g['cohort'],g['current_version'],g['test_version'],{k:g[k] for k in ['population','different_primary','only_current_right','only_test_right','both_right','both_wrong','paired_net_test_hits','coverage']})
