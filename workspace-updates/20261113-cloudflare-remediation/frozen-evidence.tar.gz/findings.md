# Cloudflare 官方修复机制资料核验

**资料读取时间：** 2026-11-13 10:32–10:35 北京时间  
**请求数：** 共 4 次网络调用：developers.cloudflare.com 文档 GET 403、错误 raw 文件路径 GET 404、Cloudflare 官方文档仓库 tree GET 200、一次 GitHub GraphQL 读取成功。详见 `search-log.json`。没有请求任何 API-Football 或 TheRundown 主机，没有携带业务密钥，也没有修改或发布规则。

## 已核验的管理员机制

Cloudflare 官方文档说明，Skip 是 zone 的 Security rules 中配置的自定义规则动作，用来让**匹配的特定请求**跳过选定安全规则或产品。管理员在 dashboard 的 Security rules 中创建或编辑 custom rule、设置表达式、选择 Skip 和所需选项后保存；也可使用 Rulesets API。文档没有说明满足条件的具体角色名，因此只能确认需要有权编辑该 zone/account 的 Security rules 或相应 API 权限。

Skip 可按 phase 跳过限速规则、WAF managed rules 或 Super Bot Fight Mode，也能针对文档列出的产品设置 Skip。它不能通用跳过所有 Cloudflare 检查：Bot Fight Mode 不支持 WAF custom rules/Page Rules 的 Skip、Bypass 或 Allow；Browser Integrity Check、Zone Lockdown 等不在 Ruleset Engine 内的产品也不能靠 phase skip 跳过，需要各自的 Skip product 选项。关闭 Skip rule 的日志记录后，命中该规则的请求不会出现在 Security Events；该动作默认开启日志记录。

如果问题来自 Bot Fight Mode，Cloudflare 明确说明自定义 WAF 规则无法为某个客户端建立例外。文档建议需要特定流量例外时使用 Super Bot Fight Mode，因为它支持 Ruleset Engine Skip。是否由 Bot Fight Mode 导致这次请求失败仍未知；这项设置只能由 API 服务商的 zone 管理员评估和修改。

## Security Events 与 Ray ID

Security Events 可供 zone 管理员查看 Cloudflare 产品标记或缓解的请求，路径为 dashboard **Analytics → Events**。文档举例支持按 IP 筛选，也说明可按事件字段和时间范围筛选、检查事件详情。Free 账户只有 Sampled logs，日志可能漏掉单个事件；账户级 dashboard 权限因计划而异。

本次实际读取的 Security Events 官方页面没有 Ray ID 字段过滤或按 Ray ID 查询说明。因此这里只能确认官方文档支持通过 zone Security Events 查看事件；不能声称 CF-Ray 可直接作为过滤条件或保证能找到该 403。API-Football 之前的 Cloudflare 错误页要求联系站点所有者并提供 Ray ID，但这是错误页上的通用说明，不等于 Cloudflare Security Events 的查询方法。

## 对当前 API 消费者的适用性

当前会话没有两家 API 服务方的 Cloudflare zone 管理绑定或规则管理工具，未进行 zone 权限测试。我们没有已确认的服务商批准出口 IP，也没有确认这次 403 命中了哪个产品或规则。所以本会话无法执行 Skip、修改 Bot Fight Mode 或查看服务方的 Security Events。可由 API 服务商授权管理员依据请求时间、CF-Ray、host/path 等事件字段检查记录；若确认是某个可跳过的规则，只为已验证的合法流量建立范围最窄的例外。不得推定应关闭整个安全产品。

首个 Cloudflare 文档站 GET 返回 403 后，没有再请求该主机；改从 Cloudflare 官方公开文档仓库读取固定 commit 的源文件。第一次 raw 路径不存在，随后以仓库 tree 确认真实文件路径，具体响应见 `search-log.json` 和 `sources.json`。
