import re,json,hashlib
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
B=Path(__file__).parent
rows=json.loads((B/'results.json').read_text());verified=[];timelines=[]
for r in rows:
 p=Path(r['raw_path']);raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()==r['sha256'];s=raw.decode();assert '試合終了' in s and '準々決勝' in s and '第1戦' in s and '2026/11/11' in s
 found=[];headers=[]
 for value in re.findall(r'self\.__next_f\.push\((\[.*?\])\)</script>',s):
  c=json.loads(value)
  if len(c)>1 and isinstance(c[1],str) and '"type":"post-game"' in c[1]:
   text=c[1]; tree=json.loads(text[text.index(':')+1:]);headers.extend(z[3] for z in tree if isinstance(z,list) and len(z)>3 and isinstance(z[3],dict) and z[3].get('type')=='post-game')
  if len(c)>1 and isinstance(c[1],str) and 'eventType' in c[1] and 'homeTeamName' in c[1]:
   text=c[1];found.append(json.loads(text[text.index(':')+1:])[3])
 assert len(found)==len(headers)==1
 h=headers[0];assert h['tournament']=='leaguecup' and h['section'].replace('　',' ')== '準々決勝 第1戦' and '2026-11-11' in h['date'] and h['isExtended'] is False
 assert [h['homeTeam']['score'],h['awayTeam']['score']]==[r['home_90'],r['away_90']]
 assert h['homeTeam']['name']==found[0]['homeTeamName'] and h['awayTeam']['name']==found[0]['awayTeamName']
 props=found[0];events=[];score=[0,0];ht=[0,0]
 for e in props['events']:
  assert e['period'] in ('前半','後半')
  for ix,side in enumerate(['home','away']):
   for player in e.get(side+'Players',[]):
    typ=player['eventType'];minute=e['time']+(45 if e['period']=='後半' else 0);extra=e.get('extraTime',0)
    events.append({'period':e['period'],'minute':minute,'added':extra,'side':side,'type':typ,'name':player['name'],'source_event':e})
    assert 'own' not in typ.lower(), 'Own goal needs separate beneficiary verification'
    if typ=='goal':
     score[ix]+=1
     if e['period']=='前半':ht[ix]+=1
 assert score==[r['home_90'],r['away_90']]
 events.sort(key=lambda e:(e['period']=='後半',e['minute'],e['added']))
 timelines.append({'match_id':'jleague:'+r['match_id'],'home':props['homeTeamName'],'away':props['awayTeamName'],'score':score,'halftime':ht,'events':events,'source_url':r['source_url'],'raw_sha256':r['sha256'],'validation':'Official goal events sum to reported final score; all periods regulation first/second halves; no extra-time/shootout/own-goal event.'})
 verified.append({**r,'match_id':'jleague:'+r['match_id'],'home_goals':score[0],'away_goals':score[1],'score_basis':'regulation_90','observed_at':datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),'observed_at_semantics':'root verification time of saved official result, not invented HTTP request second','halftime':ht,'cross_source_status':'official_only; ESPN endpoint does not cover these matches'})
(B/'verified-events.json').write_text(json.dumps(timelines,ensure_ascii=False,indent=2))
(B/'verified-results.json').write_text(json.dumps({'matches':verified,'independent_source_corroboration':False},ensure_ascii=False,indent=2))
for t in timelines:print(t['match_id'],t['score'],'HT',t['halftime'],[(e['minute'],e['added'],e['side'],e['name'],e['type']) for e in t['events'] if e['type'] in ['goal','red-card']])
