import json,sys,hashlib
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from research.analysis_freeze import save,verify
B=Path(__file__).parent
locked=json.loads((B/'locked-predictions.json').read_text())
for x in locked:assert verify(json.loads(Path(x['path']).read_text()))['record_sha256']==x['sha256']
files=['review.md','metrics.json','verified-results.json','verified-events.json','sources.json','facts.json','locked-predictions.json']
payload={'report':(B/'review.md').read_text(),'metrics':json.loads((B/'metrics.json').read_text()),'results':json.loads((B/'verified-results.json').read_text()),'sources':json.loads((B/'sources.json').read_text()),'decision':'SUPPLEMENT_DATA_AND_OBSERVE_NO_PARAMETER_CHANGE_NO_PROMOTION','source_commit':'a689b151f148905a8480e6a4ed0fc34575c38a3b','evidence_sha256':{f:hashlib.sha256((B/f).read_bytes()).hexdigest() for f in files},'prior_records':[{'freeze_id':x['freeze_id'],'sha256':x['sha256']} for x in locked]}
fixture={'match_id':'jleague-cup-20261111-batch','kickoff_at':'2026-11-11T18:00:00+08:00','cutoff_at':datetime.now(ZoneInfo('Asia/Shanghai')).isoformat()}
r=save(payload,fixture,stage='review',track='comprehensive-review',idempotency_key='20261112-jcup-review-1')
assert verify(json.loads(Path(r['path']).read_text()))['record_sha256']==r['sha256']
(B/'freeze-receipt.json').write_text(json.dumps(r,ensure_ascii=False,indent=2))
(B/'review-freeze.json').write_bytes(Path(r['path']).read_bytes())
print(json.dumps(r,ensure_ascii=False))
