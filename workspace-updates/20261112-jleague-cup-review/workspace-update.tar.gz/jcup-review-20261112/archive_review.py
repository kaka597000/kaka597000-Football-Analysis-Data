import json,hashlib,tarfile,os,shutil
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
B=Path(__file__).parent;D=Path('/workspace/kaka597000-Football-Analysis-Data');rel='workspace-updates/20261112-jleague-cup-review';out=D/rel;out.mkdir(parents=True,exist_ok=True)
files=[p for p in B.rglob('*') if p.is_file() and '__pycache__' not in p.parts and not p.name.endswith('-headers.txt')]
secrets=[v.encode() for k,v in os.environ.items() if any(w in k.lower() for w in ['key','token','secret','password']) and len(v)>=12]
for p in files:
 raw=p.read_bytes()
 if any(v in raw for v in secrets):raise RuntimeError('Credential-value scan failed; refusing archive')
entries=[{'workspace_path':str(p),'archive_path':str(p.relative_to('/workspace')),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(files)]
arc=out/'workspace-update.tar.gz'
with tarfile.open(arc,'w:gz') as t:
 for p in sorted(files):t.add(p,arcname=str(p.relative_to('/workspace')),recursive=False)
receipt=json.loads((B/'freeze-receipt.json').read_text())
manifest={'source_commit':'a689b151f148905a8480e6a4ed0fc34575c38a3b','created_at_bjt':datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),'batch':receipt,'independent_matches':4,'prematch_records_verified_unchanged':35,'comprehensive_primary':{'hits':1,'eligible':2,'scope':4},'research_primary':{'current_hits':0,'test_hits':0,'eligible_each':4},'independent_result_sources':1,'model_promotion':False,'parameters_changed':False,'archive_sha256':hashlib.sha256(arc.read_bytes()).hexdigest(),'files':entries,'dependencies':['workspace-updates/20261111-jleague-cup-lineups/manifest.json','workspace-updates/20261111-jleague-cup-display/manifest.json','workspace-updates/20261111-jleague-cup-quarterfinals/manifest.json']}
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
for f in ['review.md','metrics.json','freeze-receipt.json','verified-results.json']:shutil.copy2(B/f,out/f)
with tarfile.open(arc,'r:gz') as t:
 for e in entries:assert hashlib.sha256(t.extractfile(e['archive_path']).read()).hexdigest()==e['sha256']
latest=json.loads((D/'latest-source.json').read_text());updates=latest.setdefault('additional_workspace_updates',[])
if rel not in updates:updates.append(rel)
latest['latest_jleague_cup_review']=rel+'/manifest.json';latest['synchronized_at']=manifest['created_at_bjt'];(D/'latest-source.json').write_text(json.dumps(latest,ensure_ascii=False,indent=2)+'\n')
shared=Path('/workspace/shared');shared.mkdir(exist_ok=True);shutil.copy2(B/'review.md',shared/'jleague-cup-review-20261112.md')
print(json.dumps({'archive_files':len(files),'archive_bytes':arc.stat().st_size,'archive_verified':True,'credential_scan':'passed','review_freeze':receipt['freeze_id']},ensure_ascii=False))
