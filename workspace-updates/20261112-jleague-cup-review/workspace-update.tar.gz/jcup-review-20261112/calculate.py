import json,sys,math
from pathlib import Path
from datetime import datetime
sys.path[:0]=['/workspace/Football-Analysis/runtime','/workspace/Football-Analysis/runtime/v5']
from research.analysis_freeze import verify
from paired_review import review,legacy
import numpy as np
B=Path('/workspace/jcup-review-20261112');locked=json.loads((B/'locked-predictions.json').read_text());raw=json.loads((B/'verified-results.json').read_text());results=raw['matches'];rmap={r['match_id']:r for r in results};ids={f'jleague:11110{i}' for i in range(1,5)};assert set(rmap)==ids
for x in locked:assert verify(json.loads(Path(x['path']).read_text()))['record_sha256']==x['sha256'];assert datetime.fromisoformat(x['recorded_at'])<datetime.fromisoformat(x['fixture']['kickoff_at'].replace('Z','+00:00'))
comp={}
for rev in [1,2,3]:
 rows=[]
 for x in locked:
  if x['track']!='comprehensive' or x['revision']!=rev:continue
  r=rmap[x['match_id']];p=x['payload'];score=f"{r['home_goals']}-{r['away_goals']}";actual='胜' if r['home_goals']>r['away_goals'] else '负' if r['home_goals']<r['away_goals'] else '平';rows.append({'match_id':x['match_id'],'prediction':p.get('primary'),'result':score,'primary_hit':p.get('primary')==score if p.get('primary') else None,'wdl_prediction':p.get('wdl'),'wdl_actual':actual,'wdl_hit':p.get('wdl')==actual if p.get('wdl') in ['胜','平','负'] else None,'freeze_id':x['freeze_id'],'total_direction':p.get('total_direction')})
 assert {r['match_id'] for r in rows}==ids;comp[str(rev)]={'rows':rows,'scope':4,'primary_eligible':sum(r['primary_hit'] is not None for r in rows),'primary_hits':sum(r['primary_hit'] is True for r in rows),'wdl_eligible':sum(r['wdl_hit'] is not None for r in rows),'wdl_hits':sum(r['wdl_hit'] is True for r in rows),'total_eligible':0,'pending':0}
research={};diag=[]
for rev in [1,2]:
 pairs=[]
 for x in locked:
  if x['track']!='jleague-cup-quarterfinal-candidates' or x['revision']!=rev:continue
  pair={'match_id':x['match_id']};r=rmap[x['match_id']]
  for role,key in [('current','current_model'),('test','test_model')]:
   f=x['payload'][role];assert f.get('actual_line') is None
   pair[key]={'input':x['fixture'],'generated_at':x['recorded_at'],'version':f['version'],'matrix':f['matrix'],'matrix_hash':legacy.digest(f['matrix']),'primary':'-'.join(map(str,f['statistical_top1'])),'wdl_reference':None,'total':None}
   if rev==1:
    m=np.asarray(f['matrix']);sides={}
    for side,axis,actual in [('home',1,r['home_goals']),('away',0,r['away_goals'])]:
     p=m.sum(axis=axis);lo=int(np.searchsorted(p.cumsum(),.1));hi=int(np.searchsorted(p.cumsum(),.9));mean=float(p@np.arange(len(p)));sides[side]={'actual':actual,'mean':mean,'error_predicted_minus_actual':mean-actual,'absolute_error':abs(mean-actual),'interval80':[lo,hi],'interval_hit':lo<=actual<=hi}
    diag.append({'match_id':x['match_id'],'role':role,'probability_of_actual_score':float(m[r['home_goals'],r['away_goals']]),'score_log_loss':-math.log(max(float(m[r['home_goals'],r['away_goals']]),1e-15)),'sides':sides})
  pairs.append(pair)
 assert len(pairs)==4;research[str(rev)]=review(pairs,results)
net={}
for role,label in [('current','当前模型'),('test','test模型')]:
 rr={r['match_id']:r['models'][label]['primary_hit'] for r in research['1']['paired_rows']};cr=[r for r in comp['1']['rows'] if r['primary_hit'] is not None];net[role]={'common_eligible_matches':len(cr),'manual_hits':sum(r['primary_hit'] for r in cr),'model_hits':sum(rr[r['match_id']] for r in cr),'net_manual_minus_model':sum(int(r['primary_hit'])-int(rr[r['match_id']]) for r in cr)}
summary={'comprehensive_by_revision':comp,'independent_research_by_revision':research,'research_wdl_note':'No single WDL direction was issued in candidate freezes; probabilities or score-implied draw not retroactively counted as a direction pick','diagnostics':diag,'paired_manual_vs_candidate':net,'active_pair_status':{'scope':4,'current_valid_predictions':0,'test_valid_predictions':0,'reason':'ABSTAIN_NO_ACTIVE_COHORT'},'top3':{'selected':0,'eligible':0},'independent_match_count':4,'primary_revision_policy':'first prematch primary; revisions separate; no pooling','formal_promotion':False}
(B/'metrics.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(json.dumps({'comprehensive':{k:{j:v[j] for j in ['scope','primary_eligible','primary_hits','wdl_eligible','wdl_hits']} for k,v in comp.items()},'research':research['1']['models'],'net':net},ensure_ascii=False))
