import argparse,csv,json,unicodedata,re,collections
from pathlib import Path
parser=argparse.ArgumentParser(description='Join the SPI snapshot to both Football-Data calendars by league, exact date and opponents.')
parser.add_argument('--market-dir',required=True,type=Path)
parser.add_argument('--spi-csv',required=True,type=Path)
parser.add_argument('--out',required=True,type=Path)
args=parser.parse_args()
args.out.mkdir(parents=True,exist_ok=True)
leagues={'eng.1':'Barclays Premier League','fra.1':'French Ligue 1','ger.1':'German Bundesliga','ita.1':'Italy Serie A','esp.1':'Spanish Primera Division'}
aliases={
'Bournemouth':'AFC Bournemouth','Brighton':'Brighton and Hove Albion','Man City':'Manchester City','Man United':'Manchester United','Tottenham':'Tottenham Hotspur','West Ham':'West Ham United','Wolves':'Wolverhampton','Leicester':'Leicester City','Norwich':'Norwich City',"Nott'm Forest":'Nottingham Forest','Dijon':'Dijon FCO','Leeds':'Leeds United','Vallecano':'Rayo Vallecano','Chievo':'Chievo Verona','Hamburg':'Hamburg SV','West Brom':'West Bromwich Albion','Cardiff':'Cardiff City','Huddersfield':'Huddersfield Town','Stoke':'Stoke City','Swansea':'Swansea City','Newcastle United':'Newcastle',
'Monaco':'AS Monaco','Paris SG':'Paris Saint-Germain','Rennes':'Stade Rennes','St Etienne':'St Etienne','Nimes':'Nimes',
'Augsburg':'FC Augsburg','Union Berlin':'1. FC Union Berlin','Ein Frankfurt':'Eintracht Frankfurt','M\'gladbach':'Borussia Monchengladbach','Dortmund':'Borussia Dortmund','Leverkusen':'Bayer Leverkusen','Hertha':'Hertha Berlin','Hannover':'Hannover 96','Koln':'FC Cologne','FC Koln':'FC Cologne','Darmstadt':'SV Darmstadt 98','Ingolstadt':'FC Ingolstadt 04','Furth':'SpVgg Greuther Fürth','Nurnberg':'1. FC Nürnberg','Bochum':'VfL Bochum','Bielefeld':'Arminia Bielefeld','Freiburg':'SC Freiburg','Mainz 05':'Mainz','Hoffenheim':'TSG Hoffenheim','Schalke':'Schalke 04','Wolfsburg':'VfL Wolfsburg','Stuttgart':'VfB Stuttgart',
'Milan':'AC Milan','Inter':'Internazionale','Roma':'AS Roma','Verona':'Verona','Spal':'Spal','Spezia':'Spezia','Salernitana':'Salernitana','Monza':'Monza','Juventus':'Juventus',
'Ath Bilbao':'Athletic Bilbao','Ath Madrid':'Atletico Madrid','Sociedad':'Real Sociedad','Betis':'Real Betis','Espanol':'Espanyol','Alaves':'Alavés','Cadiz':'Cadiz','Celta':'Celta Vigo','La Coruna':'Deportivo La Coruña','Valladolid':'Real Valladolid','Sevilla':'Sevilla FC','Huesca':'SD Huesca','Gijon':'Sporting Gijón','Sp Gijon':'Sporting Gijón','Malaga':'Málaga','Almeria':'Almeria','Osasuna':'Osasuna','Girona':'Girona FC','Las Palmas':'Las Palmas','Leganes':'Leganes','Eibar':'Eibar','Granada':'Granada','Elche':'Elche','Levante':'Levante','Mallorca':'Mallorca','Valencia':'Valencia','Villarreal':'Villarreal','Getafe':'Getafe','Barcelona':'Barcelona','Real Madrid':'Real Madrid'}
def norm(s):
 s=aliases.get(s,s)
 s=unicodedata.normalize('NFKD',s).encode('ascii','ignore').decode().lower()
 return re.sub(r'[^a-z0-9]','',s)
spi=list(csv.DictReader(args.spi_csv.open(encoding='utf-8')))
index=collections.defaultdict(list)
for x in spi:
 if x['league'] in leagues.values(): index[(x['date'],x['league'],norm(x['team1']),norm(x['team2']))].append(x)
for source in ['modern-market-paths.jsonl','legacy-untouched-mixed-proxy.jsonl']:
 rows=[json.loads(l) for l in (args.market_dir/source).open()]
 output=[]; unmatched=collections.Counter(); dup=0; matched=0
 for m in rows:
  lig=leagues.get(m['cohort']); cand=index.get((m['game_date'],lig,norm(m['home']),norm(m['away'])),[]) if lig else []
  x=cand[0] if len(cand)==1 else None
  if len(cand)>1: dup+=1
  if not x: unmatched[(m['cohort'],m['home'],m['away'])]+=1
  else: matched+=1
  output.append({'match_id':m['match_id'],'game_date':m['game_date'],'cohort':m['cohort'],'home':m['home'],'away':m['away'],'spi_status':'matched' if x else 'missing','spi_source_timestamp':'2025-03-06T12:54:11Z' if x else None,'spi':({k:(float(x[k]) if x[k] not in ('','NA') else None) for k in ['spi1','spi2','prob1','prob2','probtie','proj_score1','proj_score2']} if x else None),'spi_league':x['league'] if x else None,'spi_date':x['date'] if x else None,'spi_home':x['team1'] if x else None,'spi_away':x['team2'] if x else None})
 with (args.out/source.replace('.jsonl','-spi.jsonl')).open('w') as f:
  for x in output:f.write(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n')
 print(source,'rows',len(rows),'matched',matched,'dup',dup,'coverage',matched/len(rows))
 print('common unmatched',unmatched.most_common(30))
