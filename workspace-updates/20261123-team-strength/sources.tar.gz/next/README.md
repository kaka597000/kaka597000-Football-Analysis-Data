# 2026-11-27至11-30前向赛程与近期赛果

## 前向赛程

目标区间为北京时间 2026-11-27 00:00（含）至 2026-11-30 00:00（不含），转换为 UTC 后按 ESPN 每日 scoreboard 查询并严格过滤 `2026-11-26T16:00Z <= kickoff < 2026-11-29T16:00Z`。五个 competition ID 为 `eng.1`、`esp.1`、`ita.1`、`ger.1`、`fra.1`。`fixtures.json` 是完整返回记录，不按偏好删场；列表按开球时间、联赛、ESPN ID 排序。每条含 `stage=regular`、成年男子、俱乐部、tier1 cohort 标注、ESPN 主客队ID、名称、开球时间、状态及原始响应URL、采集时间和SHA-256。

ESPN 在目标窗口返回36场，全部为 `STATUS_SCHEDULED`。逐队按明确别名与 round2 的 `data/modern-market-paths.jsonl` 2026/27 同 cohort 球队表严格匹配，36场的72个队名均有对应记录；映射带 `history_status=in_2627_cohort`，详见 `team-map.json`。这验证了对阵双方的队名均出现在本地对应联赛的 26/27 数据中，但没有独立联赛官网/FotMob赛程核验。已尝试 FotMob公开 league API 的两个候选端点，均返回 HTTP 404，因此不把它描述成双源核验。ESPN自身赛事季节和competition信息见 raw JSON。

`raw/` 保存赛程原始 JSON；`source-manifest.json` 列出每次调用的URL、采集时间、HTTP状态、文件与 SHA。市场字段标记 `NO_VERIFIABLE_SOURCE_QUOTE_TIME`，没有可核验的同期赛前赔率。

## 近期赛果

`results-20261109-22.json` 收录来源本地日期 2026-11-09 至 2026-11-22（含）的五联赛 ESPN 已完赛赛事，共45场，每联赛9场。日期使用联赛当地时区：英格兰 Europe/London；西班牙 Europe/Madrid；意大利 Europe/Rome；德国 Europe/Berlin；法国 Europe/Paris。严格过滤 ESPN 完赛状态 `STATUS_FULL_TIME`，比分为主客90分钟比分；包含 ESPN ID、队名、队伍ID、旧 Football-Data 同联赛队名、当地日期、UTC开球、来源SHA/URL/采集时间。全体队名均可映射到对应 cohort 历史队名表。

已复验：45个唯一 ESPN ID；无同联赛/本地日期/主客对阵完全重复，无同日主客颠倒重复；与本地 round2 11/8 盘口档案无同日同对阵碰撞。对 11/9–22 每场未在 round2 归档找到相同日期同向对阵。校验表见 `results-validation.json`。仅有ESPN来源，未独立确认比分；没有取得真实赛前1X2报价或实际大小球线，`market=NOT_COLLECTED`。日原始响应在 `raw_results/`，请求收据在 `results-source-manifest.json`。

## 先前三场当前状态

按冻结 ESPN ID `401875009`、`401882802`、`401879237` 分别回查 Monza–Fiorentina、Levante–Elche、Brentford–Everton。三场均为 2026-11-23 UTC 开球，采集时状态 `STATUS_SCHEDULED` / `pre`，无比分。逐场 summary 原始 JSON、URL、查询时间及SHA见 `prior-three-status.json` 和 `raw_status/`。

所有采集时间以 UTC 记录。
