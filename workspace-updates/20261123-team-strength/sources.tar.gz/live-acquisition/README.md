# Live market acquisition — 2026-11-23

## Status

Three current fixtures now have direct HKJC official full-time correct-score prices: **28 explicit scorelines plus all 5 displayed “other score” groups per fixture**. The official page also provides current 90-minute HDA, Asian handicap, and totals quotes. Machine-readable output: [hkjc-official-three-matches.json](hkjc-official-three-matches.json).

For the requested Beijing-time 2026-11-27 00:00 through 2026-11-30 00:00 window, the public HKJC correct-score list showed no events in the window at the captured time. The rendered public list had 34 events through 26 November. See [hkjc-next-window-direct-correct-score-check.json](hkjc-next-window-direct-correct-score-check.json).

## Direct HKJC quotes for the three current fixtures

The user-visible public interface `https://bet.hkjc.com/ch/football/home` returned odds without login. “More” opened each event’s public all-odds page. Full DOM, visible text, screenshots, route response, and hashes are under `raw/hkjc/`.

| ESPN match ID | HKJC front-end / match ID | Fixture | Scheduled kick-off (UTC / HKT) | Page update label (HKT) | Full-time HDA (home/draw/away) | Full-time Asian handicap (home / away) | Full-time totals (line: over/under) |
|---|---|---|---|---|---|---|---|
| espn:401875009 | FB9233 / 50079899 | Monza–Fiorentina | 23 Nov 19:45Z / 24 Nov 03:45 | 23/11/2026 11:09 | 3.40 / 3.75 / 1.75 | +0.75: 1.70 / −0.75: 2.13 | 3.5: 2.35/1.52; 3/3.5: 2.10/1.65; 4.5: 3.95/1.19 |
| espn:401879237 | FB8907 / 50079823 | Brentford–Everton | 23 Nov 20:00Z / 24 Nov 04:00 | 23/11/2026 11:09 | 2.05 / 3.30 / 2.96 | −0.25: 1.88 / +0.25: 1.88 | 2.5: 1.73/1.98; 2.5/3: 1.93/1.77; 3.5: 2.80/1.37 |
| espn:401882802 | FB9247 / 50080017 | Levante–Elche | 23 Nov 20:00Z / 24 Nov 04:00 | 23/11/2026 11:10 | 2.00 / 3.35 / 2.98 | −0.25: 1.87 / +0.25: 1.93 | 2.5: 1.68/2.05; 2.5/3: 1.87/1.83; 3.5: 2.75/1.38 |

`hkjc-official-three-matches.json` contains every correct-score outcome with its source label and price, the five “other” categories, full market data, source timing, score period, ESPN/HKJC IDs, and raw evidence hashes. The correct-score market is the regulation-time formal score (`波膽`), distinct from `半場波膽` and extra-time score. Official HKJC fixed-odds rules section 3.4 lists the score groups and treats home-win, away-win, and draw “other” outcomes separately. The visible five “other” buckets partition the remaining outcomes by result and whether the opposing side scored.

The site’s `更新時間` is a **page-level** label (Asia/Hong_Kong, UTC+08:00), not a per-selection quote timestamp. Capture time is separately recorded in UTC; no individual quote timestamp is exposed by this interface. The page calls its displayed event time `預定截止投注時間`; actual scheduled kick-off in the table and JSON comes from the ESPN fixture crosswalk. The HKJC page disclaimer says displayed odds are for reference and the final price is set when a bet is accepted.

HKJC fixed-odds rules section 3.1(b) says the stake is multiplied by the fixed odds on a win, so the displayed prices are decimal total-return multipliers; no second Hong Kong-odds conversion is needed. The official rules PDF, extracted text, response metadata, and SHA-256 are in `raw/hkjc-fixed-odds-rules.*` and `raw/hkjc-fixed-odds-rules.metadata.json`.

## InferSports public REST data

InferSports (`https://api.infersports.dev`) also served keyless read-only odds without signup or payment. Its API provides 1X2, Asian handicap, and totals, but **does not provide correct-score/exact-score markets**. The direct HKJC evidence above fills that gap; the earlier “no exact-score market” statement applied only to InferSports.

The initial three-event payloads are retained in `raw/evt_*-odds.json`; every quote row has a source `as_of`, and each snapshot has its own `as_of`, `stale`, and retrieval time. Levante–Elche’s initial provider snapshot is marked stale. These are distinct from the later direct HKJC page update labels and capture times.

For the Beijing-time 11/27–11/30 window, `next/fixtures.json` was cross-mapped one-to-one to 36 InferSports scheduled events using UTC kick-off and team names. All 36 returned positive open quotes in each of full-time 1X2, Asian handicap, and totals. Raw responses and response metadata are retained in `raw/window-*-odds.json` and `raw/window-*-odds.headers.json`; normalized long-form files are `window-top5-odds-normalized.json` and `.csv`.

At capture, the 36-event API snapshots were stale for 18 events. Across the 887 raw quote rows, source quote ages at HTTP capture were 108 at or below 1 hour, 661 over 1–16 hours, and 118 over 16 hours. Per-row source quote time, retrieval time, snapshot time/stale flag, and time to kick-off are in the normalized export. The only returned bookmaker-attributed brands in this window were Crown, M8Bet, Nova88, and SBOBET; no HKJC, Macau, or Pinnacle quotes were returned for these 36 events.

## Raw evidence

- InferSports OpenAPI/agent documentation snapshots: `raw/infersports-openapi.raw`, `raw/infersports-llms.raw`, and `raw/infersports-llms-full.raw`.
- Public HKJC homepage and public betting app shell: `raw/hkjc-homepage-public.html`, `raw/hkjc-public-betting-app-shell.html`, and the matching response headers.
- The captured public HKJC correct-score market listing and all three event pages: `raw/hkjc/official-hkjc-public-correct-score.*` and `raw/hkjc/official-FB{9233,8907,9247}-all-markets.*`.
- ESPN fixture crosswalks: `raw/espn-current-slate-fixtures-crosswalk-source.json` and `raw/espn-next-fixtures-crosswalk-source.json`.

No credentials were used and no paid subscription was purchased. All HKJC observations came from its normal public betting pages; no access controls or error responses were bypassed.
