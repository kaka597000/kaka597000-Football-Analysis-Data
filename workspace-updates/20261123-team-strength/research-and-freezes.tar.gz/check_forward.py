"""Independently verify all first-capture bodies, prices, evidence and the six-game component."""
import argparse
import csv,json
from datetime import datetime,timezone
from pathlib import Path
from zoneinfo import ZoneInfo
import sys
from collections import Counter

def run(root,source):
    sys.path[:0]=[str(source/'runtime'),str(source/'runtime/v5'),str(source)]
    from research.analysis_freeze import verify,aware
    from research_program.paired_kpi_inference import compare_audited
    from research_program.prior_team_strength import predict
    from research_program.future_validation import sha
    from research_program.kpi_score_candidate import artifact_identity
    from research_program import market_baseline
    def get(path):return json.loads(Path(path).read_bytes())
    def put(path,v):path.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
    rows=get(root/'forward/receipts.json')
    def freeze(reference):
        path=Path(reference['path'])
        local=root/'issued'/(reference['freeze_id']+'.json')
        body=local.read_bytes() if local.exists() else path.read_bytes()
        recorded=verify(json.loads(body))
        assert recorded['record_sha256']==reference['sha256']
        local.parent.mkdir(exist_ok=True)
        if not local.exists():local.write_bytes(body)
        return recorded
    plan=freeze(rows['register'])
    artifact=get(root/'study/updated/forward-artifact.json')
    assert artifact_identity(artifact)==plan['payload']['candidate']['artifact_sha256']
    captures=[];out=[];by_route=Counter()
    for mid,rec in rows['matches'].items():
        record=freeze(rec);captures.append(record)
        path=root/'forward'/(mid.replace(':','-')+'-forecast.json')
        evidence=get(path);f=evidence['fixture']; q=evidence['candidate']; m=evidence['baseline']; p=record['payload']
        assert sha(path)==p['candidate']['forecast_evidence_sha256']==p['market_baseline']['forecast_evidence_sha256']
        for name,live in (('candidate',predict(artifact,f)),('market_baseline',market_baseline.predict(f))):
            if name=='candidate':
                assert live['matrix_sha256']==q['matrix_sha256'] and live['components']==q['components']
                assert live['wdl']==p[name]['wdl'] and live['total']==q['total']
                assert (live['total'] or {}).get('direction')==p[name]['total_side']
            else:
                assert live.get('lowest_price_1x2')==p[name]['wdl']
                assert (live.get('full_win_total') or {}).get('direction')==p[name]['total_side']
            for k in ('primary','top3'):
                assert live.get(k)==p[name][k]
        assert q['primary']==q['top3'][0] and len(set(q['top3']))==3
        quote=f.get('total_quote') if q['total'] else None
        if quote:
            assert aware(f['cutoff_at'])-aware(quote['quoted_at'])<=market_baseline.MAXIMUM_QUOTE_AGE
            proof=f['market_evidence']['odds'];assert sha(root/proof['file'])==quote['source_sha256']==proof['sha256']
        by_route[(q['effective_recipe'],bool(quote),m['status'])]+=1
        out.append({'北京时间':aware(f['kickoff_at']).astimezone(ZoneInfo('Asia/Shanghai')).strftime('%Y-%m-%d %H:%M'),
                    '赛事':f['cohort'],'主队':f['home_name'],'客队':f['away_name'],'研究首选':q['primary'],
                    '备选一':q['top3'][1],'备选二':q['top3'][2],'胜平负':{'home':'主胜','draw':'平局','away':'客胜'}[q['wdl']],
                    '大小球':({'over':'大','under':'小'}[q['total']['direction']] if quote else ''),
                    '盘线':quote['line'] if quote else '','机构':quote['bookmaker'] if quote else '',
                    '市场参考首选':m.get('primary'),'选分方法':q['effective_recipe'],'冻结ID':rec['freeze_id'],'状态':'待赛'})
    report=compare_audited(plan,captures,[],evidence_root=root)
    assert report['population']==report['pending']==len(out)==36
    assert len({r['match_id'] for r in captures})==len(out)
    put(root/'forward-audit.json',{'receipt':rows['register'],'paths':[{'rule':k[0],'has_total':k[1],'control':k[2],'n':v} for k,v in by_route.items()],'audit':report})
    with (root/'forward-36.csv').open('w',encoding='utf-8-sig',newline='') as h:
        wr=csv.DictWriter(h,fieldnames=out[0].keys(),lineterminator='\n');wr.writeheader();wr.writerows(sorted(out,key=lambda r:r['北京时间']))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('source',type=Path);a=p.parse_args();run(a.root,a.source)
