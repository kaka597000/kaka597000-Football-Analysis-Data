"""Fixed-population first-score and shortlist accounting for all inspected periods."""
from collections import Counter,defaultdict
from pathlib import Path
import argparse,json
def diagnostic(rows, arms):
    summary={}
    for name in arms:
        available=[r for r in rows if r['forecast'].get(name,{}).get('top3')]
        split=Counter();modes=Counter();goals=Counter();by=defaultdict(Counter);per_match=[]
        for r in available:
            picks=r['forecast'][name]['top3'];truth=r['actual'];score='%s-%s'%tuple(truth); rank=picks.index(score)+1 if score in picks else 0
            split[str(rank)]+=1;modes[picks[0]]+=1;goals[sum(truth)]+=1
            high=sum(truth)>=4
            by[r['cohort']]['n']+=1;by[r['cohort']]['first']+=rank==1;by[r['cohort']]['three']+=rank>0
            by[r['cohort']]['actual_four_plus']+=high;by[r['cohort']]['three_hit_four_plus']+=high and rank>0
            per_match.append((picks[0]=='1-1',score=='1-1'))
        one_one_issued=sum(a for a,b in per_match);one_one_wins=sum(a and b for a,b in per_match)
        summary[name]={'available':len(available),'total_population':len(rows),'actual_score_rank':dict(split),
                       'first_scores':dict(modes.most_common()),'actual_totals':dict(goals),
                       'actual_1_1':sum(b for a,b in per_match),'when_1_1_issued':{'n':one_one_issued,'wins':one_one_wins},
                       'cohorts':by}
    return summary
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);r=p.parse_args().root
    def load(f):return [json.loads(s) for s in f.open()]
    o={s:diagnostic(load(r/('study/heads/'+s+'-picks.jsonl')),('market','six_match_xg','prior_market_xg','independent_heads')) for s in ('select','known_holdout','final')}
    o['recent_45']=diagnostic(load(r/'study/updated/recent-paired.jsonl'),('issued_comprehensive','market','six_match_xg','strength','independent_heads'))
    (r/'diagnostics.json').write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n')
