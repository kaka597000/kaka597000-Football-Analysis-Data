"""Score only the three frozen direct-price comparisons, against source-proved full times."""
import argparse,json
from pathlib import Path
import sys
from zoneinfo import ZoneInfo

def main(a):
    sys.path[:0]=[str(a.source/'runtime'),str(a.source/'runtime/v5'),str(a.source)]
    from research.analysis_freeze import verify,aware
    from research_program.kpi_validation import review
    from research_program.paired_kpi_inference import compare
    from research_program.future_validation import sha,read,write_new
    from research_program.future_identity import fixture_identity
    d=a.bundle/'direct'
    refs=read(d/'summary.json'); plan=verify(read(d/(refs['registration']['freeze_id']+'.json')))
    orig=d/'original';current=verify(read(orig/'plan.json')); originals=[verify(read(p)) for p in sorted(orig.glob('espn-*.json'))]
    checked=review(current,originals,read(a.results),evidence_root=a.evidence_root)
    assert plan['payload']['original_plan']==current['record_sha256']
    assert plan['payload']['protocol_sha256']==sha(a.bundle/'direct-score-protocol.json')
    assert set(plan['payload']['population'])=={r['match_id'] for r in checked['rows']}=={r['match_id'] for r in refs['rows']}
    old={r['match_id']:r for r in originals}; scoring=[]
    for row in checked['rows']:
        mid=row['match_id']; source,=[r for r in refs['rows'] if r['match_id']==mid]
        record=verify(read(d/(source['receipt']['freeze_id']+'.json')))
        f,p=record['fixture'],record['payload']; freeze=aware(record['recorded_at'])
        assert plan['track']=='displayed-score-registration' and record['track']=='displayed-correct-score-study' and record['revision']==1
        assert p['plan_sha256']==plan['record_sha256'] and p['original_first_sha256']==old[mid]['record_sha256']
        assert fixture_identity(f)==fixture_identity(old[mid]['fixture'])
        assert aware(plan['recorded_at'])<=aware(f['cutoff_at'])<=freeze<aware(f['kickoff_at']) and aware(p['observed_at'])<=freeze
        scoring.append({'id':mid,'cohort':f['cohort'],'date':aware(f['kickoff_at']).astimezone(ZoneInfo('Asia/Shanghai')).date().isoformat(),
                        'line':None,'actual':row['result'],'forecast':{'direct':{'top3':p['prediction']['top3']},
                        'inferred':{'top3':p['prediction']['inferred_same_page']['top3']},'original':{'top3':p['original_first']}}})
    write_new(a.out,{'evidence':'FIRST_PREMATCH_OBSERVED_PAGE_RANKS_AND_ORIGINAL_ESPN_FULLTIME_AUDIT',
                     'original_plan':current['record_sha256'],'direct_plan':plan['record_sha256'],'rows':scoring,
                     'comparisons':{k:compare(scoring,baseline=k,candidate='direct') for k in ('original','inferred')}})
if __name__=='__main__':
    parser=argparse.ArgumentParser()
    for n in ('bundle','source','results','evidence-root','out'):parser.add_argument('--'+n,type=Path,required=True)
    main(parser.parse_args())
