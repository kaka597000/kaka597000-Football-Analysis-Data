"""Check the public full-time market text against the extracted quotes and freeze a separate trial."""
import argparse
from datetime import datetime,timezone
import hashlib,json,re
from pathlib import Path
import sys

def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def store(p,value):
    with p.open('x') as f:json.dump(value,f,ensure_ascii=False,allow_nan=False,indent=2)

def markets(text):
    lines=[s.strip() for s in text.splitlines() if s.strip()]
    start=lines.index('選擇其他賽事')
    def section(a,b):
        lo=lines.index(a,start);return lines[lo+1:lines.index(b,lo+1)]
    score=section('波膽','半場波膽')
    singles=[];groups=[]
    for i,s in enumerate(score):
        if re.fullmatch(r'\d+:\d+',s):
            singles.append({'score':s.replace(':','-'),'decimal':float(score[i+1])})
        elif s in ('主其他','客其他','和其他'):
            note=score[i+1] if score[i+1].startswith('(') else ''
            groups.append({'label':s+note,'decimal':float(score[i+2 if note else i+1])})
    hda=section('主客和','半場主客和')
    prices=[float(s) for s in hda if re.fullmatch(r'\d+\.\d+',s)]
    assert len(prices)==3
    totals=section('入球大細','球隊入球大細')
    current=[]
    for i,s in enumerate(totals):
        if re.fullmatch(r'\[[\d.]+(?:/[\d.]+)?\]',s):
            legs=list(map(float,s.strip('[]').split('/')))
            current.append(dict(line=sum(legs)/len(legs),over=float(totals[i+1]),under=float(totals[i+2])))
    assert len(set(x['score'] for x in singles))==28 and len(singles)==28
    assert len(set(x['label'] for x in groups))==5 and len(groups)==5
    assert current
    return singles,groups,dict(zip(('home','draw','away'),prices)),current

def main(a):
    sys.path[:0]=[str(a.source/'runtime'),str(a.source/'runtime/v5'),str(a.source)]
    from research.analysis_freeze import save,verify,digest,aware
    from research_program.displayed_exact_scores import compare,VERSION
    root=a.root; direct=root/'live-acquisition'; p=root/'direct-score-protocol.json'
    old=read(a.older);old_plan=verify(read(Path(old['register']['path'])))
    inputs=read(direct/'hkjc-official-three-matches.json')
    rules=read(p); mids=set(rules['population'])
    assert set(old_plan['payload']['fixtures'])=={r['espn_match_id'] for r in inputs['events']}==mids
    period={'rule':VERSION,'protocol_sha256':sha(p),'population':rules['population'],
            'source_sha256':sha(a.source/'runtime/research_program/displayed_exact_scores.py'),
            'original_plan':old_plan['record_sha256'],'time_basis':'PUBLICLY_OBSERVED_BEFORE_KICKOFF_NO_OPTION_QUOTE_CLOCK'}
    now=lambda:datetime.now(timezone.utc).isoformat()
    plan=save(period,dict(match_id='displayed-score-plan:'+digest(period),cutoff_at=now(),
                   kickoff_at=min(aware(f['kickoff_at']) for f in old_plan['payload']['fixtures'].values()).isoformat()),
                   stage='prematch',track='displayed-score-registration',idempotency_key=digest(period))
    trials=[];out=root/'direct';out.mkdir(exist_ok=True)
    for r in inputs['events']:
        mid=r['espn_match_id'];old_first=verify(read(Path(old['matches'][mid]['path']))); f=old_first['fixture']
        s=r['source_evidence'];t=direct/'raw/hkjc'/s['hkjc_row_file']; dom=direct/'raw/hkjc'/s['hkjc_dom_file']
        assert (f['home_name'],f['away_name'],aware(f['kickoff_at']))==(r['home'],r['away'],aware(r['scheduled_at_utc']))
        assert sha(t)==s['row_text_sha256'] and sha(dom)==s['rendered_dom_sha256'] and aware(s['capture_time_utc'])<=aware(now())<aware(f['kickoff_at'])
        text=t.read_text();assert r['hkjc_frontend_match_id'] in text and r['hkjc_match_id'] in s['match_odds_page_url']
        singles,other,hda,totals=markets(text)
        source=r['correct_score']['outcomes']
        assert sorted((v['home_goals'],v['away_goals'],v['price_decimal']) for v in source if v['selection_type']=='exact_score')==sorted((*map(int,v['score'].split('-')),v['decimal']) for v in singles)
        assert sorted(v['price_decimal'] for v in source if v['selection_type']!='exact_score')==sorted(v['decimal'] for v in other)
        assert hda=={k:float(v) for k,v in r['hda'].items()}
        assert sorted((v['line'],v['over'],v['under']) for v in totals)==sorted(((sum(v['line_components'])/len(v['line_components']) if v['line_components'] else float(v['line_label'])),float(v['over']),float(v['under'])) for v in r['totals'])
        pred=compare(singles,other,h2h=hda,totals=totals)
        inputs={'match_id':mid,'cohort':f['cohort'],'stage':'regular','home':f['home'],'away':f['away'],'home_name':r['home'],'away_name':r['away'],
                'kickoff_at':f['kickoff_at'],'cutoff_at':now(),'score_basis':'regulation_90'}
        payload={'plan_sha256':plan['sha256'],'original_first_sha256':old_first['record_sha256'],
                 'original_first':old_first['payload']['candidate']['top3'],'hkjc_event_id':r['hkjc_match_id'],
                 'source_url':s['match_odds_page_url'],'source_text_sha256':sha(t),'source_dom_sha256':sha(dom),
                 'observed_at':s['capture_time_utc'],'page_update_display':s['visible_page_update_label_original'],
                 'individual_quote_time':None,'declared_explicit_prices':len(singles),'other_groups':len(other),
                 'offered_1x2':hda,'offered_totals':totals,'prediction':pred}
        trial=save(payload,inputs,stage='prematch',track='displayed-correct-score-study',idempotency_key=period['protocol_sha256'])
        trials.append({'match_id':mid,'home':r['home'],'away':r['away'],'direct':pred['top3'],'inferred':pred['inferred_same_page']['top3'],
                       'older_first':payload['original_first'],'quote_observed_at':payload['observed_at'],'price_tie_counts':pred['price_tie_counts'],
                       'other_shorter':pred['other_buckets_at_or_shorter_than_third'],'receipt':trial})
    for receipt in [plan]+[r['receipt'] for r in trials]:
        body=Path(receipt['path']).read_bytes();assert verify(json.loads(body))['record_sha256']==receipt['sha256']
        (out/(receipt['freeze_id']+'.json')).write_bytes(body)
    store(out/'summary.json',{'registration':plan,'rows':trials,'pending':len(trials)})
if __name__=='__main__':
    p=argparse.ArgumentParser()
    for k in ('root','source','older'):p.add_argument('--'+k,required=True,type=Path)
    main(p.parse_args())
