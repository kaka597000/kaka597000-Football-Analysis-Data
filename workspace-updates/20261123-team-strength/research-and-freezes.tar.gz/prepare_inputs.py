"""Reconcile captured raw identities, frozen controls and club spellings for this batch."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import tarfile
from zoneinfo import ZoneInfo

def read(p):
    return json.loads(p.read_bytes())

def put(p,value):
    p.write_text(json.dumps(value,ensure_ascii=False,allow_nan=False,indent=2)+'\n')

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def main(a):
    sys.path[:0]=[str(a.source/'runtime'),str(a.source/'runtime/v5'),str(a.source)]
    from research.analysis_freeze import aware
    from research_program.club_market_capture import attach
    root=a.root
    nextdir=root/'next'
    source=root/'live-acquisition'
    work=root/'study'
    fixtures=read(nextdir/'fixtures.json')
    cross={row['espn_match_id']:row for row in read(source/'window-top5-odds-normalized.json')['events']}
    caps=read(nextdir/'team-map.json')['cohorts']
    team_map={k:{i:r['football_data_name'] for i,r in ids.items() if r['football_data_name']} for k,ids in caps.items()}
    put(work/'team-map.json',team_map)
    teams={}
    inputs={}
    def capture(raw,headers):
        meta=read(headers)
        assert meta['http_status']==200
        return {'url':meta['url'],'captured_at':meta['captured_at_utc'],'file':str(raw.relative_to(root)),'sha256':sha(raw)}
    for f in fixtures:
        row=cross[f['match_id']]
        local=aware(f['kickoff_at']).astimezone(ZoneInfo('Asia/Shanghai')).date().isoformat()
        dates=source/'raw'/('events-shanghai-'+local+'.json')
        day=capture(dates,dates.with_suffix('.headers.json'))
        candidates=[r for r in read(dates)['data'] if r['id']==row['infersports_event_id']]
        event,=candidates
        assert aware(event['scheduled_at'])==aware(f['kickoff_at'])
        cohort=f['cohort']
        reviewed=teams.setdefault(cohort,{})
        for side in ('home','away'):
            t=event[side+'_team']
            key=f[side]
            mapping={'espn_name':f[side+'_name'],'provider_id':t['id'],'provider_name':t['name']}
            if key in reviewed:
                assert reviewed[key]==mapping
            reviewed[key]=mapping
        s=f['sources'][0]; boardfile=nextdir/s['file']
        assert sha(boardfile)==s['response_sha256']
        board={'file':str(boardfile.relative_to(root)),'sha256':s['response_sha256'],'url':s['source_url'],'captured_at':s['query_time']}
        oddsfile=source/'raw'/('window-'+event['id']+'-odds.json')
        inputs[f['match_id']]={'event_id':event['id'],'events':day,'espn':board,
                               'odds':capture(oddsfile,oddsfile.with_suffix('.headers.json'))}
    put(work/'infer-team-ids.json',teams)
    put(work/'infer-source-manifest.json',inputs)
    cutoff=a.cutoff or datetime.now(timezone.utc).isoformat()
    quotes=[attach(f,root,inputs[f['match_id']],teams,cutoff) for f in fixtures]
    put(work/'prepared-future.json',quotes)
    results={r['match_id']:r for r in read(nextdir/'results-20261109-22.json')}
    verified=read(nextdir/'recent-frozen-controls.json')
    xs=read(nextdir/'recent-xg.json') if (nextdir/'recent-xg.json').exists() else None
    if xs is None and not a.market_only:
        raise FileNotFoundError('recent-xg.json not available for the forward state')
    if a.market_only:
        return
    xg={r['espn_match_id']:r for r in xs['records']}
    assert set(xg)==set(results)
    updates=[]
    for c in verified['fixtures']:
        mid=c['match_id'];r=results[mid];f=c['original_frozen_selection'];q=c['market_source'];identity=c['source_identity']
        assert c['result']['home_goals']==r['home_goals'] and c['result']['away_goals']==r['away_goals']
        assert (c['cohort'],identity['home_id'],identity['away_id'],aware(identity['kickoff_at']))==(r['cohort'],r['home'],r['away'],aware(r['kickoff_at']))
        assert q['timestamp_certified'] and not q['historical_proxy'] and c['original_frozen_selection']['evaluation_slot']=='FIRST_PREMATCH'
        assert max(aware(q[k]) for k in ('h2h_quoted_at','total_quoted_at'))<=aware(identity['cutoff_at'])<aware(r['kickoff_at'])
        assert f['total_line']==q['total_line'] and f['top3'][0]==f['primary']
        h,a=(r[k+'_football_data_name'] for k in ('home','away'))
        issued={'primary':f['primary'],'top3':f['top3'],'wdl':{'主胜':'home','平局':'draw','客胜':'away'}[f['wdl']],
                'total_side':{'小':'under','大':'over'}[f['total_direction']]}
        item=dict(match_id=mid,cohort=c['cohort'],stage='regular',score_basis='regulation_90',game_date=r['source_local_date'],
                  home=h,away=a,home_goals=r['home_goals'],away_goals=r['away_goals'],market={'bookmaker':q['bookmaker'],
                  'h2h':q['1x2_decimal'],'total':dict(q['total_over_under_decimal'],line=q['total_line'])},
                  issued=issued,freeze_sha256=c['freeze_reference']['freeze_record_sha256_field'])
        original=xg[mid]
        if original.get('home_xg') is not None and original.get('away_xg') is not None:
            assert original['identity_status']=='verified' and original['full_time_verified']
            assert (original['cohort'],original['home_espn_id'],original['away_espn_id'],aware(original['kickoff_at']))==(r['cohort'],r['home'],r['away'],aware(r['kickoff_at']))
            src=original['source']
            assert aware(r['kickoff_at'])<aware(src['observed_at'])<=aware(cutoff)
            rawpath=nextdir/'recent-xg'/'raw'/('fotmob-match-'+original['fotmob_match_id']+'.json')
            if rawpath.exists():
                raw=rawpath.read_bytes()
            else:
                archive,member=src['archive_path'].removeprefix('archive:').split('#',1)
                with tarfile.open(archive) as t:raw=t.extractfile(member).read()
            assert hashlib.sha256(raw).hexdigest()==src['sha256']
            stats=json.loads(raw)['content']['stats']['Periods']['All']['stats']
            actual,=[stat['stats'] for section in stats for stat in section['stats'] if stat.get('key')=='expected_goals'][:1]
            assert [float(a) for a in actual]==[original['home_xg'],original['away_xg']]
            item['xg']={'home':original['home_xg'],'away':original['away_xg'],'source_sha256':src['sha256'],'observed_at':src['observed_at']}
        updates.append(item)
    assert len(updates)==len(set(results))==45
    put(work/'updates.json',updates)

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--root',type=Path,required=True)
    p.add_argument('--source',type=Path,required=True)
    p.add_argument('--market-only',action='store_true')
    p.add_argument('--cutoff',help='retained observation cutoff for an offline replay')
    main(p.parse_args())
