"""Fixed SPI ablation on the two last complete Big Five SPI seasons."""
import argparse
import json
from pathlib import Path
import sys
import numpy as np

def main(args):
    sys.path.insert(0, str(args.source_repo/'scripts'))
    from train_prior_team_strength import batch_poisson, evaluate, historical_markets
    from train_kpi_candidate import read_examples
    from research_program.paired_kpi_inference import compare
    examples,_ = read_examples(args.history)
    rows = [x[0] for x in examples]
    markets = historical_markets(args.history,rows,args.cache,4)
    sources={r['match_id']:r for r in map(json.loads,args.join.open())}
    result={}
    ledger=[]
    for season in ('2122','2223'):
        pts=[x for x in rows if x['season']==season]
        complete=[r for r in pts if sources[r['match_id']]['spi'] is not None
                  and all(sources[r['match_id']]['spi'][k] is not None for k in ('proj_score1','proj_score2'))]
        stats={}
        scored=[]
        for r in complete:
            src=sources[r['match_id']]
            assert (r['cohort'],r['game_date'],r['home'],r['away']) == (src['cohort'],src['spi_date'],src['home'],src['away'])
            scored.append({'id':r['match_id'],'cohort':r['cohort'],'date':r['game_date'],'actual':[r['home_goals'],r['away_goals']],
                           'line':r['market']['total']['line'],'forecast':{}})
        actual=np.array([r['actual'] for r in scored])
        lines=np.array([r['line'] for r in scored])
        spi=batch_poisson(np.array([[sources[r['match_id']]['spi'][k] for k in ('proj_score1','proj_score2')] for r in complete]))
        base=np.stack([markets[r['match_id']] for r in complete])
        delta=spi.shape[1]-base.shape[1]
        for name,mat in [('market',base),('spi',spi),('market_75_spi_25',.75*np.pad(base,((0,0),(0,delta),(0,delta)))+.25*spi)]:
            stats[name]=evaluate(mat,actual,lines,scored,name)
        seen={r['id'] for r in scored}
        missing=[r for r in pts if r['match_id'] not in seen]
        for r in missing:
            row={'id':r['match_id'],'cohort':r['cohort'],'date':r['game_date'],'actual':[r['home_goals'],r['away_goals']],
                 'line':r['market']['total']['line'],'forecast':{}}
            evaluate(markets[r['match_id']][None],np.array([row['actual']]),np.array([row['line']]),[row],'market')
            scored.append(row)
        assert len({r['id'] for r in scored})==len(pts)
        result[season]={'population':len(pts),'joined':len(complete),'missing':len(missing),'matched_metrics':stats,
                        'paired':{name:compare(scored,baseline='market',candidate=name) for name in ('spi','market_75_spi_25')}}
        ledger.extend(scored)
    (args.out/'spi-results.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    with (args.out/'spi-paired.jsonl').open('w') as handle:
        for r in ledger:handle.write(json.dumps(r,separators=(',',':'))+'\n')
if __name__=='__main__':
    p=argparse.ArgumentParser()
    for name in ('source-repo','history','cache','join','out'):p.add_argument('--'+name,type=Path,required=True)
    main(p.parse_args())
