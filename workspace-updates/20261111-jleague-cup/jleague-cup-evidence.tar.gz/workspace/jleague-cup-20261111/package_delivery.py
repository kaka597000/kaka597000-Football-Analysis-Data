import datetime,hashlib,json,os,pathlib,shutil,tarfile
root=pathlib.Path(__file__).parent
target=pathlib.Path('/workspace/kaka597000-Football-Analysis-Data/workspace-updates/20261111-jleague-cup')
target.mkdir(parents=True,exist_ok=False)
databases=[pathlib.Path('/workspace/WCPP/data/jleague-cup/jleague-cup-20261111.sqlite'),pathlib.Path('/workspace/WCPP/data/jleague-cup/jleague-cup-official-schedule-20261111.sqlite')]
audit=json.loads((root/'independent-audit.json').read_text())
readme=pathlib.Path('/workspace/Football-Analysis/docs/jleague-cup.md').read_text()+'''

## 本次交付与限制

独立复核：212场/45份历史来源，212场与旧库90分钟比分一致；8条2026/27八强首/次回合官方赛程，双方球队代码均从对应页面homeTeam/awayTeam对象重新核验。实际原始HTTP采集由Luna执行，共12次；未逐请求记录的精确抓取时间保持NULL，采集窗口另存。主代理另记只读核验时间，不能替代API抓取时点。

附独立官方赛程库jleague-cup-official-schedule-20261111.sqlite。历史源中立场仍均NULL。4个工件是旧edition研究候选，不能用于2026/27八强；不能称已有可用的该阶段活动模型。

开发诊断：2023小组赛40拟合/20留出，两候选统计Top1均1/20；2025来源1/64-finals因同日比赛成组，26拟合/仅1留出，两候选均0/1。后者尤其不能解读为有效效果验证。没有合格真实盘口，大小球命中率不报告。24个其他edition/阶段/回合样本不足未训练。统计最大格子不是综合第一推荐。

42次实际留出矩阵重载一致，41项原注册表、工件及数据库哈希未变。源码PR #28，本地688项/24组integration无跳过、静态检查零发现、远端CI以PR实际结果为准。已修复多份分段证据冲突与顺序依赖，独立重建212场事实不变。审计摘要已按review轨冻结，具体ID及时间见review-freeze-receipt.json，不冒充赛前赛事预测。

交付只保留最终final-models、相关来源与审计；早期试跑models和不需要的旧canonical SQLite不进入证据包。原代码、模型及旧预测不覆盖；未发布环境，未新增定时任务。
'''
(root/'README.md').write_text(readme)
files=[p for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts and 'models' not in p.relative_to(root).parts and p.suffix!='.sqlite']+databases
receipt=json.loads((root/'review-freeze-receipt.json').read_text());files.append(pathlib.Path(receipt['path']))
files=sorted(set(files))
secrets=[v.encode() for k,v in os.environ.items() if len(v)>=12 and any(s in k.lower() for s in ('token','secret','password','api_key','apikey','therundown'))]
entries=[]
for p in files:
    b=p.read_bytes()
    if any(s in b for s in secrets):raise ValueError('credential-value scan rejected file')
    entries.append({'path':str(p),'archive_path':str(p).lstrip('/'),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)})
archive=target/'jleague-cup-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
    for p in files:tar.add(p,arcname=str(p).lstrip('/'),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    expected={e['archive_path']:e['sha256'] for e in entries};assert set(tar.getnames())==set(expected)
    for f in tar:assert hashlib.sha256(tar.extractfile(f).read()).hexdigest()==expected[f.name]
manifest={'created_at':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),
          'archive':archive.name,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,
          'files':entries,'credential_values_included':False,'formal_acceptance_passed':False,'active_registry_modified':False}
(target/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
for name in ('README.md','independent-audit.json','review-freeze-receipt.json','database-stats.json','legacy-score-comparison.json','official-fixtures-verified.json'):
    shutil.copy2(root/name,target/name)
for p in databases:shutil.copy2(p,target/p.name)
shutil.copytree(root/'final-models',target/'research-models',ignore=shutil.ignore_patterns('dataset.json','diagnostic.json','*-evaluation-core.json'))
with (target/'README.md').open('a') as f:
    f.write('\n[历史SQLite](jleague-cup-20261111.sqlite) · [官方赛程SQLite](jleague-cup-official-schedule-20261111.sqlite) · [研究工件](research-models) · [完整证据包](jleague-cup-evidence.tar.gz) · [文件SHA清单](manifest.json) · [源码PR28](https://github.com/kaka597000/Football-Analysis/pull/28)\n\n恢复：先比对压缩包及逐文件SHA，再解压至独立目录核验，保持workspace/jleague-cup-20261111、workspace/WCPP/data/jleague-cup和review冻结的目录结构。工件依赖dataset/protocol/engine的绝对路径和SHA，单独下载artifact不足以完整重验；完整包包含所需原文、数据集与诊断。已有不同文件先处理冲突，不覆盖旧数据库或冻结。\n')
print(json.dumps({'files':len(files),'archive_bytes':archive.stat().st_size,'target':str(target)}))
