import collections,datetime,hashlib,json,pathlib,re,sqlite3,sys,unicodedata
import numpy as np
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from jleague_cup import database as db,model,evidence
from research.analysis_freeze import save

root=pathlib.Path(__file__).parent;staging=root/'staging'
protected=json.loads((root/'protected-assets.json').read_text())
for p,want in protected.items():assert hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()==want,p
database=pathlib.Path('/workspace/WCPP/data/jleague-cup/jleague-cup-20261111.sqlite')
verified=db.rows(database);assert len(verified)==212
with db.connect(database) as c:
    assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
    assert not c.execute('PRAGMA foreign_key_check').fetchall()
    assert c.execute('SELECT COUNT(*) FROM matches WHERE neutral IS NOT NULL').fetchone()[0]==0
    for s in c.execute('SELECT * FROM sources'):
        assert hashlib.sha256(pathlib.Path(s['raw_path']).read_bytes()).hexdigest()==s['raw_sha256']
index=json.loads((root/'final-models/candidates.json').read_text());artifacts=0;replayed=0;groups=[]
byid={r['match_id']:r for r in verified}
for cohort,entry in index['routes'].items():
    report=json.loads(pathlib.Path(entry['report_path']).read_text());assert report['fit_end']<report['holdout_start']
    groups.append({'cohort':cohort,'total_n':report['total_n'],'fit_n':report['fit_n'],'holdout_n':report['holdout_n'],
                   'primary_hits':{k:v['primary']['hits'] for k,v in report['metrics'].items()}})
    for role,ref in entry['artifacts'].items():
        p=pathlib.Path(ref['path']);assert evidence.sha(p)==ref['sha256'];a=json.loads(p.read_text());assert not a['formal_acceptance_passed']
        for stem in ('engine','dataset','protocol'):assert evidence.sha(a[stem+'_path'])==a[stem+'_sha256']
        artifacts+=1
        evaluation=json.loads(p.with_name(role+'-evaluation-core.json').read_text())
        for prediction in report['predictions'][role]:
            m,_=model.distribution(evaluation,byid[prediction['match_id']]);assert np.array_equal(m,np.asarray(prediction['matrix']));replayed+=1

# Verify same-page official team identities, including the awayTeam objects
# omitted by the first extraction. Never infer an absent provider team ID.
official=[];verified_at=datetime.datetime.now(datetime.timezone.utc).isoformat()
for line in (staging/'fixtures.jsonl').read_text().splitlines():
    f=json.loads(line);p=staging/f['source_path'];body=p.read_text()
    assert evidence.sha(p)==f['source_sha256']
    assert re.search(r'<link[^>]*rel="canonical"[^>]*href="'+re.escape(f['source_url'])+'"',body)
    parts=re.findall(r'self\.__next_f\.push\(\[1,("(?:\\.|[^"\\])*")\]\)',body)
    decoded=''.join(json.loads(p) for p in parts);out={**f,'query_time':None,'verified_at':verified_at}
    for side in ('home','away'):
        candidates=[]
        for m in re.finditer('"'+side+'Team":',decoded):
            try:item,_=json.JSONDecoder().raw_decode(decoded[m.end():])
            except ValueError:continue
            if item.get('nameS')==f[side+'_name']:candidates.append(item)
        codes={item['code'] for item in candidates};assert len(codes)==1
        out[side+'_id']='jleague:'+next(iter(codes))
    assert '$D'+f['kickoff_utc'] in decoded
    leg=1 if f['leg']=='first' else 2
    visible=unicodedata.normalize('NFKC',re.sub('<[^>]+>',' ',body))
    assert re.search(r'準々決勝\s*第'+str(leg)+'戦',visible)
    assert f['season']=='2026/27' and not any(f.get(k) is not None for k in ('h90','a90','extra_h','extra_a','pen_h','pen_a'))
    out.update(stage='quarterfinals',leg=leg,tie_format='two-leg',research_eligible=False,
               phase='inventory_only_no_model_for_this_edition',identity_verified=True)
    official.append(out)
assert len(official)==8 and len({f['match_id'] for f in official})==8
(root/'official-fixtures-verified.json').write_text(json.dumps(official,ensure_ascii=False,indent=2)+'\n')
schedule=pathlib.Path('/workspace/WCPP/data/jleague-cup/jleague-cup-official-schedule-20261111.sqlite')
with schedule.open('xb'):pass
c=sqlite3.connect(schedule)
c.execute('CREATE TABLE events(match_id TEXT PRIMARY KEY,edition TEXT,home_id TEXT,away_id TEXT,kickoff_utc TEXT,stage TEXT,leg INTEGER,source_path TEXT,source_sha256 TEXT,query_time TEXT,verified_at TEXT,payload_json TEXT)')
for f in official:c.execute('INSERT INTO events VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(f['match_id'],f['season'],f['home_id'],f['away_id'],f['kickoff_utc'],f['stage'],f['leg'],str(staging/f['source_path']),f['source_sha256'],None,verified_at,json.dumps(f,ensure_ascii=False)))
c.commit();assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok';c.close()
report={'historical_matches':212,'historical_sources':45,'historical_venues_unknown':212,
        'scope_competitions':20,'research_artifacts':artifacts,'groups':groups,'untrained_groups':len(index['untrained']),
        'exact_diagnostic_matrix_reload_checks':replayed,'official_edition':'2026/27','official_schedule_matches':8,
        'official_both_team_ids_verified':8,'protected_asset_hashes_unchanged':len(protected),
        'database_sha256':evidence.sha(database),'schedule_database_sha256':evidence.sha(schedule),
        'formal_acceptance_passed':False,'active_registry_modified':False,'model_available_for_2026_27_quarterfinals':False}
(root/'independent-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
shell={'match_id':'jleague-cup-data-model-audit-20261111','cohort':'jpn.league_cup','cutoff_at':verified_at,'kickoff_at':min(f['kickoff_utc'] for f in official)}
receipt=save(report,shell,stage='review',track='jleague-cup-training-audit')
(root/'review-freeze-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False))
