"""Retain historical odds fields with auditable source identity and no quote clock."""
import csv
import hashlib
import json
import math
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PRIOR = ROOT.parents[1] / 'kpi-optimization-20261123' / 'data'
CODES = {'E0': 'eng.1', 'D1': 'ger.1', 'F1': 'fra.1', 'I1': 'ita.1', 'SP1': 'esp.1'}
BOOKS = {
    'Bet365': {
        'open': ('B365H B365D B365A', 'B365>2.5 B365<2.5', 'AHh B365AHH B365AHA'),
        'close': ('B365CH B365CD B365CA', 'B365C>2.5 B365C<2.5', 'AHCh B365CAHH B365CAHA')},
    'Pinnacle': {
        'open': ('PSH PSD PSA', 'P>2.5 P<2.5', 'AHh PAHH PAHA'),
        'close': ('PSCH PSCD PSCA', 'PC>2.5 PC<2.5', 'AHCh PCAHH PCAHA')},
    'Betfair Exchange': {
        'open': ('BFEH BFED BFEA', 'BFE>2.5 BFE<2.5', 'AHh BFEAHH BFEAHA'),
        'close': ('BFECH BFECD BFECA', 'BFEC>2.5 BFEC<2.5', 'AHCh BFECAHH BFECAHA')},
    'Quoted market average': {
        'open': ('AvgH AvgD AvgA', 'Avg>2.5 Avg<2.5', 'AHh AvgAHH AvgAHA'),
        'close': ('AvgCH AvgCD AvgCA', 'AvgC>2.5 AvgC<2.5', 'AHCh AvgCAHH AvgCAHA')},
}
SPLITS = {'1516': 'fit_1516_1617', '1617': 'fit_1516_1617',
          '1718': 'selection_1718', '1819': 'heldout_1819_legacy_market_proxy'}

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def day(raw):
    return datetime.strptime(raw.strip(), '%d/%m/%Y' if len(raw.strip()) >= 10 else '%d/%m/%y').date().isoformat()

def nums(row, columns, *, odds=True):
    try:
        vals = [float(row[k]) for k in columns.split()]
    except (KeyError, TypeError, ValueError):
        return None
    if not all(math.isfinite(x) and (x > 1 if odds else True) for x in vals):
        return None
    return vals

def date_rows(raw):
    # Historical proprietary team spellings are part of the dated row identity.
    text = raw.decode('utf-8-sig',errors='replace')
    for source_line, r in enumerate(csv.DictReader(text.splitlines()), 2):
        if r.get('Date') and r.get('HomeTeam') and r.get('AwayTeam') and r.get('FTHG') and r.get('FTAG'):
            yield source_line, r

def prices(r, columns):
    hda, ou, ah = columns
    a, b, c = nums(r,hda), nums(r,ou), nums(r,ah,odds=False)
    d = {}
    if a:
        d['h2h'] = dict(zip(('home','draw','away'),a))
    if b:
        d['total'] = {'line':2.5,'over':b[0],'under':b[1]}
    if c and c[1] > 1 and c[2] > 1 and (c[0]*4).is_integer():
        d['handicap']={'home_line':c[0],'home':c[1],'away':c[2]}
    return d

def save_rows(path, rows):
    with path.open('wb') as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False, separators=(',',':'),allow_nan=False).encode()+b'\n')

def legacy_rows(sources):
    out = []
    for meta in sources:
        season, code = Path(meta['file']).stem.split('_')
        if season not in SPLITS:
            continue
        raw=(ROOT/'raw'/meta['file']).read_bytes()
        assert digest(raw)==meta['sha256']
        for lineno,r in date_rows(raw):
            date=day(r['Date'])
            home,away=r['HomeTeam'],r['AwayTeam']
            dg=f'{code}|{date}|{home}|{away}'.encode()
            assert (2000+int(season[:2]))<=int(date[:4])<=(2000+int(season[2:]))
            oh=nums(r,'PSH PSD PSA');ch=nums(r,'PSCH PSCD PSCA');ou=nums(r,'BbAv>2.5 BbAv<2.5')
            a,b=int(r['FTHG']), int(r['FTAG'])
            assert (('H' if a>b else 'A') if a!=b else 'D')==r['FTR']
            market=None
            if ch and ou:
                market={'h2h':dict(zip(('home','draw','away'),ch)),
                        'total':{'line':2.5,'over':ou[0],'under':ou[1]},
                        'bookmaker':'MIXED_SOURCE_PROXY','h2h_source':'Pinnacle PSCH/PSCD/PSCA',
                        'total_source':'Football-Data multi-book BbAv>2.5/BbAv<2.5, quote time unspecified'}
            out.append({'match_id':'football-data:'+digest(dg)[:24],'cohort':CODES[code],'stage':'regular',
                        'game_date':date,'season':season,'partition':SPLITS[season],
                        'home':home,'away':away,'home_goals':a,'away_goals':b,'score_basis':'regulation_90',
                        'historical_proxy':True,'timestamp_certified':False,'source_file':meta['file'],
                        'source_line':lineno,'source_url':meta['url'],'source_sha256':meta['sha256'],
                        'market':market,'same_book':False,'quote_time_available':False,
                        'pinnacle_open_h2h':dict(zip(('home','draw','away'),oh)) if oh else None})
    return sorted(out,key=lambda r:(r['game_date'],r['cohort'],r['home'],r['away']))

def modern_rows():
    previous_manifest=json.loads((PRIOR/'manifest.json').read_bytes())
    raw_source={Path(s['path']).name:s for s in previous_manifest['raw_proxy_sources']
                if Path(s['path']).stem.split('_')[-1] in CODES and Path(s['path']).stem.split('_')[0] not in SPLITS}
    latest=(ROOT/'retrieval.json').read_bytes()
    latesthash={s['file']:s['sha256'] for s in json.loads(latest) if s.get('status')==200 and s['file'].startswith('2627_')}
    downloaded_same={k:v['sha256']==latesthash.get(k) for k,v in raw_source.items() if k.startswith('2627_')}
    keyed={}
    for filename, meta in raw_source.items():
        raw=Path(meta['path']).read_bytes()
        assert digest(raw)==meta['sha256']
        keyed[filename]=dict(date_rows(raw))
    old=PRIOR/'closing-proxy-with-xg.jsonl'
    rows=[]
    with old.open() as source:
        for line in source:
            r=json.loads(line)
            raw=keyed[r['source_file']][r['source_line']]
            assert (r['home'],r['away'],r['game_date'],r['home_goals'],r['away_goals']) == (
                raw['HomeTeam'],raw['AwayTeam'],day(raw['Date']),int(raw['FTHG']),int(raw['FTAG']))
            odds={}
            for book, stages in BOOKS.items():
                d={stage:prices(raw,cols) for stage,cols in stages.items()}
                if any(d.values()):
                    odds[book]=d
            r.update(market_paths=odds,market_path_time_basis='archived opening/closing categories without bookmaker quote clock')
            rows.append(r)
    return rows, downloaded_same, digest(old.read_bytes())

def main():
    source=json.loads((ROOT/'retrieval.json').read_bytes())
    legacy=legacy_rows(source)
    modern,equality,previoussha=modern_rows()
    assert len({r['match_id'] for r in legacy+modern})==len(legacy)+len(modern)
    definitions={
        'legacy-untouched-mixed-proxy.jsonl':legacy,
        'modern-market-paths.jsonl':modern,
    }
    for name,rows in definitions.items(): save_rows(ROOT/name, rows)
    manifest={'built_at_utc':datetime.now(timezone.utc).isoformat(),
              'source_retrieval_manifest_sha256':digest((ROOT/'retrieval.json').read_bytes()),
              'previous_joined_input_sha256':previoussha,
              'modern_2627_redownload_same_bytes':equality,
              'assets':{},'limits':{
                  'legacy':'Pinnacle 1X2 opening and closing exist but same-book O/U missing; totals are cross-book arithmetic averages at 2.5, sampled time unspecified. No timestamp certification.',
                  'modern':'Odds category opening/closing supplied by raw archive without each bookmaker quote time. Market average is supplemental cross-book comparison and not a same-book quote.',
                  'holdout':'Legacy 1819 is earlier than fitted modern artifacts and can only be a chronological holdout for a separately fitted and selected legacy model. All modern labels were previously in the workspace.',
                  'coverage':'Empty or invalid fields are retained as omissions. Match outcome fields apply to regular-season men in the five top divisions.'}}
    for k,rr in definitions.items():
        counts={}
        for r in rr:
            w=counts.setdefault(r['partition'],Counter())
            w['matches']+=1
            w['combined_market']+=bool(r['market'])
            for book,sides in r.get('market_paths',{}).items():
                for stage,prices_ in sides.items():
                    w[f'{book}/{stage}/1x2_and_total']+=all(k in prices_ for k in ('h2h','total'))
                    w[f'{book}/{stage}/handicap']+=bool(prices_.get('handicap'))
        p=ROOT/k
        manifest['assets'][k]={'sha256':digest(p.read_bytes()),'bytes':p.stat().st_size,'n':len(rr),'partitions':counts}
    (ROOT/'market-paths-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    for k,meta in manifest['assets'].items():
        print(k,meta['n'],meta['sha256'])

if __name__=='__main__':
    main()
