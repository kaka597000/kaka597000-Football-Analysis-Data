"""Legacy closing/market-average benchmark with outcomes scored after quote-only matrices."""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
from collections import Counter
import csv
import json
import sys

ROOT=Path(__file__).resolve().parent
RUNTIME='/workspace/Football-Analysis-kpi-20261123/runtime'
sys.path[:0]=[RUNTIME,RUNTIME+'/v5']
from research_program.market_baseline import quote_only_matrices
from research_program.three_arm_model import score_picks, top_three_scores
from optimization.evaluate import settle_ou

def normalize(n):
    return {k:float(n['BbAv'+v]) for k,v in [('home','H'),('draw','D'),('away','A')]}

def labels(r):
    h,a=r['home_goals'],r['away_goals']
    return f'{h}-{a}', 'home' if h>a else 'away' if h<a else 'draw', h+a

def quote_scores(r,state):
    mixed=r['market']
    if state=='Pinnacle_close_1X2_MarketAvg_total':
        prices=mixed['h2h']
    else:
        prices=r['archived_aggregate_h2h']
    _,m=quote_only_matrices(prices,mixed['total'])
    p=score_picks(m,line=mixed['total']['line'])
    return {'top3':top_three_scores(m),'wdl':p['wdl'],'total':p['total']['direction']}

def evaluate_record(r):
    if not r['market'] or r.get('archived_aggregate_h2h') is None:
        return None
    v={'match_id':r['match_id'],'game_date':r['game_date'],'cohort':r['cohort'],'season':r['season'],'partition':r['partition']}
    for method in ('Pinnacle_close_1X2_MarketAvg_total','MarketAvg_1X2_and_total'):
        pred=quote_scores(r,method)
        score,wdl,goals=labels(r)
        v[method]={**pred,'first_hit':pred['top3'][0]==score,'three_hit':score in pred['top3'],'wdl_hit':pred['wdl']==wdl,
                   'total_settlement':settle_ou(goals,2.5,pred['total'])}
    return v

def main():
    rows=[json.loads(x) for x in (ROOT/'legacy-untouched-mixed-proxy.jsonl').open()]
    raw={}
    groups={}
    for r in rows:
        n=r['source_file']
        if n not in raw:
            with (ROOT/'raw'/n).open(encoding='utf-8-sig',errors='replace',newline='') as f:
                raw[n]={i:x for i,x in enumerate(csv.DictReader(f),2)}
        source=raw[n][r['source_line']]
        assert (source['HomeTeam'],source['AwayTeam'])==(r['home'],r['away'])
        try:r['archived_aggregate_h2h']=normalize(source)
        except (ValueError,KeyError,TypeError):r['archived_aggregate_h2h']=None
    eligible=[r for r in rows if r['season']=='1819']
    with ProcessPoolExecutor(max_workers=4) as pool: reports=list(pool.map(evaluate_record,eligible,chunksize=80))
    reports=[r for r in reports if r is not None]
    for m in ('Pinnacle_close_1X2_MarketAvg_total','MarketAvg_1X2_and_total'):
        a=[r[m] for r in reports]
        full=Counter(r['total_settlement'] for r in a)
        groups[m]={'scope':len(eligible),'coverage':len(a),'first_hits':sum(r['first_hit'] for r in a),
                   'top3_hits':sum(r['three_hit'] for r in a),'wdl_hits':sum(r['wdl_hit'] for r in a),
                   'settlements':dict(full),'ou_nonpush':len(a)-full['PUSH'],'ou_full_hits':full['FULL_WIN']}
    o={'methods':groups,'scope':'2018/19 five major European top divisions; payout based on 2.5; no goals data used in market-only predictions',
       'market_quote_timestamp':'archival category; no real published clock per offer',
       'full_wdl_and_total_system':'same fixture but market average only OU in old archive, so exact scope mixed'}
    (ROOT/'legacy-baseline-1819.json').write_text(json.dumps(o,indent=2)+'\n')
    with (ROOT/'legacy-baseline-1819-picks.jsonl').open('w') as f:
        for v in reports:f.write(json.dumps(v,separators=(',',':'))+'\n')
    print(json.dumps(o,indent=2))
if __name__=='__main__':main()
