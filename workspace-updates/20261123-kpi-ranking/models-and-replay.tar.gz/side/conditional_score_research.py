"""Date-isolated replay of market-conditional exact-score redistribution."""
import argparse
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
from scipy.optimize import minimize
from scipy.special import logsumexp, softmax
from scipy.stats import binomtest

SIDE=Path(__file__).resolve().parent
ROOT=Path('/workspace/Football-Analysis-kpi-20261123')
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'runtime'),str(ROOT)]
from train_kpi_candidate import read_examples, score_arrays, summary
from research_program import kpi_score_candidate as base

SCORE_BUCKET=5
LOW=.02
HIGH=.075


def market_features(matrices, records, history):
    home, away=np.indices(matrices.shape[1:])
    masks=[home>away,home==away,home<away]
    wdl=np.column_stack([matrices[:,m].sum(axis=1) for m in masks])
    total_over=matrices[:,home+away>=3].sum(axis=1)
    expected_total=np.sum(matrices*(home+away),axis=(-2,-1))
    expected_margin=np.sum(matrices*(home-away),axis=(-2,-1))
    league=np.asarray([[r['cohort']==co for co in base.LEAGUES[1:]] for r in records],dtype=float)
    odds=np.column_stack((expected_total, expected_margin, np.abs(expected_margin), wdl[:,1],
        total_over, (total_over-.5)*expected_margin, (total_over-.5)*np.abs(expected_margin),league))
    # Team-perspective form as of the previous date from the shared trainer.
    fields={name:base.FEATURE_NAMES.index('own_'+name) for name in base.FORM_FIELDS}
    attack=history[:,:,fields['xgf']]
    allowed=history[:,:,fields['xga']]
    raw_scored=history[:,:,fields['gf']]
    raw_conceded=history[:,:,fields['ga']]
    counted=history[:,:,fields['xg_n']]
    ppg=history[:,:,fields['points']]
    expected_form=(attack+allowed[:,::-1])/2
    extension=np.column_stack((expected_form.sum(axis=1), expected_form[:,0]-expected_form[:,1],
                    raw_scored.sum(axis=1), raw_conceded.sum(axis=1), ppg[:,0]-ppg[:,1], counted.sum(axis=1)))
    return {'odds':odds, 'odds_form':np.column_stack((odds,extension))}


def standardize(data, fit):
    center=data[fit].mean(axis=0)
    scale=np.maximum(data[fit].std(axis=0),.02)
    cols=(data-center)/scale
    return np.column_stack((np.ones(len(data)), cols)), {'mean':center.tolist(),'std_floor':scale.tolist()}


def fit_offset(features, baseline, actual, ridge):
    """Estimate conditional score odds ratios from fixed probability offsets."""
    base_log=np.log(np.maximum(baseline,1e-250))
    y=np.eye(baseline.shape[1])[actual]
    rows=len(actual)
    if rows==0:
        raise ValueError('empty training class')
    if baseline.shape[1]==1:
        return np.zeros((features.shape[1],1))
    shape=(features.shape[1], baseline.shape[1])
    ar=np.arange(rows)
    def objective(beta):
        l=beta.reshape(shape)
        logits=base_log+features@l
        z=logsumexp(logits,axis=-1)
        loss=np.mean(z-logits[ar,actual])+.5*ridge*np.square(beta).sum()
        p=np.exp(logits-z[:,None])
        g=features.T@(p-y)/rows+ridge*l
        return loss,g.ravel()
    r=minimize(objective,np.zeros(np.prod(shape)),jac=True,method='L-BFGS-B',
               options={'maxiter':220,'gtol':1e-7,'ftol':1e-12})
    if not r.success:
        raise ValueError(r.message)
    return r.x.reshape(shape)


def score_partition(matrices, actual):
    h,a=np.indices(matrices.shape[1:])
    groups=np.where(h>a,0,np.where(h==a,1,2))*2 + (h+a>=3)
    cells=np.minimum(h,SCORE_BUCKET)*(SCORE_BUCKET+1)+np.minimum(a,SCORE_BUCKET)
    target_groups=np.where(actual[:,0]>actual[:,1],0,np.where(actual[:,0]==actual[:,1],1,2))*2 + (actual.sum(axis=1)>=3)
    target_cells=np.minimum(actual,SCORE_BUCKET)@[SCORE_BUCKET+1,1]
    return groups,cells,target_groups,target_cells


def adjusted_conditionals(matrices, features, actual, fit, ridge):
    groups,cells,target_groups,target_cells=score_partition(matrices,actual)
    adjusted=np.zeros_like(matrices)
    fit_weights={}
    for k in range(6):
        mask=groups==k
        available=np.unique(cells[mask])
        baseline=np.column_stack([matrices[:,mask & (cells==c)].sum(axis=1) for c in available])
        masses=baseline.sum(axis=1,keepdims=True)
        offset=baseline/masses
        in_fit=fit & (target_groups==k)
        cell_indices=np.searchsorted(available,target_cells[in_fit])
        assert np.array_equal(available[cell_indices],target_cells[in_fit])
        beta=fit_offset(features[in_fit],offset[in_fit],cell_indices,ridge)
        conditional_probabilities=softmax(np.log(np.maximum(offset,1e-250))+features@beta,axis=1)
        ratio=conditional_probabilities/offset
        adjusted[:,mask]=matrices[:,mask]*ratio[:,np.searchsorted(available,cells[mask])]
        fit_weights[str(k)]={'score_buckets':available.tolist(),'beta':beta.tolist(),'n':int(in_fit.sum())}
        assert np.allclose(adjusted[:,mask].sum(axis=1),masses[:,0],rtol=0,atol=1e-12)
    return adjusted,fit_weights


def balance_2x3(target, proposed):
    """Restore quote-implied WDL and total marginals after fitting associations."""
    target=target.reshape(-1,3,2)
    adjusted=proposed.reshape(-1,3,2).copy()
    outcome=target.sum(axis=2,keepdims=True)
    totals=target.sum(axis=1,keepdims=True)
    for _ in range(150):
        adjusted*=outcome/adjusted.sum(axis=2,keepdims=True)
        adjusted*=totals/adjusted.sum(axis=1,keepdims=True)
        if np.max(np.abs(adjusted.sum(axis=2,keepdims=True)-outcome))<1e-12:
            return adjusted.reshape(-1,6)
    raise ValueError('marginal balancing did not converge')


def adjust_association(matrices, features, actual, fit, ridge):
    groups,_,target,_=score_partition(matrices,actual)
    joint=np.column_stack([matrices[:,groups==k].sum(axis=1) for k in range(6)])
    beta=fit_offset(features[fit],joint[fit],target[fit],ridge)
    new=softmax(np.log(joint)+features@beta,axis=1)
    adjusted=balance_2x3(joint,new)
    return adjusted/joint, beta.tolist(), groups


def pair(reference, other):
    def counts(a,b):
        gained=int((b & ~a).sum())
        lost=int((a & ~b).sum())
        p=binomtest(gained,gained+lost,.5).pvalue if gained+lost else 1.
        return {'gained':gained,'lost':lost,'net':gained-lost,'paired_exact_p':p}
    return {key:counts(reference[key],other[key]) for key in ('exact','three')}


def market_cache(rows,path,jobs,source_hash):
    expected={'source_hash':source_hash,'n':len(rows),'matrix_version':'WCPP-MARKET-ONLY-1','ids':[r['match_id'] for r in rows]}
    meta=path.with_suffix('.json')
    if path.is_file() and meta.is_file() and json.loads(meta.read_bytes())==expected:
        matrices=np.load(path,allow_pickle=False)
        if matrices.shape!=(len(rows),*base.SHAPE):
            raise ValueError('cache/support mismatch')
        return matrices
    with ProcessPoolExecutor(max_workers=jobs) as pool:
        matrices=np.stack(list(pool.map(base.quotes_matrix,rows,chunksize=80)))
    np.save(path,matrices,allow_pickle=False)
    meta.write_text(json.dumps(expected,ensure_ascii=False)+'\n')
    return matrices


def sha(path):
    d=hashlib.sha256()
    with path.open('rb') as f:
        for x in iter(lambda:f.read(256*1024),b''):d.update(x)
    return d.hexdigest()


def main(path,out,jobs):
    out.mkdir(parents=True,exist_ok=True)
    proto=json.loads((SIDE/'protocol.json').read_bytes())
    records_all,totals=read_examples(path)
    data=[row for row in records_all if row[0].get('market')]
    records,parts,actual,history=zip(*data)
    parts=np.asarray(parts)
    actual=np.asarray(actual)
    history=np.asarray(history)
    lines=np.asarray([x['market']['total']['line'] for x in records])
    assert np.all(lines==2.5)
    fit=parts=='fit'
    sourcehash=sha(path)
    frames=market_cache(records,out/'market.npy',jobs,sourcehash)
    frame_features=market_features(frames,records,history)
    packs={}
    weights={}
    tie_order_audit={}
    h, a = np.indices(frames.shape[1:])
    benchmark_masks = (h > a, h == a, h < a, h + a >= 3)
    def keep(name,m):
        assert np.allclose(m.sum(axis=(1,2)),1.,rtol=0,atol=2e-11)
        values = score_arrays(m, actual, lines)
        if name != 'market':
            # The PMF marginals are locked to the market. Bind independently
            # evaluated WDL and OU directions to the same market decision when
            # equal marginals differ by floating-point rounding.
            for mask in benchmark_masks:
                assert np.allclose(m[:, mask].sum(1), frames[:, mask].sum(1), rtol=0, atol=3e-12)
            audit = {}
            for key, mask_list in [('wdl', benchmark_masks[:3]), ('ou', benchmark_masks[3:])]:
                choice = values[key] != packs['market'][key]
                if choice.any():
                    if key == 'wdl':
                        odds = np.column_stack([frames[choice][:, mask].sum(1) for mask in mask_list])
                        odds.sort(axis=1)
                        assert np.allclose(odds[:, -1], odds[:, -2], rtol=0, atol=1e-12)
                    else:
                        assert np.allclose(frames[choice][:, mask_list[0]].sum(1), .5, rtol=0, atol=1e-12)
                audit[key] = int(choice.sum())
            tie_order_audit[name] = audit
            for key in ('wdl','wdl_hit','ou','settlement'):
                values[key] = packs['market'][key]
        packs[name] = values
    keep('market',frames)
    for label,columns in frame_features.items():
        x,features_standardization=standardize(columns,fit)
        for ridge in (LOW,HIGH):
            print('train', label,ridge,flush=True)
            m,within=adjusted_conditionals(frames,x,actual,fit,ridge)
            variant=f'{label}_within_ridge_{ridge}'
            keep(variant,m)
            weights[variant]={'within':within,'feature_scaling':features_standardization,'ridge':ridge}
            if ridge==LOW:
                fractions,joint,groups=adjust_association(frames,x,actual,fit,ridge)
                variant=f'{label}_joint_within_ridge_{ridge}'
                keep(variant,m*fractions[:,groups])
                weights[variant]={'within':within,'association':joint,'feature_scaling':features_standardization,'ridge':ridge}
    assert set(packs)==set(proto['fixed_arms'])
    def obtain(pack,selection):
        return {key:x[selection] for key,x in pack.items()}
    selects=parts=='select'
    tuning={arm:summary(obtain(p,selects)) for arm,p in packs.items()}
    order=proto['fixed_arms']
    def selection(arm):
        m=tuning[arm]
        return m['primary'],m['top3'],-m['joint_log_loss'],-order.index(arm)
    selected=max(packs,key=selection)
    best_candidate=max((k for k in packs if k!='market'),key=selection)
    (out/'conditional-coefficients.json').write_text(json.dumps(weights,indent=2,allow_nan=False)+'\n')
    (out/'selected-on-2425.json').write_text(json.dumps({'selected':selected,'best_candidate':best_candidate,'selection_details':tuning},indent=2,allow_nan=False)+'\n')
    result={'selected':selected,'best_candidate':best_candidate,'source_sha256':sourcehash,
            'protocol_sha256':sha(SIDE/'protocol.json'),'full_population':totals,'numeric_tie_decision_audit':tie_order_audit,'splits':{}}
    for kind in ['fit','select','known_holdout','final']:
        mask=parts==kind
        cs={arm:obtain(p,mask) for arm,p in packs.items()}
        result['splits'][kind]={'all':{arm:summary(p) for arm,p in cs.items()},
            'paired':{arm:pair(cs['market'],p) for arm,p in cs.items() if arm!='market'},
            'actual_goals_4plus': {arm:{'n':int((mask & (actual.sum(1) >= 4)).sum()),
                               'exact':int(v['exact'][mask & (actual.sum(1) >= 4)].sum()),
                               'three':int(v['three'][mask & (actual.sum(1) >= 4)].sum())}
                               for arm,v in packs.items()}}
        if kind=='known_holdout' or kind=='final':
            with (out/f'{kind}-conditional-predictions.jsonl').open('w') as f:
                for i,(record,goals) in enumerate(zip(np.asarray(records,dtype=object)[mask],actual[mask])):
                    arm_k={arm:[f'{v//base.SHAPE[1]}-{v%base.SHAPE[1]}' for v in p['top'][i]] for arm,p in cs.items()}
                    f.write(json.dumps({'match_id':record['match_id'],'cohort':record['cohort'],
                          'date':record['game_date'],'actual':goals.tolist(),'top3':arm_k},
                         ensure_ascii=False,allow_nan=False)+'\n')
    (out/'conditional-evaluation.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print('selected',selected,'challenger',best_candidate,flush=True)
    for k,s in result['splits'].items():
        print(k,[(name,v['primary'],v['top3'],v['joint_log_loss']) for name,v in s['all'].items()],flush=True)
    print('Not prospective: both 2526 and 2627 outcomes appeared in earlier evaluation records.')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--data',type=Path,default=Path(json.loads((SIDE/'protocol.json').read_bytes())['rows']))
    p.add_argument('--out',type=Path,default=SIDE/'conditional')
    p.add_argument('--jobs',type=int,default=2)
    args=p.parse_args()
    main(args.data,args.out,args.jobs)
