import json
from pathlib import Path
from datetime import datetime,timezone

d = {
    "experiment": "conditional WDL x total score distribution",
    "created_at": datetime.now(timezone.utc).isoformat(),
    "rows": "/workspace/WCPP/reports/kpi-optimization-20261123/data/closing-proxy-with-xg.jsonl",
    "data_scope": "Big Five regular season rows with complete bookmaker 1X2 and actual total 2.5 quote; dates only",
    "training": ["1920", "2021", "2122", "2223", "2324"],
    "selection": ["2425"],
    "previously_exposed_readouts": ["2526", "2627"],
    "fixed_arms": ["market", "odds_within_ridge_0.02", "odds_form_within_ridge_0.02", "odds_joint_within_ridge_0.02", "odds_form_joint_within_ridge_0.02", "odds_within_ridge_0.075", "odds_form_within_ridge_0.075"],
    "parameters": {
        "score_bucket_max": 5, "groups": "1X2 decision x total <=2 / >=3",
        "within": "multinomial score bucket regression with odds-only theoretical PMF as fixed offset",
        "joint": "fit six-class association around baseline with same features and ridge, then IPF back to market WDL and OU marginals",
        "xg_windows": "last six same league strictly older dates, from train_kpi_candidate read_examples; use source agreement join and availability metadata",
        "top3": "highest three cells per model PMF with stable row-major ties",
        "tie_break_on_selection": "top1, top3, lower joint loss, simpler scope",
        "marginal_hold": "all candidate models exactly preserve WDL and O/U 2.5, so hit rates there equal market baseline in this experiment"
    }
}
p=Path(__file__).with_name('protocol.json')
with p.open('x') as f: json.dump(d,f,ensure_ascii=False,indent=2)
