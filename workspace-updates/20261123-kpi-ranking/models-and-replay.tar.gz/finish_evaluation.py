from pathlib import Path
from math import isfinite
import json
import os
import sys

R=Path(__file__).resolve().parent
S=Path('/workspace/Football-Analysis-kpi-20261123-round2')
sys.path[:0]=[str(S/'runtime'),str(S/'runtime/v5'),str(S)]
from research.analysis_freeze import verify
from research_program.market_score_ranker import artifact_identity, predict
from research_program.paired_kpi_inference import compare, compare_audited

def read(p):return json.loads(Path(p).read_bytes())
def put(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def rows(path):
    with path.open() as f:
        return [json.loads(line) for line in f]
def chosen(values,skip):
    def order(k):
        p=values[k]
        return p['primary'],p['top3'],p['wdl'],p['total_full_win']/p['total_non_push'],-p['joint_log_loss']
    return max((k for k in values if k not in skip),key=order)
def main():
    data={}
    for cohort in ('modern','legacy'):
        base=R/'training'/cohort
        summary=read(base/'summary.json')
        artifact=read(base/'artifact.json')
        assert artifact_identity(artifact)==artifact['artifact_sha256']
        secondary=chosen(summary['selection_results'],('market','consensus'))
        for name in summary['outcomes']:
            scores=rows(base/(name+'-paired.jsonl'))
            assert len(scores)==summary['split_population'][name]
            live_candidate='native_'+summary['live_research_challenger']
            data[name]={
                'native':compare(scores,baseline='native_market',candidate=live_candidate),
                'complete_archive_context':compare(scores,baseline='market',candidate=secondary)}
            for tag in ('native','complete_archive_context'):
                pane=data[name][tag]
                for m,v in pane['paired'].items():
                    assert v['gained']-v['lost']==v['net_hits']
        if cohort=='modern':
            assert not secondary.startswith('path_rank')
            multi=dict(artifact,arm=secondary,book_scope='capture_consensus',
                       recipe_selection='BEST_NON_MARKET_ON_2425_ONLY')
            multi['artifact_sha256']=artifact_identity(multi)
            put(base/'multi-book-research-artifact.json',multi)
            assert predict(multi,dict(match_id='unsupported-check',cohort='usa.1'))['reasons']==['OUTSIDE_TRAINED_SCOPE']
    prior=R.parent/'kpi-optimization-20261123'
    initial=read(prior/'forward/issued/receipts.json')
    registration=verify(read(initial['register']['path']))
    records=[verify(read(v['path'])) for v in initial['matches'].values()]
    data['earlier_forward']=compare_audited(registration,records,[],evidence_root=prior)
    head=[]
    new=read(R/'training/modern/multi-book-research-artifact.json')
    for record in records:
        fixture=dict(record['fixture'])
        # Today’s time is past the artifact creation, and before source-verified kickoff.
        fixture['cutoff_at']=new['built_at']
        result=predict(new,fixture)
        assert result['status']=='ABSTAIN'
        head.append(result)
    data['new_research_preflight']=head
    data['fit_to_outcome_metrics']={}
    for k,v in data.items():
        if k not in ('check_2526','check_2627','holdout_1819'):
            continue
        data['fit_to_outcome_metrics'][k]={tag:{metric:{'n':z['eligible'],'net':z['net_hits'],'interval':z['date_cluster_ci']}
                for metric,z in pane['paired'].items()} for tag,pane in v.items()}
    put(R/'paired-results.json',data)
    print(json.dumps(data['fit_to_outcome_metrics'],ensure_ascii=False,indent=2))
if __name__=='__main__':main()
