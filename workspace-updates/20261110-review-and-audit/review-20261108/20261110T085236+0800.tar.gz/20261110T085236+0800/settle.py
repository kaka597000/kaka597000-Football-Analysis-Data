import json,pathlib,collections,csv,copy,sys
B=pathlib.Path(__file__).parent
rows=json.load(open(B/'frozen-records.json')); sources=json.load(open(B/'espn-query-results.json'))['matches']; sm={str(s['espn_event_id']):s for s in sources}
sys.path[:0]=['/workspace/Football-Analysis/runtime','/workspace/Football-Analysis/runtime/v5']
from paired_review import review

def settle(goals,line,d):
 if line is None or d not in ['小','大','under','over']:return None
 line=float(line);lines=[line] if line*2==int(line*2) else [line-.25,line+.25]
 v=sum(0 if goals==l else (1 if (goals>l)==(d in ['大','over']) else -1)for l in lines)/len(lines)
 return {1:'全赢',.5:'半赢',0:'走盘',-.5:'半输',-1:'全输'}[v]

def normalize(r,track):
 j=r['comprehensive' if track=='comprehensive'else'pair'];p=j['payload']
 if track=='comprehensive':return dict(version=p.get('method_version'),primary=p.get('primary'),wdl=p.get('wdl'),line=p.get('total_line'),direction=p.get('total_direction'))
 m=p[track];t=m.get('total');line=t['quote']['line']if t else None;d=t['reference_direction']if t else None
 if r['batch']=='day':
  ref=r['comprehensive']['payload']['derived_direction_reference'];p=B/'day/WCPP/forecasts/issued-analyses'/pathlib.Path(ref['path']).parent.name/pathlib.Path(ref['path']).name
  derived=json.load(open(p))['payload'];line=derived['quote']['line'];d=derived[track]['direction']
 return dict(version=m['version'],primary=m.get('primary'),wdl=m.get('wdl_reference'),line=line,direction=d)

def evalrows(rr):
 out=[]
 for r in rr:
  f=r['pair']['fixture'];s=sm[str(f['source_ids']['espn'])];raw=json.load(open(s['raw_path']));c=raw['header']['competitions'][0];teams={x['homeAway']:x for x in c['competitors']}
  assert c['status']['type']['name']=='STATUS_FULL_TIME' and c['status']['type']['completed']
  assert c['date'][:16]==f['kickoff_at'][:16],(c['date'],f['kickoff_at'])
  for side in ['home','away']:assert teams[side]['id']==f[side].split(':')[-1]
  h,a=[int(teams[z]['score'])for z in ['home','away']];actual=f'{h}-{a}';wdl='主胜'if h>a else'客胜'if h<a else'平局'
  row=dict(batch=r['batch'],match_id=f['match_id'],home=f.get('display_home',f['home_name']),away=f.get('display_away',f['away_name']),score=actual,source_url=s['source_url'])
  for t in ['current_model','test_model','comprehensive']:
   z=normalize(r,t);z.update(primary_hit=z['primary']==actual if z['primary'] else None,wdl_hit=z['wdl']==wdl if z['wdl']in ['主胜','平局','客胜']else None,settlement=settle(h+a,z['line'],z['direction']));row[t]=z
  out.append(row)
 return out
out=evalrows(rows)
def summarize(rs):
 result={}
 for t in ['current_model','test_model','comprehensive']:
  groups=collections.defaultdict(list)
  for r in rs:groups[r[t]['version']].append(r[t])
  result[t]={}
  for ver,zs in groups.items():
   ps=[z for z in zs if z['primary_hit']is not None];ws=[z for z in zs if z['wdl_hit']is not None];ts=[z for z in zs if z['settlement']is not None]
   result[t][ver]=dict(scope=len(zs),primary_hits=sum(z['primary_hit']for z in ps),primary_n=len(ps),wdl_hits=sum(z['wdl_hit']for z in ws),wdl_n=len(ws),totals=dict(collections.Counter(z['settlement']for z in ts)),total_n=len(ts))
 return result
summary={batch:summarize([r for r in out if r['batch']==batch])for batch in ['night','revision','day']}
# Project paired reviewer independently verifies matrices, timing, identical inputs and score accounting.
paired={}
for batch in ['night','revision','day']:
 rr=[r for r in rows if r['batch']==batch];pairs=[copy.deepcopy(r['pair']['payload'])for r in rr];res=[]
 for r,p in zip(rr,pairs):
  f=r['pair']['fixture'];s=sm[str(f['source_ids']['espn'])]
  for t in ['current_model','test_model']:p[t].setdefault('total',None)
  res.append(dict(match_id=f['match_id'],home_goals=s['home_score'],away_goals=s['away_score'],score_basis='regulation_90',observed_at=s['query_time_utc'],source_url=s['source_url']))
 try:paired[batch]=review(pairs,res)
 except Exception as e:paired[batch]={'validation_error':str(e)}
# Earliest model forecast remains the first-prematch comparison, never replaced by Nov 8 revision.
first=json.load(open(B/'earliest-pairs.json'));fr=[]
for r,j in zip([r for r in rows if r['batch']=='night'],first):
 q=copy.deepcopy(r);q['pair']=j;q['pair']['fixture']=r['pair']['fixture'];fr.append(q)
firstout=evalrows(fr);summary['earliest_model_baseline_same_46']=summarize(firstout)
(B/'settled-rows.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));(B/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));(B/'paired-review.json').write_text(json.dumps(paired,ensure_ascii=False,indent=2));(B/'earliest-settled.json').write_text(json.dumps(firstout,ensure_ascii=False,indent=2))
with open(B/'逐场复盘.csv','w',encoding='utf-8-sig',newline='')as f:
 fields=['批次','比赛','赛果','轨道','版本','第一比分','比分命中','胜平负','方向命中','盘口','大小方向','大小结算','赛果来源'];w=csv.writer(f);w.writerow(fields)
 for r in out:
  for t in ['current_model','test_model','comprehensive']:
   z=r[t];w.writerow([r['batch'],r['home']+'—'+r['away'],r['score'],t,z['version'],z['primary'],z['primary_hit'],z['wdl'],z['wdl_hit'],z['line'],z['direction'],z['settlement'],r['source_url']])
print(json.dumps(summary,ensure_ascii=False,indent=2));print('paired validation', {k:v.get('validation_error','PASS')for k,v in paired.items()})
