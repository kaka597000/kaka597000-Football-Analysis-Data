import json,sys
from pathlib import Path
sys.path[:0]=['/workspace/Football-Analysis/runtime','/workspace/Football-Analysis/runtime/v5']
from paired_review import review
from research.analysis_freeze import verify,save
root=Path(__file__).parent
src=Path('/workspace/WCPP/reports/jingcai-refresh-20261102-1925')
rows=json.loads((src/'summary.json').read_text());results=json.loads((root/'results/results.json').read_text());rm={r['竞彩ID']:r for r in results}
for r in results:
 if r['status']=='completed': r['match_id']='espn:'+r['espn_event_id']
valid=[r for r in results if r['status']=='completed'];pairs=[];firstpairs=[];out=[];receipts=[]
for r in rows:
 n=r['lottery_no'][-3:];record=verify(json.loads(Path(r['comprehensive_receipt']['path']).read_text()));first=verify(json.loads((Path(r['comprehensive_receipt']['path']).parent/'000001.json').read_text()));actual=rm[r['lottery_no']]
 item={k:r[k] for k in ('lottery_no','home','away','primary','wdl','line','total_direction')};item['result']=actual['比分'];item['first']={k:first['payload'].get(k) for k in ('primary','wdl','total_direction','total_line')}
 if actual['status']=='completed':
  h,a=actual['home_goals'],actual['away_goals'];wdl='主胜' if h>a else '客胜' if h<a else '平局'
  item['primary_hit']=None if not r['primary'] else r['primary']==actual['比分'];item['wdl_hit']=None if not r['wdl'] else r['wdl']==wdl
  item['first']['primary_hit']=None if not item['first']['primary'] else item['first']['primary']==actual['比分'];item['first']['wdl_hit']=None if not item['first']['wdl'] else item['first']['wdl']==wdl
  if r['total_direction']:
   from weighted_model import legacy
   import numpy as np
   point=np.zeros((51,51));point[h,a]=1
   item['total_settlement']=next(k for k,v in legacy.total_settlement(point,r['line'],'under' if r['total_direction']=='小' else 'over').items() if v==1)
  receipts.append(save({'source':actual,'first_prematch':first['freeze_id'],'revision':record['freeze_id'],'settlement':item},record['fixture'],stage='review',track='comprehensive'))
 out.append(item)
 p=src/f'{n}-unified.json'
 if p.exists():
  bundle=json.loads(p.read_text());pair=bundle['current_test_pair'];pairs.append(pair)
  folder=Path(bundle['paired_receipt']['path']).parent
  firstpairs.append(verify(json.loads((folder/'000001.json').read_text()))['payload'])
report={'rows':out,'first_pairs':review(firstpairs,valid),'revision_pairs':review(pairs,valid),'receipts':receipts,'notes':['001未匹配不结算；005未提供模型预测','首次赛前版本为主评价；晚间更新单列','大小球五类结算独立；观望不得补算','不重新训练、不改参数、不择优']}
(root/'review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
lines=['# 2026-11-02竞彩复盘','','首次赛前版本为主评价；20:40更新单列。001身份未匹配不结算。','','|编号|比赛|赛果|首次综合比分|晚间综合比分|晚间大小球|','|---|---|---|---|---|---|']
for r in out: lines.append(f"|{r['lottery_no']}|{r['home']}—{r['away']}|{r['result'] or '未核实'}|{r['first']['primary'] or '待定'}|{r['primary'] or '待定'}|{str(r['line'])+r['total_direction']+' '+r.get('total_settlement','') if r['total_direction'] else '观望'}|")
lines+=['','综合首次/晚间比分均0/6，覆盖6/9；胜平负均1/6。首次大小球全部观望，晚间2项：盖斯小2.75半输、本菲卡小3.75全赢。','本菲卡为唯一优先项，综合2-1未中，主胜和晚间小3.75命中；原模型2-0也未中，不能称改分改善。','纽卡2-1改1-1均未中，方向均错；布拉干2-2与原模型1-1均未中。','诊断：多场1-1的判断未覆盖实际胜负分化，萨索洛2-4显示高失球反证重要；但本菲卡1-0、纽卡0-1又不支持统一加球。应在完整时间隔离样本中比较零/一/两球路径、训练鲜度与人工改分净收益；本批不能证明因果或调整权重有效。','模型逐版本统计及冻结回执详见review.json。来源为results/中逐场ESPN summary与scoreboard；同一提供商的两端点核对，不算独立来源。']
(root/'复盘.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({k:report[k]['models'] for k in ('first_pairs','revision_pairs')},ensure_ascii=False))
