# Independent football-data historical intake (2015/16–2018/19)

This is an isolated archival collection for six leagues: E0, SP1, D1, I1, F1, N1. Split roles are 1516/1617 `train`, 1718 `weight_selection`, and 1819 `test`. It is data intake only; no model training or performance review is part of this artifact.

## Outputs

- `panels/{competition}.jsonl`: every row with valid date, home/away identity, nonnegative integer FTHG/FTAG and consistent FTR (regular-time full-time outcome); missing/invalid HST or AST never removes a result row.
- `process.jsonl`: strict subset requiring both HST and AST to be finite nonnegative integers. When HS/AS are present and parseable they also bound the corresponding SOT. Goals exceeding SOT are retained and flagged; no shot estimate is made. Every row carries original physical CSV line number and source SHA-256.
- `raw/*.csv`, sidecar `*.receipt.json`, and `raw/receipts.json`: official source bytes, retrieval time in Beijing (UTC+8), URL, response status, byte count, hash and header.
- `reconciliation.json`: per source file, row counts, excluded result rows, field availability and explicit quality issues. `season-reconciliation.json`: per season and competition `result_rows` / `process_rows`.
- `coverage.json`: season level panel, process and historical odds availability.

## Odds selection

For totals, use a complete `B365>2.5` + `B365<2.5` pair when the official source header provides those fields and values exist. Otherwise preserve the source `BbAv>2.5` + `BbAv<2.5` pair as a clearly labelled cross-book average. Bet365 1X2 is stored as a complete H/D/A set only. `paired_market` is true only when complete Bet365 1X2 and Bet365 totals are both present; aggregate average totals are never labelled same-book. Prices are archival observations without a quote clock.

## Reproduce

Run `python collect.py`. Verified raw files with matching receipt hashes are replayed from cache; damaged/missing cache files are fetched from the official football-data.co.uk URL embedded in the script. The script rewrites panels, process, receipts index and reconciliation outputs deterministically except original retrieval timestamps when a fetch is needed.
