#!/usr/bin/env python3
"""Independent football-data.co.uk six-league 2015/16–2018/19 historical intake; deterministic cached replay."""
import csv, datetime as dt, hashlib, io, json, pathlib, time, urllib.request, urllib.error, math, unicodedata
ROOT=pathlib.Path(__file__).resolve().parent
LEAGUES={'eng.1':'E0','esp.1':'SP1','ger.1':'D1','ita.1':'I1','fra.1':'F1','ned.1':'N1'}
SEASONS={'1516':'train','1617':'train','1718':'weight_selection','1819':'test'}
BASE='https://www.football-data.co.uk/mmz4281/{season}/{div}.csv'
def sha(b): return hashlib.sha256(b).hexdigest()
def stamp(): return dt.datetime.now(dt.timezone(dt.timedelta(hours=8))).isoformat(timespec='seconds')
def odds(v):
 try:
  x=float(v.strip()); return x if math.isfinite(x) and x>1 else None
 except (ValueError,AttributeError): return None
def pair(row,a,b):
 x,y=odds(row.get(a)),odds(row.get(b)); return (x,y) if x is not None and y is not None else None
def get(season,div):
 url=BASE.format(season=season,div=div); p=ROOT/'raw'/f'{season}-{div}.csv'; rp=p.with_suffix('.receipt.json'); p.parent.mkdir(parents=True,exist_ok=True)
 if p.exists() and rp.exists():
  b=p.read_bytes(); r=json.loads(rp.read_text())
  if sha(b)==r.get('sha256') and r.get('http_status')==200: return url,b,r
 req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 (compatible; independent historical data capture)'})
 try:
  with urllib.request.urlopen(req,timeout=60) as res: b=res.read(); status=res.status; final=res.geturl()
 except urllib.error.HTTPError as e: b=e.read(); status=e.code; final=e.geturl()
 except Exception as e: raise RuntimeError(f'{url}: {type(e).__name__}: {e}')
 try: txt=b.decode('utf-8-sig'); enc='utf-8-sig-strict'
 except UnicodeDecodeError: txt=b.decode('cp1252'); enc='cp1252-strict'
 r={'url':url,'final_url':final,'retrieved_at_beijing':stamp(),'http_status':status,'size_bytes':len(b),'sha256':sha(b),'decode':enc,'source_header':next(csv.reader(io.StringIO(txt)),[])}
 if status!=200: (ROOT/'raw'/f'{season}-{div}.http-error.body').write_bytes(b); rp.write_text(json.dumps(r,ensure_ascii=False,indent=2)); return url,None,r
 p.write_bytes(b); rp.write_text(json.dumps(r,ensure_ascii=False,indent=2)); return url,b,r
def team_code(s): return 'fdteam:'+hashlib.sha256(unicodedata.normalize('NFC',s.strip()).casefold().encode()).hexdigest()[:16]
def parse(body,season,comp,url,digest):
 try: txt=body.decode('utf-8-sig')
 except UnicodeDecodeError: txt=body.decode('cp1252')
 rd=csv.DictReader(io.StringIO(txt)); panel=[]; process=[]; rejected=[]; issues=[]; nonempty={k:0 for k in ['B365H','B365D','B365A','B365>2.5','B365<2.5','BbAv>2.5','BbAv<2.5']}; source_rows=0
 for row in rd:
  line=rd.line_num; source_rows+=1
  for k in nonempty:
   if (row.get(k) or '').strip(): nonempty[k]+=1
  date=(row.get('Date') or '').strip(); parsed=None
  for fmt in ('%d/%m/%Y','%d/%m/%y'):
   try: parsed=dt.datetime.strptime(date,fmt).date(); break
   except ValueError: pass
  if parsed is None:
   try: parsed=dt.date.fromisoformat(date)
   except ValueError: rejected.append({'row':line,'reason':'invalid_date','date':date}); continue
  home=(row.get('HomeTeam') or '').strip(); away=(row.get('AwayTeam') or '').strip()
  if not home or not away: rejected.append({'row':line,'reason':'missing_team','home':home,'away':away}); continue
  # Panel qualification depends only on a credible full-time result, never on shot statistics.
  try: hg,ag=int(row['FTHG']),int(row['FTAG'])
  except (ValueError,TypeError,KeyError): rejected.append({'row':line,'reason':'missing_or_noninteger_full_time_score','date':date,'home':home,'away':away,'FTHG':row.get('FTHG'),'FTAG':row.get('FTAG')}); continue
  if hg<0 or ag<0: rejected.append({'row':line,'reason':'negative_full_time_score','FTHG':hg,'FTAG':ag}); continue
  ftr=(row.get('FTR') or '').strip(); exp='H' if hg>ag else 'A' if hg<ag else 'D'
  if ftr!=exp: issues.append({'row':line,'reason':'FTR_score_disagreement','FTR':ftr,'expected':exp})
  hs=ats=None
  try:
   hs,ats=int(row.get('HST','')),int(row.get('AST',''))
   if hs<0 or ats<0: raise ValueError
  except (ValueError,TypeError): hs=ats=None
  sh=sa=None
  try: sh,sa=int(row.get('HS','')),int(row.get('AS',''))
  except (ValueError,TypeError): pass
  if hs is not None and sh is not None and (sh<0 or hs>sh): issues.append({'row':line,'reason':'home_sot_exceeds_shots_or_invalid','HS':row.get('HS'),'HST':row.get('HST')})
  if ats is not None and sa is not None and (sa<0 or ats>sa): issues.append({'row':line,'reason':'away_sot_exceeds_shots_or_invalid','AS':row.get('AS'),'AST':row.get('AST')})
  if hs is not None and hs<hg: issues.append({'row':line,'reason':'home_goals_exceed_sot_preserved','FTHG':hg,'HST':hs})
  if ats is not None and ats<ag: issues.append({'row':line,'reason':'away_goals_exceed_sot_preserved','FTAG':ag,'AST':ats})
  hpair=pair(row,'B365H','B365D'); ba=odds(row.get('B365A')); h2h={'home':hpair[0],'draw':hpair[1],'away':ba} if hpair and ba else None
  p=pair(row,'B365>2.5','B365<2.5'); total={'line':2.5,'over':p[0],'under':p[1],'bookmaker':'Bet365','price_pair_basis':'same_book','method':'archived_historical_price_observation_proxy','observation_type':'historical_price_observation_proxy'} if p else None
  if not p:
   p=pair(row,'BbAv>2.5','BbAv<2.5')
   if p: total={'line':2.5,'over':p[0],'under':p[1],'bookmaker':'multiple_bookmaker_average','price_pair_basis':'cross_book','method':'cross_book_average_historical_price_proxy','observation_type':'historical_price_observation_proxy'}
  codeh,codea=team_code(home),team_code(away); mid=hashlib.sha256(('football-data|'+comp+'|'+parsed.isoformat()+'|'+codeh+'|'+codea).encode()).hexdigest()[:24]
  panel.append({'id':'football-data:'+mid,'competition':comp,'season':season,'independent_split_role':SEASONS[season],'date':parsed.isoformat(),'stage':'regular','source_stage':'regular','leg':None,'neutral':False,'home':home,'away':away,'home_team_code':codeh,'away_team_code':codea,'home_goals':hg,'away_goals':ag,'score_basis':'regulation_90','h2h':h2h,'bookmaker':'Bet365' if h2h else None,'total':total,'paired_market':bool(h2h and total and total['price_pair_basis']=='same_book'),'market_time_basis':'archived_historical_price_observation_proxy_no_quote_clock','source_sha256':digest,'sources':[{'row':line,'sha256':digest,'url':url}]})
  # Process output is a strict subset with valid, finite nonnegative integer SOT; HS/AS bounds apply when present.
  if hs is not None and ats is not None and not (sh is not None and sh>=0 and hs>sh) and not (sa is not None and sa>=0 and ats>sa):
   process.append({'id':'football-data:'+mid,'competition':comp,'date':parsed.isoformat(),'home':home,'away':away,'home_sot':hs,'away_sot':ats,'source_sha256':digest,'source_row':line})
 return panel,process,{'source_rows':source_rows,'result_rows':len(panel),'qualified_matches':len(panel),'process_rows':len(process),'rejected_rows':rejected,'issues':issues,'odds_field_nonempty_rows':nonempty}
def main():
 panels={c:[] for c in LEAGUES}; proc=[]; receipts=[]; recon={}
 for season,role in SEASONS.items():
  for comp,div in LEAGUES.items():
   url,b,r=get(season,div); receipts.append({'season':season,'role':role,'competition':comp,'division':div,**r})
   if b is None: recon[f'{season}-{div}']={'season':season,'role':role,'http_status':r['http_status'],'panel_rows_added':0}; continue
   ps,pr,a=parse(b,season,comp,url,sha(b)); panels[comp]+=ps; proc+=pr; recon[f'{season}-{div}']={'season':season,'role':role,'competition':comp,'division':div,'source_sha256':sha(b),'size_bytes':len(b),**a,'panel_rows_added':len(ps)}; time.sleep(.2)
 out=ROOT/'panels'; out.mkdir(exist_ok=True)
 for c,rows in panels.items():
  rows.sort(key=lambda x:(x['date'],x['home'],x['away'])); (out/f'{c}.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n' for x in rows))
 proc.sort(key=lambda x:(x['date'],x['competition'],x['home'],x['away'])); (ROOT/'process.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n' for x in proc))
 (ROOT/'raw'/'receipts.json').write_text(json.dumps(receipts,ensure_ascii=False,indent=2)); (ROOT/'reconciliation.json').write_text(json.dumps(recon,ensure_ascii=False,indent=2))
 cov={}; byseason={}
 for s,role in SEASONS.items():
  xs=[p for rows in panels.values() for p in rows if p['season']==s]
  season={'role':role,'result_rows':len(xs),'process_rows':sum(1 for x in proc if x['id'] in {p['id'] for p in xs}),'bet365_1x2_complete':sum(x['h2h'] is not None for x in xs),'over_under_2_5_complete':sum(x['total'] is not None for x in xs),'bet365_same_book_pair':sum(x['paired_market'] for x in xs),'cross_book_average_total':sum(x['total'] is not None and x['total']['price_pair_basis']=='cross_book' for x in xs)}
  cov[s]=season; byseason[s]={}
  for comp,rows in panels.items():
   part=[x for x in rows if x['season']==s]
   byseason[s][comp]={'result_rows':len(part),'process_rows':sum(1 for x in proc if x['id'] in {p['id'] for p in part}),'bet365_1x2_complete':sum(x['h2h'] is not None for x in part),'over_under_2_5_complete':sum(x['total'] is not None for x in part),'bet365_same_book_pair':sum(x['paired_market'] for x in part),'cross_book_average_total':sum(x['total'] is not None and x['total']['price_pair_basis']=='cross_book' for x in part),'result_excluded_rows':len(recon[f'{s}-{LEAGUES[comp]}'].get('rejected_rows',[]))}
 (ROOT/'season-reconciliation.json').write_text(json.dumps(byseason,ensure_ascii=False,indent=2))
 (ROOT/'coverage.json').write_text(json.dumps(cov,ensure_ascii=False,indent=2))
if __name__=='__main__': main()
