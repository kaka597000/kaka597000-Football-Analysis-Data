import json,sqlite3,re,hashlib
from pathlib import Path
R=Path('/workspace/scratch/r10-shot-supplement'); U=json.loads((R/'baseline-panel-r6-audit.json').read_text())['unresolved_matches']
def norm(s):return re.sub('[^a-z0-9]','',s.casefold())
def connect(p):return sqlite3.connect('file:'+p+'?mode=ro',uri=True)
def tables(c):
 out={}
 for (t,) in c.execute("select name from sqlite_master where type='table'"):
  out[t]={'columns':[x[1] for x in c.execute(f'pragma table_info("{t}")')],'rows':c.execute(f'select count(*) from "{t}"').fetchone()[0]}
 return out
def jleague():
 paths=list(Path('/workspace/WCPP/data/jleague-cup').glob('*.sqlite')); results=[]; rows=[x for x in U if x['competition']=='jpn.league_cup']
 for p in paths:
  c=connect(str(p)); info=tables(c); hits=[]
  if 'matches' in info and 'teams' in info:
   team={a:b for a,b in c.execute('select team_id,name from teams')}
   for m in c.execute('select * from matches'):
    d=dict(zip([x[1] for x in c.execute('pragma table_info(matches)')],m))
    hn=team.get(d.get('home_id'),d.get('home_id','')); an=team.get(d.get('away_id'),d.get('away_id',''))
    for x in rows:
     if d.get('date')==x['date'] and norm(hn)==norm(x['home']) and norm(an)==norm(x['away']):
      hits.append({'id':x['id'],'match_id':d.get('match_id'),'date':d.get('date'),'home':hn,'away':an,'regulation_verified':d.get('regulation_verified'),'stage':d.get('stage'),'payload_has_sot':bool(re.search('shots.?on.?target|shotsOnTarget|射正',str(d.get('payload_json','')),re.I))})
  results.append({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'tables':info,'exact_identity_date_hits':hits})
  c.close()
 (R/'jleague-db-audit.json').write_text(json.dumps({'candidate_count':len(rows),'databases':results},ensure_ascii=False,indent=2)+'\n')
def aus():
 p='/workspace/WCPP/reports/aus-expert-20261016/dataset-boundary-refit-v1/research.sqlite';c=connect(p);info=tables(c); rows=[x for x in U if x['competition']=='aus.1']; hits=[]
 for match_id,cohort,date,season,home,away,payload in c.execute('select * from fixtures'):
  try:d=json.loads(payload)
  except: d={}
  hn=d.get('home_name',home);an=d.get('away_name',away)
  for x in rows:
   if date==x['date'] and norm(hn)==norm(x['home']) and norm(an)==norm(x['away']):
    hits.append({'id':x['id'],'fixture_match_id':match_id,'date':date,'home':hn,'away':an,'score_basis':d.get('score_basis'),'payload_has_sot':bool(re.search('shots.?on.?target|shotsOnTarget',payload,re.I))})
 report={'path':p,'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest(),'tables':info,'candidate_count':len(rows),'exact_identity_date_hits':hits,'facts_rows':info['facts']['rows']}
 (R/'aus-db-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');c.close()
def unified():
 p='/workspace/WCPP/data/unified/WCPP_统一赛事库.sqlite';c=connect(p);info=tables(c); rows=[x for x in U if x['competition'] in ('uefa.nations','aus.1','jpn.league_cup')]; hits=[]
 # training_90 exposes team labels; join observations on exact competition/date + normalized names.
 for x in rows:
  q="select m.match_id,m.competition,m.date,m.home,m.away,m.status,m.h90,m.a90,m.evidence_count from training_90 m where m.competition=? and m.date=?"
  cand=c.execute(q,(x['competition'],x['date'])).fetchall()
  for m in cand:
   if norm(m[3])==norm(x['home']) and norm(m[4])==norm(x['away']):
    obs=c.execute('select provider,raw_json,score_scope,extra_h,extra_a from observations where competition=? and date=? and home_id=(select home_id from matches where match_id=?) and away_id=(select away_id from matches where match_id=?)',(x['competition'],x['date'],m[0],m[0])).fetchall()
    keys=[]
    for o in obs:
     try:
      d=json.loads(o[1]); keys+= [k for k in d if re.search('shot|sot|target',k,re.I)]
     except:pass
    hits.append({'panel_id':x['id'],'match_id':m[0],'date':m[2],'home':m[3],'away':m[4],'status':m[5],'score_90':[m[6],m[7]],'evidence_count':m[8],'observation_count':len(obs),'sot_related_top_keys':sorted(set(keys))})
 report={'path':p,'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest(),'tables':info,'candidate_rows':len(rows),'exact_identity_date_hits':hits}
 (R/'unified-db-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');c.close()
if __name__=='__main__':jleague();aus();unified()
