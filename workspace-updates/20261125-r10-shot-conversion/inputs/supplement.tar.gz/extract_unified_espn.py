import json,sqlite3,re,hashlib
from pathlib import Path
R=Path('/workspace/scratch/r10-shot-supplement'); panel=json.loads((R/'baseline-panel-r6-audit.json').read_text())['unresolved_matches']; dbp='/workspace/WCPP/data/unified/WCPP_统一赛事库.sqlite'
def norm(s):return re.sub('[^a-z0-9]','',s.casefold())
def recursive(obj,path=''):
 if isinstance(obj,dict):
  for k,v in obj.items():
   p=f'{path}.{k}' if path else k
   if re.search(r'shotsOnTarget|shots_on_target|onTarget',k,re.I): yield p,v
   yield from recursive(v,p)
 elif isinstance(obj,list):
  for i,v in enumerate(obj):yield from recursive(v,f'{path}[{i}]')
c=sqlite3.connect('file:'+dbp+'?mode=ro',uri=True);c.row_factory=sqlite3.Row
bykey={x['id']:x for x in panel}; qual=[]; audit=[]
# source_key is exact provider event ID; join full summary observation to source manifest.
for r in c.execute("select o.*,s.path source_path,s.url source_url,s.sha256 source_sha,s.provider source_provider from observations o join sources s using(source_id) where o.provider='espn' and o.competition in ('aus.1','uefa.nations')"):
 p=bykey.get(r['source_key'])
 if not p:continue
 if r['date']!=p['date']:continue
 try:d=json.loads(r['raw_json'])
 except:continue
 comp=d.get('competition')
 if not isinstance(comp,dict): continue
 comps=comp.get('competitors',[])
 h=next((x for x in comps if x.get('homeAway')=='home'),{});a=next((x for x in comps if x.get('homeAway')=='away'),{})
 def name(x):
  t=x.get('team') or {}; return t.get('displayName') or t.get('name') or ''
 hn,an=name(h),name(a)
 if norm(hn)!=norm(p['home']) or norm(an)!=norm(p['away']):continue
 # ESPN scoreboard payload stores team statistics on competition.competitors.
 def sot(x):
  return next((z.get('displayValue') for z in x.get('statistics',[]) if z.get('name')=='shotsOnTarget'),None)
 hs=sot(h);asot=sot(a)
 status=((comp.get('status') or {}).get('type') or {}).get('name')
 # ESPN period 1/2 and exactly two linescore periods excludes ET/penalty periods.
 lp_h=h.get('linescores',[]);lp_a=a.get('linescores',[])
 period=(comp.get('status') or {}).get('period')
 normal=(status in ('STATUS_FULL_TIME','STATUS_FINAL') and period==2 and (not lp_h or len(lp_h)==2) and (not lp_a or len(lp_a)==2))
 found={'id':p['id'],'provider_event_id':r['source_key'],'source_path':r['source_path'],'source_url':r['source_url'],'source_sha256':r['source_sha'],'summary_date':r['date'],'summary_home':hn,'summary_away':an,'status':status,'period':period,'home_linescore_periods':len(lp_h),'away_linescore_periods':len(lp_a),'home_sot':hs,'away_sot':asot,'regulation_90_check':normal}
 if hs is not None and asot is not None and normal:
  q={'id':p['id'],'competition':p['competition'],'date':p['date'],'home':p['home'],'away':p['away'],'home_sot':int(hs),'away_sot':int(asot),'source_sha256':r['source_sha']}
  qual.append(q);audit.append(found)
  # Preserve original source bytes from the read-only WCPP raw path where available.
  rawdir=R/'raw'/'unified-espn';rawdir.mkdir(parents=True,exist_ok=True); out=rawdir/(p['id'].replace(':','_')+'.json')
  original=Path(r['source_path']) if r['source_path'] else None
  if original and original.is_file():out.write_bytes(original.read_bytes())
  else:out.write_bytes(r['raw_json'].encode())
  found['staged_payload']=str(out);found['staged_payload_sha256']=hashlib.sha256(out.read_bytes()).hexdigest()
  with open(R/'source-locations.jsonl','a') as f:f.write(json.dumps(found,ensure_ascii=False)+'\n')
 else:audit.append(found)
# Deduplicate by panel ID with precedence exact same raw summary; merge existing Nations/AUS rows.
old={}
for line in (R/'process.jsonl').read_text().splitlines():
 if line.strip():
  x=json.loads(line);old[x['id']]=x
for q in qual:old[q['id']]=q
(R/'process.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in sorted(old.values(),key=lambda x:(x['competition'],x['date'],x['id']))))
(R/'unified-espn-extraction-audit.json').write_text(json.dumps({'database':dbp,'database_sha256':hashlib.sha256(Path(dbp).read_bytes()).hexdigest(),'queried_provider_competitions':['aus.1','uefa.nations'],'exact_source_key_panel_links':len(audit),'qualified':len(qual),'records':audit},ensure_ascii=False,indent=2)+'\n')
print('linked',len(audit),'qualified',len(qual),'qualified by comp', {k:sum(1 for q in qual if q['competition']==k) for k in ['aus.1','uefa.nations']})
print('sample',qual[:3])
