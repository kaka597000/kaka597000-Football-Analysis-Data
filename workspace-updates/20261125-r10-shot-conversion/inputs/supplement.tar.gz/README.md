# R10 local SOT supplement

Local-only staging. No network requests were made. AFC Champions League was excluded as assigned; no Chinese sports lottery site or mirror was accessed. No repository files were edited.

## Results

`process.jsonl` contains 920 newly supported rows: 788 UEFA Nations League and 132 A-League rows. Each row has only `id,competition,date,home,away,home_sot,away_sot,source_sha256`. No R6 bilateral row was repeated. Values come from the named teams' ESPN `shotsOnTarget` statistics. No missing value was filled with zero.

`coverage-audit.json` retains the R8 panel/R6 join, excluded R6 rows, all unresolved identities, and the after-supplement remainder. The baseline contained 20,357 missing-panel candidates after excluding 17,615 R6 bilateral matches. The supplement resolved 920 and leaves 19,437 unresolved, including 1,172 AUS and 19 Nations fixtures.

## Database and source checks

- Nations SQLite: tables and columns, all table counts, exact event IDs, date and team direction are in `nations-db-audit.json`. Its 824 event rows and source records were queried read-only. Each accepted summary is hash-checked against `source_records`; ESPN Full Time plus exactly two home and away linescore periods establishes the regulation-time scope. `nations-source-conflicts.json` compares all available hash-valid local source records for accepted Nations matches: 86 matches had two sources and all paired SOT values agreed; no conflict was found.
- AUS research SQLite: schema/counts and exact date/team joins are in `aus-db-audit.json`. It has 2,807 fixtures and labels but zero facts; 258 candidates join to its fixtures, whose payload says `regulation_90`, but it has no SOT values. The 132 accepted AUS values came from ESPN cached summaries in the R8 archive index and unified-database ESPN observations, not from the score-only AUS SQLite.
- Unified SQLite: schema/counts and date/team joins are in `unified-db-audit.json`. ESPN raw JSON rows were scanned for nested `shotsOnTarget`. Exact event key, date, home and away were checked. Accepted rows require ESPN completed Full Time, period 2, and both team SOT values. Where a named research fixture existed, its `score_basis=regulation_90` was crosschecked. Duplicate annual summary records were retained once; distinct SOT values were not observed.
- J.League Cup SQLite files: schemas, row counts, identity/date match counts and source hashes are in `jleague-db-audit.json`. The match and observation payloads contain score/phase evidence but no SOT fields. No row was promoted from these databases.
- Cached ESPN index lookup: exact event IDs, source-index hash, archive/member locations, raw summary identity and regulation checks are in `espn-cache-aus-audit.json` and `unified-espn-extraction-audit.json`.

## Reproduction and retained evidence

Run `python extract_audit.py` to rescan the R8 panels, R6 replay, listed SQLite databases and available local ESPN archives, rebuild the process and audits, and package raw evidence. It makes no network requests. The component scripts show the exact read-only queries and joins.

`source-locations.jsonl` maps every accepted ID and source hash to `raw/by-sha256/<sha256>.json`, gives the originating local path or archive/member and source URL, and records the match identity and 90-minute check. The package stores each distinct raw response once. The R6 archive and panel source hashes are recorded in `baseline-panel-r6-audit.json`; database and source-index hashes are in `source-manifest.json`.

`database-reconciliation.json` is the compact per-database accounting. `nations-source-conflicts.json` preserves the duplicate-source comparison detail. All remaining candidates and missing-source cases remain listed in `coverage-audit.json`; no unresolved row is represented as zero.
