#!/usr/bin/env python3
"""Read-only inspection of named SQLite sources and exact local raw summaries."""
import json, sqlite3, hashlib, re, shutil
from pathlib import Path
ROOT=Path('/workspace/scratch/r10-shot-supplement'); AUD=ROOT/'baseline-panel-r6-audit.json'
AUDIT=json.loads(AUD.read_text()); UNRES=AUDIT['unresolved_matches']
def norm(s): return re.sub(r'[^a-z0-9]','',s.casefold())
def db(path): return sqlite3.connect('file:'+str(path)+'?mode=ro',uri=True)
def sha_bytes(b): return hashlib.sha256(b).hexdigest()
def stat_box(d):
 teams=d.get('boxscore',{}).get('teams',[]); out={}
 for team in teams:
  nm=team.get('team',{}).get('displayName') or team.get('team',{}).get('name')
  stats={x.get('name'):x.get('displayValue') for x in team.get('statistics',[])}
  out[nm]=stats.get('shotsOnTarget')
 return out

def nations():
 path=Path('/workspace/WCPP/research/nations-repair-20261116/database-v2/nations.sqlite'); c=db(path); c.row_factory=sqlite3.Row
 # Explicit table/column census and per-table counts.
 tables={r['name']:[x[1] for x in c.execute(f'pragma table_info("{r["name"]}")')] for r in c.execute("select name from sqlite_master where type='table'")}
 counts={t:c.execute(f'select count(*) from "{t}"').fetchone()[0] for t in tables}
 src={}
 for r in c.execute("select source_url,raw_path,raw_sha256,source_id,kind from source_records where kind='summary'"):
  m=re.search(r'event=([^&]+)',r['source_url'] or '')
  if m: src.setdefault(m.group(1),[]).append(dict(r))
 qualified=[]; miss=[]; reasons={}
 for p in (x for x in UNRES if x['competition']=='uefa.nations'):
  eventid=p['id'].split(':')[-1]; er=c.execute('select * from events where provider_event_id=? and competition=?',(eventid,'uefa.nations')).fetchone()
  options=src.get(eventid,[]); accepted=None; why='no_exact_event_or_raw_summary'
  if er and er['date']==p['date'] and options:
   for s in options:
    rawp=Path(s['raw_path'])
    if not rawp.is_file(): continue
    raw=rawp.read_bytes()
    if sha_bytes(raw)!=s['raw_sha256']: continue
    try: d=json.loads(raw)
    except Exception: continue
    hdr=d.get('header',{}); comp=(hdr.get('competitions') or [{}])[0]
    comps=comp.get('competitors',[]); h=next((x for x in comps if x.get('homeAway')=='home'),{}); a=next((x for x in comps if x.get('homeAway')=='away'),{})
    hn=(h.get('team') or {}).get('displayName',''); an=(a.get('team') or {}).get('displayName','')
    date=(comp.get('date') or '')[:10]; status=((comp.get('status') or {}).get('type') or {}).get('name')
    hs,asot=stat_box(d).get(hn),stat_box(d).get(an)
    lines_h=h.get('linescores',[]); lines_a=a.get('linescores',[])
    no_et=(len(lines_h)==2 and len(lines_a)==2 and status=='STATUS_FULL_TIME')
    ident=(date==p['date'] and norm(hn)==norm(p['home']) and norm(an)==norm(p['away']))
    if ident and no_et and hs is not None and asot is not None:
     accepted=(p,s,raw,hn,an,int(hs),int(asot),d);break
    why='identity_or_90min_or_sot_check_failed'
  if accepted:
   p,s,raw,hn,an,hs,asot,d=accepted
   out=ROOT/'raw'/'nations'/f'{eventid}.json';out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(raw)
   qualified.append({'id':p['id'],'competition':'uefa.nations','date':p['date'],'home':p['home'],'away':p['away'],'home_sot':hs,'away_sot':asot,'source_sha256':sha_bytes(raw)})
   info={'id':p['id'],'raw_path':str(out),'sha256':sha_bytes(raw),'original_raw_path':s['raw_path'],'original_source_id':s['source_id'],'url':s['source_url'],'event_key':er['event_key'],'summary_home':hn,'summary_away':an,'summary_date':(d['header']['competitions'][0]['date'])[:10],'status':'STATUS_FULL_TIME','home_linescores':len(next(x for x in d['header']['competitions'][0]['competitors'] if x['homeAway']=='home')['linescores']),'away_linescores':len(next(x for x in d['header']['competitions'][0]['competitors'] if x['homeAway']=='away')['linescores']),'regulation_basis':'two team linescore periods plus ESPN STATUS_FULL_TIME; Nations event row phase/stage and score_basis_evidence'}
   with open(ROOT/'source-locations.jsonl','a') as f:f.write(json.dumps(info,ensure_ascii=False)+'\n')
  else:
   reasons[why]=reasons.get(why,0)+1;miss.append(p)
 (ROOT/'process.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in qualified))
 report={'database':str(path),'tables_columns':tables,'table_counts':counts,'unresolved_candidates':sum(x['competition']=='uefa.nations' for x in UNRES),'qualified':len(qualified),'unresolved_after_check':len(miss),'reject_reasons':reasons,'qualified_rows':qualified,'unresolved_ids':[x['id'] for x in miss]}
 (ROOT/'nations-db-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 c.close();return report
if __name__=='__main__': print(json.dumps(nations(),ensure_ascii=False)[:5000])
