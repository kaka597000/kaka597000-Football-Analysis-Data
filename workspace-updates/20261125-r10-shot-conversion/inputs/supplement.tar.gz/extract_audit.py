#!/usr/bin/env python3
"""Rebuild local-only R10 SOT supplement from the named existing databases and caches."""
import shutil,subprocess,sys
from pathlib import Path
R=Path(__file__).resolve().parent
for name in ['process.jsonl','source-locations.jsonl']:
 p=R/name
 if p.exists():p.unlink()
for name in ['raw','nations-db-audit.json','aus-db-audit.json','unified-db-audit.json','jleague-db-audit.json','espn-cache-aus-audit.json','unified-espn-extraction-audit.json','nations-source-conflicts.json','database-reconciliation.json']:
 p=R/name
 if p.is_dir():shutil.rmtree(p)
 elif p.exists():p.unlink()
for script in ['baseline_scan.py','inspect_local_sources.py','audit_other_dbs.py','extract_cached_espn.py','extract_unified_espn.py','audit_nations_sources.py','finalize_audit.py']:
 print('RUN',script,flush=True)
 subprocess.run([sys.executable,str(R/script)],check=True)
