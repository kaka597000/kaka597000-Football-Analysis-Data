import json,re,hashlib,gzip,tarfile
from pathlib import Path
R=Path('/workspace/scratch/r10-shot-supplement'); unresolved=json.loads((R/'baseline-panel-r6-audit.json').read_text())['unresolved_matches']
idxp=Path('/workspace/scratch/r8-reference-20261125/prior/workspace-updates/20261123-all-scope-kpi/evidence/source-index.json'); idx=json.loads(idxp.read_text()); evdir=idxp.parent; MODELS=Path('/workspace/scratch/r8-reference-20261125/prior/workspace-updates/20261123-all-scope-kpi/models')
def norm(s):return re.sub('[^a-z0-9]','',s.casefold())
def stat(d):
 out={}
 for t in d.get('boxscore',{}).get('teams',[]):
  team=t.get('team') or {}; name=team.get('displayName') or team.get('name')
  out[name]={s.get('name'):s.get('displayValue') for s in t.get('statistics',[])}
 return out
def read_entry(v):
 if 'archive' not in v:return None
 with tarfile.open(evdir/v['archive'],'r') as tf:
  b=tf.extractfile(v['member']).read()
 if v['member'].endswith('.gz'):b=gzip.decompress(b)
 return b
qual=[]; fails=[]; checked=0
# Only prioritize AUS here; Nations rows separately use their database's explicitly indexed raw paths.
for p in (x for x in unresolved if x['competition']=='aus.1'):
 eid=p['id'].split(':')[-1]; found=[]
 for digest,v in idx.items():
  if any(f'event={eid}' in u for u in v.get('sources',[])):
   found.append((digest,v))
 if not found: continue
 for digest,v in found:
  if 'archive' not in v: continue
  b=read_entry(v); checked+=1
  try:d=json.loads(b)
  except: continue
  hcomp=next((c for c in (d.get('header',{}).get('competitions') or [{}])[0].get('competitors',[]) if c.get('homeAway')=='home'),{})
  acomp=next((c for c in (d.get('header',{}).get('competitions') or [{}])[0].get('competitors',[]) if c.get('homeAway')=='away'),{})
  comp=(d.get('header',{}).get('competitions') or [{}])[0]
  hn=(hcomp.get('team') or {}).get('displayName','');an=(acomp.get('team') or {}).get('displayName','');date=(comp.get('date') or '')[:10]
  status=((comp.get('status') or {}).get('type') or {}).get('name')
  hs=hcomp.get('linescores',[]); aas=acomp.get('linescores',[]); ss=stat(d)
  svh=ss.get(hn,{}).get('shotsOnTarget'); sva=ss.get(an,{}).get('shotsOnTarget')
  if date==p['date'] and norm(hn)==norm(p['home']) and norm(an)==norm(p['away']) and status=='STATUS_FULL_TIME' and len(hs)==2 and len(aas)==2 and svh is not None and sva is not None:
   rawdir=R/'raw'/'aus';rawdir.mkdir(parents=True,exist_ok=True);rawp=rawdir/f'{eid}.json';rawp.write_bytes(b); sh=hashlib.sha256(b).hexdigest()
   q={'id':p['id'],'competition':'aus.1','date':p['date'],'home':p['home'],'away':p['away'],'home_sot':int(svh),'away_sot':int(sva),'source_sha256':sh};qual.append(q)
   src={'id':p['id'],'source_sha256':sh,'raw_path':str(rawp),'index_digest':digest,'fixed_git_commit':v.get('commit'),'repository_path':v.get('repository_path'),'archive':v.get('archive'),'member':v.get('member'),'url':v.get('sources',[None])[0],'summary_home':hn,'summary_away':an,'summary_date':date,'status':status,'home_periods':len(hs),'away_periods':len(aas),'regulation_basis':'ESPN STATUS_FULL_TIME and exactly two team linescore periods; crosschecked AUS research.sqlite payload score_basis=regulation_90 where exact fixture match exists'}
   with open(R/'source-locations.jsonl','a') as f:f.write(json.dumps(src,ensure_ascii=False)+'\n')
   break
  else:fails.append({'id':p['id'],'found_index':True,'date':date,'home':hn,'away':an,'status':status,'home_periods':len(hs),'away_periods':len(aas),'home_sot':svh,'away_sot':sva})
# Merge with existing Nations process rows; exact same panel ids are disjoint.
proc=R/'process.jsonl'; old=[json.loads(x) for x in proc.read_text().splitlines() if x.strip()]; allrows=old+qual
proc.write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in allrows))
report={'cache_index':str(idxp),'cache_index_sha256':hashlib.sha256(idxp.read_bytes()).hexdigest(),'candidate_count':sum(x['competition']=='aus.1' for x in unresolved),'index_id_hits':len(set(x['id'] for x in fails)) + len(qual),'archive_records_read':checked,'qualified':len(qual),'qualified_rows':qual,'nonqualifying_found':fails}
(R/'espn-cache-aus-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('qualified_rows','nonqualifying_found')},ensure_ascii=False,indent=2))
