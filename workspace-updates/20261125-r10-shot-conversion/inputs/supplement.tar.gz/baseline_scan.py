#!/usr/bin/env python3
"""Reproduce R10 local-cache SOT coverage audit; performs no network access."""
import hashlib, json, tarfile
from pathlib import Path

ROOT=Path('/workspace/scratch/r10-shot-supplement')
MODELS=Path('/workspace/scratch/r8-reference-20261125/prior/workspace-updates/20261123-all-scope-kpi/models')
R6=Path('/workspace/kaka597000-Football-Analysis-Data/workspace-updates/20261123-score-gap-repair/inputs.tar.gz')

def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1<<20),b''): h.update(b)
 return h.hexdigest()

def main():
 replay={}
 with tarfile.open(R6,'r:gz') as tf:
  stream=tf.extractfile('inputs/replay-input.jsonl')
  for line in stream:
   r=json.loads(line); replay[r['id']]=r
 panels=[]; counts={}
 for arc in sorted(MODELS.glob('*.tar.gz')):
  comp=arc.name[:-7]
  if comp=='afc.champions': continue
  with tarfile.open(arc,'r:gz') as tf:
   for line in tf.extractfile('panel.jsonl'):
    p=json.loads(line); p['competition']=p.get('competition',comp); panels.append(p)
 matched=[]; missing=[]
 for p in panels:
  if 'home_sot' in p and 'away_sot' in p and p['home_sot'] is not None and p['away_sot'] is not None: continue
  r=replay.get(p['id'])
  if r and r.get('home_sot') is not None and r.get('away_sot') is not None:
   matched.append({'id':p['id'],'competition':p['competition'],'date':p.get('date'),'home':p.get('home'),'away':p.get('away'),'R6_pair':True})
  else: missing.append({'id':p['id'],'competition':p['competition'],'date':p.get('date'),'home':p.get('home'),'away':p.get('away'),'R6_pair':False})
 out={'panel_rows':len(panels),'competitions':sorted({p['competition'] for p in panels if p['competition']!='afc.champions'}),'R6_ids':len(replay),'panel_missing_sot':len(matched)+len(missing),'R6_bilateral_match_excluded':len(matched),'unresolved':len(missing),'process_rows':0,'unresolved_matches':missing,'R6_matched_excluded':matched,'sources':{'models_dir':str(MODELS),'R6_archive':str(R6),'R6_archive_sha256':sha(R6)}}
 (ROOT/'coverage-audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
 (ROOT/'baseline-panel-r6-audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
 (ROOT/'process.jsonl').write_text('')
 print(json.dumps({k:v for k,v in out.items() if k not in ('unresolved_matches','R6_matched_excluded')},ensure_ascii=False,indent=2))
if __name__=='__main__': main()
