#!/usr/bin/env python3
"""Compare every locally available hash-valid Nations summary source for accepted rows."""
import sqlite3,json,re,hashlib,unicodedata,collections
from pathlib import Path
R=Path(__file__).resolve().parent
rows=[json.loads(x) for x in (R/'process.jsonl').read_text().splitlines() if x.strip() and json.loads(x)['competition']=='uefa.nations']
def norm(s):return re.sub('[^a-z0-9]','',unicodedata.normalize('NFKD',s.casefold()).encode('ascii','ignore').decode())
c=sqlite3.connect('file:/workspace/WCPP/research/nations-repair-20261116/database-v2/nations.sqlite?mode=ro',uri=True);c.row_factory=sqlite3.Row
sources=list(map(dict,c.execute('select source_id,kind,source_url,raw_path,raw_sha256,raw_verified from source_records')))
conf=[];multi=[];counts=collections.Counter();valid_pairs=0
for p in rows:
 eid=p['id'].split(':')[-1]; vals=[]
 for s in sources:
  if not s['source_url'] or not re.search(r'[?&]event='+re.escape(eid)+r'(?:&|$)',s['source_url']):continue
  rawp=Path(s['raw_path'] or '')
  if not rawp.is_file():continue
  raw=rawp.read_bytes()
  if hashlib.sha256(raw).hexdigest()!=s['raw_sha256']:continue
  try:d=json.loads(raw)
  except Exception:continue
  comp=(d.get('header',{}).get('competitions') or [{}])[0]; status=((comp.get('status') or {}).get('type') or {}).get('name')
  teams=comp.get('competitors',[]);h=next((t for t in teams if t.get('homeAway')=='home'),{});a=next((t for t in teams if t.get('homeAway')=='away'),{})
  hn=(h.get('team') or {}).get('displayName','');an=(a.get('team') or {}).get('displayName','');box={}
  for t in d.get('boxscore',{}).get('teams',[]):
   tn=t.get('team') or {};nm=tn.get('displayName') or tn.get('name');box[nm]={z.get('name'):z.get('displayValue') for z in t.get('statistics',[])}
  hs=box.get(hn,{}).get('shotsOnTarget');asot=box.get(an,{}).get('shotsOnTarget')
  if comp.get('date','')[:10]==p['date'] and norm(hn)==norm(p['home']) and norm(an)==norm(p['away']) and hs is not None and asot is not None and status=='STATUS_FULL_TIME' and len(h.get('linescores',[]))==2 and len(a.get('linescores',[]))==2:
   vals.append({'pair':[int(hs),int(asot)],'source_id':s['source_id'],'kind':s['kind'],'sha256':s['raw_sha256'],'raw_path':s['raw_path']})
 counts[len(vals)]+=1;valid_pairs+=len(vals)
 if len(vals)>1:multi.append({'id':p['id'],'verified_source_count':len(vals),'distinct_pairs':sorted({tuple(x['pair']) for x in vals}),'sources':vals})
 pairs={tuple(x['pair']) for x in vals}
 if len(pairs)>1:conf.append({'id':p['id'],'sources':vals})
out={'database':'/workspace/WCPP/research/nations-repair-20261116/database-v2/nations.sqlite','accepted_rows_checked':len(rows),'valid_per_source_record_pairs':valid_pairs,'record_count_distribution':dict(counts),'multi_source_match_count':len(multi),'conflict_count':len(conf),'conflicts':conf,'multi_source_detail':multi}
(R/'nations-source-conflicts.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ('conflicts','multi_source_detail')},ensure_ascii=False))
