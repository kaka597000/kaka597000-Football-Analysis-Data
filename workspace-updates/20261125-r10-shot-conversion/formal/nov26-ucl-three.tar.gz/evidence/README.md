# R10 欧冠三场赛前证据包

- 采集目录：`/workspace/scratch/r10-ucl-three-evidence`。只读采集；未冻结/写入两仓。
- ESPN 当日 scoreboard 实际返回 9 场，均列在 `espn-nine-fixtures.csv`；北京时间均由 ESPN UTC 开球时间 +08:00 换算。
- R10 排名使用既有 `scratch/r10-forward-20261125` 冻结记录的 `quality.p_first`，只筛 ESPN scoreboard 这 9 个赛事 ID；排序完整见 `r10-nine-match-ranking.csv`。

## R10 前三（按冻结第一比分概率）

|名次|比赛|P(第一比分)|冻结第一比分|
|---:|---|---:|---|
|1|Shakhtar Donetsk vs Fenerbahce|11.6864%|1-1|
|2|Atlético Madrid vs Viking FK|10.4358%|3-0|
|3|Sporting CP vs Manchester United|10.3998%|1-1|

## 赛程、主客与场地核验

ESPN ID、主客、UTC/北京时间、场地与城市国家见 `espn-nine-fixtures.csv`。ESPN 对部分比赛未返回 `neutralSite` 字段，表内按 `not returned` 保留，不能从主队标记推定是否中立。Shakhtar vs Fenerbahce 的 ESPN 记录是 Shakhtar 主队、Stamford Bridge，伦敦、英格兰；这不是顿涅茨克主场。该场 ESPN 也未给 `neutralSite` 布尔值，主场异地已核实，官方中立场属性仍记未知。

## 三场双方近期过程数据

`fotmob-recent-30.csv` 按球队列出最近最多 5 场完赛比赛（共 30 行），含真实比赛日期、赛事、对手、主客与球队/对手射正及 xG；所有值取 FotMob All-period team stats，未合并加时。原始 matchDetails JSON 均保留。若响应没有 xG 或射正，直接标为 missing in response；不得以 0 代替。比赛名单按 FotMob 队伍 fixtures 中最新完赛 `FT` 条目选取。


### 已确认的过程数据缺项

|球队|日期（北京时间）|赛事|对手|主客|缺项|
|---|---|---|---|---|
|Shakhtar Donetsk|2026-11-21 00:00|Premier League|Liviy Bereh|Home|本队与对手 xG|
|Shakhtar Donetsk|2026-11-09 00:00|Premier League|Dynamo Kyiv|Home|本队与对手 xG|
|Shakhtar Donetsk|2026-10-31 00:00|Premier League|Obolon Kyiv|Home|本队与对手 xG|
|Shakhtar Donetsk|2026-10-28 00:00|Cup|Dynamo Kyiv|Home|本队与对手 xG；本队与对手射正|
|Sporting CP|2026-11-22 02:00|Taca de Portugal|União Serra|Home|本队与对手 xG；本队与对手射正|

## 首发、伤停与赔率

ESPN 赛前 summary 原始响应已保存。该响应中的 rosters 是空列表（0 人），故本次无法确认首发；没有取得可核实的伤停/停赛清单，空值不视作无人缺阵。FotMob 用 ESPN ID 请求 upcoming matchDetails 返回 `Data not found`，失败原件保留。

`espn-markets.csv` 仅保留同一 ESPN/DraftKings 提供源返回的 OU 与 WDL 报价字段；本次响应未带实际报价生成/更新时点，访问时间另列为抓取时点，不把抓取时点冒充报价时点。数值不应视作可确认的当前盘口。未拼接不同机构或不同时点。

## 原始记录与完整性

- 公开 GET 请求：50 次（预算上限 80）；HTTP 200：50 次。逐请求 URL、请求发起的实际 UTC 时间、状态、字节数和 SHA-256 在 `request-log.json`。
- 所有 JSON 原始响应位于 `raw/`；其中 FotMob `search/suggest`、球队 fixtures、单场详情及失败响应均保留。
- `manifest-sha256.csv` 为原件及交付表格的 SHA-256 清单。
- FotMob 今日赛程接口请求返回 0 场；作为真实覆盖缺项保留，没有将其当作无赛事证明。
- 来源：ESPN scoreboard/summary API、FotMob public API；未访问中国体彩或镜像，未用付费/新增账户。
