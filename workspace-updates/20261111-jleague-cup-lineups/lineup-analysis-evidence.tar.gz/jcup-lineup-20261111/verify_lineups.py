import json,re,html,hashlib,sys
from pathlib import Path
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from jleague_cup import quarterfinals as q
b=Path('/workspace/jcup-lineup-20261111');lineups=q.read(b/'staging/lineup-evidence.json')['matches'];old={x['fixture']['match_id']:x for x in q.read('/workspace/jcup-display-20261111/delivery-data.json')['matches']};cert=q.certificate('/workspace/jcup-qf-expansion-20261111/rules-certificate.json');sources={s['match_id']:s for s in q.read(b/'staging/sources.json')['sources'] if s.get('match_id')};out=[]
from datetime import datetime,timezone
for l in lineups:
 mid='jleague:'+l['official_match_id'];s=sources[mid];p=Path(l['raw_path']);assert hashlib.sha256(p.read_bytes()).hexdigest()==l['source_sha256']==s['sha256'];raw=p.read_text()
 t=re.sub(r'<(script|style)\b[^>]*>.*?</\1>','',raw,flags=re.S);t=html.unescape(re.sub('<[^>]+>',' ',t));t=re.sub(r'\s+',' ',t);start=t.index('GK',t.index('スターティングメンバー発表'));end=t.index('フォーメーション',start);segment=t[start:end]
 players=re.findall(r'(GK|DF|MF|FW)\s+(\d+)\s+(.*?)(?=\s+(?:GK|DF|MF|FW)\s+\d+|$)',segment);assert len(players)==22,(mid,len(players))
 for offset,side in enumerate(['home','away']):
  xi=l['starting_xi'][side];assert len(xi)==11 and len({x['position_number'] for x in xi})==11
  for v,(pos,num,name) in zip(xi,players[offset::2]):assert v['position']==pos and v['position_number']==num and re.sub(r'\s','',v['name_ja'])==re.sub(r'\s','',name)
 f=dict(old[mid]['fixture']);f['cutoff_at']=datetime.now(timezone.utc).isoformat();f['phase_evidence']={'raw_path':str(p),'raw_sha256':s['sha256'],'source_url':s['url'],'query_time':s['requested_at_utc_complete']};q.target_identity(f,cert);out.append(f)
(b/'verified-fixtures.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));(b/'lineup-validation.json').write_text(json.dumps({'same_event_verified':4,'official_starting_players_verified':88,'side_order_checked_against_visible_widget':True,'unique_jerseys_per_team':11,'formation_not_used_numerically':True},indent=2));print('Verified four event identities and 88 official starting players, including home/away mapping')
