from pathlib import Path
import json
from datetime import datetime
from zoneinfo import ZoneInfo
from types import SimpleNamespace
b=Path('/workspace/jcup-lineup-20261111')
q=SimpleNamespace(evidence=SimpleNamespace(aware=lambda s:datetime.fromisoformat(s.replace('Z','+00:00'))))
result=json.loads((b/'analysis.json').read_text())
ordered=sorted(result,key=lambda x:(x['fixture']['kickoff_at'],x['fixture']['match_id']))
batch=json.loads((b/'freeze-receipts.json').read_text())['batch']
lines=['# 日联杯首发公布后赛前更新','', '2026年11月11日，北京时间。八强首回合，仅90分钟；本次与早间首次预测、10:38修订分别评价。','', '|开球|对阵|综合第一比分|方向|实盘大小球|','|---|---|---|---|---|']
for r in ordered:
 f=r['fixture'];e=r['payload']['editorial'];kick=q.evidence.aware(f['kickoff_at']).astimezone(ZoneInfo('Asia/Shanghai')).strftime('%H:%M');lines.append(f"|{kick}|{e['match']}|{e['primary'] or '待定'}|{ {'平':'平局','负':'柏客胜'}.get(e['wdl'],'待定')}|观望|")
lines+=['','## 数值基准及边界','','活动current/test仍拒绝该队列。以下是独立八强研究候选，训练截止2025-09-03、首回合仅12场；均未训练阵容、xG及盘口系数。首发确认不改变矩阵；统计Top1四场均1–1，不等于综合推荐。区间是模型内等尾10%–90%分位数，非已验证真实覆盖。','', '|对阵/候选/球队|进球均值|中央80%区间及实际质量|0球|至少2球|至少3球|','|---|---|---|---|---|---|']
for r in ordered:
 for role in ['current','test']:
  for side,label in [('home','主'),('away','客')]:
   v=r['payload']['research_model_display'][role]['display_distribution'][side];lines.append(f"|{r['payload']['editorial']['match']}/{role}/{label}|{v['mean']:.2f}|{v['interval80'][0]}–{v['interval80'][1]} / {v['interval_mass']:.1%}|{v['p0']:.1%}|{v['p2plus']:.1%}|{v['p3plus']:.1%}|")
for r in ordered:
 p=r['payload'];e=p['editorial'];l=p['lineup'];lines+=['','## '+e['match'],'','[官方名单]('+l['source_url']+')；实际抓取时间见来源清单。']
 for side,name in [('home','主队'),('away','客队')]:
  lines+=['',name+'首发：'+'、'.join(v['position_number']+' '+v['name_ja'] for v in l['starting_xi'][side])+'。']
  sub=l['substitutes'].get(side)
  if isinstance(sub,dict):sub=sub.get('players',[]) if sub.get('status')=='VERIFIED' else []
  lines += ['',name+'替补：'+('、'.join((str(v.get('position_number',v.get('number','')))+' '+v.get('name_ja',v.get('name',''))) for v in sub)+'。' if sub else '尚未核实；未首发不能直接写成整场缺阵。')]
 for k in ['recent','evidence','path','selection','three_plus_path','risk']:lines+=['',e[k]]
 lines+=['','本场综合冻结：'+r['freeze_receipt']['freeze_id']+'；'+r['freeze_receipt']['recorded_at']+'。']
lines+=['','## 缺项与复盘','','近期战绩仍为J1近五轮，不是全赛事。近期xG/xGA未取得，单场射门不代替机会质量。伤停原因不从首发缺席倒推；实盘线/报价时间未核实，不自设大小球盘，不比较虚构水位。','', '合格TOP3：0场。四场完整保留：两场研究比分、两场待定；新旧版本分别结算，不能择优。','', '批次冻结ID：'+batch['freeze_id']+'；北京时间 '+batch['recorded_at']+'。']
(b/'analysis.md').write_text('\n'.join(lines)+'\n')
