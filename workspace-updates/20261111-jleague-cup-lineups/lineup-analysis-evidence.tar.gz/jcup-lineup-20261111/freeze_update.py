import sys,json,hashlib,copy
from pathlib import Path
from datetime import datetime,timezone
from zoneinfo import ZoneInfo
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from jleague_cup import quarterfinals as q
from research.analysis_freeze import save,verify
from prediction_service import run
b=Path('/workspace/jcup-lineup-20261111');old=q.read('/workspace/jcup-display-20261111/delivery-data.json');previous={d['fixture']['match_id']:d for d in old['matches']};ed=q.read(b/'editorial.json');ls=q.read(b/'staging/lineup-evidence.json');lmap={'jleague:'+d['official_match_id']:d for d in ls['matches']};sources=q.read(b/'staging/sources.json')
for s in sources['sources']:
 if s.get('raw_path'):assert q.evidence.sha(s['raw_path'])==s['sha256']
fixtures=q.read(b/'verified-fixtures.json')
for f in fixtures:f['cutoff_at']=datetime.now(timezone.utc).isoformat()
(b/'prediction-fixtures.json').write_text(json.dumps(fixtures,ensure_ascii=False,indent=2))
q.freeze_pairs('/workspace/jcup-qf-expansion-20261111/final-models/candidates.json',b/'prediction-fixtures.json',b/'research-freezes')
research={}
for p in (b/'research-freezes').glob('*.json'):
 d=q.read(p)
 if 'fixture' in d:research[d['fixture']['match_id']]=d
result=[]
for f in fixtures:
 mid=f['match_id'];prior=previous[mid];e=ed[mid];l=lmap[mid];f['cutoff_at']=datetime.now(timezone.utc).isoformat();af=copy.deepcopy(q.read('/workspace/jleague-cup-today-20261111/'+mid.replace(':','-')+'-model-status.json')['fixture']);af['cutoff_at']=f['cutoff_at']
 try:active=run(af)
 except ValueError as exc:
  assert str(exc)=='no validated identity/history model for this cohort'
  active={'match_id':mid,'status':'ABSTAIN_NO_ACTIVE_COHORT','reason':str(exc),'current_model':{'matrix':None,'status':'ABSTAIN_NO_ACTIVE_COHORT'},'test_model':{'matrix':None,'status':'ABSTAIN_NO_ACTIVE_COHORT'},'actual_entrypoint_attempt':'prediction_service.run','registry_sha256':q.evidence.sha('/workspace/WCPP/runtime/active-model.json')}
 ar=save(active,af,stage='prematch',track='current-test-pair');f['cutoff_at']=datetime.now(timezone.utc).isoformat()
 for role in ['current','test']:assert research[mid]['payload'][role]['matrix']==prior['models'][role]['matrix']
 payload={'version':'JCUP-LINEUP-REVIEW-20261111-v3','primary':e['primary'],'wdl':e['wdl'],'total_line':None,'total_direction':None,'current_test_reference':ar,'research_candidate_reference':research[mid]['freeze_receipt'],'previous_comprehensive_reference':prior['comprehensive_receipt'],'editorial':e,'lineup':l,'lineup_validation':q.read(b/'lineup-validation.json'),'source_manifest':sources,'previous_evidence_reference':'/workspace/jcup-display-20261111/delivery-data.json','previous_evidence_sha256':q.evidence.sha('/workspace/jcup-display-20261111/delivery-data.json'),'selection_evidence':{'compared_scores':e['compared_scores'],'zero_vs_one':e['zero_vs_one'],'three_plus_path':e['three_plus_path'],'total_reason':'No verified bookmaker line with source quote time; abstain','selection_reason':e['selection']},'research_model_display':prior['models'],'lineup_numeric_coefficients':'NOT_TRAINED','matrix_changed':False,'formal_acceptance_passed':False,'top3_eligible':False,'model_promotion':False,'xg_status':'NOT_OBTAINED; earlier coverage evidence preserved, no shooting-to-xG substitution','market_status':'NO_VERIFIED_CURRENT_LINE','revision_evaluation':'separate from first prematch; all four retained'}
 cr=save(payload,f,stage='prematch',track='comprehensive');result.append({'fixture':f,'payload':payload,'freeze_receipt':cr})
ordered=sorted(result,key=lambda x:(x['fixture']['kickoff_at'],x['fixture']['match_id']))
batch=save({'top3':[],'reason':'Active paired route unavailable; actual market lines unverified; independent research is not promotion','matches':[r['freeze_receipt'] for r in ordered]},dict(match_id='jleague-cup-20261111-batch',kickoff_at=min(f['kickoff_at'] for f in fixtures),cutoff_at=datetime.now(timezone.utc).isoformat()),stage='prematch',track='top3-selection')
refs=[batch]+[r['freeze_receipt'] for r in result]+[r['payload'][k] for r in result for k in ['current_test_reference','research_candidate_reference']]
for r in refs:assert verify(q.read(r['path']))['record_sha256']==r['sha256']
(b/'analysis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));(b/'freeze-receipts.json').write_text(json.dumps({'batch':batch,'records':refs},ensure_ascii=False,indent=2))
lines=['# 日联杯首发公布后赛前更新','', '2026年11月11日，北京时间。八强首回合，仅90分钟；本次与早间首次预测、10:38修订分别评价。','', '|开球|对阵|综合第一比分|方向|实盘大小球|','|---|---|---|---|---|']
for r in ordered:
 f=r['fixture'];e=r['payload']['editorial'];kick=q.evidence.aware(f['kickoff_at']).astimezone(ZoneInfo('Asia/Shanghai')).strftime('%H:%M');lines.append(f"|{kick}|{e['match']}|{e['primary'] or '待定'}|{ {'平':'平局','负':'柏客胜'}.get(e['wdl'],'待定')}|观望|")
lines+=['','## 数值基准及边界','','活动current/test仍拒绝该队列。以下是独立八强研究候选，训练截止2025-09-03、首回合仅12场；均未训练阵容、xG及盘口系数。首发确认不改变矩阵；统计Top1四场均1–1，不等于综合推荐。区间是模型内等尾10%–90%分位数，非已验证真实覆盖。','', '|对阵/候选/球队|进球均值|中央80%区间及实际质量|0球|至少2球|至少3球|','|---|---|---|---|---|---|']
for r in ordered:
 for role in ['current','test']:
  for side,label in [('home','主'),('away','客')]:
   v=r['payload']['research_model_display'][role]['display_distribution'][side];lines.append(f"|{r['payload']['editorial']['match']}/{role}/{label}|{v['mean']:.2f}|{v['interval80'][0]}–{v['interval80'][1]} / {v['interval_mass']:.1%}|{v['p0']:.1%}|{v['p2plus']:.1%}|{v['p3plus']:.1%}|")
for r in ordered:
 p=r['payload'];e=p['editorial'];l=p['lineup'];lines+=['','## '+e['match'],'','[官方名单]('+l['source_url']+')；实际抓取时间见来源清单。']
 for side,name in [('home','主队'),('away','客队')]:
  lines+=['',name+'首发：'+'、'.join(v['position_number']+' '+v['name_ja'] for v in l['starting_xi'][side])+'。']
  sub=l['substitutes'].get(side)
  if isinstance(sub,dict):sub=sub.get('players',[]) if sub.get('status')=='VERIFIED' else []
  lines += ['',name+'替补：'+('、'.join((str(v.get('position_number',v.get('number','')))+' '+v.get('name_ja',v.get('name',''))) for v in sub)+'。' if sub else '尚未核实；未首发不能直接写成整场缺阵。')]
 for k in ['recent','evidence','path','selection','three_plus_path','risk']:lines+=['',e[k]]
 lines+=['','本场综合冻结：'+r['freeze_receipt']['freeze_id']+'；'+r['freeze_receipt']['recorded_at']+'。']
lines+=['','## 缺项与复盘','','近期战绩仍为J1近五轮，不是全赛事。近期xG/xGA未取得，单场射门不代替机会质量。伤停原因不从首发缺席倒推；实盘线/报价时间未核实，不自设大小球盘，不比较虚构水位。','', '合格TOP3：0场。四场完整保留：两场研究比分、两场待定；新旧版本分别结算，不能择优。','', '批次冻结ID：'+batch['freeze_id']+'；北京时间 '+batch['recorded_at']+'。']
(b/'analysis.md').write_text('\n'.join(lines)+'\n');print(json.dumps({'batch':batch,'new_comprehensive_records':4,'verified_references':len(refs)},ensure_ascii=False))
