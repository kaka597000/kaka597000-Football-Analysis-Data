# 评估与分母修复验收（2026-11-12）

本批只修改评估代码，不训练、不重算赛前预测、不修改活动工件、参数、注册表或旧冻结。

## 修复内容

- 综合比较把矩阵众数与实际发布 Primary 分开；无活动路由且没有 version 的真实首版不再导致 KeyError。
- 概率评估新增 `frozen_wdl`，不从比分或矩阵众数补造发布方向；晋级预审比较实际冻结方向的同场命中和覆盖，缺失、方向退化、降低覆盖均阻挡。
- 复盘只接受显式 FT/completed；LIVE、延期、中断保持待结算，矛盾状态拒绝。显式 ABSTAIN/UNAVAILABLE 且没有任何推荐的空轨不会阻挡另一轨结算；双轨都缺输入时必须提供原冻结 fixture，不创造比赛时间或生成时间。
- 实际盘口结算复用既有 quote_audit，检查来源报价时点、抓取时点、冻结输入和输出相同盘口等；不合格只排除 OU，比分/WDL保留。五类结果完整列示，严格全赢率=全赢/(有效建议数−走盘)，半赢/半输留在分母。

## 真实数据复算

| 数据 | 结果 |
| --- | --- |
| 今晚欧国联8场首次综合冻结 | 修复前 KeyError('version')；修复后8场待结算、0完赛，无新增命中 |
| 既有欧洲10场综合 | 原标准化赛果缺状态；按原 SHA 重新核验保留 ESPN 原始 FT，另存标准化副本；前后综合命中均2/10 |
| 同批10场Current/Test | 9场有模型、1场无活动路由保留；9场有模型双方比分1/9、WDL5/9不变；Current OU五类3/1/0/1/4、Test2/1/0/1/5；这不是新的未见验证 |
| 现有未来注册队列 | 80场、26场FT、54场待结算；Current比分1/26、候选2/26；WDL14/26与13/26；实际OU均0，不支持晋级 |
| 366份首次模型pair | 每轨140份产生total，其中122缺合格报价时间；已核FT的120场中每轨67份total，49缺合格时间，18符合字段契约 |

18是每轨18个独立比赛，不是两轨计数相加。baseline旧OU表仅9场，原因是其统计脚本漏接受 `standard_total`，另9场被漏计；baseline另存对齐证据。字段契约合格不等于原始来源 as-of 已独立认证；正式未来队列OU仍为0。

`wdl-gate-regression.json`仅是合成软件回归：候选矩阵方向更好但发布方向从30中降到0中，旧门槛仍READY，新门槛BLOCKED。不得作为足球训练效果。

## 验证和部署边界

两组定向测试共68次执行、56个独立测试，均通过无跳过（promotion测试类被future测试导入，重复执行12项）。日志为 evaluation-tests.log 和 paired-review-tests.log。

已将真正的生产基线 `6639867d502a2dfe53a9a235c8761f8ee6b91533` 导出到独立沙盒，只覆盖 promotion_review.py 与 v2_test/evaluation.py，重新读取同一未来包：80/26/54不变，所有已结算队列输出frozen_wdl，所有晋级仍BLOCKED。见 base663-two-file-overlay-smoke.json。两文件不在该包锁定的 future_validation.py/challengers.py 清单内；这里完成兼容验收，不等同已经部署生产。

`recompute.py`只读本地原始文件，可复算欧国联、旧10场、未来80场；不调用采集、hydrate、capture、freeze或激活操作。报告中的旧归档路径须按原恢复清单准备。原始冻结哈希在 nations-before.json、historical-reverified-labels.json 和各报告中保留。
