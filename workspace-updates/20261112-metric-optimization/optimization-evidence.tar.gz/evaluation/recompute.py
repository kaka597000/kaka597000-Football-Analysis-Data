"""Read-only local evidence replay. Never fetches, predicts, freezes or activates."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

SOURCE=Path('/workspace/Football-Analysis')
OUT=Path(__file__).resolve().parent
sys.path[:0]=[str(SOURCE),str(SOURCE/'runtime'),str(SOURCE/'runtime/v5')]
from research_program.selection_review import compare
from research_program.replay import _finished_espn_label
from runtime.automation.prospective_cycle import check_bundle,_receipt,read
from research_program import future_validation

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write(name,value):(OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')

# Exact same eight first comprehensive records that reproduced KeyError('version').
nations=read('/workspace/WCPP/reports/nations-prematch-20261112-2135/analysis-records.json')
entries=[{'comprehensive':read(r['comprehensive_receipt']['path']),'pair':read(r['active_receipt']['path'])} for r in nations]
write('nations-after.json',compare(entries,[]))

# Old normalized labels lacked status. Re-derive FT only from their retained raw
# source bytes, preserving the original labels and their freeze records unchanged.
manifest=read('/workspace/WCPP/research/nine-items-20261105/prospective/selection-review-input-manifest.json')
records=[]
for item in manifest['sources']:
    assert sha(item['path'])==item['sha256']
    records.append(read(item['path']))
pairs={r['freeze_id']:r for r in records if r['track']=='current-test-pair'}
entries=[{'comprehensive':r,'pair':pairs[r['payload']['current_test_reference']['freeze_id']]} for r in records if r['track']=='comprehensive']
fixtures={r['comprehensive']['match_id']:r['comprehensive']['fixture'] for r in entries}
assert sha(manifest['result_source'])==manifest['result_source_sha256']
results=read(manifest['result_source']);normalized=[];labels=[]
for r in results:
    fixture=fixtures[r['match_id']]
    path=Path(manifest['result_source']).parent/'raw'/('espn-summary-'+r['match_id'].split(':')[1]+'.json')
    assert sha(path)==r['source_sha256']
    _finished_espn_label(dict(r,**{k:fixture[k] for k in ('cohort','kickoff_at','home','away')}),{'url':r['source_url']},path)
    normalized.append(dict(r,event_status='FT'))
    labels.append({'path':str(path),'sha256':sha(path),'status':'FT_VERIFIED_FROM_RETAINED_SOURCE'})
write('historical-reverified-labels.json',{'inputs':labels,'results':normalized,'original_normalized_file_sha256':sha(manifest['result_source'])})
spec=importlib.util.spec_from_file_location('before_selection',OUT/'before-selection_review.py');before=importlib.util.module_from_spec(spec);spec.loader.exec_module(before)
write('historical-before.json',before.compare(entries,normalized))
write('historical-after.json',compare(entries,normalized))
from paired_review import review as pair_review
all_pairs=[dict(entry['pair']['payload'],fixture=entry['pair']['fixture']) for entry in entries]
available=[p for p in all_pairs if all(p[k].get('matrix') is not None for k in ('current_model','test_model'))]
spec=importlib.util.spec_from_file_location('before_pair',OUT/'before-paired_review.py');before_pair=importlib.util.module_from_spec(spec);spec.loader.exec_module(before_pair)
write('actual-line-before-after.json',{'original_population':len(all_pairs),'forecast_available_population':len(available),
    'before_available_tracks':before_pair.review(available,normalized),'after_available_tracks':pair_review(available,normalized),
    'after_full_population':pair_review(all_pairs,normalized),
    'notice':'Unavailable first pairs remain in the full population. No historical prediction or fixture was synthesized.'})

# Same immutable prospective package; no cycle/hydrate/capture calls are made.
bundle=Path('/workspace/kaka597000-Football-Analysis-Data/future/bundle-v2');state=bundle.parent/'state'
m=check_bundle(bundle);extra=read(state/'state.json');plans=m['plans']['plans']+extra['plans'];packages=m['packages']+extra['packages'];results=read(state/'results.json')
reviews=[]
for receipt in plans:
    plan=read(_receipt(bundle,m,receipt)['path']);ids=set(plan['payload']['eligible_match_ids']);paired=[]
    for package in packages:
        if package['match_id'] in ids:
            p=copy.deepcopy(package)
            for role in ('current','candidate'):p[role+'_receipt']=_receipt(bundle,m,p[role+'_receipt'])
            paired.append(p)
    report=future_validation.review(plan,paired,[r for r in results if r['match_id'] in ids],state)
    reviews.append(dict(report,cohort=plan['payload']['cohort'],plan_record_sha256=plan['record_sha256']))
write('future-recomputed.json',{'bundle_sha256':m['manifest_sha256'],'result_file_sha256':sha(state/'results.json'),
    'population':sum(r['population'] for r in reviews),'completed':sum(r['completed'] for r in reviews),
    'pending':sum(len(r['pending_results']) for r in reviews),'cohort_reviews':reviews,'new_predictions':0,'network_calls':0,'activation_modified':False})
print(json.dumps({'nations_pending':len(nations),'historical_rows':len(entries),'future_population':sum(r['population'] for r in reviews),'future_completed':sum(r['completed'] for r in reviews)}))
