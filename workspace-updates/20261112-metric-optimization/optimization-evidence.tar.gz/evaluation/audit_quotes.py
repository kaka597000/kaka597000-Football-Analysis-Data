"""Read-only eligibility of the existing first-pair quote outputs."""
import collections,hashlib,json,sys
from pathlib import Path
sys.path[:0]=['/workspace/Football-Analysis/runtime','/workspace/Football-Analysis/runtime/v5']
from research.analysis_freeze import verify
from paired_review import _total_audit
out=Path(__file__).resolve().parent
source=out.parent/'baseline/first-pair-rows.json'
rows=json.loads(source.read_text());audits=[];counts=collections.defaultdict(collections.Counter)
for row in rows:
    record=verify(json.loads(Path(row['path']).read_text()))
    assert record['record_sha256']==row['record_sha256']
    models={}
    for name in ('current_model','test_model'):
        prediction=record['payload'][name];audit=_total_audit(prediction);has=bool(prediction.get('total'))
        models[name]={'has_frozen_total':has,**audit}
        scopes=('all_first_pairs',)+(('locally_verified_ft',) if row['actual']['status']=='LOCALLY_REVERIFIED_FT' else ())
        for scope in scopes:
            c=counts[scope+':'+name];c['population']+=1;c['has_frozen_total']+=has;c['eligible_actual_line']+=audit['eligible']
            if has and not audit['eligible']:
                c['ineligible_total']+=1
                for reason in audit['reasons']:c[reason]+=1
    audits.append({'match_id':record['match_id'],'record_sha256':record['record_sha256'],'source':row['path'],
                   'local_ft_verified':row['actual']['status']=='LOCALLY_REVERIFIED_FT','models':models})
result={'input_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'summary':dict(counts),'rows':audits,
        'notice':'Read-only quote eligibility audit; no outcome rates inferred for missing/unfinished results.'}
(out/'real-frozen-quote-eligibility.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
