# 本轮优化的只读基线（2026-11-12）

以 `summary-v2.json` 为完整输出，逐场证据在 `comprehensive-rows.json`、`first-pair-rows.json`、`actual-line-rows.json`。只读扫描两仓保留材料；没有查询外部足球数据，没有修改源码、模型、注册表或旧冻结。1273份已发布冻结均通过记录哈希检查。

本轮优先处理真实盘口前向覆盖、综合首版与数值模型同场增减、比分与胜平负/大小球独立口径；不根据这些已看过的历史成绩直接切换活动权重。

## 未来锁定样本

来源 `future/state/runs/20261112T132914482422.json`，哈希 `0e0bff73607583918c898e0988868745edd4303de7a28d8ef7301e87ec267871`。80场已捕获，26已完赛，54待结算。

|轨道|第一比分|明确WDL|有效真实OU|
|---|---:|---:|---:|
|Current|1/26|14/26|0|
|独立锁定candidate|2/26|13/26|0|

这不是活动Test或综合首版成绩。所有cohort晋级仍BLOCKED，不能将样本不足、盘口缺失或待结算写成验收完成。

## 历史保留材料覆盖

366份首版current-test-pair中120场找到并严格重核本地原始ESPN FT；180场未找到符合此次适配器约束的FT，66场未来/尚不能判完赛。247份首版综合中94场重核FT，135场缺同标准本地FT，8场旧fixture身份字段不全，10场未来。缺本地可核文件不等于比赛没完赛，也不等于其他来源没有赛果；此次没有为提高覆盖放松身份、90分钟或来源检查。原始JSON按文件名事件ID索引，未读取通用文件名的所有潜在标签。

模型有数值首版的可核FT为114场：Current比分5/114、WDL62/114；Test UCL比分1/35、WDL25/35，其余Test ML比分6/79、WDL41/79。这些名义版本总数只用于盘点。`artifact_groups`已按cohort、model_hash、code_hash再分34组，正式比较使用各组。

综合比分11/78，明确WDL46/80，其他待定保持待定。这些分母与模型不同，不能直接由两组率推导综合增益。

同场有正确引用、有效矩阵、明确首版比分与FT的综合对照：

|比较轨道|配对n|综合中|模型中|改对|改错|净增|
|---|---:|---:|---:|---:|---:|---:|
|Current MAIN1.2|55|8|2|6|0|+6|
|Test ML0.1|30|5|3|4|2|+2|
|Test UCL0.1|25|3|1|2|0|+2|

上述均引用首版模型对，不含改版补命中。它们是覆盖不完整的历史诊断，不能替代完整全体或新留出验证。实际使用的逐模型工件分组见 `manual_artifact_groups`。247份综合中47缺显式pair引用；200份path+sha均匹配，其中97缺旧schema的freeze_id字段，103有完整ID字段。没有为兼容评估改写旧freeze。3份综合比分为旧列表格式，仅在本次输出中解释为其原两整数，没有补造比分。

114场有数值模型的样本中Current第一比分1–1有67场，Test有72场，实际1–1为7场。所有这些矩阵有效且原Primary等于其argmax；该频数不能单独证明概率失准，也不支持手工减少1–1，应结合比分分布、零球和尾部校准研究。

## 真实盘口与大小球

366份首版模型对中179有结构化实盘，152缺来源quoted_at，27有结构化报价时间且早于采集/冻结/开赛。报价时间存在不等于已独立核验原始源真伪。152份抓取时间不得冒充报价时间。

已完赛且可按保留真实盘线结算的模型引用中：有结构化报价时间9场，Current 4全赢/1半赢/4全输，Test UCL 5全赢/1半赢/3全输；综合明确推荐仅1场全赢。其余来源报价时间未知的单独分组：Current 17全赢/1半赢/2走/4半输/25全输；Test UCL 9全赢/1半赢/1走/1半输/5全输；Test ML 10全赢/1走/3半输/18全输；综合11全赢/3半赢/2走/1半输/19全输。这不是完整历史盘口成绩或经独立时点认证的收益证明。

五向结算复用 `runtime/v2/model.py:total_settlement`，严格全赢率分子仅全赢、分母扣除走盘，半赢没有记为全赢。模型reference_direction是数值参考，不是综合推荐；没有用固定2.5替代缺失实盘。

## 已有研究数据与边界

- `/workspace/post32-20261112/alpha-grid/predictions.jsonl`：214配对预测，194历史重建+20未来冻结；旧已核FT76场，118缺结果、20未来待定。DC/ML组件与原freeze绑定。没有配对实盘结算。历史不是全新未见测试。
- `/workspace/post32-20261112/elo-fixed-temporal-v3/protocol.json` 明确 `historical_asof_certified=false`、`project_wide_unseen_certified=false`、`quoted_at=null`、`venue_verified=false`。其closing列市场实验不可冒充真实推荐时点验证；完整市场五臂面板0。
- 最新既有10场选择复盘 `WCPP/research/nine-items-20261105/prospective/selection-review-actual.json` 为综合2/10、与有模型9场比较净增+1；不能当全历史汇总。其normalized-results输入缺FT状态，重新调用严格API前应核对原始FT证据，不在原文件补状态。

脚本 `inventory.py`、`enrich.py` 保留计算过程；输出使用排他创建，不覆盖旧结果。重算需复制脚本到新输出目录或显式调整OUT，不能删除旧冻结。行级输出保留原freeze、结果原文路径和哈希，可按同一证据复核。

## 复算与长期恢复

恢复数据仓库的不可变标签 `workspace-full-20261102-v1`（commit `466fd626a47481e70b176a9a69c58224d7d1bf63`），再按 `NEW-ENVIRONMENT.md`、`WORKSPACE-RECOVERY.md` 及 `workspace-updates/` 已有增量恢复。无需重复上传整套WCPP。当前验收长期索引为 `workspace-updates/20261112-post32/archive-index.json`，原始冻结/历史数据已在完整备份和之后增量中保存。新增本次只读输出独立归档即可。

复算使用新的输出目录，旧输出不覆盖：

```bash
WCPP_BASELINE_OUT=/workspace/optimization-20261112/baseline-replay /workspace/football-venv/bin/python /workspace/optimization-20261112/baseline/inventory.py
WCPP_BASELINE_OUT=/workspace/optimization-20261112/baseline-replay /workspace/football-venv/bin/python /workspace/optimization-20261112/baseline/enrich.py
```

冻结/FT输入摘要见 `source-inputs.json`；最终交付文件摘要以 `manifest-final.json` 为准。输入继续新增时重算的覆盖可能增长，原首版与结果缺项不得通过修改旧记录处理。
