"""Add cohort/artifact separation and real-line settlement from already verified inventory."""
import json,pathlib,collections,sys,hashlib,os
import numpy as np
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from v2 import model as legacy
ROOT=pathlib.Path(os.environ.get('WCPP_BASELINE_OUT','/workspace/optimization-20261112/baseline'))
summary=json.loads((ROOT/'summary.json').read_text()); pairs=json.loads((ROOT/'first-pair-rows.json').read_text()); comps=json.loads((ROOT/'comprehensive-rows.json').read_text())
def ident(row,side):
 r=json.loads(pathlib.Path(row['path']).read_text())
 if 'primary' in row:
  ref=r['payload'].get('current_test_reference') or {}
  if not ref.get('path'):return None
  r=json.loads(pathlib.Path(ref['path']).read_text())
 x=r['payload'].get(side) or {}
 return {'cohort':row['cohort'],'version':x.get('version') or 'UNAVAILABLE','model_hash':x.get('model_hash'),'code_hash':x.get('code_hash')}
def key(x):return json.dumps(x,sort_keys=True)
firstgroups=collections.defaultdict(collections.Counter);manualgroups=collections.defaultdict(collections.Counter);ou=collections.defaultdict(collections.Counter);ou_rows=[]
for rows,track in [(pairs,'first_pair'),(comps,'comprehensive')]:
 for row in rows:
  if not row['time_valid'] or row['actual']['status']!='LOCALLY_REVERIFIED_FT':continue
  r=json.loads(pathlib.Path(row['path']).read_text());h,a=row['actual']['score'];actual='主胜' if h>a else '客胜' if h<a else '平局'
  if track=='first_pair':
   for side,x in row['models'].items():
    k=key(dict(side=side,**ident(row,side)));v=firstgroups[k];v['settled_population']+=1
    if isinstance(x.get('primary'),list):v['primary_n']+=1;v['primary_hits']+=x['primary']==[h,a]
    if x.get('wdl') in ('主胜','平局','客胜'):v['wdl_n']+=1;v['wdl_hits']+=x['wdl']==actual
  else:
   for side,x in row['models'].items():
    if not isinstance(row.get('primary'),list) or not isinstance(x.get('primary'),list) or not x.get('matrix_valid'):continue
    k=key(dict(side=side,**ident(row,side)));v=manualgroups[k];v['n']+=1;good=row['primary']==[h,a];base=x['primary']==[h,a]
    v['comprehensive_hits']+=good;v['issued_model_primary_hits']+=base;v['changed_right']+=good and not base;v['changed_wrong']+=base and not good;v['net_hits']+=int(good)-int(base)
  side_payloads={'comprehensive':r['payload']} if track=='comprehensive' else {s:r['payload'].get(s) or {} for s in row['models']}
  for side,x in side_payloads.items():
   direction={'大':'over','小':'under'}.get(x.get('total_direction')) if track=='comprehensive' else (x.get('total') or {}).get('reference_direction')
   q=r['fixture'].get('total_quote') if track=='comprehensive' else (x.get('total') or {}).get('quote')
   line=x.get('total_line') if track=='comprehensive' else (q or {}).get('line')
   if direction not in ('over','under') or not q or type(line) not in (int,float) or line!=q.get('line'):continue
   if q.get('match_id')!=r['match_id'] or q.get('market') not in ('asian_total','total') or not q.get('source_url') or not q.get('bookmaker'):continue
   if not all(type(q.get(z)) in (int,float) and q[z]>1 for z in ('over_odds','under_odds')):continue
   point=np.zeros((51,51));point[h,a]=1.;settlement=next(k for k,v in legacy.total_settlement(point,line,direction).items() if v==1.)
   group=key({'track':track,'side':side,'version':x.get('version') if track=='first_pair' else None,'quote_status':row['quote_status']});ou[group][settlement]+=1
   ou_rows.append({'match_id':row['match_id'],'track':track,'side':side,'primary_version':x.get('version'),'direction':direction,'line':line,'settlement':settlement,'quote_status':row['quote_status'],'freeze_id':r['freeze_id'],'source':row['path']})
summary['version_identity_notice']='Nominal version labels may reuse across cohorts/artifacts. Use artifact_groups for comparison; nominal totals are inventories only.'
summary['artifact_groups']=[dict(identity=json.loads(k),counts=dict(v)) for k,v in firstgroups.items()]
summary['manual_artifact_groups']=[dict(identity=json.loads(k),counts=dict(v)) for k,v in manualgroups.items()]
summary['real_line_settlement_groups']=[dict(identity=json.loads(k),counts=dict(v),non_push_n=sum(v.values())-v['push'],strict_full_win_rate=v['win']/(sum(v.values())-v['push']) if sum(v.values())-v['push'] else None) for k,v in ou.items()]
summary['ou_scope_notice']='Source-reported quote time missing and structured-chronology-present groups kept separate. Structured timestamps alone are not independently certified source as-of truth. Model reference totals are matrix references, not comprehensive betting recommendations. No fixed 2.5 substitution.'
for name,obj in [('summary-v2.json',summary),('actual-line-rows.json',ou_rows)]:
 with (ROOT/name).open('x') as f:json.dump(obj,f,ensure_ascii=False,indent=2)
manifest={'files':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(ROOT.glob('*')) if p.is_file()]}
with (ROOT/'manifest.json').open('x') as f:json.dump(manifest,f,indent=2)
print(json.dumps({'artifact_groups':len(firstgroups),'manual_artifact_groups':len(manualgroups),'real_line_settlement_groups':summary['real_line_settlement_groups']},ensure_ascii=False,indent=2))
