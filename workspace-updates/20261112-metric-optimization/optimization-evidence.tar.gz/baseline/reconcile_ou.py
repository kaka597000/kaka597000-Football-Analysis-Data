"""Additive correction: recognize retained standard_total market alias; no old output mutation."""
import json,pathlib,collections,hashlib,sys
import numpy as np
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from v2 import model
ROOT=pathlib.Path('/workspace/optimization-20261112/baseline')
evalpath=ROOT.parent/'evaluation/real-frozen-quote-eligibility.json'
pairs=json.loads((ROOT/'first-pair-rows.json').read_text());comps=json.loads((ROOT/'comprehensive-rows.json').read_text());old=json.loads((ROOT/'actual-line-rows.json').read_text());evaluation=json.loads(evalpath.read_text())
rows=[];groups=collections.defaultdict(collections.Counter)
for population,track in [(pairs,'first_pair'),(comps,'comprehensive')]:
 for row in population:
  if not row['time_valid'] or row['actual']['status']!='LOCALLY_REVERIFIED_FT':continue
  record=json.loads(pathlib.Path(row['path']).read_text());h,a=row['actual']['score']
  sides={'comprehensive':record['payload']} if track=='comprehensive' else {side:record['payload'].get(side) or {} for side in row['models']}
  for side,x in sides.items():
   direction={'大':'over','小':'under'}.get(x.get('total_direction')) if track=='comprehensive' else (x.get('total') or {}).get('reference_direction')
   quote=record['fixture'].get('total_quote') if track=='comprehensive' else (x.get('total') or {}).get('quote')
   line=x.get('total_line') if track=='comprehensive' else (quote or {}).get('line')
   if direction not in ('over','under') or not quote or type(line) not in (int,float) or line!=quote.get('line'):continue
   if quote.get('match_id')!=record['match_id'] or quote.get('market') not in ('asian_total','total','standard_total') or not quote.get('source_url') or not quote.get('bookmaker'):continue
   if not all(type(quote.get(z)) in (int,float) and quote[z]>1 for z in ('over_odds','under_odds')):continue
   point=np.zeros((51,51));point[h,a]=1.;settlement=next(k for k,v in model.total_settlement(point,line,direction).items() if v==1.)
   value={'match_id':row['match_id'],'track':track,'side':side,'primary_version':x.get('version'),'direction':direction,'line':line,'settlement':settlement,'quote_status':row['quote_status'],'market':quote['market'],'quoted_at':quote.get('quoted_at'),'query_time':quote.get('query_time'),'freeze_id':record['freeze_id'],'source':row['path'],'record_sha256':record['record_sha256']}
   if track=='first_pair':value['quote_present_in_original_input']=bool(x.get('input',{}).get('total_quote'))
   rows.append(value);group=json.dumps({'track':track,'side':side,'version':x.get('version') if track=='first_pair' else None,'quote_status':row['quote_status']},sort_keys=True);groups[group][settlement]+=1
summary=[{'identity':json.loads(k),'counts':dict(v),'n':sum(v.values()),'non_push_n':sum(v.values())-v['push'],'strict_full_win_rate':v['win']/(sum(v.values())-v['push']) if sum(v.values())-v['push'] else None} for k,v in groups.items()]
oldkeys={(r['match_id'],r['track'],r['side']) for r in old};added=[r for r in rows if (r['match_id'],r['track'],r['side']) not in oldkeys]
checks={}
for side in ('current_model','test_model'):
 newset={r['match_id'] for r in rows if r['side']==side and r['quote_status'].startswith('STRUCTURED')}
 evalset={r['match_id'] for r in evaluation['rows'] if r['local_ft_verified'] and r['models'][side]['eligible']}
 assert newset==evalset
 checks[side]={'baseline_before':len({r['match_id'] for r in old if r['side']==side and r['quote_status'].startswith('STRUCTURED')}),'corrected_unique_matches':len(newset),'evaluation_unique_matches':len(evalset),'sets_equal':True}
report={'schema':'WCPP-BASELINE-OU-ADDITIVE-RECONCILIATION-1','status':'PASS','root_cause':'enrich.py market allowlist accepted asian_total and total but omitted legitimate retained standard_total alias; original fixture/model.total.quote/input.total_quote were present and time checks were not the cause.','supersedes_only':'summary-v2.json real_line_settlement_groups and README historical OU counts; other baseline metrics unchanged','old_outputs_modified':False,'reconciliation':checks,'added_rows':added,'corrected_groups':summary,'source_asof_independently_certified':False,'notice':'Field-contract and structured chronology eligibility is not independent certification of original-source as-of truth. These model reference directions are not comprehensive betting recommendations. Future locked 80-population/26-complete review still has actual_line_n=0 per arm.','input_hashes':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in [ROOT/'summary-v2.json',ROOT/'first-pair-rows.json',ROOT/'comprehensive-rows.json',ROOT/'actual-line-rows.json',evalpath]],'recompute':'/workspace/football-venv/bin/python /workspace/optimization-20261112/baseline/reconcile_ou.py (outputs use exclusive creation)'}
for name,obj in [('actual-line-rows-v3.json',rows),('ou-reconciliation-v3.json',report)]:
 with (ROOT/name).open('x') as f:json.dump(obj,f,ensure_ascii=False,indent=2)
print(json.dumps({'reconciliation':checks,'added_market_rows':len(added),'corrected_groups':summary},ensure_ascii=False,indent=2))
