"""Read-only retained-evidence inventory; never modifies freezes or production state."""
import json, pathlib, collections, datetime, hashlib, re, sys, os
import numpy as np
sys.path.insert(0, '/workspace/Football-Analysis/runtime')
from research.analysis_freeze import verify, aware, digest
from research_program.replay import _finished_espn_label
ROOT=pathlib.Path('/workspace/WCPP/forecasts/issued-analyses')
OUT=pathlib.Path(os.environ.get('WCPP_BASELINE_OUT','/workspace/optimization-20261112/baseline'))
OUT.mkdir(parents=True,exist_ok=True)
now=datetime.datetime.now(datetime.timezone.utc)
records={}; bypath={}; tracks=collections.Counter(); invalid=[]
for p in ROOT.glob('*/*.json'):
 try:r=verify(json.loads(p.read_text()))
 except Exception as e:invalid.append({'path':str(p),'error':str(e)});continue
 records[r['freeze_id']]=(p,r);bypath[str(p)]=r;tracks['|'.join((r.get('track',''),r.get('evaluation_slot',''),r.get('stage','')))]+=1
comps=[(p,r) for p,r in records.values() if r.get('track')=='comprehensive' and r.get('evaluation_slot')=='FIRST_PREMATCH']
pairs=[(p,r) for p,r in records.values() if r.get('track')=='current-test-pair' and r.get('evaluation_slot')=='FIRST_PREMATCH']
wanted={r['match_id'].removeprefix('espn:') for _,r in comps+pairs}
files=collections.defaultdict(list)
for root in (pathlib.Path('/workspace/WCPP/reports'),pathlib.Path('/workspace/kaka597000-Football-Analysis-Data/future/state/raw')):
 for p in root.rglob('*.json'):
  for ident in set(re.findall(r'(?<!\d)\d{9}(?!\d)',p.name)) & wanted:files[ident].append(p)
labelcache={}
def actual(r):
 f=r['fixture']
 if not all(f.get(k) for k in ('match_id','home','away','kickoff_at','cohort')):return {'status':'FIXTURE_IDENTITY_SCHEMA_INCOMPLETE'}
 key=(f['match_id'],f.get('home'),f.get('away'),f['kickoff_at'],f['cohort'])
 if key in labelcache:return labelcache[key]
 labels=collections.defaultdict(list)
 if now < aware(f['kickoff_at'])+datetime.timedelta(minutes=90):labelcache[key]={'status':'FUTURE_OR_NOT_FINISHED'};return labelcache[key]
 for p in files[f['match_id'].removeprefix('espn:')]:
  try:
   raw=json.loads(p.read_text());event=raw.get('header')
   if event is None:event=next(x for x in raw.get('events',[]) if str(x.get('id'))==f['match_id'].removeprefix('espn:'))
   c=event['competitions'][0];t={x['homeAway']:x for x in c['competitors']}
   def goal(x):return int(x.get('displayValue')) if isinstance(x,dict) else int(x)
   h,a=goal(t['home']['score']),goal(t['away']['score']);url='https://site.api.espn.com/apis/site/v2/sports/soccer/'+f['cohort'].split(':')[0]+'/summary?event='+f['match_id'].removeprefix('espn:')
   _finished_espn_label(dict(f,home_goals=h,away_goals=a),{'url':url},p)
   labels[(h,a)].append({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'source_url':url})
  except (ValueError,KeyError,TypeError,IndexError,AttributeError,StopIteration):continue
 if len(labels)==1:
  score,evidence=next(iter(labels.items()));v={'status':'LOCALLY_REVERIFIED_FT','score':list(score),'evidence':evidence}
 else:v={'status':'CONFLICTING_RESULTS' if labels else 'MISSING_VERIFIED_LOCAL_FT'}
 labelcache[key]=v;return v

def primary(v):
 if v is None:return None
 if isinstance(v,str) and re.fullmatch(r'\d{1,2}-\d{1,2}',v):return [int(x) for x in v.split('-')]
 if isinstance(v,list) and len(v)==2 and all(type(x)is int for x in v):return v
 return 'UNSUPPORTED'

def validtime(r):
 try:return aware(r['fixture']['cutoff_at'])<=aware(r['recorded_at'])<aware(r['fixture']['kickoff_at'])
 except Exception:return False

def quotestatus(q,r):
 if not q:return 'MISSING'
 try:
  if not q.get('quoted_at'):return 'SOURCE_QUOTE_TIME_UNKNOWN'
  if not aware(q['quoted_at'])<=aware(q['query_time'])<=aware(r['recorded_at'])<aware(r['fixture']['kickoff_at']):return 'CHRONOLOGY_INVALID'
  if q.get('match_id')!=r['match_id'] or not q.get('bookmaker') or not q.get('source_url'):return 'IDENTITY_OR_SOURCE_MISSING'
  if not all(type(q.get(k)) in (int,float) for k in ('line','over_odds','under_odds')):return 'LINE_OR_ODDS_MISSING'
  return 'STRUCTURED_QUOTE_CHRONOLOGY_PRESENT_NOT_RAW_SOURCE_CERTIFIED'
 except Exception:return 'QUOTE_SCHEMA_INVALID'

def modelrow(r,side):
 x=r['payload'].get(side) or {};mat=x.get('matrix');pr=primary(x.get('primary'));v={'version':x.get('version') or 'UNAVAILABLE','primary':pr,'wdl':x.get('wdl_reference'),'status':x.get('status'),'matrix_valid':None}
 if mat is not None:
  m=np.asarray(mat,dtype=float);v['matrix_valid']=bool(m.ndim==2 and np.isfinite(m).all() and (m>=0).all() and np.isclose(m.sum(),1) and digest(mat)==x.get('matrix_hash'))
  if v['matrix_valid']:v['statistical_mode']=list(map(int,np.unravel_index(m.argmax(),m.shape)))
 return v

comp_rows=[];pair_rows=[]
for p,r in pairs:
 row={'path':str(p),'freeze_id':r['freeze_id'],'record_sha256':r['record_sha256'],'match_id':r['match_id'],'cohort':r['fixture'].get('cohort'),'time_valid':validtime(r),'quote_status':quotestatus(r['fixture'].get('total_quote'),r),'actual':actual(r)}
 row['models']={side:modelrow(r,side) for side in ('current_model','test_model')};pair_rows.append(row)
for p,r in comps:
 x=r['payload'];ref=x.get('current_test_reference') or {};pair=bypath.get(ref.get('path'));refstatus='MISSING_REFERENCE'
 if ref:
  if pair is None:refstatus='REFERENCED_FILE_MISSING'
  elif pair['record_sha256']!=ref.get('sha256'):refstatus='REFERENCE_HASH_MISMATCH';pair=None
  elif ref.get('freeze_id') not in (None,pair['freeze_id']):refstatus='REFERENCE_ID_MISMATCH';pair=None
  elif pair['track']!='current-test-pair' or pair['match_id']!=r['match_id'] or pair['fixture'].get('cohort')!=r['fixture'].get('cohort') or aware(pair['fixture']['kickoff_at'])!=aware(r['fixture']['kickoff_at']) or not validtime(pair) or aware(pair['recorded_at'])>aware(r['recorded_at']):refstatus='REFERENCE_IDENTITY_OR_CHRONOLOGY_INVALID';pair=None
  else:refstatus='EXPLICIT_ID_PATH_HASH_VERIFIED' if ref.get('freeze_id') else 'LEGACY_PATH_HASH_VERIFIED_NO_ID_FIELD'
 row={'path':str(p),'freeze_id':r['freeze_id'],'record_sha256':r['record_sha256'],'match_id':r['match_id'],'cohort':r['fixture'].get('cohort'),'time_valid':validtime(r),'primary':primary(x.get('primary')),'primary_original_type':type(x.get('primary')).__name__,'wdl':x.get('wdl'),'total_direction':x.get('total_direction'),'total_line':x.get('total_line'),'quote_status':quotestatus(r['fixture'].get('total_quote'),r),'reference_status':refstatus,'actual':actual(r),'models':{}}
 if pair:row['referenced_pair_slot']=pair['evaluation_slot'];row['models']={side:modelrow(pair,side) for side in ('current_model','test_model')}
 comp_rows.append(row)

def counts(rows,side=None):
 c=collections.Counter(population=len(rows));versions=collections.defaultdict(collections.Counter)
 for r in rows:
  c[r['actual']['status']]+=1
  if not r['time_valid']:c['invalid_freeze_chronology']+=1;continue
  x=r if side is None else r['models'].get(side,{})
  c['primary_selected']+=isinstance(x.get('primary'),list)
  if r['actual']['status']!='LOCALLY_REVERIFIED_FT':continue
  h,a=r['actual']['score'];wdl='主胜' if h>a else '客胜' if h<a else '平局'
  t=c if side is None else versions[x.get('version','UNAVAILABLE')]
  t['settled_population']+=1
  if isinstance(x.get('primary'),list):t['primary_n']+=1;t['primary_hits']+=x['primary']==[h,a]
  if x.get('wdl') in ('主胜','平局','客胜'):t['wdl_n']+=1;t['wdl_hits']+=x['wdl']==wdl
 return {'population_inventory':dict(c),'by_version':dict(versions)} if side else dict(c)
manual=collections.defaultdict(collections.Counter)
for r in comp_rows:
 if r['actual']['status']!='LOCALLY_REVERIFIED_FT' or not r['time_valid'] or not isinstance(r['primary'],list):continue
 score=r['actual']['score']
 for side,m in r['models'].items():
  if not isinstance(m.get('primary'),list) or not m.get('matrix_valid'):continue
  c=manual[side+':'+m['version']];good=r['primary']==score;base=m['primary']==score
  c['n']+=1;c['comprehensive_hits']+=good;c['issued_model_primary_hits']+=base;c['changed_right']+=good and not base;c['changed_wrong']+=base and not good;c['net_hits']+=int(good)-int(base);c['pair_revision_used']+=r.get('referenced_pair_slot')!='FIRST_PREMATCH'
latest=pathlib.Path('/workspace/kaka597000-Football-Analysis-Data/future/state/runs/20261112T132914482422.json');future=json.loads(latest.read_text());agg={m:collections.Counter() for m in ('current','candidate')}
for c in future['cohort_reviews']:
 for m,z in c['independent_denominators'].items():agg[m].update({k:v for k,v in z.items() if type(v)is int})
summary={'schema':'WCPP-READONLY-OPTIMIZATION-BASELINE-INVENTORY-1','created_at':now.isoformat(),'scope_notice':'Retained local raw FT labels reverified at this audit, not a new untouched test; source facts and quoted-at provenance not independently certified. Missing stays missing. Comprehensive versus referenced pair can include an explicitly noted pair revision. No artifact, source, registry or freeze mutated.','records':len(records),'invalid_freezes':invalid,'tracks':dict(tracks),'comprehensive':counts(comp_rows),'first_pairs':{s:counts(pair_rows,s) for s in ('current_model','test_model')},'comprehensive_reference_status':dict(collections.Counter(r['reference_status'] for r in comp_rows)),'first_pair_quote_status':dict(collections.Counter(r['quote_status'] for r in pair_rows)),'comprehensive_quote_status':dict(collections.Counter(r['quote_status'] for r in comp_rows)),'manual_same_referenced_model_primary':dict(manual),'future_frozen':{'source':str(latest),'sha256':hashlib.sha256(latest.read_bytes()).hexdigest(),'population':future['population'],'completed':future['completed'],'pending':future['pending'],'aggregate_for_inventory_only_not_promotion':{m:dict(v) for m,v in agg.items()},'all_cohort_gates_blocked':all(c['promotion_review']['status']=='BLOCKED' for c in future['cohort_reviews'])}}
for name,obj in [('summary.json',summary),('comprehensive-rows.json',comp_rows),('first-pair-rows.json',pair_rows)]:
 with (OUT/name).open('x') as f:json.dump(obj,f,ensure_ascii=False,indent=2)
print(json.dumps({k:v for k,v in summary.items() if k not in ('tracks','scope_notice')},ensure_ascii=False,indent=2))
