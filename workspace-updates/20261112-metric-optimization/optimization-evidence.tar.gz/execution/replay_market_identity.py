"""Offline replay of two retained 2026-11-12 captures; no new source requests."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                    separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def run(source, evidence, out):
    sys.path.insert(0, str(source))
    from runtime.automation.market_snapshot import ALIAS_REVIEW, ALIAS_REVIEW_SHA256, build
    from runtime.v2_test.data_contract import aware
    out.mkdir(parents=True, exist_ok=True)
    batches = []
    for name, expected in [('live-market-fresh-1', 6), ('live-market-fresh-2', 8)]:
        root = evidence / name
        metas = json.loads((root / 'source-metadata.json').read_text())
        original = json.loads((root / 'market-channel.json').read_text())
        cutoff = original['created_at']
        replay = build(root, metas['odds'], metas['identity'], cutoff=cutoff, now=aware(cutoff))
        by_match = {s['target']['match_id']: s for s in replay['snapshots']}
        unchanged = []
        for old in original['snapshots']:
            mid = old['target']['match_id']; new = by_match[mid]
            assert old == new, ('existing snapshot changed', name, mid)
            unchanged.append({'match_id': mid, 'observation_sha256': digest(old['observations']),
                              'snapshot_sha256': old['snapshot_sha256'], 'unchanged': True})
        assert replay['covered_fixture_count'] == expected
        assert replay['eligible_fixture_count'] == 8
        target = out / (name + '-replay.json')
        target.write_text(json.dumps(replay, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
        batches.append({'batch': name, 'retained_cutoff': cutoff,
                        'aliases_known_at_cutoff': aware(ALIAS_REVIEW['reviewed_at']) <= aware(cutoff),
                        'source_evidence': metas,
                        'original': {k: original[k] for k in ('coverage', 'covered_fixture_count', 'verified_quote_count')},
                        'replay': {k: replay[k] for k in ('coverage', 'covered_fixture_count', 'verified_quote_count', 'excluded')},
                        'existing_snapshots_unchanged': unchanged,
                        'new_match_ids': sorted(set(by_match) - {s['target']['match_id'] for s in original['snapshots']}),
                        'output_file': target.name, 'output_sha256': hashlib.sha256(target.read_bytes()).hexdigest()})
    summary = {'schema': 'WCPP-RETAINED-MARKET-IDENTITY-REPLAY-1',
               'executed_at': datetime.now(timezone.utc).isoformat(),
               'mode': 'OFFLINE_REPLAY_AT_RETAINED_CAPTURE_TIME',
               'live_collection': False, 'source_requests': 0,
               'review_version': ALIAS_REVIEW['version'], 'review_sha256': ALIAS_REVIEW_SHA256,
               'reviewed_at': ALIAS_REVIEW['reviewed_at'], 'batches': batches,
               'active_models_modified': False, 'historical_freezes_modified': False,
               'accuracy_improvement_claimed': False,
               'limitation': 'Adapter replay validates retained source identity and coverage; no new live quotes, model promotion, or accuracy result.'}
    (out / 'market-replay-summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({b['batch']: b['replay'] for b in batches}, ensure_ascii=False))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--evidence', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    run(args.source, args.evidence, args.out)
