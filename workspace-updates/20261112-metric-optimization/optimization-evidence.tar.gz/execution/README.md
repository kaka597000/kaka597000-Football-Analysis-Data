# 执行链路验收（2026-11-12，北京时间）

本轮仅修复数据身份适配与恢复原依赖。活动工件、模型权重、注册表、旧冻结不变；未声称命中率提升，未查询新足球数据。

本子任务的源码所有权清单（已定稿）：`runtime/automation/market_snapshot.py`、`runtime/automation/test_market_snapshot.py`、`scripts/validate_retained_aus.py`、`runtime/research_program/test_retained_aus_validation.py`。不拥有其他代理的改动，未 switch/commit/push。

## 欧国联盘口身份

`runtime/automation/market_snapshot.py` 新增两条来源受限的已审核别名：ESPN `465` 的 Türkiye / The Odds API Turkey；ESPN `450` 的 Czechia / Czech Republic。禁止同名其他 ID、模糊匹配、主客互换、异时或异赛事匹配。别名审核时间为北京时间 21:43:21；只在 cutoff 不早于审核时间时生效。

按保留原时点本地回放，而非新实采：

|保留捕获批次|原覆盖/有效报价|新适配器覆盖/有效报价|
|---|---|---|
|21:35:43，审核之前|6/8，150|6/8，150|
|21:51:45，审核之后|6/8，156|8/8，212|

两批原来六场的完整 snapshot（包括观察哈希、真实 quote/query 时间）逐一完全相同。新增场次保留原双方名字、双方 ESPN ID、provider event ID、审核版本、审核内容 SHA256 和两份原始响应 SHA256。完整映射证据的已有长期归档位置在输出 `identity_alias_review.archive` 中，不重复上传原文。

验收入口：`replay_market_identity.py`；摘要 `market-replay-summary.json`；逐批输出 `live-market-fresh-*-replay.json`。回归 14 项通过（`market-tests.log`）。

部署仅需更新数据仓库 `.github/workflows/unattended.yml` 的独立 `collector-code` ref 到包含修复的源码提交。本轮新运行代码只有 `runtime/automation/market_snapshot.py`；无需给锁定推理进程新增 overlay。现有 prospective_cycle/result_queue 两文件 overlay 保持原范围。不在部署时额外请求盘口；既有定时任务负责下一轮运行。Actions 缺盘口密钥的问题独立存在。

## 澳超原工件恢复验收

已存在的 retained-J1 源码同时完整匹配澳超原 optimization 和 runner hash。新增 `scripts/validate_retained_aus.py` 复用其原始源码 manifest，在独立解释器先加载已核验原 optimization 依赖，解决旧 runner 硬编码导入当前目录的问题。Current 在另一个解释器运行现有 generic 原入口。没有修改 runner 字节、artifact 或 manifest 来绕过检查。

首次真实执行发现 dataset manifest 正确但 `research.sqlite` 字节错误。已从既有长期归档 `workspace-updates/20261107-perth-lineup-revision/parts/perth.tar.gz.part000` 恢复原文件，原 member SHA256 `6927751edcff73c01b6bc00d537d08169ef36061fe73e36871faf4511a2fb3d4`。修改前版本 `fd6f458cb7fe4a8cc90953e1e00d82e29286f88cb73c0e33e3e122757725bfa3` 保留于 `aus-research-before-repair.sqlite`，可回滚。

全 JSON 引用审计找到四份相关文件，没有任何扫描到的锁定 manifest / 工件要求原错误字节（`aus-dependency-references.json`）；完整归档来源与恢复动作见 `aus-dataset-recovery.json`。恢复后的 38/38 活动工件原 SHA256、其明确引用的三个 dataset manifest 及成员全部匹配（`active-artifact-dependency-check.json`）。这项检查不声称已遍历所有非显式嵌套依赖。

长期归档固定在数据仓库 commit `9062043f6bae58054e978d9b6a81ff111073ede5`。`aus-dependency-recovery-catalog.json` 可直接复用现有恢复入口，仅提取该一个原始成员；其独立新目录恢复已通过（`aus-cleanroom-restore.json`）。归档原文件无需重复上传。本地缓存仅为这次验收服务，交付时不必把 `recovery-cache/` 和 `cleanroom/` 再归档。

新环境恢复命令（先用现有基础恢复流程准备原工件、源码和其他数据）：

```bash
python scripts/restore_retained_catalog.py \
  --catalog /path/to/aus-dependency-recovery-catalog.json \
  --workspace /workspace --cache /path/to/recovery-cache \
  --receipt /path/to/new-aus-restore-receipt.json
python scripts/validate_retained_aus.py \
  --registry /workspace/WCPP/runtime/active-model.json \
  --retained-manifest /workspace/WCPP/runtime/retained-j1/manifest.json \
  --seed /workspace/WCPP/reports/aus-prematch-20261030-1553/model/fixture-v2.json \
  --out /path/to/new-aus-load-receipt.json
```

恢复入口严格拒绝覆盖冲突文件；若目标已是原 hash，则无需恢复。回滚点是 `aus-research-before-repair.sqlite`，回滚时先核对其 SHA256 为记录的 `fd6f...`，再恢复到原 dataset 路径；这会重新触发原 loader 拒绝加载，是回到修复前状态，并非模型版本切换。没有自动回滚或删除旧预测。

最终真实 Current/Test 工件加载结果为 `PAIRED_SYNTHETIC_LOAD_VALIDATED`，详见 `aus-retained-load-final.json`：合法归一化双矩阵、各自真正导入模块路径/hash及依赖包版本均保存。输入是从保留真实球队身份生成的显式 `SYNTHETIC-RETAINED-AUS-LOAD`，没有伪装成真实新赛事，没有关闭时钟检查，没有发布或写入正式冻结。活动 dispatcher 尚未切换；真实未开赛交付仍待验收。

回归 7 项通过（`aus-tests.log`），覆盖工件/源码/数据库成员变更、刷新源码清单不能伪装原工件依赖，以及合成输入不得携带历史赛果/盘口。

## 韩 K1

原依赖校验及原 Test loader 已真实通过，777 场训练历史（`kor-retained-loader.json`）。Test 使用 `kleague:Kxx`，Current 使用 ESPN ID；现有统一数据库 KOR 范围的 ESPN provider 映射为 0（`kor-crosswalk-status.json`）。没有据球队名字构造跨供应商映射，因此尚未完成同一真实身份的双轨加载，不宣布 K1 正常生产。

下一步需要原始赛事/球队 ID 证据支持 ESPN ↔ KLeague 的显式映射，再复用已有隔离运行方案。没有重训或修改任何训练权重。
