"""Read-only replay of preserved real candidate/comprehensive references."""
import copy
import hashlib
import json
import sys
from pathlib import Path
from research.analysis_freeze import verify
from research.score_distribution_audit import audit_issued

source = Path(sys.argv[1])
output = Path(sys.argv[2])
if output.exists():
    raise FileExistsError(output)
results = []
for item in json.loads(source.read_text()):
    reference = item['comprehensive_receipt']
    path = Path(reference['path'])
    raw = path.read_bytes()
    record = verify(json.loads(raw))
    assert record['record_sha256'] == reference['sha256']
    candidate = item['payload']['candidate_reference']
    candidate_path = Path(candidate['path'])
    candidate_raw = candidate_path.read_bytes()
    original = audit_issued(record['payload'], record['fixture'], stage='prematch',
                            track='comprehensive', verify_record=verify)
    payload = copy.deepcopy(record['payload'])
    payload['selection_scope'] = 'candidate_research'
    updated = audit_issued(payload, record['fixture'], stage='prematch',
                           track='comprehensive', verify_record=verify)
    assert path.read_bytes() == raw and candidate_path.read_bytes() == candidate_raw
    results.append({'match_id': record['match_id'],
                    'original_comprehensive_reference': reference,
                    'original_candidate_reference': candidate,
                    'source_file_sha256': hashlib.sha256(raw).hexdigest(),
                    'before_status': original['status'],
                    'after_status': updated['status'],
                    'top3_ready': updated['top3_ready'],
                    'formal_kpi_eligible': updated['formal_kpi_eligible'],
                    'source_freezes_unchanged': True})
output.write_text(json.dumps({'purpose': 'READ_ONLY_REPLAY_NOT_A_NEW_PREDICTION_OR_FREEZE',
                             'n': len(results), 'ready': sum(r['top3_ready'] for r in results),
                             'rows': results}, ensure_ascii=False, indent=2)+'\n')
print(json.dumps({'n': len(results), 'ready': sum(r['top3_ready'] for r in results)}))
