# PR #33 α-grid review closure — 2026-11-12

本轮只修复候选复用和评估分母；不选权重，不改活动模型或生产冻结。

| Review comment | 状态与代码位置 |
|---|---|
| 4550697361：future候选冻结未核验 | 前序已修；`scripts/score_frozen_alpha_grid.py:91` 验证原候选track/首版/身份/原payload/哈希/时间。复用旧节点另需protocol显式登记原receipt且完全匹配。 |
| 4550697370：历史/前向混算 | 前序已修；`scripts/score_frozen_alpha_grid.py:183` 保留独立segments，pooled仅诊断。 |
| 4550697382：空预测除零 | 前序已修；`scripts/score_frozen_alpha_grid.py:222` 空population覆盖率为null；新增空protocol与全部重建失败两类测试。 |
| 4550735062：相同冻结根目录重跑冲突 | 本轮已修；`scripts/replay_frozen_alpha_grid.py:35` 校验链/fixture/时间，`:64` 只有重建payload完全一致才复用原回执。新protocol预先显式列retained_candidate_freeze；没有改旧cutoff。 |
| 4551049202：重建失败从覆盖分母消失 | 本轮已修；`scripts/score_frozen_alpha_grid.py:21` 核验完整protocol名单，`:137` 对缺预测保留MISSING_RECONSTRUCTED_PREDICTION，历史/前向/cohort分母均保留。 |

验证：7项定向测试通过（`tests.log`），覆盖新旧候选时间、拒绝payload变化、两场只重建一场覆盖50%、全部失败、零population、future缺预测分母。

真实验收：原214场/20个未来候选的234份冻结复制到隔离沙盒后连续两次执行生成器，两次predictions.jsonl字节完全相同，234份冻结字节与SHA不变；20原候选全部复用、0新冻结，214条均通过评分器身份/时点/分量验证。记录见`acceptance.json`、`replay-2/summary.json`。新程序只在沙盒执行生成，生产冻结没有写入。

同样本对照：严格复用旧76份真实FT证据，全部原统计与旧scored-v2完全一致（`scored-same76.json`）：Current比分3/76，Test5/76；alpha 0/0.25/0.5/0.75/1对应3/4/5/6/6。历史总体194、未来总体20且未来0结算。

额外覆盖诊断：扫描现有全部本地缓存找到另3场合格FT（`additional-retained-results.json`），因此`scored-original214.json`为79已结算，Current4/79、Test6/79，alpha对应4/5/6/7/6。这个区别来自已有源覆盖扩大，不是修代码提高预测，不是新增未来验证，不据此选参。

归档建议：保存本README、acceptance.json、tests.log、scored-same76.json、scored-original214.json、additional-retained-results.json、replay-2/protocol.json、replay-2/summary.json、replay-sandbox/before-sha256.json及日志即可。replay-sandbox/forecasts、matched-original76、replay-1/2/predictions.jsonl为已长期归档源的重复副本，可不重复上传；两scripts是复算入口。
