# Fresh Pinnacle quote collection — remaining slate

Observation requests started 2026-11-22T15:30:20.497932+00:00; all UTC. Scope cutoff: 2026-11-22T15:28:32Z; window ends 2026-11-23T04:00:00Z.

## Capture results

Fresh captures: 8 league requests. The first eight league requests returned HTTP 200; Brazil returned HTTP 401 at 2026-11-22T15:30:24.974904+00:00 and collection stopped there, so MLS was not queried. No retries were made.

Fixture rows: 20; Pinnacle h2h+totals quote rows: 14 (13 observed before kickoff, 1 Sweden quote observed after kickoff); status counts: {'OBSERVED_AT_OR_AFTER_KICKOFF': 1, 'OK_FRESH_PINNACLE': 13, 'NO_FRESH_CAPTURE_AFTER_STOP': 6}.

The Sweden fixture (Brommapojkarna–Halmstad) kicked off at 15:30Z. Its raw market quote timestamp and observation came after kickoff; it remains present for audit and is marked observation-only, not prematch.

Successful responses were retained without credentials in `raw/`; SHA256, exact request parameters, observation time, and quota headers are in `collection.json`. Canonical quote rows are in `canonical-rows.json`; old/current deltas and line audit are in `market-differences.json`.

Comparison baseline: 17:15 BJT snapshot in `scope-prematch-20261122-1713/market/markets.json` (quoted around 09:15Z). Comparisons join on the exact The Odds API provider event ID and 90-minute WCPP market mapping. Totals deltas are emitted only when the exact same point/line exists; line shifts are represented as no exact-line comparison. The Odds API does not separately label the period, so standard soccer h2h/totals were mapped to WCPP regulation-90 and that assumption is marked in each canonical row.

The two unretrieved markets (Brazil and MLS) remain explicit no-fresh-capture rows in the canonical file. Prior evidence is only referenced, not carried forward as fresh.
