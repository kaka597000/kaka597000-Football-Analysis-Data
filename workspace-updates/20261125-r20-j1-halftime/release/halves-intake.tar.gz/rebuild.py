#!/usr/bin/env python3
"""Offline-only reconstruction of frozen J1 regulation-half evidence."""
from __future__ import annotations
import gzip, hashlib, json, re, tarfile
from decimal import Decimal, InvalidOperation
from pathlib import Path

OUT = Path(__file__).resolve().parent
INTAKE = Path('/workspace/scratch/j1-lineups-history-intake')
LIVE = Path('/workspace/scratch/live-j1-afc-20261125')
R15 = Path('/workspace/scratch/r15-data/workspace-updates/20261125-r15-j1-lineups/raw')
FINAL = INTAKE/'checkpoints/final-checkpoint/events.jsonl'
R5 = INTAKE/'r5-targets.jsonl'
HEX = re.compile(r'^[0-9a-f]{64}$')
DECIMAL = re.compile(r'^(?:0|[1-9][0-9]*)(?:\.[0-9]+)?$')

def sha(b): return hashlib.sha256(b).hexdigest()
def read_jsonl(p): return [json.loads(x) for x in p.open() if x.strip()]
def dump_jsonl(path, rows):
    with path.open('w') as f:
        for row in rows: f.write(json.dumps(row,ensure_ascii=False,separators=(',',':'))+'\n')
def num(s):
    d=Decimal(s)
    return int(d) if d == d.to_integral_value() else float(d)
def same_time(a,b):
    # ESPN retains UTC Z timestamps; identity requires exact represented instant.
    from datetime import datetime
    return datetime.fromisoformat(a.replace('Z','+00:00')) == datetime.fromisoformat(b.replace('Z','+00:00'))

def tar_sources():
    found={}
    tar_meta={}
    for p in sorted(R15.glob('part-*.tar')):
        tb=p.read_bytes(); tar_meta[p.name]={'path':str(p),'sha256':sha(tb),'bytes':len(tb)}
        with tarfile.open(p,'r:') as tf:
            for m in tf.getmembers():
                if m.isfile() and HEX.fullmatch(Path(m.name).name.split('.')[0]):
                    found.setdefault(Path(m.name).name, (p,m.name))
    return found,tar_meta

def fetch_raw(digest, tar_map):
    name=digest+'.json.gz'
    if name in tar_map:
        p,member=tar_map[name]
        with tarfile.open(p,'r:') as tf: gz=tf.extractfile(member).read()
        origin={'kind':'r15_original_evidence_shard','path':str(p),'member':member}
    else:
        p=INTAKE/'raw/sha256'/name
        gz=p.read_bytes()
        origin={'kind':'intake_raw_sha256','path':str(p),'member':None}
    body=gzip.decompress(gz)
    if sha(body)!=digest: raise ValueError(f'body SHA mismatch {digest}')
    return body,origin,len(gz),sha(gz)

def extract_halves(doc, row, expected):
    errors=[]
    hdr=doc.get('header') or {}
    comps=hdr.get('competitions') or []
    if len(comps)!=1: errors.append('summary_competition_count_not_one')
    comp=comps[0] if comps else {}
    eid=str(hdr.get('id',''))
    if eid!=row['source_match_id'] or eid!=expected['source_match_id']: errors.append('event_id_mismatch')
    if comp.get('date')!=row.get('date') or comp.get('date')!=expected.get('date'): errors.append('kickoff_identity_mismatch')
    st=((comp.get('status') or {}).get('type') or {})
    if st.get('name')!='STATUS_FULL_TIME' or st.get('completed') is not True or st.get('detail')!='FT': errors.append('not_explicit_full_time')
    sides={}
    for c in comp.get('competitors') or []:
        ha=c.get('homeAway')
        if ha in ('home','away'):
            if ha in sides: errors.append(f'duplicate_{ha}_competitor')
            sides[ha]=c
    if set(sides)!={'home','away'}: errors.append('missing_home_or_away_competitor')
    full=[]; half1=[]; half2=[]; displays={}
    for ha,slot in [('home',0),('away',1)]:
        c=sides.get(ha,{})
        tid=str((c.get('team') or {}).get('id') or c.get('id') or '')
        if tid!=str(expected.get(ha+'_id')) or tid!=str(row.get(ha+'_id')): errors.append(f'{ha}_team_id_mismatch')
        try:
            fs=str(c.get('score'))
            if not DECIMAL.fullmatch(fs): raise InvalidOperation()
            fd=Decimal(fs)
            if fd<0: raise InvalidOperation()
            full.append(num(fs))
        except (InvalidOperation,ValueError,TypeError):
            errors.append(f'{ha}_full_score_invalid'); full.append(None)
        ls=c.get('linescores')
        if not isinstance(ls,list) or len(ls)!=2:
            errors.append(f'{ha}_linescores_not_exactly_two_periods'); half1.append(None); half2.append(None); displays[ha]=[]; continue
        vals=[]
        for i,x in enumerate(ls,1):
            if not isinstance(x,dict):
                errors.append(f'{ha}_period_{i}_not_object'); vals.append(None); continue
            if 'period' in x and x['period']!=i: errors.append(f'{ha}_period_{i}_label_mismatch')
            v=x.get('displayValue')
            if not isinstance(v,str) or not DECIMAL.fullmatch(v):
                errors.append(f'{ha}_period_{i}_display_value_invalid'); vals.append(None)
            else:
                try:
                    dv=Decimal(v)
                    if dv<0: raise InvalidOperation()
                    vals.append(num(v))
                except (InvalidOperation,ValueError):
                    errors.append(f'{ha}_period_{i}_display_value_invalid'); vals.append(None)
        displays[ha]=[x.get('displayValue') for x in ls]
        half1.append(vals[0]); half2.append(vals[1])
        if len(vals)==2 and None not in vals and full[slot] is not None:
            if Decimal(str(vals[0]))+Decimal(str(vals[1])) != Decimal(str(full[slot])):
                errors.append(f'{ha}_halves_do_not_sum_to_full')
    return (full if len(full)==2 else None, half1 if len(half1)==2 else None,
            half2 if len(half2)==2 else None, displays, errors)

final=read_jsonl(FINAL); r5=read_jsonl(R5)
final_by={x['source_match_id']:x for x in final}
r5_by={x['source_match_id']:x for x in r5}
tar_map,tar_meta=tar_sources()
rows=[]; idx=[]
for row in final:
    eid=row['source_match_id']; expected=r5_by.get(eid); errs=[]
    if expected is None: expected={}; errs.append('missing_registered_r5_identity')
    if row.get('competition')!='jpn.1' or expected.get('competition')!='jpn.1': errs.append('competition_not_jpn1')
    if row.get('r5_membership_verified') is not True or expected.get('membership_verified') is not True: errs.append('r5_membership_not_verified')
    if row.get('event_status')!='STATUS_FULL_TIME' or row.get('completed') is not True: errs.append('checkpoint_not_explicit_full_time')
    if row.get('regulation_periods')!=2 or row.get('regulation_final_status') is not True: errs.append('checkpoint_not_confirmed_regulation_90')
    if row.get('extra_time_indicated') is True or row.get('shootout_indicated') is True: errs.append('extra_time_or_shootout_indicated')
    digest=row.get('source_sha256','')
    if not HEX.fullmatch(digest):
        errs.append('summary_source_sha256_invalid'); doc={}; origin={}; gzbytes=0; gzsha=None
    else:
        try:
            body,origin,gzbytes,gzsha=fetch_raw(digest,tar_map); doc=json.loads(body)
            if sha(body)!=digest: errs.append('summary_body_sha256_mismatch')
        except Exception as e:
            errs.append('summary_raw_unavailable_or_invalid:'+type(e).__name__); doc={}; origin={}; gzbytes=0; gzsha=None
    if doc:
        full,h1,h2,display,parse_errors=extract_halves(doc,row,expected)
        errs.extend(parse_errors)
    else: full=h1=h2=None; display={}
    # Independently crosswalk normalized final and R5/scoreboard identity.
    for key in ('date','home_id','away_id','home','away','home_goals','away_goals'):
        if str(row.get(key))!=str(expected.get(key)): errs.append('r5_'+key+'_mismatch')
    # Bind full score to normalized historical completed-90 record.
    try:
        if full is None or [str(x) for x in full] != [str(int(row['home_goals'])),str(int(row['away_goals']))]: errs.append('raw_full_score_differs_from_final_checkpoint')
    except Exception: errs.append('normalized_full_score_invalid')
    # Remove duplicate reasons while retaining first diagnostic order.
    errs=list(dict.fromkeys(errs))
    ok=not errs
    kickoff=row.get('date')
    try:
        from datetime import datetime,timezone
        dt=datetime.fromisoformat(kickoff.replace('Z','+00:00')).astimezone(timezone.utc)
        kickoff_iso=dt.isoformat(timespec='seconds').replace('+00:00','Z')
    except Exception: kickoff_iso=kickoff
    rows.append({'match_id':'espn:'+eid,'home_id':str(row.get('home_id') or ''),'away_id':str(row.get('away_id') or ''),'kickoff_utc':kickoff_iso,
                 'full':full,'half1':h1,'half2':h2,'source_sha256':digest,'eligible':ok,'reason':None if ok else ';'.join(errs)})
    idx.append({'match_id':'espn:'+eid,'competition':'jpn.1','r5_registered':expected.get('membership_verified') is True,
                'date_r5':expected.get('date'),'date_final_checkpoint':row.get('date'),'home_id_r5':str(expected.get('home_id') or ''),'away_id_r5':str(expected.get('away_id') or ''),
                'source_summary_url':row.get('source_url'),'source_query_time_utc':row.get('source_query_time_utc'),'source_sha256':digest,
                'raw_origin':origin,'raw_gzip_bytes':gzbytes,'raw_gzip_member_sha256':gzsha,'raw_body_sha256_verified':bool(doc and sha(body)==digest),
                'checkpoint_home_goals':[row.get('home_goals'),row.get('away_goals')], 'raw_linescore_display_values':display,
                'identity_source_url':row.get('identity_source_url'),'identity_source_query_time_utc':row.get('identity_source_query_time_utc'),
                'identity_source_sha256':row.get('identity_source_sha256'),'eligible':ok,'reason':None if ok else ';'.join(errs)})

# Late seven: independently archived, explicit exclusion and never append to historical training JSONL.
late_evidence=[x for x in read_jsonl(LIVE/'final-90-evidence.jsonl') if x.get('league_slug')=='jpn.1']
late=[]; late_idx=[]
for e in late_evidence:
    eid=str(e['event_id']); rawp=LIVE/e['espn_summary_raw_path']; b=rawp.read_bytes(); digest=sha(b)
    er=[]
    if digest!=e['espn_summary_raw_sha256']: er.append('live_summary_sha256_mismatch')
    if e.get('status_name')!='STATUS_FULL_TIME' or e.get('completed') is not True or e.get('status_detail')!='FT': er.append('not_explicit_full_time')
    d=json.loads(b); header=d.get('header') or {}; comp=(header.get('competitions') or [{}])[0]
    if str(header.get('id'))!=eid: er.append('event_id_mismatch')
    if comp.get('date')!=e.get('event_date_utc'): er.append('kickoff_identity_mismatch')
    ex={'source_match_id':eid,'date':e.get('event_date_utc')}
    for side in e.get('competitors',[]): ex[side['side']+'_id']=str(side['team_id'])
    fake={'source_match_id':eid,'date':e.get('event_date_utc'),'home_id':ex.get('home_id'),'away_id':ex.get('away_id')}
    full,h1,h2,display,perr=extract_halves(d,fake,ex); er.extend(perr)
    for side in ('home','away'):
        actual=next((x for x in e['competitors'] if x['side']==side),{})
        if str(actual.get('score'))!=str(full[0 if side=='home' else 1]) if full else True: er.append(f'{side}_score_mismatch')
    er=list(dict.fromkeys(er))
    exclusion='2026-11-25_seven_late_j1_events_separate_from_2822_historical_training_population'
    late.append({'match_id':'espn:'+eid,'home_id':str(ex.get('home_id') or ''),'away_id':str(ex.get('away_id') or ''),'kickoff_utc':e.get('event_date_utc'),
                 'full':full,'half1':h1,'half2':h2,'source_sha256':digest,'eligible':False,'reason':exclusion+(';'+';'.join(er) if er else '')})
    late_idx.append({'match_id':'espn:'+eid,'home':next((x.get('display_name') for x in e['competitors'] if x['side']=='home'),None),
                     'away':next((x.get('display_name') for x in e['competitors'] if x['side']=='away'),None),'kickoff_utc':e.get('event_date_utc'),
                     'source_sha256':digest,'source_path':str(rawp),'source_url':e.get('espn_summary_url'),'capture_time_utc':e.get('espn_summary_capture_time_utc'),
                     'full':full,'half1':h1,'half2':h2,'raw_linescore_display_values':display,'eligible':False,'reason':late[-1]['reason']})

# Provenance for R15 shard parts, intake checkpoint and exact normalized baseline bytes.
inputs=[]
for p in [FINAL,R5,INTAKE/'checkpoints/final-checkpoint/snapshot-manifest.json',INTAKE/'checkpoints/final-checkpoint/coverage-audit.json']:
    b=p.read_bytes(); inputs.append({'path':str(p),'sha256':sha(b),'bytes':len(b)})
for name,meta in sorted(tar_meta.items()): inputs.append({'path':meta['path'],'sha256':meta['sha256'],'bytes':meta['bytes'],'kind':'R15_original_evidence_tar'})
for p in [LIVE/'final-90-evidence.jsonl']:
    b=p.read_bytes(); inputs.append({'path':str(p),'sha256':sha(b),'bytes':len(b)})
dump_jsonl(OUT/'matches.jsonl',rows)
dump_jsonl(OUT/'source-index.jsonl',idx)
dump_jsonl(OUT/'late-seven-excluded.jsonl',late)
dump_jsonl(OUT/'late-seven-source-index.jsonl',late_idx)

# Count disjoint failure reasons, including a full 2,822 denominator.
reason_counts={}
for x in rows:
    if not x['eligible']:
        for reason in x['reason'].split(';'):
            reason_counts[reason]=reason_counts.get(reason,0)+1
snapshot_manifest=json.loads((INTAKE/'checkpoints/final-checkpoint/snapshot-manifest.json').read_text())
coverage={'schema':'r20-j1-halves-coverage-v1','source_snapshot_as_of_utc':snapshot_manifest.get('snapshot_as_of_utc'),'population':'R5-registered J1 ESPN events in final-checkpoint/events.jsonl (2018-02-23 through 2026-11-21); 2822 is retained as denominator.',
          'rows':len(rows),'unique_match_ids':len({x['match_id'] for x in rows}),'eligible':sum(x['eligible'] for x in rows),'ineligible':sum(not x['eligible'] for x in rows),
          'failure_reason_event_counts':reason_counts,'ft90_confirmed_rows':sum(x.get('event_status')=='STATUS_FULL_TIME' and x.get('completed') is True and x.get('regulation_periods')==2 and x.get('regulation_final_status') is True and x.get('extra_time_indicated') is not True and x.get('shootout_indicated') is not True for x in final),'r5_membership_verified_rows':sum(x.get('r5_membership_verified') is True and r5_by.get(x['source_match_id'],{}).get('membership_verified') is True for x in final),'r5_date_and_side_identity_match_rows':sum(all(str(x.get(k))==str(r5_by.get(x['source_match_id'],{}).get(k)) for k in ('date','home_id','away_id','home','away')) for x in final),'raw_summary_sha256_verified_rows':sum(x['raw_body_sha256_verified'] for x in idx),'late_seven_separate_rows':len(late),'late_seven_all_eligible_false':all(not x['eligible'] for x in late),
          'late_seven_ids_absent_from_historical_rows':sorted(set(x['match_id'] for x in late).isdisjoint(x['match_id'] for x in rows) for _ in []) if False else len(set(x['match_id'] for x in late)&set(x['match_id'] for x in rows))==0,
          'source_raw_gzip_count':len(list((INTAKE/'raw/sha256').glob('*.json.gz'))),'r15_shard_member_count':sum(1 for p in R15.glob('part-*.tar') for _ in []),
          'source_roots':{'history_intake':str(INTAKE),'r15_original_evidence_shards':str(R15),'late_seven':str(LIVE)},
          'inputs':inputs,'notes':['No network access used.','No fitting or prediction outputs read.','The late seven are stored separately and are not training-eligible.','Where linescores lack period fields, their two-element array order is retained as first/second half.']}
# Correct shard member count without reopening after capture.
coverage['r15_shard_member_count']=sum(1 for name in tar_map)
(OUT/'coverage.json').write_text(json.dumps(coverage,ensure_ascii=False,indent=2)+'\n')
artifact_files=['matches.jsonl','source-index.jsonl','late-seven-excluded.jsonl','late-seven-source-index.jsonl','coverage.json','README.md','rebuild.py']
artifacts=[]
for name in artifact_files:
    b=(OUT/name).read_bytes(); artifacts.append({'path':name,'sha256':sha(b),'bytes':len(b)})
(OUT/'artifact-manifest.json').write_text(json.dumps({'schema':'r20-j1-halves-artifacts-v1','files':artifacts,'rows':{'matches':len(rows),'late_seven_excluded':len(late),'source_index':len(idx)}},ensure_ascii=False,indent=2)+'\n')
(OUT/'README.md').write_text('''# R20 J1 halves evidence intake\n\nOffline frozen evidence only. No predictions or model outputs were read and no fit was performed.\n\n## Training contract (`matches.jsonl`)\n\nOne row per one of the 2,822 registered historical events: `match_id` (`espn:<id>`), `home_id`, `away_id` (numeric strings), `kickoff_utc` (UTC ISO-8601), `full` (`[home,away]` regulation FT), `half1`, `half2`, `source_sha256`, `eligible`, `reason`. Numeric values are JSON integers or decimals. Every row stays in the denominator; ineligible rows have null half/full fields where source extraction failed and a semicolon-separated reason.\n\nThe strict pass requires exact final-checkpoint/R5 event identity, both team IDs, same kickoff instant, SHA-verified raw ESPN summary bytes, explicit completed FT, exactly two competitor linescore entries, valid nonnegative decimal `displayValue`s, optional period values matching 1 and 2, and each half sum equal to that side's regulation full score.\n\n## Raw evidence and offline rebuild\n\nThe original summary JSON bodies are not copied here. `source-index.jsonl` links every event to its SHA-verified gzip member. Preferentially these are members of the pre-existing R15 files in `workspace-updates/20261125-r15-j1-lineups/raw/part-*.tar`; any missing member falls back to the already retained intake `raw/sha256/<sha>.json.gz`. Their actual paths, member names, source response URLs/times, body SHA, identity scoreboard SHA, and R15 tar SHA are indexed. `rebuild.py` is offline and reconstructs all derived JSONL plus coverage from the three retained source roots.\n\nRun from this directory: `python rebuild.py`. It does not write to source directories.\n\n## Excluded Nov 25 seven\n\n`late-seven-excluded.jsonl` and `late-seven-source-index.jsonl` retain the seven independently captured ESPN FT summaries, but all seven have `eligible=false` and are outside the 2,822 historical denominator. Do not append these rows to the training corpus.\n''')
print(json.dumps({'historical_rows':len(rows),'eligible':sum(x['eligible'] for x in rows),'failure_events':len([x for x in rows if not x['eligible']]),'failure_reasons':reason_counts,'late_rows':len(late),'late_ids_intersection':len(set(x['match_id'] for x in late)&set(x['match_id'] for x in rows)),'r15_sources':sum(1 for x in idx if x['raw_origin'].get('kind')=='r15_original_evidence_shard'),'intake_fallbacks':sum(1 for x in idx if x['raw_origin'].get('kind')=='intake_raw_sha256')},ensure_ascii=False))
