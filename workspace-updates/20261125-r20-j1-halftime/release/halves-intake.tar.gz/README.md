# R20 J1 halves evidence intake

Offline frozen evidence only. No predictions or model outputs were read and no fit was performed.

## Training contract (`matches.jsonl`)

One row per one of the 2,822 registered historical events: `match_id` (`espn:<id>`), `home_id`, `away_id` (numeric strings), `kickoff_utc` (UTC ISO-8601), `full` (`[home,away]` regulation FT), `half1`, `half2`, `source_sha256`, `eligible`, `reason`. Numeric values are JSON integers or decimals. Every row stays in the denominator; ineligible rows have null half/full fields where source extraction failed and a semicolon-separated reason.

The strict pass requires exact final-checkpoint/R5 event identity, both team IDs, same kickoff instant, SHA-verified raw ESPN summary bytes, explicit completed FT, exactly two competitor linescore entries, valid nonnegative decimal `displayValue`s, optional period values matching 1 and 2, and each half sum equal to that side's regulation full score.

## Raw evidence and offline rebuild

The original summary JSON bodies are not copied here. `source-index.jsonl` links every event to its SHA-verified gzip member. Preferentially these are members of the pre-existing R15 files in `workspace-updates/20261125-r15-j1-lineups/raw/part-*.tar`; any missing member falls back to the already retained intake `raw/sha256/<sha>.json.gz`. Their actual paths, member names, source response URLs/times, body SHA, identity scoreboard SHA, and R15 tar SHA are indexed. `rebuild.py` is offline and reconstructs all derived JSONL plus coverage from the three retained source roots.

Run from this directory: `python rebuild.py`. It does not write to source directories.

## Excluded Nov 25 seven

`late-seven-excluded.jsonl` and `late-seven-source-index.jsonl` retain the seven independently captured ESPN FT summaries, but all seven have `eligible=false` and are outside the 2,822 historical denominator. Do not append these rows to the training corpus.
