"""Retain new evidence and reuse existing byte-verified long-lived assets."""
import os,json,hashlib,sys,tarfile,shutil,subprocess
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
R=Path(__file__).resolve().parent
REPO=Path('/workspace/kaka597000-Football-Analysis-Data')
DEST=REPO/'workspace-updates/20261114-nations-prematch'
sys.path.insert(0,'/workspace/Football-Analysis/scripts')
from check_repository import BINDINGS,PATTERNS
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):
 with Path(p).open('x') as h:json.dump(x,h,ensure_ascii=False,indent=2,allow_nan=False)
delivery=read(R/'delivery.json');source=delivery['source_commit']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd='/workspace/Football-Analysis').decode().strip()==source
assert not subprocess.check_output(['git','status','--porcelain'],cwd='/workspace/Football-Analysis').strip()
DEST.mkdir(exist_ok=False)
# Catalog only manifest-addressed, independently checksummed archives.
catalog={};archive_hashes={}
for folder in ['20261110-nations-model','20261113-nations-evening','20261114-nations-review']:
 root=REPO/'workspace-updates'/folder;m=read(root/'manifest.json')
 name=str((root/m['archive']).relative_to(REPO));assert sha(REPO/name)==m['archive_sha256']
 archive_hashes[name]=dict(sha256=m['archive_sha256'])
 for row in m.get('members',m.get('files',[])):
  path=row.get('original_path',row.get('path'));member=row.get('archive_member',row.get('archive_path'))
  if not path or not member:continue
  entry=dict(original_path=path,repository_archive=name,archive_member=member,sha256=row['sha256'])
  catalog[(str(Path(path).resolve()),row['sha256'])]=entry
 recovery=root/'recovery-map.json'
 if recovery.exists():
  old=read(recovery);archive_hashes.update(old['reused_archives'])
  for row in old['reused_files']:catalog[(str(Path(row['original_path']).resolve()),row['sha256'])]=row
paths={str(p):p for p in R.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
for rr in delivery['all_receipts']:
 for p in Path(rr['path']).parent.glob('[0-9]*.json'):paths[str(p)]=p
for p in [Path('/workspace/nations-model-20261110/models/candidates.json'),Path('/workspace/nations-model-20261110/models/protocol.json'),Path('/workspace/WCPP/runtime/active-model.json')]:paths[str(p)]=p
idx=read('/workspace/nations-model-20261110/models/candidates.json')
for route in idx['routes'].values():
 for ref in route.values():
  p=Path(ref['path']);assert sha(p)==ref['sha256'];paths[str(p)]=p
  d=read(p)
  for key in ['dataset_path','protocol_path']:
   q=Path(d[key]);paths[str(q)]=q
for name in ['odds.json','source-metadata.json']:
 p=Path('/workspace/WCPP/reports/nations-prematch-20261113-2118/market')/name;paths[str(p)]=p
new=[];reused=[];secrets=[os.environ[k].encode() for k in BINDINGS if os.environ.get(k) and len(os.environ[k])>=8]
scanned=0
for original,p in sorted(paths.items()):
 b=p.read_bytes();scanned+=1
 if any(v in b for v in secrets):raise ValueError('configured credential found; publication stopped')
 txt=b.decode('utf-8')
 for name,pattern in PATTERNS.items():
  for match in pattern.finditer(txt):
   if name=='literal_credential' and match.group(1).upper().startswith(('TEST_','SYNTHETIC_','EXAMPLE_')):continue
   raise ValueError('credential pattern found; publication stopped: '+name)
 digest=hashlib.sha256(b).hexdigest();prior=catalog.get((str(p.resolve()),digest))
 if prior and not p.is_relative_to(R):
  reused.append(dict(prior,original_path=original));continue
 new.append(dict(original_path=original,archive_member=str(Path(original).relative_to('/workspace')),sha256=digest,bytes=len(b)))
archive=DEST/'nations-prematch-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for e in new:t.add(e['original_path'],arcname=e['archive_member'],recursive=False)
used={e['repository_archive']:archive_hashes[e['repository_archive']] for e in reused}
for name,v in used.items():assert sha(REPO/name)==v['sha256']
recovery=dict(reused_archives=used,reused_files=reused,absolute_path_aliases={'/workspace/WCPP':'/workspace/recovered-workspace-20261102/WCPP'},no_frozen_path_or_hash_rewrite=True,source_checkout_separate=source,restore_notice='Stage first; reconcile the documented WCPP symlink without replacing existing user files. Source checkout and Python environment are separate. Staging verification is not a new production deployment.')
write(DEST/'recovery-map.json',recovery)
copies={'欧国联赛前分析.md':'report.md','比赛分析展示.csv':'比赛分析展示.csv','delivery.json':'delivery.json','source-audit.json':'source-audit.json','prose-correction.json':'prose-correction.json'}
for old,newname in copies.items():shutil.copy2(R/old,DEST/newname)
shutil.copy2(REPO/'workspace-updates/20261114-nations-review/verify_archive.py',DEST/'verify_archive.py')
(DEST/'README.md').write_text('''# 欧国联赛前分析｜2026年11月14日晚

[完整报告](report.md) · [CSV展示](比赛分析展示.csv) · [冻结回执](delivery.json) · [来源审计](source-audit.json)

范围8场：北京时间11月14日22:00至11月15日03:45。优先三场为科索沃1-0以色列、格鲁吉亚0-1匈牙利、葡萄牙2-1丹麦。比分与胜平负各8场，实际大小球5场明确方向、2场有盘口但观望、1场映射缺失。全部待结算。

活动欧国联Current/Test路由8次实测均拒绝输出；研究候选单独加载，11月10日首版不变，今晚追加v2，综合和TOP3另轨。21:14完成首版，21:16仅纠正一处文字阈值并追加修订，比分、方向、排名、盘口、模型数值均未变化。

保留8份当前比赛summary、8份首回合及8份最近一战过程、原始盘口、时点、来源哈希、诊断、逐轨冻结和脚本。七场合法盘口；瑞典—波黑别名未通过现有白名单，无合格总球线。未使用奥地利—冰岛错误事件。没有真实当前xG或可靠官方首发；未将空名单说成无人缺阵。

必要旧工件、原始候选首版、登记链与上一轮同盘报价复用已有长期归档；全部引用见recovery-map.json。运行 `python verify_archive.py --stage /tmp/NEW-nations-prematch-restore` 校验字节、冻结链并恢复到新暂存目录。源码须另checkout精确commit，WCPP符号链接映射需按recovery-map恢复，不改冻结内部路径和哈希。

本次没有源码、活动参数、注册表或环境发布变更；数据归档不触发源码CI。来源审计和恢复验证不等于准确率验收。
''')
sidecars=[dict(path=p.name,sha256=sha(p)) for p in sorted(DEST.iterdir()) if p.is_file() and p!=archive]
manifest=dict(schema='WCPP-NATIONS-PREMATCH-ARCHIVE-20261114',created_at_beijing=datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),source_commit=source,data_parent_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO).decode().strip(),archive=archive.name,archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,members=new,reused_files=len(reused),sidecar_files=sidecars,report_receipt=delivery['report_receipt'],top3_receipt=delivery['top3_receipt'],new_receipts=len(delivery['all_receipts']),credential_scan=dict(scanned_files=scanned,configured_bindings_checked=len(secrets),findings=0),active_model_changed=False,environment_published=False)
write(DEST/'manifest.json',manifest)
latest=read(REPO/'latest-source.json');key=str(DEST.relative_to(REPO))
assert latest['commit']==source
if key not in latest['additional_workspace_updates']:latest['additional_workspace_updates'].append(key)
latest['latest_nations_prematch']=key+'/manifest.json';latest['latest_nations_analysis']=key+'/report.md';latest['synchronized_at']=datetime.now(ZoneInfo('Asia/Shanghai')).isoformat()
latest['actual_runtime_versions']['manual_nations_prematch_commit']=source
latest['actual_runtime_versions']['manual_nations_prematch_freeze']=delivery['report_receipt']['freeze_id']
(REPO/'latest-source.json').write_text(json.dumps(latest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(destination=str(DEST),new_files=len(new),reused_files=len(reused),archives=len(used)+1,archive_bytes=manifest['archive_bytes'],credential_findings=0),ensure_ascii=False))
