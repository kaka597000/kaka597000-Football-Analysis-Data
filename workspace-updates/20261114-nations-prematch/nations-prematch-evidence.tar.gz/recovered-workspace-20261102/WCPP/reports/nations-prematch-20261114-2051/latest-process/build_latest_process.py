import json, hashlib, pathlib, datetime, re
ROOT=pathlib.Path('/workspace/WCPP/reports/nations-prematch-20261114-2051/latest-process')
CACHE=pathlib.Path('/workspace/nations-league-20261110/staging/raw/espn-summaries')
ids=['401861121','401861124','401861126','401861125','401861132','401861134','401861128','401861133']
def load(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def num(v):
    if v is None or v=='': return None
    try: return float(v) if '.' in str(v) else int(v)
    except (ValueError,TypeError): return v
rows=[]; cache_evidence=[]; reqs=[]
for eid in ids:
    raw=ROOT/f'summary-{eid}.raw.json'; dec=load(ROOT/f'summary-{eid}.decoded.json'); meta=load(ROOT/f'summary-{eid}.meta.json')
    h=dec['header']; comp=h['competitions'][0]
    if str(h['id'])!=eid or str(comp['id'])!=eid or h['league']['slug']!='uefa.nations': raise ValueError('source event identity mismatch '+eid)
    if comp['status']['type']['state']!='post' or comp['status']['type']['completed'] is not True: raise ValueError('event not completed '+eid)
    sides={x['homeAway']:x for x in comp['competitors']}
    if set(sides)!={'home','away'} or len(sides)!=2: raise ValueError('homeAway ambiguity '+eid)
    home_score=num(sides['home'].get('score')); away_score=num(sides['away'].get('score'))
    if not isinstance(home_score,(int,float)) or not isinstance(away_score,(int,float)): raise ValueError('score missing '+eid)
    date=datetime.datetime.fromisoformat(comp['date'].replace('Z','+00:00'))
    stats_by_side={}
    xg_present=[]
    for t in dec.get('boxscore',{}).get('teams',[]):
        side=t.get('homeAway')
        if side not in ('home','away'): raise ValueError('boxscore side unavailable '+eid)
        stat={x['name']:x.get('displayValue') for x in t.get('statistics',[]) if isinstance(x,dict) and x.get('name')}
        xg={k:v for k,v in stat.items() if 'xg' in k.lower() or 'expectedgoal' in k.lower() or 'expected_goal' in k.lower()}
        xg_present.extend({'team':t['team'].get('displayName'),'field':k,'value':v} for k,v in xg.items())
        metrics={'shots':num(stat.get('totalShots')),'shots_on_target':num(stat.get('shotsOnTarget')),
                 'corners':num(stat.get('wonCorners')),'possession_pct':num(stat.get('possessionPct')),
                 'saves':num(stat.get('saves')),'xg':None}
        metrics['xg_source_fields']=xg
        if not xg: metrics['xg_status']='MISSING_FROM_ESPN_SUMMARY'
        stats_by_side[side]={'team_id':str(t['team']['id']),'team_name':t['team'].get('displayName'),'metrics':metrics}
    if set(stats_by_side)!={'home','away'}: raise ValueError('team metric sides incomplete '+eid)
    # Retain only goal, penalty, and red-card key events; complete raw response remains alongside this extraction.
    key_events=[]
    for e in dec.get('keyEvents',[]):
        typ=(e.get('type') or {}).get('type','').lower()
        if not any(word in typ for word in ('goal','penalty','red-card','sending-off','second-yellow')): continue
        key_events.append({'event_id':str(e.get('id')),'type':(e.get('type') or {}).get('type'),'type_text':(e.get('type') or {}).get('text'),
          'text':e.get('text'),'short_text':e.get('shortText'),'clock':(e.get('clock') or {}).get('displayValue'),
          'period':(e.get('period') or {}).get('number'),'team_id':str((e.get('team') or {}).get('id')) if e.get('team') else None,
          'team_name':(e.get('team') or {}).get('displayName') if e.get('team') else None,
          'participants':[p.get('athlete',{}).get('displayName') for p in e.get('participants',[]) if p.get('athlete')],
          'scoring_play':e.get('scoringPlay'),'shootout':e.get('shootout'),'wallclock':e.get('wallclock')})
    row={'event_id':eid,'date_utc':date.astimezone(datetime.timezone.utc).isoformat(timespec='seconds'),
      'kickoff_bjt':date.astimezone(datetime.timezone(datetime.timedelta(hours=8))).isoformat(timespec='minutes'),
      'competition':'uefa.nations','season':h.get('season',{}).get('name'),'phase':'League Phase',
      'status':comp['status']['type'].get('detail'),'home_id':str(sides['home']['team']['id']),
      'home_name':sides['home']['team']['displayName'],'away_id':str(sides['away']['team']['id']),
      'away_name':sides['away']['team']['displayName'],'score_home_away':{'home':home_score,'away':away_score,'display':f'{home_score}-{away_score}',
        'basis':'header.competitions[].competitors where homeAway=home/away; not score_display'},
      'team_stats':{'home':stats_by_side['home'],'away':stats_by_side['away']},
      'xg_status':'PRESENT' if xg_present else 'MISSING_FROM_ALL_TEAM_BOX SCORE_STATISTICS'.replace(' ',''),
      'xg_source_fields':xg_present,'key_goal_red_penalty_events':key_events,
      'source':{'raw_file':raw.name,'raw_path':str(raw.resolve()),'sha256':sha(raw),'url':meta['source_url'],'requested_at':meta['requested_at'],'captured_at':meta['captured_at'],'http_status':meta['http_status']}}
    rows.append(row); reqs.append(meta)
    cp=CACHE/f'{eid}.json'
    if cp.is_file():
        cached=load(cp); cc=cached['header']['competitions'][0]
        cache_evidence.append({'event_id':eid,'path':str(cp),'sha256':sha(cp),'bytes':cp.stat().st_size,
          'identity_verified':str(cached['header'].get('id'))==eid and str(cc.get('id'))==eid,
          'completed_verified':cc.get('status',{}).get('type',{}).get('state')=='post' and cc.get('status',{}).get('type',{}).get('completed') is True,
          'cache_modified_at':datetime.datetime.fromtimestamp(cp.stat().st_mtime,datetime.timezone.utc).isoformat()})
(ROOT/'latest-process.json').write_text(json.dumps({'scope':'latest completed 2026-27 Nations League League Phase matches for the 16 target teams','request_count':len(rows),'matches':rows},ensure_ascii=False,indent=2)+'\n')
ledger={'source':'ESPN public summary JSON','request_count':len(reqs),'http_request_limit':8,'all_http_status_200':all(x['http_status']==200 for x in reqs),'retries':0,'same_host_serial_spacing_seconds_minimum':2,
 'cache_findings':{'path':str(CACHE),'requested_ids_found':len(cache_evidence),'note':'These FT raw copies were found in the specifically named cache directory after the 8 fresh summary requests had already completed; each cache file hash and event/completion identity is recorded below.'},
 'requests':reqs,'cached_raws':cache_evidence}
(ROOT/'source-ledger.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'events':len(rows),'cached_raws':len(cache_evidence),'xg_missing_matches':sum(x['xg_status']!='PRESENT' for x in rows),'key_events':sum(len(x['key_goal_red_penalty_events']) for x in rows)},ensure_ascii=False))
