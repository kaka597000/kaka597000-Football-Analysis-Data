"""Publish this source-bound prematch batch once, before kickoff; no fitting."""
import csv,hashlib,json,sys
from pathlib import Path
from datetime import datetime,timezone
from zoneinfo import ZoneInfo
import numpy as np
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from prediction_engine import predict_models
from research.analysis_freeze import save,verify
from research.team_goal_analysis import summarize_prediction
from research.score_distribution_audit import audit_prediction
from research.market_movement import analyze
from research_program.future_validation import quote_audit
from v2.model import total_settlement
R=Path(__file__).resolve().parent;F=Path('/workspace/WCPP/forecasts/issued-analyses');BJT=ZoneInfo('Asia/Shanghai')
SOURCE='1257fdde7b6746b7ba6d2aa919382214a2cfb589'
def read(p):return json.loads(Path(p).read_text())
def write(p,x):
 with Path(p).open('x') as h:json.dump(x,h,ensure_ascii=False,indent=2,allow_nan=False)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def now():return datetime.now(timezone.utc).isoformat()
def bt(t):return datetime.fromisoformat(t.replace('Z','+00:00')).astimezone(BJT).strftime('%m-%d %H:%M:%S')
def pct(v):return f'{v:.1%}'
fs=read(R/'prepared-fixtures.json');choices=read(R/'selections.json');recs=read(R/'candidate-update/receipts.json');forms=read(R/'verified-form.json');process=read(R/'verified-process.json');audit=read(R/'source-audit.json')
registry='/workspace/WCPP/runtime/active-model.json';registry_sha=sha(registry)
assert registry_sha=='923e34fc44cda33fe965498a24a2435abb37a01a80c539108d8ec20d490bf013'
assert len(fs)==len(recs)==len(choices)==8
assert len(process)==16 and audit['status']=='PASS'
source_checks=[]
for p in process:
 path=Path(p['source_path']);m=read(str(path).replace('.raw.json','.meta.json'))
 assert sha(path)==p['source_sha256']==m['sha256'];assert m['http_status']==200
 assert datetime.fromisoformat(m['requested_at'])<=datetime.fromisoformat(m['captured_at'])<datetime.now(timezone.utc)
 source_checks.append(dict(path=str(path),sha256=m['sha256'],query_time=m['captured_at']))
for f in fs:
 try:predict_models(dict(f,cutoff_at=now()))
 except ValueError as e:assert str(e)=='no validated identity/history model for this cohort'
 else:raise ValueError('active route changed; review before publication')
all_records=[]
for f,cr in zip(fs,recs):
 q=f.get('total_quote');choice=choices[f['source_event_id']]
 assert choice['expected_line']==(q['line'] if q else None)
 if q:assert quote_audit(dict(f,cutoff_at=now()))['eligible']
 pair=read(R/'candidate-update'/(f['match_id'].replace(':','-')+'.json'))
 if pair['current']['primary']==pair['test']['primary'] and choice['primary']!=pair['current']['primary']:
  assert len(set(choice['nonmarket_evidence_classes']))>=2
 failed=dict(status='ABSTAIN_NO_ACTIVE_ROUTE',matrix=None,primary=None,input=f)
 active=save(dict(current_model=dict(failed,model_label='当前模型'),test_model=dict(failed,model_label='test模型'),active_registry_sha256=registry_sha,candidate_substitution=False),dict(f,cutoff_at=now()),stage='prematch',track='current-test-pair',root=F)
 cand={}
 for role in ['current','test']:
  p=pair[role];cand[role]=dict(p,team_goal_analysis=summarize_prediction(p),score_distribution_audit=audit_prediction(p,choice['primary']))
  cand[role]['actual_total_settlement']={side:total_settlement(np.asarray(p['matrix']),q['line'],side) for side in ['over','under']} if q else None
 form=[x for x in forms if x['fixture_id']==f['source_event_id']]
 ids={x['team_id'] for x in form};latest_ids={max(x['games'],key=lambda y:y['date'])['id'] for x in form}
 context=[x for x in process if x['event_id'] in latest_ids or set(x['teams'])==ids]
 assert len(context)==3
 payload=dict(choice,selection_scope='candidate_research',method_version='WCPP-NATIONS-MANUAL-20261114-1',status='RESEARCH_COMPREHENSIVE',total_line=q['line'] if q else None,actual_quote=q,current_test_reference=active,candidate_reference=cr,candidate_status='UNACCEPTED_RESEARCH_ONLY',candidate_outputs=cand,selection_evidence={k:choice[k] for k in ['compared_scores','zero_vs_one','three_plus_path','total_reason']},sources={'fixture':f['phase_evidence'],'form':str(R/'verified-form.json'),'process':str(R/'verified-process.json'),'availability':str(R/'context/availability.json'),'market':str(R/'market/source-metadata.json'),'audit':str(R/'source-audit.json')},current_edition_form=form,process_evidence=context,market_movement=analyze(dict(f,cutoff_at=now())),xg_status='NO_VERIFIED_CURRENT_SAME_PROVIDER_XG',full_club_workload='NOT_VERIFIED',formal_kpi_eligible=False,active_model_promotion=False,numerical_weights_changed=False,exact_score_basis='regulation_90')
 comp=save(payload,dict(f,cutoff_at=now()),stage='prematch',track='comprehensive',root=F)
 record=verify(read(comp['path']));assert record['selection_audit']['top3_ready']
 all_records.append(dict(fixture=f,payload=payload,candidate_receipt=cr,active_receipt=active,comprehensive_receipt=comp))
byid={x['fixture']['source_event_id']:x for x in all_records}
topids=['401861163','401861164','401861167']
topitems=[]
topreasons=['两队进球产量低，科索沃最新射正占优，1-0与1-1之间优先前者；以色列客场连续进球是主要反证。','格鲁吉亚四场无进球且最新仅2次射正，匈牙利上轮客胜；0-0是最重要风险。','葡萄牙连续赢球与射正过程占优，但丹麦保持得分能力，优先2-1；四球尾部与人员资格仍有风险。']
for i,id in enumerate(topids):
 x=byid[id];p=x['payload'];topitems.append(dict(rank=i+1,match_id=x['fixture']['match_id'],**{k:p[k] for k in ['primary','wdl','total_line','total_direction']},comprehensive_reference=x['comprehensive_receipt'],reason=topreasons[i],risk=p['counter']))
shell=dict(match_id='nations-analysis-batch:20261114-evening',cohort='uefa.nations',kickoff_at=min(f['kickoff_at'] for f in fs),cutoff_at=now())
top=save(dict(selection_scope='candidate_research',population=[f['match_id'] for f in fs],top3=topitems,ranking_basis='综合比分研究优先级，依据当前进攻/防守证据与反证；不是已校准命中率排名，不追求方向分散',formal_kpi_eligible=False,active_model_promotion=False),shell,stage='prematch',track='top3-selection',root=F)
lines=['# 欧国联赛前分析｜2026年11月14日晚','',
 'HELLO BOSS','',
 '今晚8场：科索沃—以色列北京时间11月14日22:00；其余7场在11月15日01:00或03:45。全部为成年男子2026-27欧国联联赛阶段，A组级别2场、B组级别6场，按90分钟含补时结算。已结束比赛未混入赛前样本。','',
 '本版优先三场：科索沃1-0以色列、格鲁吉亚0-1匈牙利、葡萄牙2-1丹麦。排名以唯一比分的证据与反证为依据，仍是研究判断，不能解释成已验证的高命中率。','',
 '欧国联尚无通过验收的活动Current/Test路由。本次实际调用8场均返回不可用并单独冻结；以下数值来自可加载、未晋级的两套独立研究候选。Current只拟合分级均值和主场项；Test另拟合球队攻防，时间半衰期730日、正则8。两者没有训练好的xG、人员或盘口数值模块。综合判断不改任何模型矩阵、权重或活动注册表。','',
 '候选训练截止10月6日；已逐场核实今晚16队本届各4场、共64条球队赛果均存在于对应训练数据，不能仅凭40天日历间隔宣称漏训新比赛。完整俱乐部负荷未知。11月10日候选首版保留，本次追加v2且数值矩阵一致，不增加独立比赛分母。','',
 '已核对8份本场赛程、8份首回合详细过程与8份最近一战详细过程。16份过程原文都未提供真实xG；射门不是xG。科索沃比赛北京时间21:00刷新仍没有首发球员名单；本批其余首发与最新伤停也未得到可靠确认，空名单不作健康证明。','',
 '盘口来源The Odds API：Pinnacle报价北京时间20:55:02；奥地利—爱尔兰采用LeoVegas 20:54:31；实际抓取20:55:11。7/8场、195条机构市场观测通过身份、时间及原文哈希检查，不是195个独立比赛样本。瑞典—波黑保留未通过别名映射的缺项；错误的奥地利—冰岛事件未使用。','',
 '## 全部比赛','',
 '|北京时间|比赛|Current候选|Test候选|综合唯一比分|胜平负|实际大小球倾向|',
 '|---|---|---|---|---|---|---|']
for x in all_records:
 f,p=x['fixture'],x['payload'];t=p['total_line'];ou='观望（无合格线）' if t is None else f"{p['total_direction']} {t:g}"
 lines.append(f"|{bt(f['kickoff_at'])[:11]}|{p['name']}|{p['candidate_outputs']['current']['primary']}|{p['candidate_outputs']['test']['primary']}|**{p['primary']}**|{p['wdl']}|{ou}|")
lines+=['','胜平负以主/平/客结果集合独立评估，不强制等于单一比分方向。瑞典1-1与主胜倾向的区别是：前者比较每个精确比分，后者汇总所有主胜比分；两项分别冻结、分别结算。大小球也不由第一比分总和直接推出。','',
 '## 研究TOP3','', '|顺序|比赛|唯一比分|胜平负|大小球|排序理由与主要反证|','|---|---|---|---|---|---|']
for i,id in enumerate(topids):
 p=byid[id]['payload'];lines.append(f"|{i+1}|{p['name']}|{p['primary']}|{p['wdl']}|{p['total_direction']} {p['total_line']:g}|{topreasons[i]}|")
lines+=['','TOP3是三场比赛各一个比分，不是每场三个比分；完整8场另行评价。小2遇2球走盘；小3.25遇3球半赢；小2.5遇3球全输。未开赛，不预填命中率或收益。','']
for x in all_records:
 f,p=x['fixture'],x['payload'];q=p['actual_quote']
 lines+=['## '+p['name'],'',f"北京时间{bt(f['kickoff_at'])[:11]}，{f['league_level']}级联赛阶段。",'',
 '|候选|主队均值／中央80%区间|主队0球／≥2球／≥3球|客队均值／中央80%区间|客队0球／≥2球／≥3球|主胜／平局／客胜|','|---|---|---|---|---|---|']
 for role in ['current','test']:
  pred=p['candidate_outputs'][role];g=pred['team_goal_analysis'];cells=[]
  for side in ['home','away']:
   z=g[side];ci=z['central_interval'];cells+=[f"{z['mean']:.2f} / {ci['lower']}–{ci['upper']}球",' / '.join(pct(z[k]) for k in ['p0','p_ge_2','p_ge_3'])]
  cells+=[' / '.join(pct(pred['wdl'][k]) for k in ['主胜','平局','客胜'])];lines.append('|'+role+'|'+'|'.join(cells)+'|')
 lines+=['','以上均值和区间来自候选分布，不是提供方xG、已校准置信区间或人工综合概率。','',
 '本届4场窗口：'+'；'.join(f"{z['team']} {z['overall']['W']}胜{z['overall']['D']}平{z['overall']['L']}负，进{z['overall']['GF']}失{z['overall']['GA']}" for z in p['current_edition_form'])+'。','',
 '**综合判断：**'+p['reason'],'','**反证：**'+p['counter'],'',
 '比较比分：'+'、'.join(p['compared_scores'])+'；只有综合唯一比分计入该轨Top1，其他比分不补算命中。',
 '三球以上路径：'+p['three_plus_path']]
 for side,z in p['zero_vs_one'].items():lines+=['','零球对比一球（'+('主队' if side=='home' else '客队')+'）：'+z['reason']+' 反证：'+z['counterevidence']]
 lines+=['','大小球独立判断：'+p['total_reason']]
 if q:
  market=[z for z in f['market_snapshots'] if z['market']=='1x2'][-1]
  h=market['decimal_odds'];nv={k:(1/v)/sum(1/w for w in h.values()) for k,v in h.items()}
  lines+=['',f"实际机构 `{q['bookmaker']}`：主{h['home']}／平{h['draw']}／客{h['away']}；1X2简单去水约{pct(nv['home'])}／{pct(nv['draw'])}／{pct(nv['away'])}，只是市场价格参考。总球{q['line']:g}，大{q['over_odds']}／小{q['under_odds']}；报价{bt(q['quoted_at'])}，抓取{bt(q['query_time'])}。"]
  if p['total_direction'] in ['大','小']:
   side='over' if p['total_direction']=='大' else 'under'
   lines+=['','所选真实盘线的候选结算概率（不冒充人工综合概率）：','', '|候选|全赢|半赢|走盘|半输|全输|','|---|---|---|---|---|---|']
   for role in ['current','test']:
    s=p['candidate_outputs'][role]['actual_total_settlement'][side];lines.append('|'+role+'|'+'|'.join(pct(s[k]) for k in ['win','half_win','push','half_loss','loss'])+'|')
  for c in p['market_movement'].get('comparisons',[]):
   label='1X2（主/平/客）' if c['market']=='1x2' else f"总球{c['line']:g}（大/小）"
   keys=['home','draw','away'] if c['market']=='1x2' else ['over','under']
   fmt=lambda v:' / '.join(str(v[k]) for k in keys)
   lines+=['',f"同机构同盘历史对照：{label}，{bt(c['first_quoted_at'])} 的 {fmt(c['first_decimal_odds'])} → {bt(c['last_quoted_at'])} 的 {fmt(c['last_decimal_odds'])}。"]
  totals=[z for z in f['market_snapshots'] if z['market']=='totals']
  if len(totals)==2 and totals[0]['line']!=totals[1]['line']:lines+=['',f"总球从{totals[0]['line']:g}变为{totals[1]['line']:g}，仅记录换线，不作同盘水位变化比较。"]
  lines+=['','报价变化不等于资金流、内幕或独立非市场证据。']
 lines+=['','人员情景：'+p['availability'],'','可查过程来源：']
 for proc in p['process_evidence']:
  teams=list(proc['teams'].values());title='—'.join(t['name'] for t in teams)
  lines+=['- ['+title+']('+proc['source_url']+')，北京时间'+bt(proc['date'])[:11]+'，'+('首回合' if proc['window']=='FIRST_LEG' else '最近一战')+'。']
 lines+=['',f"综合冻结 `{x['comprehensive_receipt']['freeze_id']}`，北京时间{bt(x['comprehensive_receipt']['recorded_at'])}；候选 `{x['candidate_receipt']['freeze_id']}`。",'']
lines+=['## 审计与后续结算','',
 f"独立来源/赛果方向/矩阵/市场校验通过{audit['assertions_passed']}项断言，另逐一核验16份过程原文的下载元数据及SHA。文档完整性与数据检查不代表模型通过效果验收。",
 '同源点球聚合字段与真实进球事件、部分扑救与对方射正存在冲突：点球识别用原始事件，冲突字段不用于推断门将状态或虚构xG。详见verified-process.json。',
 '过程采集初稿曾把score_display当本队方向，已保留初稿与v2并由根代理从球队ID及进球字段重建；正式结论未使用错误文字。采集请求总数如实记账：赛程9次、市场1次、背景17次（含3次超预算诊断调用）、最新过程8次；部分本地FT缓存是在新请求后才发现，未把重复抓取说成新增独立证据。',
 '活动路由拒绝、Current候选、Test候选、综合Primary、TOP3、报告分别留存。当前批次所有比赛、各方向覆盖与弃权均保留，候选首版和v2分列；赛后不得择优切换版本或备选比分。',
 '大小球仅5场明确方向、2场有实盘但观望、1场无合格盘线；比分与胜平负均8场。后续按各自分母结算，大小球全赢/半赢/走盘/半输/全输分别统计。',
 '未修改模型参数、注册表、旧冻结；未发布环境。源码版本：`'+SOURCE+'`。','']
report='\n'.join(lines)
rp=save(dict(report_markdown=report,comprehensive_receipts=[x['comprehensive_receipt'] for x in all_records],top3_receipt=top,source_commit=SOURCE,formal_kpi_eligible=False),dict(shell,cutoff_at=now()),stage='prematch',track='analysis-report',root=F)
with (R/'欧国联赛前分析.md').open('x') as h:h.write(report)
write(R/'analysis-records.json',all_records)
receipts=[x[k] for x in all_records for k in ['candidate_receipt','active_receipt','comprehensive_receipt']]+[top,rp,read(R/'candidate-update/plan-receipt.json')]
for rr in receipts:
 rec=verify(read(rr['path']));assert rec['record_sha256']==rr['sha256']
 if rec['stage']=='prematch':assert datetime.fromisoformat(rec['recorded_at'])<datetime.fromisoformat(rec['fixture']['kickoff_at'])
assert sha(registry)==registry_sha
write(R/'delivery.json',dict(report_receipt=rp,top3_receipt=top,all_receipts=receipts,population=8,comprehensive_scores=8,wdl_selections=8,total_selections=5,total_qualified_quotes=7,total_abstentions=3,top3_count=3,source_commit=SOURCE,active_registry_sha256=registry_sha,active_registry_changed=False,verified_all_receipts=True,all_before_kickoff=True,source_checks=source_checks))
with (R/'比赛分析展示.csv').open('x',encoding='utf-8-sig',newline='') as h:
 w=csv.writer(h);w.writerow(['北京时间','比赛','Current候选','Test候选','综合唯一比分','胜平负','大小球方向','实际盘线','机构','大赔率','小赔率','报价北京时间','综合冻结ID'])
 for x in all_records:
  f,p=x['fixture'],x['payload'];q=p['actual_quote'] or {};w.writerow([bt(f['kickoff_at']),p['name'],p['candidate_outputs']['current']['primary'],p['candidate_outputs']['test']['primary'],p['primary'],p['wdl'],p['total_direction'],q.get('line'),q.get('bookmaker'),q.get('over_odds'),q.get('under_odds'),bt(q['quoted_at']) if q else None,x['comprehensive_receipt']['freeze_id']])
print(json.dumps(dict(report=str(R/'欧国联赛前分析.md'),report_freeze=rp,top3_freeze=top,verified_receipts=len(receipts)),ensure_ascii=False))
