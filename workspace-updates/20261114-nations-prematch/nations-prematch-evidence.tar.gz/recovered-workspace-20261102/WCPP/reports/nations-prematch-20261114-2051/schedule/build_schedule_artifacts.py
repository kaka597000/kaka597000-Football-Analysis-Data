import json, hashlib, pathlib, datetime, re
ROOT=pathlib.Path('/workspace/WCPP/reports/nations-prematch-20261114-2051/schedule')
def read(name): return json.loads((ROOT/name).read_text())
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
board=read('scoreboard-20261114.decoded.json')
boardmeta=read('scoreboard-20261114.meta.json')
ids=[str(e['id']) for e in board.get('events',[])]
assert len(ids)==len(set(ids))
assert {x.get('slug') for x in board.get('leagues',[])}=={'uefa.nations'}
# Real capture-derived current cutoff: all retained summary sources precede it.
summary_metas=[read(f'summary-{eid}.meta.json') for eid in ids]
assert len(summary_metas)==len(ids) and all(m.get('http_status')==200 for m in summary_metas)
cutoff=datetime.datetime.now(datetime.timezone.utc).isoformat()
fixtures=[]; team_sources={}; event_index={str(e['id']):e for e in board['events']}
for eid in ids:
    summary=read(f'summary-{eid}.decoded.json'); meta=read(f'summary-{eid}.meta.json')
    h=summary['header']; c=h['competitions'][0]; e=event_index[eid]
    assert str(h['id'])==eid and len(h['competitions'])==1 and str(c['id'])==eid
    assert h['league']['slug']=='uefa.nations'
    assert h['season']['name']=='2026-27 UEFA Nations League, League Phase'
    assert e['status']['type']['state']=='pre' and e['status']['type']['completed'] is False
    assert c['status']['type']['state']=='pre' and c['status']['type']['completed'] is False
    assert c['date']==e['date']
    level=re.fullmatch(r'Group ([ABCD])[1-4]', c['competitors'][0]['groups']['abbreviation']).group(1)
    assert all(x['groups']['abbreviation']==f'Group {level}{c["competitors"][0]["groups"]["abbreviation"][-1]}' for x in c['competitors'])
    sides={x['homeAway']:x['team'] for x in c['competitors']}
    assert set(sides)=={'home','away'} and sides['home']['id']!=sides['away']['id']
    neutral=c.get('neutralSite'); assert type(neutral) is bool
    dt=datetime.datetime.fromisoformat(c['date'].replace('Z','+00:00')).astimezone(datetime.timezone.utc)
    rawpath=(ROOT/f'summary-{eid}.raw.json').resolve()
    fixture={'match_id':'espn:'+eid,'source_event_id':eid,'competition':'uefa.nations','gender':'men','age':'senior','entity':'national',
      'cohort':f'uefa.nations:{level}:league-phase','league_level':level,'stage':'league-phase',
      'home':'espn:'+str(sides['home']['id']),'away':'espn:'+str(sides['away']['id']),
      'date':dt.date().isoformat(),'kickoff_at':dt.isoformat(timespec='seconds'),'phase':'PreMatch','neutral':neutral,
      'cutoff_at':cutoff,
      'phase_evidence':{'source_path':str(rawpath),'source_sha256':sha(rawpath),'source_url':meta['source_url'],'query_time':meta['captured_at']}}
    fixtures.append(fixture)
    # Build each team's source-audited recent league-phase window from API team IDs.
    for tg in summary.get('lastFiveGames',[]):
        tid=str(tg['team']['id']); tname=tg['team']['displayName']
        prior=team_sources.setdefault(tid,{'team_id':'espn:'+tid,'team_name':tname,'fixture_event_ids':[],'source_refs':[],'last_five_events':[]})
        if eid not in prior['fixture_event_ids']: prior['fixture_event_ids'].append(eid)
        if eid not in [x['event_id'] for x in prior['source_refs']]:
            prior['source_refs'].append({'event_id':eid,'source_path':str(rawpath),'source_sha256':sha(rawpath),'source_url':meta['source_url'],'query_time':meta['captured_at']})
        for x in tg.get('events',[]):
            if not any(z['event_id']==str(x.get('id')) and z['queried_for_event']==eid for z in prior['last_five_events']):
                prior['last_five_events'].append({'queried_for_event':eid,'event_id':str(x.get('id')),'date':x.get('gameDate'),
                  'competition':x.get('competitionName'),'phase':x.get('roundName'),'home_team_id':str(x.get('homeTeamId')),
                  'away_team_id':str(x.get('awayTeamId')),'home_goals':x.get('homeTeamScore'),'away_goals':x.get('awayTeamScore'),
                  'score':x.get('score'),'opponent':x.get('opponent',{}).get('displayName'),'opponent_id':str(x.get('opponent',{}).get('id')),
                  'source_game_result':x.get('gameResult'),'include_current_nations_phase':x.get('competitionName')=='2026-27 UEFA Nations League' and x.get('roundName')=='League Phase'})
(ROOT/'fixtures.json').write_text(json.dumps(fixtures,ensure_ascii=False,indent=2)+'\n')
# Aggregate once per event per team from that team's original ESPN lastFiveGames block.
forms=[]
for tid,src in team_sources.items():
    # repeated match entries can come from multiple requested fixture summaries; they must agree.
    unique={}
    for x in src['last_five_events']:
        k=x['event_id']
        sig={key:x[key] for key in ('date','competition','phase','home_team_id','away_team_id','home_goals','away_goals','score','opponent','opponent_id')}
        if k in unique and unique[k]!=sig: raise ValueError(f'conflicting repeated event {k} / team {tid}')
        unique[k]=sig
    rows=[]
    for eid,x in unique.items():
        home,away=x['home_team_id'],x['away_team_id']
        if tid not in (home,away): raise ValueError(f'target team absent from source event {eid}')
        if str(x['opponent_id']) != (away if tid==home else home): raise ValueError(f'opponent id contradiction {eid}')
        if not isinstance(x['opponent'],str) or not x['opponent']: raise ValueError(f'missing source opponent name {eid}')
        try: hg=int(x['home_goals']); ag=int(x['away_goals'])
        except (ValueError,TypeError): continue
        # Preserve ESPN's original score field; score columns are interpreted only through the event's home/away IDs.
        phase_match=x['competition']=='2026-27 UEFA Nations League' and x['phase']=='League Phase'
        row={'event_id':eid,**x,'included':phase_match,'exclusion_reason':None if phase_match else ('WORLD_CUP' if x['competition'] and 'World Cup' in x['competition'] else 'OUTSIDE_2026_27_NATIONS_LEAGUE_LEAGUE_PHASE')}
        if phase_match:
            home_side=tid==home; gf=hg if home_side else ag; ga=ag if home_side else hg
            row.update(team_venue='home' if home_side else 'away',goals_for=gf,goals_against=ga,
                       result='W' if gf>ga else ('D' if gf==ga else 'L'),total_goals=hg+ag,
                       score_home_away=f'{hg}-{ag}',score_by_team_id=f'{gf}-{ga}',
                       source_score_matches_home_away=(x['score']==f'{hg}-{ag}' if x['score'] else None),
                       source_score_matches_away_home=(x['score']==f'{ag}-{hg}' if x['score'] else None),
                       source_score_matches_team_id_score=(x['score']==f'{gf}-{ga}' if x['score'] else None),
                       source_score_orientation=('home-away' if x['score']==f'{hg}-{ag}' else ('away-home' if x['score']==f'{ag}-{hg}' else 'unresolved' if x['score'] else 'missing')))
        rows.append(row)
    selected=sorted((x for x in rows if x['included']),key=lambda x:x['date'])
    def summarize(group):
        return {'played':len(group),'wins':sum(x['result']=='W' for x in group),'draws':sum(x['result']=='D' for x in group),'losses':sum(x['result']=='L' for x in group),
          'goals_for':sum(x['goals_for'] for x in group),'goals_against':sum(x['goals_against'] for x in group),
          'zero_goals_for':sum(x['goals_for']==0 for x in group),'clean_sheets':sum(x['goals_against']==0 for x in group),
          'three_plus_total_goals':sum(x['total_goals']>=3 for x in group)}
    forms.append({'team_id':src['team_id'],'team_name':src['team_name'],'window':'2026-27 UEFA Nations League / League Phase only',
      'last_five_event_count':len(rows),'excluded_non_window_count':sum(not x['included'] for x in rows),'league_phase_matches':len(selected),
      'league_phase_record':summarize(selected),'home':summarize([x for x in selected if x['team_venue']=='home']),
      'away':summarize([x for x in selected if x['team_venue']=='away']),
      'matches':sorted(rows,key=lambda x:x['date']),'source_refs':src['source_refs']})
(ROOT/'team-last-five-nations-phase.json').write_text(json.dumps(forms,ensure_ascii=False,indent=2)+'\n')
# Article triage: API-returned news only; no page fetching. Flag only target-team + injury/availability clues.
teams=[x['team_name'] for x in forms]
injury_terms=('injury','injured','injury doubt','ruled out','suspended','suspension','doubt','fitness','misses','absent','hamstring','ankle','knee','伤','停赛','缺阵')
leads=[]; news_meta=[]
for eid in ids:
    d=read(f'summary-{eid}.decoded.json'); m=read(f'summary-{eid}.meta.json')
    news_meta.append({'event_id':eid,'summary_source_path':str((ROOT/f'summary-{eid}.raw.json').resolve()),'summary_sha256':m['sha256'],'query_time':m['captured_at']})
    for article in d.get('news',{}).get('articles',[]):
        title=article.get('headline') or article.get('title') or ''
        text=(title+' '+str(article.get('description',''))).lower()
        target=next((n for n in teams if n.lower() in text),None)
        if target and any(term in text for term in injury_terms):
            links=article.get('links',{}); web=links.get('web',{}) if isinstance(links,dict) else {}
            leads.append({'target_team':target,'headline':title,'published_at':article.get('published'),'url':web.get('href'),'source_summary_event_id':eid,'source_query_time':m['captured_at']})
(ROOT/'news-injury-leads.json').write_text(json.dumps({'triage':'ESPN summary API article metadata only; no article page/web fetch performed','leads':leads,'summary_sources':news_meta},ensure_ascii=False,indent=2)+'\n')
# Retained-source ledger and concise per-summary inventory.
ledger={'cutoff_at':cutoff,'source':'ESPN public JSON','requests':[{'kind':'scoreboard',**boardmeta}]+summary_metas,'http_failures':[],'source_order':'one scoreboard first, then event summaries serially on the same ESPN host with >=2s capture-to-next-request spacing; no retries'}
(ROOT/'source-ledger.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n')
manifest={'cutoff_at':cutoff,'source':'ESPN','summary_count':len(summary_metas),'event_ids':ids,'summaries':[{'event_id':m['event_id'],'raw_file':m['raw_file'],'decoded_file':f"summary-{m['event_id']}.decoded.json",'meta_file':f"summary-{m['event_id']}.meta.json",'http_status':m['http_status'],'requested_at':m['requested_at'],'captured_at':m['captured_at'],'sha256':m['sha256'],'bytes':m['bytes']} for m in summary_metas]}
(ROOT/'summary_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'cutoff_at':cutoff,'fixtures':len(fixtures),'forms':len(forms),'news_leads':len(leads),'levels':{l:sum(f['league_level']==l for f in fixtures) for l in 'ABCD'}},ensure_ascii=False))
