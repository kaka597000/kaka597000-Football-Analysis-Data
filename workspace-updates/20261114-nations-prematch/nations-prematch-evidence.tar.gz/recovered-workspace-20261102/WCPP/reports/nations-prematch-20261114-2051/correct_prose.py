"""Append a factual wording correction without changing forecasts or old freezes."""
import json,sys,shutil
from pathlib import Path
from datetime import datetime,timezone
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from research.analysis_freeze import save,verify
R=Path(__file__).resolve().parent;F=Path('/workspace/WCPP/forecasts/issued-analyses')
def read(p):return json.loads(Path(p).read_text())
def write(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False))
def now():return datetime.now(timezone.utc).isoformat()
prior=R/'pre-correction';prior.mkdir(exist_ok=False)
for name in ['analysis-records.json','delivery.json','欧国联赛前分析.md','比赛分析展示.csv']:shutil.copy2(R/name,prior/name)
all_records=read(R/'analysis-records.json');delivery=read(R/'delivery.json')
x=next(x for x in all_records if x['fixture']['source_event_id']=='401861163')
old=x['comprehensive_receipt'];oldtext=x['payload']['three_plus_path']
newtext=oldtext.replace('两候选总球至少3的质量均不足四成','两候选总球至少3的概率分别为40.6%和37.1%，约四成')
assert oldtext!=newtext
x['payload']['three_plus_path']=newtext;x['payload']['selection_evidence']['three_plus_path']=newtext
x['payload']['text_correction']=dict(previous_reference=old,reason='Current 40.6% is not below 40%; replace incorrect threshold wording with exact rounded values.',predictions_and_probabilities_unchanged=True)
new=save(x['payload'],dict(x['fixture'],cutoff_at=now()),stage='prematch',track='comprehensive',root=F);x['comprehensive_receipt']=new
oldtop=verify(read(delivery['top3_receipt']['path']));tp=oldtop['payload']
for item in tp['top3']:
 if item['match_id']==x['fixture']['match_id']:item['comprehensive_reference']=new
tp['text_correction_only']=True
top=save(tp,dict(oldtop['fixture'],cutoff_at=now()),stage='prematch',track='top3-selection',root=F)
report=(R/'欧国联赛前分析.md').read_text().replace(oldtext,newtext).replace(old['freeze_id'],new['freeze_id'])
oldtime=datetime.fromisoformat(old['recorded_at']).strftime('%m-%d %H:%M:%S');newtime=datetime.fromisoformat(new['recorded_at']).strftime('%m-%d %H:%M:%S')
report=report.replace(f"综合冻结 `{new['freeze_id']}`，北京时间{oldtime}",f"综合冻结 `{new['freeze_id']}`，北京时间{newtime}")
report+='\n校对修订：科索沃段原稿“均不足四成”改为“40.6%和37.1%，约四成”。仅修正文字阈值；所有推荐、排名、盘口及数值不变。原始冻结和文稿完整保留，综合、TOP3及报告追加修订。\n'
rp=save(dict(report_markdown=report,comprehensive_receipts=[a['comprehensive_receipt'] for a in all_records],top3_receipt=top,source_commit=delivery['source_commit'],formal_kpi_eligible=False,text_correction_only=True,previous_report_receipt=delivery['report_receipt']),dict(oldtop['fixture'],cutoff_at=now()),stage='prematch',track='analysis-report',root=F)
delivery.update(report_receipt=rp,top3_receipt=top,text_correction_only=True,original_recommendations_unchanged=True)
delivery['all_receipts'] += [new,top,rp]
for r in delivery['all_receipts']:assert verify(read(r['path']))['record_sha256']==r['sha256']
write(R/'analysis-records.json',all_records);write(R/'delivery.json',delivery)
(R/'欧国联赛前分析.md').write_text(report)
p=R/'比赛分析展示.csv';p.write_bytes(p.read_bytes().replace(old['freeze_id'].encode(),new['freeze_id'].encode()))
write(R/'prose-correction.json',dict(old=old,new=new,old_text=oldtext,new_text=newtext,report=rp,top3=top,predictions_unchanged=True))
print(json.dumps(dict(report_freeze=rp['freeze_id'],recorded_at=rp['recorded_at'],receipts=len(delivery['all_receipts'])),ensure_ascii=False))
