"""Source-bound, append-only Nations prematch preparation. No fitting or network."""
import json, hashlib, sys
from pathlib import Path
from datetime import datetime, timezone
sys.path.insert(0, '/workspace/Football-Analysis/runtime')
from automation.market_bridge import attach_total_quote
from nations_league import safe_cli
from research.team_goal_analysis import summarize_prediction
from research.score_distribution_audit import audit_prediction
from research_program.future_validation import quote_audit
from research.analysis_freeze import verify
R = Path(__file__).resolve().parent
F = Path('/workspace/WCPP/forecasts/issued-analyses')
def read(p): return json.loads(Path(p).read_text())
def write(p, x):
    with Path(p).open('x') as h: json.dump(x, h, ensure_ascii=False, indent=2, allow_nan=False)
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
now = datetime.now(timezone.utc)
fixtures = read(R/'schedule/fixtures.json')
assert len(fixtures) == len({f['match_id'] for f in fixtures}) == 8
meta = read(R/'market/source-metadata.json')
for m in meta['odds'], meta['identity']:
    assert sha(R/'market'/m['file']) == m['sha256']
board = read(R/'schedule/scoreboard-20261114.raw.json')
assert sha(R/'market/identity.json') == sha(R/'schedule/scoreboard-20261114.raw.json')
assert {f['source_event_id'] for f in fixtures} == {e['id'] for e in board['events']}
forms = []
for f in fixtures:
    raw = read(f['phase_evidence']['source_path'])
    assert sha(f['phase_evidence']['source_path']) == f['phase_evidence']['source_sha256']
    c = raw['header']['competitions'][0]
    assert str(c['id']) == f['source_event_id']
    assert c['status']['type']['state'] == 'pre' and c['status']['type']['completed'] is False
    assert datetime.fromisoformat(c['date'].replace('Z','+00:00')) == datetime.fromisoformat(f['kickoff_at'])
    assert c['neutralSite'] == f['neutral']
    assert {s['homeAway']: 'espn:'+str(s['team']['id']) for s in c['competitors']} == {s:f[s] for s in ['home','away']}
    for t in raw['lastFiveGames']:
        tid = str(t['team']['id']); games = []
        for e in t['events']:
            if e.get('competitionName') != '2026-27 UEFA Nations League' or e.get('roundName') != 'League Phase': continue
            ishome = str(e['homeTeamId']) == tid
            assert ishome or str(e['awayTeamId']) == tid
            assert datetime.fromisoformat(e['gameDate'].replace('Z','+00:00')) < now
            gf,ga = map(int, (e['homeTeamScore'],e['awayTeamScore']) if ishome else (e['awayTeamScore'],e['homeTeamScore']))
            games.append(dict(id=str(e['id']),date=e['gameDate'],home=ishome,gf=gf,ga=ga,opponent=e['opponent']['displayName'],opponent_id=str(e['opponent']['id'])))
        assert len(games) == 4 and len({g['id'] for g in games}) == 4
        stats = lambda rows: dict(n=len(rows),W=sum(g['gf']>g['ga'] for g in rows),D=sum(g['gf']==g['ga'] for g in rows),L=sum(g['gf']<g['ga'] for g in rows),GF=sum(g['gf'] for g in rows),GA=sum(g['ga'] for g in rows))
        forms.append(dict(fixture_id=f['source_event_id'],team=t['team']['displayName'],team_id=tid,games=games,overall=stats(games),home=stats([g for g in games if g['home']]),away=stats([g for g in games if not g['home']]),source=f['phase_evidence']))
write(R/'verified-form.json',forms)
channel = read(R/'market/market-channel.json')
mapping = {x['match_id']:x for x in channel['identity_mappings']}
oldpath = Path('/workspace/WCPP/reports/nations-prematch-20261113-2118/market/odds.json')
oldmeta = read(oldpath.parent/'source-metadata.json')['odds']
assert sha(oldpath) == oldmeta['sha256']
prepared=[]; audits=[]
for original in fixtures:
    f=dict(original,cutoff_at=now.isoformat(),identity_verified=True,score_basis='regulation_90')
    f,audit=attach_total_quote(f,R/'market',provider_order=('the-odds-api',),bookmaker_order=('pinnacle',),now=now)
    if f.get('total_quote'): assert quote_audit(f)['eligible']
    f['market_snapshots']=[]
    if f['match_id'] in mapping:
        provider_id=mapping[f['match_id']]['provider_match_id']
        book=f.get('total_quote',{}).get('bookmaker','pinnacle')
        for path,mm in [(oldpath,oldmeta),(R/'market/odds.json',meta['odds'])]:
            matched=[e for e in read(path) if e['id']==provider_id]
            if not matched:continue
            assert len(matched)==1
            e=matched[0]
            assert datetime.fromisoformat(e['commence_time'].replace('Z','+00:00'))==datetime.fromisoformat(f['kickoff_at'])
            for b in e['bookmakers']:
                if b['key']!=book:continue
                for m in b['markets']:
                    if m['key'] not in ['h2h','totals']:continue
                    names={e['home_team']:'home',e['away_team']:'away','Draw':'draw'} if m['key']=='h2h' else {'Over':'over','Under':'under'}
                    f['market_snapshots'].append(dict(match_id=f['match_id'],bookmaker=book,market='1x2' if m['key']=='h2h' else 'totals',line=m['outcomes'][0].get('point'),decimal_odds={names[o['name']]:o['price'] for o in m['outcomes']},quoted_at=m['last_update'],query_time=mm['captured_at'],source_url=mm['url'],source_sha256=mm['sha256']))
    safe_cli.validate_future(f); prepared.append(f); audits.append(dict(match_id=f['match_id'],audit=audit))
write(R/'prepared-fixtures.json',prepared)
write(R/'market-attachment-audit.json',audits)
safe_cli.freeze_pairs('/workspace/nations-model-20261110/models/candidates.json',prepared,R/'candidate-update',F)
compact=[]
for f,receipt in zip(prepared,read(R/'candidate-update/receipts.json')):
    rec=verify(read(receipt['path']))
    pair=read(R/'candidate-update'/(f['match_id'].replace(':','-')+'.json'))
    predecessors=[]
    for path in sorted(Path(receipt['path']).parent.glob('[0-9]*.json')):
        previous=verify(read(path));predecessors.append(dict(freeze_id=previous['freeze_id'],evaluation_slot=previous['evaluation_slot'],path=str(path),sha256=previous['record_sha256']))
    compact.append(dict(match_id=f['match_id'],actual_quote=f.get('total_quote'),freezes=predecessors,**{role:dict(primary=pair[role]['primary'],wdl=pair[role]['wdl'],training_data_cutoff=pair[role]['training_data_cutoff'],team_goal_analysis=summarize_prediction(pair[role]),distribution_audit=audit_prediction(pair[role])) for role in ['current','test']}))
write(R/'candidate-diagnostics.json',compact)
print(json.dumps(dict(pairs=len(compact),form_rows=len(forms),attached=sum(a['audit']['status']=='ATTACHED' for a in audits),cutoff=now.isoformat())))
