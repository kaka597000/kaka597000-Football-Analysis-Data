"""Recalculate from raw team IDs; derived agent prose is not an input."""
import json,hashlib,sys
from pathlib import Path
from datetime import datetime
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from v2_test.data_contract import digest
from research.analysis_freeze import verify
R=Path(__file__).resolve().parent
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):
    with Path(p).open('x') as h:json.dump(x,h,ensure_ascii=False,indent=2,allow_nan=False)
fs=read(R/'prepared-fixtures.json');forms=read(R/'verified-form.json')
index=read('/workspace/nations-model-20261110/models/candidates.json')
assert sha('/workspace/nations-model-20261110/models/candidates.json')=='9c60bfc468c4b04dc3343d3ba5f621ff559cc534de9f5e93afa9c4fcb8081520'
checks=0;training=[]
for f in fs:
    art=read(index['routes'][f['league_level']]['test']['path']);assert sha(art['dataset_path'])==art['dataset_sha256'];checks+=1
    dataset={x['source_event_id']:x for x in read(art['dataset_path'])['rows']}
    for form in [x for x in forms if x['fixture_id']==f['source_event_id']]:
        for g in form['games']:
            assert g['id'] in dataset
            row=dataset[g['id']];assert 'espn:'+form['team_id']==row['home' if g['home'] else 'away']
            assert [g['gf'],g['ga']]==[row['home_goals'],row['away_goals']] if g['home'] else [g['gf'],g['ga']]==[row['away_goals'],row['home_goals']]
            assert g['date'][:10]<=art['train_end'];checks+=4
        training.append(dict(fixture_id=f['source_event_id'],team_id=form['team_id'],current_edition_n=4,all_four_present_in_training_dataset=True,training_cutoff=art['train_end']))
process={}
for folder in ['context','latest-process']:
    for path in sorted((R/folder).rglob('*.raw.json')):
        d=read(path)
        if not isinstance(d,dict) or 'header' not in d:continue
        c=d['header']['competitions'][0]
        if not c['status']['type']['completed']:continue
        assert c['status']['type']['name']=='STATUS_FULL_TIME'
        eid=str(c['id']);sides={s['homeAway']:s for s in c['competitors']}
        ids={str(s['team']['id']) for s in sides.values()}
        stats={str(t['team']['id']):{s['name']:s['displayValue'] for s in t['statistics']} for t in d['boxscore']['teams']}
        assert set(stats)==ids
        scores={str(s['team']['id']):int(s['score']) for s in sides.values()}
        issues=[];events=[]
        for e in d.get('keyEvents',[]):
            typ=e.get('type',{}).get('type','')
            if e.get('scoringPlay') or typ in ['red-card','yellow-red-card','second-yellow-card']:
                events.append(dict(type=typ,minute=e['clock']['displayValue'],team_id=str(e.get('team',{}).get('id')),text=e.get('text','')))
        for tid,st in stats.items():
            opp=next(i for i in ids if i!=tid)
            if int(st['saves'])+scores[opp]!=int(stats[opp]['shotsOnTarget']):issues.append(dict(team_id=tid,type='SAVES_PLUS_OPPONENT_GOALS_DIFFERS_FROM_OPPONENT_SOT',notice='Do not infer goalkeeper quality; own goals and provider definitions may differ.'))
            scored_pen=sum(e['type']=='penalty---scored' and e['team_id']==tid for e in events)
            if scored_pen!=int(st.get('penaltyKickGoals','0')):issues.append(dict(team_id=tid,type='PENALTY_GOAL_AGGREGATE_EVENT_CONFLICT',event_count=scored_pen,aggregate=st.get('penaltyKickGoals')))
        process[eid]=dict(event_id=eid,date=c['date'],source_path=str(path),source_sha256=sha(path),source_url='https://site.api.espn.com/apis/site/v2/sports/soccer/uefa.nations/summary?event='+eid,window='FIRST_LEG' if folder=='context' else 'LATEST_CURRENT_EDITION',teams={str(t['team']['id']):dict(name=t['team']['displayName'],side=t['homeAway'],goals=int(t['score']),stats=stats[str(t['team']['id'])]) for t in sides.values()},events=events,field_conflicts=issues,real_xg_fields={tid:{k:v for k,v in st.items() if 'expected' in k.lower() or 'xg' in k.lower()} for tid,st in stats.items()})
        checks+=8
assert len(process)==16,('first-leg plus latest detailed games required',len(process))
for form in forms:
    last=max(form['games'],key=lambda g:g['date']);p=process[last['id']];tid=form['team_id']
    assert p['window']=='LATEST_CURRENT_EDITION' and p['teams'][tid]['goals']==last['gf'];checks+=2
channel=read(R/'market/market-channel.json')
for sn in channel['snapshots']:
    assert sn['snapshot_sha256']==digest({k:v for k,v in sn.items() if k!='snapshot_sha256'});checks+=1
    for row in sn['observations']:
        assert row['provider_match_id']!='30b32c194d8c2ae2bc5a209be5df44a9'
        for k in ['identity_evidence','evidence']:
            assert sha(R/'market'/row[k]['file'])==row[k]['sha256'];checks+=1
        assert datetime.fromisoformat(row['value']['quoted_at'].replace('Z','+00:00'))<=datetime.fromisoformat(row['observed_at'].replace('Z','+00:00'));checks+=1
same_matrix=[]
for x in read(R/'candidate-diagnostics.json'):
    records=[verify(read(v['path'])) for v in x['freezes']]
    assert len(records)==2
    for role in ['current','test']:
        assert records[0]['payload'][role]['matrix']==records[1]['payload'][role]['matrix'];checks+=1
    same_matrix.append(dict(match_id=x['match_id'],first=records[0]['freeze_id'],revision=records[1]['freeze_id'],numerical_matrices_unchanged=True,additional_independent_match=False))
write(R/'verified-process.json',list(process.values()))
write(R/'source-audit.json',dict(status='PASS',assertions_passed=checks,training_freshness=training,candidate_revision_audit=same_matrix,verified_process_games=len(process),verified_team_result_rows=64,market_coverage=channel['coverage'],market_quotes=channel['verified_quote_count'],known_derived_prose_error='context/support-counter-facts.json has score_display directions; superseded by v2 and independent raw-ID verification',xg_coverage=sum(bool(v) for p in process.values() for v in p['real_xg_fields'].values()),formal_kpi_acceptance=False))
print(json.dumps(dict(status='PASS',checks=checks,process_games=len(process))))
