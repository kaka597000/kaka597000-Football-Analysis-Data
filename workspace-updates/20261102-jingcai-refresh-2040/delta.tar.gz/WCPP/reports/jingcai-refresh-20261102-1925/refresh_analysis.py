import json,sys,datetime
from pathlib import Path
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from predict_active import run,legacy
from fuse_models import fuse
from research.analysis_freeze import save
import numpy as np

out=Path(__file__).parent
old=Path('/workspace/WCPP/reports/session-20261102-analysis-and-review/today')
src=Path('/workspace/WCPP/staging/jingcai-20261102-refresh-1925')
news=Path('/workspace/WCPP/staging/jingcai-20261102-news-refresh-1925')
latest=src/'odds-final-batch.json'
batch=json.loads((latest if latest.exists() else src/'odds-current-batch.json').read_text())
first=json.loads((src/'odds-current-batch.json').read_text())
matched=json.loads((src/'verified-pinnacle-quotes.json').read_text())
event_ids={q['lottery_no'][-3:]:q['odds_event_id'] for q in matched}
byid={e['id']:(call,e) for call in batch if isinstance(call.get('response'),list) for e in call['response']}
initial={e['id']:(call,e) for call in first if isinstance(call.get('response'),list) for e in call['response']}
stats=json.load(open('/workspace/WCPP/reports/v2-data-contract-20261102/snapshot-summary.json'))
stats={r['lottery_no']:r for r in stats}
summary=[];allreceipts=[]
for prior in json.load(open(old/'final-summary.json')):
 n=prior['lottery_no'][-3:];data=json.load(open(old/(n+'-comprehensive.json')))
 f=data['fixture'];payload=data['payload'];now=datetime.datetime.now(datetime.timezone.utc).isoformat()
 f=dict(f,cutoff_at=now);f.pop('total_quote',None)
 f['sources']=list(f['sources'])+[{'source_url':'https://www.okooo.com/jingcai/','query_time':json.load(open(src/'okooo-jingcai.meta.json'))['retrieved_at_utc']}]
 news_data=json.load(open(news/'news-summary.json'))
 for entry in news_data['matches']:
  if entry['match'].startswith(prior['lottery_no']):
   for source in entry.get('sources',[]):
    if source.get('http_status')==200:
     f['sources'].append({'source_url':source['url'],'query_time':news_data['captured_at_utc'],
          'source_tier':'L1','query_time_kind':'LOCAL_REVALIDATION_OF_RETAINED_OFFICIAL_PAGE; ORIGINAL_HTTP_CAPTURE_TIME_NOT_CERTIFIED'})
 q=None;market=None;book=None;call=None
 if n in event_ids and event_ids[n] in byid:
  call,event=byid[event_ids[n]];assert datetime.datetime.fromisoformat(event['commence_time'].replace('Z','+00:00'))==datetime.datetime.fromisoformat(f['kickoff_at'].replace('Z','+00:00'))
  book=next((b for b in event['bookmakers'] if b['key']=='pinnacle'),None)
  if book:
   market=next((m for m in book['markets'] if m['key']=='totals'),None)
   if market:
    values=market['outcomes'];line=values[0]['point'];assert all(v['point']==line for v in values)
    odds={v['name'].lower():v['price'] for v in values};assert set(odds)=={'over','under'}
    q={'bookmaker':'Pinnacle','market':'standard_total','line':line,'over_odds':odds['over'],'under_odds':odds['under'],
       'match_id':f['match_id'],'quoted_at':market.get('last_update',book['last_update']),'query_time':call['retrieved_at_utc'],
       'source_url':call['source_url'],'verified':True,'asian_main_line_verified':False}
    f['sources'].append({'source_url':call['source_url'],'query_time':call['retrieved_at_utc']})
    f['total_quote']=q
    f['market_snapshots']=[{'match_id':f['match_id'],'bookmaker':'Pinnacle','market':'totals','line':line,'decimal_odds':odds,'quoted_at':q['quoted_at'],'query_time':q['query_time'],'source_url':q['source_url']}]
    if n=='002':
     f['market_snapshots'].append({'match_id':f['match_id'],'bookmaker':'Pinnacle','market':'totals','line':3.,'decimal_odds':{'over':1.93,'under':1.98},'quoted_at':'2026-11-02T10:07:38+00:00','query_time':'2026-11-02T10:08:17.684651+00:00','source_url':'https://api.the-odds-api.com/v4/sports/soccer_italy_serie_a/odds'})
 f['evidence_packet']['refresh_root']=str(src)
 f['evidence_packet']['official_news_refresh_root']=str(news)
 # Actual information cutoff is the latest retained input timestamp, not a backdated
 # generation/freeze timestamp. All computation and freezes retain wall-clock time.
 f['cutoff_at']=max((s['query_time'] for s in f['sources']),key=lambda s:datetime.datetime.fromisoformat(s.replace('Z','+00:00')))
 # Old historical facts retain their actual capture times; no claim of new training.
 for m in f.get('analysis_modules',{}).values():
  m['as_of']=f['cutoff_at']
 if 'market' in f.get('analysis_modules',{}):
  f['analysis_modules']['market']={'match_id':f['match_id'],'status':'partial','as_of':f['cutoff_at'],'summary':'真实Pinnacle时间快照；仅已取得的同机构同盘线才比较，未证明亚洲主盘。','facts':{'quote':q},'sources':[{'source_url':q['source_url'],'query_time':q['query_time'],'known_at':q['query_time']}] if q else [],'missing':['full price history','Asian main line certification']}
 (out/(n+'-fixture.json')).write_text(json.dumps(f,ensure_ascii=False,indent=2))
 pair=None;fusion=None
 try:
  if not f.get('identity_verified'):raise ValueError('unresolved canonical identity; no model attempt')
  pair=run(f);fusion=fuse(pair)
  pr=save(pair,f,stage='prematch',track='current-test-pair')
  fr=save({'current_test_pair':pair,'fusion_reference':fusion,'current_test_freeze_receipt':pr},f,stage='prematch',track='ensemble-research')
  allreceipts.extend([pr,fr]);(out/(n+'-unified.json')).write_text(json.dumps({'current_test_pair':pair,'fusion_reference':fusion,'paired_receipt':pr,'fusion_receipt':fr},ensure_ascii=False,indent=2))
 except ValueError as error:
  pr=save({'status':'ABSTAIN_BOTH','reason':str(error),'actual_matrices_available':False},f,stage='prematch',track='current-test-pair');allreceipts.append(pr)
  (out/(n+'-unavailable.json')).write_text(json.dumps({'reason':str(error),'receipt':pr},ensure_ascii=False,indent=2))
 f=dict(f,cutoff_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
 payload=dict(payload,current_test_reference=pr if pair else None)
 payload['method']='WCPP-COMPREHENSIVE-REFRESH-20261102-1925'
 if n=='006':
  payload['primary']='1-1';payload['wdl']='平局'
  payload['reason']='修订原2-1：Everton官方10/30更新称Branthwaite预计恢复可用，不等于确认首发；这轮新核实的既有消息加强客队防线情景。纽卡合格联赛机会窗口仅1场0.99xG，客队两场均值0.53，不能只凭杯赛纽卡2.14xG就推主队两球。比较2-1/1-1/1-0后降为1-1和平局研究倾向，不改原两模型矩阵或历史推荐。'
  payload['risk']='纽卡官方称Elanga/Ramsey已回归，主场及两模型主胜边际仍支持2-1；Everton是否派Branthwaite首发、Grealish是否回归未定。1-1不是把融合众数改名，依据是新增官方防线信息与机会质量反证，且只作低优先研究。'
 payload['total_line']=q['line'] if q else None;payload['total_direction']=None
 payload['total_reason']='实际报价已列；独立审查矩阵、近期机会、人员及尾部。源报价超60秒时不作融合实盘输入，不自设盘口。'
 if n in ['003','008'] and fusion and fusion['total'] is not None:
  payload['total_direction']='小'
  payload['total_reason']=('小'+str(q['line'])+'：融合总球均值2.45，近期合格机会均值支持有限小球，AIK连续进球和双方防守波动为反证。' if n=='003' else '小'+str(q['line'])+'：融合总球均值3.35；近期合格机会窗口与对手调整后的主要路径支持低于市场高线，但赛季26进球、客队进球及主队扩大比分是明确尾部反证。Pinnacle此前3.5、现3.75为升盘，不能跨线解释升降水；四球时小3.75半输，五球以上全输。')
  payload['total_settlement_probabilities']=fusion['total']['under']
 payload['refresh_quote']=q
 payload['freshness_gate']=fusion['total_status'] if fusion else 'MODEL_UNAVAILABLE'
 payload['new_training_performed']=False
 payload['refresh_change_note']='追加版本，原首次比分与分母保留；融合只是未训练50/50参考，不替代综合选择。'
 payload['risk']+='；近期历史被V2保守隔离后的合格窗口及其缺项均保留，不以新盘口掩盖训练截止滞后。'
 if n in stats:payload['qualified_xg_windows']=stats[n]['features']
 payload['official_news_scope']='仅采用news refresh报告中可核实的本场信息；旧文/访问失败不当作缺阵确认，004重大风险未解保持待定。'
 payload['selection_evidence']['total_reason']=payload['total_reason']
 cr=save(payload,f,stage='prematch',track='comprehensive');allreceipts.append(cr)
 with (out/(n+'-comprehensive.json')).open('x') as h:json.dump({'fixture':f,'payload':payload,'receipt':cr},h,ensure_ascii=False,indent=2)
 s={'lottery_no':prior['lottery_no'],'home':prior['home'],'away':prior['away'],'kickoff_beijing':prior['kickoff_beijing'],
    'current':pair['current_model']['primary'] if pair else None,'test':pair['test_model']['primary'] if pair else None,'fusion':fusion['primary'] if fusion else None,
    'primary':payload['primary'],'wdl':payload['wdl'],'line':payload['total_line'],'total_direction':payload['total_direction'],'quote':q,'freshness_gate':payload['freshness_gate'],'comprehensive_receipt':cr}
 summary.append(s)
f={'match_id':'jingcai:20261102:evening-top','cohort':'BATCH','kickoff_at':'2026-11-03T00:00:00+08:00','cutoff_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
chosen=[r for r in summary if r['lottery_no']=='周一008'];top={'scope':'同一周一9场的追加版本，仅本菲卡研究优先，不凑TOP3；非旧名单重写。','top3':[{'rank':i+1,'match_id':'espn:401885403','primary':r['primary'],'wdl':r['wdl'],'total_line':r['line'],'total_direction':r['total_direction'],'reason':'赛季主场长期优势与双模型方向一致，保留客队一球；盘线和尾部另判。','risk':'合格历史窗口偏小，平台人员及报价时效限制；原模型训练滞后。','comprehensive_reference':r['comprehensive_receipt']} for i,r in enumerate(chosen)]}
tr=save(top,f,stage='prematch',track='top3-selection');allreceipts.append(tr)
(out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));(out/'receipts.json').write_text(json.dumps(allreceipts,ensure_ascii=False,indent=2))
print(json.dumps({'rows':len(summary),'top_freeze':tr},ensure_ascii=False))
