# R11 日期外样本扩展

采集六个 Football-Data 官方 2026/27 CSV：`https://www.football-data.co.uk/mmz4281/2627/{E0,SP1,D1,I1,F1,N1}.csv`。通过公开 HTTPS 免密获取，按原始响应字节保存至 `raw/`，并在 `manifest.json` 记录 URL、HTTP 状态、Last-Modified、采集 UTC 时间、字节数和 SHA-256。

纳入规则：对应 R5 league panel 最新日期（六联赛均为 2026-11-08）之后，完整主客进球可解析，且按 CSV 联赛当地时区解释开赛时间后早于北京时间 2026-11-25 15:00。身份重叠以联赛、ISO 日期、规范化主队和客队与 R5 全 panel 比对；重叠行不重复纳入。新增 ID 稳定生成 `football-data:new:<SHA256(date|home|away)前24位>`；`stage/source_stage=regular`，日期为 ISO 格式，比分按 R5 regulation_90 结构保存。

`fixture-panels.jsonl` 是新增 fixture panel，`market-rows.csv` 是同场 CSV 行的市场数据。主盘口使用非 closing `AHh/B365AHH/B365AHA`，收盘分类单独保留为 `AHCh/B365CAHH/B365CAHA`。同时保存 1X2、2.5 总球、真实物理行号、日期/队名、原始 SHA 和采集时间。全部 57 场两套 AH 字段均完整。没有使用市场均价。

运行 `python extract.py` 可重新下载并重建。网络 CSV 若更新，SHA、Last-Modified、行数及覆盖清单会随本次采集改变。
