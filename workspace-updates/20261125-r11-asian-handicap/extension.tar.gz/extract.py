#!/usr/bin/env python3
"""Fetch latest public Football-Data 2026/27 CSVs and append date-external completed fixtures."""
import csv,hashlib,io,json,urllib.request,datetime,tarfile,pathlib,zoneinfo,re
OUT=pathlib.Path(__file__).resolve().parent
R5=pathlib.Path('/workspace/scratch/r8-reference-20261125/prior/workspace-updates/20261123-all-scope-kpi')
LEAGUES={'eng.1':('E0','Europe/London'),'esp.1':('SP1','Europe/Madrid'),'ger.1':('D1','Europe/Berlin'),'ita.1':('I1','Europe/Rome'),'fra.1':('F1','Europe/Paris'),'ned.1':('N1','Europe/Amsterdam')}
CUTOFF=datetime.datetime(2026,11,25,15,0,tzinfo=zoneinfo.ZoneInfo('Asia/Shanghai'))
def clean(s): return (s or '').replace('\ufeff','').strip()
def identity(date,home,away):
    def n(s): return re.sub(r'[^a-z0-9]+','',clean(s).casefold())
    return (date,n(home),n(away))
def parse_day(s):
    for fmt in ('%d/%m/%Y','%Y-%m-%d'):
        try:return datetime.datetime.strptime(clean(s),fmt).date()
        except ValueError:pass
    return None
panels={}; maxdate={}; oldids={}
for league in LEAGUES:
    with tarfile.open(R5/'models'/f'{league}.tar.gz','r:gz') as tf:
        rows=[json.loads(line) for line in tf.extractfile('panel.jsonl').read().splitlines() if line]
    panels[league]=rows
    dates=[r['date'] for r in rows if r.get('date')]
    maxdate[league]=max(dates)
    oldids[league]={identity(r['date'],r['home'],r['away']):r['id'] for r in rows}
all_panels=[]; market_rows=[]; coverage={}; manifest=[]
for league,(code,tzname) in LEAGUES.items():
    url=f'https://www.football-data.co.uk/mmz4281/2627/{code}.csv'
    requested=datetime.datetime.now(datetime.timezone.utc).isoformat()
    req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 (compatible; R11 data intake)'})
    with urllib.request.urlopen(req,timeout=60) as resp:
        raw=resp.read(); status=resp.status; headers={k.lower():v for k,v in resp.headers.items()}
    got=datetime.datetime.now(datetime.timezone.utc).isoformat(); sha=hashlib.sha256(raw).hexdigest()
    (OUT/'raw'/f'2627-{code}.csv').write_bytes(raw)
    reader=csv.DictReader(io.StringIO(raw.decode('utf-8-sig',errors='replace')))
    csvrows=list(reader); source_rows=[]; included=[]; overlap=[]; incomplete=0; after_cutoff=0; no_time=0
    for physical,row in enumerate(csvrows,start=2):
        d=parse_day(row.get('Date')); home=clean(row.get('HomeTeam')); away=clean(row.get('AwayTeam'))
        if not d or not home or not away: continue
        ds=d.isoformat()
        ident=identity(ds,home,away)
        source_rows.append({'physical_row':physical,'date':ds,'home':home,'away':away})
        old=oldids[league].get(ident)
        hg=clean(row.get('FTHG')); ag=clean(row.get('FTAG'))
        if old:
            overlap.append({'physical_row':physical,'date':ds,'home':home,'away':away,'r5_id':old})
            continue
        if ds<=maxdate[league]: continue
        try: goals=(int(float(hg)),int(float(ag)))
        except (ValueError,TypeError): incomplete+=1; continue
        time=clean(row.get('Time'))
        if not time: no_time+=1; continue
        try:
            local=datetime.datetime.combine(d,datetime.datetime.strptime(time,'%H:%M').time(),zoneinfo.ZoneInfo(tzname))
        except ValueError: no_time+=1; continue
        if local.astimezone(datetime.timezone.utc)>=CUTOFF.astimezone(datetime.timezone.utc):
            after_cutoff+=1; continue
        # Stable extension ID derived from date and exact teams; stage/date conventions match R5 regular panels.
        idhash=hashlib.sha256('|'.join((ds,home,away)).encode()).hexdigest()[:24]
        mid='football-data:new:'+idhash
        def val(k): return clean(row.get(k))
        panel={'id':mid,'competition':league,'season':'2627','date':ds,'home':home,'away':away,'home_goals':goals[0],'away_goals':goals[1],
          'neutral':False,'stage':'regular','source_stage':'regular','leg':None,'score_basis':'regulation_90','h2h':None,'total':None,'bookmaker':None,
          'market_time_basis':None,'paired_market':False,'source_sha256':sha,'sources':[{'row':physical,'sha256':sha,'url':url}],
          'source_status':'completed_score_in_latest_csv','source_status_code':clean(row.get('FTR'))}
        all_panels.append(panel)
        market_rows.append({'id':mid,'competition':league,'season':'2627','date':ds,'home':home,'away':away,'home_goals':goals[0],'away_goals':goals[1],
          'csv_row_physical':physical,'source_url':url,'source_sha256':sha,'acquired_at_utc':got,'csv_kickoff_time_local':time,'csv_local_timezone':tzname,'kickoff_utc':local.astimezone(datetime.timezone.utc).isoformat(),
          'B365H':val('B365H'),'B365D':val('B365D'),'B365A':val('B365A'),'B365>2.5':val('B365>2.5'),'B365<2.5':val('B365<2.5'),
          'AHh':val('AHh'),'B365AHH':val('B365AHH'),'B365AHA':val('B365AHA'),'AHCh':val('AHCh'),'B365CAHH':val('B365CAHH'),'B365CAHA':val('B365CAHA'),
          'primary_AH_snapshot':'non_closing_AHh_B365AHH_B365AHA','main_AH_complete':all(val(k) for k in ['AHh','B365AHH','B365AHA']),
          'closing_AH_complete':all(val(k) for k in ['AHCh','B365CAHH','B365CAHA'])})
        included.append({'physical_row':physical,'id':mid,'date':ds,'home':home,'away':away})
    coverage[league]={'url':url,'status':status,'last_modified':headers.get('last-modified'),'etag':headers.get('etag'),'acquired_at_utc':got,'sha256':sha,'bytes':len(raw),
      'r5_panel_rows':len(panels[league]),'r5_latest_panel_date':maxdate[league],'csv_rows':len(csvrows),'identity_overlaps_r5':len(overlap),'overlaps':overlap,
      'new_completed_before_cutoff':len(included),'new_fixtures':included,'new_rows_missing_complete_goals':incomplete,'new_rows_missing_kickoff_time':no_time,'new_rows_at_or_after_cutoff':after_cutoff}
    manifest.append({'league':league,'url':url,'file':f'raw/2627-{code}.csv','sha256':sha,'bytes':len(raw),'http_status':status,'last_modified':headers.get('last-modified'),'requested_at_utc':requested,'acquired_at_utc':got})
for fn,rows in [('fixture-panels.jsonl',all_panels)]:
    (OUT/fn).write_text(''.join(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n' for x in rows),encoding='utf-8')
cols=list(market_rows[0]) if market_rows else ['id','competition','season','date','home','away','home_goals','away_goals','csv_row_physical','source_url','source_sha256','acquired_at_utc','AHh','B365AHH','B365AHA','AHCh','B365CAHH','B365CAHA']
with open(OUT/'market-rows.csv','w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=cols);w.writeheader();w.writerows(market_rows)
(OUT/'manifest.json').write_text(json.dumps({'cutoff_beijing':CUTOFF.isoformat(),'market_selection':'same-file non-closing AHh/B365AHH/B365AHA primary; closing AHCh/B365CAHH/B365CAHA retained separately','sources':manifest},indent=2,ensure_ascii=False)+'\n')
(OUT/'coverage.json').write_text(json.dumps({'cutoff_beijing':CUTOFF.isoformat(),'identity_match':'league + ISO date + normalized exact home/away team names','identity_overlap_check':'against all R5 fixture panels in the corresponding league','leagues':coverage,'new_panel_rows_total':len(all_panels),'market_rows_total':len(market_rows),'market_price_averages_used':False},indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:{'r5_latest':v['r5_latest_panel_date'],'overlap':v['identity_overlaps_r5'],'added':v['new_completed_before_cutoff']} for k,v in coverage.items()},ensure_ascii=False))
