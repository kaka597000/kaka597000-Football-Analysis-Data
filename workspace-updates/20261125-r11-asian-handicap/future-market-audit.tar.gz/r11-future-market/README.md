# R11 future Bet365 market intake

`markets.jsonl` contains zero rows because no eligible same-snapshot future prices were verifiable from allowed sources. `coverage.json` records all 54 R10 fixtures in the six requested leagues, source URLs, hashes, response headers, field observations, and per-fixture R10 IDs/files/record hashes.

`raw/` preserves the official Football-Data `fixtures.csv` and current-season CSV responses exactly as downloaded, with HTTP headers. Files are not rewritten. The current-season CSVs contain Bet365 columns but only completed-match data and no quote timestamp; `fixtures.csv` returned no rows for the requested six divisions. Existing permitted historic caches lack quote timestamps and cannot establish future quotes.
