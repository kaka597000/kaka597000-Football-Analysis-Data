# R11 赛前盘口原始资料提取

数据范围：R5 六联赛 `eng.1, esp.1, ger.1, ita.1, fra.1, ned.1` 的原 panel，以及 `evidence/source-index.json` 指向的 Football-Data CSV 原始字节。未使用中国体彩或镜像，也未评估模型效果。

## 文件

- `r11_nonclosing_primary.csv`：逐场主结果。每场固定取同一 CSV 行的普通（未标 closing）Bet365 1X2、2.5 总球和亚洲让球。让球主队盘口为 `AHh`，双方十进制价格为 `B365AHH/B365AHA`；不以均价或其他公司补值。
- `closing_ah_audit.csv`：同一批已匹配比赛的收盘亚洲让球 `AHCh/B365CAHH/B365CAHA`，只作核查。
- `raw/`：用于上述匹配的 Football-Data CSV 原始字节文件，每文件名以源季标识开头。
- `*.panel.jsonl`：R5 六联赛 panel 原始副本。
- `coverage.json`：联赛、日期、赛季覆盖，未匹配 panel 行和缺失统计；同时列明来源 URL、SHA-256、tar/member 或 git 位置。
- `r10-window-check.json`：2015–19 R10 raw 清单与字段检查。
- `extract.py`：离线复算脚本；运行 `python extract.py`。脚本从已指定的 R5 归档/仓库定位字节并逐源校验 SHA-256，然后重建导出文件。

## 结果与限制

15,138 条 panel 行中，15,135 条有 source-index 可定位的 Football-Data CSV 原始行，且比赛日与主客队匹配。荷甲 3 场（2026-05-21 Ajax–Groningen、Utrecht–Heerenveen，2026-05-24 Ajax–Utrecht）来源为 ESPN scoreboard，不属于可用 Football-Data CSV 行；详见 `coverage.json`。

普通 AH 三字段完整 15,106 场，缺一项或多项 29 场；收盘 AH 完整数和逐联赛缺项以 `coverage.json` 为准。原始 CSV 的 `Time` 是开赛时间，不是盘口报价时间；15,135 场的归档报价时间均缺失。

R10 提供的 24 个 2015–19 CSV 含 BetBrain 聚合让球字段（如 `BbAHh`, `BbMxAHH/BbMxAHA`, `BbAvAHH/BbAvAHA`），没有 Bet365 专属 AH 字段，不能作为 Bet365 双边价格替代，因此未合并进 R11 提取。
