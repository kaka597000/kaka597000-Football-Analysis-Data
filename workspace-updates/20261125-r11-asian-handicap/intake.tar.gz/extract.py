#!/usr/bin/env python3
"""Offline reproducible R5 Football-Data intake. Uses only R5 panels/index and archived bytes."""
import csv, gzip, hashlib, io, json, tarfile, pathlib, shutil
BASE=pathlib.Path('/workspace/scratch/r8-reference-20261125/prior/workspace-updates/20261123-all-scope-kpi')
OUT=pathlib.Path(__file__).resolve().parent
LEAGUES=['eng.1','esp.1','ger.1','ita.1','fra.1','ned.1']
CODES={'eng.1':'E0','esp.1':'SP1','ger.1':'D1','ita.1':'I1','fra.1':'F1','ned.1':'N1'}
idx=json.load(open(BASE/'evidence/source-index.json'))
# Panels are preserved verbatim, together with panel archive locations and hashes.
panels=[]
for league in LEAGUES:
    archive=BASE/'models'/f'{league}.tar.gz'
    with tarfile.open(archive,'r:gz') as tf:
        raw=tf.extractfile('panel.jsonl').read()
        (OUT/f'{league}.panel.jsonl').write_bytes(raw)
        panels += [(league,json.loads(line)) for line in raw.splitlines() if line]

def norm(s): return (s or '').lstrip('\ufeff').strip()
# Identify required Football-Data sources by panel provenance (retain exact sha + URL).
source_hashes={}
for league,row in panels:
    for src in row.get('sources',[]):
        h=src.get('sha256') or row.get('source_sha256')
        if h and h in idx: source_hashes[h]=idx[h]
raw_by_hash={}
for h, rec in source_hashes.items():
    url=(rec.get('sources') or [''])[0]
    if 'football-data.co.uk' not in url.lower() or not url.lower().endswith('.csv'): continue
    if rec.get('archive'):
        with tarfile.open(BASE/'evidence'/rec['archive']) as tf:
            packed=tf.extractfile(rec['member']).read()
        raw=gzip.decompress(packed) if rec['member'].endswith('.gz') else packed
        location=f"{rec['archive']}::{rec['member']}"
    elif rec.get('repository_path'):
        import subprocess
        raw=subprocess.check_output(['git','-C','/workspace/kaka597000-Football-Analysis-Data','show',f"{rec['commit']}:{rec['repository_path']}"])
        location=f"git:{rec['commit']}:{rec['repository_path']}"
    else: continue
    actual=hashlib.sha256(raw).hexdigest()
    if actual!=h: raise ValueError(f'SHA mismatch {url}: {actual} != {h}')
    raw_by_hash[h]=(raw,url,location)
# Save exactly the source CSV bytes once per SHA.
for h,(raw,url,loc) in raw_by_hash.items():
    name=url.rsplit('/',1)[-1]
    # prevent same filename across seasons collision
    season=url.split('/mmz4281/')[-1].split('/')[0] if '/mmz4281/' in url else 'other'
    (OUT/'raw').mkdir(exist_ok=True)
    (OUT/'raw'/f'{season}-{name}').write_bytes(raw)

# Parse panel source row locations, and attach all original CSV columns as raw strings.
fields=['B365H','B365D','B365A','B365>2.5','B365<2.5','AHh','B365AHH','B365AHA','AHCh','B365CAHH','B365CAHA','Time']
outputs=[]; source_info={}
for h,(raw,url,loc) in raw_by_hash.items():
    reader=csv.DictReader(io.StringIO(raw.decode('latin1')))
    rows=list(reader)
    source_info[h]=(url,loc,reader.fieldnames or [],rows)
for league,p in panels:
    h=p.get('source_sha256')
    if h not in source_info: continue
    url,loc,headers,rows=source_info[h]
    srcrow=next((s.get('row') for s in p.get('sources',[]) if s.get('sha256')==h),None)
    if srcrow is None: continue
    # Source row is physical CSV line number; DictReader data row 1 is physical line 2.
    i=int(srcrow)-2
    if i<0 or i>=len(rows): raise ValueError(f'bad source row {srcrow} {url}')
    r=rows[i]
    if norm(r.get('HomeTeam'))!=norm(p.get('home')) or norm(r.get('AwayTeam'))!=norm(p.get('away')):
        raise ValueError(f'team mismatch {league} {p.get("id")} row {srcrow}')
    out={k:p.get(k,'') for k in ['id','competition','season','date','home','away','home_goals','away_goals']}
    out.update({'source_sha256':h,'source_url':url,'source_location':loc,'source_row_physical':srcrow,
                'csv_date':norm(r.get('Date')),'csv_time':norm(r.get('Time')),
                'csv_kickoff_time':norm(r.get('Time')),'bookmaker_quote_timestamp':None,
                'regular_1x2_B365H':norm(r.get('B365H')),'regular_1x2_B365D':norm(r.get('B365D')),'regular_1x2_B365A':norm(r.get('B365A')),
                'regular_total25_over_B365':norm(r.get('B365>2.5')),'regular_total25_under_B365':norm(r.get('B365<2.5')),
                'regular_AH_home_handicap_AHh':norm(r.get('AHh')),'regular_AH_home_price_B365AHH':norm(r.get('B365AHH')),'regular_AH_away_price_B365AHA':norm(r.get('B365AHA')),
                'closing_AH_home_handicap_AHCh':norm(r.get('AHCh')),'closing_AH_home_price_B365CAHH':norm(r.get('B365CAHH')),'closing_AH_away_price_B365CAHA':norm(r.get('B365CAHA'))})
    # Fixed main snapshot is non-closing; do not substitute another line or market average.
    out['main_snapshot']='non_closing_AHh_B365AHH_B365AHA'
    out['main_complete']=all(out[k] for k in ['regular_AH_home_handicap_AHh','regular_AH_home_price_B365AHH','regular_AH_away_price_B365AHA'])
    out['closing_complete']=all(out[k] for k in ['closing_AH_home_handicap_AHCh','closing_AH_home_price_B365CAHH','closing_AH_away_price_B365CAHA'])
    outputs.append(out)
cols=list(outputs[0]) if outputs else []
for fn, subset in [('r11_nonclosing_primary.csv',outputs),('closing_ah_audit.csv',outputs)]:
    with open(OUT/fn,'w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=cols);w.writeheader()
        for row in subset: w.writerow(row)
# Coverage and missingness, strictly descriptive.
summary={}
for league in LEAGUES:
    rr=[x for x in outputs if x['competition']==league]
    dates=[x['date'] for x in rr if x['date']]
    summary[league]={'panel_rows':sum(l==league for l,_ in panels),'matched_original_csv_rows':len(rr),'date_min':min(dates) if dates else None,'date_max':max(dates) if dates else None,
      'seasons':sorted(set(x['season'] for x in rr)), 'nonclosing_AH_complete':sum(x['main_complete'] for x in rr),'nonclosing_AH_missing':sum(not x['main_complete'] for x in rr),
      'closing_AH_complete':sum(x['closing_complete'] for x in rr),'closing_AH_missing':sum(not x['closing_complete'] for x in rr),
      'bookmaker_quote_timestamp_missing':len(rr),'csv_kickoff_time_present':sum(bool(x['csv_kickoff_time']) for x in rr)}
report={'purpose':'R11 pre-match market-data intake; no model evaluation','leagues':summary,'source_csv_count':len(raw_by_hash),'source_csvs':[{'sha256':h,'url':u,'location':l,'bytes':len(raw),'stored_file':( (u.split('/mmz4281/')[-1].split('/')[0] if '/mmz4281/' in u else 'other')+'-'+u.rsplit('/',1)[-1])} for h,(raw,u,l) in raw_by_hash.items()],
 'market_policy':{'primary':'same-row non-closing AHh with B365AHH and B365AHA; home handicap from AHh','audit':'closing AHCh with B365CAHH and B365CAHA','1x2':'B365H/B365D/B365A','total_2_5':'B365>2.5/B365<2.5','market_averages_used':False,'selection_per_match':'one fixed non-closing snapshot; closing retained separately'},
 'notes':'CSV Time is kickoff time, not bookmaker quote time. Archived bookmaker quote timestamp is absent for all extracted rows.'}
report['panel_rows_without_football_data_csv']=[{'id':p.get('id'),'competition':league,'date':p.get('date'),'home':p.get('home'),'away':p.get('away'),'source_sha256':p.get('source_sha256'),'source_url':next((s.get('url') for s in p.get('sources',[]) if s.get('sha256')==p.get('source_sha256')),None)} for league,p in panels if not any(z['id']==p.get('id') for z in outputs)]
(OUT/'coverage.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
# R10 2015-19 check: inventory supplied raw collection and classify available aggregator columns.
r10=pathlib.Path('/workspace/scratch/r10-2019-intake/raw')
files=sorted(r10.glob('*.csv'))
checks=[]
for f in files:
    try:
        with f.open(encoding='latin1',newline='') as q: hdr=next(csv.reader(q))
    except Exception: hdr=[]
    checks.append({'file':f.name,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'headers':hdr})
(OUT/'r10-window-check.json').write_text(json.dumps({'scope':'2015-2019 external-window supplied raw files','csv_count':len(files),'files':checks,'finding':'The supplied R10 CSVs have BetBrain aggregate Asian handicap columns (BbAHh, BbMxAHH/BbMxAHA, BbAvAHH/BbAvAHA), not Bet365 bookmaker-specific prices. They are not substitutes and no R10 rows were used.'},indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'rows':len(outputs),'sources':len(raw_by_hash),'coverage':summary},ensure_ascii=False))
