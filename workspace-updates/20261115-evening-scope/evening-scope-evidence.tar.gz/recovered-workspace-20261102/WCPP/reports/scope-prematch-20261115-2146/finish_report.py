"""Append a presentation report with later source checks; preserve first predictions."""
import json,sys,hashlib,re,ast
from pathlib import Path
from datetime import datetime,timezone
from zoneinfo import ZoneInfo
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from research.analysis_freeze import save,verify
R=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):
 with Path(p).open('x') as h:json.dump(x,h,ensure_ascii=False,indent=2,allow_nan=False)
now=lambda:datetime.now(timezone.utc).isoformat()
x=read(R/'schedule/recheck/scope-recheck.json')
for c in x['espn_recheck']['competitions']:
 p=R/'schedule/recheck/raw'/(c['code'].replace('.','_')+'.json');assert sha(p)==c['meta']['sha256'];assert read(p)['events']==[] and c['http_status']==200
 assert datetime.fromisoformat(c['meta']['request_start_utc'])<=datetime.fromisoformat(c['meta']['read_complete_utc'])
for r in x['kor1_verification']['raw_artifacts']:assert sha(r['path'])==r['sha256']
kpath=R/'schedule/recheck/kor_sources/kleague_schedule_2026_11.json';kor=read(kpath);rows=kor['data']['scheduleList']
assert kor['resultCode']=='200' and len(rows)==22 and all(r['year']==2026 and r['leagueId']==1 for r in rows)
assert not any(r['gameDate'] in ['2026.11.15','2026.11.16'] for r in rows)
write(R/'scope-recheck-verification.json',dict(status='VERIFIED',verified_at=now(),source_path=str(R/'schedule/recheck/scope-recheck.json'),source_sha256=sha(R/'schedule/recheck/scope-recheck.json'),same_window_as_original=True,espn_empty_200=17,kor_official_rows=22,kor_no_events_in_window=True,initial_coverage_path=str(R/'schedule/coverage.json'),initial_coverage_sha256=sha(R/'schedule/coverage.json'),original_http_metadata_not_rewritten=True,predictions_unchanged=True,scope_outcome='Eight Nations fixtures, six comprehensive prematch successes, two delivery failures. Other configured competitions have no future fixtures in this window; Cup original official fixtures already past kickoff.'))
supp=R/'form-late/supplement';refs=[]
for p in supp.glob('*.meta.json'):
 m=read(p);raw=supp/m['raw_file'];assert sha(raw)==m['sha256'];refs.append(dict(source_path=str(raw),source_sha256=m['sha256'],http_status=m['http_status'],query_time=m['response_read_completed_at'],source_url=m['source_url']))
assert len(refs)==4
lineups=read(R/'lineup-verification.json');assert sum(z['confirmed_full_xi'] for z in lineups)==2
for r in read(R/'analysis-records.json'):
 p=Path(r['fixture']['phase_evidence']['source_path']);j=read(p)
 assert 'injuries' not in j and all(not t.get('roster') for t in j.get('rosters',[]))
write(R/'personnel-supplement-verification.json',dict(status='VERIFIED_UNRESOLVED_PERSONNEL_AND_XG',verified_at=now(),queries=refs,report_path=str(supp/'personnel-xg-supplement.md'),report_sha256=sha(supp/'personnel-xg-supplement.md'),six_current_summaries_without_confirmed_xi_or_injuries=True,current_same_provider_xg_unavailable=True,official_disciplinary_status='UNVERIFIED',new_personnel_factors_used_in_first_predictions=False))
original=(R/'今晚赛事分析.md').read_text();start=original.index('本次比赛夜');end=original.index('\n\n以下为',start)
intro='本次比赛夜为北京时间11月15日晚至11月16日08:00。21项配置范围已完成赛程核查：欧国联确认8场，成功交付6场赛前综合分析；其余赛事在此窗口未查到待赛比赛。17项接口22:04–22:05补查均为HTTP 200且无赛事，韩K1官方11月赛程22条中11月15、16日均无赛，巴甲本日无赛；日联杯官方当日四场已过开球。补查只完善覆盖证据，不回填22:03首版。\n\n22:00两场（拉脱维亚—亚美尼亚、塞浦路斯—黑山）已在21:52保存双候选；我的交付脚本21:59因矩阵类型错误中断，未能在开球前冻结综合结论。这两场保留为交付失败，不补发赛前人工推荐，也不从8场覆盖分母删除。'
text=original[:start]+intro+original[end:]
text=text.replace('小2.25遇2球半赢，','')
for r in read(R/'analysis-records.json'):
 for ff in r['payload']['form_evidence']:
  for side in ['home','away']:
   z=ff[side];old=str(z);new=f"{z['n']}场{z['W']}胜{z['D']}平{z['L']}负、进{z['GF']}失{z['GA']}";text=text.replace(old,new)
text=text.replace('法国—土耳其|1-1|1-0|**2-1**|主胜|小 3.5|','法国—土耳其|1-1|1-0|**2-1**|主胜|弱小 3.5|')
text=text.replace('克罗地亚—捷克|1-1|1-1|**2-0**|主胜|小 2.75|','克罗地亚—捷克|1-1|1-1|**2-0**|主胜|弱小 2.75|')
text+='\n## 交付补充核查与来源\n\n22:06核查：六场缓存summary均无injuries字段、完整首发或xG；UEFA新闻可访问但未给出芬兰/白俄罗斯相关纪律决定，芬兰足协403、白俄罗斯足协503。保留人员未知，不把空字段解释为无人伤停。此补充没有调整任何22:03选分。\n\n'
text+='[欧国联赛程来源](https://site.api.espn.com/apis/site/v2/sports/soccer/uefa.nations/scoreboard?dates=20261115) · [韩K1官方赛程](https://www.kleague.com/schedule.do?year=2026&month=11&leagueId=1) · [UEFA新闻](https://www.uefa.com/uefanationsleague/news/)\n\n'
text+='原始响应、查询时间、报价时间、哈希、数值矩阵、逐场综合冻结、失败记录与恢复清单一并归档。数值候选保留原版本；本次范围核查和显示版不会产生新的逐场预测样本。\n'
(R/'今晚赛事分析_交付版.md').write_text(text)
d=read(R/'delivery.json');old=verify(read(d['report_receipt']['path']));ref=save(dict(markdown=text,original_report_receipt=d['report_receipt'],top3_receipt=d['top3_receipt'],comprehensive_receipts=[r['comprehensive_receipt'] for r in read(R/'analysis-records.json')],coverage_supplement_path=str(R/'scope-recheck-verification.json'),personnel_supplement_path=str(R/'personnel-supplement-verification.json'),purpose='Presentation and new source checks only; six original 22:03 predictions unchanged',new_predictions=False,source_commit=d['source_commit']),dict(old['fixture'],cutoff_at=now()),stage='prematch',track='analysis-report')
verify(read(ref['path']));write(R/'report-delivery-receipt.json',ref)
print(json.dumps(dict(report=ref,scope_verified=21,predictions_unchanged=True),ensure_ascii=False))
