# 最早两场：最近比赛过程与首回合补充

所有数据来自已保存ESPN比赛summary的 `boxscore.teams.statistics`；射门/射正不是xG。比赛身份及主客顺序由summary header competitors的home/away核实。

## 最近一场（11月12日）

- **黑山2–1拉脱维亚**（401861152，Podgorica City Stadium）：控球50.2%–49.8%；射门21–15、射正7–5、角球11–6；黑山4黄1红，拉脱维亚4黄。比赛已完赛。ESPN boxscore未返回xG字段。
- **亚美尼亚1–1塞浦路斯**（401861146，Vazgen Sargsyan Republican Stadium）：控球68.6%–31.4%；射门26–10、射正7–2、角球11–4；黄牌3–2、无红牌。比赛已完赛。ESPN boxscore未返回xG字段。

## 本届首回合（9月25日）

- **亚美尼亚2–0拉脱维亚**（401861050，Vazgen Sargsyan Republican Stadium）：控球56.3%–43.7%；射门14–5、射正4–1、角球10–2。无红牌，黄牌1–0。ESPN boxscore未返回xG字段。
- **黑山2–1塞浦路斯**（401861056，Podgorica City Stadium）：控球64.2%–35.8%；射门19–11、射正4–4、角球8–1。黄牌1–3、无红牌。ESPN boxscore未返回xG字段。

ESPN summary的lastFiveGames在赛前输入里显示每队本届5场（包含11/12第5轮）；不可将该近况称为模型10/6截止前已输入或训练样本。本补充只用于赛前背景阅读。完整四份raw、URL、请求UTC起止、SHA-256在相应 `.capture.json`。
