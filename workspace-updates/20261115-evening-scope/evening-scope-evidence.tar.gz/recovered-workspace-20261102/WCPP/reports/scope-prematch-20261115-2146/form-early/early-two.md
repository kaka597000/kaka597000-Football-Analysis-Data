# 欧国联最早两场背景（北京时间 2026-11-15 21:49 左右采集）

范围：2026–27 UEFA Nations League，C2组，常规时间口径。ESPN已保存赛事ID来自 `/workspace/nations-model-20261110/forward-freezes/protocol.json` 与冻结输入；当前summary再次返回相同队名、ID、日期和开球时间。

| 比赛 | ESPN赛事ID | ESPN队ID | 开球（北京时间） | 场地 |
|---|---:|---|---|---|
| 拉脱维亚–亚美尼亚 | 401861171 | Latvia 456；Armenia 579 | 11月15日22:00 | Skonto Stadions，Riga |
| 塞浦路斯–黑山 | 401861172 | Cyprus 445；Montenegro 6775 | 11月15日22:00 | Alphamega Stadium，Kolossi |

## 小组背景
ESPN两份当前summary standings均列C2组赛5场后的同一排名：黑山4胜1平13分第一；塞浦路斯2胜2平1负8分第二；亚美尼亚1胜2平2负5分第三；拉脱维亚0胜1平4负1分第四。当前比赛状态为Scheduled，均非中立场。

## 最近比赛过程（ESPN lastFiveGames原字段）
- 拉脱维亚：11/12负黑山1–2；10/05负塞浦路斯1–2；10/02负黑山1–2；09/28与塞浦路斯0–0；09/25负亚美尼亚0–2。
- 亚美尼亚：11/12与塞浦路斯1–1；10/05与黑山0–0；10/02负塞浦路斯0–2；09/28负黑山2–3；09/25胜拉脱维亚2–0。
- 塞浦路斯：11/12与亚美尼亚1–1；10/05胜拉脱维亚2–1；10/02胜亚美尼亚2–0；09/28与拉脱维亚0–0；09/25负黑山1–2。
- 黑山：11/12胜拉脱维亚2–1；10/05与亚美尼亚0–0；10/02胜拉脱维亚2–1；09/28胜亚美尼亚3–2；09/25胜塞浦路斯2–1。

比分以summary lastFiveGames的team gameResult及team视角score为准。ESPN event schedule接口返回各队本届5场表，最新为11/12；其并未包含11/15未来赛程，比赛身份/时间从protocol历史冻结证据和当前summary核实。

## 首发、伤停、xG
- 当前summary的两边rosters均各有11人标记 `starter=true` 且 `active=true`；按ESPN实际starting XI收录。阵容见同目录 `lineups.json`。
- ESPN summary无 `injuries` 字段（响应里该键不存在）；这只能记作本源未提供伤停字段，不能解释成无人伤停或全员健康。
- 当前赛前summary没有可用xG/xGA数值；射门等事件过程未转作xG。本批未获取额外xG来源。

## 原始响应与审计
每个ESPN调用均保存原始响应。`capture_manifest.json`记录请求URL、实际UTC起止、HTTP码、字节数和SHA-256。总计6个请求，全部200。请求顺序串行，约0.5秒间隔；本次发起前未发现本任务目录中的历史schedule缓存。文件：4份 `/teams/{ID}/schedule?season=2026`，以及2份当场 `/summary?event=...`。


比赛过程补充：见同目录 `match-process.md`，包含11/12最近过程、9/25本届首回合主客核对及基础技术统计；xG无可用字段。
