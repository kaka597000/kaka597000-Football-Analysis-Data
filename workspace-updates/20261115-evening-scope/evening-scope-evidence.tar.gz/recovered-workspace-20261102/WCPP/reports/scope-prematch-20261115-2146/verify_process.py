import json,sys,hashlib
from pathlib import Path
from datetime import datetime,timezone
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from research_program.nations_phase import verify_period_scores
R=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
metas=read(R/'form-early/capture_manifest.json')+[read(p) for p in (R/'form-early').glob('*.capture.json')];sources={}
for m in metas:sources[m['raw_file']]=dict(path=m['raw_file'],sha256=m['sha256'],source_url=m['url'],query_time=m['ended_at_utc'])
for p in (R/'form-late').glob('*.meta.json'):
 m=read(p);raw=p.parent/m['raw_file'];sources[str(raw)]=dict(path=str(raw),sha256=m['sha256'],source_url=m['source_url'],query_time=m['response_read_completed_at'])
process=[];conflicts=[]
for path,s in sources.items():
 assert sha(path)==s['sha256'];d=read(path)
 if not isinstance(d,dict) or 'header' not in d:continue
 c=d['header']['competitions'][0]
 if c['status']['type']['state']!='post':continue
 assert d['header']['league']['slug']=='uefa.nations' and c['status']['type']['completed']
 teams={};goals=[];red=[]
 for t in c['competitors']:
  p=verify_period_scores(t,c['status']);assert p and p['extra_time']==0 and p['shootout'] is None
  teams[str(t['team']['id'])]=dict(side=t['homeAway'],name=t['team']['displayName'],goals=p['regulation'])
 for t in d['boxscore']['teams']:
  tid=str(t['team']['id']);assert tid in teams;teams[tid]['stats']={x['name']:x.get('displayValue') for x in t['statistics']}
 for e in d.get('keyEvents',[]):
  kind=e.get('type',{}).get('type','')
  if e.get('scoringPlay'):
   assert e['period']['number'] in [1,2] and not e.get('shootout');tid=str(e['team']['id']);assert tid in teams
   goals.append(dict(id=e['id'],beneficiary_id=tid,kind=kind,minute=e['clock']['displayValue'],text=e.get('text'),participants=e.get('participants')))
  if kind=='red-card':red.append(dict(team_id=str(e['team']['id']),minute=e['clock']['displayValue'],text=e.get('text'),participants=e.get('participants')))
 for tid,t in teams.items():
  assert sum(x['beneficiary_id']==tid for x in goals)==t['goals']
  assert sum(x['team_id']==tid for x in red)==int(t['stats']['redCards'])
  pens=sum(x['beneficiary_id']==tid and x['kind']=='penalty---scored' for x in goals)
  if pens!=int(t['stats'].get('penaltyKickGoals',0)):conflicts.append(dict(event_id=c['id'],team_id=tid,field='penaltyKickGoals',aggregate=t['stats'].get('penaltyKickGoals'),verified_events=pens,used='scoring events'))
 process.append(dict(event_id=str(c['id']),kickoff_at=c['date'],teams=teams,goals=goals,red_cards=red,xg=None,source=s))
# Match every historical process result to the current summary's own-team form row.
forms=read(R/'verified-form.json');verified=0
for p in process:
 for f in forms:
  matches=[g for g in f['games'] if g['id']==p['event_id']]
  for g in matches:
   t=p['teams'][f['team_id']];other=next(v for k,v in p['teams'].items() if k!=f['team_id']);assert t['goals']==g['gf'] and other['goals']==g['ga'] and (t['side']=='home')==g['home'];verified+=1
for name,x in [('verified-process.json',process),('source-audit.json',dict(status='VERIFIED_WITH_DECLARED_GAPS',verified_at=datetime.now(timezone.utc).isoformat(),source_files=len(sources),historical_process_matches=len(process),form_process_rows_verified=verified,source_conflicts=conflicts,missing=['current same-provider xG/xGA','independent current injury/suspension bulletins','complete club workload','six late-match confirmed starting XIs'],scope_http_metadata_loss='17 no-event responses retained with unknown HTTP status/read time; not asserted as successful complete schedule coverage',models_or_weights_changed=False))]:
 with (R/name).open('x') as h:json.dump(x,h,ensure_ascii=False,indent=2)
print(json.dumps({'process':len(process),'verified_rows':verified,'conflicts':conflicts},ensure_ascii=False))
