#!/usr/bin/env python3
"""Idempotent schedule-only ESPN collection; existing raw responses are never refetched."""
import datetime as dt, fcntl, hashlib, json, pathlib, time, urllib.error, urllib.request
BASE=pathlib.Path(__file__).parent
RAW=BASE/'raw'; RAW.mkdir(parents=True,exist_ok=True)
CONFIG=pathlib.Path('/workspace/Football-Analysis/configs/analysis-scope.json')
ASOF=dt.datetime(2026,11,15,13,46,tzinfo=dt.timezone.utc)
END=dt.datetime(2026,11,16,0,0,tzinfo=dt.timezone.utc)
LOCK='/tmp/wcpp-espn-20261115-evening.lock'
def filenames(code):
    n=code.replace('.','_')
    return (RAW/(code+'.json'),RAW/(code+'.meta.json')) if code=='uefa.nations' else (RAW/(n+'.json'),RAW/(n+'.meta.json'))
def parse_events(data):
    out=[]
    for ev in data.get('events',[]):
        c=(ev.get('competitions') or [{}])[0]; ts=c.get('competitors',[])
        h=next((x for x in ts if x.get('homeAway')=='home'),{}); a=next((x for x in ts if x.get('homeAway')=='away'),{})
        team=lambda x:x.get('team') or {}
        out.append({'event_id':ev.get('id'),'date_utc':ev.get('date'),'state':(ev.get('status') or {}).get('type',{}).get('state'),'status_detail':(ev.get('status') or {}).get('type',{}).get('detail'),'home':team(h).get('displayName'),'home_id':team(h).get('id'),'away':team(a).get('displayName'),'away_id':team(a).get('id'),'season':ev.get('season'),'competition_notes':c.get('notes')})
    return out
def fetch(code):
    p,m=filenames(code); url=f'https://site.api.espn.com/apis/site/v2/sports/soccer/{code}/scoreboard?dates=20261115'
    with open(LOCK,'a+') as lk:
        fcntl.flock(lk,fcntl.LOCK_EX)
        start=dt.datetime.now(dt.timezone.utc).isoformat(); req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'})
        try:
            with urllib.request.urlopen(req,timeout=12) as r:
                body=r.read(); status=r.status
        except urllib.error.HTTPError as e:
            body=e.read(); status=e.code
        complete=dt.datetime.now(dt.timezone.utc).isoformat(); p.write_bytes(body)
        meta={'url':url,'request_start_utc':start,'read_complete_utc':complete,'http_status':status,'sha256':hashlib.sha256(body).hexdigest(),'bytes':len(body)}
        m.write_text(json.dumps(meta,indent=2)); time.sleep(.4); fcntl.flock(lk,fcntl.LOCK_UN)
    return meta
def main():
    config=json.loads(CONFIG.read_text()); items=[]
    for c in config['competitions']:
        code=c['code']; p,m=filenames(code)
        if not p.exists():
            meta=fetch(code)
            if meta.get('http_status') in (401,403,429):
                items.append({'code':code,'name':c['name'],'status':'failed','http_status':meta['http_status'],'meta':meta})
                break
        if not p.exists(): continue
        raw=p.read_bytes(); meta=json.loads(m.read_text()) if m.exists() else {}
        status=meta.get('http_status')
        if status and status>=400:
            items.append({'code':code,'name':c['name'],'status':'interface_unsupported' if status==400 else 'failed','http_status':status,'meta':meta,'event_count':0,'future_events':[],'excluded_events':[],'reason':f'ESPN endpoint returned HTTP {status}'}); continue
        try: events=parse_events(json.loads(raw))
        except Exception as e:
            items.append({'code':code,'name':c['name'],'status':'failed','reason':type(e).__name__+': '+str(e),'meta':meta}); continue
        future=[]; excluded=[]
        for e in events:
            try: t=dt.datetime.fromisoformat(e['date_utc'].replace('Z','+00:00'))
            except Exception: excluded.append({**e,'exclusion':'missing_or_invalid_time'}); continue
            if ASOF<t<END: future.append(e)
            else: excluded.append({**e,'exclusion':'not_after_as_of_or_outside_window'})
        items.append({'code':code,'name':c['name'],'status':('matches_found' if events else ('zero_events_http_unverified' if status is None else 'zero_matches')),'http_status':status,'http_status_missing_note':('HTTP status lost during collection; raw JSON body retained and parsed.' if status is None else None),'meta':meta,'event_count':len(events),'future_events':future,'excluded_events':excluded})
    coverage={'schema':'WCPP-SCHEDULE-COVERAGE-1','as_of_utc':ASOF.isoformat(),'window_end_utc_exclusive':END.isoformat(),'window_beijing':'2026-11-15 21:46 to 2026-11-16 08:00','source':'ESPN public soccer scoreboard, dates=20261115; response bodies, URLs and request metadata in raw/','future_rule':'kickoff after as_of and before end; all other events retained under excluded_events','score_basis':'regulation_90','scope_config':str(CONFIG),'competition_count':len(items),'competitions':items}
    (BASE/'coverage.json').write_text(json.dumps(coverage,ensure_ascii=False,indent=2))
if __name__=='__main__': main()
