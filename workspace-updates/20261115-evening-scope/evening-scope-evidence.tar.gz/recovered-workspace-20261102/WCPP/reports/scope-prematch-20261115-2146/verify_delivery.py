"""Validate this delivery's actual data and freezes, including the missed deadline."""
import json,sys,hashlib,traceback
from pathlib import Path
from datetime import datetime,timezone
import numpy as np
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from research.analysis_freeze import save,verify
from v2.model import total_settlement
R=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=lambda:datetime.now(timezone.utc).isoformat()
def write(p,x):
 with Path(p).open('x') as h:json.dump(x,h,ensure_ascii=False,indent=2,allow_nan=False)
d=read(R/'delivery.json');rows=read(R/'analysis-records.json');allf=read(R/'prepared-fixtures.json')
assert len(rows)==6 and d['delivery_failures']==2
for ref in d['all_receipts']:
 z=verify(read(ref['path']));assert z['record_sha256']==ref['sha256']
 if z['stage']=='prematch': assert datetime.fromisoformat(z['recorded_at'])<datetime.fromisoformat(z['fixture']['kickoff_at'].replace('Z','+00:00'))
for x in rows:
 f,p=x['fixture'],x['payload'];a=verify(read(x['active_receipt']['path']));c=verify(read(x['comprehensive_receipt']['path']))
 assert a['payload']['current_model']['matrix'] is None and a['payload']['test_model']['matrix'] is None
 assert c['selection_audit']['top3_ready'] and c['payload']==p
 assert f['phase']=='PreMatch' and f['identity_verified']
 assert sha(f['phase_evidence']['source_path'])==f['phase_evidence']['source_sha256']
 q=p['actual_quote'];assert q==f['total_quote'] and sha(R/'market/odds.json')==q['source_sha256']
 for role in ['current','test']:
  z=p['model_outputs'][role];old=read(R/'candidate-update'/(f['match_id'].replace(':','-')+'.json'))[role]
  for k,v in old.items():assert z[k]==v
  assert np.isclose(np.sum(z['matrix']),1,atol=1e-12)
  for probabilities in z['actual_total_settlement'].values():assert abs(sum(probabilities.values())-1)<1e-12
assert sha('/workspace/WCPP/runtime/active-model.json')==d['active_registry_sha256']
oldpath='/workspace/WCPP/forecasts/issued-analyses/0054063932e6a64a6684cc7831a26ae7ad1d9120a49cd7385effe0c578bbf7c3/000001.json';old=verify(read(oldpath))
# Reproduce only the failed pure calculation; no expired fixture is issued or inferred again.
try:total_settlement(read(R/'candidate-update/espn-401861171.json')['current']['matrix'],2.25,'under')
except TypeError as e:error=dict(exception=type(e).__name__,message=str(e),reproduced_at=now(),scope='pure calculation only; no network or expired prematch publication')
else:raise AssertionError('Expected original matrix-type failure not reproduced')
fail=dict(status='PARTIAL_DELIVERY',initial_population=[f['match_id'] for f in allf],candidate_predictions_saved_before_all_kickoffs=True,successful_comprehensive=6,failed_comprehensive=['espn:401861171','espn:401861172'],error_reproduction=error,failed_script=dict(path=str(R/'finalize.py'),sha256=sha(R/'finalize.py')),retained_partial_active_freeze=dict(path=oldpath,sha256=old['record_sha256'],freeze_id=old['freeze_id'],recorded_at=old['recorded_at']),disposition='No early-match manual primary is issued retrospectively. Preserve candidates as real prematch revisions; original unfrozen draft is failure evidence only, never a score claim. Keep both failures in all-eight coverage.',root_cause='Delivery code passed a JSON list into a NumPy boolean-index settlement function. The corrected new delivery converts the unchanged matrix to ndarray and selects only genuinely future fixtures. No model or frozen payload is edited.',additional_render_fix='p_ge_2/p_ge_3 descriptive output keys corrected before successful rerun',resume_script=str(R/'finalize_resume.py'))
write(R/'delivery-failure.json',fail)
fref=save(fail,dict(match_id='delivery-failure:scope-20261115-2146',kickoff_at='2026-11-15T14:00:00+00:00',cutoff_at=now()),stage='review',track='delivery-audit')
write(R/'delivery-failure-receipt.json',fref)
write(R/'verification.json',dict(status='PASS_WITH_TWO_DECLARED_DELIVERY_FAILURES',verified_at=now(),original_population=8,candidate_pairs=8,prematch_comprehensive=6,comprehensive_failures=2,model_hashes_and_payloads_unchanged=True,real_quotes_verified=8,all_successful_predictions_before_kickoff=True,active_registry_unchanged=True,existing_report_receipt=d['report_receipt'],failure_audit_receipt=fref,formal_promotion=False))
print(json.dumps(dict(status='PASS_WITH_TWO_DECLARED_DELIVERY_FAILURES',frozen_receipts_verified=len(d['all_receipts']),failure_receipt=fref),ensure_ascii=False))
