"""Verify retained sources and run unchanged grade-specific Nations candidates."""
import json,hashlib,sys,shutil
from pathlib import Path
from datetime import datetime,timezone
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from research_program.nations_phase import classify_source_phase
from automation.market_snapshot import build
from automation.market_bridge import attach_total_quote
from nations_league import safe_cli
from research.team_goal_analysis import summarize_prediction
from research.score_distribution_audit import audit_prediction
from research_program.future_validation import quote_audit
R=Path(__file__).resolve().parent;F=Path('/workspace/WCPP/forecasts/issued-analyses')
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=lambda:datetime.now(timezone.utc)
def write(p,x):
 with Path(p).open('x') as h:json.dump(x,h,ensure_ascii=False,indent=2,allow_nan=False)
def aware(t):return datetime.fromisoformat(t.replace('Z','+00:00'))
boardp=R/'schedule/raw/uefa.nations.json';bm=read(boardp.with_suffix('.meta.json'));board=read(boardp);assert sha(boardp)==bm['sha256']
assert len(board['events'])==8
early=read(R/'form-early/capture_manifest.json')
for p in (R/'form-early').glob('*.capture.json'):early.append(read(p))
summaries={}
for meta in early:
 if '/summary?' not in meta['url']:continue
 p=Path(meta['raw_file']);d=read(p);eid=str(d['header']['id'])
 summaries[eid]=(p,dict(file=str(p),url=meta['url'],sha256=meta['sha256'],captured_at=meta['ended_at_utc'],requested_at=meta['started_at_utc']))
for meta in (R/'form-late').glob('summary-*.meta.json'):
 z=read(meta);p=meta.parent/z['raw_file'];d=read(p);eid=str(d['header']['id'])
 summaries[eid]=(p,dict(file=str(p),url=z['source_url'],sha256=z['sha256'],captured_at=z['response_read_completed_at'],requested_at=z['request_started_at']))
assert {str(e['id']) for e in board['events']}<=summaries.keys(),'wait for all eight current summaries'
dest=R/'validated-market';dest.mkdir(exist_ok=False);mm=read(R/'market/source-metadata.json')['odds'];shutil.copy2(R/'market/odds.json',dest/'odds.json');shutil.copy2(boardp,dest/'identity.json')
odds=dict(mm,captured_at=mm['response_read_complete_at']);identity=dict(file='identity.json',sha256=bm['sha256'],url=bm['url'],requested_at=bm['request_start_utc'],captured_at=bm['read_complete_utc'])
t=now();channel=build(dest,odds,identity,cutoff=t.isoformat(),now=t,competition='uefa.nations',market_max_age_seconds=3600)
write(dest/'source-metadata.json',dict(odds=odds,identity=identity));write(dest/'market-channel.json',channel)
mapping={x['match_id']:x for x in channel['identity_mappings']};fixtures=[];forms=[];lineups=[];audits=[]
for e in sorted(board['events'],key=lambda e:(e['date'],e['id'])):
 eid=str(e['id']);p,meta=summaries[eid];raw=read(p);c=raw['header']['competitions'][0];phase=classify_source_phase(raw)
 assert sha(p)==meta['sha256'] and phase['complete'] and phase['stage']=='league-phase'
 assert raw['header']['league']['slug']=='uefa.nations' and c['id']==eid and c['status']['type']['state']=='pre' and c['status']['type']['completed'] is False
 assert aware(c['date'])==aware(e['date']) and type(c['neutralSite']) is bool
 sides={s['homeAway']:'espn:'+str(s['team']['id']) for s in c['competitors']};assert len(sides)==2
 assert sides=={s['homeAway']:'espn:'+str(s['team']['id']) for s in e['competitions'][0]['competitors']}
 f=dict(match_id='espn:'+eid,source_event_id=eid,competition='uefa.nations',gender='men',age='senior',entity='national',cohort='uefa.nations:'+phase['league_level']+':league-phase',league_level=phase['league_level'],stage='league-phase',**sides,date=aware(c['date']).date().isoformat(),kickoff_at=c['date'],phase='PreMatch',neutral=c['neutralSite'],cutoff_at=now().isoformat(),phase_evidence=dict(source_path=str(p),source_sha256=sha(p),source_url=meta['url'],query_time=meta['captured_at']),identity_verified=True,score_basis='regulation_90')
 f,au=attach_total_quote(f,dest,provider_order=('the-odds-api',),bookmaker_order=('pinnacle','leovegas_se'),now=now());audits.append(dict(match_id=f['match_id'],audit=au))
 if f.get('total_quote'):assert quote_audit(f)['eligible']
 f['market_snapshots']=[]
 if f['match_id'] in mapping:
  pid=mapping[f['match_id']]['provider_match_id'];book=f.get('total_quote',{}).get('bookmaker','pinnacle')
  history=Path('/workspace/WCPP/reports/remaining-nations-brazil-20261115-0240/market-nations')
  for path,mt in [(history/'odds.json',read(history/'source-metadata.json')['odds']),(dest/'odds.json',odds)]:
   assert sha(path)==mt['sha256'];matches=[x for x in read(path) if x['id']==pid]
   if not matches:continue
   assert len(matches)==1;src=matches[0];assert aware(src['commence_time'])==aware(f['kickoff_at'])
   for b in src['bookmakers']:
    if b['key']!=book:continue
    for m in b['markets']:
     if m['key'] not in ['h2h','totals']:continue
     names={src['home_team']:'home',src['away_team']:'away','Draw':'draw'} if m['key']=='h2h' else {'Over':'over','Under':'under'}
     f['market_snapshots'].append(dict(match_id=f['match_id'],bookmaker=book,market='1x2' if m['key']=='h2h' else 'totals',line=m['outcomes'][0].get('point'),decimal_odds={names[o['name']]:o['price'] for o in m['outcomes']},quoted_at=m['last_update'],query_time=mt['captured_at'],source_url=mt['url'],source_sha256=mt['sha256']))
 safe_cli.validate_future(f);fixtures.append(f)
 for team in raw['lastFiveGames']:
  tid=str(team['team']['id']);games=[]
  for g in team['events']:
   if g.get('competitionName')!='2026-27 UEFA Nations League' or g.get('roundName')!='League Phase':continue
   ishome=str(g['homeTeamId'])==tid;assert ishome or str(g['awayTeamId'])==tid;assert aware(g['gameDate'])<now()
   gf,ga=map(int,(g['homeTeamScore'],g['awayTeamScore']) if ishome else (g['awayTeamScore'],g['homeTeamScore']))
   games.append(dict(id=str(g['id']),date=g['gameDate'],home=ishome,gf=gf,ga=ga,opponent=g['opponent']['displayName'],opponent_id=str(g['opponent']['id'])))
  assert len(games)==len({g['id'] for g in games})==5
  def stat(gs):return dict(n=len(gs),W=sum(x['gf']>x['ga'] for x in gs),D=sum(x['gf']==x['ga'] for x in gs),L=sum(x['gf']<x['ga'] for x in gs),GF=sum(x['gf'] for x in gs),GA=sum(x['ga'] for x in gs))
  forms.append(dict(fixture_id=eid,team=team['team']['displayName'],team_id=tid,games=games,overall=stat(games),home=stat([g for g in games if g['home']]),away=stat([g for g in games if not g['home']]),source=f['phase_evidence'],latest_not_in_model_training=any(g['date'][:10]>'2026-10-06' for g in games)))
 roster=[]
 for team in raw.get('rosters',[]):
  starters=[dict(id=str(v['athlete']['id']),name=v['athlete']['displayName'],position=v.get('position'),active=v.get('active'),starter=v.get('starter')) for v in team.get('roster',[]) if v.get('starter') is True]
  if starters:assert len(starters)==len({x['id'] for x in starters})==11
  roster.append(dict(team_id=str(team['team']['id']),team=team['team']['displayName'],starters=starters))
 lineups.append(dict(match_id=f['match_id'],source=f['phase_evidence'],teams=roster,confirmed_full_xi=len(roster)==2 and all(len(t['starters'])==11 for t in roster),injury_status='NO_INDEPENDENT_VERIFIED_AVAILABILITY_LIST',not_empty_means_healthy=False))
write(R/'prepared-fixtures.json',fixtures);write(R/'verified-form.json',forms);write(R/'lineup-verification.json',lineups);write(R/'market-attachment-audit.json',audits)
safe_cli.freeze_pairs('/workspace/nations-model-20261110/models/candidates.json',fixtures,R/'candidate-update',F)
diags=[]
for f in fixtures:
 p=read(R/'candidate-update'/(f['match_id'].replace(':','-')+'.json'))
 diags.append(dict(match_id=f['match_id'],quote=f.get('total_quote'),**{r:dict(primary=p[r]['primary'],wdl=p[r]['wdl'],training_data_cutoff=p[r]['training_data_cutoff'],goal_analysis=summarize_prediction(p[r]),distribution=audit_prediction(p[r])) for r in ['current','test']}))
write(R/'diagnostics.json',diags)
print(json.dumps(dict(fixtures=len(fixtures),market_mapped=len(mapping),observations=sum(len(s['observations']) for s in channel['snapshots']),full_xi=sum(x['confirmed_full_xi'] for x in lineups),excluded=channel['excluded']),ensure_ascii=False))
