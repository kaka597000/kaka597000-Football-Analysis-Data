# 赛前人员、伤停和 xG 补充核查

补充获取时间：北京时间 2026-11-15 22:06:39–22:06:47（UTC 14:06:39–14:06:47）。本补充仅核查冻结时已缓存 summary 的字段、发布时间，以及官方公开来源的可访问性；不改写 22:03 首版，不重新抓取比赛实况，不新增赛事判断。

## 已缓存 ESPN summary 字段核查

核对 6 场：Belarus–Albania（401861173）、Finland–San Marino（401861174）、Spain–England（401861175）、Belgium–Italy（401861176）、France–Türkiye（401861177）、Croatia–Czechia（401861178）。原始 ESPN summary 的事件状态均为 pre；每队 upcoming `rosters[].roster` 均为 0 人、无 formation。6场均无 `injuries` 字段。不能据此声称无人伤停、确认首发或确认停赛。

| 比赛 | ESPN summary 本地缓存/实际抓取时间（北京时间） | news中最近发布时间 | news是否提供本场人员确认 |
|---|---|---|---|
| Belarus–Albania | 11/15 21:50:55–21:50:57 | 11/15 21:16:09（UTC 13:16:09） | 否；展示的最新文章是 England–Spain 排位形势，与本场人员无关 |
| Finland–San Marino | 11/15 21:50:57–21:50:59 | 11/15 21:16:09（UTC 13:16:09） | 否；同上 |
| Spain–England | 11/15 21:49:18–21:49:19 | 11/15 21:16:09（UTC 13:16:09） | 否；新闻为赛前背景，没有阵容确认 |
| Belgium–Italy | 11/15 21:49:13–21:49:14 | 11/15 21:16:09（UTC 13:16:09） | 否；新闻为通用欧国联内容 |
| France–Türkiye | 11/15 21:49:16–21:49:18 | 11/15 21:16:09（UTC 13:16:09） | 否；新闻为通用欧国联内容 |
| Croatia–Czechia | 11/15 21:49:14–21:49:15 | 11/15 21:16:09（UTC 13:16:09） | 否；新闻为通用欧国联内容 |

`published` / `lastModified` 为 ESPN News 对象字段；上述 news 列表最新一条的标题为 “England Nations League permutations: What they need vs. Spain and why it matters”，并非任一场的伤停或名单公告。所有6场的 summary boxscore 仅有赛季汇总进球、失球、净胜球、助攻等字段，不含 xG / expected goals。当前可访问的本批 ESPN summary 同源数据没有可用的本届 xG 字段或覆盖；之前过程统计中的射正不是 xG。本结论不以历史开源 StatsBomb 数据替代本届国家队 xG。

## 上轮红牌及纪律核实

沿用 form-early 已缓存事件，不重抓比赛：

- Finland 上轮对 Albania，ESPN keyEvent `55185385`：Miro Tenho 第67分钟被出示红牌（wallclock 2026-11-12T21:08:41Z）。
- Belarus 上轮对 San Marino，ESPN keyEvent `55187740`：Aleksandr Svirepa 第90+3分钟因第二张黄牌被罚下（wallclock 2026-11-12T21:34:50Z）。

这只确认 ESPN 事件记录中的场上判罚；本次未能由可访问的官方UEFA/足协来源确认后续纪律裁决、自动停赛适用或本场出场资格，故不推定停赛长度或资格。

## 官方来源查询回执（最多4次）

| 官方来源 | URL | HTTP | 实际采集时间（UTC） | 结果 |
|---|---|---:|---|---|
| UEFA Nations League News | https://www.uefa.com/uefanationsleague/news/ | 200 | 2026-11-15 14:06:39.802992–14:06:42.120916 | 页面可访问；页面内容不含 Belarus、Finland、两名球员姓名、停赛或伤病信息，无法确认相关人员状态 |
| Finnish FA (Palloliitto) News | https://www.palloliitto.fi/ajankohtaista/ | 403 | 2026-11-15 14:06:42.121635–14:06:42.985303 | 拒绝访问；不重试、不绕过 |
| Belarusian FA (ABFF) News | https://abff.by/news | 503 | 2026-11-15 14:06:42.986036–14:06:45.234095 | 服务不可用；不重试 |
| Belarusian FA (ABFF) English News | https://abff.by/en/news | 503 | 2026-11-15 14:06:45.234622–14:06:47.235129 | 服务不可用；不重试 |

逐次响应原文及真实开始/读完时间、SHA256、URL保存在本目录相应 `*.html` 与 `*.meta.json`。官方来源未能提供可验证的个体伤停、停赛或纪律决定；这是本次补充的具体缺口。

## 缓存索引

- upcoming summary 原文与采集元数据：`../summary-401861175.raw.json` / `../summary-401861175.meta.json` 至 `summary-401861178`；Belarus–Albania、Finland–San Marino：`../../form-early/summary_Belarus-Albania.json`、`summary_Belarus-Albania.capture.json`、`summary_Finland-SanMarino.json`、`summary_Finland-SanMarino.capture.json`。
- 上轮红牌比赛原文：`../../form-early/recent_Albania-Finland.json`、`recent_Albania-Finland.capture.json`、`recent_SanMarino-Belarus.json`、`recent_SanMarino-Belarus.capture.json`。
