# Nations League late match form/process evidence

采集时点：北京时间 11/15 21:49–21:50（UTC 13:49–13:50）；仅赛前可用信息。

## 本届赛制与当前记录

四场均为 2026-27 UEFA Nations League League Phase，A1或A3小组最后一轮。ESP summary 的 `header.season.name` 与 `groups`/积分记录确认。比赛时间 2026-11-15T19:45Z = 北京时间 11/16 03:45。

| 赛事 | 小组 | 当前积分/战绩 |
|---|---|---|
| Belgium–Italy | GROUP 1 | Belgium 9分（胜平负 3-0-2）；Italy 10分（胜平负 3-1-1） |
| Croatia–Czechia | GROUP 3 | Croatia 3分（胜平负 1-0-4）；Czechia 0分（胜平负 0-0-5） |
| France–Türkiye | GROUP 1 | France 10分（胜平负 3-1-1）；Türkiye 0分（胜平负 0-0-5） |
| Spain–England | GROUP 3 | Spain 15分（胜平负 5-0-0）；England 12分（胜平负 4-0-1） |

## 各队本届最近4场同赛事

schedule endpoint 每队返回5场当前赛季欧国联赛事；仅取截至本场前已结束的最近4场，未混入友谊赛/世预赛。成绩按该队视角：
- **Belgium**：401861145 Belgium 2-1 Türkiye（胜）；401861129 Belgium 1-4 France（负）；401861109 Belgium 3-0 Türkiye（胜）；401861081 Belgium 0-1 France（负）
- **Italy**：401861151 Italy 3-1 France（胜）；401861131 Italy 3-1 Türkiye（胜）；401861103 Italy 1-1 France（平）；401861077 Italy 4-1 Türkiye（胜）
- **Croatia**：401861150 Croatia 1-2 England（负）；401861137 Croatia 1-2 Spain（负）；401861113 Croatia 0-7 England（负）；401861084 Croatia 1-4 Spain（负）
- **Czechia**：401861148 Czechia 0-2 Spain（负）；401861142 Czechia 0-3 England（负）；401861118 Czechia 1-3 Spain（负）；401861092 Czechia 0-2 England（负）
- **France**：401861151 France 1-3 Italy（负）；401861129 France 4-1 Belgium（胜）；401861103 France 1-1 Italy（平）；401861081 France 1-0 Belgium（胜）
- **Türkiye**：401861145 Türkiye 1-2 Belgium（负）；401861131 Türkiye 1-3 Italy（负）；401861109 Türkiye 0-3 Belgium（负）；401861077 Türkiye 1-4 Italy（负）
- **Spain**：401861148 Spain 2-0 Czechia（胜）；401861137 Spain 2-1 Croatia（胜）；401861118 Spain 3-1 Czechia（胜）；401861084 Spain 4-1 Croatia（胜）
- **England**：401861150 England 2-1 Croatia（胜）；401861142 England 3-0 Czechia（胜）；401861113 England 7-0 Croatia（胜）；401861092 England 2-0 Czechia（胜）

## 最近一场与首回合过程统计

来源：ESPN summary boxscore team statistics 与 keyEvents；统计不插补。射正没有替代xG。

### Belgium–Italy
**最近一场** event 401861145：Türkiye 1 - Belgium 2。
- Türkiye: 控球 53.2%；射门 10、射正 7、被封堵 2、角球 2；黄牌 2、红牌 0；点球射门/进球 0/0。xG：ESPN summary 未提供字段，缺失。
- Belgium: 控球 46.8%；射门 12、射正 6、被封堵 2、角球 3；黄牌 0、红牌 0；点球射门/进球 0/0。xG：ESPN summary 未提供字段，缺失。
关键事件（按事件 ID 去重；goal/red card/penalty/own-goal）：55166633 20' Goal - Free-kick: Goal! Türkiye 1, Belgium 0. Arda Güler (Türkiye) from a free kick with a left footed shot to the top left corner.；55166882 27' Goal: Goal! Türkiye 1, Belgium 1. Kevin De Bruyne (Belgium) right footed shot from the centre of the box to the high centre of the goal. Assisted by Jérémy Doku.；55166984 30' Goal: Goal! Türkiye 1, Belgium 2. Charles De Ketelaere (Belgium) left footed shot from very close range to the bottom left corner. Assisted by Maxim De Cuyper.
**首回合** event 401861052：Italy 0 - Belgium 2。
- Italy: 控球 55.9%；射门 21、射正 6、被封堵 5、角球 4；黄牌 3、红牌 0；点球射门/进球 0/0。xG：ESPN summary 未提供字段，缺失。
- Belgium: 控球 44.1%；射门 19、射正 8、被封堵 6、角球 8；黄牌 5、红牌 0；点球射门/进球 0/0。xG：ESPN summary 未提供字段，缺失。
关键事件（按事件 ID 去重；goal/red card/penalty/own-goal）：52846313 20' Goal: Goal! Italy 0, Belgium 1. Mika Godts (Belgium) right footed shot from the centre of the box to the bottom left corner. Assisted by Kevin De Bruyne following a fast break.；52851433 69' Goal: Goal! Italy 0, Belgium 2. Dodi Lukébakio (Belgium) left footed shot from outside the box to the bottom left corner. Assisted by Charles De Ketelaere following a fast break.

### Croatia–Czechia
**最近一场** event 401861150：England 2 - Croatia 1。
- England: 控球 54.2%；射门 15、射正 4、被封堵 5、角球 6；黄牌 0、红牌 0；点球射门/进球 1/0。xG：ESPN summary 未提供字段，缺失。
- Croatia: 控球 45.8%；射门 13、射正 5、被封堵 2、角球 7；黄牌 1、红牌 0；点球射门/进球 0/0。xG：ESPN summary 未提供字段，缺失。
关键事件（按事件 ID 去重；goal/red card/penalty/own-goal）：55178456 24' Goal: Goal! England 1, Croatia 0. Morgan Rogers (England) right footed shot from very close range to the bottom right corner. Assisted by Jude Bellingham.；55184624 59' Goal: Goal! England 1, Croatia 1. Petar Sucic (Croatia) right footed shot from very close range to the top left corner following a corner.；55184918 64' Penalty - Scored: Goal! England 2, Croatia 1. Harry Kane (England) converts the penalty with a right footed shot to the centre of the goal.
**首回合** event 401861063：Czechia 1 - Croatia 2。
- Czechia: 控球 43.6%；射门 5、射正 2、被封堵 1、角球 1；黄牌 2、红牌 0；点球射门/进球 0/0。xG：ESPN summary 未提供字段，缺失。
- Croatia: 控球 56.4%；射门 16、射正 5、被封堵 5、角球 6；黄牌 1、红牌 0；点球射门/进球 0/0。xG：ESPN summary 未提供字段，缺失。
关键事件（按事件 ID 去重；goal/red card/penalty/own-goal）：52893032 47' Goal: Goal! Czechia 0, Croatia 1. Luka Modric (Croatia) right footed shot from the centre of the box to the top left corner. Assisted by Igor Matanovic.；52893726 54' Goal: Goal! Czechia 1, Croatia 1. Adam Karabec (Czechia) left footed shot from the centre of the box to the bottom right corner. Assisted by Adam Hlozek.；52896608 77' Goal - Header: Goal! Czechia 1, Croatia 2. Marco Pasalic (Croatia) header from very close range to the centre of the goal. Assisted by Ivan Perisic with a cross.

### France–Türkiye
**最近一场** event 401861151：Italy 3 - France 1。
- Italy: 控球 35.1%；射门 11、射正 5、被封堵 1、角球 4；黄牌 2、红牌 0；点球射门/进球 2/0。xG：ESPN summary 未提供字段，缺失。
- France: 控球 64.9%；射门 18、射正 5、被封堵 4、角球 3；黄牌 2、红牌 0；点球射门/进球 0/0。xG：ESPN summary 未提供字段，缺失。
关键事件（按事件 ID 去重；goal/red card/penalty/own-goal）：55176379 10' Goal: Goal! Italy 0, France 1. Michael Olise (France) right footed shot from the centre of the box to the bottom right corner.；55178791 26' Goal: Goal! Italy 1, France 1. Francesco Pio Esposito (Italy) right footed shot from the left side of the six yard box to the centre of the goal. Assisted by Nicolò Cambiaghi.；55184865 60' Penalty - Missed: Penalty missed. Sebastiano Esposito (Italy) right footed shot is close, but misses to the right.；55185297 63' Goal: Goal! Italy 2, France 1. Davide Frattesi (Italy) left footed shot from the centre of the box to the bottom left corner. Assisted by Federico Dimarco with a cross.；55186261 75' Penalty - Scored: Goal! Italy 3, France 1. Francesco Pio Esposito (Italy) converts the penalty with a right footed shot to the bottom left corner.
**首回合** event 401861053：Türkiye 0 - France 1。
- Türkiye: 控球 36.2%；射门 12、射正 3、被封堵 4、角球 5；黄牌 2、红牌 1；点球射门/进球 0/0。xG：ESPN summary 未提供字段，缺失。
- France: 控球 63.8%；射门 12、射正 4、被封堵 2、角球 3；黄牌 3、红牌 0；点球射门/进球 0/0。xG：ESPN summary 未提供字段，缺失。
关键事件（按事件 ID 去重；goal/red card/penalty/own-goal）：52850215 54' Goal: Goal! Türkiye 0, France 1. Kylian Mbappé (France) right footed shot from the centre of the box to the bottom left corner. Assisted by Michael Olise.；52853622 87' Red Card: Ugurcan Çakir (Türkiye) is shown the red card.

### Spain–England
**最近一场** event 401861148：Czechia 0 - Spain 2。
- Czechia: 控球 29.8%；射门 13、射正 0、被封堵 4、角球 4；黄牌 0、红牌 1；点球射门/进球 0/0。xG：ESPN summary 未提供字段，缺失。
- Spain: 控球 70.2%；射门 22、射正 5、被封堵 5、角球 10；黄牌 2、红牌 0；点球射门/进球 1/0。xG：ESPN summary 未提供字段，缺失。
关键事件（按事件 ID 去重；goal/red card/penalty/own-goal）：55180909 39' Penalty - Scored: Goal! Czechia 0, Spain 1. Álex Baena (Spain) converts the penalty with a right footed shot to the bottom left corner.；55185959 72' Red Card: Ladislav Krejcí (Czechia) is shown the red card.；55188029 90'+6' Goal: Goal! Czechia 0, Spain 2. Marc Pubill (Spain) right footed shot from the centre of the box to the bottom right corner.
**首回合** event 401861066：England 2 - Spain 3。
- England: 控球 47.4%；射门 13、射正 5、被封堵 2、角球 6；黄牌 3、红牌 0；点球射门/进球 1/0。xG：ESPN summary 未提供字段，缺失。
- Spain: 控球 52.6%；射门 15、射正 5、被封堵 5、角球 3；黄牌 0、红牌 0；点球射门/进球 0/0。xG：ESPN summary 未提供字段，缺失。
关键事件（按事件 ID 去重；goal/red card/penalty/own-goal）：52888561 2' Goal: Goal! England 0, Spain 1. Lamine Yamal (Spain) left footed shot from the centre of the box to the bottom left corner.；52891473 36' Goal: Goal! England 1, Spain 1. Anthony Gordon (England) right footed shot from outside the box to the bottom right corner. Assisted by Jude Bellingham following a fast break.；52891784 40' Goal - Header: Goal! England 2, Spain 1. Harry Kane (England) header from the centre of the box to the bottom right corner. Assisted by Nico O'Reilly with a cross.；52895372 54' Penalty - Missed: Penalty missed. Harry Kane (England) right footed shot is close, but misses to the right.；52894653 60' Goal: Goal! England 2, Spain 2. Álex Baena (Spain) right footed shot from outside the box to the bottom right corner. Assisted by Dani Olmo.；52896454 74' Goal: Goal! England 2, Spain 3. Mikel Oyarzabal (Spain) left footed shot from the centre of the box to the centre of the goal. Assisted by Álex Baena.

## 首发、伤停、xG 与来源缺项

- 四场 upcoming summary 的 `rosters` 两队均为空阵容（0名球员）；没有 confirmed lineup。原 summary 无 injury collection/key，不能从空阵容推断无人伤停。
- 未使用赔率或射正推代xG；这批 ESPN 数据对8场过程统计均无 xG 字段。
- 比赛事件提取均用 keyEvents 的真实 event ID 去重。已检查：8场中无 own goal 事件；处罚/红牌事件见上文。
- 原文、URL、HTTP 状态、请求开始/读完时间与SHA256保存在同目录 `*.raw.json` / `*.meta.json`。总HTTP请求20/24；ESPN请求以共享fcntl锁单次串行，0.3秒锁内间隔。
