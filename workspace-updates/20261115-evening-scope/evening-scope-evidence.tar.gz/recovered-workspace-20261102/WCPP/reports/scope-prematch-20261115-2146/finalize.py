"""Issue eight independently compared prematch selections before earliest kickoff."""
import json,sys,hashlib,csv
from pathlib import Path
from datetime import datetime,timezone
from zoneinfo import ZoneInfo
sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from prediction_engine import predict_models
from research.analysis_freeze import save,verify
from research.market_movement import analyze
from research.team_goal_analysis import summarize_prediction
from research.score_distribution_audit import audit_prediction
from v2.model import total_settlement
from research_program.future_validation import quote_audit
R=Path(__file__).resolve().parent;F=Path('/workspace/WCPP/forecasts/issued-analyses');BJT=ZoneInfo('Asia/Shanghai')
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();now=lambda:datetime.now(timezone.utc).isoformat()
def write(p,x):
 with Path(p).open('x') as h:json.dump(x,h,ensure_ascii=False,indent=2,allow_nan=False)
def bt(t):return datetime.fromisoformat(t.replace('Z','+00:00')).astimezone(BJT).strftime('%m-%d %H:%M:%S')
fs=read(R/'prepared-fixtures.json');forms=read(R/'verified-form.json');process=read(R/'verified-process.json');lineups={x['match_id']:x for x in read(R/'lineup-verification.json')}
choices={
 '401861171':dict(name='拉脱维亚—亚美尼亚',primary='0-1',wdl='客胜',total_direction='小',scores=['0-1','1-1','0-0','1-2'],reason='拉脱维亚本届0胜1平4负、进3失8；亚美尼亚首回合主场2-0、射正4-1占优，最新对塞浦路斯射正7-2。综合偏客队小胜。',counter='亚美尼亚两个客场均未进球；拉脱维亚最新客场对黑山5次射正且进球，0-1的主队零球判断并不稳，1-1是主要反证。',total_reason='实际小2.25，结合亚美尼亚两客场0进球、拉脱维亚两主场仅1进球，低总球路径有依据；近两队最新合计射正12次为反证。2球仅半赢，3球全输，不因0-1直接推出小球。',zero={'home':{'reason':'拉脱维亚五场仅3球，两个主场1球，首回合只有1次射正。','counterevidence':'最新对黑山5次射正并进球，且亚美尼亚五场失6球，主队1球完全可能。'},'away':{'reason':'亚美尼亚首回合2球，最新26次射门7次射正。','counterevidence':'本届两个客场均0球，不能把主场高产直接外推客场。'}},priority=False),
 '401861172':dict(name='塞浦路斯—黑山',primary='1-1',wdl='平局',total_direction='观望',scores=['1-1','1-2','2-1','0-1'],reason='塞浦路斯两个主场全胜、进4失1；黑山五场不败，两个客场均赢但失3球。主队主场表现与客队整体成绩相抵，研究选双方各一球。黑山13分已超过次名8分加一场最高11分，不能写成必须获胜。',counter='塞浦路斯最新对亚美尼亚射正2-7处于劣势；黑山最新7次射正、首回合2-1，客胜路径仍强。黑山上场萨维奇两黄变红，不能在无官方停赛核验时编造处罚期限。',total_reason='实际2.5；原双候选偏低总球，但同机构大球赔率从1.97降到1.85，两队近期互有失球。低节奏与三球路径冲突，保留观望。',zero={'home':{'reason':'塞浦路斯两主场都进球，首回合也攻入1球。','counterevidence':'最新仅2次射正，黑山整体不败，0球仍有路径。'},'away':{'reason':'黑山五场进9球、两客场进5球。','counterevidence':'已锁定小组头名，进攻投入存在不确定性；没有量化战意权重。'}},priority=False),
 '401861173':dict(name='白俄罗斯—阿尔巴尼亚',primary='0-1',wdl='客胜',total_direction='小',scores=['0-1','1-1','0-0','1-2'],reason='阿尔巴尼亚4胜1负、进10失3，最新对芬兰射正6-1；首回合主场2-0白俄罗斯。白俄罗斯五场进7球中6球来自圣马力诺，对非弱旅得分受限，客胜倾向保留。',counter='白俄罗斯连续四场零封，两个主场均赢且不失球；阿尔巴尼亚曾客场1-2负芬兰。白俄罗斯上场红牌的处罚及晚场首发尚未独立核实，本场不列优先三场。',total_reason='实际盘由2.25降至2，两种盘口价格不直接作同盘水位比较。白俄罗斯四场零封及阿尔巴尼亚近场防守支持小2，但2球走盘而非全赢，客队压迫下三球是风险。',zero={'home':{'reason':'白俄罗斯对阿尔巴尼亚首回合0球，首回合射正2次，近期进球集中在圣马力诺。','counterevidence':'两个主场均得分，阿尔巴尼亚客场曾失2球；主队1球路径不能排除。'},'away':{'reason':'阿尔巴尼亚本届每场均得分，最新射正6次。','counterevidence':'白俄罗斯连续四场零封，0-0需要保留。'}},priority=False),
 '401861174':dict(name='芬兰—圣马力诺',primary='3-0',wdl='主胜',total_direction='小',scores=['3-0','2-0','4-0','3-1','5-0'],reason='圣马力诺五战全败、仅进1球失18球；芬兰首回合客场7-0，射正11-0。Test统计为2-0，结合对手差距比较2、3、4球后人工取3-0；首回合有红牌与点球，不能直接复制7球。',counter='芬兰近四场仅进2球，最近连续两场0球；上场出现红牌，晚场首发和具体停赛名单未独立核实。方向强于精确进球数；圣马力诺曾客场对阿尔巴尼亚进球，3-1是反证。',total_reason='实际4球；双方原候选完整总球分布及芬兰近期产量均不支持把首回合七球机械复刻，弱倾向小4；恰4球走盘，5球全输。大4赔率1.93降1.87是反证，未据此改永久进球率。',zero={'away':{'reason':'圣马力诺五场四次零球、首回合0次射正，最新对白俄罗斯仅1次射正。','counterevidence':'曾客场进阿尔巴尼亚1球，芬兰上场红牌人员影响未知，不能保证零封。'},'home':{'reason':'对手五场失18球、首回合射正差11-0，主队进球路径充分。','counterevidence':'芬兰近四场三场零球，进球集中于首回合，3-0不是高命中保证。'}},priority=True),
 '401861175':dict(name='西班牙—英格兰',primary='2-1',wdl='主胜',total_direction='观望',scores=['2-1','1-1','2-2','1-2'],reason='西班牙本届五战全胜、进14失5，主场两胜进7球；首回合客场3-2。最新对捷克射正5-0，保持持续得分路径；英格兰进16球，客队1球更合理。',counter='英格兰两个客场进9球且零失球，首回合射正5-5，双方Test胜率接近；西班牙最新首球点球、对手后段红牌，不能只看2-0。市场主胜1.80升1.97，也削弱强推。',total_reason='实际3球；两队攻击强、首回合5球，但西班牙领先积分、比赛控制与英格兰客场零封也支持低总球。3球走盘，在2球/4球以上两边缺乏优势，观望。',zero={'home':{'reason':'西班牙五场均至少2球，首回合3球。','counterevidence':'英格兰两客场均零封，0-1仍属于失败路径。'},'away':{'reason':'英格兰五场进16球，首回合进2球且曾罚失点球。','counterevidence':'西班牙最新让捷克0射正，客队面对控球压制可能得分下降。'}},priority=True),
 '401861176':dict(name='比利时—意大利',primary='1-1',wdl='平局',total_direction='观望',scores=['1-1','2-1','1-2','2-2'],reason='意大利最新3-1法国、射正5次，五场进11球；比利时首回合客场2-0意大利、射正8-6，主场仍有得分依据。双方攻守证据相抵，比较双向2球路径后取1-1。',counter='比利时落后意大利1分，后段争胜可能放大比分；意大利近三场均进3球，1-2/2-2不能忽略。首发未公布，模型两边胜率接近。',total_reason='实际2.75；双方进攻和晋级积分压力支持三球路径，但意大利保持积分领先的控制路径也成立。价格1.82/2.09到1.83/2.07变化小，方向观望。',zero={'home':{'reason':'比利时最新6次射正进2球，首回合进2球。','counterevidence':'主场曾0-1法国，近期对土耳其被打7次射正，比赛失控可能压低产量。'},'away':{'reason':'意大利五场11球、最新3球。','counterevidence':'首回合6次射正但0球，机会不必然兑现。'}},priority=False),
 '401861177':dict(name='法国—土耳其',primary='2-1',wdl='主胜',total_direction='小',scores=['2-1','2-0','1-0','3-1'],reason='法国本届进8失5，两个主场进5球；土耳其五战全败失13球。法国首回合客场1-0且进球早于对手红牌；主胜有多项支持。土耳其最新对比利时7次射正并进球，因此比机械零封更倾向2-1。',counter='法国最新1-3意大利、同样5次射正仍负，防守及转换不稳；土耳其进攻也可能未能兑现，2-0可替代。机构大3.5赔率下降，3-1及更高总球是主要风险。',total_reason='实际3.5；两候选原总球均值约3，法国首回合1-0、土耳其本届低进球支持弱小3.5；对手五场失13球和市场大球降水为反证。不把2-1总和单独当依据。',zero={'home':{'reason':'法国五场都有进球，土耳其五场均失球。','counterevidence':'原候选众数仅1球，首回合只进1球，主队进2球有不确定性。'},'away':{'reason':'土耳其最新7次射正并先进球，法国近三场均失球。','counterevidence':'土耳其首回合0球、两个客场合计1球，客队0球仍是强候选。'}},priority=True),
 '401861178':dict(name='克罗地亚—捷克',primary='2-0',wdl='主胜',total_direction='小',scores=['2-0','2-1','1-1','3-1'],reason='克罗地亚首回合客场2-1，射门16-5、射正5-2；最新对英格兰射正5次且进球。捷克五败只进2球，最新对西班牙0射正，综合偏主胜并比较客队0与1球。',counter='克罗地亚五场全部失球、累计失16球，捷克首回合也曾得分；虽然多数对手是西班牙与英格兰，仍不足以证明本场零封。零球反证明显，本场不列TOP3。',total_reason='实际2.75；捷克近两场0球、最新0射正支持弱小盘，同盘小球2.01降1.93；克罗地亚防守不稳，3球时小盘半输、4球全输，须保留尾部风险。',zero={'away':{'reason':'捷克五场仅2球、最新0射正，最近两场零球。','counterevidence':'克罗地亚五场均失球，首回合捷克2次射正进1球，零封不稳。'},'home':{'reason':'克罗地亚首回合射正5-2、最新对英格兰也5次射正，捷克五场均失至少2球。','counterevidence':'克罗地亚两个主场合计仅1球，机会转化不稳定。'}},priority=False)
}
crs={verify(read(x['path']))['match_id']:x for x in read(R/'candidate-update/receipts.json')};records=[];registry_sha=sha('/workspace/WCPP/runtime/active-model.json')
for f in fs:
 eid=f['source_event_id'];ch=choices[eid];q=f['total_quote'];assert quote_audit(dict(f,cutoff_at=now()))['eligible']
 try:predict_models(dict(f,cutoff_at=now()))
 except ValueError as e:assert str(e)=='no validated identity/history model for this cohort'
 else:raise ValueError('Unexpected active Nations route')
 failed=dict(status='ABSTAIN_NO_ACTIVE_ROUTE',matrix=None,primary=None,input=f)
 active=save(dict(current_model=dict(failed,model_label='当前模型'),test_model=dict(failed,model_label='test模型'),active_registry_sha256=registry_sha,candidate_substitution=False),dict(f,cutoff_at=now()),stage='prematch',track='current-test-pair')
 pair=read(R/'candidate-update'/(f['match_id'].replace(':','-')+'.json'));outputs={}
 for role in ['current','test']:
  p=pair[role];outputs[role]=dict(p,team_goal_analysis=summarize_prediction(p),score_distribution_audit=audit_prediction(p,ch['primary']),actual_total_settlement={s:total_settlement(p['matrix'],q['line'],s) for s in ['over','under']})
 ff=[x for x in forms if x['fixture_id']==eid];ids={f['home'].split(':')[-1],f['away'].split(':')[-1]};latest={max(x['games'],key=lambda g:g['date'])['id'] for x in ff};ctx=[p for p in process if p['event_id'] in latest or set(p['teams'])==ids]
 assert len(ctx)==3
 payload=dict(ch,compared_scores=ch['scores'],selection_scope='candidate_research',method_version='WCPP-NATIONS-MANUAL-20261115-EVENING-1',status='RESEARCH_COMPREHENSIVE',total_line=q['line'],actual_quote=q,current_test_reference=active,candidate_reference=crs[f['match_id']],model_outputs=outputs,selection_evidence=dict(compared_scores=ch['scores'],zero_vs_one=ch['zero'],three_plus_path='逐场比较'+','.join(ch['scores'])+'；落后追分、早球及防线空间可形成三球以上，领先控制也可降速。'+ch['counter'],total_reason=ch['total_reason']),nonmarket_evidence_classes=['current edition home-away results','verified recent and head-to-head chance creation','group points and game-state paths'],form_evidence=ff,process_evidence=ctx,lineup_evidence=lineups[f['match_id']],market_movement=analyze(dict(f,cutoff_at=now())),training_freshness='Original numerical candidates end 2026-10-06; fifth round 2026-11-12 is qualitative evidence only',xg_status='NO_VERIFIED_CURRENT_SAME_PROVIDER_XG',full_club_workload='UNVERIFIED',formal_kpi_eligible=False,active_model_promotion=False,numerical_weights_changed=False,exact_score_basis='regulation_90',source_commit='7a18cee715acb0633904af434b3f743d870c0951')
 comp=save(payload,dict(f,cutoff_at=now()),stage='prematch',track='comprehensive');assert verify(read(comp['path']))['selection_audit']['top3_ready']
 records.append(dict(fixture=f,payload=payload,active_receipt=active,candidate_receipt=crs[f['match_id']],comprehensive_receipt=comp))
write(R/'analysis-records.json',records)
byid={x['fixture']['source_event_id']:x for x in records};topids=['401861174','401861177','401861175'];items=[]
for n,eid in enumerate(topids,1):
 x=byid[eid];p=x['payload'];items.append(dict(rank=n,match_id=x['fixture']['match_id'],**{k:p[k] for k in ['primary','wdl','total_line','total_direction']},comprehensive_reference=x['comprehensive_receipt'],reason=p['reason'],risk=p['counter']))
shell=dict(match_id='analysis-night:20261115-2146',kickoff_at=min(f['kickoff_at'] for f in fs),cutoff_at=now())
top=save(dict(selection_scope='candidate_research',top3=items,population=[f['match_id'] for f in fs],ranking_basis='Evidence and counterevidence comparison, not calibrated hit probabilities. Finland/France exact scores less certain than result direction; Spain balanced matchup ranked third. Croatia zero-goal counterevidence prevents priority.',formal_kpi_eligible=False),shell,stage='prematch',track='top3-selection')
plan=save(dict(population=[dict(match_id=x['fixture']['match_id'],current_test_reference=x['active_receipt'],candidate_reference=x['candidate_receipt'],comprehensive_reference=x['comprehensive_receipt']) for x in records],top3_reference=top,status='PENDING_ALL_NOT_STARTED',policy='First prematch per track is default; revisions separate. One exact score only, no alternative-score credit; actual-line OU win/half_win/push/half_loss/loss, abstentions and pending retained.',score_basis='regulation_90',automatic_promotion=False),dict(shell,cutoff_at=now()),stage='prematch',track='forward-validation-plan')
lines=['# 覆盖范围内今晚赛前分析｜北京时间2026年11月15日','','HELLO BOSS','','本次比赛夜从11月15日晚至11月16日08:00。已确认并完成分析的未来赛事为8场欧国联；21项覆盖配置的核查与缺口均保留。巴甲接口明确当日无赛；韩K1接口400、日联杯接口400但官方四场均已过开球；另17项返回无赛事原文，采集脚本丢失HTTP状态/读取时间，不能据此声称覆盖检查全部成功。未分析已经开场的比赛。','',
 '以下为未晋级候选支持的人工综合研究。活动Current/Test仍拒绝欧国联路由，数值列为独立研究候选。原工件训练至10月6日，16队11月12日最新一轮未进入数值训练；本次核实本届各5场、最近赛及首回合过程作为综合背景，没有改权重。','',
 '盘口：Pinnacle真实报价北京时间21:48:29，API读完21:48:43；8/8有完整实际盘线及双边价格，230条可核验机构市场观测并非230场样本。按既有最长一小时赛前快照政策使用。前一快照为11月15日02:44，只有同机构同线才比较水位；白俄罗斯总球从2.25变2，属于变盘。','',
 '|北京时间|比赛|Current统计|Test统计|综合唯一比分|胜平负|实际大小球|','|---|---|---|---|---|---|---|']
for x in records:
 f,p=x['fixture'],x['payload'];lines.append(f"|{bt(f['kickoff_at'])[:14]}|{p['name']}|{p['model_outputs']['current']['primary']}|{p['model_outputs']['test']['primary']}|**{p['primary']}**|{p['wdl']}|{p['total_direction']} {p['total_line']:g}|")
lines+=['','当前/测试统计比分不等于综合推荐。小2.25遇2球半赢，小2/小4遇对应球数走盘，小2.75遇3球半输；观望不补算命中。','',
 '研究参考TOP3：芬兰—圣马力诺3-0（主胜、小4）；法国—土耳其2-1（主胜、弱小3.5）；西班牙—英格兰2-1（主胜、大小球观望3）。这是三场赛事各一个比分，不是每场三个候选比分。芬兰和法国的胜负方向依据强于精确比分；西英接近，第三位风险更高。','']
for x in records:
 f,p=x['fixture'],x['payload'];q=p['actual_quote'];lines += ['## '+p['name']+'｜'+bt(f['kickoff_at']),'',p['reason'],'','主要反证：'+p['counter'],'','候选比较：'+ '、'.join(p['scores'])+'。选分与盘口均独立记录。','',p['total_reason'],'',f"实际报价：{q['bookmaker']}，{q['line']:g}球，大{q['over_odds']} / 小{q['under_odds']}；报价{bt(q['quoted_at'])}。",'']
 for ff in p['form_evidence']:
  a=ff['overall'];lines.append(f"- {ff['team']}本届5场：{a['W']}胜{a['D']}平{a['L']}负，进{a['GF']}失{a['GA']}；主场{ff['home']}，客场{ff['away']}。")
 lines+=['','|候选模型|主/客进球均值|中央80%区间 主/客|主/客零球概率|主/客至少2球概率|主/客至少3球概率|','|---|---|---|---|---|---|']
 for role in ['current','test']:
  z=p['model_outputs'][role];g=z['team_goal_analysis'];a,b=g['home'],g['away'];lines.append(f"|{z['version']}|{a['mean']:.2f}/{b['mean']:.2f}|{a['central_interval']}/{b['central_interval']}|{a['p0']:.1%}/{b['p0']:.1%}|{a['p_ge2']:.1%}/{b['p_ge2']:.1%}|{a['p_ge3']:.1%}/{b['p_ge3']:.1%}|")
 lines+=['','以上为模型内部概率，未校准成综合判断概率，也不代表已验证区间覆盖率。','']
 for side,z in p['zero'].items():lines.append(('主队' if side=='home' else '客队')+'0与1球：'+z['reason']+' 反证：'+z['counterevidence'])
 lines+=['','首发：'+('ESPN当次原文双方各11名starter，名单已保存；独立伤停公告仍缺。' if p['lineup_evidence']['confirmed_full_xi'] else '本场完整首发尚未在取回来源中公布；按已核实近况与轮换情景研究，不假设无人伤停。'),'','综合冻结：`'+x['comprehensive_receipt']['freeze_id']+'`（'+bt(x['comprehensive_receipt']['recorded_at'])+'北京时间）。','']
lines+=['## 数据与后续验证','','原始响应/球队身份/阶段/主客/90分钟比分已核验。16场历史过程与当前summary的32条球队赛果一致；有6处点球汇总字段与事件不符，保留原始汇总并采用进球事件解释。未获得真实当前同源xG，不把射正当xG；完整俱乐部负荷、独立最新伤停/停赛公告仍缺。红牌只证明历史事件，不擅自断言当前停赛期限。','',
 '本次不拟合、改融合权重、晋级活动模型或发布环境。Current/Test、候选、综合和TOP3分别冻结，之后按首版/修订分开复盘。本日下午复盘未证明人工改分有稳定增益，今晚仍是待验证研究，不能承诺命中率。']
report='\n'.join(lines)+'\n';(R/'今晚赛事分析.md').write_text(report)
rr=save(dict(markdown=report,comprehensive_receipts=[x['comprehensive_receipt'] for x in records],top3_receipt=top,forward_plan_receipt=plan,source_commit='7a18cee715acb0633904af434b3f743d870c0951',formal_kpi_eligible=False),dict(shell,cutoff_at=now()),stage='prematch',track='analysis-report')
receipts=[read(R/'candidate-update/plan-receipt.json'),top,plan,rr]+[x[k] for x in records for k in ['candidate_receipt','active_receipt','comprehensive_receipt']]
for ref in receipts:
 z=verify(read(ref['path']));assert z['record_sha256']==ref['sha256']
 if z['stage']=='prematch':assert datetime.fromisoformat(z['recorded_at'])<datetime.fromisoformat(z['fixture']['kickoff_at'].replace('Z','+00:00'))
assert sha('/workspace/WCPP/runtime/active-model.json')==registry_sha
write(R/'delivery.json',dict(report_receipt=rr,top3_receipt=top,forward_plan_receipt=plan,all_receipts=receipts,population=8,primary_selections=8,wdl_selections=8,total_selections=5,total_abstentions=3,full_starting_xi_games=2,source_commit='7a18cee715acb0633904af434b3f743d870c0951',source_main_commit='1257fdde7b6746b7ba6d2aa919382214a2cfb589',active_registry_sha256=registry_sha,active_model_changed=False,environment_published=False,all_before_kickoff=True))
with (R/'比赛分析展示.csv').open('x',encoding='utf-8-sig',newline='') as h:
 w=csv.writer(h);w.writerow(['北京时间','比赛','Current统计','Test统计','综合唯一比分','胜平负','大小球方向','实际盘线','报价北京时间','冻结ID'])
 for x in records:
  f,p=x['fixture'],x['payload'];w.writerow([bt(f['kickoff_at']),p['name'],p['model_outputs']['current']['primary'],p['model_outputs']['test']['primary'],p['primary'],p['wdl'],p['total_direction'],p['total_line'],bt(p['actual_quote']['quoted_at']),x['comprehensive_receipt']['freeze_id']])
print(json.dumps(dict(report=rr,top3=top,receipts=len(receipts)),ensure_ascii=False))
