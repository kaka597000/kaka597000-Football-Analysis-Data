#!/usr/bin/env python3
"""One bounded, sequential ESPN scoreboard recheck. No retries."""
import datetime as dt,fcntl,hashlib,json,pathlib,time,urllib.request,urllib.error
BASE=pathlib.Path(__file__).parent; RAW=BASE/'raw'; RAW.mkdir(parents=True,exist_ok=True)
LOCK='/tmp/wcpp-espn-20261115-evening.lock'
CODES=['eng.1','esp.1','ger.1','ita.1','fra.1','jpn.1','aus.1','usa.1','fin.1','nor.1','swe.1','ned.1','uefa.champions','uefa.europa','uefa.europa.conf','afc.champions','fifa.world']
ASOF=dt.datetime(2026,11,15,13,46,tzinfo=dt.timezone.utc); END=dt.datetime(2026,11,16,0,0,tzinfo=dt.timezone.utc)
items=[]; stopped=None
for code in CODES:
    path=RAW/(code.replace('.','_')+'.json'); meta_path=path.with_suffix('.meta.json')
    url=f'https://site.api.espn.com/apis/site/v2/sports/soccer/{code}/scoreboard?dates=20261115'
    with open(LOCK,'a+') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        req_start=dt.datetime.now(dt.timezone.utc).isoformat()
        req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0','Accept':'application/json'})
        try:
            try:
                with urllib.request.urlopen(req,timeout=15) as resp:
                    status=resp.status; body=resp.read(); read_complete=dt.datetime.now(dt.timezone.utc).isoformat()
            except urllib.error.HTTPError as e:
                status=e.code; body=e.read(); read_complete=dt.datetime.now(dt.timezone.utc).isoformat()
            path.write_bytes(body)
            meta={'url':url,'request_start_utc':req_start,'read_complete_utc':read_complete,'http_status':status,'sha256':hashlib.sha256(body).hexdigest(),'bytes':len(body)}
            meta_path.write_text(json.dumps(meta,indent=2))
            try:data=json.loads(body)
            except Exception as e:data={}; meta['parse_error']=type(e).__name__+': '+str(e); meta_path.write_text(json.dumps(meta,indent=2))
            events=[]
            for ev in data.get('events',[]):
                c=(ev.get('competitions') or [{}])[0]; ts=c.get('competitors',[])
                h=next((x for x in ts if x.get('homeAway')=='home'),{}); a=next((x for x in ts if x.get('homeAway')=='away'),{})
                team=lambda x:x.get('team') or {}
                item={'event_id':ev.get('id'),'date_utc':ev.get('date'),'state':(ev.get('status') or {}).get('type',{}).get('state'),'status_detail':(ev.get('status') or {}).get('type',{}).get('detail'),'home':team(h).get('displayName'),'home_id':team(h).get('id'),'away':team(a).get('displayName'),'away_id':team(a).get('id'),'season':ev.get('season'),'competition_notes':c.get('notes')}
                try:
                    when=dt.datetime.fromisoformat(item['date_utc'].replace('Z','+00:00'))
                    item['in_original_future_window']=bool(ASOF<when<END)
                except Exception:item['in_original_future_window']=None
                events.append(item)
            items.append({'code':code,'status':'matches_found' if events else ('zero_matches' if status==200 else 'failed'),'http_status':status,'event_count':len(events),'events':events,'meta':meta})
            time.sleep(.4)
        except Exception as e:
            completed=dt.datetime.now(dt.timezone.utc).isoformat()
            meta={'url':url,'request_start_utc':req_start,'read_complete_utc':None,'failure_observed_utc':completed,'error':type(e).__name__+': '+str(e)}
            meta_path.write_text(json.dumps(meta,indent=2)); items.append({'code':code,'status':'failed','http_status':None,'events':[],'meta':meta})
            time.sleep(.4)
        finally: fcntl.flock(lock,fcntl.LOCK_UN)
    if items[-1].get('http_status') in (401,403,429):
        stopped=f"HTTP {items[-1]['http_status']} at {code}"; break
for code in CODES[len(items):]: items.append({'code':code,'status':'not_attempted_service_stopped','http_status':None,'events':[],'reason':stopped})
report={'schema':'WCPP-SCHEDULE-RECHECK-1','scope_as_of_utc':ASOF.isoformat(),'scope_end_utc_exclusive':END.isoformat(),'request_window_note':'HTTP metadata below records actual recheck time; event inclusion is evaluated against original 2026-11-15 21:46 Beijing scope cutoff.','source':'ESPN public scoreboard, dates=20261115','recheck_count':len(items),'stopped_reason':stopped,'competitions':items}
(BASE/'recheck_results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({'count':len(items),'stopped':stopped,'summary':[{'code':i['code'],'status':i['status'],'http':i.get('http_status'),'events':i.get('event_count')} for i in items]},ensure_ascii=False))
