from pathlib import Path
from datetime import datetime, timezone, timedelta
import csv
import hashlib
import json

ROOT = Path(__file__).resolve().parent
BJT = timezone(timedelta(hours=8))
NAMES = {'eng.1': '英超', 'ita.1': '意甲', 'swe.1': '瑞典超', 'aus.1': '澳超'}
rows = json.loads((ROOT/'data/rows.json').read_text())
records = []
comparisons = []
cutoffs = []
for co in ('eng.1', 'ita.1', 'swe.1', 'aus.1'):
    scoped = [r for r in rows if r['cohort'] == co]
    stamps = [datetime.fromisoformat(r.get('kickoff_at', r.get('dateUTC')).replace('Z', '+00:00')).astimezone(BJT) for r in scoped]
    if co != 'aus.1':
        report = json.loads((ROOT/'europe-final'/co/'holdout-report.json').read_text())
        fit_n, n = len(report['plan']['fit_new_ids']), len(report['plan']['holdout_ids'])
        for kind in ('current', 'test'):
            old, new = (report['metrics'][prefix+'_'+kind] for prefix in ('original', 'refreshed'))
            delta = report['paired_comparisons'][kind]
            item = {'cohort': co, 'league': NAMES[co], 'track': kind, 'n': n, 'old_scored': old['scored'], 'new_scored': new['scored'],
                    'old_primary_hits': old['primary_hits'], 'new_primary_hits': new['primary_hits'],
                    'old_wdl_hits': old['wdl_hits'], 'new_wdl_hits': new['wdl_hits'],
                    'old_score_log_loss': old['score_log_loss'], 'new_score_log_loss': new['score_log_loss'],
                    'old_wdl_brier': old['wdl_brier'], 'new_wdl_brier': new['wdl_brier'],
                    'old_wdl_rps': old['wdl_rps'], 'new_wdl_rps': new['wdl_rps']}
            records.append(item)
            comparisons.append({'cohort': co, 'track': kind, 'net_primary_hits': delta['primary_net_hits'],
                                'old_wrong_new_right': delta['old_wrong_new_right'], 'old_right_new_wrong': delta['old_right_new_wrong'],
                                'ci95_pp': [100*x for x in delta['primary_date_block_bootstrap95']]})
        current = json.loads((ROOT/'europe-final'/co/'final/current-artifact.json').read_text())
        final_n = len(current['history'])
    else:
        report = json.loads((ROOT/'aus/result/summary.json').read_text())
        fit_n, n, final_n = report['refresh_n'], report['holdout_n'], report['original_n']+report['new_accepted']
        for kind in ('current', 'test'):
            old, new = (report['metrics'][prefix+'_'+kind] for prefix in ('old', 'refreshed'))
            delta = report['paired'][kind]
            records.append({'cohort': co, 'league': NAMES[co], 'track': kind, 'n': n,
                'old_scored': old['predicted'], 'new_scored': new['predicted'],
                'old_primary_hits': old['primary_hits'], 'new_primary_hits': new['primary_hits'],
                'old_wdl_hits': old['wdl_hits'], 'new_wdl_hits': new['wdl_hits'],
                'old_score_log_loss': old['score_log_loss'], 'new_score_log_loss': new['score_log_loss'],
                'old_wdl_brier': old['wdl_brier'], 'new_wdl_brier': new['wdl_brier'],
                'old_wdl_rps': old['wdl_rps'], 'new_wdl_rps': new['wdl_rps']})
            comparisons.append({'cohort': co, 'track': kind, 'net_primary_hits': delta['net_primary_hits'],
                'old_wrong_new_right': delta['hit_transitions']['primary_hit']['old_wrong_new_right'], 'old_right_new_wrong': delta['hit_transitions']['primary_hit']['old_right_new_wrong'],
                'ci95_pp': [100*x for x in delta['metrics']['primary_hit']['date_block_bootstrap_95']]})
    cutoffs.append({'cohort': co, 'league': NAMES[co], 'new_matches': len(scoped), 'fit_new_matches': fit_n, 'holdout_matches': n,
                    'final_history_matches': final_n, 'first_added_kickoff_bjt': min(stamps).isoformat(),
                    'latest_added_kickoff_bjt': max(stamps).isoformat()})

summary = {'created_at': datetime.now(BJT).isoformat(), 'decision': 'KEEP_ACTIVE_MODELS_NO_PROMOTION',
           'mode': 'RETROSPECTIVE_TIME_HOLDOUT_NOT_ASOF_NOT_PROSPECTIVE', 'new_rows': len(rows),
           'holdout_rows': sum(x['holdout_matches'] for x in cutoffs), 'inactive_final_candidates': 8,
           'coverage': 'PARTIAL_BLOCKED', 'cutoffs': cutoffs, 'metrics': records, 'comparisons': comparisons,
           'actual_market_ou_evaluated': False, 'statistical_reference_not_comprehensive_primary': True}
(ROOT/'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2)+'\n')
with (ROOT/'对照验证.csv').open('w') as f:
    writer = csv.DictWriter(f, fieldnames=list(records[0])); writer.writeheader(); writer.writerows(records)

lines = ['# 四联赛固定配方刷新与独立对照', '', '执行日期：北京时间 2026-11-10。', '',
    '**结论：181 条新增常规赛赛果已核验，完成 102 场时间留出对照，保存 8 份最终独立候选；保持活动模型。** 意甲和瑞典超的 current 各净增 1 次精确比分，但胜平负均少中 1 场；英超和澳超精确比分未增加。所有 test 的精确比分命中数均未增加。证据不足以切换权重或工件。', '',
    '下表的比分是模型统计矩阵的唯一首选，不是综合人工推荐；这些回顾性指标不并入真实赛前冻结业绩。', '',
    '## 新增数据与固定切分', '',
    '|联赛|原历史+新增后的场数|新增|刷新训练新增|留出|最新新增比赛开球（北京时间）|', '|---|---:|---:|---:|---:|---|']
for c in cutoffs:
    stamp = datetime.fromisoformat(c['latest_added_kickoff_bjt']).strftime('%m-%d %H:%M')
    lines.append(f"|{c['league']}|{c['final_history_matches']}|{c['new_matches']}|{c['fit_new_matches']}|{c['holdout_matches']}|{stamp}|")
lines += ['', '先锁定协议，再按各联赛合格新增样本的唯一比赛日，将前一半整日用于刷新，剩余整日作一次留出；来源日期按 UTC 分组，展示时间统一转北京时间。同日不跨训练/留出。各联赛独立，澳超保持域外研究，不混入欧洲。', '',
    '欧洲保持原 MAIN baseline、test 特征/LightGBM 配方和 alpha（英超/意甲 0.5、瑞典 0.25）；澳超保持 constant 与 Poisson365/ridge20/rho0。澳超原优化源码和 runner 经哈希匹配，旧 2807 行重拟合精确复现原数值。没有重新选配方或权重。', '',
    '英超旧历史来自 5Dollar，并通过既有 ESPN 场地身份映射到球队；新增来自 ESPN。保留旧行全部字段，包括原过程数据，不伪造旧比分来源为 ESPN。仅新增赛果，未把缺失 xG、伤停、阵容或过程统计填为零。', '',
    '## 同场留出结果', '', '|联赛|轨道|留出场次|精确比分：旧→刷新|胜平负：旧→刷新|比分 log-loss：旧→刷新|WDL Brier：旧→刷新|', '|---|---|---:|---|---|---|---|']
for r in records:
    lines.append(f"|{r['league']}|{r['track']}|{r['n']}|{r['old_primary_hits']}→{r['new_primary_hits']}|{r['old_wdl_hits']}→{r['new_wdl_hits']}|{r['old_score_log_loss']:.4f}→{r['new_score_log_loss']:.4f}|{r['old_wdl_brier']:.4f}→{r['new_wdl_brier']:.4f}|")
lines += ['', '四联赛、四个比较臂在各自留出集均 100% 产出数值预测，未剔除失败样本。log-loss、Brier 越低越好；不能以概率指标小幅改善替代最高优先的精确比分命中。完整 RPS、逐场比分和原概率矩阵保存在 JSON/CSV。', '',
    '意甲 current：旧错新对 2 场、旧对新错 1 场，净 +1；日期块配对 bootstrap 95% 差值区间为 -6.45 至 +11.43 个百分点。瑞典 current：旧错新对 1 场，净 +1，区间为 0 至 +13.79 个百分点。其余轨道没有精确比分命中状态变化。区间均未支持稳定正向增益；样本小、日期块少，零宽度区间只反映本批命中状态无变化，不能证明未来效果恰为零。', '',
    '各自日期块抽样 10,000 次、固定 seed=20261110，区间是描述性、未做多重比较校正。澳超 test 的 Brier 有小幅下降，但比分和胜平负命中均未提高，仍不晋级。', '',
    '## 数据质量与解释边界', '',
    '- 181 行均核验原文文件哈希、赛事/球队身份、FT、两节 90 分钟比分、最终比分及明确场地。澳超年度清单中 7 场季后赛排除，保留排除证据。',
    '- 329 次来源请求（320 成功、9 次日期范围参数请求返回 400）保留台账。欧洲逐日清单、澳超年度清单均来自 ESPN；没有独立第二清单和完整分页证明，因此四联赛仍为 PARTIAL_BLOCKED，不能声称所有比赛覆盖完整。',
    '- 旧数据观测及历史 first-known 不足，本轮补采也发生在目标比赛之后。按比赛日期切分防止目标标签进入拟合，但不等于重建当时可获得的信息；结果为回顾性研究，不是历史 as-of 或未来验证。',
    '- 缺少合格历史赛前实盘报价，实际盘口大小球未评估，未用固定 2.5 代替。伤停、战意、首发等缺项未被包装为已训练权重。',
    '- 评价候选只用前段新增；最终 8 份候选在对照完成后用全部新增另训，包含留出标签，不能借用上述留出成绩作为这些最终工件的独立成绩。', '',
    '## 验证与保存', '',
    '- 正式 integration runner：22 套件、633 项测试通过、零跳过。后续仅澄清澳超元数据字段含义，9 项定向测试再次通过，无重训。',
    '- 独立从原矩阵、比分和原文复算 7,086 项检查，0 项失败；16 个比较臂的指标、配对净增、日期块区间及训练/留出隔离全部吻合。',
    '- 三欧洲原工件共 6 组矩阵与原预测入口逐元素一致；改变目标比分不会改变矩阵。澳超旧配方复现、最终工件重载矩阵检查通过。合成测试 fixture 和模拟时钟明确标记，不充当真实冻结。',
    '- 欧洲第一次执行在拟合前因旧英超没有 ESPN score_evidence 而停止。补齐旧来源身份兼容后首次实际评分成功；未查看成绩后挑选重跑版本。',
    '- 澳洲原 summary 的 targets_preceding_old_artifact_creation 字段统计的是全部新增样本；追加 metadata-clarification.json 澄清：current 的 11 场均属于训练前段，真正留出提前数为 0。原 summary 和预测字节保留。',
    '- 协议、来源原文、矩阵、评价/最终工件、执行源码、依赖映射和测试证据保存在本目录，附最终文件哈希清单及研究复盘冻结凭证。活动注册表及原工件保持原样。', '',
    '本轮完成数据刷新和对照验证。下一步应在未来真实未见比赛上并行冻结对照，积累同场净增命中与覆盖率证据；本批结果不支持立即替换活动模型。', '',
    '复算入口：源码 runtime/research/refresh_holdout.py、aus_refresh_validation.py；输入 data/*-rows-final.json、*-coverage-final.json、raw_root/；协议 protocol.json、aus/protocol.json；执行源码快照 execution-sources/；独立复算 validation/。']
(ROOT/'四联赛刷新与对照验证.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({'new_rows': len(rows), 'holdout': summary['holdout_rows'], 'candidates': 8}, ensure_ascii=False))
