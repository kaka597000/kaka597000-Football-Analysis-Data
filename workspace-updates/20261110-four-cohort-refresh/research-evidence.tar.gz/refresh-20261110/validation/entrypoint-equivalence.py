"""Read-only numerical equivalence check; synthetic fixtures, mocked clock, no freeze.

Run with /workspace/football-venv/bin/python. Writes only the sibling JSON evidence.
"""
import copy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sys
from unittest.mock import patch

os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
sys.dont_write_bytecode = True
SOURCE = Path('/workspace/Football-Analysis')
sys.path.insert(0, str(SOURCE / 'runtime'))
sys.path.insert(0, str(SOURCE / 'runtime/research'))
import numpy as np
import refresh_holdout as subject


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class FixedClock(datetime):
    @classmethod
    def now(cls, tz=None):
        value = cls(2026, 11, 7, 12, tzinfo=timezone.utc)
        return value.astimezone(tz) if tz else value.replace(tzinfo=None)


def main():
    records = []
    inputs = {}
    for cohort in ('eng.1', 'ita.1', 'swe.1'):
        cp = Path('/workspace/WCPP/models/weighted-20261012') / cohort / 'artifact.json'
        tp = Path('/workspace/WCPP/models/ml-20261012') / cohort / 'artifact.json'
        current_artifact, test_artifact = (json.loads(p.read_text()) for p in (cp, tp))
        inputs.update({str(p): sha(p) for p in (cp, tp)})
        old = current_artifact['history'][-1]
        fixture = {
            'match_id': 'SYNTHETIC-REPLAY-EQUIVALENCE-' + cohort,
            'cohort': cohort, 'competition': cohort, 'stage': 'regular',
            'home': old['home'], 'away': old['away'], 'phase': 'PreMatch',
            'neutral': False, 'identity_verified': True,
            'cutoff_at': '2026-11-07T11:00:00+00:00',
            'kickoff_at': '2026-11-08T12:00:00+00:00',
            'sources': [{'source_url': 'https://example.org/synthetic-fixture',
                         'query_time': '2026-11-07T10:00:00+00:00'}],
        }
        with patch.object(subject.refresh.legacy, 'datetime', FixedClock), \
                patch.object(subject.refresh.ml, 'datetime', FixedClock):
            current = subject.refresh.legacy.predict(current_artifact['anchor'], fixture)
            test = subject.refresh.ml.predict(test_artifact, current, fixture)
        target = dict(fixture, date='2026-11-08', home_goals=0, away_goals=0)
        replay = subject.numerical_pair(current_artifact, test_artifact, target)
        mutated = copy.deepcopy(target)
        mutated.update(home_goals=5, away_goals=4)
        replay_mutated = subject.numerical_pair(current_artifact, test_artifact, mutated)
        for arm, actual in (('current', current), ('test', test)):
            equal = bool(np.array_equal(np.asarray(actual['matrix']), np.asarray(replay[arm]['matrix'])))
            unchanged = replay[arm]['matrix_sha256'] == replay_mutated[arm]['matrix_sha256']
            assert equal and unchanged, (cohort, arm)
            records.append({
                'cohort': cohort, 'arm': arm, 'synthetic': True, 'mock_clock': True,
                'production_entry_matrix_array_equal': equal,
                'matrix_sha256': replay[arm]['matrix_sha256'],
                'production_matrix_sha256': subject.refresh.legacy.digest(actual['matrix']),
                'production_status': actual['recommendation_status'],
                'target_label_mutation': {'before': [0, 0], 'after': [5, 4],
                                          'matrix_sha256_unchanged': unchanged},
                'fixture': fixture,
            })
    assert all(sha(p) == checksum for p, checksum in inputs.items())
    result = {
        'generated_at_utc': datetime.now(timezone.utc).isoformat(),
        'synthetic': True, 'mock_clock': True,
        'mock_now_utc': '2026-11-07T12:00:00+00:00',
        'scope': 'NUMERICAL_ENTRYPOINT_EQUIVALENCE_ONLY_NOT_ASOF_VALIDATION',
        'no_network': True, 'no_freeze': True, 'no_model_refit': True,
        'active_inputs_unchanged': True, 'active_inputs_sha256': inputs,
        'script_sha256': sha(__file__),
        'source_files_sha256': {str(p): sha(p) for p in (
            SOURCE / 'runtime/research/refresh_holdout.py',
            SOURCE / 'runtime/research/fixed_recipe_refresh.py',
            SOURCE / 'runtime/v4/main_model.py', SOURCE / 'runtime/v6/ml_model.py')},
        'matrix_hash_definition': 'legacy.digest(canonical JSON matrix.tolist()) SHA256',
        'checks_passed': len(records), 'records': records,
    }
    destination = Path(__file__).with_suffix('.json')
    destination.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'output': str(destination), 'checks_passed': len(records),
                      'all_array_equal': True, 'all_target_label_mutation_invariant': True}))


if __name__ == '__main__':
    main()
