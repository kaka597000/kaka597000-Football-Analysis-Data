"""Independent arithmetic/evidence audit; imports no experiment/model functions.
Run /workspace/football-venv/bin/python this_file.py. Reads existing artifacts only;
writes sibling JSON. It does not fit, predict, freeze, publish, or use network.
"""
import gzip
import hashlib
import json
import math
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse, parse_qs
import numpy as np
from scipy.stats import poisson

ROOT = Path('/workspace/refresh-20261110')
INPUTS = {}
FAILURES = []
WARNINGS = []
CHECKS = 0


def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def digest(v): return hashlib.sha256(json.dumps(v, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode()).hexdigest()
def read(p):
    p = Path(p); INPUTS[str(p)] = sha(p)
    return json.loads(gzip.decompress(p.read_bytes()) if p.suffix == '.gz' else p.read_text())
def check(condition, message):
    global CHECKS
    CHECKS += 1
    if not condition: FAILURES.append(message)
def equal(actual, expected, message):
    if isinstance(actual, (int, float)) and not isinstance(actual, bool) and isinstance(expected, (int, float)):
        check(math.isclose(actual, expected, rel_tol=1e-10, abs_tol=1e-12), message)
    else: check(actual == expected, message)
def source_ids(row):
    out = set()
    for name in ('api_evidence', 'score_evidence'):
        value = row.get(name, {}).get('source_key')
        if value is not None: out.add(value)
    u = urlparse(row.get('neutral_evidence', {}).get('source_url', ''))
    ids = parse_qs(u.query).get('event', [])
    if u.hostname == 'site.api.espn.com' and u.path == '/apis/site/v2/sports/soccer/' + row['cohort'] + '/summary' and len(ids) == 1 and ids[0].isdigit():
        out.add('espn:' + ids[0])
    return out


def verify_raw(row):
    ev = row['score_evidence']; p = Path(ev['source_path'])
    equal(sha(p), ev['response_sha256'], row['match_id'] + ': raw file hash')
    obj = read(p); obj = obj.get('data', obj); head = obj['header']; comp = head['competitions'][0]
    equal('espn:' + head['id'], ev['source_key'], row['match_id'] + ': raw event ID')
    equal(head['league']['slug'], row['cohort'], row['match_id'] + ': raw league')
    equal(comp['status']['type']['name'], 'STATUS_FULL_TIME', row['match_id'] + ': FT')
    equal((head.get('date') or comp['date'])[:10], row['date'], row['match_id'] + ': raw date')
    for side in ('home', 'away'):
        teams = [c for c in comp['competitors'] if c['homeAway'] == side]
        check(len(teams) == 1, row['match_id'] + ': unique ' + side)
        c = teams[0]; equal('espn:' + c['team']['id'], row[side], row['match_id'] + ': raw ' + side + ' ID')
        lines = c['linescores']; check(len(lines) == 2, row['match_id'] + ': two periods')
        goal = row[side + '_goals']; equal(sum(int(v['displayValue']) for v in lines), goal, row['match_id'] + ': half-time sum')
        score = c['score']; score = score.get('value', score.get('displayValue')) if isinstance(score, dict) else score
        equal(float(score), goal, row['match_id'] + ': final score')


def numerical(row, arm):
    stored = row[arm]
    if 'matrix' not in stored: return None
    m = np.array(stored['matrix'], dtype=float); tag = row['match_id'] + '/' + arm
    check(m.ndim == 2 and np.isfinite(m).all() and (m >= 0).all() and abs(float(m.sum())-1) < 1e-9, tag + ': valid normalized probabilities')
    equal(digest(stored['matrix']), stored['matrix_sha256'], tag + ': matrix hash')
    h, a = row['home_goals'], row['away_goals']; primary = list(map(int, np.unravel_index(m.argmax(), m.shape)))
    # Independent triangular aggregation: rows=home goals, columns=away goals.
    wdl = np.array([np.tril(m, -1).sum(), np.trace(m), np.triu(m, 1).sum()])
    observed = 0 if h > a else 1 if h == a else 2; target = np.eye(3)[observed]
    ph = primary == [h, a]; wp = int(wdl.argmax()); wh = wp == observed
    probability = float(m[h, a]) if h < m.shape[0] and a < m.shape[1] else 0.0
    value = {'primary_hit': ph, 'wdl_hit': wh, 'score_log_loss': -math.log(max(probability, 1e-300)),
             'wdl_brier': float(sum((wdl-target)**2)), 'wdl_rps': float(sum((np.cumsum(wdl-target)[:2])**2)/2)}
    equal(primary, stored['primary'], tag + ': primary')
    equal(wp, stored['wdl_pick'] if isinstance(stored['wdl_pick'], int) else ['主胜', '平局', '客胜'].index(stored['wdl_pick']), tag + ': WDL pick')
    check(np.allclose(wdl, stored.get('wdl', stored.get('wdl_probabilities')), rtol=1e-12, atol=1e-14), tag + ': WDL probabilities')
    for k, v in value.items(): equal(v, stored[k], tag + ': ' + k)
    return value


def verify_predictions(rows, report, aus=False):
    arms = ['old_current', 'refreshed_current', 'old_test', 'refreshed_test'] if aus else ['original_current', 'refreshed_current', 'original_test', 'refreshed_test']
    calculated = {arm: [numerical(r, arm) for r in rows] for arm in arms}; result = {'n': len(rows), 'metrics': {}, 'paired': {}}
    for arm in arms:
        good = [v for v in calculated[arm] if v is not None]; n = len(rows); s = len(good)
        metric = {'n': n, 'scored': s, 'abstained': n-s, 'coverage': s/n,
                  'primary_hits': sum(v['primary_hit'] for v in good), 'wdl_hits': sum(v['wdl_hit'] for v in good)}
        metric.update(primary_rate_all_targets=metric['primary_hits']/n, wdl_rate_all_targets=metric['wdl_hits']/n,
                      primary_rate_scored=metric['primary_hits']/s if s else None, wdl_rate_scored=metric['wdl_hits']/s if s else None)
        metric.update({k: sum(v[k] for v in good)/s if s else None for k in ('score_log_loss', 'wdl_brier', 'wdl_rps')})
        mapping = {'n': 'scope', 'scored': 'predicted', 'abstained': 'abstentions', 'primary_rate_scored': 'primary_top1', 'wdl_rate_scored': 'wdl_accuracy'} if aus else {}
        for k, v in metric.items(): equal(v, report['metrics'][arm][mapping.get(k, k)], arm + ': aggregate ' + k)
        result['metrics'][arm] = metric
    for kind in ('current', 'test'):
        old = ('old_' if aus else 'original_') + kind; new = 'refreshed_' + kind
        pair = [(r, a, b) for r, a, b in zip(rows, calculated[old], calculated[new]) if a is not None and b is not None]
        transitions = {k: {'old_wrong_new_right': sum(not a[k] and b[k] for _, a, b in pair),
                           'old_right_new_wrong': sum(a[k] and not b[k] for _, a, b in pair)} for k in ('primary_hit', 'wdl_hit')}
        deltas = {k: sum(b[k]-a[k] for _, a, b in pair)/len(pair) for k in ('score_log_loss', 'wdl_brier', 'wdl_rps')}
        net = {k: sum(int(b[k])-int(a[k]) for _, a, b in pair) for k in ('primary_hit', 'wdl_hit')}
        stored = report['paired' if aus else 'paired_comparisons'][kind]
        equal(len(pair), stored['paired_n'], kind + ': paired N')
        equal(net['primary_hit'], stored['net_primary_hits' if aus else 'primary_net_hits'], kind + ': net Primary')
        equal(net['wdl_hit'], stored['net_wdl_hits' if aus else 'wdl_net_hits'], kind + ': net WDL')
        for k, v in transitions['primary_hit'].items(): equal(v, stored['hit_transitions']['primary_hit'][k] if aus else stored[k], kind + ': Primary ' + k)
        if aus:
            for k, v in transitions['wdl_hit'].items(): equal(v, stored['hit_transitions']['wdl_hit'][k], kind + ': WDL ' + k)
        for k, v in deltas.items(): equal(v, stored['metrics'][k]['mean_difference'] if aus else stored[k+'_difference'], kind + ': paired '+k)
        dates = sorted({r['date'] for r, _, _ in pair}); totals = np.array([sum(r['date'] == d for r, _, _ in pair) for d in dates])
        blocks = np.array([sum(int(b['primary_hit'])-int(a['primary_hit']) for r, a, b in pair if r['date'] == d) for d in dates])
        picks = np.random.default_rng(20261110).integers(0, len(dates), (10000, len(dates)))
        ci = np.quantile(blocks[picks].sum(axis=1)/totals[picks].sum(axis=1), [.025, .975]).tolist()
        equal(ci, stored['metrics']['primary_hit']['date_block_bootstrap_95'] if aus else stored['primary_date_block_bootstrap95'], kind + ': Primary bootstrap')
        result['paired'][kind] = {'paired_n': len(pair), 'hit_transitions': transitions, 'net_primary_hits': net['primary_hit'], 'net_wdl_hits': net['wdl_hit'], 'loss_differences': deltas, 'primary_bootstrap95': ci}
    return result


def check_split(incoming, plan, fit_key):
    dates = sorted({r['date'] for r in incoming}); edge = dates[len(dates)//2]
    fit = sorted((r for r in incoming if r['date'] < edge), key=lambda r:(r['date'],r['match_id']))
    holdout = sorted((r for r in incoming if r['date'] >= edge), key=lambda r:(r['date'],r['match_id']))
    equal([r['match_id'] for r in fit], plan[fit_key], 'locked date split training IDs')
    equal([r['match_id'] for r in holdout], plan['holdout_ids'], 'locked date split holdout IDs')
    return fit, holdout


def disjoint(history, holdout, label):
    mids = {r['match_id'] for r in history}; tids = {r['match_id'] for r in holdout}
    check(not mids & tids, label + ': no target IDs in history')
    hs = set().union(*(source_ids(r) for r in history)); ts = set().union(*(source_ids(r) for r in holdout))
    check(not hs & ts, label + ': no provider ID collision')
    check(max(r['date'] for r in history) < min(r['date'] for r in holdout), label + ': strict calendar date boundary')
    check(not {(r['date'],r['home'],r['away']) for r in history} & {(r['date'],r['home'],r['away']) for r in holdout}, label + ': no fixture collision')


def main():
    protocol = read(ROOT/'protocol.json'); registry = read('/workspace/WCPP/runtime/active-model.json')
    active = {p: {'expected': v, 'actual': sha(p), 'unchanged': sha(p) == v} for p,v in protocol['active_hashes'].items()}
    check(all(v['unchanged'] for v in active.values()), 'all protected active hashes unchanged')
    cohorts = {}; eu_rows = read(ROOT/'data/eu-rows-final.json')
    for cohort in ('eng.1','ita.1','swe.1'):
        p = ROOT/'europe-final'/cohort; report = read(p/'holdout-report.json'); predictions = read(p/'holdout-predictions.json.gz')
        incoming = [r for r in eu_rows if r['cohort'] == cohort]; fit, holdout = check_split(incoming, report['plan'], 'fit_new_ids')
        equal([r['match_id'] for r in predictions], [r['match_id'] for r in holdout], cohort+': actual target population')
        for source, rec in zip(holdout,predictions):
            for k in ('match_id','date','home','away','home_goals','away_goals'): equal(rec[k], source[k], cohort+': source label/identity '+k)
            verify_raw(source)
        audit = verify_predictions(predictions, report); audit['artifacts'] = {}; audit['coverage'] = report['coverage']['status']
        for kind in ('current','test'):
            original = read(registry['models'][cohort][('test_' if kind == 'test' else '')+'artifact_path'])
            evp = p/'evaluation'/f'{kind}-artifact.json'; fip = p/'final'/f'{kind}-artifact.json'
            ev, final = read(evp), read(fip)
            original_rows = original['history']; expected_eval = sorted(original_rows+fit,key=lambda r:(r['date'],r['match_id'])); expected_final = sorted(original_rows+incoming,key=lambda r:(r['date'],r['match_id']))
            equal(ev['history'],expected_eval,cohort+'/'+kind+': preserves exact original dictionaries and fit-only additions')
            equal(final['history'],expected_final,cohort+'/'+kind+': exact original dictionaries and all additions')
            disjoint(ev['history'],holdout,cohort+'/'+kind)
            equal(ev['train_end'],max(r['date'] for r in expected_eval),cohort+'/'+kind+': train_end')
            check(sha(evp)!=sha(fip) and ev['core']!=final['core'],cohort+'/'+kind+': evaluation/final separate cores and files')
            if kind=='current': equal(ev['anchor']['history'],ev['history'],cohort+': evaluation anchor history')
            else:
                ids={r['match_id'] for r in ev['history']}-set(report['ml_fit']['excluded_training_targets'])
                equal(digest(sorted(ids)),report['ml_fit']['training_target_id_digest'],cohort+': ML fit targets digest')
                check(not ids & set(report['plan']['holdout_ids']),cohort+': no ML holdout labels')
            audit['artifacts'][kind]={'original_n':len(original_rows),'evaluation_n':len(expected_eval),'final_n':len(expected_final),'evaluation_sha256':sha(evp),'final_sha256':sha(fip),'old_dictionaries_unchanged':True,'holdout_excluded':True}
        cohorts[cohort]=audit
    p=ROOT/'aus/result'; report=read(p/'summary.json'); predictions=read(p/'holdout-predictions.json'); plan=read(p/'evaluation-plan.json'); fits=read(p/'evaluation-fits.json'); final_rows=read(p/'final-training-rows.json'); incoming=read(ROOT/'data/aus-rows-final.json')
    fit,holdout=check_split(incoming,plan,'refresh_ids');equal([r['match_id'] for r in predictions],[r['match_id'] for r in holdout],'AUS prediction targets')
    for source,rec in zip(holdout,predictions):
        for k in ('match_id','date','home','away','home_goals','away_goals'): equal(rec[k],source[k],'AUS source identity/label '+k)
        verify_raw(source)
    old_count=report['original_n']; old=final_rows[:old_count]; expected=old+fit; disjoint(expected,holdout,'AUS evaluation reconstruction')
    equal(sorted(r['match_id'] for r in final_rows[old_count:]),sorted(r['match_id'] for r in incoming),'AUS final new identity population')
    new_by_id={r['match_id']:r for r in incoming}
    for final_row in final_rows[old_count:]:
        original_row=new_by_id[final_row['match_id']]
        for key,value in original_row.items(): equal(final_row[key],value,'AUS final preserves new input '+key)
    aus_route=registry['models']['aus.1'];aus_old={kind:read(aus_route[('test_' if kind=='test' else '')+'artifact_path']) for kind in ('current','test')}
    dataset=Path(aus_old['test']['dataset']);manifest=read(dataset/'manifest.json');parts={}
    for name in ('fixtures.jsonl','labels.jsonl','facts.jsonl'):
        path=dataset/name;INPUTS[str(path)]=sha(path);equal(sha(path),manifest['files'][name],'AUS old dataset hash '+name)
        parts[name]=[json.loads(line) for line in path.read_text().splitlines()]
    labels={r['match_id']:r for r in parts['labels.jsonl']}
    original_old=sorted([{**r,**labels[r['match_id']]} for r in parts['fixtures.jsonl']],key=lambda r:(r['date'],r['match_id']))
    equal(old,original_old,'AUS old original dictionaries preserved')
    all_new={r['match_id']:r for r in final_rows[old_count:]}
    # Reconstruct matrices independently from saved evaluation coefficients, never final cores.
    for row in predictions:
        neutral=all_new[row['match_id']]['neutral']
        for prefix in ('old','refreshed'):
            for kind in ('current','test'):
                core=aus_old[kind]['core'] if prefix=='old' else fits['fit'][kind]
                if kind=='current': rates=core['constant']
                else:
                    teams=core['teams'];coeff=core['coefficients'];n=len(teams);rates=[]
                    for side,(team,opponent) in enumerate(((row['home'],row['away']),(row['away'],row['home']))):
                        eta=coeff[0]+coeff[1]*int(side==0 and neutral is not True)+coeff[2]*int(neutral is None)+coeff[3+teams.index(team)]+coeff[3+n+teams.index(opponent)]
                        rates.append(float(np.clip(math.exp(eta),.08,8.)))
                key=prefix+'_'+kind;m=np.asarray(row[key]['matrix']);replay=np.outer(poisson.pmf(np.arange(m.shape[0]),rates[0]),poisson.pmf(np.arange(m.shape[1]),rates[1]));replay/=replay.sum()
                check(np.allclose(m,replay,rtol=1e-12,atol=1e-14),'AUS '+row['match_id']+'/'+key+': saved evaluation coefficient matrix reproduction')
    audit=verify_predictions(predictions,report,True);audit['coverage']=report['data_coverage']['status'];audit['artifacts']={}
    for kind in ('current','test'):
        final=read(p/f'final-{kind}-artifact.json'); core=fits['fit'][kind]
        equal(core['fit_n'],len(expected),'AUS eval fit count '+kind);equal(core['fit_end'],max(r['date'] for r in expected),'AUS eval fit date '+kind)
        equal(final['core']['fit_n'],len(final_rows),'AUS final count '+kind);check(core!=final['core'],'AUS final/evaluation cores different '+kind)
        equal(final['training_input_sha256'],sha(p/'final-training-rows.json'),'AUS final input hash '+kind)
        if kind=='current': check(np.allclose(core['constant'],[np.mean([r[k+'_goals'] for r in expected]) for k in ('home','away')],rtol=0,atol=1e-14),'AUS eval constant reconstructed from no-holdout rows')
        audit['artifacts'][kind]={'evaluation_n':core['fit_n'],'evaluation_end':core['fit_end'],'final_n':final['core']['fit_n'],'final_end':final['core']['fit_end'],'evaluation_core_sha256':digest(core),'final_core_sha256':digest(final['core']),'no_holdout_in_reconstructed_fit':True}
    actual_preceding={}
    for kind in ('current','test'):
        born=datetime.fromisoformat(report['artifact_created_at'][kind]);actual_preceding[kind]=sum(datetime.fromisoformat(r['kickoff_at'].replace('Z','+00:00'))<born for r in holdout)
    if actual_preceding!=report['targets_preceding_old_artifact_creation']:
        WARNINGS.append({'field':'aus.summary.targets_preceding_old_artifact_creation','reported':report['targets_preceding_old_artifact_creation'],'actual_holdout_targets':actual_preceding,'explanation':'Producer iterates all accepted incremental rows; counts describe full incremental input, not holdout. Numerical metrics unaffected.'})
    clarification_path=p/'metadata-clarification.json'
    if clarification_path.exists():
        clarification=read(clarification_path)
        equal(clarification['original_summary_sha256'],sha(p/'summary.json'),'AUS clarification links exact original report')
        equal(clarification['holdout_matches_preceding_old_artifact_creation'],actual_preceding,'AUS clarification true holdout count')
        equal(clarification['all_incremental_matches_preceding_old_artifact_creation'],report['targets_preceding_old_artifact_creation'],'AUS clarification true full incremental count')
        audit['metadata_clarification']={'path':str(clarification_path),'sha256':sha(clarification_path),'verified':True}
        for warning in WARNINGS: warning['resolved_by_append_only_clarification']=str(clarification_path)
    audit['holdout_targets_preceding_old_artifact_creation']=actual_preceding;cohorts['aus.1']=audit
    failed=ROOT/'europe';files=sorted(str(f.relative_to(failed)) for f in failed.rglob('*') if f.is_file())
    equal(files,['eng.1/row-audit.json'],'first failed run contains no fit/predictions/results')
    check(all(sha(p)==v for p,v in INPUTS.items()),'all inspected inputs unchanged during audit')
    result={'status':'FAIL' if FAILURES else ('PASS_NUMERICS_WITH_METADATA_CLARIFICATION' if WARNINGS else 'PASS'),'checked_at_utc':datetime.now(timezone.utc).isoformat(),'independent_implementation':True,'imports_model_or_experiment_code':False,'network_used':False,'model_refit_performed':False,'checks':CHECKS,'failures':FAILURES,'warnings':WARNINGS,'cohorts':cohorts,'active_hashes':active,'first_failed_run':{'path':str(failed),'files':files,'contains_scored_results':False,'excluded_from_comparison':True},'source_keys_review':'5dollar API keys retain provider prefix; explicit ESPN neutral-summary event IDs add collision keys only, no row rewrites or implied ESPN score certification. Evaluation and final history dictionaries compared directly against originals.','limitations':['Retrospective label-time holdout, not historical as-of or prospective KPI.','All four cohorts PARTIAL_BLOCKED; single-source completeness not independently established.','AUS saved evaluation cores include fit counts/date and split IDs rather than full training rows; audit reconstructs exact intended fit from old and locked IDs, independently verifies constant fit; no Poisson refit performed.'],'inputs_sha256':INPUTS,'script_sha256':sha(__file__)}
    target=Path(__file__).with_suffix('.json');target.write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'output':str(target),'status':result['status'],'checks':CHECKS,'failures':FAILURES,'warnings':WARNINGS,'top1':{co:{arm:m['primary_hits'] for arm,m in r['metrics'].items()} for co,r in cohorts.items()}},ensure_ascii=False))
    if FAILURES: raise SystemExit(1)


if __name__=='__main__':main()
