import json, pathlib, hashlib, datetime, re, sys, urllib.parse
sys.path.insert(0,'/workspace/Football-Analysis/runtime/research')
from fixed_recipe_refresh import validate_new
base=pathlib.Path('/workspace/refresh-20261110/data'); raw=base/'raw_root'; boards=raw/'scoreboards'; summaries=raw/'summaries'
cohorts=['eng.1','ita.1','swe.1']; start='2026-09-21'; end='2026-11-09'; days=[];d=datetime.date.fromisoformat(start); last=datetime.date.fromisoformat(end)
while d<=last: days.append(d.isoformat());d+=datetime.timedelta(days=1)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def mtime(p):return datetime.datetime.fromtimestamp(p.stat().st_mtime,datetime.timezone.utc).isoformat()
rows=[]; coverage={'range_utc_inclusive':[start,end],'provider':'ESPN public scoreboard and summary','cohorts':{}}; audit={'source':'ESPN site.api public JSON','request_policy':'Same provider serialized; minimum 0.32 seconds between calls; scoreboard date-specific calls then one summary per returned event.','scoreboard_queries':[],'summary_queries':[],'validation_exclusions':[],'accepted_by_cohort':{}}
for c in cohorts:
 expected=[]; unresolved=[]; all_events={}
 for day in days:
  p=boards/f'{c}-{day.replace("-","")}.json'
  if not p.exists(): unresolved.append({'date':day,'reason':'scoreboard response missing'});continue
  url=f'https://site.api.espn.com/apis/site/v2/sports/soccer/{c}/scoreboard?dates={day.replace("-","")}'
  audit['scoreboard_queries'].append({'cohort':c,'date':day,'url':url,'query_time':mtime(p),'response_sha256':sha(p),'source_path':str(p.resolve()),'bytes':p.stat().st_size})
  try: body=json.loads(p.read_bytes())
  except Exception as e: unresolved.append({'date':day,'reason':'invalid scoreboard json '+str(e)});continue
  for e in body.get('events',[]):
   if e.get('date','')[:10]!=day:continue
   all_events[str(e.get('id'))]=e
 accepted=[]
 for eid,e in all_events.items():
  co=(e.get('competitions')or[{}])[0];st=co.get('status',e.get('status',{})).get('type',{})
  if st.get('completed') is True and st.get('name')=='STATUS_FULL_TIME':expected.append('espn:'+eid)
  else: unresolved.append({'match_id':'espn:'+eid,'date':e.get('date','')[:10],'reason':'scoreboard status is not full time','status':st.get('name')})
  p=summaries/f'{c}-{eid}.json'
  if not p.exists(): unresolved.append({'match_id':'espn:'+eid,'date':e.get('date','')[:10],'reason':'summary not fetched'});continue
  data=json.loads(p.read_bytes());h=data.get('header',{}); comps=h.get('competitions')or[]
  if len(comps)!=1 or str(h.get('id'))!=eid or h.get('league',{}).get('slug')!=c:
   unresolved.append({'match_id':'espn:'+eid,'reason':'summary identity ambiguous/conflicting'});continue
  comp=comps[0]; season=h.get('season',{});name=season.get('name','')
  # All three are league season schedules, without cup/playoff phases.
  if not name or any(x in name.lower() for x in ('cup','playoff','final')):
   unresolved.append({'match_id':'espn:'+eid,'reason':'stage not confirmed regular','season_name':name});continue
  sides={x.get('homeAway'):x for x in comp.get('competitors',[])}
  if set(sides)!={'home','away'} or comp.get('neutralSite') is not False:
   unresolved.append({'match_id':'espn:'+eid,'reason':'home/away or neutralSite unknown'});continue
  if comp.get('status',{}).get('type',{}).get('name')!='STATUS_FULL_TIME' or comp.get('status',{}).get('type',{}).get('completed') is not True:
   unresolved.append({'match_id':'espn:'+eid,'reason':'summary status is not FT'});continue
  goals={}
  ok=True
  for side in ('home','away'):
   x=sides[side];periods=x.get('linescores',[]);score=x.get('score')
   if isinstance(score,dict):score=score.get('value',score.get('displayValue'))
   try: g=int(float(score)); ptotal=sum(int(z['displayValue']) for z in periods)
   except Exception:ok=False;break
   if len(periods)!=2 or ptotal!=g:ok=False;break
   goals[side]=g
  if not ok:
   unresolved.append({'match_id':'espn:'+eid,'reason':'two-period totals or score invalid'});continue
  if comp.get('date','')[:10]!=e.get('date','')[:10]:
   unresolved.append({'match_id':'espn:'+eid,'reason':'scoreboard/summary date conflict'});continue
  rawpath=p.resolve(); digest=sha(p); q=mtime(p); url=f'https://site.api.espn.com/apis/site/v2/sports/soccer/{c}/summary?event={eid}'
  row={'match_id':'espn:'+eid,'competition':c,'cohort':c,'stage':'regular','date':comp['date'][:10],'kickoff_at':comp['date'],'home':'espn:'+str(sides['home']['team']['id']),'away':'espn:'+str(sides['away']['team']['id']),'home_goals':goals['home'],'away_goals':goals['away'],'neutral':False,'status':'FT','score_basis':'regulation_90','source_url':url,'observed_at':q,'score_evidence':{'source_key':'espn:'+eid,'source_path':str(rawpath),'response_sha256':digest,'query_time':q,'source_url':url},'neutral_evidence':{'source_key':'espn:'+eid,'source_path':str(rawpath),'response_sha256':digest,'query_time':q,'source_url':url,'neutral_site':False}}
  try:validate_new(row,c,datetime.datetime.now(datetime.timezone.utc),raw)
  except Exception as ex:
   unresolved.append({'match_id':'espn:'+eid,'reason':'validate_new rejected','detail':str(ex)});continue
  accepted.append(row);rows.append(row)
  audit['summary_queries'].append({'cohort':c,'event_id':eid,'url':url,'query_time':q,'response_sha256':digest,'source_path':str(rawpath),'bytes':p.stat().st_size})
 accepted_ids={r['match_id'] for r in accepted}
 # A single supplier calendar is a usable fixture list, but does not independently prove it omitted no matches.
 coverage['cohorts'][c]={'start':start,'end':end,'checked_dates':days,'inventory_verified':False,'expected_finished_event_ids':sorted(expected),'schedule_events_returned':len(all_events),'finished_event_count':len(expected),'accepted_event_ids':sorted(accepted_ids),'accepted_count':len(accepted),'missing':[],'unresolved':unresolved,'status':'PARTIAL_BLOCKED','reason':'ESPN is the only schedule inventory source; no independent fixture list verifies omissions.'}
 audit['accepted_by_cohort'][c]=len(accepted)
(base/'eu-rows.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
(base/'eu-coverage.json').write_text(json.dumps(coverage,ensure_ascii=False,indent=2)+'\n')
(base/'eu-source-audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
print('accepted total',len(rows),audit['accepted_by_cohort'])
for c,v in coverage['cohorts'].items():print(c,'returned',v['schedule_events_returned'],'FT',v['finished_event_count'],'accepted',v['accepted_count'],'unresolved',len(v['unresolved']))
