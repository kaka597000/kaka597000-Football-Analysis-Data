import json,pathlib,hashlib,datetime,shutil,sys,gzip
sys.path.insert(0,'/workspace/Football-Analysis/runtime/research')
from fixed_recipe_refresh import validate_new
base=pathlib.Path('/workspace/refresh-20261110/data');raw=base/'raw_root';cached_root=base/'raw_root'/'aus1';cached_root.mkdir(exist_ok=True)
score=json.load(open(raw/'aus-scoreboard-2026.json'));start='2026-04-27';end='2026-11-09'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def mtime(p):return datetime.datetime.fromtimestamp(p.stat().st_mtime,datetime.timezone.utc).isoformat()
# Gather regular-season schedule events returned in date scope.
events=[];excluded=[]
for e in score.get('events',[]):
 day=e.get('date','')[:10];season=e.get('season',{}); c=(e.get('competitions')or[{}])[0];slug=season.get('slug');typ=season.get('type');status=c.get('status',e.get('status',{})).get('type',{})
 if not(start<=day<=end):continue
 if typ!=14401 or slug!='regular-season':
  excluded.append({'match_id':'espn:'+str(e.get('id')),'date':day,'season_type':typ,'season_slug':slug,'status':status.get('name'),'reason':'playoffs/finals excluded; regular season only'});continue
 events.append(e)
# Reuse original captured, gzip summaries for already normalized 12; newly returned event IDs get direct summary bytes.
prior={}
for line in open('/workspace/kaka597000-Football-Analysis-Data/normalized-results.jsonl'):
 x=json.loads(line)
 if x.get('cohort')=='aus.1' and start<=x.get('date','')<=end:prior[x['match_id'].split(':')[1]]=x
rows=[];unresolved=[];requests=[]
for e in events:
 eid=str(e['id']);day=e['date'][:10]
 if eid in prior:
  old=prior[eid];src=pathlib.Path('/workspace/kaka597000-Football-Analysis-Data')/old['raw_reference']['path'];dst=cached_root/f'summary-{eid}.json.gz'
  if src.exists() and not dst.exists():shutil.copyfile(src,dst)
  source=dst;query=old.get('raw_reference',{}).get('captured_at') or old.get('known_at');requested='reused_raw_capture'
 else:
  source=raw/'summaries'/f'aus.1-{eid}.json';query=mtime(source) if source.exists() else None;requested='fetched_in_this_batch'
 if not source.exists():unresolved.append({'match_id':'espn:'+eid,'date':day,'reason':'missing summary response'});continue
 try:data=json.loads(source.read_bytes()) if source.suffix!='.gz' else json.load(gzip.open(source,'rt'))
 except Exception as ex:unresolved.append({'match_id':'espn:'+eid,'reason':'invalid summary json','detail':str(ex)});continue
 h=data.get('header',{});cs=h.get('competitions')or[];season=h.get('season',{})
 if len(cs)!=1 or str(h.get('id'))!=eid or h.get('league',{}).get('slug')!='aus.1' or season.get('type')!=14401 or 'Regular Season' not in season.get('name',''):
  unresolved.append({'match_id':'espn:'+eid,'reason':'summary competition/stage mismatch','season':season});continue
 comp=cs[0];sides={x.get('homeAway'):x for x in comp.get('competitors',[])}
 if set(sides)!={'home','away'} or comp.get('neutralSite') is not False:
  unresolved.append({'match_id':'espn:'+eid,'reason':'home/away/neutral unknown'});continue
 st=comp.get('status',{}).get('type',{})
 if st.get('completed') is not True or st.get('name')!='STATUS_FULL_TIME':
  unresolved.append({'match_id':'espn:'+eid,'reason':'not regulation FT','status':st.get('name')});continue
 goals={};ok=True
 for side in ('home','away'):
  t=sides[side];ls=t.get('linescores',[]);scoreval=t.get('score')
  if isinstance(scoreval,dict):scoreval=scoreval.get('value',scoreval.get('displayValue'))
  try:g=int(float(scoreval));pt=sum(int(z['displayValue']) for z in ls)
  except Exception:ok=False;break
  if len(ls)!=2 or pt!=g:ok=False;break
  goals[side]=g
 if not ok or comp.get('date','')[:10]!=day:
  unresolved.append({'match_id':'espn:'+eid,'reason':'date/period/score mismatch'});continue
 digest=sha(source);url=f'https://site.api.espn.com/apis/site/v2/sports/soccer/aus.1/summary?event={eid}';ev={'source_key':'espn:'+eid,'source_path':str(source.resolve()),'response_sha256':digest,'query_time':query,'source_url':url}
 row={'match_id':'espn:'+eid,'competition':'aus.1','cohort':'aus.1','stage':'regular','date':day,'kickoff_at':comp['date'],'home':'espn:'+str(sides['home']['team']['id']),'away':'espn:'+str(sides['away']['team']['id']),'home_goals':goals['home'],'away_goals':goals['away'],'neutral':False,'status':'FT','score_basis':'regulation_90','source_url':url,'observed_at':query,'score_evidence':ev,'neutral_evidence':dict(ev,neutral_site=False),'season_name':season.get('name'),'season_type':season.get('type')}
 try:validate_new(row,'aus.1',datetime.datetime.now(datetime.timezone.utc),raw)
 except Exception as ex:unresolved.append({'match_id':'espn:'+eid,'reason':'validate_new rejected','detail':str(ex)});continue
 rows.append(row);requests.append({'event_id':eid,'date':day,'request_status':requested,'source_url':url,'query_time':query,'response_sha256_file_bytes':digest,'source_path':str(source.resolve())})
# Coverage schedule fixture list is provider returned calendar only; no second inventory means blocked.
days=[];dt=datetime.date.fromisoformat(start);last=datetime.date.fromisoformat(end)
while dt<=last:days.append(dt.isoformat());dt+=datetime.timedelta(days=1)
board=raw/'aus-scoreboard-2026.json';boardinfo={'url':'https://site.api.espn.com/apis/site/v2/sports/soccer/aus.1/scoreboard?dates=2026&limit=1000','query_time':mtime(board),'source_path':str(board.resolve()),'response_sha256':sha(board),'bytes':board.stat().st_size,'returned_annual_event_count':len(score.get('events',[]))}
expected=sorted('espn:'+str(e['id']) for e in events if (e.get('competitions')or[{}])[0].get('status',e.get('status',{})).get('type',{}).get('completed') is True and (e.get('competitions')or[{}])[0].get('status',e.get('status',{})).get('type',{}).get('name')=='STATUS_FULL_TIME')
coverage={'cohort':'aus.1','range_utc_inclusive':[start,end],'stage_filter':{'regular_season_type':14401,'regular_season_slug':'regular-season','summary_name_contains':'Regular Season','finals_excluded':True},'source_inventory':boardinfo,'checked_dates':days,'inventory_verified':False,'schedule_events_returned':30,'regular_season_events_returned':len(events),'eligible_finished_event_ids':expected,'expected_finished_event_ids':expected,'accepted_count':len(rows),'accepted_event_ids':sorted(r['match_id']for r in rows),'excluded_playoff_events':excluded,'unresolved':unresolved,'status':'PARTIAL_BLOCKED','reason':'One ESPN annual scoreboard response supplied the inventory; pagination/truncation and independent fixture completeness cannot be established.'}
audit={'cohort':'aus.1','scoreboard_request_count':1,'summary_new_request_count':sum(1 for r in requests if r['request_status']=='fetched_in_this_batch'),'summary_cache_reuse_count':sum(1 for r in requests if r['request_status']=='reused_raw_capture'),'scoreboard':boardinfo,'accepted_rows':requests,'excluded':excluded,'unresolved':unresolved,'hash_basis':'sha256 of retained response file bytes; old normalized sha may be hash of decompressed JSON, not reused','validation':'actual fixed_recipe_refresh.validate_new for every accepted row'}
(base/'aus-rows-final.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');(base/'aus-coverage-final.json').write_text(json.dumps(coverage,ensure_ascii=False,indent=2)+'\n');(base/'aus-source-audit-final.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
print('rows',len(rows),'excluded playoff',len(excluded),'unresolved',len(unresolved),'new',audit['summary_new_request_count'],'cache',audit['summary_cache_reuse_count'])
