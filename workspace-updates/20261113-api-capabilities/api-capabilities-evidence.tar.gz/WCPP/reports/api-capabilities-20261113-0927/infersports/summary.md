# InferSports 能力核查

测试时间：2026-11-13 09:32–09:35（北京时间；所有请求至少间隔 1 秒）。使用已就绪 Bearer 绑定 `infer_yapan_zhishu`。使用本地已缓存官方 OpenAPI schema，未新增公共 docs 请求。本次共 6 次 API 请求，均 HTTP 200；目录/事件查询返回的 `x-ratelimit-limit=60`、`remaining=29` 原样保留。API 本轮受保护 odds 请求成功，之前 11 月 12 日的 HTTP 401 没有在本次未来赛事请求上重现。

官方精确名称过滤 `UEFA Nations League` 返回空数组；用此前实际目录确认并经赛事对照的提供方别名 `UEFANLA`、`UEFANLC` 查询，取得当前赛程。`UEFANLA` 在北京时间 11 月 14 日返回荷兰–希腊、塞尔维亚–德国等 scheduled fixture。荷兰–希腊赔率为 HTTP 200，提供了实际 1X2、亚洲让球、大小球的机构、线、两侧价格和单条 quote `as_of`。逐市场代表性报价和实际 quote 年龄见 [market-evidence.json](market-evidence.json)。

响应顶层 `as_of=2026-11-13T01:19:30Z, stale=false` 不代表每条报价都在该时刻更新：例如 Crown 1X2 是前一日 22:07:37Z；M8Bet 亚洲让球线 -1.0、两边 1.94 的 `as_of` 为 01:19:30Z；M8Bet 大小球 3.0、Over 2.05/Under 1.81 的 `as_of` 为 00:29:56Z。逐行保留 source quote time 并应用鲜度门槛。对已完赛的土耳其–比利时赛事，另一赔率响应标 stale=true，报价均为 suspended/0，不能当可用盘口。

发现赛事级别污染：亚美尼亚–塞浦路斯、黑山–拉脱维亚、圣马力诺–白俄罗斯、阿尔巴尼亚–芬兰同时出现在 `UEFANLA` 与 `UEFANLC`，对阵/开球时间相同但 event ID 不同；前者不应被直接当作 League A。详情见 [integrity-review.json](integrity-review.json)，这些行应标 `COHORT_ID_CONFLICT` 并排除模型。当前只验证欧国联，其他 19 项比赛标 UNVERIFIED。盘口价格不代表成交额或资金流。

项目60分钟鲜度复核：本场47条盘口记录中，仅2条亚洲让球同时满足open、两边有效价格和60分钟内报价；6条1X2、21条大小球均未达到该门槛。最接近的大小球报价抓取时已64.3分钟。接口恢复不等于本次已有可用的新鲜大小球备用，明细见quote-freshness-audit.json。
