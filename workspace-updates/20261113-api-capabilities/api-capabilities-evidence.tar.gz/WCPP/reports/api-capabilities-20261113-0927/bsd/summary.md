# BSD capability test — 2026-11-13

- Authentication: explicit `bsd` binding sent as `Authorization: Token …`; all 9 API requests returned HTTP 200. Calls were serial with at least 1 second between requests. No additional calls were made after reaching the per-service limit.
- Coverage: the full 100-row league catalog was fetched. A date batch returned 20/45 events for 2026-11-13; a second returned 37 finished events for 2026-10-14. Event 601031 is a 2026/27 UEFA Champions League league-phase match, Manchester City 2–4 Paris Saint-Germain.
- Verified on that one completed event: confirmed 11-player starting lineups, 22 incident rows, team statistics and xG (`xg_estimated=false`, 2.57–1.83). Standings and injuries/suspensions were not sampled; live in-play data was not established.
- Odds response contains 1X2-style and totals-style numeric values with `last_update_at`, but no bookmaker identity, source attribution, explicit market/line object or evidence of both sides from an identified operator. This is not verified as an actual bookmaker quote. No odds history was fetched.
- All 20 exact-name competition mappings and their evidence are in `capability.json`; directory listing is distinguished from verified current match coverage.

See `responses.json` for the scrubbed structured API responses, response hashes, HTTP/content-type and request timing.
