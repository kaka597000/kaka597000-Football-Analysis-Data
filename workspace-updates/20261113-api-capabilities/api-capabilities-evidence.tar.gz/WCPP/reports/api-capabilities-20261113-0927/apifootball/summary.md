# API-Football / API-SPORTS 实测摘要

2026-11-13 09:29:18（北京时间）首个 `GET https://v3.football.api-sports.io/status` 返回 **HTTP 403**，`text/html; charset=UTF-8`，`CF-Ray: a59a0136081766e9-DFW`。响应正文未保存（HTML 安全边界），也未获得额度头。凭据是否被接受无法判定。

按共同规则，首个 403 后立即停止本服务所有 API 请求；本次没有实际验证赛事目录、当前赛季赛程/赛果、统计/xG、事件、首发、伤停、积分榜或赔率。`capability.json` 将 20 个字段及 20 项赛事覆盖均标为 `BLOCKED`，不是证明服务不支持这些字段。

root 已收到 HTTP 状态、错误分类和 CF-Ray，可安排 Luna 浏览器核查。
