# TheRundown 实测摘要

- 官方文档副本核实生产主机为 `therundown.io`，使用 `X-TheRundown-Key`；文档列出 `/api/v1/sports/{sportID}/schedule`。sport ID 11 在覆盖矩阵中是 EPL，因此本次足球方向复测不是把美式橄榄球/篮球成功冒充足球。
- 本次对授权绑定域执行 1 次正式文档端点请求（R2），返回 HTTP 403，`x-at-upstream-error=true`、CF-Ray `a59a02c6aabbf0c1-DFW`，无 JSON API 错误体。按停止条件没有继续请求。无法据此判断密钥是否有效。
- 未获得赛事目录、赛程、比分、赔率、统计或实际来源报价时间。20 项比赛覆盖均为 BLOCKED；不应据此声称服务本身不支持这些比赛。
- 同域公开首页请求也被 Cloudflare 403 拦截（CF-Ray `a59a0202cc7ff0c1-DFW`）。建议由已授权 Luna 浏览器核查公开官方文档和服务可达性。没有将密钥发往任何其他域。

证据详见 [capability.json](capability.json) 和上级 `../plan.json`。失败响应原文未留存，以避免无谓保留 Cloudflare 页面内容；保留字节数、SHA-256、状态和安全错误头。
