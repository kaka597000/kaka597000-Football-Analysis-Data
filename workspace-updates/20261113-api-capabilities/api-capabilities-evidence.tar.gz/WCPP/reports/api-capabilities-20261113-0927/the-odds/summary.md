# The Odds API 能力核查

测试时间：2026-11-13 09:31（北京时间，UTC 01:31 起）。凭证使用已就绪绑定 `THE_ODDS`，请求参数中携带的密钥未保存。5 次 API 请求均为 HTTP 200：目录 1 次、欧国联/英超/德甲赔率各 1 次、欧国联 `daysFrom=1` scores 1 次。按响应额度头合计消耗 11 units，开始余 287、最后余 276；未请求 history，避免超过本批 14-unit 上限。

`/sports?all=true` 返回 187 个目录项。欧国联、英超、德甲目录均标 active 且本次实际返回当前赔率。三次赔率请求分别返回 27、20、18 行；这表示接口返回数量，不表示每行比赛身份均已核实。市场响应里有实际机构、赔率点/大小球线、双方价格，以及机构和市场各自的 `last_update`。示例及逐市场 quote time 在 [market-evidence.json](market-evidence.json)，原始脱敏响应和 SHA256 在 [responses.json](responses.json)。`spreads` 保留其原字段名称；未认证为亚洲让球。

欧国联 scores 接口返回35条赛事记录，其中8条已完赛且有比分，27条未来／未完赛；它证明近期结果数据，不是滚球比分覆盖。目录映射了 18 个本项目赛事 key，其中当前请求实际只验证 3 项赔率；目录的 active 标志不等于有当前赛事报价。芬超、日职、K League、世界杯和日联杯目录状态及缺项详见 `capability.json`。

独立身份核验发现欧国联两个返回行把奥地利安排在同一开球时间对阵冰岛和爱尔兰；具体 ID 在 [integrity-review.json](integrity-review.json)，标记 `EVENT_CONFLICT`，应排除。故不能把 27 行整体说成已核验真实赛程。只使用逐场身份确认且 quote 未过时的盘口，不从价格推断投注资金流。
