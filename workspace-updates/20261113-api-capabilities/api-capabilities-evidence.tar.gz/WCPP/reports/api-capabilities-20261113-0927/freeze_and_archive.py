"""Freeze this completed audit and archive only sanitized evidence; no API calls."""
import json
import hashlib
import tarfile
import shutil
import subprocess
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
from research.analysis_freeze import save, verify
R=Path(__file__).resolve().parent
D=Path('/workspace/kaka597000-Football-Analysis-Data/workspace-updates/20261113-api-capabilities')
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,d):Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
if (R/'delivery.json').exists() or D.exists():raise SystemExit('Existing delivery: inspect it; do not create duplicate freeze/archive.')
audit=read(R/'independent-audit.json');assert audit['status']=='PASS_WITH_QUALIFICATIONS'
summary=read(R/'audit-summary.json')
for d in summary['provider_summaries'].values():assert sha(R/d['capability_path'])==d['capability_sha256']
files=sorted(p for p in R.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
payload={'report_markdown':(R/'report.md').read_text(),'summary':summary,'verification':read(R/'verification.json'),
         'independent_audit':audit,'evidence_sha256':{str(p.relative_to(R)):sha(p) for p in files},
         'decision':'KEEP_EXISTING_MODEL_AND_DATABASE; CAPABILITY_AUDIT_ONLY; APPLY_IDENTITY_AND_QUOTE_FRESHNESS_GATES',
         'model_promotion':False,'automatic_source_activation':False}
now=datetime.now(ZoneInfo('Asia/Shanghai')).isoformat()
fixture={'match_id':'api-capability-audit:20261113-0927','cohort':'data-source-audit','kickoff_at':'2026-11-13T09:27:00+08:00','cutoff_at':now}
receipt=save(payload,fixture,stage='review',track='api-capability-audit',idempotency_key='20261113-api-capability-final-1')
assert verify(read(receipt['path']))['record_sha256']==receipt['sha256']
delivery={'receipt':receipt,'report_file':'report.md','report_sha256':sha(R/'report.md'),
          'source_commit':summary['source_commit'],'environment_published':False,'model_or_database_modified':False}
write(R/'delivery.json',delivery)
D.mkdir(parents=True)
files=sorted(p for p in R.rglob('*') if p.is_file() and '__pycache__' not in p.parts)+[Path(receipt['path'])]
members=[];archive=D/'api-capabilities-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
    for p in files:
        if p.is_relative_to(R):arc='WCPP/reports/'+R.name+'/'+str(p.relative_to(R))
        else:arc='WCPP/forecasts/issued-analyses/'+str(p).split('/forecasts/issued-analyses/')[1]
        tf.add(p,arcname=arc,recursive=False);members.append({'path':arc,'bytes':p.stat().st_size,'sha256':sha(p)})
with tarfile.open(archive) as tf:
    for m in members:assert hashlib.sha256(tf.extractfile(m['path']).read()).hexdigest()==m['sha256']
for name in ['report.md','audit-summary.json','competition-matrix.csv','field-capabilities.csv','delivery.json','verification.json','independent-audit.json']:
    shutil.copy2(R/name,D/name)
write(D/'manifest.json',{'schema':'WCPP-API-CAPABILITY-ARCHIVE-1','source_commit':summary['source_commit'],
    'data_parent_commit':subprocess.check_output(['git','-C',str(D.parents[1]),'rev-parse','HEAD'],text=True).strip(),
    'archive':archive.name,'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'members':members,
    'freeze_receipt':receipt,'recover_without_expiring_actions_links':True,'no_model_backup_duplication':True})
print(json.dumps({'receipt':receipt,'archive_bytes':archive.stat().st_size,'members_verified':len(members)},ensure_ascii=False))
