# 8 API实测共同边界

用户请求：针对当前20项比赛范围，实测8 API能获取的数据；API-Football和TheRundown必须重测，若API失败安排Luna浏览器核查。北京时间2026-11-13，所有数据采集由Luna执行。先读项目AGENTS.md、docs/api-first-collection.md及本地provider适配，复用历史文档/缓存定位端点，但本次可用性必须实际请求。

执行环境已实测ready，observations_current=true，spec_revision=3，network unrestricted/enforced；/workspace可执行。8个secret ready，名称与允许目的域：bsd→sports.bzzoiro.com；openfoot→openfootapi.com；_5DOLLARS→api.5dollarfootballapi.com；THE_ODDS→api.the-odds-api.com；footballdata_org→api.football-data.org；infer_yapan_zhishu→api.infersports.dev；apifootball→v3.football.api-sports.io及dashboard.api-football.com；therundown→therundown.io。不可打印凭据、异常含key URL、响应中的个人账户资料；不交叉发送密钥，redirect关闭。保留现有代理和CA，TLS校验不得关闭。API-Football不是apifootball.com，OpenFootAPI不是open-football.org足球模拟器。

先写自己的plan.json，保存本次请求范围/预算和停止条件。同服务顺序限速，API-Football>=10秒，football-data>=6秒；401/403/429停止该服务本批API请求。保留错误分类/HTTP/content-type/安全错误字段、CF-Ray或请求ID，勿重复撞端点。用户新授权允许另由指定Luna进行正常浏览器核查，但不绕过验证码、访问限制或登录。无购买、订阅、后台定时、环境发布、模型改动。

分析范围以旁边analysis-scope.json的20项为准，分清男子成年、杯赛阶段/年代/轮次；2026或2026/27当前赛季与历史可用分别核实。数据维度：赛事目录、赛程/即时比分/赛果、积分榜、历史、球队/球员、真实首发、伤停停赛、事件、统计/xG、1X2/大小球/让球、赔率历史。返回200不等于该字段有真实数据；空数组、null、占位零、文档宣传、目录存在、历史样本、未来真实数据分别标注。盘口要实际机构/市场/线/双方价/来源报价时间；抓取时间不能代替报价时间，consensus不是机构quote。

输出独立provider目录，每个服务必须capability.json及简短summary.md。尽量统一schema：provider, tested_at, requests[], authentication, current_data_status, historical_data_status, quota, capabilities[{field,status,evidence,limitations}], competition_coverage[20项，每项code/provider_id/status/evidence], blockers[], recommended_use。覆盖状态选LIVE_VERIFIED、CATALOG_LISTED、HISTORICAL_ONLY、NOT_ENTITLED、NOT_LISTED_IN_RETURNED_CATALOG、UNVERIFIED、BLOCKED，不从1个联赛外推20个全通。每个关键判断引用本次request_id/文件路径。原始公共数据可原字节保存（先检测是否含密钥/个人信息）；否则保存脱敏响应并记录原始哈希及脱敏标记。输出URL无key，时间有UTC和北京时间，SHA256、HTTP和额度保留。

已有源码 /workspace/Football-Analysis/runtime/data_sources/clients.py 可复用fetch(provider,...,credential_binding=指定当前绑定)，避免旧别名优先造成误测。其calls仅脱敏结构，raw response可能缺body诊断，必要时使用安全自写Python。数据全部放 /workspace/WCPP/reports/api-capabilities-20261113-0927/，不要写正式数据库、冻结目录或Git仓库，root会统一核验归档推送。原始错误网页可能回显密钥，保存前清理，禁止截图有key的页面。
