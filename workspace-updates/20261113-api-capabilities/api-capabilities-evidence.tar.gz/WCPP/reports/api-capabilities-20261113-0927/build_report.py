"""Build the capability audit tables from retained provider evidence; no network."""
import csv
import json
import hashlib
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
from collections import Counter
R=Path(__file__).resolve().parent
ORDER=['bsd','openfoot','5dollar','football-data','the-odds','infersports','apifootball','therundown']
NAMES={'bsd':'BSD','openfoot':'OpenFootAPI','5dollar':'5Dollar','football-data':'football-data.org','the-odds':'The Odds API','infersports':'InferSports','apifootball':'API-Football','therundown':'TheRundown'}
scope=json.loads((R/'analysis-scope.json').read_text())['competitions']
caps={name:json.loads((R/name/'capability.json').read_text()) for name in ORDER}
descriptions={
 'bsd':('可调用，9次200','赛程、赛果；单场欧冠样本有统计、xG、22条事件及双方确认首发','欧冠赛后样本；18项在目录（含欧冠）','xG来源仅按供应商返回，未独立认证；赔率缺机构/明确盘线；伤停未验证','候选过程数据源，逐联赛核验后使用'),
 'openfoot':('基础接口可用；高级事件403','英超当前赛程/赛果、球队、比赛上下文、派生xG、公允赔率参考','英超实取；另17项目录；泛亚冠存在但精英阶段未核','Starter事件权限不足；派生xG不是原生xG，fair odds不是机构报价；范围内滚球未验证','赛程/比赛背景补充，不替代真实盘口'),
 '5dollar':('可调用，10次200','英超/西甲/德甲赛程；英超完赛统计、事件；单场Bet365历史开/关盘','3项当前赛程，另意甲/法甲/J1目录；J1当前窗口为空','本轮无xG/首发/伤停实证；取得的赔率是历史，closing缺报价时间','已验证联赛赛程及赛后过程备用'),
 'football-data':('授权基础数据可用','五大联赛及荷甲当前赛程、球队/赛季/轮次；英超积分榜','6项当前赛程；世界杯仅目录；欧冠响应遗失故未验证','Odds-Package未启用；未来比赛空比分不能当赛果；采集偏差详见审计','赛程、比赛身份和积分榜基准'),
 'the-odds':('可调用，5次200','欧国联/英超/德甲机构1X2、大小球、spreads及真实报价时间；欧国联8场完赛比分','18项目录，3项赔率实取；8完赛比分+27未来/未完赛行','欧国联2条奥地利同时间对阵冲突需隔离；spreads不直接认证为亚洲盘；history未测','当前盘口主候选，先核身份与逐市场鲜度'),
 'infersports':('本轮6次200，旧401未重现','欧国联赛程及1X2、亚洲让球、大小球报价记录','仅欧国联实取；其他19项未核','47条样本仅2条让球满足60分钟鲜度，1X2/大小球均无合格新报价；有A/C分级冲突','有条件备用；当前样本不能接替新鲜大小球'),
 'apifootball':('API403；浏览器也403','本轮未取得赛事数据或套餐额度','20项本轮均受阻，非断言服务不覆盖','Cloudflare HTML；不能据此认定密钥无效','暂不可用，保留CF-Ray诊断'),
 'therundown':('API403；浏览器也403','本轮未取得赛事数据或套餐额度','20项本轮均受阻，非断言服务不覆盖','官方授权域端点及官网均Cloudflare403；未跨域发送密钥','暂不可用，保留CF-Ray诊断')}
state_names={'CATALOG_LISTED':'目录列出','NOT_LISTED_IN_RETURNED_CATALOG':'返回目录未列','UNVERIFIED':'未验证','BLOCKED':'请求受阻','NOT_ENTITLED':'未授权','HISTORICAL_ONLY':'仅历史样本'}
def state(provider,row):
    if row['status']=='LIVE_VERIFIED':return {'bsd':'实取赛后样本','openfoot':'实取赛程/上下文','5dollar':'实取赛程','football-data':'实取赛程','the-odds':'实取赔率*','infersports':'实取报价*'}[provider]
    if provider=='openfoot' and row['code']=='afc.champions':return '泛亚冠有目录/精英未核'
    return state_names.get(row['status'],row['status'])
cov={name:{x['code']:x for x in caps[name]['competition_coverage']} for name in ORDER}
for name in ORDER:assert set(cov[name])=={x['code'] for x in scope}
matrix=[]
for c in scope:matrix.append({'code':c['code'],'赛事':c['name'],**{NAMES[n]:state(n,cov[n][c['code']]) for n in ORDER}})
def csv_write(path,rows,fields):
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
csv_write(R/'competition-matrix.csv',matrix,['code','赛事',*[NAMES[n] for n in ORDER]])
field_rows=[]
for n in ORDER:
    for f in caps[n]['capabilities']:
        field_rows.append({'provider':NAMES[n],'field':f['field'],'status':f['status'],
            'evidence':json.dumps(f.get('evidence'),ensure_ascii=False) if not isinstance(f.get('evidence'),str) else f['evidence'],
            'limitations':f.get('limitations','')})
csv_write(R/'field-capabilities.csv',field_rows,['provider','field','status','evidence','limitations'])
physical=sum(len(caps[n]['requests']) for n in ORDER)
assert physical==49
summary={'schema':'WCPP-API-CAPABILITY-AUDIT-1','generated_at':datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),
    'scope_count':20,'provider_count':8,'api_requests_reported':49,'browser_navigations':2,'additional_public_therundown_request':1,
    'providers_returning_some_data':6,'fully_blocked_providers':['apifootball','therundown'],
    'count_does_not_imply_all_fields_or_competitions_available':True,'source_commit':'ddfbc43197df8944072c70135e2a2831ae1a3ef5',
    'scope_sha256':hashlib.sha256((R/'analysis-scope.json').read_bytes()).hexdigest(),
    'provider_summaries':{n:{'name':NAMES[n],'request_count':len(caps[n]['requests']),'connection':descriptions[n][0],
      'observed_data':descriptions[n][1],'observed_scope':descriptions[n][2],'limitations':descriptions[n][3],
      'recommended_role':descriptions[n][4],'competition_status_counts':dict(Counter(x['status'] for x in caps[n]['competition_coverage'])),
      'capability_path':n+'/capability.json','capability_sha256':hashlib.sha256((R/n/'capability.json').read_bytes()).hexdigest()} for n in ORDER},
    'matrix':matrix,'database_or_model_modified':False,'environment_published':False,
    'important_gaps':['No J.League Cup data verified in any of8 providers in this run','AFC Elite phase identity unresolved','No native xG across all20 competitions','No fresh InferSports1x2/totals in sampled event under60min policy','Football-data CL response lost; remains unverified']}
(R/'audit-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
lines=['# 当前20项赛事 × 8个API能力实测', '',
    '核查日期：北京时间2026年11月13日。范围以configs/analysis-scope.json为准：成年男子、90分钟含补时，杯赛等级／阶段单独核验。8个环境绑定均ready；按用户要求全部实际发起Python接口请求，并由Luna执行采集。', '',
    '**结果：6个API返回了数据；API-Football和TheRundown的接口、浏览器访问均403。能调用不等于全部赛事、字段或盘口都可用。**', '',
    '|API|本轮状态|实际拿到的数据|主要范围|限制／建议用途|',
    '|---|---|---|---|---|']
for n in ORDER:
    s=descriptions[n];lines.append(f'|{NAMES[n]}|{s[0]}|{s[1]}|{s[2]}|{s[3]}；{s[4]}|')
lines+=['','**当前赛事范围逐项清单**','','“实取”表示本批有对应类型样本，未宣称整季完整覆盖或模型已接入；“目录”只证明供应商列出了赛事；“返回目录未列”不等于永久不支持。“*”表示存在身份或鲜度限制，不能整批直接入模。','','|赛事|'+'|'.join(NAMES[n] for n in ORDER)+'|','|---|'+'|'.join('---' for n in ORDER)+'|']
for row in matrix:lines.append('|'+row['赛事']+'|'+'|'.join(row[NAMES[n]] for n in ORDER)+'|')
lines+=['', '至少一个接口本轮取得实际数据的范围为五大联赛、荷甲、欧冠与欧国联，共8项；其中欧冠验证的是赛后过程样本。其余多数只有目录证据。日联杯本轮没有从这8个API验证到目标赛事数据，亚冠精英仍有阶段身份缺口，不能按“密钥可用”一并视为已覆盖。', '',
    '**API-Football与TheRundown重测、浏览器结果**', '',
    '- API-Football使用当前绑定apifootball，Python请求官方v3.football.api-sports.io/status、x-apisports-key鉴权头，返回403 HTML，CF-Ray：a59a0136081766e9-DFW。不是未使用Python，也不是误用了另一家apifootball.com。',
    '- TheRundown使用当前绑定therundown及官方X-TheRundown-Key，访问授权域therundown.io的英超schedule端点，返回403 Cloudflare HTML，CF-Ray：a59a02c6aabbf0c1-DFW。未把密钥发往未授权子域或RapidAPI。',
    '- Luna检查了浏览器控制能力：当前没有共享桌面的CUA／browser JS工具或运行中的Chrome/CDP，因此用已有Chromium＋Playwright实际导航两家官网，继承代理且保持TLS校验。两页均为403、标题Attention Required! | Cloudflare，并显示blocked。TheRundown浏览器CF-Ray：a59a06234f5c7cdd-DFW。',
    '- 浏览器并未取得赛事页面、后台数据或可用API响应。没有登录、验证码绕过、关闭TLS、重复撞限或更换未授权主机。证据见browser/。403不足以判断密钥是否失效、套餐是否到期，精确拦截规则本轮无法确认。', '',
    '**本轮关键数据质量结论**', '',
    '1. The Odds API的机构盘口可以实际获取，但欧国联返回两条奥地利同时间比赛（对冰岛／对爱尔兰）。两行先隔离，不能将27行返回值整体称为真实已核赛程。scores返回35赛事行，其中仅8条已完赛且有比分，27条是未来／未完赛。',
    '2. InferSports先前的401本轮未重现，赛程与受保护赔率请求均200。但4场C级比赛同时被放进UEFANLA、UEFANLC且event ID不同，不能按别名直接划入A级模型。',
    '3. InferSports荷兰—希腊响应顶层stale=false仍不代表各报价新鲜。按项目现有60分钟门槛，47条报价只有2条亚洲让球满足open、有效价格和时效；6条1X2、21条大小球均不合格。最接近的大小球已64.3分钟。因此本次没有验证出可直接替代The Odds的新鲜大小球备用。',
    '4. BSD欧冠样本返回xG2.57–1.83及xg_estimated=false、确认首发和事件，但仅为单场供应商返回证据，不代表20赛事已有完整且独立认证的原生xG。赔率缺机构／盘口归属，不能当实盘。OpenFoot的2.30–0.65是derived xG；fair odds是模型基准，不是机构报价，不能混作原生xG或实盘。',
    '5. 5Dollar本轮取得的是一场已完赛比赛的Bet365历史开／关盘，closing没有来源报价时间，不能用抓取时间补齐或当当前盘口。football-data赔率消息明确要求启用Odds-Package；OpenFoot事件403明确为plan_upgrade_required，与两家Cloudflare403原因不同。',
    '6. J1在BSD/OpenFoot/The Odds目录存在，5Dollar目录也有对应条目但本次时间窗无赛程；不能据空数组断言没有权限。日联杯未验证到覆盖，泛亚冠目录也不能直接代替亚冠精英身份。', '',
    '**对本项目的使用安排**', '',
    '- 盘口优先候选仍是The Odds API，逐场校验身份、机构、市场、盘线、两边价和来源时间。InferSports保留有条件备用，本轮没有通过新鲜大小球验收。BSD聚合价格、OpenFoot fair odds不能充当同机构结算盘口。',
    '- 赛程／身份／积分榜优先使用已实测football-data范围；5Dollar和OpenFoot作已验证范围的补充。欧国联仍须分A级、C级等阶段，不能直接相信提供方别名。',
    '- 过程／首发／事件可以继续验证BSD；5Dollar作为已有统计／事件备用。xG按原生与派生分别保存，缺失伤停保持未知，不能解释为全员健康。',
    '- 日联杯及亚冠阶段缺口继续使用项目已有经核验的公开赛事源补齐；本轮没有为这两项伪造API覆盖，也没有把候选源自动写入数据库或模型。',
    '- API-Football和TheRundown暂列BLOCKED，保留CF-Ray供服务方定位；本次不再重复请求。没有必要因为这两个受阻而停用其他已能提供数据的接口。', '',
    '**额度、复核与限制**', '',
    '本轮报告49次API物理调用，另有TheRundown公开网页1次、浏览器导航2次；两家403后均停止API采集。The Odds使用11units，余量287→276；历史赔率可能另计额度，未在剩余3units预算下盲测。5Dollar状态为Community、300次／小时、20次／分钟突发；OpenFoot响应为Starter月额度5000，某次查询显示剩余4979，此值不是最终余额。其余额度按实际响应保留，未猜测套餐或购买订阅。', '',
    '采集有一项已披露偏差：football-data实际12次超出内部计划10次，最后两次间隔2.118秒低于内部6秒要求；欧冠响应被后续文件写入覆盖，原响应无法复核，故保留丢失说明并将欧冠当前能力记为未验证。没有补造或重请求补盖证据。此缺口不影响其他保留响应的字段核查。', '',
    '目录映射、时区显示、派生字段及旧文案中的错误均在冻结前校正，记录于root-corrections.json；来源数据及真实quote时间没有改写。原始字节未保留的接口响应以脱敏结构化文件、原始／规范化哈希及说明保存，不能把结构化快照说成原字节备份。', '',
    'CSV清单：competition-matrix.csv（20×8覆盖）、field-capabilities.csv（逐字段状态与证据）。每个服务的capability.json、response文件、HTTP错误、请求时间和额度均纳入归档。独立审查见independent-audit.json。', '',
    '源码仍为ddfbc43197df8944072c70135e2a2831ae1a3ef5；只新增能力审计与证据，未修改活动权重／注册表／数据库、未安装后台任务、未将凭据上传GitHub、未发布环境。', '']
(R/'report.md').write_text('\n'.join(lines))
print('20x8 coverage matrix, field table and report built; API physical calls',physical)
