# OpenFootAPI capability test — 2026-11-13

- Authentication: explicit `openfoot` binding sent as `Authorization: Bearer …`. Four initial requests returned HTTP 200; request 5 (match events) returned HTTP 403 `plan_upgrade_required`. Per the stop rule, no later requests were sent. Total: 5/9.
- Current coverage: catalog returned 120 competition rows; the 2026-11-13 batch returned 25 matches, including one live status/score/minute sample. Focused EPL 2026/27 query returned 50/380 records. One finished EPL match context was fetched.
- That context returned form, team fields, derived xG (2.3–0.65) and fair odds (1X2 implied percentages/projected fair prices). Those prices are model benchmarks, not bookmaker quotes. The record had no lineups or shot map.
- The events endpoint returned HTTP 403 and explicitly said Starter includes fixtures, scores and league standings while Developer unlocks events/commentary. Calls stopped at that response. Lineups, shot-map xG, odds endpoint and other feature routes remain untested after the stop.
- Catalog coverage of all 20 scope competitions, exact provider IDs, current batch results and status are listed row-by-row in `capability.json`. Entries marked catalog-only are not asserted as current event coverage.

The 403 response and successful payloads are in `feature-responses.json`; credentials and account key identifiers were redacted. Full response hashes and safe metadata are recorded.
