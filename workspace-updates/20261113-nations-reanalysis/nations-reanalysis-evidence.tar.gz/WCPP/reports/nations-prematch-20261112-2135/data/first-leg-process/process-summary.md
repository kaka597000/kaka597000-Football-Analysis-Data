# 本届欧国联八场首回合过程字段核查

8场已完成赛事实况。原始ESPN summary中的 STATUS_FULL_TIME、league-phase、两段比分与主客身份共同确认90分钟结果。ESPN boxscore含有统计字段，检查 `boxscore.teams[].statistics[].name` 未发现 expectedGoals/xG 字段；因此两端xG及对手xG（本方xGA）均缺失。射门数据未代替xG。采集时点、URL和响应哈希见 process-fields.json。

## Croatia 0–7 England — Group A3
- 2026-10-03T16:00Z；espn:401861113；90分钟：['0', '0'] vs ['4', '3']；neutral=False。
- xG/xGA：无。过程字段名称：Fouls, Yellow Cards, Red Cards, Offsides, Corner Kicks, Saves, Possession, SHOTS, ON GOAL, On Target %, Penalty Goals, Penalty Kicks Taken, Accurate Passes, Passes, Pass Completion %, Accurate Crosses, Crosses, Cross %, Long Balls, Accurate Long Balls, Long Balls %, Blocked Shots, Effective Tackles, Tackles, Tackle %, Interceptions, Effective Clearances, Clearances。
- 原响应 `401861113.json`；查询 2026-11-12T13:49:21.712282+00:00，捕获 2026-11-12T13:49:23.600283+00:00 UTC；SHA256 `664d5d6567a94396596b1e19dd809c795f8f975675325316ae5cc6167bd566f0`。

## Spain 3–1 Czechia — Group A3
- 2026-10-03T18:45Z；espn:401861118；90分钟：['2', '1'] vs ['0', '1']；neutral=False。
- xG/xGA：无。过程字段名称：Fouls, Yellow Cards, Red Cards, Offsides, Corner Kicks, Saves, Possession, SHOTS, ON GOAL, On Target %, Penalty Goals, Penalty Kicks Taken, Accurate Passes, Passes, Pass Completion %, Accurate Crosses, Crosses, Cross %, Long Balls, Accurate Long Balls, Long Balls %, Blocked Shots, Effective Tackles, Tackles, Tackle %, Interceptions, Effective Clearances, Clearances。
- 原响应 `401861118.json`；查询 2026-11-12T13:49:23.761584+00:00，捕获 2026-11-12T13:49:25.349048+00:00 UTC；SHA256 `ec875990000aa27fa1e2d6ca40d9034f691c5fb5afe835119d0d0e40c33c5e59`。

## France 1–1 Italy — Group A1
- 2026-10-02T18:45Z；espn:401861103；90分钟：['0', '1'] vs ['0', '1']；neutral=False。
- xG/xGA：无。过程字段名称：Fouls, Yellow Cards, Red Cards, Offsides, Corner Kicks, Saves, Possession, SHOTS, ON GOAL, On Target %, Penalty Goals, Penalty Kicks Taken, Accurate Passes, Passes, Pass Completion %, Accurate Crosses, Crosses, Cross %, Long Balls, Accurate Long Balls, Long Balls %, Blocked Shots, Effective Tackles, Tackles, Tackle %, Interceptions, Effective Clearances, Clearances。
- 原响应 `401861103.json`；查询 2026-11-12T13:49:25.520987+00:00，捕获 2026-11-12T13:49:27.150793+00:00 UTC；SHA256 `7c8229396fa82e6f2853751301939e5c150fa955aa2ce303ccf34ef9eb78f063`。

## Belgium 3–0 Türkiye — Group A1
- 2026-10-02T18:45Z；espn:401861109；90分钟：['1', '2'] vs ['0', '0']；neutral=False。
- xG/xGA：无。过程字段名称：Fouls, Yellow Cards, Red Cards, Offsides, Corner Kicks, Saves, Possession, SHOTS, ON GOAL, On Target %, Penalty Goals, Penalty Kicks Taken, Accurate Passes, Passes, Pass Completion %, Accurate Crosses, Crosses, Cross %, Long Balls, Accurate Long Balls, Long Balls %, Blocked Shots, Effective Tackles, Tackles, Tackle %, Interceptions, Effective Clearances, Clearances。
- 原响应 `401861109.json`；查询 2026-11-12T13:49:27.321205+00:00，捕获 2026-11-12T13:49:29.033684+00:00 UTC；SHA256 `4a7ffaf4784ca869171f9cbdec949488ffcdb4a534ace1beda1796cc5a53d48d`。

## Latvia 1–2 Montenegro — Group C2
- 2026-10-02T16:00Z；espn:401861105；90分钟：['0', '1'] vs ['1', '1']；neutral=False。
- xG/xGA：无。过程字段名称：Fouls, Yellow Cards, Red Cards, Offsides, Corner Kicks, Saves, Possession, SHOTS, ON GOAL, On Target %, Penalty Goals, Penalty Kicks Taken, Accurate Passes, Passes, Pass Completion %, Accurate Crosses, Crosses, Cross %, Long Balls, Accurate Long Balls, Long Balls %, Blocked Shots, Effective Tackles, Tackles, Tackle %, Interceptions, Effective Clearances, Clearances。
- 原响应 `401861105.json`；查询 2026-11-12T13:49:29.206232+00:00，捕获 2026-11-12T13:49:31.508504+00:00 UTC；SHA256 `3e76a2ce86a6f43cbd4fd348e8e32d8ab8f69b5ecce4fb6e7097e510220e8556`。

## Cyprus 2–0 Armenia — Group C2
- 2026-10-02T16:00Z；espn:401861104；90分钟：['2', '0'] vs ['0', '0']；neutral=False。
- xG/xGA：无。过程字段名称：Fouls, Yellow Cards, Red Cards, Offsides, Corner Kicks, Saves, Possession, SHOTS, ON GOAL, On Target %, Penalty Goals, Penalty Kicks Taken, Accurate Passes, Passes, Pass Completion %, Accurate Crosses, Crosses, Cross %, Long Balls, Accurate Long Balls, Long Balls %, Blocked Shots, Effective Tackles, Tackles, Tackle %, Interceptions, Effective Clearances, Clearances。
- 原响应 `401861104.json`；查询 2026-11-12T13:49:31.686225+00:00，捕获 2026-11-12T13:49:32.954290+00:00 UTC；SHA256 `b57925ae5bfbd23f6b7d56148cfa959a22b32007fedafec836ed00a16cbc2430`。

## Finland 2–1 Albania — Group C1
- 2026-10-03T13:00Z；espn:401861111；90分钟：['1', '1'] vs ['1', '0']；neutral=False。
- xG/xGA：无。过程字段名称：Fouls, Yellow Cards, Red Cards, Offsides, Corner Kicks, Saves, Possession, SHOTS, ON GOAL, On Target %, Penalty Goals, Penalty Kicks Taken, Accurate Passes, Passes, Pass Completion %, Accurate Crosses, Crosses, Cross %, Long Balls, Accurate Long Balls, Long Balls %, Blocked Shots, Effective Tackles, Tackles, Tackle %, Interceptions, Effective Clearances, Clearances。
- 原响应 `401861111.json`；查询 2026-11-12T13:49:33.113690+00:00，捕获 2026-11-12T13:49:34.317275+00:00 UTC；SHA256 `95ff024d8468ea32a9240586f2816e4d2dff51755e1194b0a23bbca241a9f2a1`。

## Belarus 4–0 San Marino — Group C1
- 2026-10-03T16:00Z；espn:401861114；90分钟：['0', '4'] vs ['0', '0']；neutral=False。
- xG/xGA：无。过程字段名称：Fouls, Yellow Cards, Red Cards, Offsides, Corner Kicks, Saves, Possession, SHOTS, ON GOAL, On Target %, Penalty Goals, Penalty Kicks Taken, Accurate Passes, Passes, Pass Completion %, Accurate Crosses, Crosses, Cross %, Long Balls, Accurate Long Balls, Long Balls %, Blocked Shots, Effective Tackles, Tackles, Tackle %, Interceptions, Effective Clearances, Clearances。
- 原响应 `401861114.json`；查询 2026-11-12T13:49:34.477963+00:00，捕获 2026-11-12T13:49:37.521920+00:00 UTC；SHA256 `6a51f73389d589223f3a3afbcfaade6aaddd883d79de8fea807dcdf48bb64a64`。
