# Early refresh — two UEFA Nations League fixtures

Capture cutoff: 2026-11-12 16:22 UTC / 2026-11-13 00:22 Beijing. Kickoff is 17:00 UTC / Nov 13 01:00 Beijing. ESPN summaries were fetched once per match. Raw JSON and request metadata are in `raw/` and `metadata/`.

## Türkiye vs Belgium — ESPN 401861145
- Identity/stage: UEFA Nations League; 2026-27 UEFA Nations League, League Phase; LEAGUE A - GROUP 1; Türkiye (ESPN 465) vs Belgium (ESPN 459). Scheduled, pre-match; neutral=False. Venue: Göztepe Gürsel Aksel Stadi, Izmir.
- Standings at capture: Belgium rank 3, 6 pts, 2-0-2; Türkiye rank 4, 0 pts, 0-0-4.
- League-phase recent results (actual home team and score first, away team and score second; team-perspective result in brackets):
  - 2026-09-25 Türkiye 0–1 France [team perspective: Türkiye 0–1; L]
  - 2026-09-25 Italy 0–2 Belgium [team perspective: Belgium 2–0; W]
  - 2026-09-28 Türkiye 1–4 Italy [team perspective: Türkiye 1–4; L]
  - 2026-09-28 Belgium 0–1 France [team perspective: Belgium 0–1; L]
  - 2026-10-02 Belgium 3–0 Türkiye [team perspective: Türkiye 0–3; L]
  - 2026-10-02 Belgium 3–0 Türkiye [team perspective: Belgium 3–0; W]
  - 2026-10-05 Italy 3–1 Türkiye [team perspective: Türkiye 1–3; L]
  - 2026-10-05 France 4–1 Belgium [team perspective: Belgium 1–4; L]
- Türkiye, latest 4 league-phase games: 2 scored / 11 conceded; own-goal zero in 2/4, exactly one in 2/4. Small sample, no xG.
- Belgium, latest 4 league-phase games: 6 scored / 5 conceded; own-goal zero in 1/4, exactly one in 1/4. Small sample, no xG.
- First-leg replay (already stored; no requery): Belgium 17 shots/10 on target, possession 53.9%, red cards 0; Türkiye 23 shots/8 on target, possession 46.1%, red cards 0.
- Lineups/availability: ESPN summary has roster rows but no separate confirmed-lineup status. Treat starter flags as unconfirmed; no verified confirmed XI. Injury endpoint absent/null. Reviewed news did not establish team-specific absences. No claim that either side is fully available.
- xG/xGA: unavailable for the fixture/recent Nations League rows in the reused sources; do not substitute shot totals. StatsBomb open competitions list had no 2026–27 Nations League entry; Understat does not cover this national-team competition.
- Standing/table motivation: Belgium is 3rd on 6 points, four behind France (1st) and one behind Italy (2nd); Türkiye is 4th on 0. Two rounds remain by six-round league-phase format. Belgium has a plausible route to move toward second, Türkiye mathematically can still reach 6 if winning both but likely needs help; exact qualification/relegation permutations not computed.
- Main evidence/limits: Belgium won 3–0 in first meeting; Türkiye’s four league matches in this cycle were all losses (2–11 goals), but shot volume in the prior meeting was substantial (23 vs Belgium 17), with only 8 vs 10 on target. Türkiye’s 1-goal pathway is present in two of four league matches (Italy 1, Belgium 0; specifically 1 scored vs Italy in 4–1 loss and 0 vs Belgium), while Belgium recorded two clean sheets; Belgium scored 2+ in two of four. Supports Belgium advantage and Türkiye scoring uncertainty; no xG to judge shot quality.

## Armenia vs Cyprus — ESPN 401861146
- Identity/stage: UEFA Nations League; 2026-27 UEFA Nations League, League Phase; GROUP C2; Armenia (ESPN 579) vs Cyprus (ESPN 445). Scheduled, pre-match; neutral=False. Venue: Vazgen Sargsyan Republican Stadium, Yerevan.
- Standings at capture: Cyprus rank 2, 7 pts, 2-1-1; Armenia rank 3, 4 pts, 1-1-2.
- League-phase recent results (actual home team and score first, away team and score second; team-perspective result in brackets):
  - 2026-09-25 Armenia 2–0 Latvia [team perspective: Armenia 2–0; W]
  - 2026-09-25 Montenegro 2–1 Cyprus [team perspective: Cyprus 1–2; L]
  - 2026-09-28 Armenia 2–3 Montenegro [team perspective: Armenia 2–3; L]
  - 2026-09-28 Latvia 0–0 Cyprus [team perspective: Cyprus 0–0; D]
  - 2026-10-02 Cyprus 2–0 Armenia [team perspective: Armenia 0–2; L]
  - 2026-10-02 Cyprus 2–0 Armenia [team perspective: Cyprus 2–0; W]
  - 2026-10-05 Cyprus 2–1 Latvia [team perspective: Cyprus 2–1; W]
  - 2026-10-05 Montenegro 0–0 Armenia [team perspective: Armenia 0–0; D]
- Armenia, latest 4 league-phase games: 4 scored / 5 conceded; own-goal zero in 2/4, exactly one in 0/4. Small sample, no xG.
- Cyprus, latest 4 league-phase games: 5 scored / 3 conceded; own-goal zero in 1/4, exactly one in 1/4. Small sample, no xG.
- First-leg replay (already stored; no requery): Cyprus 8 shots/4 on target, possession 32.3%, red cards 1; Armenia 17 shots/5 on target, possession 67.7%, red cards 0.
- Lineups/availability: ESPN summary has roster rows but no separate confirmed-lineup status. Treat starter flags as unconfirmed; no verified confirmed XI. Injury endpoint absent/null. Reviewed news did not establish team-specific absences. No claim that either side is fully available.
- xG/xGA: unavailable for the fixture/recent Nations League rows in the reused sources; do not substitute shot totals. StatsBomb open competitions list had no 2026–27 Nations League entry; Understat does not cover this national-team competition.
- Standing/table motivation: Cyprus is 2nd on 7 points, three behind Montenegro; Armenia is 3rd on 4, six behind leaders and three behind Cyprus, with two rounds remaining. Cyprus can still challenge for first; Armenia can challenge Cyprus’s second place. No motivation inference treated as outcome evidence.
- Main evidence/limits: In the first meeting, Cyprus led 2–0 by halftime; Kostas Pileas was sent off in the 52nd minute, and the score remained 2–0 at full time; Armenia still had 17 shots/5 on target vs Cyprus 8/4, but the sending-off is a major context confound. In four cycle games Armenia scored 2,2,0,0 (two zero-goal matches, no exact-one); Cyprus 1,0,2,2 (one zero, one exact-one). Both have 2+ scoring paths, while Armenia’s zero and Cyprus’s zero/one paths exist; sample is only four and first-leg red-card state limits transfer.

## Correction note

2026-11-12 16:24 UTC: Corrected the Beijing capture time to Nov 13 00:22; corrected Armenia and Cyprus chronological goals-for sequences from raw ESPN `homeTeamScore`/`awayTeamScore`; rechecked all four teams’ scoring and concession aggregates. Raw ESPN files remain unchanged.

2026-11-12 16:25 UTC: Clarified the Cyprus-Armenia first-leg sequence (2–0 at halftime, 52-minute red card, unchanged final score) and made every recent score row explicit in actual home–away order.
