"""Append the complete real prematch analysis and research TOP3, without promotion."""
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from zoneinfo import ZoneInfo
import sys

sys.path.insert(0,'/workspace/Football-Analysis/runtime')
from research.analysis_freeze import save, verify
from research.score_distribution_audit import comprehensive_audit
from research.team_goal_analysis import summarize_prediction
from research.score_distribution_audit import audit_prediction

ROOT=Path(__file__).resolve().parent
OLD=Path('/workspace/WCPP/reports/nations-prematch-20261112-2135')
FREEZES=Path('/workspace/WCPP/forecasts/issued-analyses')
BJT=ZoneInfo('Asia/Shanghai')
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def stamp():return datetime.now(timezone.utc).isoformat()
def bjt(t):return datetime.fromisoformat(t.replace('Z','+00:00')).astimezone(BJT).strftime('%m-%d %H:%M:%S')
def write(p,j):
    with Path(p).open('x') as h:json.dump(j,h,ensure_ascii=False,indent=2,allow_nan=False)
def balance(p):return p['win']+.5*p['half_win']-.5*p['half_loss']-p['loss']
def total_text(p):return (p['total_direction']+' '+str(p['total_line'])+'（轻倾向）') if p['total_direction'] else str(p['total_line'])+' 观望'

source_commit=subprocess.check_output(['git','-C','/workspace/Football-Analysis','rev-parse','HEAD'],text=True).strip()
assert not subprocess.check_output(['git','-C','/workspace/Football-Analysis','status','--porcelain'],text=True).strip()
choices=read(ROOT/'selections.json');numerical=read(ROOT/'numerical-summary.json');records=[]
first_leg={'401861145':'401861109','401861146':'401861104','401861147':'401861111',
           '401861148':'401861118','401861149':'401861114','401861150':'401861113',
           '401861151':'401861103','401861152':'401861105'}
old_records={r['fixture']['match_id']:r for r in read(OLD/'analysis-records.json')}
for n in numerical:
    f=dict(n['fixture'],cutoff_at=stamp());eid=f['source_event_id'];choice=choices[eid]
    assert f['total_quote']['line']==choice['expected_line']
    pair=read(ROOT/'candidate-update'/(f['match_id'].replace(':','-')+'.json'))
    candidates={role:dict(pair[role],team_goal_analysis=n['candidates'][role]['team_goal_analysis'],
        score_distribution_audit=n['candidates'][role]['score_distribution_audit'])for role in ('current','test')}
    totals={}
    for role in ('current','test'):
        probs=n['candidates'][role]['total_probabilities']
        side='over' if balance(probs['over'])>balance(probs['under']) else 'under'
        totals[role]={'reference_direction':side,'probabilities':probs,'line':f['total_quote']['line'],
            'source_matrix_hash':pair[role]['matrix_hash'],'rule':'existing future_validation balance: win + half_win/2 - half_loss/2 - loss',
            'independent_derived_research_reference':True,'original_candidate_record_modified':False}
    process_path=OLD/'data/first-leg-process'/(first_leg[eid]+'.json')
    news=ROOT/'data/late/news-sources.json'
    payload=dict(choice,status='EXPERIMENTAL_MANUAL_ANALYSIS' if choice['primary'] else 'ABSTAIN_MATERIAL_PERSONNEL_RISK',
        method_version='WCPP-NATIONS-MANUAL-20261113-0021',selection_scope='candidate_research',
        total_line=f['total_quote']['line'],actual_quote=f['total_quote'],
        current_test_reference=n['active_receipt'],candidate_reference=n['candidate_receipt'],
        candidate_outputs=candidates,candidate_totals_reference=totals,candidate_status='UNACCEPTED_RESEARCH_ONLY',
        previous_comprehensive_reference=old_records[f['match_id']]['comprehensive_receipt'],
        selection_evidence={k:choice[k]for k in ('compared_scores','zero_vs_one','three_plus_path','total_reason')},
        sources={'fixture':f['phase_evidence'],
            'latest_market':{'path':str(ROOT/'data/market-current/source-metadata.json'),'sha256':sha(ROOT/'data/market-current/source-metadata.json')},
            'first_leg_process':{'path':str(process_path),'sha256':sha(process_path),
                'source_url':'https://site.api.espn.com/apis/site/v2/sports/soccer/uefa.nations/summary?event='+first_leg[eid]},
            'news_index':{'path':str(news),'sha256':sha(news)},
            'latest_context':str(ROOT/'data/early/early-evidence.json') if eid in ('401861145','401861146') else str(ROOT/'data/late/evidence'/(eid+'.json'))},
        market_movement=n['market_movement'],
        xg_status='NO_CURRENT_VERIFIED_SAME_PROVIDER_XG',lineup_status='NO_INDEPENDENTLY_CONFIRMED_FULL_XI',
        full_club_workload='NOT_FULLY_VERIFIED',formal_kpi_eligible=False,active_model_promotion=False,
        numeric_weights_changed=False,source_commit=source_commit)
    out=ROOT/('comprehensive-'+eid+'-receipt.json')
    if out.exists():
        receipt=read(out);prior=verify(read(receipt['path']));assert prior['payload']==payload
    else:
        receipt=save(payload,f,stage='prematch',track='comprehensive',root=FREEZES)
        write(out,receipt)
    record=verify(read(receipt['path']));assert record['record_sha256']==receipt['sha256']
    if choice['primary'] is not None:assert record['selection_audit']['top3_ready'], record['selection_audit']
    assert record['selection_audit']['formal_kpi_eligible'] is False
    records.append(dict(n,fixture=record['fixture'],payload=payload,comprehensive_receipt=receipt))

byid={r['fixture']['source_event_id']:r for r in records}
ranked=['401861149','401861148','401861147']
reasons={
 '401861149':'优先比较零封路径与客队1/2/3球：圣马力诺本届3/4场零进球、白俄罗斯近三场零封，0-2有完整反证比较；白俄罗斯其他三场仅1球，精确两球仍不稳定。',
 '401861148':'西班牙四胜、捷克四败且首回合射正9比2；西班牙本届四场均失球，为1-2提供双方路径。亚马尔缺席和轮换风险使其不是高把握比分。',
 '401861147':'阿尔巴尼亚主场表现、芬兰剔开对圣马力诺的进球集中性及首回合早段红牌背景支持1-0；Test方向相反、人员未知，列第三而非因赔率直接排序。'}
items=[]
for rank,eid in enumerate(ranked,1):
    r=byid[eid];p=r['payload'];items.append({'rank':rank,'match_id':r['fixture']['match_id'],
        'primary':p['primary'],'wdl':p['wdl'],'total_line':p['total_line'],
        'total_direction':p['total_direction'],'comprehensive_reference':r['comprehensive_receipt'],
        'reason':reasons[eid]})
shell={'match_id':'nations-analysis-batch:20261112-evening','cohort':'uefa.nations',
       'kickoff_at':min(r['fixture']['kickoff_at']for r in records),'cutoff_at':stamp()}
top_payload={'selection_scope':'candidate_research','top3':items,
    'population':[r['fixture']['match_id']for r in records],
    'ranking_target':'unique first exact score research suitability; not WDL favorite sorting',
    'method_version':'WCPP-NATIONS-MANUAL-20261113-0021','formal_kpi_eligible':False,
    'active_model_promotion':False,'previous_versions_preserved':True}
top=save(top_payload,shell,stage='prematch',track='top3-selection',root=FREEZES)
write(ROOT/'top3-receipt.json',top)

lines=['# 欧国联赛前再分析｜北京时间2026年11月13日', '',
 '本轮8场均为成年男子欧国联联赛阶段，A/C级分开调用，90分钟口径。前两场01:00，其余03:45。按当前请求追加版本，保留11月10日及11月12日晚的首版/修订，不增加独立比赛分母。','',
 '**结论：7个综合研究比分保留，意大利—法国继续观望；英格兰大3.25、黑山大2.5改为观望。第一比分研究TOP3调整为圣马力诺—白俄罗斯0-2、捷克—西班牙1-2、阿尔巴尼亚—芬兰1-0。**','',
 '最新Pinnacle机构报价时间为11月13日00:22:20，抓取00:22:21。8场新摘要在00:22—00:24取得；没有可独立确认的完整官方首发，近期同源xG/xGA及完整俱乐部负荷仍缺失。空伤停不代表全员健康。', '',
 '**模型状态：欧国联没有通过验收的活动Current/Test路由，8场活动双模型均明确拒绝并冻结。表内Current/Test是独立研究候选，不是已经晋级的生产模型。** A级训练109场、C级174场，截止2026-10-06；已核本届前四轮在其数据中。Current只拟合等级均值/主场，Test另拟合球队攻防（半衰730天、ridge8），未学习盘口、人员、xG或完整负荷的数值权重。', '',
 '本轮真实重载工件并计算，矩阵与上一版保持相同，因为数值配方和已训练输入没有变化；最新资料用于独立综合研究。均值不是提供方xG，模型概率不是综合推荐置信度，尚无70%/80%目标达成证明。', '',
 '|开球（北京）|比赛|Current候选统计比分|Test候选统计比分|综合研究第一比分|胜平负|实际大小球判断|',
 '|---|---|---|---|---|---|---|']
for r in records:
    f,p=r['fixture'],r['payload'];lines.append(f"|{bjt(f['kickoff_at'])[6:11]}|{p['name']}|{r['candidates']['current']['primary']}|{r['candidates']['test']['primary']}|{p['primary'] or '待定'}|{p['wdl']}|{total_text(p)}|")
lines += ['', '## 第一比分研究TOP3', '',
 '|排名|比赛／开球|唯一第一比分|胜平负|大小球|排序依据与主要风险|',
 '|---|---|---|---|---|---|']
for item in items:
    r=next(r for r in records if r['fixture']['match_id']==item['match_id']);p=r['payload']
    lines.append(f"|{item['rank']}|{p['name']}／03:45|{p['primary']}|{p['wdl']}|{total_text(p)}|{item['reason']}|")
lines += ['', '本榜排序目标是第一比分的路径适合度，属于人工研究，不是已校准的命中率排序。英格兰主胜方向仍有较强相对依据，但3-1、3-0、2-1分歧大，因此移出第一比分TOP3；大小球没有足够依据的项保持观望，不强行与比分榜绑定。', '',
 f"研究TOP3冻结：`{top['freeze_id']}`，北京时间{bjt(top['recorded_at'])}；scope=`candidate_research`，未晋级。", '',
 '## 大小球单独判断', '',
 '本轮只保留亚美尼亚—塞浦路斯小2.25、土耳其—比利时小3.25的轻倾向。前者2球半赢、3球全输；后者3球半赢、4球全输。其余六场观望。研究比分的总进球数不自动代表推荐其所在的大/小区间。', '',
 '## 最新市场快照与变动', '',
 '|比赛|Pinnacle主／平／客|总球线：大／小|相较上一分析|','|---|---|---|---|']
for r in records:
    f,p=r['fixture'],r['payload'];rows=f['market_snapshots'];h=[v for v in rows if v['market']=='1x2'];o=[v for v in rows if v['market']=='totals'];oldh,newh=h[0],h[-1];oldo,newo=o[0],o[-1]
    prices=' / '.join(str(newh['decimal_odds'][k])for k in ('home','draw','away'))
    if oldo['line']!=newo['line']:change=f"总球{oldo['line']}→{newo['line']}，变盘不作同盘水位比较"
    else:change='主/平/客 '+ ' / '.join(str(oldh['decimal_odds'][k])for k in ('home','draw','away'))+' → '+prices
    q=f['total_quote'];lines.append(f"|{p['name']}|{prices}|{q['line']}：{q['over_odds']} / {q['under_odds']}|{change}|")
lines += ['', '旧端点为11月12日21:51:36，新端点为11月13日00:22:20；同机构同市场同线才比较价格。这里只是两端快照，不是完整逐时轨迹，也不是资金量、内幕或成交数据。', '']

for r in records:
    f,p=r['fixture'],r['payload'];q=f['total_quote']
    lines += ['## '+p['name'], '', '**单队进球分布（真实候选矩阵）**', '',
        '|候选|主队均值／中央80%区间|主队0／≥2／≥3球|客队均值／中央80%区间|客队0／≥2／≥3球|胜／平／负|',
        '|---|---|---|---|---|---|']
    for role in ('current','test'):
        stat=r['candidates'][role];g=stat['team_goal_analysis'];cells=[]
        for side in ('home','away'):
            a=g[side];ci=a['central_interval'];cells += [f"{a['mean']:.2f}／{ci['lower']}–{ci['upper']}",' / '.join(f"{a[k]:.1%}"for k in ('p0','p_ge_2','p_ge_3'))]
        lines.append('|'+role+'|'+'|'.join(cells)+'|'+' / '.join(f"{stat['wdl'][k]:.1%}"for k in ('主胜','平局','客胜'))+'|')
    lines += ['', '区间为模型内整数分位数区间，不是实证80%覆盖保证；区间包含的实际概率质量保存在JSON。', '',
        '**比赛路径与第一比分：** '+p['reason'], '',
        '**候选比较：** '+'、'.join(p['compared_scores'])+'。'+p['three_plus_path'], '',
        '**反证：** '+p['counter'], '', '**人员：** '+p['availability'], '', '**大小球：** '+p['total_reason'], '',
        '|候选|按实际线的统计方向（独立参考）|全赢|半赢|走盘|半输|全输|',
        '|---|---|---|---|---|---|---|']
    for role,ref in p['candidate_totals_reference'].items():
        side=ref['reference_direction'];probs=ref['probabilities'][side]
        lines.append('|'+role+'|'+('大' if side=='over' else '小')+str(q['line'])+'|'+'|'.join(f"{probs[k]:.1%}"for k in ('win','half_win','push','half_loss','loss'))+'|')
    lines += ['', '上述统计方向使用既有五类结算概率净胜方向规则，仅作两候选各自参考；综合方向可为观望。未把半赢当作全赢，未修改原模型矩阵或原候选冻结。','',
        f"盘口：Pinnacle {q['line']}，大{q['over_odds']}／小{q['under_odds']}；来源报价{bjt(q['quoted_at'])}，接收{bjt(q['query_time'])}。", '',
        f"来源：[本场最新摘要]({f['phase_evidence']['source_url']})；[首回合过程]({p['sources']['first_leg_process']['source_url']})。首回合红牌属于已发生的历史比赛环境，不代表当前停赛结论。", '',
        f"冻结：综合 `{r['comprehensive_receipt']['freeze_id']}`，{bjt(r['comprehensive_receipt']['recorded_at'])}；候选配对 `{r['candidate_receipt']['freeze_id']}`。", '']
lines += ['## 来源、版本与后续复盘口径', '',
 '本轮保存新ESPN赛程、8场摘要、The Odds API原始1X2/总球响应、4篇复取ESPN/AP消息及SHA256。近期结果使用主客队ID与homeTeamScore/awayTeamScore；忽略ESPN历史行的可疑“advances”注记，不据此改判淘汰赛。', '',
 'xG来源核查复用此前StatsBomb公开目录（没有2026–27欧国联）及Understat覆盖结论；8场首回合ESPN过程无xG字段。射门、射正和控球只作过程线索，不冒充xG。全赛事球员负荷没有完整核实，不把国家队比赛间隔当俱乐部休息。', '',
 '[法国姆巴佩消息](https://www.espn.com/soccer/story/_/id/50452835/kylian-mbappe-hamstring-miss-france-clash-italy)；[法国其他伤缺](https://www.espn.com/soccer/story/_/id/50446771/france-thuram-tchouameni-leave-squad-injuries)；[西班牙人员消息](https://www.espn.com/soccer/story/_/id/50455459/spain-lamine-yamal-injury-luis-de-la-fuente-nations-league)。', '',
 f"源码版本 `{source_commit}`；活动注册表SHA256 `{sha('/workspace/WCPP/runtime/active-model.json')}`。未重训、未晋级、未改权重。Current等级基线相同输出1-1是模型结构所致，不意味着八场比赛情况相同。", '',
 '本轮为同场追加修订：逐场Current候选/Test候选/综合各自保留，首版仍为主评价版本。本轮7个研究比分、1个比分待定、2个大小球方向，分母独立；未开赛/未完赛保持待结算，不增加独立比赛数，不从旧新版本中择优统计。研究TOP3也独立保存，不能替代全8场结果。']
report='\n'.join(lines)+'\n'
report_path=ROOT/'欧国联再分析_2026-11-13.md'
with report_path.open('x') as h:h.write(report)
report_receipt=save({'report_markdown':report,'selection_scope':'candidate_research',
    'comprehensive_receipts':[r['comprehensive_receipt']for r in records],
    'top3_receipt':top,'source_commit':source_commit,'formal_kpi_eligible':False},
    dict(shell,cutoff_at=stamp()),stage='prematch',track='analysis-report',root=FREEZES)
write(ROOT/'analysis-records.json',records)
all_receipts=[r[k]for r in records for k in ('candidate_receipt','active_receipt','comprehensive_receipt')]
all_receipts += [read(ROOT/'candidate-update/plan-receipt.json'),top,report_receipt]
for receipt in all_receipts:
    record=verify(read(receipt['path']));assert record['record_sha256']==receipt['sha256']
write(ROOT/'delivery.json',{'report_receipt':report_receipt,'top3_receipt':top,'all_receipts':all_receipts,
    'population':8,'comprehensive_scores':7,'comprehensive_abstentions':1,'ou_directions':2,
    'independent_match_count_increase':0,'source_commit':source_commit,'active_registry_changed':False,
    'report_file':report_path.name,'report_sha256':sha(report_path)})
print(json.dumps({'population':8,'report':str(report_path),'report_receipt':report_receipt,
                  'top3_receipt':top,'ou_directions':2},ensure_ascii=False))
