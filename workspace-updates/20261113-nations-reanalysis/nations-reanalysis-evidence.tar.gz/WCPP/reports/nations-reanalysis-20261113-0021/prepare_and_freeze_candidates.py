"""Retain a real prematch revision using verified new source bytes; no training."""
import hashlib
import json
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
import sys
import numpy as np

sys.path.insert(0, '/workspace/Football-Analysis')
sys.path.insert(0, '/workspace/Football-Analysis/runtime')
from nations_league import model
from prediction_engine import predict_models
from runtime.automation.market_bridge import attach_total_quote
from research.analysis_freeze import save, verify
from research.team_goal_analysis import summarize_prediction
from research.score_distribution_audit import audit_prediction
from research.market_movement import analyze
from v2.model import total_settlement

ROOT=Path(__file__).resolve().parent
OLD=Path('/workspace/WCPP/reports/nations-prematch-20261112-2135')
FREEZES=Path('/workspace/WCPP/forecasts/issued-analyses')
INDEX=Path('/workspace/nations-model-20261110/models/candidates.json')
def read(p): return json.loads(Path(p).read_text())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def stamp(): return datetime.now(timezone.utc).isoformat()
def write(p,j):
    with Path(p).open('x') as h: json.dump(j,h,ensure_ascii=False,indent=2,allow_nan=False)

metas={r['event_id']:r for r in read(ROOT/'data/late/summary-sources.json')}
for eid in ('401861145','401861146'):
    meta=read(ROOT/'data/early/metadata'/(eid+'-summary.json'))
    meta.update(raw_file=str(ROOT/'data/early/raw'/(eid+'-summary.json')),captured_at=meta['retrieved_at_utc'])
    metas[eid]=meta
market=ROOT/'data/market-current'
channel=read(market/'market-channel.json')
previous_market_hash=sha(OLD/'data/live-market-fresh-2/odds.json')
prepared=[];preflight=[]
for original in read(OLD/'prepared-fixtures.json'):
    f=deepcopy(original);eid=f['source_event_id'];meta=metas[eid]
    assert sha(meta['raw_file'])==meta['sha256']
    raw=read(meta['raw_file']);c=raw['header']['competitions'][0]
    f.update(cutoff_at=stamp(),neutral=c['neutralSite'],kickoff_at=c['date'],
             status=c['status']['type']['name'],entity='national',identity_verified=True,score_basis='regulation_90')
    f['phase_evidence']={'source_path':meta['raw_file'],'source_url':meta['url'],
                         'source_sha256':meta['sha256'],'query_time':meta['captured_at']}
    f.pop('total_quote',None)
    model.validate_future(f)
    f,audit=attach_total_quote(f,market,provider_order=('the-odds-api',),bookmaker_order=('pinnacle',))
    assert audit['status']=='ATTACHED' and f['total_quote']['bookmaker']=='pinnacle'
    f['market_snapshots']=[r for r in f['market_snapshots'] if r['source_sha256']==previous_market_hash]
    assert len(f['market_snapshots'])==2
    snap=next(s for s in channel['snapshots'] if s['target']['match_id']==f['match_id'])
    for row in snap['observations']:
        q=row['value']
        if q['bookmaker']!='pinnacle': continue
        assert q['market'] in ('h2h','totals')
        f['market_snapshots'].append({'match_id':f['match_id'],'bookmaker':q['bookmaker'],
            'market':'1x2' if q['market']=='h2h' else 'totals','line':q.get('line'),
            'decimal_odds':q['odds'],'quoted_at':q['quoted_at'],'query_time':row['observed_at'],
            'source_url':row['evidence']['url'],'source_sha256':row['evidence']['sha256']})
    assert len(f['market_snapshots'])==4
    try: predict_models(f)
    except ValueError as exc:
        assert str(exc)=='no validated identity/history model for this cohort'
        preflight.append({'match_id':f['match_id'],'active_route_error':str(exc),'checked_at':stamp()})
    else: raise ValueError('active route unexpectedly available; review required')
    prepared.append(f)
write(ROOT/'prepared-fixtures.json',prepared);write(ROOT/'active-route-check.json',preflight)
model.freeze_pairs(INDEX,prepared,ROOT/'candidate-update',FREEZES)
receipts=read(ROOT/'candidate-update/receipts.json');outputs=[]
for f,receipt in zip(prepared,receipts):
    pair=read(ROOT/'candidate-update'/(f['match_id'].replace(':','-')+'.json'))
    frozen=verify(read(receipt['path']));assert frozen['record_sha256']==receipt['sha256']
    unavailable={'status':'ABSTAIN_NO_ACTIVE_ROUTE','matrix':None,'primary':None,'input':f}
    active={'current_model':dict(unavailable,model_label='当前活动模型'),
            'test_model':dict(unavailable,model_label='test活动模型'),
            'active_registry_sha256':sha('/workspace/WCPP/runtime/active-model.json'),'candidate_substitution':False}
    active_receipt=save(active,dict(f,cutoff_at=stamp()),stage='prematch',track='current-test-pair',root=FREEZES)
    stats={}
    for role in ('current','test'):
        p=pair[role];m=np.asarray(p['matrix']);line=f['total_quote']['line']
        stats[role]={k:v for k,v in p.items() if k not in ('matrix','input')}
        stats[role].update(team_goal_analysis=summarize_prediction(p),score_distribution_audit=audit_prediction(p),
            total_probabilities={side:total_settlement(m,line,side)for side in ('over','under')})
    outputs.append({'fixture':f,'candidate_receipt':receipt,'active_receipt':active_receipt,
                    'candidates':stats,'market_movement':analyze(f)})
write(ROOT/'numerical-summary.json',outputs)
print(json.dumps({'candidate_pairs_frozen':len(outputs),'active_pairs':'8 explicit ABSTAIN revisions',
                  'model_parameters_changed':False,'out':str(ROOT/'numerical-summary.json')},ensure_ascii=False))
